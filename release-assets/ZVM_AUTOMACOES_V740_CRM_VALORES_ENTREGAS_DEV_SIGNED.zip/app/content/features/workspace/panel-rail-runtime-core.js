;(function(root,factory){"use strict";if(root)root.__extCreateRailRuntimeCore=factory;})(typeof window!=="undefined"?window:null,function(deps){
  "use strict";deps=deps||{};
  var NAV_ICONS=deps.navIcons||{},OPTIONS_DEFAULTS=deps.optionsDefaults||{},NEW_INSTALL_OPTIONS_DEFAULTS=deps.newInstallOptionsDefaults||{},OPTIONS_KEY=deps.optionsKey||"";
  var railState={
    bootGate:{observer:null,timer:0,completing:false},deferredUiBootDone:false,
    layout:{app:null,placement:null,snapshot:null,resizeObserver:null,resizeTarget:null,frame:0,reserve:-1,inlineParent:null,inlineBefore:null},viewLifecycle:[],entrancePlayed:false,
    workspaceRootObserver:null,mounting:false,lastMountAttemptAt:0
  };
  var extBridgeCall=deps.bridgeCall,extGet=deps.get,extSet=deps.set,extApplyMenuVisibility=deps.applyMenuVisibility,vectorNavChip=deps.vectorNavChip,openShellHtml=deps.openShellHtml,closeAllPanels=deps.closeAllPanels;
  var extRefreshPanelDockHost=deps.refreshPanelDockHost,extApplyWorkspaceRect=deps.applyWorkspaceRect,extClampWorkspaceRect=deps.clampWorkspaceRect,extPrunePanelRegistry=deps.prunePanelRegistry,extSyncActiveNavButtons=deps.syncActiveNavButtons;
  var extActivityCounts=deps.activityCounts,extActivityHydrate=deps.activityHydrate,extActivitySubscribe=deps.activitySubscribe,extBindNotificationRefresh=deps.bindNotificationRefresh,extRefreshNotificationBadge=deps.refreshNotificationBadge,extMaybeShowUrgentNotification=deps.maybeShowUrgentNotification;
  var extNavigateRail=deps.navigateRail,extWorkspace=deps.workspace,panelBuilderCatalog=deps.panelBuilderCatalog,railNavigation=deps.railNavigation,ensurePanel=deps.ensurePanel,_navButtonsByPanelId=deps.navButtonsByPanelId||{},toast=deps.toast;
  if(!railNavigation||typeof railNavigation.register!=="function"||typeof railNavigation.clear!=="function"||typeof ensurePanel!=="function"||!extWorkspace||typeof extWorkspace.open!=="function")throw new TypeError("Dependências de navegação da rail inválidas.");
  function extInitOnboarding(){return deps.initOnboarding?deps.initOnboarding():undefined;}
  var EXTUI_RIPPLE_SELECTOR = ".extuiNavIconBtn, .extuiNavPrimaryBtn, .extuiNavSecondaryBtn, .extuiNavLogoutBtn, .extuiThemeRadioBtn, .extuiNavPanelCloseBtn, .extuiNavAgendaCancelBtn, .extui-btn";
  document.addEventListener("click", function (ev) {
    var el = ev.target.closest ? ev.target.closest(EXTUI_RIPPLE_SELECTOR) : null;
    if (!el || el.disabled) return;
    var rect = el.getBoundingClientRect();
    var size = Math.max(rect.width, rect.height);
    var ripple = document.createElement("span");
    ripple.className = "extuiRipple";
    ripple.style.width = ripple.style.height = size + "px";
    ripple.style.left = (ev.clientX - rect.left - size / 2) + "px";
    ripple.style.top = (ev.clientY - rect.top - size / 2) + "px";
    el.appendChild(ripple);
    ripple.addEventListener("animationend", function () { ripple.remove(); });
  }, true);


  var RAIL_PIN_KEY = "EXTUI:extappRailPinned";


  function extLogoResolve(theme) {
    return extBridgeCall("resourceUrl", theme === "light" ? "logo-light" : "logo-dark");
  }
  function extHydrateRailLogo(imgEl) {
    extLogoResolve(document.documentElement.getAttribute("data-extui-theme")).then(function (url) {
      if (url && imgEl.isConnected) imgEl.src = url;
      else extRailLogoFallback(imgEl);
    }).catch(function () { extRailLogoFallback(imgEl); });
  }
  function extRailLogoFallback(imgEl) {
    if (!imgEl || !imgEl.isConnected) return;
    var fallback = document.createElement("div");
    fallback.className = "extuiNavLogo extuiNavLogoFallback";
    fallback.title = "Extensão";
    fallback.textContent = "EXTUI";
    imgEl.replaceWith(fallback);
  }
  function extHydrateOnboardingLogo(imgEl) {
    extLogoResolve(document.documentElement.getAttribute("data-extui-theme")).then(function (url) {
      if (url && imgEl.isConnected) imgEl.src = url;
      else extOnboardingLogoFallback(imgEl);
    }).catch(function () { extOnboardingLogoFallback(imgEl); });
  }
  function extOnboardingLogoFallback(imgEl) {
    if (!imgEl || !imgEl.isConnected) return;
    var fallback = document.createElement("span");
    fallback.textContent = "EXTUI";
    imgEl.replaceWith(fallback);
  }
  function extRailElementVisible(el) {
    if (!el || !el.isConnected) return false;
    try {
      var rect = el.getBoundingClientRect(), cs = getComputedStyle(el);
      return rect.width >= 1 && rect.height >= 1 && cs.display !== "none" && cs.visibility !== "hidden";
    } catch (_) { return false; }
  }
  function extWhatsAppShellReadyForRail() {
    if (!document.body || document.documentElement.getAttribute("data-extui-theme-ready") !== "true") return false;
    var app = extFindWhatsAppAppRoot();
    if (!app || !extRailElementVisible(app)) return false;
    var primary = document.querySelector('[data-testid="navbar-primary-section"]');
    var footer = document.querySelector('[data-testid="navbar-footer-section"]');
    if (!extRailElementVisible(primary) || !extRailElementVisible(footer)) return false;
    var surface = extFindNativeRailSurface(app, document.getElementById("extapp-sidebar-nav-root"));
    return !!(surface && surface.el && extRailElementVisible(surface.el));
  }
  function extStopRailBootGate() {
    if (railState.bootGate.observer) { try { railState.bootGate.observer.disconnect(); } catch (_) {} railState.bootGate.observer = null; }
    if (railState.bootGate.timer) { clearTimeout(railState.bootGate.timer); railState.bootGate.timer = 0; }
  }
  function extCompleteThemeBeforeRailMount() {
    try {
      var theme = window.__extThemeSystem;
      if (theme && typeof theme.load === "function" && typeof theme.apply === "function") {
        return Promise.resolve(theme.load()).then(function (opts) { theme.apply(opts); return opts; }).catch(function () { return null; });
      }
      if (theme && typeof theme.ready === "function") return Promise.resolve(theme.ready()).catch(function () { return null; });
    } catch (_) {}
    return Promise.resolve(null);
  }
  function extFinishDeferredUiBoot() {
    if (railState.deferredUiBootDone) return;
    railState.deferredUiBootDone = true;
    try { extBindNotificationRefresh(); } catch (_) {}
    try { extInitOnboarding(); } catch (_) {}
  }
  function extArmRailBootGate() {
    if (railState.bootGate.completing) return;
    function check() {
      if (!extWhatsAppShellReadyForRail()) return false;
      railState.bootGate.completing = true;
      extStopRailBootGate();
      extCompleteThemeBeforeRailMount().then(function () {
        railState.bootGate.completing = false;
        railState.lastMountAttemptAt = 0;
        extAttemptMount(true);
      });
      return true;
    }
    if (check()) return;
    if (!railState.bootGate.observer && document.documentElement) {
      var railGateQueued=false;
      railState.bootGate.observer = new MutationObserver(function () {
        if(railGateQueued)return;
        railGateQueued=true;
        requestAnimationFrame(function(){railGateQueued=false;check();});
      });
      try { railState.bootGate.observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["data-extui-theme-ready"] }); } catch (_) {}
    }
    if (!railState.bootGate.timer) {
      railState.bootGate.timer = setTimeout(function () {
        railState.bootGate.timer = 0;
        check();
      }, 2000);
    }
  }
  function extRailOwn(cleanup) { if (typeof cleanup === "function") railState.viewLifecycle.push(cleanup); return cleanup; }
  function extResetRailViewLifecycle() { var cleanups = railState.viewLifecycle.splice(0); for (var i = cleanups.length - 1; i >= 0; i--) { try { cleanups[i](); } catch (_) {} } }
  function extRailSetTimeout(fn, delay) { var timer = setTimeout(fn, delay); extRailOwn(function () { clearTimeout(timer); }); return timer; }
  function extEnsureRailResizeObserver(bar) {
    if (!bar || typeof ResizeObserver !== "function") return;
    if (railState.layout.resizeObserver && railState.layout.resizeTarget === bar) return;
    if (railState.layout.resizeObserver) { try { railState.layout.resizeObserver.disconnect(); } catch (_) {} }
    railState.layout.resizeTarget = bar;
    railState.layout.resizeObserver = new ResizeObserver(function () {
      var current = railState.layout.resizeTarget;
      if (!current || !current.isConnected) return;
      extSyncWhatsAppRailVisuals(current);
      if (current.classList.contains("extuiOuterDock")) extApplyOuterRailReserve(current);
    });
    railState.layout.resizeObserver.observe(bar);
  }
  function extRailPlacement() {
    return document.documentElement.getAttribute("data-extui-sidebar-placement") === "right-conversation" ? "right-conversation" : "left-native";
  }

  function extUsableCssColor(value) {
    value = String(value || "").trim();
    if (!value || value === "transparent") return false;
    var m = value.match(/^rgba?\(([^)]+)\)$/i);
    if (m) {
      var parts = m[1].split(",").map(function (x) { return x.trim(); });
      if (parts.length > 3 && Number(parts[3]) <= 0.05) return false;
    }
    return true;
  }

  function extFindNativeRailSurface(app, bar) {
    if (!app) return null;var appRect=app.getBoundingClientRect(),expectedLeft=appRect.left;if(bar&&bar.classList&&bar.classList.contains("extuiInlineDock")){try{expectedLeft+=bar.getBoundingClientRect().width;var dockHost=document.getElementById("extapp-panel-dock-host");if(dockHost&&!dockHost.hidden&&dockHost.parentElement===bar.parentElement)expectedLeft+=dockHost.getBoundingClientRect().width;}catch(_){}}
    function candidate(el,bonus){if(!el||el===bar||bar&&bar.contains(el))return null;var rect,cs;try{rect=el.getBoundingClientRect();cs=getComputedStyle(el);}catch(_){return null;}if(!rect||rect.width<44||rect.width>96||rect.height<window.innerHeight*.58||Math.abs(rect.left-expectedLeft)>28)return null;if(!cs||cs.display==="none"||cs.visibility==="hidden"||!extUsableCssColor(cs.backgroundColor))return null;return{el:el,style:cs,score:(bonus||0)+120-Math.abs(rect.width-64)-Math.abs(rect.left-expectedLeft)*2};}
    var best=null,bestScore=-1,seeds=[document.querySelector('[data-testid="navbar-primary-section"]'),document.querySelector('[data-testid="navbar-footer-section"]')].filter(Boolean);seeds.forEach(function(seed){var n=seed,depth=0;while(n&&n!==app&&depth++<6){var c=candidate(n,220-depth*8);if(c&&c.score>bestScore){best=c;bestScore=c.score;}n=n.parentElement;}});if(best)return best;
    var nodes=app.querySelectorAll("nav,aside,div"),max=Math.min(nodes.length,900);for(var i=0;i<max;i++){var c2=candidate(nodes[i],0);if(c2&&c2.score>bestScore){best=c2;bestScore=c2.score;}}return best;
  }

  function extFindInlineDockSlot(app, bar) {
    if (!app) return null;
    var nativeSurface = extFindNativeRailSurface(app, bar);
    if (!nativeSurface || !nativeSurface.el) return null;
    var node = nativeSurface.el, appRect = app.getBoundingClientRect();
    while (node && node.parentElement && node.parentElement !== document.body) {
      var parent = node.parentElement, pr, nr, cs;
      try { pr = parent.getBoundingClientRect(); nr = node.getBoundingClientRect(); cs = getComputedStyle(parent); } catch (_) { pr = null; }
      if (pr && nr && cs) {
        var display = String(cs.display || ""), direction = String(cs.flexDirection || "row");
        var horizontal = display.indexOf("flex") >= 0 ? direction.indexOf("column") !== 0 : display.indexOf("grid") >= 0;
        var tall = pr.height >= Math.min(window.innerHeight * 0.65, appRect.height * 0.72);
        var wide = pr.width >= Math.min(360, appRect.width * 0.55);
        var inlineOffset = bar && bar.classList && bar.classList.contains("extuiInlineDock") && bar.parentElement === parent ? bar.getBoundingClientRect().width : 0;
        var dockHost = document.getElementById("extapp-panel-dock-host");
        if (dockHost && !dockHost.hidden && dockHost.parentElement === parent) inlineOffset += dockHost.getBoundingClientRect().width;
        var startsLeft = Math.abs((nr.left - pr.left) - inlineOffset) <= 28;
        if (horizontal && tall && wide && startsLeft) return { parent: parent, before: node, nativeSurface: nativeSurface };
      }
      if (parent === app) break;
      node = parent;
    }
    return null;
  }

  function extSyncWhatsAppRailVisuals(bar) {
    if (!bar || !bar.isConnected) return;
    var bg = "", fg = "", border = "";
    try {
      var rootStyle = getComputedStyle(document.documentElement);
      ["--navbar-background","--panel-background","--background-default","--app-background"].some(function (name) {
        var value = rootStyle.getPropertyValue(name);
        if (extUsableCssColor(value)) { bg = value.trim(); return true; }
        return false;
      });
      ["--icon","--secondary","--primary-strong"].some(function (name) {
        var value = rootStyle.getPropertyValue(name);
        if (extUsableCssColor(value)) { fg = value.trim(); return true; }
        return false;
      });
      var app = extFindWhatsAppAppRoot();
      var nativeSurface = extFindNativeRailSurface(app, bar);
      if (nativeSurface) {
        bg = nativeSurface.style.backgroundColor || bg;
        fg = nativeSurface.style.color || fg;
        border = nativeSurface.style.borderRightColor || nativeSurface.style.borderColor || border;
      }
      if (!extUsableCssColor(bg) && app) { var appStyle=getComputedStyle(app); if(appStyle&&extUsableCssColor(appStyle.backgroundColor)) bg=appStyle.backgroundColor; }
      if (!extUsableCssColor(bg) && document.body) { var bodyStyle=getComputedStyle(document.body); if(bodyStyle&&extUsableCssColor(bodyStyle.backgroundColor)) bg=bodyStyle.backgroundColor; }
    } catch (_) {}
    if (!extUsableCssColor(bg)) bg = "rgb(29, 31, 31)";
    if (!extUsableCssColor(fg)) { var _m=String(bg).match(/rgba?\(\s*(\d+)\D+(\d+)\D+(\d+)/i),_light=_m&&((.2126*Number(_m[1])+.7152*Number(_m[2])+.0722*Number(_m[3]))/255>.58); fg=_light?"rgb(84, 101, 111)":"rgb(174, 186, 193)"; }
    if (!extUsableCssColor(border) || border === bg) border = String(fg).indexOf("84, 101, 111")>=0?"rgba(17,27,33,.10)":"rgba(255,255,255,.055)";
    bar.style.setProperty("--extui-wa-rail-bg", bg);
    bar.style.setProperty("--extui-wa-rail-fg", fg);
    bar.style.setProperty("--extui-wa-rail-border", border);
  }
  function extInlineStyleSnapshot(el) {
    var out = {};
    ["left","right","width","max-width","min-width","margin-left","margin-right","box-sizing"].forEach(function (name) {
      out[name] = { value: el.style.getPropertyValue(name), priority: el.style.getPropertyPriority(name) };
    });
    return out;
  }
  function extRestoreInlineStyle(el, snapshot) {
    if (!el || !snapshot) return;
    Object.keys(snapshot).forEach(function (name) {
      var item = snapshot[name];
      if (item && item.value) el.style.setProperty(name, item.value, item.priority || "");
      else el.style.removeProperty(name);
    });
    el.style.removeProperty("--extui-outer-rail-reserve");
    el.classList.remove("extuiRailAppShiftLeft", "extuiRailAppShiftRight");
  }
  function extFindWhatsAppAppRoot() {
    var app = document.getElementById("app");
    if (app && app !== document.body && app.isConnected) return app;
    var main = document.getElementById("main");
    if (!main) return null;
    var node = main;
    while (node.parentElement && node.parentElement !== document.body) node = node.parentElement;
    return node && node !== document.body ? node : null;
  }
  function extReflowActiveWorkspaceForRail() {
    if (typeof extWorkspace === "undefined" || !extWorkspace || !extWorkspace.activePanel) return;
    if (typeof extClampWorkspaceRect !== "function" || typeof extApplyWorkspaceRect !== "function") return;
    var active=extWorkspace.activePanel;
    if (!active || !active.isConnected) return;
    requestAnimationFrame(function () { if (active.isConnected) extApplyWorkspaceRect(active, extClampWorkspaceRect(active.getBoundingClientRect())); });
  }
  function extApplyOuterRailReserve(bar) {
    if (!bar || !bar.isConnected) return false;
    var placement = extRailPlacement();
    var app = extFindWhatsAppAppRoot();
    if (!app) return false;
    var st = railState.layout;
    if (st.app !== app || st.placement !== placement) {
      if (st.app) extRestoreInlineStyle(st.app, st.snapshot);
      st.app = app;
      st.placement = placement;
      st.snapshot = extInlineStyleSnapshot(app);
    }
    var hidden = bar.classList.contains("extuiNavBarHidden") || window.getComputedStyle(bar).display === "none";
    var rect = bar.getBoundingClientRect();
    var reserve = hidden ? 0 : Math.max(0, Math.ceil(rect.width || (bar.classList.contains("extuiExpanded") ? 226 : 56)));
    var computed = window.getComputedStyle(app);
    var positioned = computed.position === "fixed" || computed.position === "absolute";
    app.style.setProperty("--extui-outer-rail-reserve", reserve + "px");
    app.style.setProperty("box-sizing", "border-box");
    app.style.setProperty("min-width", "0");
    app.classList.toggle("extuiRailAppShiftLeft", placement === "left-native");
    app.classList.toggle("extuiRailAppShiftRight", placement === "right-conversation");
    var reserveChanged=st.reserve!==reserve;
    st.reserve=reserve;
    if (positioned) {
      app.style.setProperty("width", "auto");
      app.style.setProperty("max-width", "none");
      app.style.setProperty("margin-left", "0");
      app.style.setProperty("margin-right", "0");
      if (placement === "left-native") {
        app.style.setProperty("left", reserve + "px");
        app.style.setProperty("right", "0");
      } else {
        app.style.setProperty("left", "0");
        app.style.setProperty("right", reserve + "px");
      }
    } else {
      app.style.removeProperty("left");
      app.style.removeProperty("right");
      app.style.setProperty("width", "calc(100% - " + reserve + "px)");
      app.style.setProperty("max-width", "calc(100% - " + reserve + "px)");
      if (placement === "left-native") {
        app.style.setProperty("margin-left", reserve + "px");
        app.style.setProperty("margin-right", "0");
      } else {
        app.style.setProperty("margin-left", "0");
        app.style.setProperty("margin-right", reserve + "px");
      }
    }
    if (reserveChanged) extReflowActiveWorkspaceForRail();
    return true;
  }
  function extPlayRailEntrance(bar) {
    if (railState.entrancePlayed || !bar || !bar.isConnected) return;
    railState.entrancePlayed = true;
    bar.classList.add("extuiRailEntrance");
    var logo = bar.querySelector(".extuiNavLogoBtn");
    if (logo) logo.classList.add("extuiRailEntranceLogo");
    window.setTimeout(function () {
      if (bar && bar.isConnected) bar.classList.remove("extuiRailEntrance");
      if (logo && logo.isConnected) logo.classList.remove("extuiRailEntranceLogo");
    }, 900);
  }

  function extPlaceRail(bar) {
    if (!bar) return false;
    if (!extWhatsAppShellReadyForRail()) {
      bar.classList.add("extuiRailBootPending");
      extArmRailBootGate();
      return false;
    }
    bar.classList.remove("extuiRailBootPending");
    var placement = extRailPlacement(), app = extFindWhatsAppAppRoot();
    bar.setAttribute("data-extui-dock-side", placement);
    bar.classList.toggle("extuiDockLeftNative", placement === "left-native");
    bar.classList.toggle("extuiDockRightConversation", placement === "right-conversation");
    if (placement === "left-native" && app) {
      var slot = extFindInlineDockSlot(app, bar);
      if (slot && slot.parent && slot.before) {
        if (railState.layout.app) extRestoreInlineStyle(railState.layout.app, railState.layout.snapshot);
        railState.layout.app = app; railState.layout.placement = placement; railState.layout.snapshot = null; railState.layout.reserve = 0;
        railState.layout.inlineParent = slot.parent; railState.layout.inlineBefore = slot.before;
        bar.classList.remove("extuiOuterDock", "extuiLayoutFallback");
        bar.classList.add("extuiInlineDock", "extuiLayoutIntegrated");
        var dockHost=document.getElementById("extapp-panel-dock-host");
        var hostBetween=!!(dockHost&&!dockHost.hidden&&dockHost.parentElement===slot.parent&&dockHost.previousElementSibling===bar&&dockHost.nextElementSibling===slot.before);
        if (bar.parentElement !== slot.parent || (bar.nextSibling !== slot.before && !hostBetween)) {
          slot.parent.insertBefore(bar, slot.before);
          if (dockHost&&!dockHost.hidden) slot.parent.insertBefore(dockHost, slot.before);
        }
        extSyncWhatsAppRailVisuals(bar);
        if(typeof extRefreshPanelDockHost==="function")extRefreshPanelDockHost();
        extEnsureRailResizeObserver(bar);
        extPlayRailEntrance(bar);
        return true;
      }
    }
    bar.classList.remove("extuiInlineDock", "extuiLayoutIntegrated");
    bar.classList.add("extuiOuterDock", "extuiLayoutFallback");
    extSyncWhatsAppRailVisuals(bar);
    if (document.body && bar.parentElement !== document.body) document.body.appendChild(bar);
    var applied = extApplyOuterRailReserve(bar);
    extEnsureRailResizeObserver(bar);
    if (applied) extPlayRailEntrance(bar);
    return applied;
  }
  function extScheduleRailLayout() {
    if (railState.layout.frame) return;
    railState.layout.frame = requestAnimationFrame(function () {
      railState.layout.frame = 0;
      var bar = document.getElementById("extapp-sidebar-nav-root");
      if (bar) extPlaceRail(bar);
      else extAttemptMount();
    });
  }
  window.__extScheduleRailLayout = extScheduleRailLayout;
  function buildNavBar() {
    if (document.getElementById("extapp-sidebar-nav-root")) return;
    extResetRailViewLifecycle();
    var bar = document.createElement("div");
    bar.id = "extapp-sidebar-nav-root";
    bar.className = "extuiNavBar";
    bar.setAttribute("data-extui-academy-target", "rail");
    var railPinned = false;

    function setExpanded(on) { var before=bar.classList.contains("extuiExpanded"); bar.classList.toggle("extuiExpanded", !!on); if(before!==!!on) requestAnimationFrame(extScheduleRailLayout); }


    window.__extCollapseRailForPanel = function () {
      if (!railPinned) setExpanded(false);
      if (document.activeElement && bar.contains(document.activeElement)) document.activeElement.blur();
    };

    var logoRow = document.createElement("div");
    logoRow.className = "extuiNavLogoRow";


    var logoBtn = document.createElement("button");
    logoBtn.type = "button";
    logoBtn.className = "extuiNavLogoBtn";
    logoBtn.setAttribute("aria-label", "Abrir Painel de Controle");
    logoBtn.setAttribute("data-extui-academy-target", "rail-logo");
    var logo = document.createElement("img");
    logo.className = "extuiNavLogo";


    logo.alt = "";


    logo.addEventListener("error", function () { extRailLogoFallback(logo); }, { once: true });
    extHydrateRailLogo(logo);
    var railThemeObserver = new MutationObserver(function () { extHydrateRailLogo(logo); });
    railThemeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-extui-theme"] });
    extRailOwn(function () { railThemeObserver.disconnect(); });
    logoBtn.appendChild(logo);
    logoBtn.addEventListener("mouseenter", function () { showTooltip(logoBtn, "Painel de Controle"); });
    logoBtn.addEventListener("mouseleave", hideTooltip);
    logoBtn.addEventListener("focus", function () { showTooltip(logoBtn, "Painel de Controle"); });
    logoBtn.addEventListener("blur", hideTooltip);


    logoBtn.addEventListener("click", function (ev) {
      ev.stopPropagation();
      closeAllPanels();
      openShellHtml();
    });
    logoRow.appendChild(logoBtn);

    var pinBtn = document.createElement("button");
    pinBtn.type = "button";
    pinBtn.className = "extuiNavPinBtn";
    pinBtn.innerHTML = '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/></svg>';
    function paintPin() {
      pinBtn.classList.toggle("extuiActive", railPinned);
      pinBtn.title = railPinned ? "Desafixar menu" : "Fixar menu expandido";
      pinBtn.setAttribute("aria-label", pinBtn.title);
      pinBtn.setAttribute("aria-pressed", String(railPinned));
    }
    paintPin();
    pinBtn.addEventListener("click", async function () {
      railPinned = !railPinned;
      paintPin();
      setExpanded(railPinned);
      try { await extSet(RAIL_PIN_KEY, railPinned); } catch (err) { }
    });
    logoRow.appendChild(pinBtn);


    bar.appendChild(logoRow);
    var navScroll = document.createElement("div");
    navScroll.className = "extuiNavScroll";
    navScroll.tabIndex = 0;
    navScroll.setAttribute("aria-label", "Atalhos da extensão");
    navScroll.addEventListener("wheel", function (ev) {
      if (navScroll.scrollHeight <= navScroll.clientHeight + 1) return;
      var delta = Number(ev.deltaY) || 0;
      if (ev.deltaMode === 1) delta *= 36; else if (ev.deltaMode === 2) delta *= Math.max(1, navScroll.clientHeight);
      var before = navScroll.scrollTop;
      navScroll.scrollTop += delta;
      if (navScroll.scrollTop !== before) { ev.preventDefault(); ev.stopPropagation(); }
    }, { passive: false });
    navScroll.addEventListener("keydown", function (ev) {
      var amount = 0;
      if (ev.key === "ArrowDown") amount = 44; else if (ev.key === "ArrowUp") amount = -44; else if (ev.key === "PageDown") amount = Math.max(120, navScroll.clientHeight * 0.8); else if (ev.key === "PageUp") amount = -Math.max(120, navScroll.clientHeight * 0.8);
      else if (ev.key === "Home") { navScroll.scrollTop = 0; ev.preventDefault(); return; }
      else if (ev.key === "End") { navScroll.scrollTop = navScroll.scrollHeight; ev.preventDefault(); return; }
      if (amount) { navScroll.scrollTop += amount; ev.preventDefault(); ev.stopPropagation(); }
    });
    bar.appendChild(navScroll);
    extGet(RAIL_PIN_KEY).then(function (v) {
      railPinned = !!v;
      paintPin();
      if (railPinned) setExpanded(true);
    }).catch(function () {});


    var tooltipEl = document.createElement("div");
    tooltipEl.className = "extuiTooltip";
    document.body.appendChild(tooltipEl);
    function showTooltip(target, text) {
      if (bar.classList.contains("extuiExpanded")) return;
      var rect = target.getBoundingClientRect();
      tooltipEl.textContent = text;
      tooltipEl.style.top = (rect.top + rect.height / 2) + "px";
      if (extRailPlacement() === "left-native") { tooltipEl.style.removeProperty("right"); tooltipEl.style.left = (rect.right + 8) + "px"; }
      else { tooltipEl.style.removeProperty("left"); tooltipEl.style.right = (window.innerWidth - rect.left + 8) + "px"; }
      tooltipEl.classList.add("extuiVisible");
    }
    function hideTooltip() { tooltipEl.classList.remove("extuiVisible"); }


    var buttons = [
      { key: "itens", category: "comunicacao", accent: "#14b8a6", icon: NAV_ICONS.itens, title: "Itens", desc: "Biblioteca de mensagens, áudios, mídias, documentos, Pix, fluxos e funis salvos", action: function () {
        try {
          var registry = window.ExtensionCore && window.ExtensionCore.PanelControllers;
          var controller = registry && registry.items;
          if (!controller || typeof controller.open !== "function") { toast("Painel de Itens não carregou nesta aba. Recarregue a página (F5) e tente de novo.", true); return; }
          if (extWorkspace.isOpen(document.getElementById("ext-items-panel-root"))) extWorkspace.close();
          else controller.open();
        } catch (err) { toast("Erro ao abrir Itens. Recarregue a página.", true); }
      } },


      panelBuilderCatalog.nav("crm"),
      panelBuilderCatalog.nav("crm-funnel"),
      panelBuilderCatalog.nav("encomendas"),
      panelBuilderCatalog.nav("delivery"),
      panelBuilderCatalog.nav("envios"),
      { key: "disparos", category: "comunicacao", panelId: "ext-broadcast-panel-root", accent: "#a855f7", icon: NAV_ICONS.disparos, title: "Disparo em massa", desc: "Envie um item para uma lista de números", action: function () {
        try {
          var registry = window.ExtensionCore && window.ExtensionCore.PanelControllers;
          var controller = registry && registry.broadcast;
          if (!controller || typeof controller.open !== "function") { toast("Painel de Disparo em massa não carregou nesta aba. Recarregue a página (F5) e tente de novo.", true); return; }
          if (extWorkspace.isOpen(document.getElementById("ext-broadcast-panel-root"))) extWorkspace.close();
          else controller.open();
        } catch (err) { toast("Erro ao abrir Disparo em massa. Recarregue a página.", true); }
      } },
      panelBuilderCatalog.nav("fluxos"),
      panelBuilderCatalog.nav("funis"),


      panelBuilderCatalog.nav("resposta-rapida"),
      panelBuilderCatalog.nav("followup"),
      panelBuilderCatalog.nav("autoatendimento"),
      panelBuilderCatalog.nav("status"),
      panelBuilderCatalog.nav("ferramentas"),
      panelBuilderCatalog.nav("agenda"),
      panelBuilderCatalog.nav("notas"),
      panelBuilderCatalog.nav("lembrete"),
      panelBuilderCatalog.nav("google-calendar"),
      panelBuilderCatalog.nav("assinatura"),
      panelBuilderCatalog.nav("assistente-texto"),
      panelBuilderCatalog.nav("substituicao-texto"),
      panelBuilderCatalog.nav("google"),
      { key: "salvar", category: "clientes", accent: "#10b981", icon: NAV_ICONS.salvar, title: "Exportar contatos", desc: "Exporte contatos para CSV ou vCard", action: async function () {
        var registry = window.ExtensionCore && window.ExtensionCore.PanelControllers;
        var controller = registry && registry.items;
        if (!controller || typeof controller.open !== "function" || typeof controller.exportContacts !== "function") { toast("Painel de Itens não carregou nesta aba. Recarregue a página (F5) e tente de novo.", true); return; }
        var itensRoot = document.getElementById("ext-items-panel-root");
        if (!itensRoot || !itensRoot.classList.contains("extuiOpen")) {
          closeAllPanels();
          controller.open();
        }
        controller.exportContacts();
      } },
      panelBuilderCatalog.nav("notificacoes"),
      panelBuilderCatalog.nav("sistema"),


      panelBuilderCatalog.nav("webhooks")
    ];

    buttons.forEach(function (b) {
      var btn = null;
      if (!b.hidden) {
        btn = document.createElement("button");
        btn.type = "button";
        btn.className = "extuiNavIconBtn";
        btn.style.setProperty("--extui-nav-accent", "var(--extui-primary, #00c85a)");
        btn.setAttribute("data-extui-nav-key", b.key);
        btn.setAttribute("data-extui-nav-category", b.category || "geral");
        btn.setAttribute("data-extui-academy-target", "rail-" + b.key);


        btn.setAttribute("aria-label", b.desc ? (b.title + ": " + b.desc) : b.title);
        btn.setAttribute("aria-pressed", "false");
        btn.replaceChildren();
        btn.appendChild(vectorNavChip(b.icon, b.key));
        var navLabel = document.createElement("span");
        navLabel.className = "extuiNavLabel";
        navLabel.textContent = b.title;
        btn.appendChild(navLabel);
        var tooltipText = b.title;
        btn.addEventListener("mouseenter", function () { showTooltip(btn, tooltipText); });
        btn.addEventListener("mouseleave", hideTooltip);
        btn.addEventListener("focus", function () { showTooltip(btn, tooltipText); });
        btn.addEventListener("blur", hideTooltip);
        if (b.panelId) _navButtonsByPanelId[b.panelId] = btn;


        if (b.key === "envios") {
          var badge = document.createElement("span");
          badge.className = "extuiNavBadge";
          badge.style.display = "none";
          btn.querySelector(".extuiNavIconChip").appendChild(badge);
          var updateEnviosBadge = function () {
            var n = extActivityCounts();
            badge.textContent = n > 9 ? "9+" : String(n);
            badge.style.display = n > 0 ? "flex" : "none";
          };
          extRailOwn(extActivitySubscribe(updateEnviosBadge));
          extActivityHydrate().then(updateEnviosBadge);
        }
      }
      railNavigation.register(b.key, async function (options) {
        options = options || {};
        var panel = b.panelId ? document.getElementById(b.panelId) : null;
        if (b.action) {


          if (!(options.ensureOpen === true && panel && panel.classList.contains("extuiOpen"))) {
            await b.action(options);
          }
          panel = b.panelId ? document.getElementById(b.panelId) : null;
        } else {
          panel = await ensurePanel(b.key, b.builder);
          if (options.ensureOpen === true) {
            if (!panel.classList.contains("extuiOpen")) {
              extWorkspace.open(panel);
            }
          } else {
            extWorkspace.open(panel);
          }
        }
        if (panel) panel.setAttribute("data-extui-academy-target", "panel-" + b.key);
        extSyncActiveNavButtons();
        return {
          key: b.key,
          panelId: b.panelId || null,
          open: !!(panel && panel.classList.contains("extuiOpen")),
          panelReady: !b.panelId || !!panel
        };
      });
      if (btn) {
        btn.addEventListener("click", function () {
          extNavigateRail(b.key, { source: "user", ensureOpen: false }).catch(function (err) {
            var message = err && err.message ? err.message : "Este recurso não conseguiu abrir.";
            if (/conexão segura|canal seguro|WPP_SECURE_CHANNEL|context invalidated/i.test(message)) message = "A conexão com o WhatsApp ainda está iniciando. Tente novamente em alguns segundos ou recarregue esta aba.";
            toast(message, true);
          });
        });
        navScroll.appendChild(btn);
      }
    });
    extPlaceRail(bar);
    extGet(OPTIONS_KEY).then(function(raw){var opts=raw?(typeof raw==="string"?JSON.parse(raw):raw):NEW_INSTALL_OPTIONS_DEFAULTS;extApplyMenuVisibility(opts||{});}).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SIDEBAR_OPTIONS_HYDRATE_FAILED",err);});
    extRefreshNotificationBadge().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SIDEBAR_NOTIFICATION_BADGE_REFRESH_FAILED",err);});
    extRailSetTimeout(function(){extMaybeShowUrgentNotification().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SIDEBAR_URGENT_NOTIFICATION_REFRESH_FAILED",err);});},1200);
    extWatchWorkspaceRoot();
  }




  var EXTUI_MOUNT_RETRY_BACKOFF_MS = 2000;
  function extAttemptMount(forceReady) {
    if (window.__EXT_SIDEBAR_ENABLED__ === true) {
      var legacyRail = document.getElementById("extapp-sidebar-nav-root");
      if (legacyRail) legacyRail.remove();
      extFinishDeferredUiBoot();
      return;
    }
    if (!forceReady && !extWhatsAppShellReadyForRail()) { extArmRailBootGate(); return; }
    var existingBar = document.getElementById("extapp-sidebar-nav-root");
    if (existingBar) { if (extPlaceRail(existingBar)) extFinishDeferredUiBoot(); return; }
    if (railState.mounting) return;
    var now = Date.now();
    if (now - railState.lastMountAttemptAt < EXTUI_MOUNT_RETRY_BACKOFF_MS) return;
    railState.lastMountAttemptAt = now;
    railState.mounting = true;
    try {
      extPrunePanelRegistry();
      railNavigation.clear();
      _navButtonsByPanelId = {};
      buildNavBar();
      extFinishDeferredUiBoot();
    } catch (err) {
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("SIDEBAR_RAIL_MOUNT_FAILED",err);
      var partialBar = document.getElementById("extapp-sidebar-nav-root");
      if (partialBar) partialBar.remove();
      setTimeout(extAttemptMount, EXTUI_MOUNT_RETRY_BACKOFF_MS + 250);
    } finally {
      railState.mounting = false;
    }
  }
  function extWatchWorkspaceRoot() {
    if (railState.workspaceRootObserver) return;
    railState.workspaceRootObserver = new MutationObserver(function () {
      var app=extFindWhatsAppAppRoot();
      if (window.__EXT_SIDEBAR_ENABLED__ === true) {
        var v2=document.getElementById("ext-sidebar-host");
        if (!v2 && window.ExtensionUI && window.ExtensionUI.sidebarLifecycle && typeof window.ExtensionUI.sidebarLifecycle.mount === "function") {
          window.ExtensionUI.sidebarLifecycle.mount(window.__EXT_SIDEBAR_CSS__).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SIDEBAR_REMOUNT_FAILED",err);});
        }
      } else {
        var bar=document.getElementById("extapp-sidebar-nav-root");
        if (!bar || !app || app!==railState.layout.app) extScheduleRailLayout();
      }
      if (typeof extRefreshPanelDockHost === "function") extRefreshPanelDockHost();
    });
    railState.workspaceRootObserver.observe(document.body, { childList: true });
    window.addEventListener("resize", function(){
      if (window.__EXT_SIDEBAR_ENABLED__ !== true) extScheduleRailLayout();
      if (typeof extRefreshPanelDockHost === "function") extRefreshPanelDockHost();
    }, { passive: true });
  }



  function handlePagehide(ev){
    if(ev&&ev.persisted)return;
    extResetRailViewLifecycle();
    if(railState.layout.resizeObserver){try{railState.layout.resizeObserver.disconnect();}catch(_){}railState.layout.resizeObserver=null;railState.layout.resizeTarget=null;}
  }
  return Object.freeze({hydrateOnboardingLogo:extHydrateOnboardingLogo,armBootGate:extArmRailBootGate,resetViewLifecycle:extResetRailViewLifecycle,handlePagehide:handlePagehide,scheduleLayout:extScheduleRailLayout,attemptMount:extAttemptMount,watchWorkspaceRoot:extWatchWorkspaceRoot});
});
