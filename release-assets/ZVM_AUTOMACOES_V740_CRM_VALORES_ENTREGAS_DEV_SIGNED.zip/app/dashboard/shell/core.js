;
try{
(function () {
  "use strict";

                                                                             
                                                                               
                                                                           
                                                                              
                                                                                
                                             
  if (!window.__extDialogLifecycle) {
    window.__extDialogLifecycle = function (overlay, modal, opts) {
      opts = opts || {};
      var previousFocus = document.activeElement;
      var closed = false;
      if (!modal.getAttribute("role")) modal.setAttribute("role", "dialog");
      if (!modal.hasAttribute("aria-modal")) modal.setAttribute("aria-modal", "true");
      if (!modal.hasAttribute("tabindex")) modal.setAttribute("tabindex", "-1");
      function focusables() {
        return Array.prototype.slice.call(modal.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')).filter(function (node) {
          return !node.hidden && node.getAttribute("aria-hidden") !== "true" && node.getClientRects().length;
        });
      }
      function cleanup() {
        document.removeEventListener("keydown", onKeyDown, true);
      }
      function close(reason) {
        if (closed) return false;
        if (typeof opts.beforeClose === "function" && opts.beforeClose(reason) === false) return false;
        closed = true;
        cleanup();
        if (overlay && overlay.isConnected) overlay.remove();
        if (typeof opts.onClose === "function") opts.onClose(reason);
        if (opts.restoreFocus !== false && previousFocus && previousFocus.isConnected && typeof previousFocus.focus === "function") {
          try { previousFocus.focus({ preventScroll: true }); } catch (_) { try { previousFocus.focus(); } catch (_) {} }
        }
        return true;
      }
      function onKeyDown(event) {
        if (event.key === "Escape" && opts.escape !== false) { event.preventDefault(); event.stopPropagation(); close("escape"); return; }
        if (event.key !== "Tab" || opts.trapFocus === false) return;
        var nodes = focusables();
        if (!nodes.length) { event.preventDefault(); modal.focus(); return; }
        var first = nodes[0], last = nodes[nodes.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
      if (opts.backdrop !== false && overlay) overlay.addEventListener("click", function (event) { if (event.target === overlay) close("backdrop"); });
      document.addEventListener("keydown", onKeyDown, true);
      function focusInitial() {
        if (closed) return;
        var target = opts.initialFocus;
        if (typeof target === "function") target = target();
        if (!target || typeof target.focus !== "function") target = focusables()[0] || modal;
        try { target.focus({ preventScroll: true }); } catch (_) { try { target.focus(); } catch (_) {} }
      }
      if (opts.deferFocus === false) focusInitial(); else requestAnimationFrame(focusInitial);
      return { close: close, focus: focusInitial, cleanup: cleanup, isClosed: function () { return closed; } };
    };
  }

  if (!window.extModalPrompt) {
                                                                        
                                                                         
                                                                        
                                                                  
                                                                          
                                                                          
                                                                     
    window.extModalPrompt = function (message, opts) {
      opts = opts || {};
      return new Promise(function (resolve) {
        var overlay = document.createElement("div");
        overlay.className = "extui-modal-overlay";
        var modal = document.createElement("div");
        modal.className = "extui-modal";
        modal.setAttribute("aria-label", opts.title || (opts.input ? "Entrada de dados" : "Confirmação"));
        modal.style.width = "380px";
        modal.style.padding = "22px";
        var title = null;
        if (opts.title) {
          title = document.createElement("h3");
          title.textContent = String(opts.title);
          title.style.margin = "0 0 10px";
          title.style.color = "var(--extui-text)";
        }
        var msg = document.createElement("p");
        msg.style.margin = "0";
        msg.style.color = "var(--extui-text)";
        msg.style.fontSize = "14px";
        msg.style.lineHeight = "1.5";
        msg.style.whiteSpace = "pre-line";
        msg.textContent = message;
        var input = null;
        if (opts.input) {
          input = document.createElement("input");
          input.type = "text";
          input.id = "extui-modal-input-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
          input.value = opts.inputValue || "";
          if (opts.inputPlaceholder) input.placeholder = opts.inputPlaceholder;
          input.setAttribute("aria-label", opts.inputLabel || opts.inputPlaceholder || "Valor");
        }
        var actions = document.createElement("div");
        actions.className = "extuifModalActions";
        var settled = false;
        var lifecycle = null;
        function close(confirmed) {
          if (settled) return;
          settled = true;
          if (lifecycle) lifecycle.close(confirmed ? "confirm" : "cancel"); else overlay.remove();
          resolve(opts.input ? (confirmed ? input.value : null) : confirmed);
        }
        function onEnter(ev) {
          if (ev.key === "Enter" && opts.input && document.activeElement === input) { ev.preventDefault(); close(true); }
        }
        if (opts.cancel !== false) {
          var cancelBtn = document.createElement("button");
          cancelBtn.type = "button";
          cancelBtn.className = "extui-btn extui-btn--ghost";
          cancelBtn.textContent = opts.cancelLabel || "Cancelar";
          cancelBtn.addEventListener("click", function () { close(false); });
          actions.appendChild(cancelBtn);
        }
        var okBtn = document.createElement("button");
        okBtn.type = "button";
        okBtn.className = "extui-btn " + (opts.danger ? "extui-btn--danger" : "extui-btn--primary");
        okBtn.textContent = opts.okLabel || "OK";
        okBtn.addEventListener("click", function () { close(true); });
        actions.appendChild(okBtn);
        if (title) modal.appendChild(title);
        modal.appendChild(msg);
        if (input) {
          if (opts.inputLabel) { var label = document.createElement("label"); label.textContent = opts.inputLabel; label.setAttribute("for", input.id); modal.appendChild(label); }
          modal.appendChild(input);
        }
        modal.appendChild(actions);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);
        lifecycle = window.__extDialogLifecycle(overlay, modal, {
          initialFocus: input || okBtn,
          onClose: function (reason) {
            document.removeEventListener("keydown", onEnter, true);
            if (!settled && (reason === "escape" || reason === "backdrop")) { settled = true; resolve(opts.input ? null : false); }
          }
        });
        document.addEventListener("keydown", onEnter, true);
        if (input) requestAnimationFrame(function () { try { input.select(); } catch (_) {} });
      });
    };
    window.extConfirm = function (message, opts) {
      return window.extModalPrompt(message, Object.assign({}, opts, { cancel: true }));
    };
    window.extAlert = function (message, opts) {
      return window.extModalPrompt(message, Object.assign({}, opts, { cancel: false }));
    };
                                                                        
                                                            
    window.extPrompt = function (message, defaultValue, opts) {
      return window.extModalPrompt(message, Object.assign({}, opts, { cancel: true, input: true, inputValue: defaultValue }));
    };
  }
  function extApplyIconVars(opts) {
    var iconTheme = opts && (opts.iconTheme === "3d" || opts.iconTheme === "color") ? opts.iconTheme : "monochrome";
    document.documentElement.setAttribute("data-extui-icon-theme", iconTheme);
    var useSidebarSize = !!(opts && opts.dashboardUseSidebarIconSize === true);
    var sidebarSize = Number(opts && opts.sidebarMainIconSize) || 36;
    var menuSize = Number(opts && opts.dashboardMenuIconSize) || 28;
    var size = Math.min(Math.max(useSidebarSize ? sidebarSize : menuSize, 16), 64);
    document.documentElement.style.setProperty("--extui-dashboard-menu-icon-size", size + "px");
  }
  function extApplyThemeVars(opts) {
    if (window.__extThemeSystem) { window.__extThemeSystem.apply(window.__extThemeSystem.normalize(opts || {})); return; }
    document.documentElement.setAttribute("data-extui-theme", "light");
    extApplyIconVars(opts);
  }
  function extParseOptionsRaw(raw) {
    if (!raw) return null;
    if (typeof raw !== "string") return raw && typeof raw === "object" ? raw : null;
    try { var parsed = JSON.parse(raw); return parsed && typeof parsed === "object" ? parsed : null; } catch (_) { return null; }
  }

                                                          
                                                                          
                                                                      
                                                                           
                                                       

  try {
    chrome.storage.local.get("EXTUI:extappOptionsStore", function (res) {
      if (chrome.runtime.lastError) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("DASHBOARD_OPTIONS_READ_FAILED", new Error(chrome.runtime.lastError.message)); return; }
      var raw = res && res["EXTUI:extappOptionsStore"];
      var opts = extParseOptionsRaw(raw);
      if (raw != null && !opts) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("DASHBOARD_OPTIONS_PAYLOAD_INVALID", new Error("Preferências persistidas inválidas")); return; }
      extApplyThemeVars(opts);
    });
  } catch (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("DASHBOARD_OPTIONS_BOOT_FAILED", err); }
                                                                
                                                                          
                                                                           
                                                                         
                                                                        
                                                                        
                                    
  try {
    onStorageKeyChange("EXTUI:extappOptionsStore", function (raw) { var opts=extParseOptionsRaw(raw); if(raw!=null&&!opts){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_OPTIONS_SYNC_PAYLOAD_INVALID",new Error("Preferências sincronizadas inválidas"));return;} extApplyThemeVars(opts); });
  } catch (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("DASHBOARD_OPTIONS_SYNC_BIND_FAILED", err); }

                                                                          
                                                                          
                                                                           
                                                                   
                                                                      
                                                                        
                                                                         
                                                                      
                                                                       
                 
  function extApplyBrandLogo() {
    var img = document.getElementById("extappBrandLogo");
    if (!img) return;
    var src = chrome.runtime.getURL("assets/brand/logo-icon-light.png");
    if (img.getAttribute("src") !== src) img.setAttribute("src", src);
  }
  try {
    new MutationObserver(extApplyBrandLogo).observe(document.documentElement, { attributes: true, attributeFilter: ["data-extui-theme"] });
  } catch (err) {                                                                                                   }
  extApplyBrandLogo();

                                                                         
                                                                            
                                                                           
                                                                            
                                                                      
                                                               
                                                               
                                                                            
                                                                           
                                                                          
                                                                     
                                                                         
                                                                         
                                                                
                                                                
                                                                           
                                                                        
                                                                          
                                                                       
                                                                     
                                                                        
                                             
  var DASHBOARD_VISUAL_META = {
    disparos: { eyebrow: "COMUNICAÇÃO", desc: "Crie campanhas de envio em etapas, acompanhe o progresso e analise resultados em um só lugar." },
    fluxos: { eyebrow: "AUTOMAÇÃO", desc: "Crie automações por gatilho com etapas, condições, IA e ações conectadas." },
    funis: { eyebrow: "AUTOMAÇÃO", desc: "Organize sequências de mensagens, intervalos e acompanhamento de contatos." },
    agenda: { eyebrow: "AUTOMAÇÃO", desc: "Planeje envios e recupere agendamentos pendentes com segurança." },
    followup: { eyebrow: "AUTOMAÇÃO", label: "FollowUp", accent: "#6366f1", desc: "Crie regras de acompanhamento que aguardam o momento certo e reagem ao comportamento do contato." },
    laboratorio: { eyebrow: "AUTOMAÇÃO", desc: "Teste fluxos, funis e comportamentos antes de usar uma conversa real." },
    "ai-connect": { eyebrow: "AUTOMAÇÃO", label: "Assistentes IA", accent: "#6366f1", desc: "Conecte e gerencie os serviços de IA." },
    "ai-transcription": { eyebrow: "ASSISTENTES IA", label: "Assistentes IA", accent: "#10b981", desc: "Conecte e gerencie os serviços de IA." },
    "ai-translation": { eyebrow: "ASSISTENTES IA", label: "Assistentes IA", accent: "#8b5cf6", desc: "Conecte e gerencie os serviços de IA." },
    "ai-agents": { eyebrow: "AUTOMAÇÃO", desc: "Configure agentes, ferramentas, memória e contexto para automações inteligentes." },
    "ai-assistants": { eyebrow: "AUTOMAÇÃO", label: "Perfis IA", accent: "#8b5cf6", desc: "Crie perfis de IA reutilizáveis e conecte instruções, modelos e conhecimento às automações." },
    "ai-memory": { eyebrow: "AUTOMAÇÃO", label: "Memória IA", accent: "#06b6d4", desc: "Gerencie contexto persistente e memória utilizada pelos recursos inteligentes da extensão." },
    knowledge: { eyebrow: "AUTOMAÇÃO", label: "Base de Conhecimento", accent: "#22c55e", desc: "Organize fontes e conteúdos consultados pelos agentes e automações inteligentes." },
    crm: { eyebrow: "CLIENTES", desc: "Gerencie contatos, etapas, tarefas e histórico comercial em um só lugar." },
    customers: { eyebrow: "CLIENTES", label: "Painel de Clientes", accent: "#10b981", desc: "Centralize cadastro, categorias, notas, agenda e histórico operacional de cada cliente." },
    "quick-responses": { eyebrow: "COMUNICAÇÃO", label: "Respostas Rápidas", accent: "#8b5cf6", desc: "Organize respostas prontas de atendimento com mensagens e ações reutilizáveis em sequência." },
    "itens-message": { eyebrow: "COMUNICAÇÃO", label: "Biblioteca", accent: "#ec4899", desc: "Centralize mensagens, áudios, imagens, vídeos, documentos e outros itens reutilizáveis do atendimento." },
    "crm-funnel": { eyebrow: "CLIENTES", desc: "Visualize conversão, distribuição e valor por etapa do seu CRM." },
    encomendas: { eyebrow: "CLIENTES", label: "Encomendas", accent: "#f97316", desc: "Cadastre e acompanhe encomendas, transportadoras e rastreios com uma visão simples e direta." },
    delivery: { eyebrow: "CLIENTES", label: "Entregas", accent: "#fb7185", desc: "Gerencie pedidos, preparo, entregadores, entregas e acompanhamento pós-venda em um fluxo operacional completo." },
    atividades: { eyebrow: "NÚCLEO", label: "Atividades", accent: "#f59e0b", desc: "Centralize alertas e eventos importantes de encomendas, CRM, automações e integrações." },
    salvar: { eyebrow: "CLIENTES", label: "Exportar Contatos", desc: "Exporte contatos e grupos com filtros seguros e pré-visualização." },
    integracoes: { eyebrow: "ECOSSISTEMA", desc: "Conecte webhooks, automações externas e rastreamento operacional à Extensão." },
    "meta-oficial": { eyebrow: "WHATSAPP OFICIAL", label: "Meta Oficial", accent: "#1877f2", desc: "Conecte a conta WhatsApp Business Platform do próprio cliente à Extensão." },
    core: { eyebrow: "NÚCLEO", label: "Central", accent: "#00e676", desc: "Acompanhe o funcionamento da extensão, avisos importantes, modelos, favoritos, conquistas e recursos especiais." },
    segredos: { eyebrow: "", label: "Segredos", accent: "#c084fc", desc: "Acompanhe descobertas, mascotes, temas secretos, pistas e experiências especiais da extensão." },
    personalizacao: { eyebrow: "", desc: "Ajuste identidade, temas, ícones e a experiência visual da extensão." },
    ajustes: { eyebrow: "", desc: "Configure comportamento, segurança, WhatsApp e conta da extensão." },
    backup: { eyebrow: "", label: "Backup", accent: "#10b981", desc: "Exporte, importe e automatize cópias dos dados da extensão." },
    trash: { eyebrow: "", label: "Lixeira", accent: "#64748b", desc: "Restaure itens removidos ou faça a exclusão definitiva com controle de retenção." },
    academy: { eyebrow: "APRENDIZADO", desc: "Aprenda os recursos da extensão com guias e tutoriais dentro da própria interface." }
  };

  var SIDEBAR_NAV_ITEMS = [
    { section: "home", group: "Principal", accent: "#38bdf8", label: "Início", icon: '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>' },
    { section: "academy", group: "Principal", accent: "#10b981", label: "Tutoriais", icon: '<path d="m4 19.5 8-4 8 4"/><path d="M4 4.5 12 8l8-3.5L12 1z"/><path d="M4 4.5v15M20 4.5v15M12 8v7.5"/>' },
    { section: "meta-oficial", group: "Principal", accent: "#1877f2", label: "Meta Oficial", featured: true, icon: '<path d="M7 15c2.2-6.8 4.5-7.6 6-2.3 1.4 5 3.3 4.3 5.2-1.4"/><circle cx="12" cy="12" r="9"/>' },
    { section: "atividades", group: "Principal", accent: "#f59e0b", label: "Atividades", icon: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>' },
    { section: "disparos", group: "Comunicação", accent: "#10b981", label: "Disparos", icon: '<path d="M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"/><path d="M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14"/><path d="M8 6v8"/>' },
    { section: "itens-message", group: "Comunicação", accent: "#ec4899", label: "Biblioteca", icon: '<path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"/>' },
    { section: "quick-responses", group: "Comunicação", accent: "#8b5cf6", label: "Respostas Rápidas", icon: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>' },
    { section: "fluxos", group: "Automação", accent: "#fb923c", label: "Fluxos", icon: '<rect width="8" height="8" x="3" y="3" rx="2"/><path d="M7 11v4a2 2 0 0 0 2 2h4"/><rect width="8" height="8" x="13" y="13" rx="2"/>' },
    { section: "funis", group: "Automação", accent: "#f43f5e", label: "Funis", icon: '<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>' },
    { section: "agenda", group: "Automação", accent: "#22d3ee", label: "Agenda", icon: '<path d="M8 2v3"/><path d="M16 2v3"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>' },
    { section: "followup", group: "Automação", accent: "#6366f1", label: "FollowUp", icon: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>' },
    { section: "laboratorio", group: "Automação", accent: "#10b981", label: "Laboratório", icon: '<path d="M9 3h6"/><path d="M10 9V3h4v6l5 9a2 2 0 0 1-1.8 3H6.8A2 2 0 0 1 5 18z"/><path d="M7.5 15h9"/>' },
    { section: "ai-connect", group: "Automação", accent: "#6366f1", label: "Assistentes IA", icon: '<path d="M12 3v2.2M12 18.8V21M3 12h2.2M18.8 12H21M5.6 5.6l1.6 1.6M16.8 16.8l1.6 1.6M18.4 5.6l-1.6 1.6M7.2 16.8l-1.6 1.6"/><circle cx="12" cy="12" r="5"/><path d="M9.5 12h5M12 9.5v5"/>' },
    { section: "crm", group: "Clientes", accent: "#eab308", label: "CRM", icon: '<path d="M5 3v14"/><path d="M12 3v8"/><path d="M19 3v18"/>' },
    { section: "customers", group: "Clientes", accent: "#10b981", label: "Painel", icon: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>' },
    { section: "encomendas", group: "Clientes", accent: "#f97316", label: "Encomendas", icon: '<path d="m21 8-9-5-9 5 9 5 9-5Z"/><path d="m3 8 9 5 9-5"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>' },
    { section: "delivery", group: "Clientes", accent: "#fb7185", label: "Entregas", icon: '<path d="M10 17h4V5H2v12h3"/><path d="M14 8h4l4 4v5h-3"/><circle cx="7.5" cy="17.5" r="2.5"/><circle cx="16.5" cy="17.5" r="2.5"/>' },
    { section: "salvar", group: "Clientes", accent: "#10b981", label: "Exportar Contatos", icon: '<path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/>' },
    { section: "integracoes", group: "Sistema", accent: "#0ea5e9", label: "Integrações", icon: '<path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a6 6 0 0 1-12 0V8Z"/><path d="M4 8h16"/>' },
    { section: "segredos", group: "Sistema", accent: "#c084fc", label: "Segredos", icon: '<path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8Z"/><path d="M5 15l.9 2.1L8 18l-2.1.9L5 21l-.9-2.1L2 18l2.1-.9Z"/>' },
    { section: "personalizacao", group: "Sistema", accent: "#a78bfa", label: "Personalização", icon: '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>' },
    { section: "ajustes", group: "Sistema", accent: "#94a3b8", label: "Ajustes", icon: '<path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"/><circle cx="12" cy="12" r="3"/>' },
    { section: "backup", group: "Sistema", accent: "#10b981", label: "Backup", icon: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/><path d="M9.5 16h5"/>' },
    { section: "trash", group: "Sistema", accent: "#64748b", label: "Lixeira", icon: '<path d="M3 6h18"/><path d="M19 6v14H5V6"/><path d="M8 6V4h8v2"/><path d="M10 11v6M14 11v6"/>' }
  ];
  var EXTUI_SECTION_PALETTE = window.ExtensionSectionPalette || null;
  if (EXTUI_SECTION_PALETTE) {
    SIDEBAR_NAV_ITEMS.forEach(function(item){ item.accent = EXTUI_SECTION_PALETTE.forSection(item.section, item.accent); });
    Object.keys(DASHBOARD_VISUAL_META).forEach(function(section){
      var ctx = DASHBOARD_VISUAL_META[section];
      var paletteKey = section.indexOf("itens-")===0 ? "itens-message" : section;
      ctx.accent = EXTUI_SECTION_PALETTE.forSection(paletteKey, ctx.accent);
    });
  }
  var DASHBOARD_ROUTE_CONTEXT = {
    "itens-message": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Mensagens", group: "Comunicação" },
    "itens-audio": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Áudios", group: "Comunicação" },
    "itens-image": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Imagens", group: "Comunicação" },
    "itens-video": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Vídeos", group: "Comunicação" },
    "itens-media": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Imagens", group: "Comunicação" },
    "itens-sticker": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Figurinhas", group: "Comunicação" },
    "itens-document": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Documentos", group: "Comunicação" },
    "itens-pix": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "PIX", group: "Comunicação" },
    "itens-interactive-list": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Listas", group: "Comunicação" },
    "itens-contact": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Contatos", group: "Comunicação" },
    "itens-signature": { parent: "itens-message", parentLabel: "Biblioteca", childLabel: "Assinaturas", group: "Comunicação" },
    "ai-connect": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Conexões", group: "Automação" },
    "ai-transcription": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Conexões & Recursos", group: "Automação" },
    "ai-translation": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Conexões & Recursos", group: "Automação" },
    "ai-assistants": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Perfis", group: "Automação" },
    "ai-agents": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Agentes", group: "Automação" },
    "ai-memory": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Memória", group: "Automação" },
    "knowledge": { parent: "ai-connect", parentLabel: "Assistentes IA", childLabel: "Conhecimento", group: "Automação" },
    "crm": { parent: "crm", parentLabel: "CRM", childLabel: "CRM", group: "Clientes" },
    "crm-funnel": { parent: "crm", parentLabel: "CRM", childLabel: "Análise do funil", group: "Clientes" },
    "salvar": { parent: "salvar", parentLabel: "Exportar Contatos", childLabel: "Exportar Contatos", group: "Clientes" }
  };
  function dashboardRouteContext(name) {
    var ctx = DASHBOARD_ROUTE_CONTEXT[name];
    if (ctx) return ctx;
    for (var i = 0; i < SIDEBAR_NAV_ITEMS.length; i++) {
      var item = SIDEBAR_NAV_ITEMS[i];
      if (item.section === name) return { parent: name, parentLabel: item.label, childLabel: item.label, group: item.group };
    }
    var meta = DASHBOARD_VISUAL_META[name] || {};
    return { parent: name, parentLabel: meta.label || name, childLabel: meta.label || name, group: meta.eyebrow || "Extensão" };
  }

  var EXTUI_COLOR_ICON_PALETTE = ["#00a884","#e85b9e","#4f8df7","#f3a31b","#a855f7","#14b8a6","#84cc16","#f43f5e","#22d3ee","#6366f1","#f97316","#10b981"];
  function renderSidebarNav() {
    var nav = document.getElementById("extappSidebarNav");
    if (!nav || nav.children.length) return;
    var GROUP_STATE_KEY = "EXTUI:dashboardNavGroupState";
    var collapsed = {};
    try { collapsed = JSON.parse(localStorage.getItem(GROUP_STATE_KEY) || "{}") || {}; } catch (_) { collapsed = {}; }
    var lastGroup = null;
    var groupButtons = {};
    function applyGroup(group) {
      var isCollapsed = collapsed[group] === true;
      var header = groupButtons[group];
      if (header) {
        header.setAttribute("aria-expanded", String(!isCollapsed));
        header.classList.toggle("is-collapsed", isCollapsed);
      }
      nav.querySelectorAll('.navItem[data-nav-group="' + group.replace(/"/g, "") + '"]').forEach(function (btn) {
        btn.hidden = isCollapsed;
      });
    }
    SIDEBAR_NAV_ITEMS.forEach(function (item, itemIndex) {
      if (item.group !== lastGroup) {
        var label = document.createElement("button");
        label.type = "button";
        label.className = "extappNavGroupLabel";
        label.textContent = item.group;
        label.setAttribute("aria-label", item.group + " — expandir ou recolher");
        label.setAttribute("aria-expanded", "true");
        label.setAttribute("data-nav-group-toggle", item.group);
        label.innerHTML = '<span>' + item.group + '</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>';
        label.addEventListener("click", function () {
          if (document.getElementById("extappSidebar").classList.contains("compact")) return;
          collapsed[item.group] = !(collapsed[item.group] === true);
          try { localStorage.setItem(GROUP_STATE_KEY, JSON.stringify(collapsed)); } catch (_) {}
          applyGroup(item.group);
        });
        nav.appendChild(label);
        groupButtons[item.group] = label;
        lastGroup = item.group;
      }
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "navItem";
      if (item.featured) btn.classList.add("navItem--featured");
      btn.style.setProperty("--extui-nav-accent", item.accent || "#00c85a");
      btn.setAttribute("data-section", item.section);
      btn.setAttribute("data-nav-group", item.group);
      btn.setAttribute("data-extui-academy-target", "dashboard-nav-" + item.section);
      if (item.disabled) btn.classList.add("disabled");
      if (item.external) btn.setAttribute("data-external", "1");
      btn.setAttribute("aria-label", item.label);
      var iconColor = EXTUI_COLOR_ICON_PALETTE[itemIndex % EXTUI_COLOR_ICON_PALETTE.length];
      btn.innerHTML = '<span class="navIconChip" style="--c:' + iconColor + ';"><svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + item.icon + '</svg></span>' +
        '<span class="navLabel">' + item.label + '</span>' +
        (item.featured ? '<span class="navOfficialBadge" aria-hidden="true">OFICIAL</span>' : "") +
        (item.soon ? '<span class="soon">' + item.soon + '</span>' : "") +
        '<span class="navBadge" style="display:none;" aria-hidden="true"></span>';
      nav.appendChild(btn);
    });
    Object.keys(groupButtons).forEach(applyGroup);
    nav._extuiApplyGroupState = function () {
      var sidebar = document.getElementById("extappSidebar");
      if (sidebar && sidebar.classList.contains("compact")) {
        nav.querySelectorAll(".navItem[data-nav-group]").forEach(function (btn) { btn.hidden = false; });
        return;
      }
      Object.keys(groupButtons).forEach(applyGroup);
    };
    nav._extuiExpandGroupForSection = function (name) {
      var sidebar = document.getElementById("extappSidebar");
      if (sidebar && sidebar.classList.contains("compact")) return;
      var ctx = dashboardRouteContext(name);
      var group = ctx && ctx.group;
      if (group && collapsed[group]) {
        collapsed[group] = false;
        try { localStorage.setItem(GROUP_STATE_KEY, JSON.stringify(collapsed)); } catch (_) {}
        applyGroup(group);
      }
    };
  }
  renderSidebarNav();

                                                                           
                                                                       
                                                                          
                                                                         
                                                                    
                                                                         
                                            
  (function setupNavTooltip() {
    var tooltipEl = document.createElement("div");
    tooltipEl.className = "extuiTooltip";
    tooltipEl.setAttribute("role", "tooltip");
    document.body.appendChild(tooltipEl);
    function show(target) {
      var sidebar = document.getElementById("extappSidebar");
      if (!sidebar.classList.contains("compact")) return;
      var label = target.getAttribute("aria-label") || "";
      var rect = target.getBoundingClientRect();
                                                                           
                                                                        
                                                                          
                                                                         
                                                                            
      var sidebarRect = sidebar.getBoundingClientRect();
      tooltipEl.textContent = label;
      tooltipEl.style.top = (rect.top + rect.height / 2) + "px";
      tooltipEl.style.left = (sidebarRect.right + 8) + "px";
      tooltipEl.classList.add("extuiVisible");
    }
    function hide() { tooltipEl.classList.remove("extuiVisible"); }
    var TOOLTIP_TARGETS = ".navItem, .extappNavGroupLabel";
    document.getElementById("extappSidebarNav").addEventListener("focusin", function (ev) {
      var item = ev.target.closest ? ev.target.closest(TOOLTIP_TARGETS) : null;
      if (item) show(item);
    });
    document.getElementById("extappSidebarNav").addEventListener("focusout", function (ev) {
      var item = ev.target.closest ? ev.target.closest(TOOLTIP_TARGETS) : null;
      if (item) hide();
    });
    document.getElementById("extappSidebarNav").addEventListener("mouseover", function (ev) {
      var item = ev.target.closest ? ev.target.closest(TOOLTIP_TARGETS) : null;
      if (item) show(item);
    });
    document.getElementById("extappSidebarNav").addEventListener("mouseout", function (ev) {
      var item = ev.target.closest ? ev.target.closest(TOOLTIP_TARGETS) : null;
      if (item) hide();
    });
  })();

                                                                          
                                                                          
                                                                         
                                                                      
                                                                          
                            
  document.addEventListener("click", function (ev) {
    var el = ev.target.closest ? ev.target.closest(".navItem, .extui-btn, .extappIconBtn, .extappSidebarToggleBtn") : null;
    if (!el || el.disabled || el.classList.contains("navItem")) return;
    var rect = el.getBoundingClientRect();
    var size = Math.max(rect.width, rect.height);
    var ripple = document.createElement("span");
    ripple.className = "extuiRipple";
    ripple.style.width = ripple.style.height = size + "px";
    ripple.style.left = (ev.clientX - rect.left - size / 2) + "px";
    ripple.style.top = (ev.clientY - rect.top - size / 2) + "px";
    el.appendChild(ripple);
    ripple.addEventListener("animationend", function () { ripple.remove(); });
  }, true);

  var sections = {};
  var sectionNavigationGuard = null;
  var contentArea = document.getElementById("extappContentArea");
  function currentNavButtons() { return document.querySelectorAll("#extappSidebarNav [data-section]"); }
  var _x5 = "EXTUI:license";
  var _x0 = window.__extG0;
  var _x2 = _x0 ? _x0.STATES.CHECKING_AUTH : "CHECKING_AUTH";
  var _x1 = null;
  var dashboardQuery = new URLSearchParams(window.location.search);
  var accessRequestedSection = dashboardQuery.get("section") || (history.state && history.state.extappSection) || null;
  var lastAuthorizedSection = null;

  function _x3() {
    return !!(_x0 && _x2 === _x0.STATES.AUTHORIZED);
  }

  function hideFallbackSurface() {
    if (contentArea) contentArea.classList.remove("extuiHidden");
  }

  function showHomeFallback() {
    if (!_x3()) return false;
    if (typeof showSection === "function") {
      showSection("home");
      return true;
    }
    hideFallbackSurface();
    return false;
  }

  var currentSectionName = null;

  function notifySectionState(phase, name) {
    document.dispatchEvent(new CustomEvent("ext:dashboard-section-" + phase, {
      detail: { section: name }
    }));
  }

  function ensureContextTabs(name) {
    var old = contentArea.querySelector(":scope > .extappContextTabs"); if (old) old.remove();
    var sets = null;
    if (/^itens-(message|audio|image|video|media|sticker|document|pix|interactive-list|contact|signature)$/.test(name)) sets = [
      ["itens-message","Mensagens"],["itens-audio","Áudios"],["itens-image","Imagens"],["itens-video","Vídeos"],["itens-sticker","Figurinhas"],["itens-document","Documentos"],["itens-pix","PIX"],["itens-interactive-list","Listas"],["itens-contact","Contatos"],["itens-signature","Assinaturas"]
    ];
    else if (name === "ai-connect" || name === "ai-transcription" || name === "ai-translation" || name === "ai-assistants" || name === "ai-agents" || name === "ai-memory" || name === "knowledge") sets = [
      ["ai-connect","Conexões & Recursos"],["ai-assistants","Perfis"],["ai-agents","Agentes"],["ai-memory","Memória"],["knowledge","Conhecimento"]
    ];
    if (!sets) return;
    var nav = document.createElement("nav"); nav.className = "extappContextTabs"; nav.setAttribute("aria-label", name.indexOf("itens-") === 0 ? "Categorias da Biblioteca" : (name.indexOf("ai-") === 0 || name === "knowledge" ? "Áreas de IA" : "Áreas do CRM")); nav.setAttribute("role", "tablist");
    sets.forEach(function (pair, index) {
      var active = pair[0] === name;
      var b = document.createElement("button"); b.type = "button"; b.className = "extappContextTab" + (active ? " is-active" : ""); b.textContent = pair[1];b.setAttribute("data-section",pair[0]);
      b.setAttribute("role", "tab"); b.setAttribute("aria-selected", String(active)); b.setAttribute("aria-current", active ? "page" : "false"); b.tabIndex = active ? 0 : -1;
      b.addEventListener("click", function () {
        var targetSection = pair[0];
        if (targetSection === currentSectionName) return;
        var libraryFast = /^itens-(message|audio|image|video|media|sticker|document|pix|interactive-list|contact|signature)$/.test(targetSection) && /^itens-(message|audio|image|video|media|sticker|document|pix|interactive-list|contact|signature)$/.test(currentSectionName || "") && typeof window.__extLibraryFastSwitch === "function";
        if (libraryFast) {
          Promise.resolve(window.__extLibraryFastSwitch(targetSection)).then(function (switched) {
            if (!switched) { showSection(targetSection); return; }
            currentSectionName = targetSection; lastAuthorizedSection = targetSection;
            syncDashboardSectionUrl(targetSection, { preserveRouteParams: true });
            notifySectionState("change", targetSection);
            Array.prototype.forEach.call(nav.querySelectorAll('[role="tab"]'), function (tab) { var activeNow = tab.getAttribute("data-section") === targetSection; tab.classList.toggle("is-active", activeNow); tab.setAttribute("aria-selected", String(activeNow)); tab.setAttribute("aria-current", activeNow ? "page" : "false"); tab.tabIndex = activeNow ? 0 : -1; });
            ensureAccessibleControls(contentArea);
          }).catch(function () { showSection(targetSection); });
          return;
        }
        showSection(targetSection);
      });
      b.addEventListener("keydown", function (event) {
        if (event.key !== "ArrowLeft" && event.key !== "ArrowRight" && event.key !== "Home" && event.key !== "End") return;
        event.preventDefault();
        var nextIndex = index;
        if (event.key === "Home") nextIndex = 0;
        else if (event.key === "End") nextIndex = sets.length - 1;
        else nextIndex = (index + (event.key === "ArrowRight" ? 1 : -1) + sets.length) % sets.length;
        var target = nav.querySelectorAll('[role="tab"]')[nextIndex];
        if (target) { target.focus(); target.click(); }
      });
      nav.appendChild(b);
    });
    contentArea.insertBefore(nav, contentArea.firstChild);
    if(window.__extPlanGate)window.__extPlanGate.state().then(window.__extPlanGate.applyNav).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_PLAN_NAV_SYNC_FAILED",err);});
  }

  function ensureAccessibleControls(scope) {
    scope = scope || contentArea;
    scope.querySelectorAll('button:not([type])').forEach(function (button) { button.type = "button"; });
    scope.querySelectorAll('button,a[href],[role="button"]').forEach(function(control){
      if(control.getAttribute("aria-label")||control.getAttribute("aria-labelledby"))return;
      var text=String(control.textContent||"").replace(/\s+/g," ").trim();
      var label=control.getAttribute("title")||control.getAttribute("data-tooltip")||control.getAttribute("data-label")||"";
      if(!label&&/^[×✕✖]$/.test(text))label="Fechar";
      if(!label&&!text){var raw=control.getAttribute("data-action")||control.getAttribute("data-command")||"";if(raw)label=String(raw).replace(/[._-]+/g," ");}
      if(label)control.setAttribute("aria-label",String(label).replace(/\s+/g," ").trim().slice(0,120));
    });
    scope.querySelectorAll('[role="dialog"],[aria-modal="true"]').forEach(function(dialog){
      if(!dialog.getAttribute("role"))dialog.setAttribute("role","dialog");
      if(!dialog.getAttribute("aria-label")&&!dialog.getAttribute("aria-labelledby")){
        var heading=dialog.querySelector("h1,h2,h3,.title,.extuiModalTitle");
        if(heading){if(!heading.id)heading.id="extapp-dialog-title-"+Math.random().toString(36).slice(2,9);dialog.setAttribute("aria-labelledby",heading.id);}
      }
    });
    scope.querySelectorAll('[aria-hidden="true"]').forEach(function(node){
      if(node.matches('button,a[href],input,select,textarea,[tabindex]:not([tabindex="-1"])'))node.setAttribute("tabindex","-1");
    });
    var controls = scope.querySelectorAll('input:not([type="hidden"]),select,textarea');
    var seq = 0;
    controls.forEach(function (control) {
      if (control.tagName === "INPUT" && (control.type === "text" || control.type === "search")) {
        var searchHint = control.getAttribute("placeholder") || control.getAttribute("aria-label") || "";
        if (/^(buscar|pesquisar|procurar)\b/i.test(searchHint.trim())) {
          try { control.type = "search"; } catch (_) {}
          if (!control.getAttribute("autocomplete")) control.setAttribute("autocomplete", "off");
          if (!control.getAttribute("enterkeyhint")) control.setAttribute("enterkeyhint", "search");
        }
      }
      if (control.getAttribute("aria-label") || control.getAttribute("aria-labelledby")) return;
      if (control.id) { var explicit = document.querySelector('label[for="' + CSS.escape(control.id) + '"]'); if (explicit) return; }
      var wrappingLabel = control.closest("label");
      if (wrappingLabel) {
        var wrappingText = String(wrappingLabel.textContent || "").replace(/\s+/g, " ").trim();
        if (wrappingText) return;
      }
      var labelText = "";
      var row = control.closest(".extuiAjustesRow,.extuiSafetyFieldRow,.extuiFieldGroup,.extuiDisparosDashSection,.extuiAgendaFormGrid>label,.extuiFollowUpField,.extuiConfigStudioField,.extuiOrdersField");
      if (row) {
        var labelNode = row.querySelector(".title,.extuiFieldLabel,.extuiAjustesRowText .title,label,.extuiDisparosDashSectionTitle,span,strong");
        if (labelNode && labelNode !== control) labelText = (labelNode.textContent || "").trim();
      }
      if (!labelText) {
        var prev = control.previousElementSibling;
        if (prev && /^(LABEL|SPAN|STRONG|DIV)$/.test(prev.tagName)) labelText = (prev.textContent || "").trim();
      }
      if (!labelText) labelText = control.getAttribute("placeholder") || control.getAttribute("name") || control.id || (control.type === "checkbox" ? "Opção" : "Campo");
      labelText = String(labelText).replace(/\s+/g," ").trim().slice(0,120);
      if (labelText) control.setAttribute("aria-label", labelText);
      if (!control.id) control.id = "extapp-auto-field-" + (++seq) + "-" + Date.now().toString(36);
    });
  }


  var sectionScrollPositions = Object.create(null);
  var sectionRenderGeneration = 0;
  var sectionBusyTimer = 0;
  var shellTabId = null;
  var DASHBOARD_ROUTE_KEYS = ["focus","crmContactId","crmId","crmView","crmProfileTab","crmCreate","crmCopilot","flowId","funnelId"];

  function resolveShellTabId(callback) {
    if (shellTabId != null) { callback(shellTabId); return; }
    if (!chrome.tabs || typeof chrome.tabs.getCurrent !== "function") { callback(null); return; }
    try {
      chrome.tabs.getCurrent(function (tab) {
        if (!chrome.runtime.lastError && tab && tab.id != null) shellTabId = tab.id;
        callback(shellTabId);
      });
    } catch (_) { callback(null); }
  }
  resolveShellTabId(function () {});

  function syncDashboardSectionUrl(name, options) {
    options = options || {};
    try {
      var url = new URL(window.location.href);
      if (!options.preserveRouteParams) {
        if (name !== "crm" && name !== "crm-funnel") {
          ["crmContactId","crmId","crmView","crmProfileTab","crmCreate","crmCopilot","flowId","funnelId"].forEach(function (key) { url.searchParams.delete(key); });
        } else if (name === "crm-funnel") {
          ["crmContactId","crmView","crmProfileTab","crmCreate","crmCopilot","flowId","funnelId"].forEach(function (key) { url.searchParams.delete(key); });
        }
        if (name !== "ajustes") url.searchParams.delete("focus");
      }
      url.searchParams.delete("section");
      var next = url.pathname + (url.searchParams.toString() ? "?" + url.searchParams.toString() : "") + url.hash;
      history.replaceState({ extappSection: name || "" }, "", next);
    } catch (_) {}
  }

  function applyShellRouteMessage(message, targetSection) {
    try {
      var url = new URL(window.location.href);
      DASHBOARD_ROUTE_KEYS.forEach(function (key) { url.searchParams.delete(key); });
      url.searchParams.delete("section");
      if (message.focus) url.searchParams.set("focus", message.focus);
      if (message.crmContactId) url.searchParams.set("crmContactId", message.crmContactId);
      if (message.crmId) url.searchParams.set("crmId", message.crmId);
      if (message.crmView) url.searchParams.set("crmView", message.crmView);
      if (message.crmProfileTab) url.searchParams.set("crmProfileTab", message.crmProfileTab);
      if (message.flowId) url.searchParams.set("flowId", message.flowId);
      if (message.funnelId) url.searchParams.set("funnelId", message.funnelId);
      if (message.crmCreate === true) url.searchParams.set("crmCreate", "1");
      if (message.crmCopilot === true) url.searchParams.set("crmCopilot", "1");
      var next = url.pathname + (url.searchParams.toString() ? "?" + url.searchParams.toString() : "") + url.hash;
      history.replaceState({ extappSection: targetSection || "" }, "", next);
    } catch (_) {}
  }

  function setSectionBusy(generation, busy) {
    clearTimeout(sectionBusyTimer);
    if (!busy) {
      contentArea.removeAttribute("aria-busy");
      var topbarDone = document.getElementById("extappTopbar");
      if (topbarDone) topbarDone.removeAttribute("data-extui-section-busy");
      return;
    }
    contentArea.setAttribute("aria-busy", "true");
    sectionBusyTimer = setTimeout(function () {
      if (generation !== sectionRenderGeneration) return;
      var topbar = document.getElementById("extappTopbar");
      if (topbar) topbar.setAttribute("data-extui-section-busy", "true");
    }, 450);
  }

  function renderSectionError(name, error) {
    contentArea.innerHTML = "";
    contentArea.setAttribute("data-extui-dashboard-section", name || "error");
    var surface = document.createElement("section");
    surface.className = "extappSectionError";
    surface.setAttribute("role", "alert");
    var icon = document.createElement("span"); icon.className = "extappSectionErrorIcon"; icon.setAttribute("aria-hidden", "true"); icon.textContent = "!";
    var copy = document.createElement("div");
    var title = document.createElement("h2"); title.textContent = "Não foi possível carregar esta área";
    var desc = document.createElement("p"); desc.textContent = "A extensão manteve o restante do painel ativo. Tente novamente; se o problema persistir, abra outra seção e retorne.";
    var detail = document.createElement("small"); detail.textContent = error && error.message ? String(error.message).slice(0, 180) : "Falha inesperada de renderização.";
    copy.appendChild(title); copy.appendChild(desc); copy.appendChild(detail);
    var actions = document.createElement("div"); actions.className = "extappSectionErrorActions";
    var retry = document.createElement("button"); retry.type = "button"; retry.className = "extui-btn extui-btn--primary"; retry.textContent = "Tentar novamente";
    retry.addEventListener("click", function () { showSection(name, { force: true, preserveScroll: false }); });
    var home = document.createElement("button"); home.type = "button"; home.className = "extui-btn extui-btn--ghost"; home.textContent = "Ir para Início";
    home.addEventListener("click", function () { showSection("home", { preserveScroll: false }); });
    actions.appendChild(retry); actions.appendChild(home);
    surface.appendChild(icon); surface.appendChild(copy); surface.appendChild(actions);
    contentArea.appendChild(surface);
    requestAnimationFrame(function () { try { retry.focus({ preventScroll: true }); } catch (_) { retry.focus(); } });
  }

  function finalizeSectionRender(name, generation, options) {
    if (generation !== sectionRenderGeneration || currentSectionName !== name) return { ok: false, section: name, reason: "superseded" };
    contentArea.setAttribute("data-extui-dashboard-section", name);
    ensureContextTabs(name);
    ensureAccessibleControls();
    var scrollTarget = name === "disparos" ? 0 : (options && options.preserveScroll === false ? 0 : Number(sectionScrollPositions[name] || 0));
    if (name === "disparos") sectionScrollPositions[name] = 0;
    requestAnimationFrame(function () { if (generation === sectionRenderGeneration) contentArea.scrollTop = Math.max(0, scrollTarget); });
    notifySectionState("ready", name);
    return { ok: true, section: name };
  }

  function showSectionAfterGuard(name, options) {
    options = options || {};
    var previousName = currentSectionName;
    if (previousName && previousName !== name) sectionScrollPositions[previousName] = contentArea.scrollTop || 0;
    var generation = ++sectionRenderGeneration;
    if (name === "disparos") { sectionScrollPositions[name] = 0; contentArea.scrollTop = 0; }
    currentSectionName = name;
    lastAuthorizedSection = name;
    if (!options.skipUrlSync) syncDashboardSectionUrl(name, { preserveRouteParams: options.preserveRouteParams === true });
    notifySectionState("change", name);
    hideFallbackSurface();
    var routeCtx = dashboardRouteContext(name);
    var navHost = document.getElementById("extappSidebarNav");
    if (navHost && navHost._extuiExpandGroupForSection) navHost._extuiExpandGroupForSection(name);
    currentNavButtons().forEach(function (btn) {
      var active = btn.getAttribute("data-section") === (routeCtx.parent || name);
      btn.classList.toggle("active", active);
      if (active) btn.setAttribute("aria-current", "page");
      else btn.removeAttribute("aria-current");
    });
    setSectionBusy(generation, true);

    function updateContent() {
      function resolveRenderer() {
        var renderFn = sections[name];
        if (typeof renderFn === "function") return Promise.resolve(renderFn);
        var loader = window.__extDashboardLazyLoader;
        if (!loader || typeof loader.canLoad !== "function" || !loader.canLoad(name)) return Promise.reject(new Error("Área ainda não registrada: " + name));
        return Promise.resolve(loader.ensure(name)).then(function () {
          var loadedRenderer = sections[name];
          if (typeof loadedRenderer !== "function") throw new Error("O módulo da área não registrou o renderer: " + name);
          return loadedRenderer;
        });
      }
      return resolveRenderer().then(function (renderFn) {
        if (generation !== sectionRenderGeneration || currentSectionName !== name) return { ok: false, section: name, reason: "superseded" };
        contentArea.innerHTML = "";
        var renderResult;
        try { renderResult = renderFn(contentArea); }
        catch (error) { return Promise.reject(error); }
        return Promise.resolve(renderResult).then(function () { return finalizeSectionRender(name, generation, options); });
      });
    }

    var renderPromise = updateContent();

    return Promise.resolve(renderPromise).then(function (result) {
      if (generation === sectionRenderGeneration) setSectionBusy(generation, false);
      return result || { ok: true, section: name };
    }, function (error) {
      if (generation === sectionRenderGeneration && currentSectionName === name) {
        renderSectionError(name, error);
        notifySectionState("error", name);
        setSectionBusy(generation, false);
      }
      return { ok: false, section: name, reason: "render-error", error: error && error.message ? error.message : String(error) };
    });
  }

  function showSection(name, options) {
    options = options || {};
    if (name === "core") {
      name = "home";
      options = Object.assign({}, options, { force: true, preserveRouteParams: true });
    }
    if (!_x3()) return Promise.resolve({ ok: false, section: name, reason: "access-locked" });
    return extDashboardPlanState().then(function(plan){
      extDashboardApplyPlanNav(plan);
      if(plan.isPaid!==true){if(plan.isFree&&!extDashboardFreeAllows(name))return extDashboardRenderPlanPaywall(name);if(!plan.isFree)return {ok:false,section:name,reason:"plan-locked"};}
      if (currentSectionName === name && options.force !== true && contentArea.childNodes.length) {
        if (name === "disparos") { sectionScrollPositions[name] = 0; contentArea.scrollTop = 0; }
        return { ok: true, section: name, reused: true };
      }
      if (!sectionNavigationGuard) return showSectionAfterGuard(name, options);
      return Promise.resolve(sectionNavigationGuard(name)).then(function (allowed) {
        if (allowed === false) return { ok: false, section: name, reason: "blocked" };
        return showSectionAfterGuard(name, options);
      });
    });
  }

  if (chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      if (!message || message.__extShellNavigate !== true) return;
      if (!sender || sender.id !== chrome.runtime.id) return;
      resolveShellTabId(function (tabId) {
        if (message.targetTabId != null && tabId != null && Number(message.targetTabId) !== Number(tabId)) return;
        var hasRouteIntent = !!(message.section || message.focus || message.crmContactId || message.crmId || message.crmView || message.crmProfileTab || message.flowId || message.funnelId || message.crmCreate === true || message.crmCopilot === true);
        if (!hasRouteIntent) { sendResponse({ ok: true, focused: true }); return; }
        var targetSection = message.section || (message.focus ? "ajustes" : (currentSectionName || "home"));
        applyShellRouteMessage(message, targetSection);
        accessRequestedSection = targetSection;
        var hasContext = !!(message.focus || message.crmContactId || message.crmId || message.crmView || message.crmProfileTab || message.flowId || message.funnelId || message.crmCreate === true || message.crmCopilot === true);
        sendResponse({ ok: true, accepted: true, section: targetSection });
        if (_x3()) showSection(targetSection, { force: hasContext || currentSectionName !== targetSection, preserveScroll: false, preserveRouteParams: true, skipUrlSync: true });
      });
      return true;
    });
  }

  function registerSection(name, renderFn) {
    sections[name] = renderFn;
  }
  function setNavigationGuard(guard) {
    sectionNavigationGuard = typeof guard === "function" ? guard : null;
  }

  currentNavButtons().forEach(function (btn) {
    btn.addEventListener("click", function () {
      var name = btn.getAttribute("data-section");
      if (btn.classList.contains("disabled") || btn.getAttribute("data-external") === "1") {
                                                                            
                                                                
        showHomeFallback();
        return;
      }
      showSection(name);
    });
  });

  function extPlaySystemSound(kind){try{var Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;var activation=navigator.userActivation;if(activation&&activation.isActive!==true)return;var ctx=new Ctx();if(ctx.state==="suspended"){try{var resumed=ctx.resume();if(resumed&&typeof resumed.catch==="function")resumed.catch(function(){});}catch(_){try{ctx.close();}catch(__){}return;}}var osc=ctx.createOscillator(),gain=ctx.createGain(),now=ctx.currentTime;osc.type="sine";osc.frequency.setValueAtTime(kind==="error"?330:620,now);if(kind==="error")osc.frequency.exponentialRampToValueAtTime(220,now+.14);else osc.frequency.exponentialRampToValueAtTime(820,now+.1);gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(.045,now+.012);gain.gain.exponentialRampToValueAtTime(.0001,now+.17);osc.connect(gain);gain.connect(ctx.destination);osc.start(now);osc.stop(now+.18);osc.onended=function(){try{ctx.close();}catch(_){}};}catch(_){}}
  window.__extPlaySystemSound=extPlaySystemSound;

  function dashboardToast(message, isError) {
    message = String(message == null ? "" : message);
    var region = document.getElementById("extuid-global-status-region");
    if (!region) {
      region = document.createElement("div"); region.id = "extuid-global-status-region"; region.setAttribute("role","status");
      region.setAttribute("aria-live","polite"); region.setAttribute("aria-atomic","true");
      region.style.cssText="position:fixed;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;";
      document.body.appendChild(region);
    }
    region.textContent=""; setTimeout(function(){region.textContent=message;},0);
    var meaningfulSuccess = /(?:enviad[oa]|conclu[ií]d|importad[oa]|exportad[oa]|backup|c[oó]pia|restaurad[oa]|agendad[oa]|conectad[oa]|campanha|teste.{0,24}sucesso|processamento.{0,24}finaliz)/i.test(message);
    if (!isError && !meaningfulSuccess) return region;
    var wrap = document.getElementById("extuid-global-toast-wrap");
    if (!wrap) { wrap = document.createElement("div"); wrap.id = "extuid-global-toast-wrap"; wrap.className = "extuiToastWrap"; document.body.appendChild(wrap); }
    var item = document.createElement("div"); item.className = "extuiToast " + (isError ? "extuiToast--error" : "extuiToast--success");
    item.setAttribute("role", isError ? "alert" : "status"); item.textContent = message; wrap.appendChild(item);
    while (wrap.children.length > 3) wrap.firstElementChild.remove();
    setTimeout(function () { if (item.parentNode) item.remove(); }, isError ? 4200 : 2600);
    return item;
  }

  function sendToWhatsAppTabDirect(type, payload, timeoutMs) {
    return new Promise(function (resolve, reject) {
      var requestId = "extuid-" + Date.now() + "-" + Math.random().toString(36).slice(2, 9);
      var settled = false;
      var timeoutId = null;
      function finish(err, data) {
        if (settled) return;
        settled = true;
        if (timeoutId) clearTimeout(timeoutId);
        if (err) reject(err); else resolve(data);
      }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        if (chrome.runtime.lastError) { finish(new Error(chrome.runtime.lastError.message)); return; }
        var tab = (tabs || []).find(function (candidate) { return candidate && candidate.active; }) || (tabs || [])[0];
        if (!tab || tab.id == null) { finish(new Error("Abra o WhatsApp Web em outra aba e aguarde o carregamento.")); return; }
        chrome.tabs.sendMessage(tab.id, { type: type, requestId: requestId, payload: payload || {} }, function (response) {
          if (chrome.runtime.lastError) { finish(new Error(chrome.runtime.lastError.message)); return; }
          if (!response || response.requestId !== requestId) { finish(new Error("Resposta inválida do WhatsApp Web.")); return; }
          if (response.error) {
            var error = new Error(response.error);
            if (response.code) error.code = response.code;
            finish(error);
            return;
          }
          finish(null, response.data);
        });
        timeoutId = setTimeout(function () {
          finish(new Error("Tempo esgotado. Confira se o WhatsApp Web está aberto e terminou de carregar."));
        }, Math.max(1000, Number(timeoutMs) || 25000));
      });
    });
  }

  function storageGetSafe(keys) {
    try {
      if (window.ExtensionStorage && typeof window.ExtensionStorage.getMany === "function") {
        var normalized = Array.isArray(keys) ? keys : (typeof keys === "string" ? [keys] : Object.keys(keys || {}));
        return window.ExtensionStorage.getMany(normalized).then(function (result) { return result || {}; });
      }
    } catch (_) {}
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(keys, function (result) {
          if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
          resolve(result || {});
        });
      } catch (error) { reject(error); }
    });
  }

  function storageSetSafe(patch) {
    try {
      if (window.ExtensionStorage && typeof window.ExtensionStorage.setMany === "function") {
        return window.ExtensionStorage.setMany(patch || {}).then(function () {});
      }
    } catch (_) {}
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.set(patch, function () {
          if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
          resolve();
        });
      } catch (error) { reject(error); }
    });
  }
  function storageRemoveSafe(keys) {
    try { if (window.ExtensionStorage && typeof window.ExtensionStorage.removeMany === "function") return window.ExtensionStorage.removeMany(Array.isArray(keys) ? keys : [keys]).then(function () {}); } catch (_) {}
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.remove(keys, function () {
          if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
          resolve();
        });
      } catch (error) { reject(error); }
    });
  }

  window.__extDashboardShell = {
    registerSection: registerSection,
    showSection: showSection,
    refreshSectionChrome: function () {
      if (!currentSectionName) return;
      ensureContextTabs(currentSectionName);
      ensureAccessibleControls(contentArea);
    },
    getCurrentSection: function () { return currentSectionName; },
    hasSection: function (name) { return typeof sections[String(name || "")] === "function"; },
    getRegisteredSections: function () { return Object.keys(sections).filter(function (name) { return typeof sections[name] === "function"; }).sort(); },
    showHomeFallback: showHomeFallback,
    setNavigationGuard: setNavigationGuard,
    _a: _x3,
    getAccessState: function () { return _x2; },
    toast: dashboardToast,
    sendToWhatsAppTab: sendToWhatsAppTabDirect,
    storageGet: storageGetSafe,
    storageSet: storageSetSafe
  };

  (function setupCrossSurfaceDataSync(){
    if(!window.ExtensionCore||!window.ExtensionCore.UISync)return;
    var byDomain={
      "orders":["encomendas"],"activities":["atividades"],"activity":["atividades"],
      "crm":["crm","crm-funnel"],"quick-responses":["quick-responses"],
      "quick-items":["itens-message","itens-audio","itens-image","itens-video","itens-sticker","itens-document","itens-pix","itens-interactive-list","itens-contact","itens-signature"],
      "fluxos":["fluxos"],"funis":["funis"],"agenda":["agenda"],"followup":["followup"],
      "integrations":["integracoes","meta-oficial"],"webhooks":["integracoes"],
      "ai":["ai-connect","ai-assistants","ai-agents","ai-memory"],"knowledge":["knowledge"]
    };
    var refreshTimer=0,pendingExternal=false;
    var selfManagedSections=new Set(["crm","crm-funnel","fluxos","funis","agenda","followup","quick-responses","ai-memory"]);
    function editing(){var a=document.activeElement;return !!(a&&contentArea.contains(a)&&a.matches('input,textarea,select,[contenteditable="true"]'));}
    function matches(detail){var current=currentSectionName;if(!current||!detail||selfManagedSections.has(current))return false;var domains=Array.isArray(detail.externalDomains)?detail.externalDomains:detail.domains;return Array.isArray(domains)&&domains.some(function(domain){return (byDomain[domain]||[]).indexOf(current)>=0;});}
    function refresh(){refreshTimer=0;if(!pendingExternal)return;if(editing())return;pendingExternal=false;showSection(currentSectionName,{force:true,preserveScroll:true,preserveRouteParams:true}).catch(function(err){pendingExternal=true;if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_CROSS_SURFACE_REFRESH_FAILED",err);});}
    window.ExtensionCore.UISync.subscribe("*",function(detail){if(!detail||detail.external!==true||!matches(detail))return;pendingExternal=true;clearTimeout(refreshTimer);refreshTimer=setTimeout(refresh,60);});
    contentArea.addEventListener("focusout",function(){if(!pendingExternal)return;setTimeout(function(){if(!editing()){clearTimeout(refreshTimer);refreshTimer=setTimeout(refresh,30);}},0);});
  })();

  (function setupAccessibilityObserver(){
    var pending=0;
    var observer=new MutationObserver(function(records){
      var shouldRun=records.some(function(r){return r.addedNodes&&r.addedNodes.length;});
      if(!shouldRun)return;
      clearTimeout(pending);
      pending=setTimeout(function(){
        try{
          ensureAccessibleControls(document);
          if (currentSectionName && contentArea && contentArea.isConnected) {
            var expectsContextTabs = /^(itens-(message|audio|image|video|media|sticker|document|pix|interactive-list|contact|signature)|ai-connect|ai-assistants|ai-agents|ai-memory|knowledge)$/.test(currentSectionName);
            if (expectsContextTabs && !contentArea.querySelector(":scope > .extappContextTabs")) ensureContextTabs(currentSectionName);
          }
        }catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_ACCESSIBILITY_REFRESH_FAILED",err);}
      },40);
    });
    observer.observe(document.body,{childList:true,subtree:true});
  })();

                                                                          
                                                                        
                                                                
                                                                          
                                                                       
                                                                           
                                           
  (function setupSidebarCompact() {
    var sidebar = document.getElementById("extappSidebar");
    var toggleBtn = document.getElementById("extappSidebarToggle");
    if (!sidebar || !toggleBtn) return;
    var COMPACT_KEY = "EXTUI:extappDashboardSidebarCompact";
    var LEGACY_PINNED_KEY = "EXTUI:extappDashboardRailPinned";                                                                                 
    var compact = false;
    var toggleLabelEl = toggleBtn.querySelector(".extappSidebarToggleLabel");

    function apply(next) {
      compact = !!next;
      sidebar.classList.toggle("compact", compact);
      sidebar.querySelectorAll(".extappNavGroupLabel").forEach(function (groupLabel) {
        if (compact) { groupLabel.tabIndex = -1; groupLabel.setAttribute("aria-hidden", "true"); }
        else { groupLabel.tabIndex = 0; groupLabel.removeAttribute("aria-hidden"); }
      });
      var nav = document.getElementById("extappSidebarNav");
      if (nav && typeof nav._extuiApplyGroupState === "function") nav._extuiApplyGroupState();
      var label = compact ? "Expandir menu" : "Recolher menu";
      toggleBtn.title = label;
      toggleBtn.setAttribute("aria-label", label);
      toggleBtn.setAttribute("aria-pressed", String(compact));
      if (toggleLabelEl) toggleLabelEl.textContent = label;
    }

    toggleBtn.addEventListener("click", function () {
      var previous = compact;
      apply(!compact);
      var obj = {}; obj[COMPACT_KEY] = compact;
      storageSetSafe(obj).catch(function () {
        apply(previous);
        dashboardToast("Não foi possível salvar o estado do menu.", true);
      });
    });

                                                               
                                                                       
                                                                         
                                                                          
                                                                      
                                                
    try {
      chrome.storage.local.get([COMPACT_KEY, LEGACY_PINNED_KEY], function (res) {
        if (res && Object.prototype.hasOwnProperty.call(res, COMPACT_KEY)) {
          apply(res[COMPACT_KEY]);
        } else {
          apply(false);
          if (res && Object.prototype.hasOwnProperty.call(res, LEGACY_PINNED_KEY)) {
            storageRemoveSafe(LEGACY_PINNED_KEY).catch(function () {});
          }
        }
      });
    } catch (err) {
      apply(false);
    }
  })();

                                               
                                                   
                                                            
                                                                           
                                                                        
                                                                         
                                                                            
                                                                          
                                                                           
                                                             
  var SHELL_ACTIONS = [
    { id: "new-broadcast", label: "Novo disparo", section: "disparos", selector: '[data-extui-academy-target="broadcast-content"]', icon: '<path d="M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"/>' },
    { id: "new-message", label: "Nova mensagem salva", section: "itens-message", selector: '[data-extui-academy-target="items-new-message"]', activate: true, icon: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>' },
    { id: "quick-responses-manage", label: "Gerenciar respostas rápidas", section: "quick-responses", selector: '.extuiQuickResponsesDashboard input[type="search"]', icon: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2"/>' },
    { id: "new-flow", label: "Novo fluxo", section: "fluxos", selector: '[data-extui-academy-target="flow-new"]', activate: true, icon: '<rect width="8" height="8" x="3" y="3" rx="2"/><rect width="8" height="8" x="13" y="13" rx="2"/>' },
    { id: "new-funnel", label: "Novo funil", section: "funis", selector: '.extuiFunnelListHeader .extui-btn--primary,.extuifHeader .extui-btn--primary', activate: true, icon: '<path d="M3 4h18M6 9h12M9 14h6M11 19h2"/>' },
    { id: "new-schedule", label: "Novo agendamento", section: "agenda", selector: '[data-extui-academy-target="agenda-fields"] input,[data-extui-academy-target="agenda-fields"] select', icon: '<path d="M8 2v3M16 2v3"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>' },
    { id: "new-crm", label: "Novo CRM", section: "crm", selector: '.extuiCrmSection .extui-btn--primary,.extuiCrmHeader .extui-btn--primary', activate: true, icon: '<path d="M5 3v14M12 3v8M19 3v18"/>' },
    { id: "new-order", label: "Nova encomenda", section: "encomendas", selector: '[data-extui-shell-action="new-order"]', activate: true, icon: '<path d="m21 8-9-5-9 5 9 5 9-5Z"/><path d="M3 8v8l9 5 9-5V8"/>' },
    { id: "new-ai-agent", label: "Novo agente IA", section: "ai-agents", selector: '[data-extui-academy-target="ai-agents-new"],.extuigEmpty .extui-btn--primary', activate: true, icon: '<circle cx="12" cy="12" r="3"/><path d="M9.5 3h5l1 3 3 1.7"/>' },
    { id: "audio-transcription", label: "Configurar transcrição de áudio", section: "ai-transcription", icon: '<path d="M4 12h2m2-5v10m4-13v16m4-12v8m4-5v2"/>' },
    { id: "ai-translation", label: "Configurar tradução por IA", section: "ai-translation", icon: '<path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/>' },
    { id: "export-contacts", label: "Exportar Contatos", section: "salvar", selector: '[data-extui-academy-target="salvar-source"]', icon: '<path d="M12 15V3"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>' },
    { id: "backup", label: "Criar cópia de segurança", section: "backup", selector: '#extuiAjustesExportBackupBtn', activate: true, icon: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/>' },
    { id: "theme", label: "Alterar Modo (claro/escuro)", targetId: "extappThemeToggleBtn", icon: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2"/>' },
    { id: "sidebar", label: "Recolher/expandir menu lateral", targetId: "extappSidebarToggle", icon: '<path d="m15 18-6-6 6-6"/>' },
    { id: "ajustes", label: "Abrir Ajustes", targetId: "extappSettingsBtn", icon: '<path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0"/><circle cx="12" cy="12" r="3"/>' }
  ];

                                                                     
                                                                    
                                                                   
                                                                     
  function extFuzzyScore(query, label) {
    var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
    var q = formHelpers ? formHelpers.normalizeSearch(query) : String(query || "").toLowerCase();
    var l = formHelpers ? formHelpers.normalizeSearch(label) : String(label || "").toLowerCase();
    var prefixIdx = l.indexOf(q);
    if (prefixIdx === 0) return { tier: 0, index: 0, span: q.length, matches: extRange(0, q.length) };
    if (prefixIdx !== -1) return { tier: 1, index: prefixIdx, span: q.length, matches: extRange(prefixIdx, prefixIdx + q.length) };
    var matches = [];
    var li = 0;
    for (var qi = 0; qi < q.length; qi++) {
      var found = -1;
      for (; li < l.length; li++) {
        if (l[li] === q[qi]) { found = li; li++; break; }
      }
      if (found === -1) return null;
      matches.push(found);
    }
    return { tier: 2, index: matches[0], span: matches[matches.length - 1] - matches[0] + 1, matches: matches };
  }
  function extRange(start, end) { var a = []; for (var i = start; i < end; i++) a.push(i); return a; }
  function extCompareScored(a, b) {
    if (a.score.tier !== b.score.tier) return a.score.tier - b.score.tier;
    if (a.score.index !== b.score.index) return a.score.index - b.score.index;
    if (a.score.span !== b.score.span) return a.score.span - b.score.span;
    return a.label.localeCompare(b.label);
  }
                                                                            
                                                               
  function extBuildHighlightedLabel(label, matchedIndices) {
    var frag = document.createDocumentFragment();
    var matchSet = {};
    (matchedIndices || []).forEach(function (i) { matchSet[i] = true; });
    for (var i = 0; i < label.length; i++) {
      if (matchSet[i]) {
        var b = document.createElement("b");
        b.className = "extappSearchMatch";
        b.textContent = label[i];
        frag.appendChild(b);
      } else {
        frag.appendChild(document.createTextNode(label[i]));
      }
    }
    return frag;
  }

  (function setupTopbar() {
    var searchBtn = document.getElementById("extappTopbarSearchBtn");
    var searchOverlay = document.getElementById("extappSearchOverlay");
    var searchInput = document.getElementById("extappSearchInput");
    var searchResults = document.getElementById("extappSearchResults");
    var settingsBtn = document.getElementById("extappSettingsBtn");
    var themeBtn = document.getElementById("extappThemeToggleBtn");

    var RECENTS_KEY = "EXTUI:extappPaletteRecents";
    var MAX_RECENTS = 5;
    var SECTION_BY_NAME = {};
    SIDEBAR_NAV_ITEMS.forEach(function (item) { SECTION_BY_NAME[item.section] = item; });
    var PALETTE_SECTION_ITEMS = SIDEBAR_NAV_ITEMS.slice();
    Object.keys(DASHBOARD_ROUTE_CONTEXT).forEach(function(route){
      if (SECTION_BY_NAME[route]) return;
      var ctx=DASHBOARD_ROUTE_CONTEXT[route],parent=SECTION_BY_NAME[ctx.parent];
      if(!parent)return;
      var item={section:route,group:ctx.group,accent:parent.accent,label:ctx.parentLabel+" · "+ctx.childLabel,icon:parent.icon};
      SECTION_BY_NAME[route]=item;PALETTE_SECTION_ITEMS.push(item);
    });

                                                                           
                                                                         
                                                                         
                                                                         
    function loadRecents(callback) {
      try {
        chrome.storage.local.get(RECENTS_KEY, function (res) {
          var list = (res && Array.isArray(res[RECENTS_KEY])) ? res[RECENTS_KEY] : [];
          var valid = list.filter(function (r) { return r && SECTION_BY_NAME[r.section]; }).slice(0, MAX_RECENTS);
          callback(valid);
        });
      } catch (err) {
        callback([]);
      }
    }
                                                                           
                                                                         
                                                                           
                                                                     
                                                                     
                                               
    var recentsWriteChain = Promise.resolve();
    function recordRecent(section) {
      recentsWriteChain = recentsWriteChain.then(async function () {
        try {
          var res = await storageGetSafe(RECENTS_KEY);
          var list = (res && Array.isArray(res[RECENTS_KEY])) ? res[RECENTS_KEY] : [];
          list = list.filter(function (r) { return r && r.section !== section; });
          list.unshift({ section: section, lastUsedAt: Date.now() });
          var obj = {}; obj[RECENTS_KEY] = list.slice(0, MAX_RECENTS);
          await storageSetSafe(obj);
        } catch (err) { }
      });
    }

    var recentsCache = [];
    var rows = [];
    var activeIndex = -1;
    var previouslyFocused = null;
    var FAVORITES_KEY = "EXTUI:extappGlobalFavorites";
    var UNIVERSAL_FAVORITES_LIMIT = 80;
    var universalIndex = [];
    var favoritesCache = [];
    var favoritesStoreReady = false;
    var lastSearchQuery = "";
    var UNIVERSAL_KEYS = [
      "EXTUI:textMessageStore","EXTUI:audioStore","EXTUI:mediaStore","EXTUI:documentStore","EXTUI:stickerStore","EXTUI:pixStore","EXTUI:interactiveListStore","EXTUI:contactCardStore","EXTUI:signaturesStore",
      "EXTUI:extappFlowStore","EXTUI:extappFunnelStore","EXTUI:CrmStore","EXTUI:crmProfessionalStore","EXTUI:ordersStore","EXTUI:extappFollowUpStore","EXTUI:extappQuickResponseStore"
    ];
    function paletteParse(raw) {
      if (raw == null) return {};
      try { var parsed = typeof raw === "string" ? JSON.parse(raw) : raw; return parsed && parsed.state ? parsed.state : (parsed || {}); }
      catch (_) { return {}; }
    }
    function paletteItemIcon(section) {
      var item = SECTION_BY_NAME[section];
      return item ? item.icon : '<circle cx="12" cy="12" r="8"/><path d="M8 12h8"/>';
    }
    function paletteItemAccent(section) {
      var item = SECTION_BY_NAME[section];
      return item ? item.accent : "#10b981";
    }
    function universalPush(out, section, entityType, id, label, meta, extra) {
      label = String(label || "").trim(); if (!label) return;
      var item = Object.assign({
        kind:"entity", id:String(id || (entityType+":"+label)), section:section, entityType:entityType,
        label:label, meta:String(meta || ""), accent:paletteItemAccent(section), icon:paletteItemIcon(section)
      }, extra || {});
      out.push(item);
    }
    function buildUniversalIndex(values) {
      var out = [];
      function addList(key, field, section, type, typeLabel) {
        var state = paletteParse(values[key]), list = Array.isArray(state[field]) ? state[field] : [];
        list.forEach(function (item, index) {
          if (!item) return;
          var label = item.name || item.title || item.fileName || item.merchantName || item.contactName || item.id || (typeLabel+" "+(index+1));
          universalPush(out, section, type, item.id || (type+":"+index), label, typeLabel);
        });
      }
      addList("EXTUI:textMessageStore","textMessageList","itens-message","message","Mensagem");
      addList("EXTUI:audioStore","audioList","itens-audio","audio","Áudio");
      (function(){
        var mediaState=paletteParse(values["EXTUI:mediaStore"]), mediaList=Array.isArray(mediaState.mediaList)?mediaState.mediaList:[];
        mediaList.forEach(function(item,index){
          if(!item)return;
          var subtype=item.mediaKind==="video"?"video":"image";
          var section=subtype==="video"?"itens-video":"itens-image";
          var label=item.name||item.fileName||item.id||((subtype==="video"?"Vídeo ":"Imagem ")+(index+1));
          universalPush(out,section,subtype,item.id||(subtype+":"+index),label,subtype==="video"?"Vídeo":"Imagem");
        });
      })();
      addList("EXTUI:documentStore","documentList","itens-document","document","Documento");
      addList("EXTUI:stickerStore","stickerList","itens-sticker","sticker","Figurinha");
      addList("EXTUI:pixStore","pixList","itens-pix","pix","PIX");
      addList("EXTUI:interactiveListStore","interactiveListList","itens-interactive-list","interactive-list","Lista interativa");
      addList("EXTUI:contactCardStore","contactList","itens-contact","contact-card","Contato salvo");
      addList("EXTUI:signaturesStore","list","itens-signature","signature","Assinatura");
      addList("EXTUI:extappFlowStore","flowList","fluxos","flow","Fluxo");
      addList("EXTUI:extappFunnelStore","funnelList","funis","funnel","Funil");
      var crm = paletteParse(values["EXTUI:CrmStore"]), crmList = Array.isArray(crm.crmList) ? crm.crmList : [];
      crmList.forEach(function (board) {
        if (!board) return;
        universalPush(out,"crm","crm",board.id,board.name||"CRM","CRM");
        (board.columns||[]).forEach(function (column) {
          (column.items||[]).forEach(function (membership) {
            if (!membership || !membership.contact) return;
            var phone=String(membership.contact.phoneNumber||"");
            var name=String(membership.contact.name||phone||"Contato");
            universalPush(out,"crm","crm-contact",membership.id,name+(phone?" · "+phone:""),(board.name||"CRM")+" · "+(column.title||"Etapa"),{contactId:String(membership.id||""),phoneNumber:phone});
          });
        });
      });
      var pro = paletteParse(values["EXTUI:crmProfessionalStore"]), contacts = pro && pro.contacts && typeof pro.contacts === "object" ? pro.contacts : {};
      Object.keys(contacts).forEach(function (contactId) {
        var profile=contacts[contactId]||{};
        (profile.notes||[]).forEach(function(note,index){ if(note&&(note.title||note.text)) universalPush(out,"crm","crm-note",contactId+":note:"+(note.id||index),note.title||String(note.text||"").slice(0,70),"Nota do CRM",{contactId:contactId}); });
        (profile.tasks||[]).forEach(function(task,index){ if(task&&task.title) universalPush(out,"crm","crm-task",contactId+":task:"+(task.id||index),task.title,"Tarefa do CRM",{contactId:contactId}); });
      });
      var ordersRaw=values["EXTUI:ordersStore"], orders=[]; try{orders=typeof ordersRaw==="string"?JSON.parse(ordersRaw):(Array.isArray(ordersRaw)?ordersRaw:[]);}catch(_){orders=[];}
      (Array.isArray(orders)?orders:[]).forEach(function(order,index){if(order)universalPush(out,"encomendas","order",order.id||index,order.name||order.orderId||"Encomenda",order.trackingCode?"Rastreio · "+order.trackingCode:"Encomenda");});
      var fu=paletteParse(values["EXTUI:extappFollowUpStore"]), rules=Array.isArray(fu.list)?fu.list:(Array.isArray(fu.followUpList)?fu.followUpList:[]);
      rules.forEach(function(rule,index){if(rule)universalPush(out,"followup","followup",rule.id||index,rule.nome||rule.name||"Regra de FollowUp",rule.active?"FollowUp ativo":"FollowUp");});
      var qr=paletteParse(values["EXTUI:extappQuickResponseStore"]), qrs=Array.isArray(qr.items)?qr.items:[];
      qrs.forEach(function(item,index){if(item)universalPush(out,"quick-responses","quick-response",item.id||index,item.name||"Resposta rápida",item.shortcut?"Atalho · "+item.shortcut:"Resposta Rápida");});
      return out;
    }
    function refreshUniversalIndex(callback) {
      try { chrome.storage.local.get(UNIVERSAL_KEYS.concat([FAVORITES_KEY]), function(res){
        if(chrome.runtime.lastError){favoritesStoreReady=false;if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_FAVORITES_READ_FAILED",new Error(chrome.runtime.lastError.message));if(callback)callback(false);return;}
        universalIndex = buildUniversalIndex(res||{});
        window.__extUniversalIndex = universalIndex.slice();
        var rawFavorites=res&&res[FAVORITES_KEY];
        if(rawFavorites!=null&&!Array.isArray(rawFavorites)){favoritesStoreReady=false;if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_FAVORITES_STORE_CORRUPT",new Error("O armazenamento de Favoritos está inválido."));if(callback)callback(false);return;}
        favoritesCache = Array.isArray(rawFavorites) ? rawFavorites.filter(Boolean) : [];
        if(favoritesCache.length>UNIVERSAL_FAVORITES_LIMIT){favoritesStoreReady=false;if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_FAVORITES_STORE_TOO_LARGE",new Error("Há mais de "+UNIVERSAL_FAVORITES_LIMIT+" Favoritos salvos e nenhum será truncado."));if(callback)callback(false);return;}
        favoritesStoreReady=true;
        if(callback)callback(true);
      }); } catch(err) { favoritesStoreReady=false;if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_FAVORITES_READ_FAILED",err);if(callback)callback(false); }
    }
    function favoriteKey(kind,id){return String(kind||"")+":"+String(id||"");}
    function isFavorite(kind,id){var key=favoriteKey(kind,id);return favoritesCache.some(function(item){return item&&item.key===key;});}
    function saveFavorites(){if(!favoritesStoreReady)return Promise.reject(new Error("Os Favoritos ainda não estão disponíveis para alteração."));if(favoritesCache.length>UNIVERSAL_FAVORITES_LIMIT)return Promise.reject(new Error("O limite de "+UNIVERSAL_FAVORITES_LIMIT+" Favoritos foi atingido."));var obj={};obj[FAVORITES_KEY]=favoritesCache.slice();return storageSetSafe(obj);}
    function toggleFavoriteFromRow(row) {
      if(!favoritesStoreReady){toast("Não foi possível carregar os Favoritos com segurança. Recarregue o painel antes de alterá-los.",true);return;}
      var kind=row.getAttribute("data-kind"),id=row.getAttribute("data-id"),key=favoriteKey(kind,id),idx=favoritesCache.findIndex(function(item){return item&&item.key===key;});
      if(idx<0&&favoritesCache.length>=UNIVERSAL_FAVORITES_LIMIT){toast("O limite de "+UNIVERSAL_FAVORITES_LIMIT+" Favoritos foi atingido.",true);return;}
      var previous=favoritesCache.slice();
      if(idx>=0)favoritesCache.splice(idx,1);else favoritesCache.unshift({key:key,kind:kind,id:id,label:row.getAttribute("data-label")||"Favorito",section:row.getAttribute("data-section")||id,entityType:row.getAttribute("data-entity-type")||"",contactId:row.getAttribute("data-contact-id")||"",meta:row.getAttribute("data-meta")||"",accent:row.getAttribute("data-accent")||"",icon:row.getAttribute("data-icon")||""});
      renderResults(lastSearchQuery);
      saveFavorites().catch(function(err){favoritesCache=previous;renderResults(lastSearchQuery);if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_FAVORITES_SAVE_FAILED",err);toast("Não foi possível salvar a alteração nos Favoritos.",true);});
    }

    function iconChip(accentOrNull, svg) {
      var span = document.createElement("span");
      if (accentOrNull) {
        span.className = "navIconChip";
        span.style.setProperty("--c", accentOrNull);
      } else {
        span.className = "extappSearchActionIcon";
      }
      span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + svg + '</svg>';
      return span;
    }

    function palettePlanLocked(section) {
      section=String(section||"");if(!section)return false;
      var kind=String(window.__extCurrentPlanKind||"locked");
      if(kind==="paid")return false;
      if(kind==="free"&&window.__extPlanGate&&typeof window.__extPlanGate.allowsSection==="function")return !window.__extPlanGate.allowsSection(section);
      var nav=document.querySelector('#extappSidebarNav [data-section="'+section.replace(/"/g,"")+'"]');
      return !nav||nav.hasAttribute("data-plan-locked");
    }
    function buildRow(kind, id, accentOrNull, svg, labelText, matchedIndices, metaText, payload) {
      payload = payload || {};
      var row = document.createElement("div");
      row.className = "extappSearchResultRow";
      row.setAttribute("role", "listitem");
      row.setAttribute("data-kind", kind);
      row.setAttribute("data-id", id);
      row.setAttribute("data-label", labelText || "");
      row.setAttribute("data-section", payload.section || (kind === "section" ? id : ""));
      row.setAttribute("data-entity-type", payload.entityType || "");
      row.setAttribute("data-contact-id", payload.contactId || "");
      row.setAttribute("data-meta", metaText || payload.meta || "");
      row.setAttribute("data-accent", accentOrNull || payload.accent || "");
      row.setAttribute("data-icon", svg || payload.icon || "");
      var planLocked=palettePlanLocked(payload.section || (kind === "section" ? id : ""));
      row.toggleAttribute("data-plan-locked",planLocked);
      row.appendChild(iconChip(accentOrNull, svg));
      var labelEl = document.createElement("span");
      labelEl.className = "extappSearchRowLabel";
      if (matchedIndices) labelEl.appendChild(extBuildHighlightedLabel(labelText, matchedIndices));
      else labelEl.textContent = labelText;
      row.appendChild(labelEl);
      if (metaText) {
        var meta = document.createElement("span");
        meta.className = "extappSearchRowMeta";
        meta.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
        var metaLabel = document.createElement("span");
        metaLabel.textContent = metaText;
        meta.appendChild(metaLabel);
        row.appendChild(meta);
      }
      if(planLocked){var pro=document.createElement("span");pro.className="extappSearchPlanChip";pro.textContent="PRO";row.appendChild(pro);}
      if ((kind === "section" || kind === "entity") && !planLocked) {
        var favorite = document.createElement("button");
        favorite.type = "button";
        favorite.className = "extappSearchFavorite" + (isFavorite(kind,id) ? " is-active" : "");
        favorite.setAttribute("aria-label", isFavorite(kind,id) ? "Remover dos favoritos" : "Adicionar aos favoritos");
        favorite.title = favorite.getAttribute("aria-label");
        favorite.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.6"><path d="m12 2.8 2.72 5.51 6.08.88-4.4 4.29 1.04 6.06L12 16.68l-5.44 2.86 1.04-6.06-4.4-4.29 6.08-.88Z"/></svg>';
        favorite.addEventListener("click", function(event){event.stopPropagation();toggleFavoriteFromRow(row);});
        row.appendChild(favorite);
      }
      row.addEventListener("click", function () { activateRow(row); });
      return row;
    }

    function groupLabel(text) {
      var el = document.createElement("div");
      el.className = "extappSearchGroupLabel";
      el.setAttribute("role", "presentation");
      el.textContent = text;
      return el;
    }

    function fmtRecentWhen(ms) {
      var diff = Date.now() - ms;
      if (diff < 90000) return "agora há pouco";
      var mins = Math.round(diff / 60000);
      if (mins < 60) return "há " + mins + " min";
      var hours = Math.round(mins / 60);
      if (hours < 24) return "há " + hours + "h";
      var days = Math.round(hours / 24);
      return "há " + days + (days === 1 ? " dia" : " dias");
    }

    function renderResults(query) {
      var q = (query || "").trim();
      lastSearchQuery = query || "";
      searchResults.innerHTML = "";
      rows = [];

      function appendPaletteItem(item, matchedIndices, metaOverride) {
        if (!item) return;
        var kind=item.kind||"entity", id=item.id||item.section, section=item.section||id;
        if(section==="segredos"&&!document.documentElement.hasAttribute("data-extui-secrets-unlocked"))return;
        if(kind==="entity"&&palettePlanLocked(section))return;
        var row=buildRow(kind,id,item.accent||paletteItemAccent(section),item.icon||paletteItemIcon(section),item.label||id,matchedIndices,metaOverride!=null?metaOverride:item.meta,{section:section,entityType:item.entityType||"",contactId:item.contactId||"",meta:item.meta||"",accent:item.accent||"",icon:item.icon||""});
        searchResults.appendChild(row);rows.push(row);
      }

      if (!q) {
        if (favoritesCache.length) {
          searchResults.appendChild(groupLabel("Favoritos globais"));
          favoritesCache.slice(0,10).forEach(function(fav){
            if(!fav)return;
            if(fav.kind==="section"){
              var sec=SECTION_BY_NAME[fav.id];if(sec)appendPaletteItem({kind:"section",id:sec.section,section:sec.section,label:sec.label,accent:sec.accent,icon:sec.icon},null,"Favorito");
              return;
            }
            var current=universalIndex.find(function(item){return favoriteKey("entity",item.id)===fav.key;});
            appendPaletteItem(current||{kind:"entity",id:fav.id,section:fav.section,label:fav.label,meta:fav.meta,accent:fav.accent,icon:fav.icon,entityType:fav.entityType,contactId:fav.contactId},null,"Favorito"+(fav.meta?" · "+fav.meta:""));
          });
        }
        var recentSections = {};
        if (recentsCache.length) {
          searchResults.appendChild(groupLabel("Recentes"));
          recentsCache.forEach(function (r) {
            var item = SECTION_BY_NAME[r.section];
            if (!item) return;
            recentSections[r.section] = true;
            appendPaletteItem({kind:"section",id:item.section,section:item.section,accent:item.accent,icon:item.icon,label:item.label},null,fmtRecentWhen(r.lastUsedAt));
          });
        }
        var remaining = SIDEBAR_NAV_ITEMS.filter(function (item) { return !recentSections[item.section]; });
        if (remaining.length) {
          searchResults.appendChild(groupLabel("Todas as seções"));
          remaining.forEach(function (item) { appendPaletteItem({kind:"section",id:item.section,section:item.section,accent:item.accent,icon:item.icon,label:item.label},null,null); });
        }
      } else {
        var sectionMatches = [];
        PALETTE_SECTION_ITEMS.forEach(function (item) {
          var score = extFuzzyScore(q, item.label);
          if (score) sectionMatches.push({ item: item, label: item.label, score: score });
        });
        sectionMatches.sort(extCompareScored);
        var actionMatches = [];
        SHELL_ACTIONS.forEach(function (action) {
          var score = extFuzzyScore(q, action.label);
          if (score) actionMatches.push({ item: action, label: action.label, score: score });
        });
        actionMatches.sort(extCompareScored);
        var entityMatches=[];
        universalIndex.forEach(function(item){
          if(palettePlanLocked(item&&item.section))return;
          var score=extFuzzyScore(q,item.label);
          var fromMeta=false;
          if(!score&&item.meta){score=extFuzzyScore(q,item.meta);fromMeta=!!score;}
          if(score)entityMatches.push({item:item,label:item.label,score:score,fromMeta:fromMeta});
        });
        entityMatches.sort(extCompareScored);

        if (!sectionMatches.length && !actionMatches.length && !entityMatches.length) {
          var empty = document.createElement("div");
          empty.className = "extappSearchEmpty";
          var main = document.createElement("div");
          main.textContent = "Nada encontrado na extensão.";
          var sub = document.createElement("div");
          sub.className = "extappSearchEmptySub";
          sub.textContent = "Busque por contato, CRM, item, fluxo, funil, resposta, encomenda, seção ou ação.";
          empty.appendChild(main); empty.appendChild(sub); searchResults.appendChild(empty);
        } else {
          if (entityMatches.length) {
            searchResults.appendChild(groupLabel("Conteúdo da extensão"));
            entityMatches.slice(0,14).forEach(function (m) { appendPaletteItem(m.item,m.fromMeta?null:m.score.matches,m.item.meta||m.item.entityType); });
          }
          if (actionMatches.length) {
            searchResults.appendChild(groupLabel("Ações"));
            actionMatches.slice(0,10).forEach(function (m) {
              var row = buildRow("action", m.item.id, null, m.item.icon, m.item.label, m.score.matches, null, {section:m.item.section||""});
              searchResults.appendChild(row); rows.push(row);
            });
          }
          if (sectionMatches.length) {
            searchResults.appendChild(groupLabel("Seções"));
            sectionMatches.slice(0,10).forEach(function (m) { appendPaletteItem({kind:"section",id:m.item.section,section:m.item.section,accent:m.item.accent,icon:m.item.icon,label:m.item.label},m.score.matches,null); });
          }
        }
      }

      rows.forEach(function (row, i) { row.id = "extappPaletteRow-" + i; });
      activeIndex = rows.length ? 0 : -1;
      updateActiveRow();
    }

    function updateActiveRow() {
      rows.forEach(function (row, i) {
        var isActive = i === activeIndex;
        row.classList.toggle("extuiActive", isActive);
        if (isActive) row.setAttribute("aria-current", "true");
        else row.removeAttribute("aria-current");
      });
      if (activeIndex >= 0) {
        searchInput.setAttribute("aria-activedescendant", rows[activeIndex].id);
        rows[activeIndex].scrollIntoView({ block: "nearest" });
      } else {
        searchInput.removeAttribute("aria-activedescendant");
      }
    }

    function activateRow(row) {
      var kind = row.getAttribute("data-kind");
      var id = row.getAttribute("data-id");
      if (kind === "section") {
        openSection(id);
      } else if (kind === "entity") {
        var section = row.getAttribute("data-section") || "home";
        var entityType = row.getAttribute("data-entity-type") || "";
        var contactId = row.getAttribute("data-contact-id") || "";
        closeSearch();
        showSection(section).then(function(){
          if ((entityType === "crm-contact" || entityType === "crm-note" || entityType === "crm-task") && contactId && typeof window.__extCrmOpenContactProfile === "function") {
            window.__extCrmOpenContactProfile(contactId, "timeline");
          }
        });
      } else if (kind === "action") {
        var action = SHELL_ACTIONS.filter(function (a) { return a.id === id; })[0];
        if (!action) return;
                                                                          
                                                                           
                                                                             
                                                              
        if (action.section) {
          closeSearch();
          showSection(action.section).then(function () {
            if (!action.selector) return;
            var target = contentArea.querySelector(action.selector);
            if (!target) return;
            if (action.activate && typeof target.click === "function") target.click();
            else if (typeof target.focus === "function") target.focus({ preventScroll: false });
            if (typeof target.scrollIntoView === "function") target.scrollIntoView({ block: "center", behavior: "smooth" });
          });
          return;
        }
        var target = document.getElementById(action.targetId);
        if (target) target.click();
        closeSearch();
      }
    }

    function openSection(name) {
      recordRecent(name);
      closeSearch();
      showSection(name);
    }
    function openSearch() {
      previouslyFocused = document.activeElement;
      searchOverlay.style.display = "flex";
      searchOverlay.setAttribute("aria-hidden", "false");
      searchBtn.setAttribute("aria-expanded", "true");
      searchInput.setAttribute("aria-expanded", "true");
      searchInput.value = "";
      loadRecents(function (recents) {
        recentsCache = recents;
        refreshUniversalIndex(function(){ renderResults(""); });
      });
      searchInput.focus();
    }
    function closeSearch() {
      searchOverlay.style.display = "none";
      searchOverlay.setAttribute("aria-hidden", "true");
      searchBtn.setAttribute("aria-expanded", "false");
      searchInput.setAttribute("aria-expanded", "false");
      if (previouslyFocused && document.contains(previouslyFocused) && typeof previouslyFocused.focus === "function") {
        previouslyFocused.focus();
      }
      previouslyFocused = null;
    }
    searchBtn.addEventListener("click", openSearch);
    searchOverlay.addEventListener("click", function (ev) { if (ev.target === searchOverlay) closeSearch(); });
    searchInput.addEventListener("input", function () { renderResults(searchInput.value); });
    document.addEventListener("keydown", function (ev) {
                                                                           
                                                                       
                                                                  
                                                                         
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "k") {
        ev.preventDefault();
        if (searchOverlay.style.display === "flex") closeSearch(); else openSearch();
        return;
      }
      if (searchOverlay.style.display !== "flex") return;
      if (ev.key === "Escape") { ev.preventDefault(); closeSearch(); return; }
      if (ev.key === "Tab") { ev.preventDefault(); searchInput.focus(); return; }
      if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
        ev.preventDefault();
        if (!rows.length) return;
        activeIndex = ev.key === "ArrowDown" ? Math.min(activeIndex + 1, rows.length - 1) : Math.max(activeIndex - 1, 0);
        updateActiveRow();
      } else if (ev.key === "Enter") {
        if (typeof window.__extTryCheatCode === "function" && window.__extTryCheatCode(searchInput.value)) {
          ev.preventDefault();
          closeSearch();
          searchInput.value = "";
          return;
        }
        if (activeIndex >= 0 && rows[activeIndex]) activateRow(rows[activeIndex]);
      }
    });

    refreshUniversalIndex();
    window.__extOpenUniversalSearch = openSearch;
    try {
      var universalRefreshTimer = null;
      chrome.storage.onChanged.addListener(function (changes, areaName) {
        if (areaName !== "local" || !changes) return;
        var watched = UNIVERSAL_KEYS.concat([FAVORITES_KEY]);
        var relevant = watched.some(function (key) { return Object.prototype.hasOwnProperty.call(changes, key); });
        if (!relevant) return;
        clearTimeout(universalRefreshTimer);
        universalRefreshTimer = setTimeout(function () { refreshUniversalIndex(function () { if (searchOverlay.style.display === "flex") renderResults(searchInput.value); }); }, 90);
      });
    } catch (_) {}

    settingsBtn.addEventListener("click", function () { showSection("ajustes"); });

    themeBtn.addEventListener("click", function () {
      try {
        chrome.storage.local.get("EXTUI:extappOptionsStore", function (res) {
          var raw = res && res["EXTUI:extappOptionsStore"];
          var opts = extParseOptionsRaw(raw) || {};
          if (window.__extThemeSystem) {
            opts = window.__extThemeSystem.normalize(opts);
            opts.mode = window.__extThemeSystem.resolvedMode(opts) === "light" ? "dark" : "light";
            opts = window.__extThemeSystem.withDefinition(opts);
          } else {
            opts.mode = opts.mode === "light" ? "dark" : "light";
          }
          extApplyThemeVars(opts);
          function announce(saved){try{document.dispatchEvent(new CustomEvent("ext:appearance-updated",{detail:saved||opts}));}catch(_){}}
          if(window.__extThemeSystem&&window.__extThemeSystem.save)window.__extThemeSystem.save(opts).then(announce).catch(function(){dashboardToast("Não foi possível salvar o tema.",true);});else storageSetSafe({ "EXTUI:extappOptionsStore": opts }).then(function(){announce(opts);}).catch(function(){dashboardToast("Não foi possível salvar o tema.",true);});
        });
      } catch (err) { }
    });
  })();

                                                                           
                                                                           
                                                                       
                                                                   
                                                                         
                                              
                                                                     
                                                                       
                                                                            
                                                               
                                                                           
                                                                           
                                                                           
                                                                        
                                                                           
                                                                            
                                                                          
                                           
                                                                           
  function onStorageKeyChange(key, handler) {
    if (!window.ExtensionStorage || typeof window.ExtensionStorage.subscribe !== "function") return function () {};
    return window.ExtensionStorage.subscribe(key, function (newValue) {
      try { handler(newValue); } catch (err) { }
    });
  }

                                                 
                                                                           
                                                                           
                                                                        
                                                                          
                                                                           
                                                                           
                                                                         
                                                                         
                                                                    
  var wppRuntimeState = "initializing";
  var wppTabAvailable = null;
  window.__extSetWppStatus = function (state) {
    wppRuntimeState = state || "initializing";
    var effectiveState = wppTabAvailable === false ? "unavailable" : (wppTabAvailable === null ? "initializing" : wppRuntimeState);
    var dot = document.getElementById("extappWppStatus");
    var health = document.getElementById("extappWppHealth");
    var stateText = document.getElementById("extappWppStatusText");
    var help = document.getElementById("extappWppHealthHelp");
    if (!dot) return;
                                                                        
                                                                           
                                    
    dot.classList.remove("extuiStatusDot--ok", "extuiStatusDot--error");
    if (health) health.classList.toggle("extappWppHealth--attention", effectiveState === "unavailable");
    if (effectiveState === "ready") {
      dot.classList.add("extuiStatusDot--ok");
      if (stateText) stateText.textContent = "Conectado";
      if (help) help.hidden = true;
      if (health) health.title = "WhatsApp Web encontrado e pronto para uso";
    } else if (effectiveState === "unavailable") {
      dot.classList.add("extuiStatusDot--error");
      if (stateText) stateText.textContent = "Requer atenção";
      if (help) help.hidden = false;
      if (health) health.title = "Abra ou recarregue o WhatsApp Web";
    } else {
      if (stateText) stateText.textContent = "Verificando";
      if (help) help.hidden = true;
      if (health) health.title = "Verificando a conexão com o WhatsApp";
    }
  };
  window.__extSetWppStatus("initializing");
  (function loadWppStatus() {
                                                                            
                                                                   
    try {
      chrome.storage.local.get("EXTUI:wppStatus", function (res) {
        var state = res && res["EXTUI:wppStatus"];
        if (state) window.__extSetWppStatus(state);
      });
    } catch (err) { }
                                                                      
                                                                           
                                                    
    onStorageKeyChange("EXTUI:wppStatus", function (newValue) { window.__extSetWppStatus(newValue); });
    function refreshWppTabAvailability() {
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        wppTabAvailable = !!(tabs && tabs.length);
        window.__extSetWppStatus(wppRuntimeState);
      });
    }
    refreshWppTabAvailability();
    if (chrome.tabs && chrome.tabs.onCreated) chrome.tabs.onCreated.addListener(refreshWppTabAvailability);
    if (chrome.tabs && chrome.tabs.onRemoved) chrome.tabs.onRemoved.addListener(refreshWppTabAvailability);
    if (chrome.tabs && chrome.tabs.onUpdated) chrome.tabs.onUpdated.addListener(function (tabId, changeInfo) { if (changeInfo.url || changeInfo.status) refreshWppTabAvailability(); });
  })();

                                                                           
                                                                        
                                                                           
                                                                   
                                                                         
                                                                   
                                                                         
                                                                           
                                                                           
  (function setupNavBadges() {
    var NAV_ITEM_BY_SECTION = {};
    SIDEBAR_NAV_ITEMS.forEach(function (item) { NAV_ITEM_BY_SECTION[item.section] = item; });

                                                                           
                                                                          
                                                               
    function parsePlain(raw) {
      if (!raw) return null;
      try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (err) { return null; }
    }
    function parsePersistedState(raw) {
      var parsed = parsePlain(raw);
      return (parsed && parsed.state) ? parsed.state : null;
    }
    function numberBadgeOrNull(n) { return n > 0 ? { type: "number", value: n } : null; }

    var BADGE_SUFFIX = {
      agenda: function (badge) { return badge.value === 1 ? "1 agendamento pendente" : badge.value + " agendamentos pendentes"; },
      disparos: function (badge) { return badge.value === 1 ? "1 envio na fila" : badge.value + " envios na fila"; },
      fluxos: function () { return "há automação aguardando intervenção humana"; },
      funis: function () { return "há automação com erro"; }
    };

    var BADGE_COMPUTE = {
      agenda: function (raw) {
        var state = parsePlain(raw);
        var list = (state && Array.isArray(state.list)) ? state.list : [];
        return numberBadgeOrNull(list.filter(function (i) { return i && i.status === "scheduled"; }).length);
      },
      disparos: function (raw) {
        var list = Array.isArray(raw) ? raw : [];
        return numberBadgeOrNull(list.filter(function (e) { return e && (e.state === "queued" || e.state === "sending"); }).length);
      },
      fluxos: function (raw) {
        var state = parsePersistedState(raw);
        var list = (state && Array.isArray(state.runningList)) ? state.runningList : [];
                                                                              
                                
        var hasNeedsHuman = list.some(function (r) { return r && r.status === "needsHuman"; });
        return hasNeedsHuman ? { type: "dot", tone: "warn" } : null;
      },
      funis: function (raw) {
        var state = parsePersistedState(raw);
        var list = (state && Array.isArray(state.runningList)) ? state.runningList : [];
        var hasError = list.some(function (r) { return r && r.status === "error"; });
        return hasError ? { type: "dot", tone: "danger" } : null;
      }
    };

    var SECTION_TO_KEY = {
      agenda: "EXTUI:extappScheduleStore",
      disparos: "ext:bulkQueue",
      fluxos: "EXTUI:extappFlowRunningStore",
      funis: "EXTUI:extappFunnelRunningStore"
    };

                                                                            
                                                                            
                                       
    var lastApplied = {};
    function badgeSignature(badge) {
      if (!badge) return "none";
      return badge.type === "number" ? "number:" + badge.value : "dot:" + badge.tone;
    }

    function applyBadge(section, badge) {
      var sig = badgeSignature(badge);
      if (lastApplied[section] === sig) return;
      lastApplied[section] = sig;

      var btn = document.querySelector('#extappSidebarNav .navItem[data-section="' + section + '"]');
      if (!btn) return;
      var slot = btn.querySelector(".navBadge");
      var navItem = NAV_ITEM_BY_SECTION[section];
      if (!slot || !navItem) return;

      var suffix = "";
      if (badge && badge.type === "number") {
        slot.className = "navBadge navBadge--num";
        slot.textContent = badge.value > 9 ? "9+" : String(badge.value);
        slot.style.display = "";
        if (BADGE_SUFFIX[section]) suffix = BADGE_SUFFIX[section](badge);
      } else if (badge && badge.type === "dot") {
        slot.className = "navBadge navBadge--dot navBadge--" + badge.tone;
        slot.textContent = "";
        slot.style.display = "";
        if (BADGE_SUFFIX[section]) suffix = BADGE_SUFFIX[section](badge);
      } else {
        slot.className = "navBadge";
        slot.textContent = "";
        slot.style.display = "none";
      }
                                                                            
                                                                     
                                                                       
                                                                         
      btn.setAttribute("aria-label", suffix ? (navItem.label + ", " + suffix) : navItem.label);
    }

    Object.keys(SECTION_TO_KEY).forEach(function (section) {
      var key = SECTION_TO_KEY[section];
      var compute = BADGE_COMPUTE[section];
      try {
        chrome.storage.local.get(key, function (res) {
          try { applyBadge(section, compute(res && res[key])); }
          catch (err) { }
        });
      } catch (err) {
      }
      onStorageKeyChange(key, function (newValue) {
        try { applyBadge(section, compute(newValue)); }
        catch (err) { }
      });
    });
  })();

                                             
                                                                        
                                                                               
  function updatePlanTag(license) {
    var tag = document.getElementById("extappPlanTag");
    if (!tag) return;
    if (!license || !license.authenticated) { tag.textContent = ""; return; }
    tag.textContent = license.planName || (license.plan_id ? "Plano ativo" : "Conta");
  }
  (function loadPlanTag() {
    var tag = document.getElementById("extappPlanTag");
    if (!tag) return;
                                                                      
                                                                      
                                                               
                                                                             
    try {
      chrome.storage.local.get("EXTUI:license", function (res) {
        var license = res && res["EXTUI:license"];
        updatePlanTag(license);
      });
    } catch (err) { }
  })();

  var EXTUI_FREE_SECTIONS=new Set(["home","itens-message","itens-audio","itens-image","itens-video","itens-media","itens-document","agenda","personalizacao","ajustes","academy","atividades"]);
  var EXTUI_PLAN_URL=window.__extRuntimeConfig.backendUrl("/planos");
  function extDashboardPlanState(){return new Promise(function(resolve){try{chrome.runtime.sendMessage({type:"EXTUI_PLAN_STATE"},function(res){if(chrome.runtime.lastError||!res||res.ok!==true||!res.result){resolve({kind:"locked",isFree:false,isPaid:false,locked:true,license:{}});return;}var p=res.result,kind=p.kind==="free"||p.kind==="paid"?p.kind:"locked";resolve({kind:kind,isFree:kind==="free",isPaid:kind==="paid",locked:kind==="locked",license:p.license&&typeof p.license==="object"?p.license:{}});});}catch(_){resolve({kind:"locked",isFree:false,isPaid:false,locked:true,license:{}});}});}
  function extDashboardFreeAllows(name){return EXTUI_FREE_SECTIONS.has(String(name||""));}
  function extDashboardApplyPlanNav(plan){window.__extCurrentPlanKind=plan&&plan.isPaid===true?"paid":plan&&plan.isFree===true?"free":"locked";var isPaid=!!(plan&&plan.isPaid===true),isFree=!!(plan&&plan.isFree===true);document.querySelectorAll("#extappSidebarNav [data-section], .extappContextTab[data-section]").forEach(function(btn){var section=btn.getAttribute("data-section")||"",locked=!isPaid&&(!isFree||!extDashboardFreeAllows(section));btn.toggleAttribute("data-plan-locked",locked);var chip=btn.querySelector(".extuiPlanProChip");if(locked&&!chip){chip=document.createElement("span");chip.className="extuiPlanProChip";chip.textContent="PRO";btn.appendChild(chip);}else if(!locked&&chip)chip.remove();});}
  function extDashboardPlanUsage(action,itemType,scheduledItems){return new Promise(function(resolve,reject){try{chrome.runtime.sendMessage({type:"EXTUI_PLAN_USAGE",action:action||"check",itemType:itemType,scheduledItems:scheduledItems},function(res){if(chrome.runtime.lastError){var e=new Error("Não foi possível validar o plano gratuito.");e.code="EXTAPP_FREE_QUOTA_UNAVAILABLE";reject(e);return;}if(!res||res.ok!==true){var er=new Error(res&&res.userMessage||"Não foi possível validar o plano gratuito.");er.code=res&&res.errorCode||"EXTAPP_FREE_QUOTA_UNAVAILABLE";reject(er);return;}resolve(res.result||{});});}catch(err){reject(err);}});}
  async function extDashboardRequireScheduleCapacity(currentCount){var plan=await extDashboardPlanState();if(plan.isPaid)return null;if(!plan.isFree){var le=new Error("Sua sessão precisa ser validada novamente.");le.code="LICENSE_REQUIRED";throw le;}var result=await extDashboardPlanUsage("check","scheduleItem",currentCount),row=result&&result.limits&&result.limits.scheduleItem;if(!row||typeof row.max!=="number"){var u=new Error("Não foi possível confirmar o limite de agendamentos.");u.code="EXTAPP_FREE_QUOTA_UNAVAILABLE";throw u;}if(row.max===0||row.max>0&&Math.max(Number(row.sent||0),Number(currentCount||0))>=row.max){var e=new Error("O plano gratuito permite até "+row.max+" agendamentos ativos.");e.code="EXTAPP_FREE_LIMIT_REACHED";throw e;}return row;}
  async function extDashboardRequirePaid(label,section){var plan=await extDashboardPlanState();if(!plan.isPaid){if(plan.isFree&&section)extDashboardRenderPlanPaywall(section);var e=new Error(plan.isFree?(label||"Este recurso")+" faz parte do plano Pro da extensão.":"Sua sessão precisa ser validada novamente.");e.code=plan.isFree?"EXTAPP_PLAN_UPGRADE_REQUIRED":"LICENSE_REQUIRED";throw e;}return await new Promise(function(resolve,reject){try{chrome.runtime.sendMessage({type:"EXTUI_PLAN_REQUIRE",feature:String(label||section||"premium").slice(0,120)},function(res){if(chrome.runtime.lastError){var er=new Error("Não foi possível confirmar a autorização segura deste recurso.");er.code="SERVER_AUTHORITY_UNAVAILABLE";reject(er);return;}if(!res||res.ok!==true){var e2=new Error(res&&res.userMessage||"Não foi possível autorizar este recurso.");e2.code=res&&res.errorCode||"LICENSE_REQUIRED";reject(e2);return;}resolve(true);});}catch(err){reject(err);}});}
  function extDashboardRenderPlanPaywall(name){
    hideFallbackSurface();
    currentSectionName=name;
    lastAuthorizedSection=name;
    if(!contentArea)return{ok:false,section:name,reason:"plan-upgrade-required"};
    contentArea.innerHTML="";
    contentArea.setAttribute("data-extui-dashboard-section",name);
    var meta=DASHBOARD_VISUAL_META[name]||{},nav=SIDEBAR_NAV_ITEMS.find(function(x){return x.section===name;})||{},label=nav.label||meta.label||"Recurso Pro";
    function safeHtml(value){return String(value==null?"":value).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
    var wrap=document.createElement("section");
    wrap.className="extuiPlanPaywall";
    wrap.innerHTML='<div class="extuiPlanPaywallBadge">PLANO GRATUITO</div><div class="extuiPlanPaywallOrb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 2 3 6 6 .9-4.5 4.4 1.1 6.2L12 16.6 6.4 19.5l1.1-6.2L3 8.9 9 8z"/></svg></div><h1>'+safeHtml(label)+' é um recurso Pro</h1><p>O plano gratuito foi feito para você experimentar a base da extensão. Faça upgrade para liberar automações, CRM, produtividade avançada e integrações sem as limitações do modo gratuito.</p><div class="extuiPlanPaywallGrid"><article><strong>Automação completa</strong><span>Fluxos, Funis, FollowUp e Autoatendimento.</span></article><article><strong>Gestão comercial</strong><span>CRM, Encomendas, exportações e ferramentas avançadas.</span></article><article><strong>Ecossistema</strong><span>Assistentes IA, Webhooks, integrações e Backup.</span></article><article><strong>Mais produtividade</strong><span>Respostas Rápidas e recursos premium da Biblioteca.</span></article></div><div class="extuiPlanPaywallActions"><button type="button" class="extui-btn extui-btn--ghost" data-free-home>Voltar ao início</button><button type="button" class="extui-btn extui-btn--primary" data-upgrade>Conhecer plano Pro</button></div>';
    contentArea.appendChild(wrap);
    wrap.querySelector("[data-free-home]").addEventListener("click",function(){showSection("home",{force:true});});
    wrap.querySelector("[data-upgrade]").addEventListener("click",function(){chrome.tabs.create({url:EXTUI_PLAN_URL});});
    var routeCtx=dashboardRouteContext(name),navHost=document.getElementById("extappSidebarNav");
    if(navHost&&navHost._extuiExpandGroupForSection)navHost._extuiExpandGroupForSection(name);
    currentNavButtons().forEach(function(btn){var active=btn.getAttribute("data-section")===(routeCtx.parent||name);btn.classList.toggle("active",active);if(active)btn.setAttribute("aria-current","page");else btn.removeAttribute("aria-current");});
    ensureAccessibleControls(contentArea);
    notifySectionState("change",name);
    return{ok:false,section:name,reason:"plan-upgrade-required"};
  }

  window.__extPlanGate=Object.freeze({state:extDashboardPlanState,allowsSection:extDashboardFreeAllows,applyNav:extDashboardApplyPlanNav,requirePaid:extDashboardRequirePaid,usage:extDashboardPlanUsage,requireScheduleCapacity:extDashboardRequireScheduleCapacity});

  function _x6() {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(_x5, function (res) {
          if (chrome.runtime && chrome.runtime.lastError) { reject(chrome.runtime.lastError); return; }
          resolve(res && res[_x5]);
        });
      } catch (err) { reject(err); }
    });
  }

  extDashboardPlanState().then(extDashboardApplyPlanNav).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_PLAN_NAV_SYNC_FAILED",err);});
  try{chrome.storage.onChanged.addListener(function(changes,area){if(area!=="local"||!changes["EXTUI:license"])return;extDashboardPlanState().then(extDashboardApplyPlanNav).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_PLAN_NAV_SYNC_FAILED",err);});});}catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_PLAN_NAV_LISTENER_FAILED",err);}

  function openWhatsAppForAccess() {
    try {
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        if (chrome.runtime && chrome.runtime.lastError) return;
        if (tabs && tabs[0]) {
          chrome.tabs.update(tabs[0].id, { active: true });
          if (tabs[0].windowId != null && chrome.windows && chrome.windows.update) chrome.windows.update(tabs[0].windowId, { focused: true });
          return;
        }
        chrome.tabs.create({ url: "https://web.whatsapp.com/", active: true });
      });
    } catch (err) { }
  }

  function clearPrivateSurface() {
    if (currentSectionName) lastAuthorizedSection = currentSectionName;
    currentSectionName = null;
    if (contentArea) {
      contentArea.innerHTML = "";
      contentArea.removeAttribute("data-extui-dashboard-section");
      contentArea.classList.remove("extuiHidden");
    }
    currentNavButtons().forEach(function (btn) { btn.classList.remove("active"); });
    var searchOverlay = document.getElementById("extappSearchOverlay");
    if (searchOverlay) searchOverlay.style.display = "none";
    var searchButton = document.getElementById("extappTopbarSearchBtn");
    if (searchButton) searchButton.setAttribute("aria-expanded", "false");
  }

  function _x9(snapshot) {
    var state = snapshot && snapshot.state ? snapshot.state : (_x0 ? _x0.STATES.LOCKED : "LOCKED");
    var previousState = _x2;
    var authorized = !!(_x0 && state === _x0.STATES.AUTHORIZED);
    var checking = !!(_x0 && state === _x0.STATES.CHECKING_AUTH);
    _x2 = state;

    document.body.setAttribute("data-extui-access-state", authorized ? "authorized" : (checking ? "checking" : "locked"));
    var privateApp = document.getElementById("extappPrivateApp");
    if (privateApp) {
      privateApp.toggleAttribute("inert", !authorized);
      privateApp.setAttribute("aria-hidden", String(!authorized));
    }
    var gate = document.getElementById("extappAccessGate");
    var checkingView = document.getElementById("extappAccessChecking");
    var lockedView = document.getElementById("extappAccessLocked");
    if (gate) gate.setAttribute("aria-busy", String(checking));
    if (checkingView) checkingView.hidden = !checking;
    if (lockedView) lockedView.hidden = authorized || checking;

    if (!authorized && !checking) {
      clearPrivateSurface();
      var reason = snapshot && snapshot.reason || "access-denied";
      var title = document.getElementById("extappAccessLockedTitle");
      var description = document.getElementById("extappAccessLockedDescription");
      var isValidationProblem = reason === "validationUnavailable" || reason === "access-check-failed" || reason === "accessCheckFailed" || reason === "LICENSE_VALIDATION_UNAVAILABLE" || reason === "SERVER_AUTHORITY_UNAVAILABLE";
      var isMissing = reason === "missingSession" || reason === "access-denied" || reason === "credentials-removed" || reason === "access-service-unavailable";
      var isExpired = reason === "expired" || reason === "inactive" || reason === "forceLogout" || reason === "licenseTamperOrRevoked";
      if (title) title.textContent = isValidationProblem ? "Não foi possível validar sua sessão" : (isExpired ? "Sessão inválida ou expirada" : (isMissing ? "Acesso não ativado" : "Acesso negado"));
      if (description) description.textContent = isValidationProblem
        ? "O Painel de Controle permanece bloqueado até que a sessão existente seja validada. Abra o WhatsApp Web e tente novamente."
        : (isExpired ? "A sessão atual não autoriza o Painel de Controle. Reative ou valide a extensão pela tela segura dentro do WhatsApp Web." : "O Painel de Controle só é liberado depois que a extensão é ativada e validada dentro do WhatsApp Web.");
      var loginPanel = document.getElementById("extappAccessLoginPanel");
      var recoveryActions = document.getElementById("extappAccessRecoveryActions");
      if (loginPanel) loginPanel.hidden = true;
      if (recoveryActions) recoveryActions.hidden = false;
      if (previousState !== state) {
        var focusTarget = document.getElementById("extappAccessRecoveryWhatsApp") || document.getElementById("extappAccessRetry");
        if (focusTarget) setTimeout(function () { focusTarget.focus(); }, 0);
      }
    }

    function emitAccessState() {
      try {
        window.dispatchEvent(new CustomEvent("ext:access-state", { detail: { state: state, reason: snapshot && snapshot.reason || "" } }));
      } catch (err) {                                                          }
    }

    if (authorized && previousState !== state) {
      function knownSection(sectionName) {
        if (sectionName && typeof sections[sectionName] === "function") return true;
        var loader = window.__extDashboardLazyLoader;
        return !!(sectionName && loader && typeof loader.canLoad === "function" && loader.canLoad(sectionName));
      }
      var target = currentSectionName && knownSection(currentSectionName)
        ? currentSectionName
        : (lastAuthorizedSection && knownSection(lastAuthorizedSection) ? lastAuthorizedSection : (knownSection(accessRequestedSection) ? accessRequestedSection : "home"));
      Promise.resolve(showSection(target)).then(emitAccessState, emitAccessState);
    } else emitAccessState();
  }

  function _x8() {
    var recoveryWhatsAppButton = document.getElementById("extappAccessRecoveryWhatsApp");
    var retryButton = document.getElementById("extappAccessRetry");
    if (recoveryWhatsAppButton) recoveryWhatsAppButton.addEventListener("click", openWhatsAppForAccess);

    if (!_x0 || !window.__extS0 || typeof window.__extS0._p !== "function") {
      _x9({ state: _x0 ? _x0.STATES.LOCKED : "LOCKED", reason: "access-service-unavailable" });
      return;
    }

    _x1 = _x0._g1({
      resolveAccess: function () { return window.__extS0._p(); },
      onStateChange: _x9
    });

    Object.defineProperty(window, "__extG1", {
      value: Object.freeze({
        STATES: _x0.STATES,
        _a: _x3,
        _s: function () { return _x2; },
        _r: function () { return _x6().then(function (license) { return _x1.check(license, "manual-retry"); }); }
      }),
      enumerable: false,
      configurable: false,
      writable: false
    });
    if (retryButton) retryButton.addEventListener("click", function () { window.__extG1._r(); });

    var observedKey = null;
    function _x7(license, reason) {
      updatePlanTag(license);
      var valid = _x0._g0(license);
      var nextKey = valid ? String(license.keyId || license.keyHint || "credential") : null;
      var previousKey = observedKey;
      observedKey = nextKey;
      if (!valid) {
        _x1.applyLicense(null, reason || "credentials-removed");
        return;
      }
                                                                         
                                                                         
                                      
      if (previousKey !== nextKey || _x2 === _x0.STATES.LOCKED) {
        _x1.applyLicense(license, reason || "credentials-changed");
      }
    }

    onStorageKeyChange(_x5, function (newValue) { _x7(newValue, "license-storage-change"); });
    window.addEventListener("extui-s0-state", function (ev) {
      var detail = ev.detail || {};
      if (detail.state === "forceLogout" || detail.state === "logout") _x1.lock(detail.state);
      else if (detail.state === "validationUnavailable") _x1.lock("validationUnavailable");
      else if ((detail.state === "restored" || detail.state === "offlineGrace") && _x2 === _x0.STATES.LOCKED) {
        _x6().then(function (license) {
          if (_x2 !== _x0.STATES.LOCKED) return;
          _x1.check(license, detail.state);
        });
      }
    });

    _x6().then(function (license) {
      observedKey = _x0._g0(license) ? String(license.keyId || license.keyHint || "credential") : null;
      return _x1.check(license, "boot");
    }).catch(function () {
      _x1.lock("license-storage-error");
    });
  }

                                                                           
                                                                        
                                                               
  document.addEventListener("DOMContentLoaded", _x8);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
