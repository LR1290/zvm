;
try{
(function () {
  "use strict";

  if (window.__extAcademyModuleBooted) return;
  window.__extAcademyModuleBooted = true;

  var STORAGE_KEY = "EXTUI:onboardingState";
  var ACADEMY_VERSION = 5;
  var LESSON_IDS = ["sidebar-whatsapp", "painel-controle", "biblioteca-completa", "respostas-rapidas", "crm-analise-encomendas", "fluxos-funis", "laboratorio", "followup-agenda", "disparos-seguranca", "status", "assistentes-ia", "exportacao-integracoes", "personalizacao-ajustes-backup"];
  var activeCenter = null;
  var activeGuide = null;
  var activeConnectionPrompt = null;
  var stateWrite = Promise.resolve();
  var academyMachine = null;
  var WHATSAPP_MESSAGE_WAIT_MS = 5000;
  var WHATSAPP_RELOAD_WAIT_MS = 12000;
  var DASHBOARD_TARGET_WAIT_MS = 6500;

  function routeSelector(section) { return '#extappContentArea[data-extui-dashboard-section="' + section + '"]'; }
  function step(id, section, selector, title, description, doNow, expect, tip, warning, options) {
    return Object.assign({ id: id, section: section, selector: selector || routeSelector(section), title: title, description: description, doNow: doNow, expect: expect, tip: tip || "", warning: warning || "" }, options || {});
  }
  function waStep(id, panel, title) { return { id: id, context: "whatsapp", panel: panel || null, title: title }; }

  var LESSONS = [
    {
      id: "sidebar-whatsapp", number: "01", title: "Menu lateral do WhatsApp, botão por botão", duration: "8 min",
      description: "Percorra cada atalho do menu lateral, entenda o que ele abre e quando usar o painel rápido sem sair da conversa.", context: "whatsapp",
      steps: [
        waStep("sidebar-logo", null, "Painel de Controle"), waStep("sidebar-items", "items", "Itens"), waStep("sidebar-crm", "crm", "CRM"), waStep("sidebar-crm-funnel", "crm-funnel", "Funil CRM"),
        waStep("sidebar-orders", "encomendas", "Encomendas"), waStep("sidebar-activity", "envios", "Envios"), waStep("sidebar-broadcast", "disparos", "Disparo em massa"), waStep("sidebar-flow", "fluxos", "Fluxos"),
        waStep("sidebar-funnel", "funis", "Funis"), waStep("sidebar-quick-response", "resposta-rapida", "Respostas Rápidas"), waStep("sidebar-followup", "followup", "FollowUp"), waStep("sidebar-auto-service", "autoatendimento", "Autoatendimento"),
        waStep("sidebar-status", "status", "Status"), waStep("sidebar-tools", "ferramentas", "Ferramentas"), waStep("sidebar-google", "google", "Google"), waStep("sidebar-export", null, "Exportar Contatos"),
        waStep("sidebar-agenda", "agenda", "Agenda"), waStep("sidebar-notifications", "notificacoes", "Notificações"), waStep("sidebar-system", "sistema", "Sistema")
      ]
    },
    {
      id: "painel-controle", number: "02", title: "Painel de Controle, seção por seção", duration: "7 min",
      description: "Aprenda a se localizar no Painel de Controle, usar a busca, acompanhar a conexão com o WhatsApp e voltar aos Tutoriais sem perder o contexto.",
      steps: [
        step("home", "home", '[data-extui-academy-target="home-overview"]', "Início é o mapa da operação", "A tela inicial resume atalhos e estados importantes sem exigir que você memorize onde cada recurso fica.", "Observe os blocos do Início e identifique a área que deseja administrar.", "O caminho no topo e o menu lateral continuam visíveis enquanto o conteúdo muda no centro.", "Use o Início para ter uma visão rápida antes de entrar em uma área específica."),
        step("global-search", "home", "#extappTopbarSearchBtn", "Busca rápida do Painel", "A busca do topo encontra áreas e ações sem você precisar percorrer todo o menu.", "Localize o campo Buscar uma seção ou ação. Você também pode usar Ctrl + K.", "A busca deve abrir por cima do conteúdo atual e mostrar resultados agrupados conforme você digita.", "Quando souber o nome do que procura, a busca costuma ser o caminho mais rápido."),
        step("whatsapp-health", "home", "#extappWppHealth", "Estado da conexão com o WhatsApp", "O indicador no topo mostra se o Painel de Controle está conseguindo conversar com a aba do WhatsApp Web.", "Confira o estado ao lado da palavra WhatsApp.", "Quando estiver conectado, as ações que dependem do WhatsApp podem ser usadas normalmente; quando houver problema, a própria área deve orientar a abrir ou recarregar o WhatsApp.", "Antes de investigar uma função que parece não responder, confira este indicador."),
        step("navigation", "home", "#extappSidebarNav", "O menu lateral organiza as áreas", "As funções estão agrupadas por assunto para reduzir a quantidade de opções visíveis de uma vez.", "Passe pelos grupos Principal, Comunicação, Automação, Clientes, Sistema e Aprendizado.", "O botão da área atual deve permanecer destacado enquanto o conteúdo correspondente aparece no centro.", "Use os grupos para entender onde cada tipo de tarefa fica, em vez de decorar posições."),
        step("workspace", "home", '[data-tab="workspace"]', "Modelos adaptam a experiência", "Na Central você pode combinar modelos por segmento e deixar cada pacote criar os conteúdos operacionais recomendados. O modo focado organiza o menu sem excluir dados ou recursos.", "Abra a aba Modelos e observe os modelos disponíveis.", "Você pode selecionar mais de um modelo e voltar para a extensão completa quando quiser.", "Use o modo focado apenas quando quiser reduzir visualmente o menu."),
        step("activity-center", "atividades", '[data-extui-academy-target="activity-center"]', "Central de Atividades", "O sininho reúne avisos operacionais importantes de diferentes áreas da extensão, como encomendas atrasadas e tarefas CRM pendentes.", "Abra Atividades e observe não lidas, itens que requerem atenção e histórico.", "Ler ou limpar a Central não deve alterar a encomenda, CRM ou automação que originou o aviso.", "Use o botão Abrir para ir à área responsável pelo evento."),
        step("academy", "academy", routeSelector("academy") + " .extuiaLessonList", "Tutoriais ficam sempre disponíveis", "A Central salva seu progresso e permite começar, continuar ou refazer qualquer assunto.", "Use a busca dos Tutoriais ou escolha a função que deseja aprender.", "A lista deve filtrar os assuntos sem apagar o progresso e sem executar ações da extensão automaticamente.", "Os Tutoriais seguem a sequência 01–13 para que cada etapa prepare a próxima.")
      ]
    },
    {
      id: "biblioteca-completa", number: "03", title: "Biblioteca completa", duration: "7 min",
      description: "Passe por mensagens, áudios, imagens, vídeos, figurinhas, documentos, PIX e contatos, entendendo o papel de cada item reutilizável.",
      steps: [
        step("messages", "itens-message", '[data-extui-academy-target="items-library"]', "Mensagens salvas", "Mensagens são blocos reutilizáveis para atendimento, automações e agendamentos.", "Revise a lista e use o botão de novo item apenas para abrir o formulário.", "A biblioteca deve permanecer visível enquanto o editor é aberto, sem salvar nada até sua confirmação.", "Use nomes claros para encontrar o conteúdo depois em Fluxos, Funis, Agenda e Disparos."),
        step("new-message", "itens-message", '[data-extui-academy-target="items-new-message"]', "Criar uma mensagem", "Abrir o formulário é seguro: o conteúdo só entra na Biblioteca depois de salvar.", "Clique em Novo item/Nova mensagem e observe os campos disponíveis.", "O formulário deve abrir dentro da mesma área e a etapa será reconhecida após o clique.", "Você pode fechar o editor sem salvar para continuar o tutorial.", "Não confirme um conteúdo de teste se não quiser mantê-lo.", { actionRequired: true }),
        step("audio", "itens-audio", ".extuiItensPage--audio .extuiItensPageHeading", "Áudios", "A área de Áudios concentra os arquivos reutilizáveis que podem ser enviados em conversas e automações.", "Observe cadastro, lista e ações disponíveis para um áudio.", "A aba Áudios deve estar selecionada e nenhuma outra categoria deve aparecer como ativa.", "Dê nomes que indiquem claramente o conteúdo ou objetivo do áudio."),
        step("images", "itens-image", ".extuiItensPage--image .extuiItensPageHeading", "Imagens", "Imagens reúne arquivos visuais salvos para reutilização.", "Confira cadastro, busca e prévia das imagens.", "A navegação deve permanecer na aba Imagens e o conteúdo deve caber sem cortes laterais.", "Use a prévia para conferir imagem e legenda antes de reutilizá-las."),
        step("videos", "itens-video", ".extuiItensPage--video .extuiItensPageHeading", "Vídeos", "Vídeos reúne arquivos de vídeo reutilizáveis e seus modos de envio.", "Confira cadastro, busca e prévia dos vídeos.", "A navegação deve permanecer na aba Vídeos e o conteúdo deve caber sem cortes laterais.", "Confira legenda, visualização única e vídeo recado antes de salvar."),
        step("stickers", "itens-sticker", ".extuiItensPage--sticker .extuiItensPageHeading", "Figurinhas", "Figurinhas ficam separadas de imagens e vídeos para facilitar o uso rápido.", "Revise a área de Figurinhas e como os itens são apresentados.", "A aba Figurinhas deve ser a única marcada como selecionada.", "Evite arquivos visualmente semelhantes com nomes idênticos."),
        step("documents", "itens-document", ".extuiItensPage--document .extuiItensPageHeading", "Documentos", "Documentos armazenam arquivos reutilizáveis como PDFs e outros formatos aceitos pela extensão.", "Observe o cadastro e a listagem de documentos.", "A área deve mostrar nome e ações do arquivo sem confundir com imagens e vídeos.", "Use um nome que permita reconhecer o documento sem precisar abri-lo."),
        step("pix", "itens-pix", ".extuiItensPage--pix .extuiItensPageHeading", "PIX", "PIX mantém dados reutilizáveis de cobrança separados das mensagens comuns.", "Revise os campos e a forma como o PIX será identificado.", "A categoria PIX deve permanecer selecionada durante a edição.", "Confira os dados antes de reutilizar um PIX em atendimento ou automação."),
        step("contacts", "itens-contact", ".extuiItensPage--contact .extuiItensPageHeading", "Contatos", "Contatos salvos permitem reutilizar dados de contato em ações compatíveis.", "Observe os campos disponíveis e a listagem.", "A categoria Contatos deve ficar ativa sem alterar as outras categorias.", "Mantenha nome e número consistentes para evitar cadastros ambíguos.")
      ]
    },
    {
      id: "respostas-rapidas", number: "04", title: "Respostas Rápidas passo a passo", duration: "8 min",
      description: "Aprenda a localizar respostas, criar uma nova resposta em três passos, montar a sequência de ações e organizar categorias sem executar nada por engano.",
      steps: [
        step("overview", "quick-responses", ".extuiQrDashApp", "Como a área é organizada", "Respostas Rápidas possui três áreas: Respostas, Criar / Editar e Categorias.", "Observe as três abas no topo antes de alterar qualquer conteúdo.", "A troca de aba deve acontecer dentro da própria página, mantendo o restante do Painel de Controle estável.", "Comece pela lista para entender o que já existe antes de criar uma nova resposta."),
        step("library-tab", "quick-responses", '[data-view="library"]', "Aba Respostas", "A aba Respostas é sua biblioteca de respostas prontas, com busca, filtros, favoritos e detalhes.", "Clique em Respostas para garantir que a biblioteca esteja aberta.", "Você deve ver busca, filtros e a área de detalhes sem enviar nenhuma resposta ao WhatsApp.", "Selecionar uma resposta apenas mostra os detalhes; executar é uma ação separada.", "", { actionRequired: true }),
        step("library", "quick-responses", ".extuiQrDashToolbar", "Buscar, filtrar e escolher", "Use a busca para nome ou atalho e os filtros para reduzir listas grandes.", "Observe a busca, o botão Nova resposta e o acesso às categorias.", "A lista deve mudar conforme os filtros sem alterar ou excluir respostas.", "Favoritos ajudam a manter as respostas mais usadas no alcance rápido."),
        step("builder-tab", "quick-responses", '[data-view="builder"]', "Aba Criar / Editar", "O construtor separa a criação em identificação, sequência e revisão para diminuir erros.", "Clique em Criar / Editar.", "Um formulário guiado em três passos deve aparecer; nada é salvo somente por abrir esta aba.", "Você pode voltar para Respostas sem salvar um teste.", "Não salve conteúdo de teste se não quiser mantê-lo.", { actionRequired: true }),
        step("builder-wizard", "quick-responses", ".extuiQrDashWizard", "Os três passos do construtor", "Primeiro você identifica a resposta, depois monta a ordem das ações e por fim revisa tudo antes de salvar.", "Leia os três passos mostrados no topo do construtor.", "A etapa atual deve ficar clara e apenas o conteúdo correspondente deve aparecer como principal.", "Nome e atalho ajudam a localizar a resposta; a sequência define o que realmente será executado."),
        step("sequence", "quick-responses", ".extuiQrDashComposer", "Monte a sequência com cuidado", "Uma resposta pode ter uma única mensagem ou várias ações executadas de cima para baixo.", "Observe os grupos de ação, o tipo de ação e os campos de configuração, sem adicionar uma etapa de teste.", "Mensagem, itens salvos, CRM, esperas, gestão e transferência devem aparecer como opções separadas.", "Monte primeiro a lógica e só depois use ações que alteram CRM, conversa ou atendimento."),
        step("categories-tab", "quick-responses", '[data-view="categories"]', "Aba Categorias", "Categorias organizam respostas sem duplicar o conteúdo.", "Clique em Categorias.", "A área de criação e gerenciamento de categorias deve abrir sem alterar as respostas existentes.", "Excluir uma categoria e excluir uma categoria junto com suas respostas são ações diferentes; leia a confirmação.", "", { actionRequired: true }),
        step("categories", "quick-responses", ".extuiQrDashCategoryPage", "Organize sem perder respostas", "Você pode criar, renomear, ocultar ou excluir categorias e acompanhar quantas respostas existem em cada uma.", "Revise as ações disponíveis e observe a diferença entre ocultar e excluir.", "Respostas preservadas devem poder voltar para Sem categoria quando apenas a categoria for removida.", "Use categorias curtas e objetivas para reduzir o tempo de procura durante o atendimento.")
      ]
    },
    {
      id: "crm-analise-encomendas", number: "05", title: "CRM, Cliente 360° e Encomendas", duration: "11 min",
      description: "Percorra CRMs, Visão geral, Kanban, Notas e Análise; depois veja como Encomendas e o Cliente 360° completam o acompanhamento do cliente.",
      steps: [
        step("crm-tabs", "crm", '[data-extui-academy-target="crm-view-tabs"]', "As cinco visões do CRM", "A barra do CRM separa administração dos CRMs, visão resumida, quadro de etapas, notas e análise.", "Localize CRMs, Visão geral, Kanban, Notas e Análise.", "Os cinco controles devem permanecer na mesma posição ao alternar entre as visões.", "Use cada visão para uma finalidade; não é necessário sair do CRM para alternar entre elas."),
        step("crm-hub-tab", "crm", '[data-extui-academy-target="crm-tab-hub"]', "CRMs: escolha e organização", "CRMs é a entrada para selecionar, criar, editar, fixar, arquivar ou excluir processos comerciais.", "Clique em CRMs.", "Os cards dos CRMs devem aparecer sem redirecionar automaticamente para o Funil CRM.", "Fixe os CRMs mais usados e arquive os que não devem participar dos seletores atuais.", "", { actionRequired: true }),
        step("crm-hub", "crm", ".extuiCrmHub", "Cards de CRM", "Cada card resume o processo e permite abrir conscientemente o CRM desejado.", "Observe contagem de listas, contatos e as ações do card.", "Editar, arquivar e excluir devem ser ações distintas e a exclusão deve pedir confirmação.", "Evite CRMs com nomes quase iguais; uma descrição curta ajuda a reconhecer o processo."),
        step("crm-overview-tab", "crm", '[data-extui-academy-target="crm-tab-overview"]', "Visão geral", "A Visão geral reúne indicadores, base de contatos, próximos agendamentos, automações e um resumo do funil.", "Clique em Visão geral.", "O conteúdo deve mudar sem deslocar a barra de visões do CRM.", "Use esta tela para leitura rápida antes de entrar no quadro de etapas.", "", { actionRequired: true }),
        step("crm-overview", "crm", ".extuiOverview", "Leia o CRM sem editar o quadro", "Aqui você acompanha números e contatos sem precisar manipular colunas.", "Observe os indicadores, a base de contatos e o resumo do funil.", "A busca deve encontrar contatos por nome e os blocos laterais devem continuar legíveis mesmo sem dados.", "Clique em um contato somente quando quiser abrir seu perfil."),
        step("crm-kanban-tab", "crm", '[data-extui-academy-target="crm-tab-kanban"]', "Kanban: quadro de etapas", "Kanban é a visão operacional para movimentar contatos entre as listas do processo.", "Clique em Kanban.", "As listas devem aparecer lado a lado e a barra de visões deve permanecer fixa no mesmo ponto.", "Mover um contato deve transferi-lo de etapa, não criar uma duplicata.", "", { actionRequired: true }),
        step("crm-kanban", "crm", ".extui-board", "Contatos e etapas", "Cada contato deve ocupar uma única etapa dentro do mesmo CRM.", "Observe uma coluna ou cartão, quando houver dados, e localize a busca do quadro.", "O nome e o telefone devem permitir reconhecer o contato e a etapa atual deve ser inequívoca.", "Use a busca por nome ou telefone antes de percorrer um quadro muito grande."),
        step("crm-notes-tab", "crm", '[data-extui-academy-target="crm-tab-notes"]', "Notas: histórico comercial", "Notas reúne registros escritos ligados aos contatos e ao contexto comercial.", "Clique em Notas.", "A busca e a lista de notas devem aparecer dentro do CRM selecionado.", "Registre contexto útil para o atendimento; evite repetir informações que já estão em campos estruturados.", "", { actionRequired: true }),
        step("crm-notes", "crm", ".extuiCrmNotesWorkspace", "Encontre notas pelo contexto", "A busca aceita contato, etapa e conteúdo da nota para recuperar informações rapidamente.", "Observe os indicadores e a lista; se estiver vazia, leia a orientação apresentada.", "Notas vazias não devem quebrar a página, e abrir perfil deve ser uma ação explícita.", "Use notas para contexto humano e campos do CRM para informações que precisam ser filtradas ou analisadas."),
        step("analysis", "crm-funnel", ".extuiCrmFunnelSection", "Análise do funil", "Análise transforma as etapas do CRM em indicadores e gráficos sem mover contatos.", "Escolha um CRM quando solicitado e revise Métrica, Visualização e Ordenação.", "Contatos, conversão, ticket médio e receita devem ser apresentados sem inventar valores ausentes.", "Troque o tipo de gráfico para leitura; isso não altera a estrutura do CRM."),
        step("orders", "encomendas", '[data-extui-academy-target="orders-overview"]', "Encomendas", "A área reúne o cadastro das encomendas e, quando necessário, recursos de entrega como preparo, entregadores, rastreio, pagamentos e avisos ao cliente.", "Passe pelas abas Pedidos, Entregas, Entregadores, Histórico e Análise antes de criar uma encomenda.", "As encomendas antigas devem continuar aparecendo e cada etapa precisa permanecer clara.", "Vincule o WhatsApp correto para aproveitar o Cliente 360° e os avisos de andamento.")
      ]
    },
    {
      id: "fluxos-funis", number: "06", title: "Fluxos e Funis sem atalhos", duration: "7 min",
      description: "Diferencie lógica visual de sequência ordenada e aprenda onde iniciar cada tipo de automação.",
      steps: [
        step("flow-overview", "fluxos", '[data-extui-academy-target="flow-overview"]', "Fluxos são mapas de decisão", "Fluxos representam caminhos com ações, condições e possíveis ramificações.", "Observe a busca, a lista e o botão Novo fluxo.", "A barra superior deve manter o mesmo padrão de alinhamento usado em Funis.", "Use Fluxo quando a próxima ação depende de uma condição ou de algo que inicia a automação."),
        step("flow-new", "fluxos", '[data-extui-academy-target="flow-new"]', "Antes de criar um Fluxo", "Novo fluxo abre o editor visual e já cria uma nova definição na sua lista; por isso o tutorial não exige que você clique apenas para testar.", "Localize + Novo fluxo e avance sem clicar, a menos que realmente queira começar uma automação.", "O botão deve ficar ao lado da busca e seguir o mesmo padrão de ações usado no restante do Painel.", "Quando for criar de verdade, dê um nome claro e configure primeiro o que inicia o fluxo.", "Não crie um fluxo descartável apenas para concluir o tutorial."),
        step("flow-events", "fluxos", "[data-extuif-trigger]", "Fluxos também podem reagir a eventos", "Além de palavras-chave e movimentações do CRM, um Fluxo pode começar quando um Funil termina, um FollowUp é enviado, um agendamento é executado ou um Pedido muda.", "Abra um Fluxo existente e use o botão Gatilho na barra superior do editor.", "Os gatilhos por evento devem respeitar dias, horários, público e a condição opcional do CRM assim como os demais gatilhos.", "Use eventos para encadear processos com propósito claro e evite criar ciclos entre automações."),
        step("funnel-overview", "funis", '[data-extui-academy-target="funnel-overview"]', "Funis são sequências", "Funis executam itens em ordem e são mais adequados quando não existe ramificação entre etapas.", "Compare a lista de Funis com a tela de Fluxos.", "Busca, ações e tela vazia devem seguir o mesmo padrão visual do Painel de Controle.", "Use Funil quando a ordem é previsível e linear."),
        step("funnel-time", "funis", '[data-extui-academy-target="funnel-time-units"]', "Intervalos do Funil", "As esperas entre itens controlam o ritmo da sequência.", "Localize os controles de tempo disponíveis no Funil.", "As unidades e valores devem estar legíveis e coerentes com o restante da extensão.", "Valide sequências mais complexas no Laboratório antes de usar contatos reais.")
      ]
    },
    {
      id: "laboratorio", number: "07", title: "Laboratório antes da produção", duration: "5 min",
      description: "Use a simulação para validar variáveis, ações e caminhos sem depender de uma conversa real.",
      steps: [
        step("simulation", "laboratorio", '[data-extui-academy-target="laboratory-simulation"]', "Modo de simulação", "A simulação permite verificar a lógica sem enviar mensagens ou mover contatos reais.", "Confirme que o modo de simulação está selecionado.", "A interface deve indicar claramente que você está em ambiente de teste.", "Use este modo sempre que alterar uma automação importante."),
        step("scenarios", "laboratorio", ".extuilScenarioGroup", "Cenários rápidos", "Os cenários preenchem um contato fictício e decisões comuns para acelerar testes de novo lead, retorno, resposta diferente ou ausência de resposta.", "Revise os cenários disponíveis sem precisar executar nenhum deles.", "Escolher um cenário deve alterar somente o ambiente de simulação e nunca os dados reais do CRM ou WhatsApp.", "Use Sem resposta para validar expiração e Resposta diferente para conferir ramificações."),
        step("contact", "laboratorio", '[data-extui-academy-target="laboratory-contact"]', "Contato fictício", "Nome e telefone de teste servem para resolver variáveis e condições durante a simulação.", "Revise os campos do contato fictício.", "Os dados devem permanecer locais à simulação e não virar um contato real automaticamente.", "Use valores fáceis de reconhecer para interpretar a linha do tempo."),
        step("real-mode", "laboratorio", '[data-extui-academy-target="laboratory-real-mode"]', "Simulação e execução real são coisas diferentes", "O modo real existe para testes conscientes com uma conversa escolhida por você; ele não deve ser usado só para concluir o tutorial.", "Localize a opção de modo real, mas permaneça em Simulação durante o aprendizado.", "A interface deve diferenciar claramente o modo seguro de simulação do modo que pode agir sobre uma conversa real.", "Só use o modo real quando souber exatamente qual automação e qual contato serão testados.", "O tutorial nunca exige uma execução real."),
        step("run", "laboratorio", '[data-extui-academy-target="laboratory-run"]', "Executar e ler a linha do tempo", "A linha do tempo mostra a ordem e o resultado das etapas executadas pelo simulador.", "Execute uma simulação quando houver uma automação de teste disponível.", "Após a execução, a linha do tempo deve explicar o que ocorreu em cada etapa.", "Leia avisos e condições antes de levar a automação para produção.", "A execução real deve ser uma decisão separada da simulação.", { completionEvent: "ext:lab-simulation-complete", actionRequired: true })
      ]
    },
    {
      id: "followup-agenda", number: "08", title: "FollowUp e Agenda", duration: "8 min",
      description: "Diferencie retorno automático por condição de CRM de um envio programado para data e hora específicas, incluindo monitoramento e recorrência.",
      steps: [
        step("followup", "followup", '[data-extui-academy-target="followup-form"]', "FollowUp observa uma condição", "FollowUp é usado quando a posição do contato no CRM e o tempo ou a entrada em uma etapa devem iniciar uma ação automática.", "Revise nome da regra, CRM, etapa, momento do disparo e conteúdo sem salvar uma regra de teste.", "Os campos devem deixar claro o que inicia a regra e o que será executado depois.", "Prefira tempos realistas e valide o CRM e a etapa antes de ativar."),
        step("followup-preview", "followup", ".extuiFollowUpLogicPreview", "Leia a regra antes de salvar", "A prévia traduz sua configuração em uma frase do tipo SE... E... ENTÃO..., facilitando perceber combinações erradas.", "Leia a prévia lógica montada abaixo dos campos.", "CRM, etapa, espera e ação devem formar uma frase coerente.", "Se a frase não representar sua intenção, ajuste os campos antes de salvar."),
        step("cancel-reply", "followup", '[data-extui-academy-target="followup-cancel-on-reply"]', "Cancelar quando o cliente responder", "Esta proteção evita que um retorno automático seja enviado depois que a conversa já retomou.", "Localize Cancelar se o contato responder antes do disparo.", "O estado do controle deve ser fácil de reconhecer antes de salvar.", "Para a maioria dos retornos comerciais, manter esta proteção ativa evita mensagens fora de contexto."),
        step("followup-monitor", "followup", '[data-extui-academy-target="followup-monitor"]', "Acompanhe regras criadas", "O monitor mostra regras ativas, contatos aguardando, execuções concluídas e erros.", "Observe os indicadores, a busca e o filtro de regras.", "Ativar, desativar e excluir uma regra devem ser ações distintas e nenhum filtro deve alterar os dados.", "Consulte os erros antes de criar outra regra para o mesmo objetivo."),
        step("agenda-fields", "agenda", '[data-extui-academy-target="agenda-fields"]', "Agenda é pontual ou recorrente", "Agenda programa um item para um contato em data e hora definidas e também permite repetição quando necessário.", "Revise Tipo, Item, Contato, Data, Hora e Recorrência sem confirmar um agendamento de teste.", "Os campos devem permanecer agrupados e a data/hora precisa ser inequívoca.", "Use Agenda quando você sabe quando a ação deve acontecer; use FollowUp quando a ação depende da situação do contato."),
        step("agenda-list", "agenda", '[data-extui-academy-target="agenda-list"]', "Itens agendados", "A lista permite buscar, conferir estado e cancelar agendamentos futuros.", "Observe a busca e os estados da lista, mesmo que ela esteja vazia.", "Agendados, erros e próximos horários devem ser compreensíveis sem abrir cada item.", "Antes de repetir um agendamento, confira se já existe um semelhante."),
        step("agenda-offline", "agenda", '[data-extui-academy-target="agenda-offline"]', "Quando o WhatsApp estava fechado", "Esta preferência define o que fazer com um agendamento que venceu enquanto o WhatsApp Web não estava disponível.", "Leia a opção de tolerância de atraso sem alterá-la se não quiser.", "A interface deve explicar que itens muito atrasados podem ser marcados como não enviados em vez de disparados ao reabrir.", "Essa proteção evita enviar conteúdo antigo fora do contexto esperado.")
      ]
    },
    {
      id: "disparos-seguranca", number: "09", title: "Disparos com Proteção de Envio", duration: "6 min",
      description: "Monte campanhas com revisão de conteúdo, público, intervalo e acompanhamento antes de iniciar o lote.",
      steps: [
        step("audience", "disparos", '[data-extui-academy-target="broadcast-audience"]', "Destinatários", "Comece definindo quem receberá a campanha usando busca, etiquetas, CRM/Etapas, número manual ou planilha.", "Revise a origem e a quantidade dos destinatários antes de avançar.", "A seleção deve permanecer deduplicada e fácil de conferir.", "Prefira públicos segmentados e somente contatos com permissão para receber a comunicação."),
        step("content", "disparos", '[data-extui-academy-target="broadcast-content"]', "Ações do disparo", "Monte a sequência de mensagens e ações na ordem em que será executada para cada destinatário.", "Use o catálogo de ações e revise a sequência antes de seguir para a revisão.", "Cada etapa deve mostrar claramente sua função, conteúdo resumido e posição na sequência.", "Use esperas e ações de CRM apenas quando fizerem parte do fluxo esperado."),
        step("safety", "disparos", '[data-extui-academy-target="broadcast-delay"]', "Revisão e ritmo", "Antes de iniciar, confira o intervalo, pausas automáticas, consentimento, opt-out e a validação da Proteção de Envio.", "Revise os controles exibidos e não inicie um lote de teste pelo tutorial.", "A tela deve deixar claro o que será enviado, para quem e em qual ritmo.", "Evite reduzir intervalos apenas para terminar mais rápido."),
        step("protection-tab", "disparos", '[data-extui-academy-target="broadcast-protection"]', "Proteção de Envio", "Os perfis e guardrails de envio agora ficam junto de Disparos, ao lado de Campanhas e Relatórios.", "Clique em Proteção de Envio e revise o perfil ativo, limites e janela contra reenvio.", "A configuração deve abrir sem sair da área de Disparos.", "Ajuste os limites somente quando entender o efeito sobre as campanhas.", "", { actionRequired: true }),
        step("send-safety", "disparos", "#extuiSendSafetyCard", "Entenda os limites antes de mudar", "Os controles desta área regulam espaçamento, volume por período, máximo por campanha, reenvio e horários das automações. O card de Prontidão para envio resume compatibilidade, sessão e estabilidade; o diagnóstico detalhado fica em Início → Diagnóstico.", "Use Testar tudo para uma verificação completa ou abra Diagnóstico para testar compatibilidade e sessão separadamente.", "A tela deve diferenciar claramente compatibilidade técnica, sessão conectada, estabilidade operacional e prontidão real para envio.", "A Proteção de Envio reduz comportamento agressivo, mas não promete evitar restrições da plataforma."),
        step("history", "disparos", '[data-extui-academy-target="broadcast-history"]', "Envio e resultados", "Durante e após a execução, acompanhe progresso, sucessos, falhas e resultados da campanha.", "Localize os estados do envio e as áreas de Campanhas e Relatórios.", "A interface deve diferenciar aguardando, enviando, sucesso, falha e cancelamento quando aplicável.", "Revise falhas antes de reenviar ou repetir uma campanha.")
      ]
    },
    {
      id: "status", number: "10", title: "Status: conteúdo, privacidade e fila", duration: "5 min",
      description: "Abra o painel de Status no WhatsApp e revise criação, audiência, publicação/agendamento e fila em etapas separadas.", context: "whatsapp",
      steps: [waStep("status-open", "status", "Abrir Status"), waStep("status-content", "status", "Conteúdo"), waStep("status-privacy", "status", "Privacidade"), waStep("status-publish", "status", "Publicar ou agendar"), waStep("status-queue", "status", "Fila e agendamentos")]
    },
    {
      id: "assistentes-ia", number: "11", title: "Assistentes IA em cinco áreas", duration: "7 min",
      description: "Siga Conexões, Perfis, Agentes, Memória e Conhecimento na ordem lógica e entenda o papel de cada camada.",
      steps: [
        step("connections", "ai-connect", '[data-extui-academy-target="ai-connect-header"]', "1. Conexões", "Conexões guardam o serviço de IA, a chave de acesso e o modelo que serão usados pelos recursos de IA.", "Revise os serviços de IA e o estado das conexões existentes.", "A tela deve mostrar com clareza se uma conexão está pronta antes de ser usada.", "Valide a conexão antes de criar dependências nela."),
        step("profiles", "ai-assistants", '[data-extui-academy-target="ai-assistants-header"]', "2. Perfis", "Perfis definem comportamento e configuração reutilizável para os Agentes.", "Revise a lista de Perfis e os controles principais.", "A tela deve permanecer na aba Perfis dentro de Assistentes IA.", "Crie perfis por função, evitando misturar objetivos incompatíveis."),
        step("agents", "ai-agents", '[data-extui-academy-target="ai-agents-header"]', "3. Agentes", "Agentes usam um Perfil e acrescentam objetivo, passos e permissões de execução.", "Revise a lista de Agentes e as capacidades associadas.", "O usuário deve conseguir distinguir configuração do Agente das capacidades herdadas.", "Conceda somente as capacidades necessárias ao objetivo do agente."),
        step("memory", "ai-memory", '[data-extui-academy-target="ai-memory-header"]', "4. Memória", "Memória armazena contexto persistente apenas para os Agentes autorizados.", "Revise quem pode usar memória e como os registros são apresentados.", "A tela deve deixar explícito o vínculo entre Memória e Agentes.", "Não use memória como substituto para dados estruturados do CRM."),
        step("knowledge", "knowledge", '[data-extui-academy-target="knowledge-header"]', "5. Base de Conhecimento", "Conhecimento reúne fontes consultáveis pelos Agentes para responder com informações específicas.", "Revise bases, documentos e permissões de acesso.", "A área deve diferenciar conteúdo pronto para consulta, conteúdo ainda em processamento e acesso dos Agentes.", "Mantenha as fontes atualizadas e remova documentos obsoletos.")
      ]
    },
    {
      id: "exportacao-integracoes", number: "12", title: "Exportação e Integrações", duration: "8 min",
      description: "Revise a origem e a prévia antes de exportar contatos e entenda separadamente ações externas, webhooks e Meta.",
      steps: [
        step("export-source", "salvar", '[data-extui-academy-target="salvar-source"]', "Origem dos contatos", "A exportação começa pela definição de quais contatos devem entrar no arquivo.", "Escolha visualmente entre todos, etiqueta ou grupo sem iniciar um download.", "A origem selecionada deve permanecer evidente durante a revisão.", "Quanto mais específica a origem, menor a chance de exportar dados desnecessários."),
        step("export-preview", "salvar", '[data-extui-academy-target="salvar-actions"]', "Prévia e formato", "Antes de baixar, confira quantidade, colunas e formato de saída.", "Revise a prévia e os botões de formato disponíveis.", "O download só deve ocorrer após uma ação explícita sua.", "Confira a quantidade antes de exportar listas grandes."),
        step("integrations-overview", "integracoes", ".extuiiPageV2 > .extuiiHeader", "Integrações externas", "Esta área reúne conexões operacionais. Serviços de IA possuem uma área própria em Assistentes IA.", "Observe o resumo e os grupos apresentados antes de abrir qualquer configuração.", "A página deve diferenciar ações externas, avisos automáticos e Meta.", "Configure somente integrações que tenham uma finalidade definida no seu processo."),
        step("external-actions", "integracoes", ".extuiiAutomationGroup", "Ações externas", "Ações externas permitem que automações da extensão consultem ou enviem dados para um serviço autorizado.", "Revise a área de ações sem criar uma chamada de teste.", "Nome, destino, autenticação, campos permitidos e resposta visível para a IA devem ser configurados separadamente.", "Conceda apenas os campos e permissões necessários para a ação."),
        step("webhooks", "integracoes", '[aria-label="Webhooks"]', "Avisos automáticos para outros sistemas", "Webhooks enviam um aviso da extensão para outro sistema quando um evento configurado acontece.", "Localize Webhooks e o botão de gerenciamento.", "A área deve mostrar quantidade de avisos ativos sem exigir configuração para quem não usa esse recurso.", "Pense neles como notificações automáticas entre sistemas; proteja as chaves de acesso."),
        step("meta", "integracoes", '[aria-label="Meta Pixel e envio de eventos"]', "Meta Pixel e envio de eventos", "Esta integração envia eventos de negócio para a Meta quando você realmente precisa acompanhar essas conversões.", "Localize a seção da Meta e leia a descrição antes de configurar.", "A chave de acesso deve ser tratada como dado protegido e ficar fora das cópias de segurança.", "Não ative rastreamento sem saber quais eventos serão enviados.")
      ]
    },
    {
      id: "personalizacao-ajustes-backup", number: "13", title: "Personalização, Ajustes e Cópias de Segurança", duration: "15 min",
      description: "Feche o ciclo entendendo aparência, comportamento da extensão, conta e cópias de segurança sem misturar configurações diferentes.",
      steps: [
        step("personalization-mode", "personalizacao", "#extuiModeRow", "Modo claro, escuro ou automático", "O modo define a base visual do Painel de Controle e pode acompanhar o ambiente automaticamente.", "Revise Automático, Escuro e Claro sem trocar se não quiser.", "Somente uma opção deve aparecer ativa por vez e o restante da página deve continuar legível.", "Automático é útil quando você quer que a aparência acompanhe o sistema ou o WhatsApp."),
        step("personalization-theme", "personalizacao", "#extuiVisualThemeGrid", "Tema visual", "O tema muda a identidade visual sem alterar suas funções ou dados.", "Observe as opções de tema e qual está selecionada.", "A escolha deve afetar cores e superfícies sem esconder ícones, textos ou estados ativos.", "Confira contraste tanto no claro quanto no escuro quando usar um tema personalizado."),
        step("personalization-advanced", "personalizacao", ".extuiAppearanceAdvancedToggle", "Mais opções visuais", "As opções avançadas reúnem fonte, movimento, arredondamento, ícones e tamanhos da interface.", "Localize Mais opções visuais; abrir esta área não altera nenhuma preferência sozinho.", "O conteúdo avançado deve poder ser expandido e recolhido sem deslocamentos bruscos.", "Mude uma preferência por vez quando estiver ajustando a aparência."),
        step("settings-tabs", "ajustes", ".extuiAjustesTabsV3", "Ajustes são separados por assunto", "Geral reúne comportamento do WhatsApp e automações; Conta reúne licença e dados da conta. A Proteção de Envio fica em Disparos.", "Localize as abas Geral e Conta.", "Somente uma aba deve ficar ativa por vez e o caminho no topo deve acompanhar a categoria atual.", "Use a busca de configurações quando souber o nome da opção."),
        step("settings-general", "ajustes", '[data-tab="geral"]', "Geral", "Aqui ficam confirmações de envio, comportamento do WhatsApp e preferências do sistema.", "Clique em Geral.", "Os cartões WhatsApp, Automação e Sistema devem aparecer nesta categoria.", "Confirmações antes de enviar ajudam a evitar ações manuais por engano.", "", { actionRequired: true }),
        step("settings-account", "ajustes", '[data-tab="conta"]', "Conta", "Conta reúne informações de licença e acesso separadas das preferências operacionais.", "Clique em Conta e identifique os cartões disponíveis.", "Dados da conta não devem se misturar com os controles de automação ou segurança.", "Use esta área quando o assunto for licença, acesso ou informações da conta.", "", { actionRequired: true }),
        step("core-home", "home", '.extuiHomeCoreHub .extuiCoreTabs', "Central", "Início reúne o resumo operacional e a Central completa — saúde local, favoritos, modelos, integrações, diagnóstico e conquistas — sem substituir as áreas especializadas.", "Abra Início e observe a Central integrada abaixo do resumo operacional.", "Os indicadores devem funcionar como atalhos para investigar pendências, não como uma segunda cópia do Painel de Controle.", "Use esta área como ponto de checagem antes de iniciar uma rotina de trabalho."),
        step("core-favorites", "home", '[data-extui-academy-target="core-tab-favorites"]', "Favoritos globais", "Favoritos guardam atalhos para áreas, contatos e conteúdos encontrados pela Busca Universal.", "Clique em Favoritos.", "A lista deve mostrar somente itens que você marcou com estrela e permitir removê-los sem excluir o conteúdo original.", "Favoritar não duplica dados; apenas cria um atalho.", "", { actionRequired: true }),
        step("core-vault", "home", '[data-extui-academy-target="core-tab-vault"]', "Cofre de Integrações", "O Cofre mostra o estado das conexões sem revelar a credencial completa.", "Clique em Cofre e confira os serviços listados.", "Chaves devem aparecer somente mascaradas quando aplicável e continuar excluídas das cópias de segurança.", "Gerencie a credencial na área específica da integração.", "", { actionRequired: true }),
        step("core-diagnostics", "home", '[data-extui-academy-target="core-tab-diagnostics"]', "Diagnóstico local", "O diagnóstico verifica componentes básicos da extensão sem enviar os resultados para um servidor.", "Clique em Diagnóstico.", "Cada verificação deve indicar OK ou atenção e oferecer um atalho quando existir uma área relacionada.", "Copie o diagnóstico quando precisar registrar um problema antes de alterar configurações.", "", { actionRequired: true }),
        step("backup-categories", "backup", ".extuiBackupManualCategories", "Escolha o que entra na cópia", "Cada categoria pode ser incluída ou removida da exportação; arquivos associados entram no ZIP quando suportados.", "Revise Selecionar Todos e as categorias individuais.", "Marcar ou desmarcar uma categoria deve apenas mudar a seleção, sem exportar nada imediatamente.", "Antes de mudanças grandes, prefira uma cópia ampla para facilitar a recuperação."),
        step("backup-mode", "backup", "#extuiBackupModeRow", "Mesclar ou Sobrescrever", "Mesclar preserva os dados atuais e adiciona ou atualiza o conteúdo importado. Sobrescrever substitui as categorias escolhidas.", "Compare Mesclar (Recomendado) e Sobrescrever.", "A explicação abaixo deve mudar junto com a opção selecionada.", "Quando houver dúvida, use Mesclar; Sobrescrever é indicado apenas quando substituir os dados atuais for sua intenção.", "Sobrescrever pode remover dados existentes das categorias importadas."),
        step("backup-format", "backup", "#extuiBackupFormatRow", "ZIP ou JSON", "ZIP é o formato recomendado porque pode levar também os arquivos da Biblioteca e outros arquivos associados.", "Observe ZIP (Recomendado) e JSON.", "A descrição deve explicar as diferenças e limitações de cada formato.", "Use ZIP para cópias completas e portáveis entre computadores."),
        step("backup-actions", "backup", ".extuiBackupMainActions", "Exportar e Importar Cópia", "Exportar cria um arquivo com as categorias escolhidas; Importar primeiro permite revisar o arquivo e selecionar o que será restaurado.", "Localize Exportar Cópia e Importar Cópia sem clicar se estiver apenas estudando.", "Nenhuma importação deve acontecer sem seleção e confirmação explícitas.", "Guarde a cópia em um local que você consiga encontrar antes de grandes mudanças."),
        step("backup-auto", "backup", ".extuiBackupAutoGrid", "Cópia automática", "A cópia automática reutiliza as categorias selecionadas e permite escolher frequência, quantidade de cópias mantidas e subpasta dentro de Downloads.", "Revise o interruptor, frequência, histórico e destino sem ativar se não quiser.", "A área deve indicar quando os controles estão ativos e mostrar claramente a pasta de destino.", "Defina uma frequência compatível com a importância e a frequência de mudança dos seus dados."),
        step("backup-now", "backup", "#extuiBackupCreateNow", "Criar Cópia Agora", "Este botão gera uma cópia manual usando as categorias, o formato e a pasta atualmente configurados.", "Localize o botão; não é necessário criar um arquivo apenas para concluir o tutorial.", "A criação só deve começar após seu clique e deve mostrar progresso enquanto prepara o arquivo.", "Use antes de importar dados externos ou fazer alterações estruturais importantes.")
      ]
    }
  ];

  var ACADEMY_COVERAGE = {
    home: "painel-controle", academy: "painel-controle", disparos: "disparos-seguranca", "quick-responses": "respostas-rapidas",
    "itens-message": "biblioteca-completa", "itens-audio": "biblioteca-completa", "itens-image": "biblioteca-completa", "itens-video": "biblioteca-completa", "itens-media": "biblioteca-completa", "itens-sticker": "biblioteca-completa", "itens-document": "biblioteca-completa", "itens-pix": "biblioteca-completa", "itens-interactive-list": "biblioteca-completa", "itens-contact": "biblioteca-completa", "itens-signature": "biblioteca-completa",
    crm: "crm-analise-encomendas", "crm-funnel": "crm-analise-encomendas", encomendas: "crm-analise-encomendas", delivery: "crm-analise-encomendas", fluxos: "fluxos-funis", funis: "fluxos-funis", laboratorio: "laboratorio", followup: "followup-agenda", agenda: "followup-agenda",
    "ai-connect": "assistentes-ia", "ai-transcription": "assistentes-ia", "ai-translation": "assistentes-ia", "ai-assistants": "assistentes-ia", "ai-agents": "assistentes-ia", "ai-memory": "assistentes-ia", knowledge: "assistentes-ia", salvar: "exportacao-integracoes", integracoes: "exportacao-integracoes", segredos: "painel-controle", personalizacao: "personalizacao-ajustes-backup", ajustes: "personalizacao-ajustes-backup", backup: "personalizacao-ajustes-backup"
  };

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      if (key === "class") node.className = attrs[key];
      else if (key === "text") node.textContent = attrs[key];
      else if (key.indexOf("on") === 0 && typeof attrs[key] === "function") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      else node.setAttribute(key, attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); });
    return node;
  }

  function numberOrNull(value) { if (value == null || value === "") return null; var number = Number(value); return Number.isFinite(number) && number >= 0 ? number : null; }
  function parseState(raw) {
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    raw = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
    var legacy = (Number(raw.academyVersion) || 0) < ACADEMY_VERSION;
    var lessons = {};
    LESSON_IDS.forEach(function (id) { lessons[id] = legacy ? false : !!(raw.lessons && raw.lessons[id]); });
    if (legacy) { raw.currentLessonId = null; raw.currentStepId = null; raw.currentContext = null; raw.pendingTransition = null; raw.completedVersion = null; raw.skippedVersion = null; }
    var pending = raw.pendingTransition && typeof raw.pendingTransition === "object" ? raw.pendingTransition : null;
    if (pending && (typeof pending.id !== "string" || (pending.destinationContext !== "dashboard" && pending.destinationContext !== "whatsapp"))) pending = null;
    return Object.assign({}, raw, {
      academyVersion: ACADEMY_VERSION, completedVersion: numberOrNull(raw.completedVersion), skippedVersion: numberOrNull(raw.skippedVersion), lessons: lessons,
      currentLessonId: LESSON_IDS.indexOf(raw.currentLessonId) >= 0 ? raw.currentLessonId : null, currentStepId: typeof raw.currentStepId === "string" ? raw.currentStepId : null,
      currentContext: raw.currentContext === "whatsapp" || raw.currentContext === "dashboard" ? raw.currentContext : null, academyEntryMode: raw.academyEntryMode === "auto" ? "auto" : raw.academyEntryMode === "manual" ? "manual" : null,
      pendingTransition: pending, lastCompletedTransitionId: typeof raw.lastCompletedTransitionId === "string" ? raw.lastCompletedTransitionId : null
    });
  }
  function storageGet() { return window.__extDashboardShell.storageGet(STORAGE_KEY).then(function (result) { return parseState(result && result[STORAGE_KEY]); }); }
  function storageSet(patch) {
    stateWrite = stateWrite.catch(function () {}).then(async function () { var current = await storageGet(); var next = Object.assign({}, current, patch); if (patch.lessons) next.lessons = Object.assign({}, current.lessons, patch.lessons); var payload = {}; payload[STORAGE_KEY] = next; await window.__extDashboardShell.storageSet(payload); return parseState(next); });
    return stateWrite;
  }
  function storageReplace(nextState) { stateWrite = stateWrite.catch(function () {}).then(async function () { var normalized = parseState(nextState); var payload = {}; payload[STORAGE_KEY] = normalized; await window.__extDashboardShell.storageSet(payload); return normalized; }); return stateWrite; }
  function progressOf(state) { var completed = LESSON_IDS.filter(function (id) { return state.lessons[id]; }).length; return { completed: completed, total: LESSON_IDS.length, percent: Math.round((completed / LESSON_IDS.length) * 100) }; }
  function lessonById(id) { return LESSONS.find(function (lesson) { return lesson.id === id; }); }
  function firstIncompleteLessonId(state) { for (var i = 0; i < LESSON_IDS.length; i++) if (!state.lessons[LESSON_IDS[i]]) return LESSON_IDS[i]; return null; }
  function authorized() { return !!(window.__extG1 && window.__extG1._a()); }
  function isValidLessonPosition(lesson, state) { if (!lesson || !state || state.currentLessonId !== lesson.id) return false; return lesson.steps.some(function (candidate) { return candidate.id === state.currentStepId && (candidate.context || lesson.context || "dashboard") === state.currentContext; }); }
  function statusFor(lesson, state) { var required = firstIncompleteLessonId(state); if (state.lessons[lesson.id]) return { label: "Concluído", className: "is-complete", action: "Refazer" }; if (lesson.id !== required) return { label: "Aguardando", className: "is-locked", action: "Bloqueado" }; if (isValidLessonPosition(lesson, state)) return { label: "Em andamento", className: "is-progress", action: "Continuar" }; return { label: "Não iniciado", className: "is-new", action: "Começar" }; }
  function showCenter() { cleanupGuide(); if (!authorized()) return Promise.resolve({ ok: false, reason: "access-locked" }); return window.__extDashboardShell ? window.__extDashboardShell.showSection("academy") : Promise.resolve({ ok: false, reason: "shell-unavailable" }); }

  function focusTab(tab) { return new Promise(function (resolve) { chrome.tabs.update(tab.id, { active: true }, function () { if (chrome.windows && chrome.windows.update) chrome.windows.update(tab.windowId, { focused: true }); resolve(); }); }); }
  function sendAcademyIntent(tab, transition) {
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = setTimeout(function () { if (settled) return; settled = true; reject(new Error("O WhatsApp não confirmou a etapa dentro do tempo esperado.")); }, WHATSAPP_MESSAGE_WAIT_MS);
      chrome.tabs.sendMessage(tab.id, { __extAcademyCommand: true, academyNavigate: { transitionId: transition.id, lessonId: transition.lessonId, stepId: transition.stepId, panel: transition.panel || null, transition: transition } }, function (response) {
        if (settled) return; settled = true; clearTimeout(timer);
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response || response.ok !== true || response.transitionId !== transition.id || response.targetReady !== true || (transition.panel && response.panelReady !== true)) { var err = new Error(response && response.error ? response.error : "O WhatsApp não confirmou que a etapa ficou pronta."); err.destinationResponded = !!response; reject(err); return; }
        resolve(response);
      });
    });
  }
  function reloadWhatsappTab(tab) { return new Promise(function (resolve, reject) { var settled = false; var timer = setTimeout(function () { finish(new Error("O WhatsApp não terminou de recarregar.")); }, WHATSAPP_RELOAD_WAIT_MS); function finish(error) { if (settled) return; settled = true; clearTimeout(timer); chrome.tabs.onUpdated.removeListener(onUpdated); if (error) reject(error); else resolve(); } function onUpdated(tabId, changeInfo) { if (tabId === tab.id && changeInfo.status === "complete") finish(); } chrome.tabs.onUpdated.addListener(onUpdated); chrome.tabs.reload(tab.id, function () { if (chrome.runtime.lastError) finish(new Error(chrome.runtime.lastError.message)); }); }); }
  function closeConnectionPrompt() { if (activeConnectionPrompt && activeConnectionPrompt.isConnected) activeConnectionPrompt.remove(); activeConnectionPrompt = null; }
  function showWhatsappRecovery(position, error, whatsappMissing) {
    closeConnectionPrompt();
    var root = el("section", { class: "extuiaConnectionPrompt", role: "alertdialog", "aria-labelledby": "extuiaConnectionTitle" });
    root.appendChild(el("span", { class: "extuiaEyebrow", text: "CONEXÃO COM O WHATSAPP" }));
    root.appendChild(el("h2", { id: "extuiaConnectionTitle", text: whatsappMissing ? "Abra o WhatsApp para continuar" : "Não foi possível abrir esta etapa no WhatsApp" }));
    root.appendChild(el("p", { text: whatsappMissing ? "Abra o WhatsApp Web, aguarde a extensão ficar pronta e tente novamente." : "O progresso foi preservado. Você pode tentar novamente sem reiniciar o tutorial." }));
    if (error && error.message) root.appendChild(el("small", { class: "extuiaConnectionDetail", text: error.message }));
    var actions = el("div", { class: "extuiaConnectionActions" });
    actions.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Sair", onClick: function () { if (academyMachine) academyMachine.exit("whatsapp-recovery-exit"); closeConnectionPrompt(); } }));
    actions.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Abrir WhatsApp", onClick: function () { chrome.tabs.create({ url: "https://web.whatsapp.com/" }); } }));
    actions.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Pular etapa", onClick: async function () { var result = academyMachine ? await academyMachine.skipStep() : null; closeConnectionPrompt(); if (result && result.completed) showCenter(); } }));
    var retry = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Tentar novamente", onClick: async function () { retry.disabled = true; var result = academyMachine ? await academyMachine.retry() : { ok: false }; if (result && result.ok) closeConnectionPrompt(); else retry.disabled = false; } });
    actions.appendChild(retry); root.appendChild(actions); document.body.appendChild(root); activeConnectionPrompt = root; retry.focus({ preventScroll: true });
  }
  async function openWhatsappPosition(position, transition) {
    if (!authorized()) throw new Error("Os Tutoriais ficam disponíveis após validar o acesso.");
    if (!transition) throw new Error("Não foi possível preparar a abertura do tutorial no WhatsApp.");
    var tabs = await new Promise(function (resolve) { chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (found) { resolve(chrome.runtime.lastError ? [] : (found || [])); }); });
    if (!tabs.length) { var missing = new Error("Nenhuma aba do WhatsApp Web está aberta."); showWhatsappRecovery(position, missing, true); throw missing; }
    var tab = tabs.find(function (candidate) { return candidate.active; }) || tabs[0]; await focusTab(tab);
    try { return await sendAcademyIntent(tab, transition); }
    catch (firstError) {
      if (firstError.destinationResponded) { showWhatsappRecovery(position, firstError, false); throw firstError; }
      try { await new Promise(function (resolve) { setTimeout(resolve, 350); }); return await sendAcademyIntent(tab, transition); }
      catch (secondError) {
        try { await reloadWhatsappTab(tab); await focusTab(tab); return await sendAcademyIntent(tab, transition); }
        catch (finalError) { showWhatsappRecovery(position, finalError, false); throw finalError; }
      }
    }
  }

  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function machineUnavailable() { return Promise.resolve({ ok: false, reason: "academy-core-unavailable" }); }
  async function startLesson(id) { if (!academyMachine) return machineUnavailable(); var state = await storageGet(), required = firstIncompleteLessonId(state); if (required && id !== required && !state.lessons[id]) { var requiredLesson = lessonById(required); toast("Conclua primeiro o tutorial " + (requiredLesson ? requiredLesson.number + " · " + requiredLesson.title : "anterior") + ".", true); await showCenter(); return { ok: false, reason: "lesson-order", requiredLessonId: required }; } return academyMachine.startLesson(id); }
  async function resumeLesson(id) { if (!academyMachine) return machineUnavailable(); var state = await storageGet(), required = firstIncompleteLessonId(state); if (required && id !== required && !state.lessons[id]) return startLesson(id); return academyMachine.resumeLesson(id); }
  function restartLesson(id) { return academyMachine ? academyMachine.restartLesson(id) : machineUnavailable(); }

  function visibleTarget(node) { if (!node || !node.isConnected) return false; var rect = node.getBoundingClientRect(); if (rect.width <= 1 || rect.height <= 1) return false; var style = window.getComputedStyle(node); return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0; }
  function queryTarget(selector) { if (!selector) return null; var nodes; try { nodes = document.querySelectorAll(selector); } catch (_) { return null; } for (var i = 0; i < nodes.length; i++) if (visibleTarget(nodes[i])) return nodes[i]; return null; }
  function setSpotlightRect(element, top, left, width, height) { if (!element) return; element.style.top = Math.round(top) + "px"; element.style.left = Math.round(left) + "px"; element.style.width = Math.max(0, Math.round(width)) + "px"; element.style.height = Math.max(0, Math.round(height)) + "px"; }
  function placeGuideCard(root, focus, viewportWidth, viewportHeight) {
    if (!root || !root.isConnected) return;
    var edge = 14, gap = 14, rect = root.getBoundingClientRect();
    var candidates = [
      { left: focus.right + gap, top: focus.top + (focus.height - rect.height) / 2 },
      { left: focus.left - gap - rect.width, top: focus.top + (focus.height - rect.height) / 2 },
      { left: focus.left + (focus.width - rect.width) / 2, top: focus.bottom + gap },
      { left: focus.left + (focus.width - rect.width) / 2, top: focus.top - gap - rect.height }
    ];
    function score(pos) { return Math.min(pos.left - edge, viewportWidth - edge - (pos.left + rect.width), pos.top - edge, viewportHeight - edge - (pos.top + rect.height)); }
    candidates.sort(function (a, b) { return score(b) - score(a); });
    var best = candidates[0];
    root.style.left = Math.max(edge, Math.min(viewportWidth - rect.width - edge, best.left)) + "px";
    root.style.top = Math.max(edge, Math.min(viewportHeight - rect.height - edge, best.top)) + "px";
    root.style.right = "auto"; root.style.bottom = "auto";
  }
  function layoutGuideSpotlight() {
    if (!activeGuide || !activeGuide.focusLayer) return;
    activeGuide.layoutFrame = 0;
    var layer = activeGuide.focusLayer, width = window.innerWidth, height = window.innerHeight, target = activeGuide.target;
    var rect = visibleTarget(target) ? target.getBoundingClientRect() : null;
    var fullMask = layer.querySelector('[data-extuia-mask="full"]'), spotlight = layer.querySelector(".extuiaSpotlight");
    if (!rect) { setSpotlightRect(fullMask, 0, 0, width, height); ["top", "left", "right", "bottom"].forEach(function (name) { setSpotlightRect(layer.querySelector('[data-extuia-mask="' + name + '"]'), 0, 0, 0, 0); }); if (spotlight) spotlight.hidden = true; if (activeGuide.root) { activeGuide.root.style.left = "50%"; activeGuide.root.style.top = "50%"; activeGuide.root.style.transform = "translate(-50%,-50%)"; } return; }
    var padding = 7, focus = { top: Math.max(0, rect.top - padding), left: Math.max(0, rect.left - padding), right: Math.min(width, rect.right + padding), bottom: Math.min(height, rect.bottom + padding) };
    focus.width = focus.right - focus.left; focus.height = focus.bottom - focus.top;
    setSpotlightRect(fullMask, 0, 0, 0, 0); setSpotlightRect(layer.querySelector('[data-extuia-mask="top"]'), 0, 0, width, focus.top); setSpotlightRect(layer.querySelector('[data-extuia-mask="left"]'), focus.top, 0, focus.left, focus.height); setSpotlightRect(layer.querySelector('[data-extuia-mask="right"]'), focus.top, focus.right, width - focus.right, focus.height); setSpotlightRect(layer.querySelector('[data-extuia-mask="bottom"]'), focus.bottom, 0, width, height - focus.bottom); setSpotlightRect(spotlight, focus.top, focus.left, focus.width, focus.height); if (spotlight) spotlight.hidden = false;
    if (activeGuide.root) { activeGuide.root.style.transform = "none"; placeGuideCard(activeGuide.root, focus, width, height); }
  }
  function scheduleGuideSpotlight() { if (!activeGuide || activeGuide.layoutFrame) return; activeGuide.layoutFrame = requestAnimationFrame(layoutGuideSpotlight); }
  function releaseGuideTarget(guide) { if (!guide) return; if (guide.observer) { guide.observer.disconnect(); guide.observer = null; } if (guide.target && guide.targetClickHandler) guide.target.removeEventListener("click", guide.targetClickHandler, true); if (guide.target) guide.target.classList.remove("extuiaAcademyTarget"); if (guide.geometryObserver) { guide.geometryObserver.disconnect(); guide.geometryObserver = null; } guide.target = null; guide.targetClickHandler = null; scheduleGuideSpotlight(); }
  function cleanupGuide() { if (!activeGuide) return; var previousFocus = activeGuide.previousFocus; releaseGuideTarget(activeGuide); if (activeGuide.completionEvent) window.removeEventListener(activeGuide.completionEvent, activeGuide.completionHandler); if (activeGuide.keyHandler) document.removeEventListener("keydown", activeGuide.keyHandler, true); if (activeGuide.sectionHandler) document.removeEventListener("ext:dashboard-section-change", activeGuide.sectionHandler); window.removeEventListener("resize", scheduleGuideSpotlight); window.removeEventListener("scroll", scheduleGuideSpotlight, true); if (activeGuide.layoutFrame) cancelAnimationFrame(activeGuide.layoutFrame); if (activeGuide.focusLayer && activeGuide.focusLayer.isConnected) activeGuide.focusLayer.remove(); if (activeGuide.root && activeGuide.root.isConnected) activeGuide.root.remove(); activeGuide = null; if (previousFocus && previousFocus.isConnected && typeof previousFocus.focus === "function") previousFocus.focus({ preventScroll: true }); }
  function setGuideUnavailable(message, canReturn, canRecover) { if (!activeGuide) return; var fallback = activeGuide.root.querySelector(".extuiaGuideFallback"), returnButton = activeGuide.root.querySelector("[data-extuia-return]"), recovery = activeGuide.root.querySelector("[data-extuia-recovery]"); if (fallback) { fallback.textContent = message; fallback.hidden = false; } if (returnButton) returnButton.hidden = !canReturn; if (recovery) recovery.hidden = !canRecover; }
  function waitForTarget(selector, guide, navigationId) {
    return new Promise(function (resolve) {
      if (!selector) { resolve(null); return; }
      var initial = queryTarget(selector); if (initial) { resolve(initial); return; }
      var settled = false, observer = new MutationObserver(check), timer = setTimeout(function () { finish(null); }, DASHBOARD_TARGET_WAIT_MS);
      function finish(target) { if (settled) return; settled = true; clearTimeout(timer); observer.disconnect(); resolve(target); }
      function check() { if (!activeGuide || activeGuide !== guide || guide.navigationId !== navigationId) { finish(null); return; } var target = queryTarget(selector); if (target) finish(target); }
      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "aria-hidden"] }); check();
    });
  }
  async function waitStable(target, guide, navigationId) {
    var previous = "", stable = 0;
    for (var i = 0; i < 18; i++) {
      if (!activeGuide || activeGuide !== guide || guide.navigationId !== navigationId || !visibleTarget(target)) return false;
      var rect = target.getBoundingClientRect(), key = [Math.round(rect.left), Math.round(rect.top), Math.round(rect.width), Math.round(rect.height)].join(":");
      if (key === previous) stable += 1; else stable = 0; previous = key; if (stable >= 2) return true;
      await new Promise(function (resolve) { requestAnimationFrame(resolve); });
    }
    return visibleTarget(target);
  }
  function unlockRequiredAction(guide, label) { if (!guide || guide !== activeGuide) return; guide.actionDone = true; var next = guide.root.querySelector('[data-extuia-action="next"]'); if (next) next.disabled = false; var badge = guide.root.querySelector(".extuiaGuideActionState"); if (badge) { badge.hidden = false; badge.textContent = label || "Ação reconhecida. Você pode avançar."; } }
  async function findAndBindTarget(stepDef, guide, navigationId) {
    releaseGuideTarget(guide);
    if (!stepDef.selector) { setGuideUnavailable("Esta etapa não depende de um controle específico.", false, false); return true; }
    var target = await waitForTarget(stepDef.selector, guide, navigationId);
    if (!activeGuide || activeGuide !== guide || guide.navigationId !== navigationId) return false;
    if (!target) { setGuideUnavailable("O controle desta etapa não ficou disponível. Tente novamente; se a interface mudou, pule somente esta etapa.", false, true); return false; }
    if (target.id === "extappContentArea") {
      var renderedChildren = Array.prototype.slice.call(target.children || []).filter(function (child) {
        return visibleTarget(child) && !child.classList.contains("extappGuideRow") && !child.classList.contains("extappSectionNav");
      });
      if (renderedChildren.length) target = renderedChildren[renderedChildren.length - 1];
    }
    guide.target = target; target.classList.add("extuiaAcademyTarget");
    try { target.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" }); } catch (_) { target.scrollIntoView({ block: "center" }); }
    if (!(await waitStable(target, guide, navigationId))) { setGuideUnavailable("A área abriu, mas o controle ainda não estabilizou.", false, true); return false; }
    if (window.ResizeObserver) { guide.geometryObserver = new ResizeObserver(scheduleGuideSpotlight); guide.geometryObserver.observe(target); }
    scheduleGuideSpotlight();
    var fallback = guide.root.querySelector(".extuiaGuideFallback"), returnButton = guide.root.querySelector("[data-extuia-return]"), recovery = guide.root.querySelector("[data-extuia-recovery]"); if (fallback) fallback.hidden = true; if (returnButton) returnButton.hidden = true; if (recovery) recovery.hidden = true;
    if (stepDef.actionRequired) { guide.targetClickHandler = function () { unlockRequiredAction(guide, "Ação reconhecida. Agora avance para a próxima etapa."); }; target.addEventListener("click", guide.targetClickHandler, true); }
    guide.observer = new MutationObserver(function () { if (!activeGuide || activeGuide !== guide || guide.navigationId !== navigationId) return; if (!visibleTarget(target)) { guide.observer.disconnect(); guide.observer = null; guide.target = null; if (guide.actionDone) { var fallback = guide.root.querySelector(".extuiaGuideFallback"), recovery = guide.root.querySelector("[data-extuia-recovery]"); if (fallback) fallback.hidden = true; if (recovery) recovery.hidden = true; } else setGuideUnavailable("O controle desta etapa mudou antes de a ação ser reconhecida.", true, true); scheduleGuideSpotlight(); } else scheduleGuideSpotlight(); });
    guide.observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "aria-hidden"] });
    return true;
  }
  function bindCompletionEvent(stepDef, guide) { if (guide.completionEvent) window.removeEventListener(guide.completionEvent, guide.completionHandler); guide.completionEvent = null; guide.completionHandler = null; if (!stepDef.completionEvent) return; guide.completionEvent = stepDef.completionEvent; guide.completionHandler = function () { unlockRequiredAction(guide, "Exercício reconhecido. O resultado foi gerado com segurança."); }; window.addEventListener(stepDef.completionEvent, guide.completionHandler, { once: true }); }
  async function nextGuideStep() { if (!activeGuide || !academyMachine) return; var current = activeGuide.lesson.steps[activeGuide.index]; if (current.actionRequired && !activeGuide.actionDone) return; var result = await academyMachine.next(); if (result && result.completed) { toast("Tutorial concluído."); showCenter(); } }
  async function previousGuideStep() { if (activeGuide && academyMachine) await academyMachine.previous(); }
  async function navigateGuideToStep(guide, stepDef, force) {
    if (!authorized() || !activeGuide || activeGuide !== guide) return false;
    var navigationId = ++guide.navigationId, shell = window.__extDashboardShell;
    if (shell && stepDef.section) {
      var current = typeof shell.getCurrentSection === "function" ? shell.getCurrentSection() : null;
      if (force || current !== stepDef.section) { var navigation; try { navigation = await shell.showSection(stepDef.section); } catch (_) { navigation = null; } if (!navigation || navigation.ok !== true) { setGuideUnavailable("Não foi possível abrir a área desta etapa.", false, true); return false; } }
    }
    if (!activeGuide || activeGuide !== guide || guide.navigationId !== navigationId) return false;
    var ready = await findAndBindTarget(stepDef, guide, navigationId); if (ready) bindCompletionEvent(stepDef, guide); return ready;
  }
  function infoBlock(label, text, className) { if (!text) return null; return el("div", { class: "extuiaGuideInfo " + className }, [el("strong", { text: label }), el("span", { text: text })]); }
  async function renderGuide() {
    if (!activeGuide) return;
    var guide = activeGuide, renderId = ++guide.renderId, stepDef = guide.lesson.steps[guide.index]; guide.actionDone = !stepDef.actionRequired;
    if (guide.completionEvent) window.removeEventListener(guide.completionEvent, guide.completionHandler); guide.completionEvent = null; guide.completionHandler = null; guide.root.innerHTML = "";
    guide.root.appendChild(el("div", { class: "extuiaGuideHead" }, [el("div", {}, [el("span", { class: "extuiaEyebrow", text: guide.lesson.number + " · " + guide.lesson.title }), el("strong", { id: "extuiaGuideTitle", text: stepDef.title })]), el("button", { type: "button", class: "extuiaGuideClose", "aria-label": "Sair do tutorial", text: "Sair", onClick: function () { if (academyMachine) academyMachine.exit("guide-close"); cleanupGuide(); } })]));
    var progress = el("div", { class: "extuiaGuideProgress", role: "progressbar", "aria-valuemin": "1", "aria-valuemax": String(guide.lesson.steps.length), "aria-valuenow": String(guide.index + 1) }); progress.appendChild(el("span", { style: "width:" + (((guide.index + 1) / guide.lesson.steps.length) * 100) + "%" })); guide.root.appendChild(progress);
    guide.root.appendChild(el("span", { class: "extuiaGuideStepCount", text: "Etapa " + (guide.index + 1) + " de " + guide.lesson.steps.length })); guide.root.appendChild(el("p", { class: "extuiaGuideCopy", text: stepDef.description }));
    [infoBlock("Faça agora", stepDef.doNow, "is-do"), infoBlock("Você deve ver", stepDef.expect, "is-expect"), infoBlock("Dica", stepDef.tip, "is-tip"), infoBlock("Atenção", stepDef.warning, "is-warning")].forEach(function (node) { if (node) guide.root.appendChild(node); });
    var actionState = el("div", { class: "extuiaGuideActionState", text: "Faça a ação indicada para liberar Próximo." }); actionState.hidden = !stepDef.actionRequired; guide.root.appendChild(actionState);
    var fallback = el("p", { class: "extuiaGuideFallback", text: "Não foi possível abrir esta etapa. Seu progresso continua salvo." }); fallback.hidden = true; guide.root.appendChild(fallback);
    var returnButton = el("button", { type: "button", class: "extui-btn extui-btn--secondary extuiaGuideReturn", text: "Retornar à etapa", "data-extuia-return": "true", onClick: function () { if (academyMachine) academyMachine.returnToStep(); } }); returnButton.hidden = true; guide.root.appendChild(returnButton);
    var recovery = el("div", { class: "extuiaGuideRecoveryActions", "data-extuia-recovery": "true" }); recovery.hidden = true; recovery.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--secondary", text: "Tentar novamente", onClick: function () { if (academyMachine) academyMachine.retry(); } })); recovery.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Pular etapa", onClick: async function () { var result = academyMachine ? await academyMachine.skipStep() : null; if (result && result.completed) showCenter(); } })); recovery.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Sair", onClick: function () { if (academyMachine) academyMachine.exit("recovery-exit"); cleanupGuide(); } })); guide.root.appendChild(recovery);
    var actions = el("div", { class: "extuiaGuideActions" }), skip = el("button", { type: "button", class: "extuiaGuideSkip", text: "Pular tutorial", onClick: async function () { if (academyMachine) await academyMachine.skipLesson(); showCenter(); } }), nav = el("div", { class: "extuiaGuideNav" });
    var back = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Voltar", onClick: previousGuideStep }); back.disabled = guide.index === 0;
    var next = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: guide.index === guide.lesson.steps.length - 1 ? "Concluir" : "Próximo", "data-extuia-action": "next", onClick: nextGuideStep }); next.disabled = !!stepDef.actionRequired;
    nav.appendChild(back); nav.appendChild(next); actions.appendChild(skip); actions.appendChild(nav); guide.root.appendChild(actions);
    var targetReady = await navigateGuideToStep(guide, stepDef, false); if (!activeGuide || activeGuide !== guide || guide.renderId !== renderId) return; if (!targetReady) recovery.hidden = false; scheduleGuideSpotlight(); (targetReady && !next.disabled ? next : recovery.querySelector("button"))?.focus({ preventScroll: true });
    return { ok: targetReady, targetReady: targetReady, error: targetReady ? null : "O alvo da etapa não ficou disponível." };
  }
  function openGuide(lesson, index) {
    if (!authorized()) return Promise.resolve({ ok: false, targetReady: false, error: "access-locked" }); cleanupGuide();
    var previousFocus = document.activeElement, focusLayer = el("div", { class: "extuiaSpotlightLayer", "aria-hidden": "true" }); focusLayer.innerHTML = '<div class="extuiaSpotlightMask" data-extuia-mask="full"></div><div class="extuiaSpotlightMask" data-extuia-mask="top"></div><div class="extuiaSpotlightMask" data-extuia-mask="left"></div><div class="extuiaSpotlightMask" data-extuia-mask="right"></div><div class="extuiaSpotlightMask" data-extuia-mask="bottom"></div><div class="extuiaSpotlight" hidden></div>';
    var root = el("aside", { class: "extuiaGuide", role: "dialog", "aria-modal": "false", "aria-labelledby": "extuiaGuideTitle" }); document.body.appendChild(focusLayer); document.body.appendChild(root);
    activeGuide = { root: root, focusLayer: focusLayer, lesson: lesson, index: index, observer: null, geometryObserver: null, layoutFrame: 0, target: null, targetClickHandler: null, completionEvent: null, completionHandler: null, keyHandler: null, sectionHandler: null, previousFocus: previousFocus, renderId: 0, navigationId: 0, actionDone: false };
    activeGuide.keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); if (academyMachine) academyMachine.exit("guide-escape"); cleanupGuide(); } };
    activeGuide.sectionHandler = function (event) { if (!activeGuide) return; var current = activeGuide.lesson.steps[activeGuide.index]; if (!current || !current.section || !event.detail || event.detail.section === current.section) return; releaseGuideTarget(activeGuide); if (academyMachine) academyMachine.suspend("manual-dashboard-navigation"); setGuideUnavailable("Você saiu da área desta etapa.", true, false); };
    document.addEventListener("keydown", activeGuide.keyHandler, true); document.addEventListener("ext:dashboard-section-change", activeGuide.sectionHandler); window.addEventListener("resize", scheduleGuideSpotlight); window.addEventListener("scroll", scheduleGuideSpotlight, true); return renderGuide();
  }
  async function navigateAcademyPosition(position, transition) { if (!authorized()) return { ok: false, targetReady: false, error: "access-locked" }; if (position.context === "whatsapp") { cleanupGuide(); return openWhatsappPosition(position, transition); } closeConnectionPrompt(); var lesson = lessonById(position.lessonId); if (!lesson) return { ok: false, targetReady: false, error: "Tutorial indisponível." }; var index = lesson.steps.findIndex(function (candidate) { return candidate.id === position.stepId; }); if (index < 0) return { ok: false, targetReady: false, error: "Etapa indisponível." }; if (!activeGuide || activeGuide.lesson.id !== lesson.id) return openGuide(lesson, index); activeGuide.index = index; return renderGuide(); }
  function createAcademyMachine() { var core = window.__extAcademyStateCore; if (!core || typeof core.createMachine !== "function") return null; return core.createMachine({ lessons: LESSONS, version: ACADEMY_VERSION, context: "dashboard", adapter: { readState: storageGet, writeState: storageReplace, isAuthorized: authorized, navigate: navigateAcademyPosition, onStateChange: function (snapshot) { if (snapshot.phase === core.PHASES.LOCKED) { cleanupGuide(); closeConnectionPrompt(); } } } }); }

  function renderCenter(container) {
    if (!authorized() || !container || !container.isConnected) return Promise.resolve(); cleanupGuide(); activeCenter = container;
    return storageGet().then(function (state) {
      if (!container.isConnected || !window.__extDashboardShell || window.__extDashboardShell.getCurrentSection() !== "academy" || activeGuide) return;
      var progress = progressOf(state); container.innerHTML = ""; var page = el("div", { class: "extuiaPage" }), header = el("header", { class: "extuiaHeader" });
      header.appendChild(el("div", {}, [el("span", { class: "extuiaEyebrow", text: "GUIAS PRÁTICOS · VERSÃO ATUAL" }), el("h1", { text: "Tutoriais" }), el("p", { text: "Aprenda cada área com instruções detalhadas, foco no controle real e progresso salvo entre Painel de Controle e WhatsApp." })]));
      var meter = el("div", { class: "extuiaMasterProgress", role: "progressbar", "aria-valuemin": "0", "aria-valuemax": String(progress.total), "aria-valuenow": String(progress.completed) }); meter.appendChild(el("strong", { text: progress.completed + "/" + progress.total })); meter.appendChild(el("span", { text: progress.completed === progress.total ? "tutoriais concluídos" : "tutoriais concluídos" })); var track = el("div", { class: "extuiaMasterTrack" }); LESSON_IDS.forEach(function (_, index) { track.appendChild(el("i", { class: index < progress.completed ? "is-done" : "" })); }); meter.appendChild(track); header.appendChild(meter); page.appendChild(header);
      var tools = el("div", { class: "extuiaCenterTools" }), search = el("input", { type: "search", class: "extuiaLessonSearch", placeholder: "Buscar funcionalidade ou tutorial...", "aria-label": "Buscar tutorial" }); tools.appendChild(search); page.appendChild(tools);
      page.appendChild(el("div", { class: "extuiaIntroLine" }, [el("span", { text: progress.completed === 0 ? "Comece pelo tutorial 01 e avance em sequência até o 13." : progress.completed === progress.total ? "Todos os tutoriais foram concluídos. Você pode refazer qualquer um." : "Continue do próximo tutorial da sequência 01–13." })]));
      var list = el("div", { class: "extuiaLessonList" }), empty = el("div", { class: "extuiaLessonSearchEmpty", text: "Nenhum tutorial encontrado para esta busca." }); empty.hidden = true;
      LESSONS.forEach(function (lesson) { var status = statusFor(lesson, state), row = el("article", { class: "extuiaLesson " + status.className, "data-extuia-search": (lesson.title + " " + lesson.description).toLowerCase() }); row.appendChild(el("span", { class: "extuiaLessonNumber", text: lesson.number })); var copy = el("div", { class: "extuiaLessonCopy" }); copy.appendChild(el("div", { class: "extuiaLessonTitleRow" }, [el("h2", { text: lesson.title }), el("span", { class: "extuiaLessonDuration", text: lesson.duration })])); copy.appendChild(el("p", { text: lesson.description })); row.appendChild(copy); row.appendChild(el("span", { class: "extuiaLessonStatus", text: status.label })); var button = el("button", { type: "button", class: "extui-btn " + (status.className === "is-progress" ? "extui-btn--primary" : "extui-btn--ghost"), text: status.action }); if (status.className === "is-locked") { button.disabled = true; button.setAttribute("aria-disabled", "true"); } else button.addEventListener("click", function () { if (status.className === "is-complete") restartLesson(lesson.id); else if (status.className === "is-progress") resumeLesson(lesson.id); else startLesson(lesson.id); }); row.appendChild(button); list.appendChild(row); });
      search.addEventListener("input", function () { var term = search.value.trim().toLowerCase(), shown = 0; list.querySelectorAll(".extuiaLesson").forEach(function (row) { var match = !term || row.getAttribute("data-extuia-search").indexOf(term) >= 0; row.hidden = !match; if (match) shown += 1; }); empty.hidden = shown !== 0; });
      page.appendChild(list); page.appendChild(empty); container.appendChild(page);
    });
  }

  async function resumeDashboardLesson() { if (!authorized() || !academyMachine) return; var state = await storageGet(), pending = state.pendingTransition; if (pending && pending.destinationContext === "dashboard") state = await storageSet({ pendingTransition: null, lastCompletedTransitionId: pending.id || pending.transitionId || null }); var required = firstIncompleteLessonId(state); if (!required) return; if (state.currentLessonId && state.currentLessonId !== required) { var hadActive = !!state.currentLessonId; state = await storageSet({ currentLessonId: null, currentStepId: null, currentContext: null, pendingTransition: null }); if (hadActive) await academyMachine.startLesson(required); return; } if (!state.currentLessonId || state.currentContext === "whatsapp") return; await academyMachine.resumeLesson(required); }

  if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") window.ExtensionStorage.subscribe(STORAGE_KEY, function () { var shell = window.__extDashboardShell, open = !!(shell && shell.getCurrentSection && shell.getCurrentSection() === "academy"); if (authorized() && open && !activeGuide && activeCenter && activeCenter.isConnected) renderCenter(activeCenter); });
  academyMachine = createAcademyMachine();
  window.__extAcademy = { showCenter: showCenter, startLesson: startLesson, resumeLesson: resumeLesson, restartLesson: restartLesson, progressOf: progressOf, coverage: Object.assign({}, ACADEMY_COVERAGE), lessons: LESSON_IDS.slice(), getState: function () { return academyMachine ? academyMachine.getSnapshot() : null; } };
  if (window.__extDashboardShell) window.__extDashboardShell.registerSection("academy", renderCenter);
  document.addEventListener("DOMContentLoaded", function () { if (authorized()) resumeDashboardLesson(); });
  window.addEventListener("ext:access-state", function (event) { var detail = event.detail || {}; if (detail.state === "AUTHORIZED") resumeDashboardLesson(); else { if (academyMachine) academyMachine.lock("access-locked-live"); cleanupGuide(); closeConnectionPrompt(); } });
})();

}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
