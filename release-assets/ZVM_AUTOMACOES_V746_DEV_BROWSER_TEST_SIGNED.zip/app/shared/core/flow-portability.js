(function(root){
  "use strict";
  if(root.ExtensionFlowPortability)return;
  var FORMAT="zvm-flow",SCHEMA_VERSION=2,MAX_BYTES=4*1024*1024,MAX_NODES=600,MAX_GROUPS=120,MAX_DEPTH=40,MAX_OBJECTS=20000,MAX_ID_LEN=160,MAX_EXPECTED_MESSAGES=100;
  function err(code,message){var e=new Error(message);e.code=code;return e;}
  function clone(v){return JSON.parse(JSON.stringify(v));}
  function uid(){return root.crypto&&root.crypto.randomUUID?root.crypto.randomUUID():"flow-"+Date.now()+"-"+Math.random().toString(36).slice(2,10);}
  function stable(v,depth){depth=depth||0;if(depth>MAX_DEPTH)throw err("FLOW_IMPORT_TOO_DEEP","O arquivo de Fluxo possui profundidade excessiva.");if(v===null||typeof v!=="object")return JSON.stringify(v);if(Array.isArray(v))return"["+v.map(function(x){return stable(x,depth+1);}).join(",")+"]";var keys=Object.keys(v).sort();return"{"+keys.map(function(k){return JSON.stringify(k)+":"+stable(v[k],depth+1);}).join(",")+"}";}
  function utf8(s){return new TextEncoder().encode(String(s));}
  async function sha256Hex(s){if(!root.crypto||!root.crypto.subtle)throw err("FLOW_EXPORT_CRYPTO_UNAVAILABLE","A verificação criptográfica de Fluxos não está disponível.");var b=new Uint8Array(await root.crypto.subtle.digest("SHA-256",utf8(s))),out="";for(var i=0;i<b.length;i++)out+=b[i].toString(16).padStart(2,"0");return out;}
  function safeId(value){var id=String(value==null?"":value);return id&&id.length<=MAX_ID_LEN?id:"";}
  function assertStructureLimits(value){var stack=[{value:value,depth:0}],seen=typeof WeakSet!=="undefined"?new WeakSet():null,count=0;while(stack.length){var item=stack.pop(),v=item.value,depth=item.depth;if(depth>MAX_DEPTH)throw err("FLOW_IMPORT_TOO_DEEP","O arquivo de Fluxo possui profundidade excessiva.");if(v===null||typeof v!=="object")continue;if(seen){if(seen.has(v))throw err("FLOW_IMPORT_SCHEMA_INVALID","O arquivo de Fluxo contém uma estrutura circular inválida.");seen.add(v);}count++;if(count>MAX_OBJECTS)throw err("FLOW_IMPORT_COMPLEXITY_LIMIT","O arquivo de Fluxo possui estruturas demais.");var keys=Object.keys(v);for(var i=0;i<keys.length;i++){var key=keys[i];if(key==="__proto__")throw err("FLOW_IMPORT_UNSAFE_FIELD","O arquivo de Fluxo contém um campo inseguro.");stack.push({value:v[key],depth:depth+1});}}return true;}
  function targets(node){var out=[];(Array.isArray(node&&node.nextNodeIds)?node.nextNodeIds:[]).forEach(function(id){if(id!=null)out.push(String(id));});[node&&node.nextNodeIdOnExpiration,node&&node.nextNodeIdOnDifferentAnswer,node&&node.nextNodeIdOnConditionFalse].forEach(function(id){if(id!=null)out.push(String(id));});(node&&node.data&&Array.isArray(node.data.weights)?node.data.weights:[]).forEach(function(w){if(w&&w.nextNodeId!=null)out.push(String(w.nextNodeId));});return out;}
  function canonicalNodeGroups(flow){if(Array.isArray(flow&&flow.nodeGroups))return flow.nodeGroups;if(Array.isArray(flow&&flow.groups))return flow.groups;return[];}
  function validateFlow(flow,options){
    options=options&&typeof options==="object"?options:{};var allowLegacyStartGroup=options.allowLegacyStartGroup===true;
    if(!flow||typeof flow!=="object"||Array.isArray(flow))throw err("FLOW_IMPORT_SCHEMA_INVALID","O Fluxo importado não possui uma estrutura válida.");
    assertStructureLimits(flow);
    var nodes=Array.isArray(flow.nodes)?flow.nodes:[];
    if(!nodes.length||nodes.length>MAX_NODES)throw err("FLOW_IMPORT_NODE_LIMIT","O Fluxo possui uma quantidade inválida de etapas.");
    var seen=Object.create(null),nodeById=Object.create(null),issues=[];
    nodes.forEach(function(n){var id=n&&typeof n==="object"?safeId(n.id):"";if(!id)issues.push("node_without_id");else if(seen[id])issues.push("duplicate_node_id:"+id);else{seen[id]=true;nodeById[id]=n;}if(n&&n.type==="userInput"&&n.data&&Array.isArray(n.data.expectedMessages)){if(n.data.expectedMessages.length>MAX_EXPECTED_MESSAGES)issues.push("too_many_expected_messages:"+id);else if(n.data.expectedMessages.length!==(Array.isArray(n.nextNodeIds)?n.nextNodeIds.length:0))issues.push("answer_route_count:"+id);}if(n&&n.type==="randomizer"){var weights=n.data&&Array.isArray(n.data.weights)?n.data.weights:[];if(weights.length<2)issues.push("randomizer_route_count:"+id);weights.forEach(function(w){if(!w||!(Number(w.weight)>0)||!safeId(w.nextNodeId))issues.push("randomizer_route_invalid:"+id);});}});
    nodes.forEach(function(n){targets(n).forEach(function(id){if(!seen[id])issues.push("dangling_target:"+id);});});
    var startId=safeId(flow.startNodeId),fallbackStart=nodes.find(function(n){return n&&n.type==="start"&&safeId(n.id);});if(startId&&!seen[startId])issues.push("invalid_start_node:"+startId);if(!startId&&!fallbackStart)issues.push("missing_start_node");
    var groups=canonicalNodeGroups(flow);if(groups.length>MAX_GROUPS)throw err("FLOW_IMPORT_GROUP_LIMIT","O Fluxo possui grupos demais.");
    var groupSeen=Object.create(null),ownedNode=Object.create(null);
    groups.forEach(function(g){var gid=g&&typeof g==="object"?safeId(g.id):"";if(!gid)issues.push("group_without_id");else if(groupSeen[gid])issues.push("duplicate_group_id:"+gid);else groupSeen[gid]=true;var members=Array.isArray(g&&g.memberNodeIds)?g.memberNodeIds:[];if(members.length<2)issues.push("group_too_small:"+gid);members.forEach(function(id){id=String(id);if(!seen[id])issues.push("dangling_group_member:"+id);else if(nodeById[id]&&nodeById[id].type==="start"&&!allowLegacyStartGroup)issues.push("start_group_member:"+id);if(ownedNode[id])issues.push("duplicate_group_owner:"+id);ownedNode[id]=gid;});});
    if(issues.length)throw err("FLOW_IMPORT_REFERENCES_INVALID","O Fluxo possui referências internas inválidas: "+issues.slice(0,8).join(", "));
    return{nodeCount:nodes.length,groupCount:groups.length};
  }
  function dependencyList(flow){var deps=[],seen=Object.create(null);function add(type,id,name){if(!id)return;var key=type+":"+id;if(seen[key])return;seen[key]=true;deps.push({type:type,id:String(id),name:name?String(name):null});}(flow.nodes||[]).forEach(function(n){var d=n&&n.data||{};if(/^send/.test(String(n&&n.type||""))&&d.itemId)add("library",d.itemId,d.label||d.name);if(n&&n.type==="aiGenerate"&&d.assistantId)add("assistant",d.assistantId,d.assistantName);if(n&&n.type==="aiAgent"&&d.agentId)add("agent",d.agentId,d.agentName);if(n&&n.type==="moveToColumn"&&d.crmId)add("crm",d.crmId,d.crmName);if(n&&n.type==="condition"&&d.crmId)add("crm",d.crmId,d.crmName);});return deps;}
  function normalizeGroupsForExport(flow){var copy=clone(flow),groups=canonicalNodeGroups(copy),nodes=Array.isArray(copy.nodes)?copy.nodes:[],byId=Object.create(null);nodes.forEach(function(n){if(n&&n.id!=null)byId[String(n.id)]=n;});copy.nodeGroups=clone(groups).map(function(g){var next=g&&typeof g==="object"?g:{};next.memberNodeIds=(Array.isArray(next.memberNodeIds)?next.memberNodeIds:[]).map(String).filter(function(id){return !(byId[id]&&byId[id].type==="start");});return next;}).filter(function(g){return Array.isArray(g.memberNodeIds)&&g.memberNodeIds.length>=2;});delete copy.groups;return copy;}
  async function exportFlow(flow,sourceVersion){validateFlow(flow);var exportedFlow=normalizeGroupsForExport(flow);exportedFlow.isActive=false;var base={format:FORMAT,schemaVersion:SCHEMA_VERSION,exportedAt:new Date().toISOString(),sourceVersion:String(sourceVersion||""),flow:exportedFlow,dependencies:dependencyList(exportedFlow)};var digest=await sha256Hex(stable(base));return Object.assign(base,{integrity:{sha256:digest}});}
  function remapFlow(flow){
    var copy=normalizeGroupsForExport(flow),nodeMap=Object.create(null),groupMap=Object.create(null);
    (copy.nodes||[]).forEach(function(n){nodeMap[String(n.id)]=uid();});
    (copy.nodeGroups||[]).forEach(function(g){groupMap[String(g.id)]=uid();});
    function map(id){return id==null?id:(nodeMap[String(id)]||null);}
    copy.id=uid();copy.name=String(copy.name||"Fluxo importado").slice(0,120);copy.isActive=false;copy.createdAtInMs=Date.now();copy.updatedAtInMs=copy.createdAtInMs;
    copy.nodes=(copy.nodes||[]).map(function(n){n.id=nodeMap[String(n.id)];n.nextNodeIds=(Array.isArray(n.nextNodeIds)?n.nextNodeIds:[]).map(map).filter(Boolean);n.nextNodeIdOnExpiration=map(n.nextNodeIdOnExpiration);n.nextNodeIdOnDifferentAnswer=map(n.nextNodeIdOnDifferentAnswer);n.nextNodeIdOnConditionFalse=map(n.nextNodeIdOnConditionFalse);if(n.data&&Array.isArray(n.data.weights))n.data.weights=n.data.weights.map(function(w){var next={};Object.keys(w&&typeof w==="object"?w:{}).forEach(function(k){if(k!=="__proto__")next[k]=w[k];});next.nextNodeId=map(w&&w.nextNodeId);return next;});return n;});
    copy.startNodeId=map(copy.startNodeId)||((copy.nodes||[]).find(function(n){return n.type==="start";})||{}).id||null;
    copy.nodeGroups=(copy.nodeGroups||[]).map(function(g){g.id=groupMap[String(g.id)]||uid();g.memberNodeIds=(Array.isArray(g.memberNodeIds)?g.memberNodeIds:[]).map(map).filter(Boolean);g.updatedAtInMs=Date.now();return g;});
    delete copy.groups;
    return copy;
  }
  function sanitizeParsed(raw){var text;try{text=typeof raw==="string"?raw:JSON.stringify(raw);}catch(_){throw err("FLOW_IMPORT_JSON_INVALID","O arquivo selecionado não contém JSON válido.");}if(utf8(text).byteLength>MAX_BYTES)throw err("FLOW_IMPORT_TOO_LARGE","O arquivo de Fluxo excede o limite permitido.");var obj;try{obj=typeof raw==="string"?JSON.parse(raw):clone(raw);}catch(_){throw err("FLOW_IMPORT_JSON_INVALID","O arquivo selecionado não contém JSON válido.");}assertStructureLimits(obj);return obj;}
  var adapters=[];function registerAdapter(adapter){if(adapter&&typeof adapter.detect==="function"&&typeof adapter.convert==="function")adapters.push(adapter);}
  async function importAny(raw){
    var obj=sanitizeParsed(raw);
    if(obj&&obj.format===FORMAT){
      if(Number(obj.schemaVersion)!==1&&Number(obj.schemaVersion)!==SCHEMA_VERSION)throw err("FLOW_IMPORT_SCHEMA_UNSUPPORTED","Esta versão do formato .zflow ainda não é compatível.");
      if(!obj.integrity||!/^[a-f0-9]{64}$/i.test(String(obj.integrity.sha256||"")))throw err("FLOW_IMPORT_CHECKSUM_MISSING","O arquivo .zflow não possui integridade válida.");
      var comparable=clone(obj);delete comparable.integrity;var actual=await sha256Hex(stable(comparable));if(actual!==String(obj.integrity.sha256).toLowerCase())throw err("FLOW_IMPORT_TAMPERED","A integridade do arquivo .zflow não confere.");
      validateFlow(obj.flow,{allowLegacyStartGroup:Number(obj.schemaVersion)===1});var imported=remapFlow(obj.flow);validateFlow(imported);
      return{format:FORMAT,flow:imported,dependencies:Array.isArray(obj.dependencies)?clone(obj.dependencies):dependencyList(imported),warnings:Number(obj.schemaVersion)===1?[{code:"FLOW_IMPORT_SCHEMA_MIGRATED",message:"Fluxo .zflow v1 migrado para o formato atual com grupos canônicos."}]:[],sourceVersion:obj.sourceVersion||null};
    }
    for(var i=0;i<adapters.length;i++){
      if(adapters[i].detect(obj)){
        var analysis=typeof adapters[i].analyze==="function"?adapters[i].analyze(obj):{warnings:[]},converted=await adapters[i].convert(obj);validateFlow(converted);var remapped=remapFlow(converted);validateFlow(remapped);return{format:adapters[i].id||"external",flow:remapped,dependencies:dependencyList(remapped),warnings:analysis&&Array.isArray(analysis.warnings)?analysis.warnings:[]};
      }
    }
    throw err("FLOW_IMPORT_FORMAT_UNSUPPORTED","Este formato de Fluxo não é reconhecido. Exporte como .zflow ou use um formato compatível.");
  }
  root.ExtensionFlowPortability=Object.freeze({FORMAT:FORMAT,SCHEMA_VERSION:SCHEMA_VERSION,MAX_BYTES:MAX_BYTES,MAX_NODES:MAX_NODES,MAX_GROUPS:MAX_GROUPS,MAX_DEPTH:MAX_DEPTH,validateFlow:validateFlow,dependencyList:dependencyList,exportFlow:exportFlow,importAny:importAny,registerAdapter:registerAdapter,stableStringify:stable});
})(typeof window!=="undefined"?window:globalThis);
