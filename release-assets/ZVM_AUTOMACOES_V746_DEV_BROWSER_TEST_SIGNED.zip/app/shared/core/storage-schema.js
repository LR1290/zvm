(function (root) {
  "use strict";

  try {
  if (root.__extStorageSchema) return;

  var SCHEMA_VERSION = 1;
  var LEDGER_KEY = "EXTUI:storageMigrationState";
  var isDashboard = !!(root.document && root.location && root.location.protocol === "chrome-extension:" && /\/pages\/dashboard(?:\/|$)/.test(root.location.pathname || ""));

  function entry(key, domain, options) {
    options = options || {};
    return {
      key: key,
      domain: domain,
      schemaVersion: options.schemaVersion == null ? 1 : options.schemaVersion,
      codec: options.codec || "opaque",
      owner: options.owner || "extapp",
      binaryPolicy: options.binaryPolicy || "metadata-only",
      migration: options.migration || "preserve",
    };
  }

  var entries = [
    entry("EXTUI:extappScheduleStore", "agenda", { codec: "json" }),
    entry("EXTUI:extappFlowStore", "fluxos", { codec: "zustand-json" }),
    entry("EXTUI:extappFlowRunningStore", "fluxos", { codec: "json" }),
    entry("EXTUI:extappFunnelStore", "funis", { codec: "zustand-json" }),
    entry("EXTUI:extappFunnelRunningStore", "funis", { codec: "json" }),
    entry("EXTUI:extappFollowUpStore", "followup", { codec: "zustand-json" }),
    entry("EXTUI:extappFollowUpQueueStore", "followup", { codec: "zustand-json" }),
    entry("EXTUI:extappFollowUpMembershipStore", "followup", { codec: "json" }),
    entry("EXTUI:extappAutoServiceStore", "auto-service", { codec: "json" }),
    entry("EXTUI:extappWebhookStore", "webhooks", { codec: "zustand-json" }),
    entry("EXTUI:webhookSecrets", "webhook-secrets", { codec: "opaque" }),
    entry("EXTUI:CrmStore", "crm", { codec: "zustand-json" }),
    entry("EXTUI:crmProfessionalStore", "crm", { codec: "json" }),
    entry("EXTUI:crmCopilotPreferences", "crm", { codec: "json" }),
    entry("EXTUI:crmFunnelAnalyticsStore", "crm", { codec: "json" }),
    entry("EXTUI:extappActivityStore", "activity", { codec: "json" }),
    entry("EXTUI:extappSeenChatsStore", "chat-state", { codec: "zustand-json" }),
    entry("EXTUI:extappLastSeenDateStore", "chat-state", { codec: "zustand-json" }),
    entry("EXTUI:extappOptionsStore", "settings", { codec: "zustand-json" }),
    entry("EXTUI:greetingMessagesStore", "settings", { codec: "json" }),
    entry("EXTUI:signaturesStore", "quick-items", { codec: "json" }),
    entry("EXTUI:onboardingState", "settings", { codec: "json" }),
    entry("EXTUI:extappQuickResponseStore", "quick-responses", { codec: "json" }),
    entry("EXTUI:textMessageStore", "quick-items", { codec: "zustand-json" }),
    entry("EXTUI:audioStore", "quick-items", { codec: "zustand-json", binaryPolicy: "reference-only" }),
    entry("EXTUI:mediaStore", "quick-items", { codec: "zustand-json", binaryPolicy: "reference-only" }),
    entry("EXTUI:documentStore", "quick-items", { codec: "zustand-json", binaryPolicy: "reference-only" }),
    entry("EXTUI:stickerStore", "quick-items", { codec: "zustand-json", binaryPolicy: "reference-only" }),
    entry("EXTUI:pixStore", "quick-items", { codec: "zustand-json" }),
    entry("EXTUI:interactiveListStore", "quick-items", { codec: "zustand-json" }),
    entry("EXTUI:contactCardStore", "quick-items", { codec: "zustand-json" }),
    entry("EXTUI:labelStore", "labels", { codec: "zustand-json" }),
    entry("EXTUI:quickItemsRecents", "quick-items", { codec: "json" }),
    entry("EXTUI:trashStore", "lixeira", { codec: "json", binaryPolicy: "reference-only" }),
    entry("EXTUI:backupSettings", "cópia de segurança", { codec: "json" }),
    entry("EXTUI:autoBackupFileIndex", "cópia de segurança", { codec: "json", binaryPolicy: "metadata-only" }),
    entry("EXTUI:statusScheduleStore", "status", { codec: "json" }),
    entry("EXTUI:notificationStore", "notifications", { codec: "json" }),
    entry("EXTUI:notificationCenterFeed", "notifications", { codec: "json" }),
    entry("EXTUI:notificationCenterRead", "notifications", { codec: "json" }),
    entry("EXTUI:contactMetadataStore", "contacts", { codec: "json" }),
    entry("EXTUI:customerStore", "customers", { codec: "json" }),
    entry("EXTUI:audioTranscriptionStore", "transcriptions", { codec: "json" }),
    entry("EXTUI:audioTranscriptionSettings", "ai", { codec: "json" }),
    entry("EXTUI:aiTranslationSettings", "ai", { codec: "json" }),
    entry("EXTUI:aiQuickDefaults", "ai", { codec: "json" }),
    entry("EXTUI:replacementStore", "chat-surface", { codec: "json" }),
    entry("EXTUI:chatCapabilities", "chat-surface", { codec: "json" }),
    entry("EXTUI:userTabsStore", "chat-surface", { codec: "json" }),
    entry("EXTUI:profileStore", "contacts", { codec: "json" }),
    entry("EXTUI:agendaMessagesStore", "agenda", { codec: "json" }),
    entry("EXTUI:flowFilesStore", "fluxos", { codec: "json", binaryPolicy: "reference-only" }),
    entry("EXTUI:quickAssetsStore", "quick-responses", { codec: "json", binaryPolicy: "reference-only" }),
    entry("EXTUI:bulkGroupsStore", "disparos", { codec: "json" }),
    entry("EXTUI:pinnedChatsStore", "chat-state", { codec: "json" }),
    entry("EXTUI:trackingStore", "tracking", { codec: "json" }),
    entry("EXTUI:trackingSecrets", "tracking-secrets", { codec: "opaque" }),
    entry("EXTUI:meetCalendarStore", "meet-calendar", { codec: "json" }),
    entry("EXTUI:ordersStore", "orders", { codec: "json" }),
    entry("EXTUI:deliveryCouriersStore", "orders", { codec: "json" }),
    entry("EXTUI:deliverySettingsStore", "orders", { codec: "json" }),
    entry("EXTUI:activityCenterStore", "activities", { codec: "json" }),
    entry("EXTUI:adaptiveWorkspaceStore", "dashboard-ui", { codec: "json", migration: "preserve-ui" }),
    entry("EXTUI:disparosHistory", "disparos", { codec: "json" }),
    entry("EXTUI:disparosJourneys", "disparos", { codec: "json" }),
    entry("EXTUI:disparosLastType", "disparos", { codec: "plain" }),
    entry("ext:bulkQueue", "disparos", { codec: "json" }),
    entry("EXTUI:aiAgentsStore", "ai", { codec: "json" }),
    entry("EXTUI:aiAssistantsStore", "ai", { codec: "json" }),
    entry("EXTUI:aiAssistantDraftStore", "ai-drafts", { codec: "json", migration: "preserve-work-in-progress" }),
    entry("EXTUI:aiMemoryStore", "ai", { codec: "json" }),
    entry("EXTUI:integrationsStore", "integrations", { codec: "json" }),
    entry("EXTUI:integrationSecrets", "integrations", { codec: "opaque" }),
    entry("EXTUI:externalActionsStore", "integrations", { codec: "json" }),
    entry("EXTUI:externalActionSecrets", "integrations", { codec: "opaque" }),
    entry("EXTUI:knowledgeBasesStore", "knowledge", { codec: "json" }),
    entry("EXTUI:license", "license", { codec: "json", owner: "native-extapp", migration: "preserve-native" }),
    entry("EXTUI:licenseSecret", "license-secret", { codec: "opaque", owner: "native-extapp", migration: "preserve-native" }),
    entry("EXTUI:licenseSecretVault", "license-secret", { codec: "opaque", owner: "native-extapp", migration: "preserve-native" }),
    entry("EXTUI:deviceId", "license", { codec: "plain", owner: "native-extapp", migration: "preserve-native" }),
    entry("EXTUI:wppPhoneNumber", "wpp-context", { codec: "plain" }),
    entry("EXTUI:wppStatus", "wpp-context", { codec: "plain" }),
    entry("EXTUI:extappDashboardSidebarCompact", "dashboard-ui", { codec: "plain" }),
    entry("EXTUI:extappDashboardRailPinned", "dashboard-ui", { codec: "plain", migration: "preserve-ui" }),
    entry("EXTUI:extappGlobalFavorites", "experience", { codec: "json" }),
    entry("EXTUI:extappAchievements", "experience", { codec: "json" }),
    entry("EXTUI:extappEasterEggs", "experience", { codec: "json" }),
    entry("EXTUI:extappTemplateInstallations", "experience", { codec: "json" }),
    entry("EXTUI:extappAppearanceStore", "dashboard-ui", { codec: "json", migration: "preserve-ui" }),
    entry("EXTUI:dashboardMenuVisibilityStore", "dashboard-ui", { codec: "json", migration: "preserve-ui" }),
    entry("EXTUI:sidebarV2", "sidebar-ui", { codec: "json", migration: "preserve-ui" }),
    entry("EXTUI:extappRailPinned", "sidebar-ui", { codec: "plain", migration: "preserve-ui" }),
    entry("EXTUI:metaOfficialConfig", "integrations", { codec: "json" }),
    entry("EXTUI:privacyOptions", "personalization", { codec: "json", migration: "preserve-ui" }),
    entry("EXTUI:quotaStore", "quota", { codec: "zustand-json" }),
                                                                      
  ];

  if (isDashboard) {
    var experience = Object.create(null);
    ["EXTUI:extappGlobalFavorites","EXTUI:extappAchievements","EXTUI:extappEasterEggs","EXTUI:extappTemplateInstallations"].forEach(function (key) { experience[key] = true; });
    var moved = [];
    entries = entries.filter(function (item) { if (experience[item.key]) { moved.push(item); return false; } return true; });
    var activityIndex = entries.findIndex(function (item) { return item.key === "EXTUI:extappActivityStore"; });
    entries.splice.apply(entries, [activityIndex + 1, 0].concat(moved));
  }

  var byKey = Object.create(null);
  entries.forEach(function (e) { byKey[e.key] = e; });

  function describe(key) { return byKey[key] || null; }

  function canonicalKey(key) { return key; }

  function safeParse(raw, fallback) {
    if (raw == null || raw === "") return fallback === undefined ? null : fallback;
    if (typeof raw !== "string") return raw;
    try { return JSON.parse(raw); } catch (err) { return fallback === undefined ? raw : fallback; }
  }

  function parseZustand(raw, fallbackState) {
    var parsed = safeParse(raw, null);
    if (!parsed || typeof parsed !== "object") return { state: fallbackState || {}, version: 0 };
    if (!parsed.state || typeof parsed.state !== "object") parsed.state = fallbackState || {};
    if (typeof parsed.version !== "number") parsed.version = 0;
    return parsed;
  }

  function serialize(value, codec) {
    if (codec === "plain" || codec === "opaque") return value;
    if (typeof value === "string") return value;
    return JSON.stringify(value);
  }

  root.__extStorageSchema = Object.freeze({
    version: "1.0.0",
    schemaVersion: SCHEMA_VERSION,
    ledgerKey: LEDGER_KEY,
    entries: entries.slice(),
    byKey: byKey,
    describe: describe,
    canonicalKey: canonicalKey,
    safeParse: safeParse,
    parseZustand: parseZustand,
    serialize: serialize
  });
  } catch (err) {
    if (root.document && typeof root.__extRecordBootError === "function") { root.__extRecordBootError(err); return; }
    throw err;
  }
})(typeof self !== "undefined" ? self : globalThis);
