(function(root){
  "use strict";
  var portability=root.ExtensionFlowPortability;if(!portability||typeof portability.registerAdapter!=="function")return;
  var MAX_NODES=600,MAX_EDGES=2400,MAX_EXPECTED=100;
  function fail(code,message){var e=new Error(message);e.code=code;throw e;}
  function text(v,max){return String(v==null?"":v).slice(0,max||4000);}
  function detect(raw){return !!(raw&&typeof raw==="object"&&!Array.isArray(raw)&&Array.isArray(raw.nodes)&&Array.isArray(raw.edges)&&!raw.format);}
  function mapType(t){t=String(t||"").toLowerCase();if(t==="start")return"start";if(t==="input"||t==="userinput")return"userInput";if(t==="message"||t==="text"||t==="sendtext")return"sendText";if(t==="human"||t==="handoff")return"endHuman";if(t==="end")return"end";return"unsupported";}
  function edgeLabel(e){var d=e&&e.data&&typeof e.data==="object"?e.data:{};var raw=e&&e.label!=null?e.label:(d.label!=null?d.label:(d.value!=null?d.value:(e&&e.sourceHandle!=null?e.sourceHandle:"")));return text(raw,240).trim();}
  function normalizeAnswer(v){return text(v,240).trim().toLocaleLowerCase("pt-BR");}
  function inspect(raw){
    if(!detect(raw))fail("FLOW_EXTERNAL_FORMAT_INVALID","O arquivo externo não possui a estrutura node/edge esperada.");
    if(raw.nodes.length<1)fail("FLOW_EXTERNAL_EMPTY","O Fluxo externo não possui etapas.");
    if(raw.nodes.length>MAX_NODES)fail("FLOW_EXTERNAL_NODE_LIMIT","O Fluxo externo excede o limite de "+MAX_NODES+" etapas.");
    if(raw.edges.length>MAX_EDGES)fail("FLOW_EXTERNAL_EDGE_LIMIT","O Fluxo externo excede o limite de "+MAX_EDGES+" conexões.");
    var seen=Object.create(null),warnings=[];
    raw.nodes.forEach(function(n,i){
      if(!n||typeof n!=="object")fail("FLOW_EXTERNAL_NODE_INVALID","Existe uma etapa externa inválida na posição "+(i+1)+".");
      var id=text(n.id,161);
      if(!id||id.length>160)fail("FLOW_EXTERNAL_NODE_ID_INVALID","Existe uma etapa externa sem identificador válido.");
      if(seen[id])fail("FLOW_EXTERNAL_DUPLICATE_NODE_ID","O Fluxo externo possui identificadores de etapa duplicados.");
      seen[id]=true;
      if(mapType(n.type)==="unsupported")warnings.push({code:"FLOW_EXTERNAL_UNSUPPORTED_NODE",nodeId:id,message:"A etapa externa “"+text(n.type||"sem tipo",80)+"” não possui equivalente direto e exigirá revisão."});
    });
    raw.edges.forEach(function(e){
      var from=text(e&&e.source,161),to=text(e&&e.target,161);
      if(!seen[from]||!seen[to])warnings.push({code:"FLOW_EXTERNAL_DANGLING_EDGE",message:"Uma conexão externa aponta para uma etapa inexistente e será ignorada."});
    });
    return{seen:seen,warnings:warnings};
  }
  function analyze(raw){
    var inspected=inspect(raw),warnings=inspected.warnings.slice(),outgoing=Object.create(null);
    raw.edges.forEach(function(e){var from=String(e&&e.source==null?"":e.source);if(!outgoing[from])outgoing[from]=[];outgoing[from].push({target:String(e&&e.target==null?"":e.target),label:edgeLabel(e)});});
    raw.nodes.forEach(function(src){var id=String(src.id),type=mapType(src.type),list=outgoing[id]||[],d=src.data&&typeof src.data==="object"?src.data:{};if(type==="userInput"){var answers=Array.isArray(d.expectedMessages)?d.expectedMessages:(Array.isArray(d.answers)?d.answers:[]);if(answers.length){var labels=Object.create(null),amb=false;list.forEach(function(e){var k=normalizeAnswer(e.label);if(!k||labels[k]&&labels[k]!==e.target)amb=true;labels[k]=e.target;});answers.slice(0,MAX_EXPECTED).forEach(function(a){if(!labels[normalizeAnswer(a)])amb=true;});if(amb)warnings.push({code:"FLOW_EXTERNAL_AMBIGUOUS_ROUTES",nodeId:id,message:"Uma etapa de resposta possui rotas ambíguas e será importada como não suportada para revisão."});}else if(list.length>1)warnings.push({code:"FLOW_EXTERNAL_AMBIGUOUS_ROUTES",nodeId:id,message:"Uma etapa de resposta possui múltiplas saídas sem respostas rotuladas e será importada como não suportada."});}else if((type==="start"||type==="sendText")&&list.length>1)warnings.push({code:"FLOW_EXTERNAL_AMBIGUOUS_BRANCH",nodeId:id,message:"Uma etapa externa possui múltiplas saídas sem condição equivalente e exigirá revisão."});else if((type==="end"||type==="endHuman")&&list.length)warnings.push({code:"FLOW_EXTERNAL_TERMINAL_WITH_OUTPUT",nodeId:id,message:"Uma etapa terminal externa possui saída adicional e exigirá revisão."});});
    return{warnings:warnings};
  }
  function makeUnsupported(node,src,d,reason,extra){
    node.type="unsupported";
    node.data={externalType:text(src&&src.type||"unknown",120),label:text(d.label||d.name||"Etapa externa",240),requiresReview:true,reviewReason:text(reason,600)};
    if(extra&&Array.isArray(extra.expectedMessages)&&extra.expectedMessages.length)node.data.expectedMessages=extra.expectedMessages.slice(0,MAX_EXPECTED);
    if(extra&&Number.isFinite(extra.routeCount))node.data.routeCount=Math.max(0,Math.floor(extra.routeCount));
  }
  function convert(raw){
    var inspection=inspect(raw),ids=Object.create(null),nodes=raw.nodes.map(function(src,i){
      var old=String(src.id),id="ext-"+i;ids[old]=id;
      var d=src.data&&typeof src.data==="object"?src.data:{},type=mapType(src.type);
      var node={id:id,type:type,position:{x:Number(src.position&&src.position.x)||0,y:Number(src.position&&src.position.y)||0},data:{},nextNodeIds:[]};
      if(type==="sendText")node.data.text=text(d.text||d.message||d.label,12000);
      else if(type==="userInput"){
        var answers=Array.isArray(d.expectedMessages)?d.expectedMessages:(Array.isArray(d.answers)?d.answers:[]);
        node.data.expectedMessages=answers.slice(0,MAX_EXPECTED).map(function(x){return text(x,240);});
      }else if(type==="unsupported")makeUnsupported(node,src,d,"Tipo de etapa externa sem equivalente seguro.");
      else if(d.label)node.data.label=text(d.label,240);
      return node;
    });
    var byId=Object.create(null),sourceByNew=Object.create(null),edgesBySource=Object.create(null);
    nodes.forEach(function(n,i){byId[n.id]=n;sourceByNew[n.id]=raw.nodes[i];});
    raw.edges.forEach(function(e){
      var from=ids[String(e&&e.source)],to=ids[String(e&&e.target)];
      if(!from||!to||!byId[from]||!byId[to])return;
      if(!edgesBySource[from])edgesBySource[from]=[];
      var duplicate=edgesBySource[from].some(function(item){return item.to===to&&item.label===edgeLabel(e);});
      if(!duplicate)edgesBySource[from].push({to:to,label:edgeLabel(e)});
    });
    nodes.forEach(function(n){
      var outgoing=edgesBySource[n.id]||[],src=sourceByNew[n.id]||{},d=src.data&&typeof src.data==="object"?src.data:{};
      n.nextNodeIds=outgoing.map(function(e){return e.to;});
      if(n.type==="userInput"){
        var expected=Array.isArray(n.data.expectedMessages)?n.data.expectedMessages:[];
        if(expected.length){
          var labelMap=Object.create(null),ambiguous=false;
          outgoing.forEach(function(e){var k=normalizeAnswer(e.label);if(!k){ambiguous=true;return;}if(labelMap[k]&&labelMap[k]!==e.to)ambiguous=true;labelMap[k]=e.to;});
          var aligned=[];
          expected.forEach(function(answer){var target=labelMap[normalizeAnswer(answer)];if(!target)ambiguous=true;aligned.push(target||null);});
          if(!ambiguous&&aligned.length===expected.length){n.nextNodeIds=aligned;}
          else makeUnsupported(n,src,d,"As respostas esperadas não puderam ser associadas de forma inequívoca às conexões externas.",{expectedMessages:expected,routeCount:outgoing.length});
        }else if(outgoing.length>1){
          makeUnsupported(n,src,d,"A etapa de resposta possui múltiplas saídas sem rótulos/respostas suficientes para preservar a decisão.",{routeCount:outgoing.length});
        }
      }else if((n.type==="start"||n.type==="sendText")&&outgoing.length>1){
        makeUnsupported(n,src,d,"Esta etapa externa possui múltiplas saídas, mas o equivalente da ZVM não preserva essa bifurcação sem uma condição explícita.",{routeCount:outgoing.length});
      }else if((n.type==="end"||n.type==="endHuman")&&outgoing.length){
        makeUnsupported(n,src,d,"Uma etapa terminal externa possui saída adicional e precisa de revisão manual.",{routeCount:outgoing.length});
      }
    });
    var start=(nodes.find(function(n){return n.type==="start";})||nodes[0]||{}).id;
    if(!start)fail("FLOW_EXTERNAL_EMPTY","O Fluxo externo não possui etapas utilizáveis.");
    return{id:"external-import",name:text(raw.name||raw.title||"Fluxo importado",120),description:"Importado de formato node/edge genérico. Revise etapas marcadas como não suportadas antes de ativar.",isActive:false,startNodeId:start,nodes:nodes,groups:[],trigger:{sendToContacts:true,sendToGroups:false},createdAtInMs:Date.now(),updatedAtInMs:Date.now(),importWarnings:inspection.warnings};
  }
  portability.registerAdapter({id:"generic-node-edge",detect:detect,analyze:analyze,convert:convert});
})(typeof window!=="undefined"?window:globalThis);
