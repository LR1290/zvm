;
try{
(function(root){
  "use strict";
  if(root.__extCreateBackupMigrationService)return;
  root.__extCreateBackupMigrationService=function(root,config){
    config=config||{};

  "use strict";

  var SETTINGS="EXTUI:backupSettings";
  var FILE_INDEX="EXTUI:autoBackupFileIndex";
  var VERSION=6;
  var EXCLUDED=new Set([
    SETTINGS,FILE_INDEX,"EXTUI:integrationSecrets","EXTUI:externalActionSecrets", "EXTUI:webhookSecrets",
    "EXTUI:trackingSecrets","EXTUI:aiMemoryStore","ext:bulkQueue","ext:bulkQueueCancelRequested","ext:bulkQueuePauseRequested",
    "EXTUI:license","EXTUI:licenseSecret","EXTUI:licenseSecretVault","EXTUI:backupProtectionSecret","EXTUI:deviceId","EXTUI:wppPhoneNumber","EXTUI:wppStatus"
  ]);
  var OWNER_BOUND_KEYS=Object.freeze(["EXTUI:extappAchievements","EXTUI:extappEasterEggs"]);
  var OWNER_BOUND_KEY_SET=new Set(OWNER_BOUND_KEYS);
  var OWNER_BOUND_VERSION=1;
  var SECRET_THEME_IDS=new Set(["matrix","aureus","retrowave","espresso","cosmos42","neoncore","zenith","signalrain","festivalpop","velocityred","glitchcore","portalvoid","brasaviva","oceanoazul","pixelpop"]);
  var CATEGORIES=Object.freeze({
    flows:{label:"Fluxos",keys:["EXTUI:extappFlowStore","EXTUI:flowFilesStore"]},
    funnels:{label:"Funis",keys:["EXTUI:extappFunnelStore"]},
    followups:{label:"FollowUp",keys:["EXTUI:extappFollowUpStore"]},
    items:{label:"Biblioteca",keys:["EXTUI:textMessageStore","EXTUI:audioStore","EXTUI:mediaStore","EXTUI:documentStore","EXTUI:stickerStore","EXTUI:pixStore","EXTUI:interactiveListStore","EXTUI:contactCardStore","EXTUI:quickItemsRecents","EXTUI:greetingMessagesStore","EXTUI:signaturesStore"],description:"Mensagens, áudios, imagens, vídeos, documentos, figurinhas, PIX, listas, contatos, assinaturas e itens recentes salvos na Biblioteca. Respostas Rápidas ficam na categoria própria."},
    quickResponses:{label:"Respostas Rápidas",keys:["EXTUI:extappQuickResponseStore","EXTUI:quickAssetsStore"],description:"Modelos de Respostas Rápidas e os arquivos vinculados a elas."},
    labels:{label:"Etiquetas locais (compatibilidade)",keys:["EXTUI:labelStore"],hidden:true,description:"Store local legado. As Etiquetas do WhatsApp são lidas diretamente da conta Business e não pertencem ao backup local da extensão."},
    crm:{label:"CRM",keys:["EXTUI:CrmStore","EXTUI:crmProfessionalStore","EXTUI:crmCopilotPreferences","EXTUI:crmFunnelAnalyticsStore"]},
    agenda:{label:"Agenda",keys:["EXTUI:extappScheduleStore","EXTUI:agendaMessagesStore","EXTUI:meetCalendarStore"]},
    bulk:{label:config.bulkLabel||"Disparos",keys:["EXTUI:disparosHistory","EXTUI:disparosJourneys","EXTUI:disparosLastType","EXTUI:bulkGroupsStore"],description:"Histórico, campanhas/jornadas, grupos e preferências de Disparos. A fila de envio em andamento nunca é copiada nem restaurada."},
    signatures:{label:"Assinaturas (legado)",keys:["EXTUI:signaturesStore"],hidden:true,description:"Categoria legada aceita apenas para compatibilidade de importação; novas cópias incluem Assinaturas dentro da Biblioteca."},
    personalization:{label:"Personalização",keys:["EXTUI:extappAppearanceStore","EXTUI:replacementStore","EXTUI:chatCapabilities","EXTUI:userTabsStore","EXTUI:pinnedChatsStore","EXTUI:extappDashboardSidebarCompact","EXTUI:extappDashboardRailPinned","EXTUI:adaptiveWorkspaceStore","EXTUI:dashboardMenuVisibilityStore","EXTUI:sidebarV2","EXTUI:extappRailPinned","EXTUI:privacyOptions"]},
    settings:{label:"Ajustes e Segurança",keys:["EXTUI:extappOptionsStore","EXTUI:sendSafetySuppressionStore"],description:"Inclui Proteção de Envio, lista local Não contatar (somente hashes + últimos 4 dígitos) e demais preferências configuradas em Ajustes."},
    integrations:{label:"Integrações",keys:["EXTUI:integrationsStore","EXTUI:externalActionsStore","EXTUI:trackingStore","EXTUI:metaOfficialConfig"],safeWithoutSecrets:true},
    automation:{label:"Autoatendimento",keys:["EXTUI:extappAutoServiceStore"]},
    webhooks:{label:"Webhooks",keys:["EXTUI:extappWebhookStore"]},
    contacts:{label:"Contatos e Notas",keys:["EXTUI:contactMetadataStore","EXTUI:profileStore"],description:"Metadados e notas locais associados aos contatos."},
    transcriptions:{label:"Transcrições de Áudio",keys:["EXTUI:audioTranscriptionStore"],description:"Histórico local das transcrições já geradas. Preferências de Transcrição ficam em IA."},
    customers:{label:"Clientes",keys:["EXTUI:customerStore"]},
    status:{label:"Status e Notificações",keys:["EXTUI:statusScheduleStore","EXTUI:notificationStore","EXTUI:notificationCenterFeed","EXTUI:notificationCenterRead"]},
    ai:{label:"IA",keys:config.aiTranscription===false?["EXTUI:aiAgentsStore","EXTUI:aiAssistantsStore","EXTUI:knowledgeBasesStore"]:["EXTUI:aiAgentsStore","EXTUI:aiAssistantsStore","EXTUI:knowledgeBasesStore","EXTUI:audioTranscriptionSettings","EXTUI:aiTranslationSettings","EXTUI:aiQuickDefaults"],safeWithoutSecrets:true,description:config.aiTranscription===false?"Inclui configurações de Assistentes, Agentes e Bases de Conhecimento; credenciais não são incluídas.":"Inclui configurações de Assistentes, Agentes, Bases de Conhecimento e preferências de Tradução/Transcrição; credenciais não são incluídas."},
    orders:{label:"Encomendas",keys:["EXTUI:ordersStore","EXTUI:deliveryCouriersStore","EXTUI:deliverySettingsStore"]},
    activities:{label:"Central de Atividades",keys:["EXTUI:activityCenterStore"]},
    experience:{label:"Experiência extensão",keys:["EXTUI:extappGlobalFavorites","EXTUI:extappAchievements","EXTUI:extappEasterEggs","EXTUI:extappTemplateInstallations"],description:"Favoritos e modelos continuam portáveis; Conquistas, Easter Eggs e jogos são restaurados somente pela licença proprietária."},
    trash:{label:"Lixeira",keys:["EXTUI:trashStore"],description:"Inclui itens enviados à Lixeira para permitir recuperação após restaurar a cópia."}
  });
  var ITEM_LISTS=Object.freeze([
    {key:"EXTUI:textMessageStore",field:"textMessageList",kind:"message"},
    {key:"EXTUI:audioStore",field:"audioList",kind:"audio"},
    {key:"EXTUI:mediaStore",field:"mediaList",kind:"media"},
    {key:"EXTUI:documentStore",field:"documentList",kind:"document"},
    {key:"EXTUI:stickerStore",field:"stickerList",kind:"sticker"},
    {key:"EXTUI:pixStore",field:"pixList",kind:"pix"},
    {key:"EXTUI:interactiveListStore",field:"interactiveListList",kind:"interactive-list"},
    {key:"EXTUI:contactCardStore",field:"contactList",kind:"contact"}
  ]);
  var DEFAULT_CATEGORY_IDS=Object.freeze(Object.keys(CATEGORIES).filter(function(id){return CATEGORIES[id].hidden!==true;}));
  var ALLOWED_DATA_KEYS=(function(){var set=new Set();Object.keys(CATEGORIES).forEach(function(id){CATEGORIES[id].keys.forEach(function(k){if(!EXCLUDED.has(k))set.add(k);});});return set;})();
  var CREDENTIAL_SCAN_STORES=new Set(["EXTUI:integrationsStore","EXTUI:externalActionsStore","EXTUI:trackingStore","EXTUI:metaOfficialConfig","EXTUI:extappWebhookStore","EXTUI:audioTranscriptionSettings","EXTUI:aiAgentsStore","EXTUI:aiAssistantsStore"]);
  var CREDENTIAL_FIELD_NAMES=new Set(["apikey","apitoken","accesstoken","refreshtoken","clientsecret","oauthsecret","password","passwd","authorization","bearertoken","authtoken","webhooksecret","signingsecret","privatekey","secretkey","token"]);
  function credentialFieldName(k){return String(k==null?"":k).toLowerCase().replace(/[^a-z0-9]/g,"");}
  function credentialValuePresent(v){if(v==null)return false;if(typeof v==="string")return v.trim().length>0;if(typeof v==="number"||typeof v==="boolean")return true;if(Array.isArray(v))return v.length>0;if(typeof v==="object")return Object.keys(v).length>0;return false;}
  function credentialError(code,message){var e=new Error(message);e.code=code;return e;}
  function scanCredentialValue(value,path,state,depth){state=state||{nodes:0};depth=Number(depth||0);state.nodes++;if(state.nodes>60000||depth>28)throw credentialError("BACKUP_CREDENTIAL_SCAN_LIMIT","A configuração de integração excede os limites seguros para a verificação de credenciais.");if(value==null)return;if(Array.isArray(value)){for(var i=0;i<value.length;i++)scanCredentialValue(value[i],path+"["+i+"]",state,depth+1);return;}if(typeof value!=="object")return;Object.keys(value).forEach(function(k){if(!safeObjectKey(k))throw credentialError("BACKUP_CREDENTIAL_SCAN_INVALID","A configuração contém uma propriedade insegura e não pode ser exportada.");var v=value[k],normalized=credentialFieldName(k);if(CREDENTIAL_FIELD_NAMES.has(normalized)&&credentialValuePresent(v))throw credentialError("BACKUP_CREDENTIAL_DETECTED","Cópia cancelada por segurança: uma credencial foi encontrada em uma configuração exportável. Remova e reconecte essa integração antes de criar a cópia.");scanCredentialValue(v,path+"."+k,state,depth+1);});}
  function assertNoCredentials(data){Object.keys(data||{}).forEach(function(storeKey){if(!CREDENTIAL_SCAN_STORES.has(storeKey))return;var raw=data[storeKey],parsed=raw;if(typeof raw==="string"){var trimmed=raw.trim();if(!trimmed)return;try{parsed=JSON.parse(trimmed);}catch(_){throw credentialError("BACKUP_CREDENTIAL_SCAN_INVALID","Uma configuração de integração está corrompida ou não pode ser verificada com segurança. A cópia foi cancelada.");}}scanCredentialValue(parsed,storeKey,{nodes:0},0);});return true;}

  function repo(){if(!root.ExtensionStorage){var e=new Error("Os dados da extensão não estão disponíveis no momento");e.code="STORAGE_UNAVAILABLE";throw e;}return root.ExtensionStorage;}
  async function paid(){if(!root.__extPlanGate)throw Object.assign(new Error("Sua sessão precisa ser validada novamente."),{code:"LICENSE_REQUIRED"});if(Object.prototype.hasOwnProperty.call(config,"paidFeature"))await root.__extPlanGate.requirePaid("Cópias de Segurança",config.paidFeature);else await root.__extPlanGate.requirePaid("Cópias de Segurança");return true;}
  function clone(v){if(v==null)return v;function clean(x){if(Array.isArray(x))return x.map(clean);if(!x||typeof x!=="object")return x;var out={};Object.keys(x).forEach(function(k){if(!safeObjectKey(k))return;out[k]=clean(x[k]);});return out;}try{return clean(JSON.parse(JSON.stringify(v)));}catch(_){return clean(v);}}
  function parse(v){if(v==null)return null;if(typeof v!=="string")return clone(v);try{return JSON.parse(v);}catch(_){return v;}}
  function safeObjectKey(k){k=String(k||"");return k!=="__proto__"&&k!=="prototype"&&k!=="constructor";}
  function safeAssign(target){target=target&&typeof target==="object"?target:{};for(var i=1;i<arguments.length;i++){var src=arguments[i];if(!src||typeof src!=="object")continue;Object.keys(src).forEach(function(k){if(safeObjectKey(k))target[k]=src[k];});}return target;}
  function own(o,k){return !!o&&Object.prototype.hasOwnProperty.call(o,k);}
  function safeDynamicKey(k){
    k=String(k||"");
    if(!k||k.length>180||k==="__proto__"||k==="prototype"||k==="constructor"||EXCLUDED.has(k)||ALLOWED_DATA_KEYS.has(k))return false;
                                                                        
                                                                        
                                                        
    return /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|id-\d{10,16}-[A-Za-z0-9_-]{4,40}|[0-9a-f]{24,64}|[0-9]{8,20})$/i.test(k);
  }
  function allPortableKeys(){return Array.from(ALLOWED_DATA_KEYS);}
  function normalizeCategoryIds(ids){if(!Array.isArray(ids))return DEFAULT_CATEGORY_IDS.slice();var valid=[];ids.forEach(function(id){if(id==="signatures")id="items";if(CATEGORIES[id]&&CATEGORIES[id].hidden!==true&&valid.indexOf(id)<0)valid.push(id);});return valid;}
  function migrateCategoryIds(ids,ver){var raw=Array.isArray(ids)?ids.slice():null,out=raw?normalizeCategoryIds(raw):DEFAULT_CATEGORY_IDS.slice();if(raw&&Number(ver||0)<6){if(raw.indexOf("greetings")>=0&&out.indexOf("items")<0)out.push("items");if(raw.indexOf("personalization")>=0&&out.indexOf("settings")<0)out.push("settings");}if(raw&&Number(ver||0)<10&&out.indexOf("experience")<0)out.push("experience");if(raw&&Number(ver||0)<9&&raw.indexOf("status")>=0&&out.indexOf("activities")<0)out.push("activities");if(raw&&Number(ver||0)<14&&out.indexOf("customers")<0)out.push("customers");if(raw&&Number(ver||0)<15){if(raw.indexOf("items")>=0&&out.indexOf("quickResponses")<0)out.push("quickResponses");if(raw.indexOf("contacts")>=0&&out.indexOf("transcriptions")<0)out.push("transcriptions");}return out;}
  function keysForCategories(ids){var out=[];normalizeCategoryIds(ids).forEach(function(id){CATEGORIES[id].keys.forEach(function(k){if(!EXCLUDED.has(k)&&out.indexOf(k)<0)out.push(k);});});return out;}
  function categoryForKey(key){var found=null;Object.keys(CATEGORIES).some(function(id){if(CATEGORIES[id].keys.indexOf(key)>=0){found=id;return true;}return false;});return found;}
  function chunks(list,size){var out=[];for(var i=0;i<list.length;i+=size)out.push(list.slice(i,i+size));return out;}
  async function getManyChunked(keys){var out={};for(var part of chunks(keys,200)){var got=await repo().getMany(part);Object.keys(got||{}).forEach(function(k){out[k]=got[k];});}return out;}
  async function setManyChunked(values){var ks=Object.keys(values||{});for(var part of chunks(ks,120)){var payload={};part.forEach(function(k){payload[k]=values[k];});await repo().setMany(payload);}return true;}
  async function removeManyChunked(keys){for(var part of chunks(keys,200))await repo().removeMany(part);return true;}

  function ownerBoundSelected(categories){return Array.isArray(categories)&&categories.indexOf("experience")>=0;}
  function ownerBoundPayloadFromData(data){var payload={};OWNER_BOUND_KEYS.forEach(function(k){if(own(data,k)){payload[k]=data[k];delete data[k];}});return payload;}
  function ownerBoundNormalize(raw){if(!raw||typeof raw!=="object"||Array.isArray(raw))return null;var payload={};var source=raw.payload&&typeof raw.payload==="object"&&!Array.isArray(raw.payload)?raw.payload:{};OWNER_BOUND_KEYS.forEach(function(k){if(own(source,k))payload[k]=source[k];});var ownerHash=String(raw.ownerHash||"").toLowerCase(),payloadHash=String(raw.payloadHash||"").toLowerCase(),proof=String(raw.proof||"").toLowerCase();if(Number(raw.version)!==OWNER_BOUND_VERSION||raw.kind!=="extapp-secret-progress"||!/^[a-f0-9]{64}$/.test(ownerHash)||!/^[a-f0-9]{64}$/.test(payloadHash)||!/^[a-f0-9]{64}$/.test(proof)||!Object.keys(payload).length)return null;return{version:OWNER_BOUND_VERSION,kind:"extapp-secret-progress",algorithm:"HMAC-SHA-256",ownerHash:ownerHash,payloadHash:payloadHash,proof:proof,payloadKeys:Object.keys(payload),payload:payload};}
  function ownerBoundMessage(type,payload){return new Promise(function(resolve,reject){try{chrome.runtime.sendMessage({type:type,ownerBound:payload&&payload.ownerBound||null,payload:payload&&payload.payload||null},function(response){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message||"Não foi possível validar o progresso protegido."));return;}if(!response||response.ok!==true){var err=new Error(response&&response.error||"Não foi possível validar o progresso protegido.");err.code=response&&response.code||"BACKUP_OWNER_BINDING_FAILED";reject(err);return;}resolve(response.result||{});});}catch(err){reject(err);}});}
  async function sealOwnerBound(payload){if(!payload||!Object.keys(payload).length)return null;var result=await ownerBoundMessage("EXTUI_BACKUP_OWNER_SEAL",{payload:payload});return ownerBoundNormalize(result&&result.ownerBound);}
  async function verifyOwnerBound(raw){var normalized=ownerBoundNormalize(raw);if(!normalized)return{verified:false,reason:"missing_or_invalid"};try{return await ownerBoundMessage("EXTUI_BACKUP_OWNER_VERIFY",{ownerBound:normalized});}catch(err){return{verified:false,reason:err&&err.code||"verification_unavailable"};}}
  function sanitizeSecretThemeStore(raw){var value=parse(raw),changed=false;if(!value||typeof value!=="object"||Array.isArray(value))return{value:raw,changed:false};function scrub(obj){if(!obj||typeof obj!=="object"||Array.isArray(obj))return;if(SECRET_THEME_IDS.has(String(obj.visualTheme||""))){obj.visualTheme="padrao";obj.appearanceDefinition="custom";changed=true;}}scrub(value);scrub(value.state);return{value:typeof raw==="string"?JSON.stringify(value):value,changed:changed};}

  function itemKind(spec,item){
    if(!spec||spec.kind!=="media")return spec&&spec.kind||"";
    var explicit=String(item&&item.mediaKind||"").toLowerCase();
    return explicit==="image"||explicit==="video"?explicit:"media";
  }
  function itemRefsFromData(data){
    var refs=[];
    ITEM_LISTS.forEach(function(spec){
      if(!own(data,spec.key))return;
      var parsed=parse(data[spec.key]);
      var state=parsed&&parsed.state&&typeof parsed.state==="object"?parsed.state:{};
      var list=Array.isArray(state[spec.field])?state[spec.field]:[];
      list.forEach(function(item){
        var id=item&&safeDynamicKey(item.id)?String(item.id):"";
        if(id&&!refs.some(function(r){return r.id===id;}))refs.push({id:id,kind:itemKind(spec,item)});
      });
    });
    return refs;
  }
  function itemIdsFromData(data){return itemRefsFromData(data).map(function(r){return r.id;});}
  function resolveAssetKind(kind,raw){
    kind=String(kind||"").toLowerCase();if(kind!=="media")return kind;
    var value=parse(raw);if(!value||typeof value!=="object"||Array.isArray(value))return kind;
    var explicit=String(value.mediaKind||"").toLowerCase();if(explicit==="image"||explicit==="video")return explicit;
    var mime=String(value.mimeType||value.type||value.fileType||"").toLowerCase();
    if(/^image\//.test(mime))return"image";if(/^video\//.test(mime))return"video";
    var data=String(value.data||"");if(/^data:image\//i.test(data))return"image";if(/^data:video\//i.test(data))return"video";
    var fileName=String(value.fileName||value.name||"").toLowerCase();if(/\.(?:jpe?g|png|webp|gif|bmp|avif|heic)$/i.test(fileName))return"image";if(/\.(?:mp4|webm|mov|mkv|avi|3gp|m4v)$/i.test(fileName))return"video";
    return kind;
  }
  function usableAsset(kind,raw){
    var value=parse(raw);
    if(!value||typeof value!=="object"||Array.isArray(value))return false;
    if(kind==="message")return typeof value.data==="string";
    if(kind==="audio"||kind==="media"||kind==="image"||kind==="video"||kind==="document"||kind==="sticker")return typeof value.data==="string"&&(/^data:[^;,]+(?:;[^,]*)?,/i.test(value.data)||(root.ExtensionMediaStore&&root.ExtensionMediaStore.isRef(value.data)));
    if(kind==="pix")return typeof value.key==="string"&&value.key.trim().length>0;
    if(kind==="contact")return typeof value.contactPhone==="string"&&value.contactPhone.replace(/\D/g,"").length>0;
    return true;
  }
  function portableAsset(raw){return raw;}
  async function offloadAsset(raw){var value=parse(raw);if(!value||typeof value!=="object"||Array.isArray(value)||!root.ExtensionMediaStore||typeof value.data!=="string")return raw;var out=clone(value);out.data=await root.ExtensionMediaStore.maybeStore(value.data,{mimeType:value.mimeType||"",fileName:value.fileName||"arquivo",sizeBytes:Number(value.sizeBytes||0)});return typeof raw==="string"?JSON.stringify(out):out;}
  function normalizeAssets(backup,data){
    var assets={};
    Object.keys(backup&&backup.assets||{}).forEach(function(k){if(safeDynamicKey(k))assets[k]=backup.assets[k];});
                                                                        
                                                                            
                                                                              
                             
    itemIdsFromData(data).forEach(function(id){if(!own(assets,id)&&own(data,id)){assets[id]=data[id];delete data[id];}});
    return assets;
  }
  function integrityFor(data,assets){var refs=itemRefsFromData(data),missing=refs.filter(function(ref){return !own(assets,ref.id)||!usableAsset(ref.kind,assets[ref.id]);}).map(function(ref){return ref.id;});var valid=refs.length-missing.length;return{itemRefs:refs.length,itemAssets:valid,missingItemAssets:missing};}

  async function exportData(options){
    await paid();
    options=options||{};
    var categoryIds=Array.isArray(options.categories)?normalizeCategoryIds(options.categories):DEFAULT_CATEGORY_IDS.slice();
    var list=Array.isArray(options.keys)&&options.keys.length?options.keys.filter(function(k){return ALLOWED_DATA_KEYS.has(k)&&!EXCLUDED.has(k);}):keysForCategories(categoryIds);
    var values=await getManyChunked(list),data={};
    list.forEach(function(k){if(own(values,k)&&values[k]!==undefined)data[k]=values[k];});
    assertNoCredentials(data);
    var assets={},assetKinds={};
    var wantsItems=categoryIds.indexOf("items")>=0||ITEM_LISTS.some(function(s){return list.indexOf(s.key)>=0;});
    if(wantsItems){
      var itemRefs=itemRefsFromData(data),refs=itemRefs.map(function(r){return r.id;}),payloads=await getManyChunked(refs);
      for(var itemRef of itemRefs){if(own(payloads,itemRef.id)&&payloads[itemRef.id]!==undefined&&usableAsset(itemRef.kind,payloads[itemRef.id])){assets[itemRef.id]=portableAsset(payloads[itemRef.id]);assetKinds[itemRef.id]=resolveAssetKind(itemRef.kind,payloads[itemRef.id]);}}
    }
    var ownerPayload=ownerBoundPayloadFromData(data),ownerBound=null;if(Object.keys(ownerPayload).length)ownerBound=await sealOwnerBound(ownerPayload);
    var integrity=integrityFor(data,assets);
    return{format:"EXTAPP_BACKUP",version:VERSION,createdAt:new Date().toISOString(),mode:"portable",assetEncoding:"source",categories:categoryIds,keys:Object.keys(data),assetKeys:Object.keys(assets),assetKinds:assetKinds,data:data,assets:assets,ownerBound:ownerBound,integrity:integrity,security:{secretsIncluded:false,credentialLeakScan:"passed-v1",ownerBoundProgress:!!ownerBound,ownerBinding:ownerBound?"license-owner+hmac-sha256":null}};
  }

  function encodeMerged(current,incoming,value){return typeof current==="string"||(current==null&&typeof incoming==="string")?JSON.stringify(value):value;}
  function mergeRowsById(currentRows,incomingRows){var order=[],byId=new Map(),loose=[];function push(row,prefer){if(!row||typeof row!=="object"||Array.isArray(row)){loose.push(clone(row));return;}var id=row.id!=null?String(row.id):"";if(!id){loose.push(clone(row));return;}if(!byId.has(id))order.push(id);var prev=byId.get(id);byId.set(id,prefer&&prev?safeAssign({},prev,row):clone(row));} (Array.isArray(currentRows)?currentRows:[]).forEach(function(row){push(row,false);});(Array.isArray(incomingRows)?incomingRows:[]).forEach(function(row){push(row,true);});return order.map(function(id){return byId.get(id);}).concat(loose);}
  function signatureList(value){if(Array.isArray(value))return value;if(value&&value.state&&Array.isArray(value.state.list))return value.state.list;if(value&&Array.isArray(value.list))return value.list;return[];}
  function mergeSignatureValue(current,incoming){var a=parse(current),b=parse(incoming),out=safeAssign({},a&&typeof a==="object"&&!Array.isArray(a)?a:{},b&&typeof b==="object"&&!Array.isArray(b)?b:{});out.version=Math.max(2,Number(a&&a.version)||0,Number(b&&b.version)||0);out.list=mergeRowsById(signatureList(a),signatureList(b));delete out.state;return encodeMerged(current,incoming,out);}
  function mergeTranscriptionValue(current,incoming){var a=parse(current)||{},b=parse(incoming)||{},ae=a&&a.entries&&typeof a.entries==="object"&&!Array.isArray(a.entries)?a.entries:{},be=b&&b.entries&&typeof b.entries==="object"&&!Array.isArray(b.entries)?b.entries:{},entries={};Object.keys(ae).forEach(function(k){if(safeObjectKey(k))entries[k]=clone(ae[k]);});Object.keys(be).forEach(function(k){if(safeObjectKey(k))entries[k]=clone(be[k]);});var out=safeAssign({},a,b,{version:Math.max(2,Number(a&&a.version)||0,Number(b&&b.version)||0),entries:entries});return encodeMerged(current,incoming,out);}
  function backupCustomerPhone(row){if(!row||typeof row!=="object")return"";var value=row.phone||row.contactId||row.profile&&row.profile.phone||"";if(root.ExtensionCustomerStore&&typeof root.ExtensionCustomerStore.canonicalPhone==="function"){try{return String(root.ExtensionCustomerStore.canonicalPhone(value)||"");}catch(_){}}return String(value||"").replace(/\D/g,"");}
  function mergeCustomerBackup(current,incoming){var a=parse(current)||{},b=parse(incoming)||{},rows=(Array.isArray(a.customers)?a.customers:[]).map(clone),idMap={},byId=new Map(),byPhone=new Map();function index(){byId.clear();byPhone.clear();rows.forEach(function(row,i){var id=String(row&&row.id||"");if(id)byId.set(id,i);var phone=backupCustomerPhone(row);if(phone&&!byPhone.has(phone))byPhone.set(phone,i);});}index();(Array.isArray(b.customers)?b.customers:[]).forEach(function(incomingRow){if(!incomingRow||typeof incomingRow!=="object")return;var row=clone(incomingRow),incomingId=String(row.id||""),phone=backupCustomerPhone(row),idx=incomingId&&byId.has(incomingId)?byId.get(incomingId):(phone&&byPhone.has(phone)?byPhone.get(phone):-1);if(idx>=0){var existing=rows[idx]||{},canonicalId=String(existing.id||incomingId||"");var merged=safeAssign({},existing,row);if(existing.profile&&row.profile&&typeof existing.profile==="object"&&typeof row.profile==="object")merged.profile=safeAssign({},existing.profile,row.profile);if(canonicalId)merged.id=canonicalId;rows[idx]=merged;if(incomingId)idMap[incomingId]=canonicalId||incomingId;}else{rows.push(row);if(incomingId)idMap[incomingId]=incomingId;}index();});var categories=mergeRowsById(Array.isArray(a.categories)?a.categories:[],Array.isArray(b.categories)?b.categories:[]),deleted={};Object.keys(a.deletedCustomers||{}).forEach(function(k){if(safeObjectKey(k))deleted[k]=Number(a.deletedCustomers[k])||0;});Object.keys(b.deletedCustomers||{}).forEach(function(k){if(safeObjectKey(k))deleted[k]=Math.max(Number(deleted[k])||0,Number(b.deletedCustomers[k])||0);});var out=safeAssign({},a,b,{schemaVersion:Math.max(Number(a.schemaVersion)||0,Number(b.schemaVersion)||0),categories:categories,customers:rows,deletedCustomers:deleted});return{value:encodeMerged(current,incoming,out),idMap:idMap};}
  function remapTranscriptionCustomers(raw,idMap){if(!raw||!idMap||!Object.keys(idMap).length)return raw;var parsed=parse(raw);if(!parsed||!parsed.entries||typeof parsed.entries!=="object"||Array.isArray(parsed.entries))return raw;var out=clone(parsed);Object.keys(out.entries).forEach(function(k){var row=out.entries[k];if(!row||typeof row!=="object")return;var old=String(row.customerId||"");if(old&&Object.prototype.hasOwnProperty.call(idMap,old))row.customerId=idMap[old];});return encodeMerged(raw,raw,out);}
  function prepareMergeBatch(currentMap,incomingMap){var data=safeAssign({},incomingMap||{}),premerged={};if(Object.prototype.hasOwnProperty.call(data,"EXTUI:customerStore")){var cm=mergeCustomerBackup(currentMap&&currentMap["EXTUI:customerStore"],data["EXTUI:customerStore"]);premerged["EXTUI:customerStore"]=cm.value;if(Object.prototype.hasOwnProperty.call(data,"EXTUI:audioTranscriptionStore"))data["EXTUI:audioTranscriptionStore"]=remapTranscriptionCustomers(data["EXTUI:audioTranscriptionStore"],cm.idMap);}return{incoming:data,premerged:premerged};}
  function mergeValue(current,incoming,key){if(key==="EXTUI:signaturesStore")return mergeSignatureValue(current,incoming);if(key==="EXTUI:audioTranscriptionStore")return mergeTranscriptionValue(current,incoming);if(key==="EXTUI:customerStore")return mergeCustomerBackup(current,incoming).value;var a=parse(current),b=parse(incoming);if(a&&b&&typeof a==="object"&&!Array.isArray(a)&&!Array.isArray(b)){if(a.state&&b.state&&typeof a.state==="object"&&typeof b.state==="object"){var out=clone(a),bs=b.state;out.state=safeAssign({},a.state);Object.keys(bs).forEach(function(k){if(!safeObjectKey(k))return;if(Array.isArray(bs[k])&&Array.isArray(out.state[k])){var byId=new Map(),loose=[];out.state[k].forEach(function(x){if(x&&x.id!=null)byId.set(String(x.id),clone(x));else loose.push(clone(x));});bs[k].forEach(function(x){if(x&&x.id!=null)byId.set(String(x.id),clone(x));else loose.push(clone(x));});out.state[k]=byId.size?Array.from(byId.values()).concat(loose):loose;}else out.state[k]=clone(bs[k]);});return typeof current==="string"?JSON.stringify(out):out;}var merged=safeAssign({},a,b);return typeof current==="string"?JSON.stringify(merged):merged;}return incoming;}

  function normalizeBackupShape(backup){
                                                                             
                                                                          
                                                                      
    var rawData={},legacyOwnerBound=false;Object.keys(backup&&backup.data||{}).forEach(function(k){if(EXCLUDED.has(k)||(!ALLOWED_DATA_KEYS.has(k)&&!safeDynamicKey(k)))return;if(OWNER_BOUND_KEY_SET.has(k)){legacyOwnerBound=true;return;}rawData[k]=backup.data[k];});
    var assets=normalizeAssets(backup||{},rawData),data={};
    Object.keys(rawData).forEach(function(k){if(ALLOWED_DATA_KEYS.has(k))data[k]=rawData[k];});
                                                                         
                                                                           
                                                           
    var refs=new Set(itemIdsFromData(data)),safeAssets={};Object.keys(assets||{}).forEach(function(k){if(refs.has(k)&&safeDynamicKey(k))safeAssets[k]=assets[k];});
    var ownerBound=ownerBoundNormalize(backup&&backup.ownerBound);
    return safeAssign({},backup,{version:Number(backup&&backup.version)||1,data:data,assets:safeAssets,ownerBound:ownerBound,ownerBoundLegacyDetected:backup&&backup.ownerBoundLegacyDetected===true||legacyOwnerBound,keys:Object.keys(data),assetKeys:Object.keys(safeAssets),integrity:integrityFor(data,safeAssets)});
  }
  function filterBackup(backup,categoryIds){
    backup=normalizeBackupShape(backup);
    var normalized=normalizeCategoryIds(categoryIds),allowed=new Set(keysForCategories(normalized)),data={};
    Object.keys(backup.data||{}).forEach(function(k){if(allowed.has(k)&&!EXCLUDED.has(k))data[k]=backup.data[k];});
    var assets={};
    if(normalized.indexOf("items")>=0){var refs=new Set(itemIdsFromData(data));Object.keys(backup.assets||{}).forEach(function(k){if(refs.has(k)&&safeDynamicKey(k))assets[k]=backup.assets[k];});}
    var ownerBound=ownerBoundNormalize(backup.ownerBound);
    return safeAssign({},backup,{categories:normalized,keys:Object.keys(data),assetKeys:Object.keys(assets),data:data,assets:assets,ownerBound:ownerBound,ownerBoundLegacyDetected:ownerBoundSelected(normalized)&&backup.ownerBoundLegacyDetected===true,integrity:integrityFor(data,assets)});
  }
  function normalizeIncomingBackup(backup){
    if(backup&&backup.format==="EXTAPP_BACKUP"&&backup.data&&typeof backup.data==="object"&&!Array.isArray(backup.data))return normalizeBackupShape(backup);
    if(root.__extBackupCompatibility&&typeof root.__extBackupCompatibility.convert==="function"){
      var converted=root.__extBackupCompatibility.convert(backup);
      if(converted&&converted.format==="EXTAPP_BACKUP"&&converted.data&&typeof converted.data==="object"&&!Array.isArray(converted.data))return normalizeBackupShape(converted);
    }
    var invalid=new Error("O formato desta cópia não é compatível com esta extensão.");invalid.code="BACKUP_FORMAT_UNSUPPORTED";throw invalid;
  }
  async function normalizeIncomingBackupAsync(backup){
    if(backup&&backup.format==="EXTAPP_BACKUP"&&backup.data&&typeof backup.data==="object"&&!Array.isArray(backup.data))return normalizeBackupShape(backup);
    if(root.__extBackupCompatibility){
      var converted;if(typeof root.__extBackupCompatibility.convertAsync==="function")converted=await root.__extBackupCompatibility.convertAsync(backup);else if(typeof root.__extBackupCompatibility.convert==="function")converted=root.__extBackupCompatibility.convert(backup);
      if(converted&&converted.format==="EXTAPP_BACKUP"&&converted.data&&typeof converted.data==="object"&&!Array.isArray(converted.data))return normalizeBackupShape(converted);
    }
    var invalid=new Error("O formato desta cópia não é compatível com esta extensão.");invalid.code="BACKUP_FORMAT_UNSUPPORTED";throw invalid;
  }

  function dropMissingRefs(data,missing){
    if(!missing.length)return data;
    var bad=new Set(missing),out=safeAssign({},data);
    ITEM_LISTS.forEach(function(spec){
      if(!own(out,spec.key))return;
      var raw=out[spec.key],parsed=parse(raw);if(!parsed||!parsed.state||!Array.isArray(parsed.state[spec.field]))return;
      parsed.state[spec.field]=parsed.state[spec.field].filter(function(item){return !(item&&bad.has(String(item.id)));});
      out[spec.key]=typeof raw==="string"?JSON.stringify(parsed):parsed;
    });
    return out;
  }

  async function importData(backup,options){
    await paid();
    options=options||{};
    var mode=(options.mode==="replace"||options.mode==="overwrite")?"replace":"merge";
    backup=await normalizeIncomingBackupAsync(backup);
    var selected=Array.isArray(options.categories)&&options.categories.length?filterBackup(backup,options.categories):backup;
    selected=normalizeBackupShape(selected);
    var incoming={};Object.keys(selected.data).forEach(function(k){if(!EXCLUDED.has(k)&&!OWNER_BOUND_KEY_SET.has(k))incoming[k]=selected.data[k];});
    var assets=safeAssign({},selected.assets||{}),warnings=[],ownerVerified=false,ownerVerification=null,experienceSelected=ownerBoundSelected(selected.categories||[]);
    if(selected.ownerBound){ownerVerification=await verifyOwnerBound(selected.ownerBound);ownerVerified=!!(ownerVerification&&ownerVerification.verified===true);}
    if(experienceSelected&&ownerVerified&&ownerVerification.payload&&typeof ownerVerification.payload==="object")OWNER_BOUND_KEYS.forEach(function(k){if(own(ownerVerification.payload,k))incoming[k]=ownerVerification.payload[k];});
    if(experienceSelected&&selected.ownerBound&&!ownerVerified){var reason=ownerVerification&&ownerVerification.reason||"verification_failed";warnings.push({code:reason==="owner_mismatch"?"BACKUP_OWNER_MISMATCH":"BACKUP_OWNER_PROOF_INVALID",message:reason==="owner_mismatch"?"Conquistas, Easter Eggs e jogos deste backup pertencem a outra licença e foram ignorados. Os demais dados continuam sendo importados normalmente.":"O progresso protegido de Conquistas, Easter Eggs e jogos não pôde ser autenticado e foi ignorado."});}
    if(experienceSelected&&selected.ownerBoundLegacyDetected===true&&!ownerVerified)warnings.push({code:"BACKUP_LEGACY_SECRET_PROGRESS_SKIPPED",message:"Este backup contém progresso secreto antigo sem vínculo de proprietário. Conquistas, Easter Eggs e jogos foram preservados somente na instalação atual; os demais dados podem ser importados normalmente."});
    if(!ownerVerified){var sanitizedThemes=0;["EXTUI:extappOptionsStore","EXTUI:extappAppearanceStore"].forEach(function(k){if(!own(incoming,k))return;var clean=sanitizeSecretThemeStore(incoming[k]);incoming[k]=clean.value;if(clean.changed)sanitizedThemes++;});if(sanitizedThemes)warnings.push({code:"BACKUP_SECRET_THEME_SKIPPED",message:"Um tema secreto do backup não pertence a uma progressão autenticada desta licença e foi substituído pelo tema padrão."});}
    var refSpecs=itemRefsFromData(incoming),refs=refSpecs.map(function(r){return r.id;});
    var existingAssets=refs.length?await getManyChunked(refs):{};
    var missing=refSpecs.filter(function(ref){
      var incomingOk=own(assets,ref.id)&&usableAsset(ref.kind,assets[ref.id]);
      var existingOk=own(existingAssets,ref.id)&&usableAsset(ref.kind,existingAssets[ref.id]);
      return !incomingOk&&!existingOk;
    }).map(function(ref){return ref.id;});
    refSpecs.forEach(function(ref){if(own(assets,ref.id)&&!usableAsset(ref.kind,assets[ref.id]))delete assets[ref.id];});
    for(var assetId of Object.keys(assets)){assets[assetId]=await offloadAsset(assets[assetId]);}

                                                                           
                                                                             
                                                                             
    if(missing.length){
      incoming=dropMissingRefs(incoming,missing);
      warnings.push({code:"BACKUP_MISSING_ITEM_CONTENT",count:missing.length,message:missing.length+" item(ns) sem conteúdo no arquivo foram ignorados para evitar cards quebrados."});
      refs=itemIdsFromData(incoming);
    }
    Object.keys(assets).forEach(function(id){if(refs.indexOf(id)<0)delete assets[id];});

    var oldRefs=[];
    if(mode==="replace"&&selected.categories&&selected.categories.indexOf("items")>=0){
      var oldStores=await getManyChunked(ITEM_LISTS.map(function(s){return s.key;}));oldRefs=itemIdsFromData(oldStores);
    }

    if(config.atomicImport!==false){
    var replaceCategories=mode==="replace"&&Array.isArray(selected.categories)?selected.categories:[];
    var replaceKeys=mode==="replace"?keysForCategories(replaceCategories).filter(function(k){return !OWNER_BOUND_KEY_SET.has(k)||ownerVerified;}):[];
    var touched=[];
    function addTouched(k){if(k&&touched.indexOf(k)<0)touched.push(k);}
    Object.keys(incoming).forEach(addTouched);Object.keys(assets).forEach(addTouched);replaceKeys.forEach(addTouched);oldRefs.forEach(addTouched);
    var before=touched.length?await getManyChunked(touched):{};
    try{
      if(Object.keys(assets).length)await setManyChunked(assets);
      if(mode==="replace"){
        var absentKeys=replaceKeys.filter(function(k){return !own(incoming,k);});
        if(absentKeys.length)await removeManyChunked(absentKeys);
        if(Object.keys(incoming).length)await setManyChunked(incoming);
      }
      else{
        var mergeBatch=prepareMergeBatch(before,incoming),mergeIncoming=mergeBatch.incoming,merged={};
        Object.keys(mergeIncoming).forEach(function(k){merged[k]=Object.prototype.hasOwnProperty.call(mergeBatch.premerged,k)?mergeBatch.premerged[k]:mergeValue(before&&before[k],mergeIncoming[k],k);});
        if(Object.keys(merged).length)await setManyChunked(merged);
      }

      if(oldRefs.length){
        var newStores=await getManyChunked(ITEM_LISTS.map(function(s){return s.key;})),newRefs=new Set(itemIdsFromData(newStores));
        var orphaned=oldRefs.filter(function(id){return !newRefs.has(id);});if(orphaned.length)await removeManyChunked(orphaned);
      }
    }catch(commitError){
      try{
        var removeOnRollback=touched.filter(function(k){return !own(before,k);});
        if(removeOnRollback.length)await removeManyChunked(removeOnRollback);
        if(Object.keys(before).length)await setManyChunked(before);
      }catch(rollbackError){
        try{commitError.rollbackError=rollbackError&&rollbackError.message||String(rollbackError);}catch(_){}
      }
      throw commitError;
    }
    }else{
    if(Object.keys(assets).length)await setManyChunked(assets);
    if(mode==="replace"){


      var replaceCategories=Array.isArray(selected.categories)?selected.categories:[];
      var replaceKeys=keysForCategories(replaceCategories).filter(function(k){return !OWNER_BOUND_KEY_SET.has(k)||ownerVerified;});
      var absentKeys=replaceKeys.filter(function(k){return !own(incoming,k);});
      if(absentKeys.length)await removeManyChunked(absentKeys);
      if(Object.keys(incoming).length)await setManyChunked(incoming);
    }
    else{
      var current=await getManyChunked(Object.keys(incoming)),mergeBatch=prepareMergeBatch(current,incoming),mergeIncoming=mergeBatch.incoming,merged={};
      Object.keys(mergeIncoming).forEach(function(k){merged[k]=Object.prototype.hasOwnProperty.call(mergeBatch.premerged,k)?mergeBatch.premerged[k]:mergeValue(current&&current[k],mergeIncoming[k],k);});
      await setManyChunked(merged);
    }

    if(oldRefs.length){
      var newStores=await getManyChunked(ITEM_LISTS.map(function(s){return s.key;})),newRefs=new Set(itemIdsFromData(newStores));
      var orphaned=oldRefs.filter(function(id){return !newRefs.has(id);});if(orphaned.length)await removeManyChunked(orphaned);
    }
    }

    return{ok:true,mode:mode,keys:Object.keys(incoming).length,assets:Object.keys(assets).length,categories:selected.categories||[],ownerBoundRestored:ownerVerified,warnings:warnings,compatibilityReport:backup.compatibilityReport||[]};
  }

  function sanitizeBackupPrefix(raw){var value=String(raw||"zvm_backup").trim();try{value=value.normalize("NFKD").replace(/[\u0300-\u036f]/g,"");}catch(_){}value=value.replace(/\s+/g,"_").replace(/[^A-Za-z0-9_-]+/g,"_").replace(/_+/g,"_").replace(/^[_-]+|[_-]+$/g,"").slice(0,48);return value||"zvm_backup";}
  function normalizeBackupFormat(v){v=String(v||"zip").toLowerCase();return v==="json"?"json":v==="secure"?"secure":"zip";}
  function normalizeDestinationMode(v){v=String(v||"downloads");return v==="googleDrive"||v==="both"?v:"downloads";}
  async function settings(){await paid();var raw=await repo().get(SETTINGS),v=parse(raw)||{},ver=Number(v.backupSettingsVersion)||0,folder=String(v.downloadFolder||"ZVM-BACKUPs");if(ver<14&&(folder==="Cópias da extensão"||folder==="Backups da extensão"))folder="ZVM-BACKUPs";var base={backupSettingsVersion:17,enabled:v.enabled===true,intervalMinutes:Math.max(15,Number(v.intervalMinutes)||360),filePrefix:sanitizeBackupPrefix(v.filePrefix||"zvm_backup"),downloadFolder:folder.replace(/[\\/:*?"<>|]+/g,"-").slice(0,80)||"ZVM-BACKUPs",retention:Math.max(1,Math.min(20,Number(v.retention)||10))},drive={destinationMode:normalizeDestinationMode(v.destinationMode),driveConnected:v.driveConnected===true,driveFolderId:String(v.driveFolderId||""),driveFolderName:String(v.driveFolderName||"ZVM-BACKUPs").slice(0,120)||"ZVM-BACKUPs",driveAccountEmail:String(v.driveAccountEmail||"").slice(0,254),driveAccountName:String(v.driveAccountName||"").slice(0,160),driveLastBackupAt:Number(v.driveLastBackupAt)||0,driveNeedsAttention:v.driveNeedsAttention===true},out;if(config.backupFormatBeforeCategories===true)out={backupSettingsVersion:base.backupSettingsVersion,enabled:base.enabled,intervalMinutes:base.intervalMinutes,filePrefix:base.filePrefix,downloadFolder:base.downloadFolder,retention:base.retention,backupFormat:normalizeBackupFormat(v.backupFormat),categories:migrateCategoryIds(v.categories,ver),includeTrash:v.includeTrash!==false,lastRunAt:Number(v.lastRunAt)||0};else out={backupSettingsVersion:base.backupSettingsVersion,enabled:base.enabled,intervalMinutes:base.intervalMinutes,filePrefix:base.filePrefix,downloadFolder:base.downloadFolder,retention:base.retention,categories:migrateCategoryIds(v.categories,ver),backupFormat:normalizeBackupFormat(v.backupFormat),includeTrash:v.includeTrash!==false,lastRunAt:Number(v.lastRunAt)||0};out=safeAssign(out,drive);if((out.destinationMode==="googleDrive"||out.destinationMode==="both")&&!out.driveConnected)out.destinationMode="downloads";if(ver<17||Object.prototype.hasOwnProperty.call(v,"downloadCopy")||Object.prototype.hasOwnProperty.call(v,"customDirectoryName")||Object.prototype.hasOwnProperty.call(v,"directoryToken")||Object.prototype.hasOwnProperty.call(v,"permissionRequired")||Object.prototype.hasOwnProperty.call(v,"lastPermissionCheckAt")||Object.prototype.hasOwnProperty.call(v,"sendToSelf")||Object.prototype.hasOwnProperty.call(v,"driveEnabled"))await repo().set(SETTINGS,JSON.stringify(out));return out;}
  async function configure(cfg){await paid();var cur=await settings(),next=safeAssign(cur,cfg||{});next.backupSettingsVersion=17;next.enabled=next.enabled===true;next.intervalMinutes=Math.max(15,Number(next.intervalMinutes)||360);next.retention=Math.max(1,Math.min(20,Number(next.retention)||10));next.categories=Array.isArray(next.categories)?normalizeCategoryIds(next.categories):DEFAULT_CATEGORY_IDS.slice();next.filePrefix=sanitizeBackupPrefix(next.filePrefix||"zvm_backup");next.downloadFolder=String(next.downloadFolder||"ZVM-BACKUPs").replace(/[\\/:*?"<>|]+/g,"-").slice(0,80)||"ZVM-BACKUPs";next.backupFormat=normalizeBackupFormat(next.backupFormat);next.includeTrash=next.includeTrash!==false;next.lastRunAt=Number(next.lastRunAt)||0;next.destinationMode=normalizeDestinationMode(next.destinationMode);next.driveConnected=next.driveConnected===true;next.driveFolderId=String(next.driveFolderId||"");next.driveFolderName=String(next.driveFolderName||"ZVM-BACKUPs").slice(0,120)||"ZVM-BACKUPs";next.driveAccountEmail=String(next.driveAccountEmail||"").slice(0,254);next.driveAccountName=String(next.driveAccountName||"").slice(0,160);next.driveLastBackupAt=Number(next.driveLastBackupAt)||0;next.driveNeedsAttention=next.driveNeedsAttention===true;if((next.destinationMode==="googleDrive"||next.destinationMode==="both")&&!next.driveConnected)next.destinationMode="downloads";delete next.downloadCopy;delete next.customDirectoryName;delete next.directoryToken;delete next.permissionRequired;delete next.lastPermissionCheckAt;delete next.sendToSelf;delete next.driveEnabled;await repo().set(SETTINGS,JSON.stringify(next));return next;}

  var api=Object.freeze({version:"6.1.0-backup-taxonomy",categories:CATEGORIES,defaultCategories:DEFAULT_CATEGORY_IDS.slice(),excludedKeys:Array.from(EXCLUDED),allPortableKeys:allPortableKeys,keysForCategories:keysForCategories,categoryForKey:categoryForKey,itemIdsFromData:itemIdsFromData,usableAsset:usableAsset,exportData:exportData,filterBackup:filterBackup,normalizeIncomingBackup:normalizeIncomingBackup,normalizeIncomingBackupAsync:normalizeIncomingBackupAsync,importData:importData,mergeValue:mergeValue,configure:configure,settings:settings});
  return api;

  };
})(typeof window!=="undefined"?window:self);
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
