(function(root){
  "use strict";
  if(root.__extAiAssistantDraftsCore)return;
  var STORE_KEY="EXTUI:aiAssistantDraftStore",STORE_VERSION=1,SCHEMA_VERSION=1,MAX_DRAFTS=64,MAX_AGE_MS=1000*60*60*24*90,KEY_RE=/^(?:new|assistant:[A-Za-z0-9._:-]{1,160})$/;
  function safeClone(v){try{return JSON.parse(JSON.stringify(v));}catch(_){return null;}}
  function now(){return Date.now();}
  function cleanString(v,max){v=String(v==null?"":v);return v.slice(0,max);}
  function cleanStringArray(v,maxItems,maxLen){var out=[];(Array.isArray(v)?v:[]).slice(0,maxItems).forEach(function(x){x=cleanString(x,maxLen).trim();if(x&&out.indexOf(x)<0)out.push(x);});return out;}
  function validKey(key){return KEY_RE.test(String(key||""));}
  function requireKey(key){key=String(key||"");if(!validKey(key)){var e=new Error("AI_DRAFT_KEY_INVALID");e.code="AI_DRAFT_KEY_INVALID";throw e;}return key;}
  function sanitizeDraft(input){input=input&&typeof input==="object"?input:{};var out={
    schemaVersion:SCHEMA_VERSION,
    assistantId:input.assistantId==null?null:cleanString(input.assistantId,128),
    baseUpdatedAt:Math.max(0,Number(input.baseUpdatedAt)||0),
    draftUpdatedAt:Math.max(0,Number(input.draftUpdatedAt)||now()),
    name:cleanString(input.name,80),description:cleanString(input.description,160),providerId:cleanString(input.providerId,64),
    modelMode:input.modelMode==="specific"?"specific":"default",model:input.model==null?null:cleanString(input.model,160),
    instructions:cleanString(input.instructions,24000),
    knowledge:{mode:input.knowledge&&input.knowledge.mode==="base"?"base":"none",baseId:input.knowledge&&input.knowledge.baseId?cleanString(input.knowledge.baseId,128):null},
    context:{mode:input.context&&input.context.mode==="recent"?"recent":"none",messageCount:[5,10,20].indexOf(Number(input.context&&input.context.messageCount))>=0?Number(input.context.messageCount):5},
    memory:{mode:input.memory&&input.memory.mode==="customer"?"customer":"none"},
    tools:{enabled:cleanStringArray(input.tools&&input.tools.enabled,64,128)},externalActions:{enabled:cleanStringArray(input.externalActions&&input.externalActions.enabled,64,128)},
    multimodal:{image:!!(input.multimodal&&input.multimodal.image),audio:!!(input.multimodal&&input.multimodal.audio)},enabled:input.enabled!==false
  };
  return out;
  }
  function normalizeStore(raw){if(typeof raw==="string"){try{raw=JSON.parse(raw);}catch(_){raw=null;}}raw=raw&&typeof raw==="object"&&!Array.isArray(raw)?raw:{};var drafts={};Object.keys(raw.drafts&&typeof raw.drafts==="object"?raw.drafts:{}).slice(0,MAX_DRAFTS*2).forEach(function(key){if(!validKey(key))return;var d=sanitizeDraft(raw.drafts[key]);if(now()-d.draftUpdatedAt<=MAX_AGE_MS)drafts[key]=d;});return{version:STORE_VERSION,drafts:drafts};}
  function keyFor(assistantId){if(assistantId==null||assistantId==="")return"new";var raw=String(assistantId);if(!/^[A-Za-z0-9._:-]{1,160}$/.test(raw)){var e=new Error("AI_DRAFT_ASSISTANT_ID_INVALID");e.code="AI_DRAFT_ASSISTANT_ID_INVALID";throw e;}return"assistant:"+raw;}
  function recoveryState(draft,assistant){
    if(!draft)return"none";
    if(!assistant)return"recover";
    var savedAt=Math.max(0,Number(assistant.updatedAt||assistant.updatedAtInMs)||0),baseAt=Math.max(0,Number(draft.baseUpdatedAt)||0),draftAt=Math.max(0,Number(draft.draftUpdatedAt)||0);
    if(!baseAt)return draftAt>savedAt?"conflict":"stale";
    if(baseAt!==savedAt)return"conflict";
    return draftAt>savedAt?"recover":"stale";
  }
  function createRepository(io){if(!io||typeof io.read!=="function"||typeof io.write!=="function")throw new Error("AI_DRAFT_STORAGE_REQUIRED");var chain=Promise.resolve();function mutate(fn){chain=chain.then(async function(){var store=normalizeStore(await io.read());var result=await fn(store);await io.write(JSON.stringify(store));return result;});return chain;}
    return{
      async load(key){key=requireKey(key);var store=normalizeStore(await io.read());return store.drafts[key]?safeClone(store.drafts[key]):null;},
      save(key,draft){key=requireKey(key);return mutate(function(store){var next=sanitizeDraft(Object.assign({},draft,{draftUpdatedAt:now()}));store.drafts[key]=next;var keys=Object.keys(store.drafts).sort(function(a,b){return Number(store.drafts[b].draftUpdatedAt)-Number(store.drafts[a].draftUpdatedAt);});keys.slice(MAX_DRAFTS).forEach(function(k){delete store.drafts[k];});return safeClone(next);});},
      remove(key){key=requireKey(key);return mutate(function(store){delete store.drafts[key];return true;});},
      async list(){var store=normalizeStore(await io.read());return Object.keys(store.drafts).filter(validKey).map(function(key){return{key:key,draft:safeClone(store.drafts[key])};});},
      recoveryState:recoveryState,
      isNewerThanSaved:function(draft,assistant){return recoveryState(draft,assistant)==="recover";},
      prune(){return mutate(function(store){var normalized=normalizeStore(store);store.version=normalized.version;store.drafts=normalized.drafts;return Object.keys(store.drafts).length;});}
    };
  }
  root.__extAiAssistantDraftsCore=Object.freeze({STORE_KEY:STORE_KEY,STORE_VERSION:STORE_VERSION,SCHEMA_VERSION:SCHEMA_VERSION,keyFor:keyFor,sanitizeDraft:sanitizeDraft,normalizeStore:normalizeStore,recoveryState:recoveryState,createRepository:createRepository});
})(typeof window!=="undefined"?window:globalThis);
