(function(root){
  "use strict";
  if(root.ExtensionFlowTemplatesCore)return;

  function uid(){return root.crypto&&root.crypto.randomUUID?root.crypto.randomUUID():"n-"+Date.now()+"-"+Math.random().toString(36).slice(2,10);}
  function node(id,type,x,y,data,next,other,expire,timeout){return{id:id,type:type,position:{x:x,y:y},data:data||{},nextNodeIds:Array.isArray(next)?next:[],nextNodeIdOnDifferentAnswer:other||null,nextNodeIdOnExpiration:expire||null,expirationTimeoutInMs:timeout||null};}
  function group(name,members,layoutMode){var t=Date.now();return{id:uid(),name:name,memberNodeIds:members.slice(),layoutMode:layoutMode==="structured"?"structured":"free",layoutRevision:1,collapsed:false,createdAtInMs:t,updatedAtInMs:t};}
  function manualTrigger(){return{type:"manual",activationTypes:["manual"],isCaseSensitive:false,keywordRules:[],sendToContacts:true,sendToGroups:false};}

  function buildJourney360(){
    var ids={};for(var i=1;i<=36;i++)ids[i]=uid();
    var n=[];
    n.push(node(ids[1],"start",0,420,{},[ids[2]]));
    n.push(node(ids[2],"randomizer",300,420,{mode:"sticky",weights:[{weight:50,nextNodeId:ids[3]},{weight:50,nextNodeId:ids[4]}]},[]));
    n.push(node(ids[3],"sendText",620,330,{text:"Olá! 👋 Sou o atendimento inteligente. Em poucos passos eu identifico sua necessidade e encaminho você pelo melhor caminho."},[ids[5]]));
    n.push(node(ids[4],"sendText",620,510,{text:"Oi! 👋 Vamos resolver isso juntos. Escolha uma opção e eu organizo o atendimento para você sem perder tempo."},[ids[5]]));
    n.push(node(ids[5],"sendText",940,420,{text:"Como posso ajudar?\n\n1️⃣ Comprar\n2️⃣ Solicitar orçamento\n3️⃣ Suporte / pós-venda\n4️⃣ Consultar pedido\n5️⃣ Financeiro\n6️⃣ Falar com uma pessoa"},[ids[6]]));
    n.push(node(ids[6],"userInput",1260,420,{expectedMessages:["1","comprar","compra","2","orçamento","orcamento","3","suporte","pós-venda","pos-venda","4","pedido","status","5","financeiro","6","humano","atendente"]},[ids[7],ids[7],ids[7],ids[15],ids[15],ids[15],ids[22],ids[22],ids[22],ids[22],ids[28],ids[28],ids[28],ids[31],ids[31],ids[35],ids[35],ids[35]],ids[33],ids[34],120000));

    // Compra · 7-14
    n.push(node(ids[7],"sendText",1620,-520,{text:"Perfeito. O que você procura?\n1 Produto\n2 Serviço\n3 Ainda não sei exatamente"},[ids[8]]));
    n.push(node(ids[8],"userInput",1940,-520,{expectedMessages:["1","produto","2","serviço","servico","3","não sei","nao sei"]},[ids[9],ids[9],ids[10],ids[10],ids[11],ids[11],ids[11],ids[11]],ids[33],ids[34],120000));
    n.push(node(ids[9],"sendText",2260,-660,{text:"Ótimo. Para produto, qual é sua urgência?\n1 Hoje / urgente\n2 Nesta semana\n3 Sem pressa"},[ids[12]]));
    n.push(node(ids[10],"sendText",2260,-500,{text:"Entendi. Para serviço, quando você pretende começar?\n1 Hoje / urgente\n2 Nesta semana\n3 Sem pressa"},[ids[12]]));
    n.push(node(ids[11],"sendText",2260,-340,{text:"Sem problema. Vamos descobrir juntos. Qual ritmo faz mais sentido?\n1 Quero resolver hoje\n2 Quero avaliar nesta semana\n3 Estou só pesquisando"},[ids[12]]));
    n.push(node(ids[12],"userInput",2580,-500,{expectedMessages:["1","hoje","urgente","2","semana","7 dias","3","sem pressa","pesquisando"]},[ids[35],ids[35],ids[35],ids[13],ids[13],ids[13],ids[14],ids[14],ids[14]],ids[33],ids[34],120000));
    n.push(node(ids[13],"sendText",2900,-580,{text:"Ótimo perfil. Já tenho contexto suficiente para uma continuidade consultiva e objetiva. Vou deixar este atendimento pronto para o próximo passo."},[ids[36]]));
    n.push(node(ids[14],"sendText",2900,-380,{text:"Perfeito. Sem pressão: sua intenção ficou registrada neste atendimento. Quando quiser avançar, basta iniciar novamente ou pedir atendimento humano."},[ids[36]]));

    // Orçamento · 15-21
    n.push(node(ids[15],"sendText",1620,-80,{text:"Vamos estruturar seu orçamento. Qual volume você imagina?\n1 Unidade\n2 Pequeno lote\n3 Volume maior"},[ids[16]]));
    n.push(node(ids[16],"userInput",1940,-80,{expectedMessages:["1","unidade","2","lote","3","volume","maior"]},[ids[17],ids[17],ids[17],ids[18],ids[18],ids[18],ids[18]],ids[33],ids[34],120000));
    n.push(node(ids[17],"sendText",2260,-140,{text:"Certo. Qual prazo você precisa?\n1 Hoje\n2 Até 7 dias\n3 Mais de 7 dias"},[ids[19]]));
    n.push(node(ids[18],"sendText",2260,20,{text:"Para um volume maior, prazo é importante. Quando você precisa?\n1 Hoje\n2 Até 7 dias\n3 Mais de 7 dias"},[ids[19]]));
    n.push(node(ids[19],"userInput",2580,-60,{expectedMessages:["1","hoje","2","7 dias","semana","3","mais de 7 dias","15 dias"]},[ids[35],ids[35],ids[20],ids[20],ids[20],ids[21],ids[21],ids[21]],ids[33],ids[34],120000));
    n.push(node(ids[20],"sendText",2900,-140,{text:"Perfeito. Seu orçamento tem prazo definido e pode seguir para análise comercial com prioridade normal."},[ids[36]]));
    n.push(node(ids[21],"sendText",2900,40,{text:"Ótimo. Como há mais prazo, o atendimento pode preparar uma proposta com mais calma e melhor contexto."},[ids[36]]));

    // Suporte · 22-27
    n.push(node(ids[22],"sendText",1620,420,{text:"Vamos classificar o suporte. Qual assunto descreve melhor?\n1 Problema técnico\n2 Pedido / entrega\n3 Financeiro\n4 Outro assunto"},[ids[23]]));
    n.push(node(ids[23],"userInput",1940,420,{expectedMessages:["1","técnico","tecnico","2","pedido","entrega","3","financeiro","4","outro"]},[ids[24],ids[24],ids[24],ids[28],ids[28],ids[28],ids[31],ids[31],ids[27],ids[27]],ids[33],ids[34],120000));
    n.push(node(ids[24],"sendText",2260,340,{text:"Esse problema impede totalmente o uso?\n1 Sim, está bloqueando\n2 Não, ainda consigo usar"},[ids[25]]));
    n.push(node(ids[25],"userInput",2580,340,{expectedMessages:["1","sim","bloqueando","2","não","nao"]},[ids[26],ids[26],ids[26],ids[27],ids[27],ids[27]],ids[33],ids[34],120000));
    n.push(node(ids[26],"sendText",2900,280,{text:"Entendi. Como o impacto é bloqueante, vou interromper a automação e priorizar atendimento humano."},[ids[35]]));
    n.push(node(ids[27],"sendText",2900,460,{text:"Obrigado. O caso foi classificado e já está organizado para continuidade sem repetir as perguntas iniciais."},[ids[36]]));

    // Pedido · 28-30
    n.push(node(ids[28],"sendText",1620,820,{text:"Digite o número/código do pedido. Se preferir atendimento direto, responda HUMANO."},[ids[29]]));
    n.push(node(ids[29],"userInput",1940,820,{expectedMessages:["humano","atendente"]},[ids[35],ids[35]],ids[30],ids[34],120000));
    n.push(node(ids[30],"sendText",2260,820,{text:"Recebi a referência informada. O atendimento já pode seguir para consulta de status sem retornar ao menu inicial."},[ids[36]]));

    // Financeiro · 31-32
    n.push(node(ids[31],"sendText",1620,1120,{text:"Qual assunto financeiro?\n1 Segunda via / documento\n2 Cobrança divergente\n3 Negociação\n4 Falar com humano"},[ids[32]]));
    n.push(node(ids[32],"userInput",1940,1120,{expectedMessages:["1","segunda via","documento","2","cobrança","cobranca","3","negociação","negociacao","4","humano","atendente"]},[ids[36],ids[36],ids[36],ids[35],ids[35],ids[35],ids[35],ids[35],ids[35],ids[35],ids[35],ids[35]],ids[33],ids[34],120000));

    // Recuperação + encerramentos · 33-36
    n.push(node(ids[33],"sendText",2300,1360,{text:"Não consegui reconhecer essa opção com segurança. Para evitar um loop ou uma resposta errada, vou encaminhar você para atendimento humano."},[ids[35]]));
    n.push(node(ids[34],"sendText",2580,1460,{text:"O tempo de resposta terminou. Encerramos esta execução com segurança; quando quiser, você pode iniciar novamente."},[ids[36]]));
    n.push(node(ids[35],"endHuman",3260,620,{label:"Transferir para humano"},[]));
    n.push(node(ids[36],"end",3260,1040,{label:"Fim controlado"},[]));

    var nodeGroups=[
      group("Abertura inteligente",[ids[2],ids[3],ids[4],ids[5],ids[6]]),
      group("Compra e qualificação",[ids[7],ids[8],ids[9],ids[10],ids[11],ids[12],ids[13],ids[14]]),
      group("Orçamento",[ids[15],ids[16],ids[17],ids[18],ids[19],ids[20],ids[21]]),
      group("Suporte / pós-venda",[ids[22],ids[23],ids[24],ids[25],ids[26],ids[27]]),
      group("Pedido",[ids[28],ids[29],ids[30]]),
      group("Financeiro",[ids[31],ids[32]]),
      group("Recuperação e encerramento",[ids[33],ids[34],ids[35],ids[36]])
    ];
    var t=Date.now();
    return{id:uid(),name:"Atendimento 360 · Jornada Premium",description:"Modelo demonstrativo com 36 etapas, seis intenções, A/B de abertura, qualificação, orçamento, suporte, pedido, financeiro, timeout, fallback seguro e handoff humano.",color:"#00d084",isActive:false,startNodeId:ids[1],favorite:true,nodes:n,nodeGroups:nodeGroups,trigger:manualTrigger(),createdAtInMs:t,updatedAtInMs:t,template:{id:"showcase-360-premium",version:1}};
  }

  function buildCommercial50(){
    var ids={};for(var i=1;i<=50;i++)ids[i]=uid();var n=[];
    n.push(node(ids[1],"start",0,240,{},[ids[2]]));
    n.push(node(ids[2],"sendText",280,240,{text:"Olá! 👋 Vou te ajudar a encontrar o melhor caminho. Responda 1 para Comprar, 2 para Orçamento, 3 para Pós-venda/Suporte ou 4 para falar com um atendente."},[ids[3]]));
    n.push(node(ids[3],"userInput",560,240,{expectedMessages:["1","comprar","compra","2","orçamento","orcamento","3","suporte","pós-venda","pos-venda","4","humano","atendente"]},[ids[4],ids[4],ids[4],ids[15],ids[15],ids[15],ids[26],ids[26],ids[26],ids[26],ids[39],ids[39],ids[39]],ids[42],ids[40],120000));
    n.push(node(ids[4],"sendText",900,-540,{text:"Ótimo. O que você procura? Responda 1 Produto, 2 Serviço ou 3 Ainda estou pesquisando."},[ids[5]]));
    n.push(node(ids[5],"userInput",1180,-540,{expectedMessages:["1","produto","2","serviço","servico","3","pesquisando"]},[ids[6],ids[6],ids[6],ids[6],ids[6],ids[14],ids[14]],ids[43],ids[41],120000));
    n.push(node(ids[6],"sendText",1460,-540,{text:"Qual é sua urgência? 1 Hoje, 2 Nesta semana, 3 Sem pressa."},[ids[7]]));
    n.push(node(ids[7],"userInput",1740,-540,{expectedMessages:["1","hoje","2","semana","3","sem pressa"]},[ids[8],ids[8],ids[9],ids[9],ids[10],ids[10]],ids[44],ids[41],120000));
    n.push(node(ids[8],"sendText",2020,-700,{text:"Perfeito. Como é urgente, vou priorizar atendimento humano para agilizar."},[ids[39]]));
    n.push(node(ids[9],"sendText",2020,-540,{text:"Qual faixa combina melhor? 1 Até 500, 2 de 500 a 2.000, 3 acima de 2.000."},[ids[11]]));
    n.push(node(ids[10],"sendText",2020,-380,{text:"Sem problema. Qual faixa combina melhor? 1 Até 500, 2 de 500 a 2.000, 3 acima de 2.000."},[ids[11]]));
    n.push(node(ids[11],"userInput",2300,-460,{expectedMessages:["1","até 500","ate 500","2","500 a 2000","3","acima de 2000"]},[ids[12],ids[12],ids[12],ids[12],ids[12],ids[13],ids[13]],ids[44],ids[41],120000));
    n.push(node(ids[12],"sendText",2580,-540,{text:"Obrigado! Registrei suas preferências. Posso encerrar por aqui ou você pode falar com um atendente respondendo HUMANO."},[ids[45]]));
    n.push(node(ids[13],"sendText",2580,-380,{text:"Pelo perfil informado, vale acelerar a conversa com nosso atendimento."},[ids[39]]));
    n.push(node(ids[14],"sendText",1460,-220,{text:"Sem compromisso. Posso te deixar um resumo e você volta quando quiser."},[ids[45]]));
    n.push(node(ids[15],"sendText",900,20,{text:"Vamos montar seu orçamento. Responda 1 para unidade, 2 para pequeno lote, 3 para volume maior."},[ids[16]]));
    n.push(node(ids[16],"userInput",1180,20,{expectedMessages:["1","unidade","2","lote","3","volume"]},[ids[17],ids[17],ids[18],ids[18],ids[18],ids[18]],ids[43],ids[41],120000));
    n.push(node(ids[17],"sendText",1460,-20,{text:"Qual prazo? 1 Hoje, 2 até 7 dias, 3 acima de 7 dias."},[ids[19]]));
    n.push(node(ids[18],"sendText",1460,140,{text:"Para quantidade maior preciso entender o prazo. 1 Hoje, 2 até 7 dias, 3 acima de 7 dias."},[ids[19]]));
    n.push(node(ids[19],"userInput",1740,60,{expectedMessages:["1","hoje","2","7 dias","3","mais de 7 dias"]},[ids[20],ids[20],ids[21],ids[21],ids[22],ids[22]],ids[44],ids[41],120000));
    n.push(node(ids[20],"sendText",2020,-20,{text:"Prazo de hoje detectado. Vou encaminhar para atendimento humano."},[ids[39]]));
    n.push(node(ids[21],"sendText",2020,100,{text:"Você prefere receber retorno por aqui? 1 Sim, 2 Quero falar com humano agora."},[ids[23]]));
    n.push(node(ids[22],"sendText",2020,220,{text:"Seu prazo permite analisar com calma. Deseja 1 receber orientação por aqui ou 2 falar com humano?"},[ids[23]]));
    n.push(node(ids[23],"userInput",2300,160,{expectedMessages:["1","sim","por aqui","2","humano"]},[ids[24],ids[24],ids[24],ids[39],ids[39]],ids[44],ids[41],120000));
    n.push(node(ids[24],"sendText",2580,100,{text:"Perfeito. As informações foram coletadas para continuidade do orçamento."},[ids[25]]));
    n.push(node(ids[25],"end",2860,100,{label:"Fim · Orçamento"},[]));
    n.push(node(ids[26],"sendText",900,560,{text:"Certo. Qual assunto? 1 Problema técnico, 2 Pedido/status, 3 Financeiro, 4 Outro."},[ids[27]]));
    n.push(node(ids[27],"userInput",1180,560,{expectedMessages:["1","técnico","tecnico","2","pedido","status","3","financeiro","4","outro"]},[ids[28],ids[28],ids[28],ids[31],ids[31],ids[31],ids[34],ids[34],ids[37],ids[37]],ids[43],ids[41],120000));
    n.push(node(ids[28],"sendText",1460,440,{text:"O problema impede totalmente o uso? 1 Sim, 2 Não."},[ids[29]]));
    n.push(node(ids[29],"userInput",1740,440,{expectedMessages:["1","sim","2","não","nao"]},[ids[30],ids[30],ids[36],ids[36],ids[36]],ids[44],ids[41],120000));
    n.push(node(ids[30],"sendText",2020,400,{text:"Entendi. Como é bloqueante, vou encaminhar imediatamente."},[ids[39]]));
    n.push(node(ids[31],"sendText",1460,600,{text:"Seu pedido está atrasado? 1 Sim, 2 Não, 3 Não sei."},[ids[32]]));
    n.push(node(ids[32],"userInput",1740,600,{expectedMessages:["1","sim","2","não","nao","3","não sei","nao sei"]},[ids[33],ids[33],ids[36],ids[36],ids[36],ids[36],ids[36],ids[36]],ids[44],ids[41],120000));
    n.push(node(ids[33],"sendText",2020,560,{text:"Vou priorizar a análise do status com um atendente."},[ids[39]]));
    n.push(node(ids[34],"sendText",1460,760,{text:"É cobrança/segunda via? 1 Sim, 2 Outro assunto financeiro."},[ids[35]]));
    n.push(node(ids[35],"userInput",1740,760,{expectedMessages:["1","sim","2","outro"]},[ids[36],ids[36],ids[39],ids[39]],ids[44],ids[41],120000));
    n.push(node(ids[36],"sendText",2300,580,{text:"Obrigado. O caso foi classificado e pode seguir pelo atendimento normal."},[ids[45]]));
    n.push(node(ids[37],"sendText",1460,920,{text:"Descreva resumidamente o assunto ou responda HUMANO para atendimento."},[ids[38]]));
    n.push(node(ids[38],"userInput",1740,920,{expectedMessages:["humano","atendente"]},[ids[39],ids[39]],ids[36],ids[41],120000));
    n.push(node(ids[39],"endHuman",3160,280,{label:"Handoff humano"},[]));
    n.push(node(ids[40],"sendText",560,520,{text:"Ainda está por aí? Responda 1, 2, 3 ou 4 para eu continuar."},[ids[46]]));
    n.push(node(ids[41],"sendText",2020,1080,{text:"Parece que ficamos sem resposta. Quando quiser, é só iniciar novamente."},[ids[45]]));
    n.push(node(ids[42],"sendText",840,360,{text:"Não entendi. Use 1 Comprar, 2 Orçamento, 3 Suporte ou 4 Humano."},[ids[46]]));
    n.push(node(ids[43],"sendText",1180,1120,{text:"Essa opção não corresponde às alternativas. Vou repetir a pergunta principal para você."},[ids[46]]));
    n.push(node(ids[44],"sendText",2300,1120,{text:"Não consegui reconhecer essa resposta. Você pode responder HUMANO para atendimento ou reiniciar."},[ids[47]]));
    n.push(node(ids[45],"end",3160,760,{label:"Fim controlado"},[]));
    n.push(node(ids[46],"sendText",1120,360,{text:"Menu: 1 Comprar · 2 Orçamento · 3 Pós-venda/Suporte · 4 Humano."},[ids[47]]));
    n.push(node(ids[47],"userInput",1400,360,{expectedMessages:["1","comprar","2","orçamento","orcamento","3","suporte","4","humano","atendente"]},[ids[4],ids[4],ids[15],ids[15],ids[15],ids[26],ids[26],ids[39],ids[39],ids[39]],ids[48],ids[49],120000));
    n.push(node(ids[48],"sendText",1680,1160,{text:"Ainda não reconheci a opção. Para evitar um loop, vou encerrar este atendimento automático."},[ids[50]]));
    n.push(node(ids[49],"sendText",1680,1240,{text:"Tempo esgotado. Encerrando com segurança; você pode iniciar novamente quando quiser."},[ids[50]]));
    n.push(node(ids[50],"end",1960,1200,{label:"Fim · fallback"},[]));
    var nodeGroups=[
      group("Entrada",[ids[2],ids[3]]),
      group("Compra",[ids[4],ids[5],ids[6],ids[7],ids[8],ids[9],ids[10],ids[11],ids[12],ids[13],ids[14]]),
      group("Orçamento",[ids[15],ids[16],ids[17],ids[18],ids[19],ids[20],ids[21],ids[22],ids[23],ids[24],ids[25]]),
      group("Pós-venda",[ids[26],ids[27],ids[28],ids[29],ids[30],ids[31],ids[32],ids[33],ids[34],ids[35],ids[36],ids[37],ids[38]]),
      group("Fallbacks",[ids[40],ids[41],ids[42],ids[43],ids[44],ids[46],ids[47],ids[48],ids[49]]),
      group("Encerramento",[ids[39],ids[45],ids[50]])
    ];
    var t=Date.now();return{id:uid(),name:"Qualificação Comercial Avançada",description:"Modelo avançado com compra, orçamento, pós-venda, fallback, timeout, recuperação e handoff humano.",color:"#10b981",isActive:false,startNodeId:ids[1],favorite:false,nodes:n,nodeGroups:nodeGroups,trigger:manualTrigger(),createdAtInMs:t,updatedAtInMs:t,template:{id:"advanced-commercial-qualification",version:2}};
  }

  var TEMPLATE_META=Object.freeze([
    Object.freeze({id:"showcase-360-premium",name:"Atendimento 360 · Jornada Premium",description:"36 etapas autossuficientes com seis intenções, A/B de abertura, qualificação, orçamento, suporte, pedido, financeiro, fallback, timeout e humano.",version:1,nodeCount:36,badge:"Destaque",recommended:true}),
    Object.freeze({id:"advanced-commercial-qualification",name:"Qualificação Comercial Avançada",description:"50 etapas com compra, orçamento, pós-venda, recuperação, timeout e handoff humano.",version:2,nodeCount:50,badge:"Extenso",recommended:false})
  ]);

  function targets(n){var out=(n&&Array.isArray(n.nextNodeIds)?n.nextNodeIds:[]).slice();[n&&n.nextNodeIdOnDifferentAnswer,n&&n.nextNodeIdOnExpiration,n&&n.nextNodeIdOnConditionFalse].forEach(function(id){if(id)out.push(id);});if(n&&n.data&&Array.isArray(n.data.weights))n.data.weights.forEach(function(w){if(w&&w.nextNodeId)out.push(w.nextNodeId);});return out;}
  function validate(flow){
    var ids=Object.create(null),errors=[],startCount=0;
    (flow&&flow.nodes||[]).forEach(function(n){if(!n||!n.id){errors.push("node_without_id");return;}if(ids[n.id])errors.push("duplicate:"+n.id);ids[n.id]=true;if(n.type==="start")startCount++;});
    (flow&&flow.nodes||[]).forEach(function(n){if(!n||!n.id)return;targets(n).forEach(function(id){if(!ids[id])errors.push("missing:"+id);});if(n.type==="userInput"&&n.data&&Array.isArray(n.data.expectedMessages)&&n.data.expectedMessages.length!==(n.nextNodeIds||[]).length)errors.push("answer_route_count:"+n.id);if(n.type==="randomizer"){var weights=n.data&&Array.isArray(n.data.weights)?n.data.weights:[];if(weights.length<2||weights.some(function(w){return !w||!ids[w.nextNodeId]||!(Number(w.weight)>0);}))errors.push("randomizer_invalid:"+n.id);}});
    if(startCount!==1)errors.push("start_count:"+startCount);if(!flow||!ids[flow.startNodeId])errors.push("start_missing");
    var owner=Object.create(null),groupIds=Object.create(null);(flow&&Array.isArray(flow.nodeGroups)?flow.nodeGroups:[]).forEach(function(g){if(!g||!g.id){errors.push("group_without_id");return;}if(groupIds[g.id])errors.push("group_duplicate:"+g.id);groupIds[g.id]=true;var members=Array.isArray(g.memberNodeIds)?g.memberNodeIds:[];if(members.length<2)errors.push("group_too_small:"+g.id);members.forEach(function(id){if(!ids[id])errors.push("group_missing:"+id);var target=(flow.nodes||[]).find(function(n){return n&&n.id===id;});if(target&&target.type==="start")errors.push("group_start:"+id);if(owner[id])errors.push("group_owner_duplicate:"+id);owner[id]=g.id;});});
    return{ok:errors.length===0,errors:errors,nodeCount:(flow&&flow.nodes||[]).length,groupCount:(flow&&flow.nodeGroups||[]).length};
  }

  function instantiate(id){var flow;if(id==="showcase-360-premium")flow=buildJourney360();else if(id==="advanced-commercial-qualification")flow=buildCommercial50();else throw new Error("FLOW_TEMPLATE_NOT_FOUND");var check=validate(flow);var meta=TEMPLATE_META.find(function(item){return item.id===id;});if(meta&&check.nodeCount!==meta.nodeCount)check.errors.push("template_node_count:"+check.nodeCount);if(check.errors.length)throw new Error("FLOW_TEMPLATE_INVALID:"+check.errors.join(","));return flow;}

  root.ExtensionFlowTemplatesCore=Object.freeze({list:function(){return TEMPLATE_META.map(function(item){return Object.assign({},item);});},instantiate:instantiate,validate:validate});
})(typeof window!=="undefined"?window:globalThis);
