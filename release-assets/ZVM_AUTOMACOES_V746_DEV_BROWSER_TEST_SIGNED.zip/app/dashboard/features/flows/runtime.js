;
try{
(function () {
  "use strict";

  if (window.__extFluxosModuleBooted) return;
  window.__extFluxosModuleBooted = true;

  var STORAGE_KEY = "EXTUI:extappFlowStore";
  var RUNNING_STORAGE_KEY = "EXTUI:extappFlowRunningStore";

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
  }
  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }

  var sendToWhatsAppTab = window.__extSendToWhatsAppTab;

  function directContactTestBlockReason(flow) {
    if (flow && flow.trigger && flow.trigger.sendToContacts === false) {
      return "Este Fluxo está configurado para não enviar a contatos individuais. Ative ENVIAR PARA CONTATOS em Gatilho do fluxo para executar um teste.";
    }
    return "";
  }

  function friendlyAutomationTestError(error, flow) {
    var raw = String(error && error.message || error || "");
    if (/flow does not allow direct contacts/i.test(raw)) {
      return directContactTestBlockReason(flow) || "Este Fluxo não permite envios para contatos individuais. Ative ENVIAR PARA CONTATOS em Gatilho do fluxo para executar um teste.";
    }
    return raw || "Não foi possível iniciar o teste.";
  }

  function openAutomationTestDialog(options) {
    var overlay = el("div", { class: "extuifModalOverlay" });
    var modal = el("div", { class: "extuifModal extuifAutomationTestModal", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuifAutomationTestTitle" });
    modal.appendChild(el("h3", { id: "extuifAutomationTestTitle", text: "Executar teste" }));
    modal.appendChild(el("p", { class: "extuifAutomationTestWarning", text: "O teste fará envios reais para um único contato usando a mesma automação." }));
    modal.appendChild(el("label", { text: "Contato" }));
    var resultsId = "extuifAutomationTestResults-" + Date.now();
    var input = el("input", { type: "search", placeholder: "Busque por nome ou número", autocomplete: "off", role: "combobox", "aria-autocomplete": "list", "aria-controls": resultsId, "aria-expanded": "false" });
    var results = el("div", { id: resultsId, class: "extuifAutomationTestResults", role: "listbox" });
    modal.appendChild(input);
    modal.appendChild(results);
    var selected = null;
    var searchTimer = null;
    var searchSeq = 0;
    var closed = false;
    var sending = false;
    var lifecycle = null;
    async function search() {
      var seq = ++searchSeq;
      results.innerHTML = '<div class="extuifAutomationTestEmpty">Buscando...</div>';
      try {
        var contacts = await sendToWhatsAppTab("EXTUI_DISPAROS_SEARCH_CONTACTS", { query: input.value });
        if (closed || seq !== searchSeq) return;
        results.innerHTML = "";
        input.setAttribute("aria-expanded", "true");
        if (!contacts.length) { results.appendChild(el("div", { class: "extuifAutomationTestEmpty", text: "Nenhum contato encontrado" })); return; }
        contacts.slice(0, 20).forEach(function (contact) {
          var row = el("button", { type: "button", class: "extuifAutomationTestContact", role: "option", "aria-selected": "false", text: contact.label + (contact.displayNumber ? " · " + contact.displayNumber : "") });
          row.addEventListener("click", function () {
            selected = contact;
            input.value = contact.label;
            Array.prototype.forEach.call(results.children, function (child) { var active = child === row; child.classList.toggle("extuiSelected", active); if (child.getAttribute && child.getAttribute("role") === "option") child.setAttribute("aria-selected", active ? "true" : "false"); });
            confirmBtn.disabled = false;
          });
          results.appendChild(row);
        });
      } catch (err) {
        if (closed || seq !== searchSeq) return;
        results.innerHTML = "";
        results.appendChild(el("div", { class: "extuifAutomationTestEmpty", text: err.message }));
      }
    }
    input.addEventListener("input", function () { selected = null; confirmBtn.disabled = true; clearTimeout(searchTimer); searchTimer = setTimeout(search, 250); });
    input.addEventListener("focus", search);
    input.addEventListener("keydown", function (event) { if (event.key === "ArrowDown") { var first = results.querySelector('[role="option"]'); if (first) { event.preventDefault(); first.focus(); } } });
    var actions = el("div", { class: "extuifModalActions" });
    var cancelBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" });
    var confirmBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Enviar teste", disabled: "disabled" });
    function close() {
      if (closed) return;
      closed = true;
      searchSeq++;
      clearTimeout(searchTimer);
      input.setAttribute("aria-expanded", "false");
      if (lifecycle) lifecycle.close("action"); else overlay.remove();
    }
    cancelBtn.addEventListener("click", close);
    confirmBtn.addEventListener("click", async function () {
      if (!selected || sending) return;
      sending = true;
      confirmBtn.disabled = true;
      cancelBtn.disabled = true;
      modal.setAttribute("aria-busy", "true");
      try { await options.onConfirm(selected); sending = false; close(); toast("Teste iniciado para " + selected.label + "."); }
      catch (err) { sending = false; modal.removeAttribute("aria-busy"); cancelBtn.disabled = false; toast(friendlyAutomationTestError(err, options && options.flow), true); confirmBtn.disabled = false; }
    });
    actions.appendChild(cancelBtn); actions.appendChild(confirmBtn); modal.appendChild(actions); overlay.appendChild(modal); document.body.appendChild(overlay);
    lifecycle = window.__extDialogLifecycle ? window.__extDialogLifecycle(overlay, modal, { initialFocus: input, beforeClose: function () { return !sending; }, onClose: function () { if (!closed) { closed = true; searchSeq++; clearTimeout(searchTimer); } } }) : null;
    if (!lifecycle) input.focus();
  }
  window.__extOpenAutomationTestDialog = openAutomationTestDialog;

                                                                             
                                                                            
                                                                
  var ICONS = {
    edit: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
    zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
    flow: '<rect width="8" height="8" x="3" y="3" rx="2"/><path d="M7 11v4a2 2 0 0 0 2 2h4"/><rect width="8" height="8" x="13" y="13" rx="2"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    arrowLeft: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    play: '<path d="m6 3 14 9-14 9z"/>',
                                                                        
                                                                             
                                                                             
                                                      
    shuffle: '<path d="m18 14 3 3-3 3"/><path d="m18 4 3 3-3 3"/><path d="M3 7h3c4 0 5 10 9 10h6"/><path d="M3 17h3c1.2 0 2.1-.8 3-2M14 7c.4 0 .7 0 1 0h6"/>',
    expand: '<path d="M15 3h6v6"/><path d="m21 3-7 7"/><path d="M9 21H3v-6"/><path d="m3 21 7-7"/>',
    sparkles: '<path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8Z"/><path d="M19 14l.9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9Z"/><path d="M5 14l.9 2.1L8 17l-2.1.9L5 20l-.9-2.1L2 17l2.1-.9Z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    filter: '<path d="M22 3H2l8 9.46V19l4 2v-8.54z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06-2.83 2.83-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21h-4v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06-2.83-2.83.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3v-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06 2.83-2.83.06.06A1.65 1.65 0 0 0 8.92 4a1.65 1.65 0 0 0 1-1.51V2h4v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06 2.83 2.83-.06.06A1.65 1.65 0 0 0 19.4 9c.12.37.48.63.87.63H21v4h-.73c-.39 0-.75.26-.87.63z"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    selection: '<rect x="4" y="4" width="16" height="16" rx="2" stroke-dasharray="3 3"/><path d="M2 8V2h6M16 2h6v6M22 16v6h-6M8 22H2v-6"/>'
  };
  function icon(name, extraClass) {
    var span = document.createElement("span");
    span.className = "extui-svgicon" + (extraClass ? " " + extraClass : "");
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || "") + "</svg>";
    return span;
  }

  function storageGet(key) {
    return window.__extDashboardShell.storageGet(key).then(function (result) { return result ? result[key] : undefined; });
  }
  function storageSet(key, value) {
    var obj = {}; obj[key] = value;
    return window.__extDashboardShell.storageSet(obj);
  }
  function parsePersisted(raw) {
    if (raw == null || raw === "") return null;
    var parsed;
    try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (err) { err.code = err.code || "FLOW_STORE_CORRUPT"; throw err; }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state)) {
      var invalid = new Error("Os dados de Fluxos estão inválidos e não serão sobrescritos.");
      invalid.code = "FLOW_STORE_CORRUPT";
      throw invalid;
    }
    return parsed.state;
  }
  var flowStartMigrationDone = false;
  var flowImportedLayoutMigrationDone = false;
  function flowGroupsCore() { return window.ExtensionFlowGroupsCore || null; }
  function flowNodeTargets(node) {
    var out = [];
    if (!node || typeof node !== "object") return out;
    if (isIntentionalTerminalNode(node)) return out;
    (Array.isArray(node.nextNodeIds) ? node.nextNodeIds : []).forEach(function (id) { if (id && out.indexOf(String(id)) < 0) out.push(String(id)); });
    [node.nextNodeIdOnExpiration, node.nextNodeIdOnDifferentAnswer, node.nextNodeIdOnConditionFalse].forEach(function (id) { if (id && out.indexOf(String(id)) < 0) out.push(String(id)); });
    var weights = node.data && Array.isArray(node.data.weights) ? node.data.weights : [];
    weights.forEach(function (weight) { var id = weight && weight.nextNodeId; if (id && out.indexOf(String(id)) < 0) out.push(String(id)); });
    return out;
  }
  var FLOW_OPT_IN_TERMINAL_TYPES = ["sendText","sendAudio","sendImage","sendVideo","sendSticker","sendDocument","sendPix","sendList","sendContact","sendSignature","sendQuickResponse","sendMedia","moveToColumn","condition"];
  function isIntentionalTerminalNode(node) {
    if (!node || typeof node !== "object") return false;
    if (node.type === "end" || node.type === "endHuman") return true;
    return FLOW_OPT_IN_TERMINAL_TYPES.indexOf(node.type) >= 0 && !!(node.data && node.data.isTerminal === true);
  }
  function analyzeFlowGraph(flow) {
    var nodes = flow && Array.isArray(flow.nodes) ? flow.nodes : [], byId = Object.create(null), issues = [], reachable = Object.create(null);
    nodes.forEach(function (node) { if (node && node.id) byId[String(node.id)] = node; });
    var start = byId[String(flow && flow.startNodeId || "")] || nodes.find(function (node) { return node && node.type === "start"; }) || null;
    if (!start) issues.push({ severity: "error", code: "missing_start", message: "O fluxo não possui uma etapa inicial válida." });
    nodes.forEach(function (node) {
      if (!node || !node.id) { issues.push({ severity: "error", code: "node_without_id", message: "Existe uma etapa sem identificador válido." }); return; }
      if (node.type === "unsupported" || node.data && node.data.requiresReview === true) issues.push({ severity: "error", code: "unsupported_imported_node", nodeId: String(node.id), message: "Uma etapa importada precisa ser revisada e convertida antes de ativar o fluxo." });
      flowNodeTargets(node).forEach(function (target) { if (!byId[target]) issues.push({ severity: "error", code: "dangling_target", nodeId: String(node.id), message: "Uma saída aponta para uma etapa que não existe mais." }); });
      if (node.type === "condition" && !isIntentionalTerminalNode(node)) {
        if (!(node.nextNodeIds && node.nextNodeIds[0])) issues.push({ severity: "error", code: "condition_true_missing", nodeId: String(node.id), message: "Uma condição não possui caminho para quando for atendida." });
        if (!node.nextNodeIdOnConditionFalse) issues.push({ severity: "error", code: "condition_false_missing", nodeId: String(node.id), message: "Uma condição não possui caminho para quando não for atendida." });
      }
      if (["sendAudio", "sendImage", "sendVideo", "sendSticker", "sendDocument", "sendQuickResponse", "sendPix", "sendList", "sendContact", "sendSignature"].indexOf(node.type) >= 0 && !(node.data && node.data.itemId)) {
        issues.push({ severity: "error", code: "saved_item_missing", nodeId: String(node.id), message: "Selecione um item salvo para esta etapa antes de executar o fluxo." });
      }
      if (node.type === "randomizer") {
        var weights = node.data && Array.isArray(node.data.weights) ? node.data.weights : [];
        if (weights.length < 2 || weights.some(function (weight) { return !weight || !weight.nextNodeId || !byId[String(weight.nextNodeId)]; })) issues.push({ severity: "error", code: "randomizer_incomplete", nodeId: String(node.id), message: "Um aleatorizador precisa de pelo menos dois caminhos válidos." });
      }
    });
    if (start && start.id) {
      var queue = [String(start.id)]; reachable[String(start.id)] = true;
      while (queue.length) { var current = byId[queue.shift()]; flowNodeTargets(current).forEach(function (target) { if (byId[target] && !reachable[target]) { reachable[target] = true; queue.push(target); } }); }
    }
    nodes.forEach(function (node) {
      if (!node || !node.id) return;
      if (start && !reachable[String(node.id)]) issues.push({ severity: "warning", code: "unreachable", nodeId: String(node.id), message: "Uma etapa não é alcançável a partir do início." });
      if (!isIntentionalTerminalNode(node) && flowNodeTargets(node).length === 0 && node.type !== "userInput" && node.type !== "delay" && node.type !== "intervalo") issues.push({ severity: "warning", code: "dead_end", nodeId: String(node.id), message: "Uma etapa termina sem apontar para a próxima etapa." });
    });
    var errors = issues.filter(function (issue) { return issue.severity === "error"; }), warnings = issues.filter(function (issue) { return issue.severity === "warning"; });
    return { valid: errors.length === 0, errors: errors, warnings: warnings, issues: issues, reachableCount: Object.keys(reachable).length, nodeCount: nodes.length };
  }
  function flowIssueNodeLabel(flow, nodeId) {
    if (!nodeId) return "Fluxo";
    var node = flow && Array.isArray(flow.nodes) ? flow.nodes.find(function (candidate) { return candidate && String(candidate.id || "") === String(nodeId); }) : null;
    if (!node) return "Etapa";
    var data = node.data || {};
    var typeDef = Array.isArray(NODE_TYPES) ? NODE_TYPES.find(function (def) { return def && def.type === node.type; }) : null;
    return String(data.label || data.title || data.name || typeDef && typeDef.label || node.type || "Etapa");
  }
  function openFlowDiagnostics(flow, flowHealth) {
    flowHealth = flowHealth || analyzeFlowGraph(flow);
    var overlay = el("div", { class: "extuifModalOverlay extuifDiagnosticsOverlay" });
    var titleId = "extuifDiagnosticsTitle-" + Date.now();
    var modal = el("div", { class: "extuifModal extuifDiagnostics", role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, tabindex: "-1" });
    var head = el("div", { class: "extuifDiagnosticsHeader" });
    head.appendChild(el("div", { class: "extuifDiagnosticsHeading" }, [
      el("span", { class: "extuifDiagnosticsEyebrow", text: "DIAGNÓSTICO DO FLUXO" }),
      el("h3", { id: titleId, text: flow && flow.name ? flow.name : "Fluxo" })
    ]));
    var closeBtn = el("button", { type: "button", class: "extuifDiagnosticsClose", "aria-label": "Fechar diagnóstico", text: "×" });
    head.appendChild(closeBtn); modal.appendChild(head);
    var summary = el("div", { class: "extuifDiagnosticsSummary" });
    summary.appendChild(el("span", { class: "extuifDiagnosticsCount is-error", text: flowHealth.errors.length + " erro(s)" }));
    summary.appendChild(el("span", { class: "extuifDiagnosticsCount is-warning", text: flowHealth.warnings.length + " aviso(s)" }));
    modal.appendChild(summary);
    var body = el("div", { class: "extuifDiagnosticsBody" });
    function appendSection(title, issues, severity) {
      if (!issues.length) return;
      var section = el("section", { class: "extuifDiagnosticsSection is-" + severity });
      section.appendChild(el("h4", { text: title + " (" + issues.length + ")" }));
      issues.forEach(function (issue) {
        var row = el("article", { class: "extuifDiagnosticsIssue is-" + severity });
        var copy = el("div", { class: "extuifDiagnosticsIssueCopy" });
        copy.appendChild(el("strong", { text: issue.nodeId ? flowIssueNodeLabel(flow, issue.nodeId) : "Fluxo" }));
        copy.appendChild(el("span", { text: issue.message }));
        row.appendChild(copy);
        if (issue.nodeId) {
          var gotoBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifDiagnosticsGoto", text: "Ir para etapa" });
          gotoBtn.addEventListener("click", function (event) {
            event.stopPropagation();
            close();
            openFlowCanvas(flow, { focusNodeId: String(issue.nodeId) }).catch(function (err) { toast(err && err.message || "Não foi possível abrir a etapa.", true); });
          });
          row.appendChild(gotoBtn);
        }
        section.appendChild(row);
      });
      body.appendChild(section);
    }
    appendSection("Erros", flowHealth.errors, "error");
    appendSection("Avisos", flowHealth.warnings, "warning");
    if (!flowHealth.errors.length && !flowHealth.warnings.length) body.appendChild(el("div", { class: "extuifDiagnosticsEmpty", text: "Nenhum erro ou aviso encontrado neste fluxo." }));
    modal.appendChild(body); overlay.appendChild(modal); document.body.appendChild(overlay);
    var lifecycle = window.ExtensionUiLifecycle && typeof window.ExtensionUiLifecycle.modal === "function" ? window.ExtensionUiLifecycle.modal({ overlay: overlay, dialog: modal, close: function () { close(); }, initialFocus: closeBtn }) : null;
    function close() { if (lifecycle && typeof lifecycle.close === "function") { var next = lifecycle; lifecycle = null; next.close(); return; } if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }
    closeBtn.addEventListener("click", close);
    overlay.addEventListener("click", function (event) { if (event.target === overlay) close(); });
    modal.addEventListener("keydown", function (event) { if (event.key === "Escape") { event.preventDefault(); close(); } });
    setTimeout(function () { try { modal.focus(); } catch (_) {} }, 0);
    return { close: close, element: modal };
  }
  function flowBranchLabels(node, byId) {
    var rows = []; if (!node) return rows; if (isIntentionalTerminalNode(node)) return rows; byId = byId || Object.create(null);
    function add(label, target) { if (!target) return; rows.push({ label: label, targetId: String(target), targetLabel: byId[String(target)] && (byId[String(target)].data && (byId[String(target)].data.label || byId[String(target)].data.title) || byId[String(target)].type) || "Etapa" }); }
    if (node.type === "condition") { add("Condição atendida", node.nextNodeIds && node.nextNodeIds[0]); add("Condição não atendida", node.nextNodeIdOnConditionFalse); return rows; }
    if (node.type === "userInput") { add("Respondeu", node.nextNodeIds && node.nextNodeIds[0]); add("Expirou", node.nextNodeIdOnExpiration); add("Resposta diferente", node.nextNodeIdOnDifferentAnswer); return rows; }
    if (node.type === "randomizer") { (node.data && Array.isArray(node.data.weights) ? node.data.weights : []).forEach(function (weight, index) { add("Caminho " + String.fromCharCode(65 + index), weight && weight.nextNodeId); }); return rows; }
    add("Próxima etapa", node.nextNodeIds && node.nextNodeIds[0]); return rows;
  }
  function layoutFlowNodesForReview(flow) {
    var nodes = flow && Array.isArray(flow.nodes) ? flow.nodes : [];
    if (!nodes.length) return false;
    var groupsCore = flowGroupsCore();
    if (groupsCore && typeof groupsCore.buildGroupAwareOrganizePatch === "function" && Array.isArray(flow.nodeGroups) && flow.nodeGroups.length) {
      var groupedPatch = groupsCore.buildGroupAwareOrganizePatch(flow);
      if (groupedPatch && groupedPatch.ok) {
        nodes.forEach(function (node) { var next = groupedPatch.positions && groupedPatch.positions[String(node && node.id || "")]; if (node && next) node.position = { x: next.x, y: next.y }; });
        return true;
      }
    }
    var byId = {}, order = {};
    nodes.forEach(function (node, index) { if (node && node.id) { byId[String(node.id)] = node; order[String(node.id)] = index; } });
    var start = byId[String(flow.startNodeId || "")] || nodes.find(function (node) { return node && node.type === "start"; }) || nodes[0];
    var depth = {}, queue = [];
    if (start && start.id) { depth[String(start.id)] = 0; queue.push(String(start.id)); }
    while (queue.length) {
      var id = queue.shift(), d = depth[id], node = byId[id];
      flowNodeTargets(node).forEach(function (target) { if (!byId[target]) return; if (depth[target] === undefined || depth[target] > d + 1) { depth[target] = d + 1; queue.push(target); } });
    }
    var maxDepth = Object.keys(depth).reduce(function (max, id) { return Math.max(max, depth[id]); }, -1);
    nodes.forEach(function (node) { var id = node && String(node.id || ""); if (id && depth[id] === undefined) depth[id] = ++maxDepth; });
    var layers = {};
    nodes.forEach(function (node) { if (!node || !node.id) return; var d = depth[String(node.id)] || 0; (layers[d] || (layers[d] = [])).push(node); });
    var wave = [0, 110, -70, 150, 35, -115, 90, -35], baseY = 280, xGap = 330, yGap = 180, minY = Infinity;
    Object.keys(layers).map(Number).sort(function (a, b) { return a - b; }).forEach(function (d) {
      var layer = layers[d].slice().sort(function (a, b) { return (order[String(a.id)] || 0) - (order[String(b.id)] || 0); });
      var center = baseY + wave[d % wave.length], count = layer.length;
      layer.forEach(function (node, index) { var y = center + (index - (count - 1) / 2) * yGap; node.position = { x: 90 + d * xGap, y: Math.round(y / 20) * 20 }; minY = Math.min(minY, node.position.y); });
    });
    if (minY < 60) { var shift = Math.ceil((60 - minY) / 20) * 20; nodes.forEach(function (node) { if (node && node.position) node.position.y += shift; }); }
    return true;
  }
  function flowLayoutLooksDegenerate(nodes) {
    if (!Array.isArray(nodes) || nodes.length < 4) return false;
    var positions = nodes.map(function (node) { return node && node.position; }).filter(function (pos) { return pos && Number.isFinite(Number(pos.x)) && Number.isFinite(Number(pos.y)); });
    if (positions.length !== nodes.length) return true;
    var ys = positions.map(function (pos) { return Number(pos.y); }), minY = Math.min.apply(Math, ys), maxY = Math.max.apply(Math, ys), bands = new Set(ys.map(function (y) { return Math.round(y / 80); }));
    return maxY - minY < 140 || bands.size <= Math.max(2, Math.floor(nodes.length * .12));
  }
  function ensureStructuralStart(flow) {
    if (!flow || !Array.isArray(flow.nodes)) return false;
    var existing = flow.nodes.find(function (node) { return node && node.type === "start"; });
    if (existing) {
      if (flow.startNodeId !== existing.id) { flow.startNodeId = existing.id; return true; }
      return false;
    }
    var previousStart = flow.nodes.find(function (node) { return node.id === flow.startNodeId; }) || flow.nodes[0] || null;
    var previousPos = previousStart && previousStart.position || { x: 410, y: 170 };
    var startNode = { id: uid(), type: "start", position: { x: Math.max(40, Number(previousPos.x || 410) - 320), y: Number(previousPos.y || 170) }, data: {}, nextNodeIds: previousStart ? [previousStart.id] : [], nextNodeIdOnExpiration: null, nextNodeIdOnDifferentAnswer: null, expirationTimeoutInMs: null };
    flow.nodes.unshift(startNode);
    flow.startNodeId = startNode.id;
    flow.updatedAtInMs = Date.now();
    return true;
  }
  async function loadFlows() {
    var raw = await storageGet(STORAGE_KEY);
    var state = parsePersisted(raw);
    var list = (state && state.flowList) || [];
    var changed = false;
    if (!flowStartMigrationDone) flowStartMigrationDone = true;
    list.forEach(function (flow) { if (ensureStructuralStart(flow)) changed = true; });
    if (!flowImportedLayoutMigrationDone) {
      flowImportedLayoutMigrationDone = true;
      list.forEach(function (flow) {
        var imported = flow && (flow.importSource || flow.importSourceId);
        if (imported && flowLayoutLooksDegenerate(flow.nodes) && layoutFlowNodesForReview(flow)) { flow.layoutRevision = 2; flow.updatedAtInMs = Date.now(); changed = true; }
      });
    }
    var groupsCore = flowGroupsCore();
    if (groupsCore && typeof groupsCore.normalizeFlowNodeGroups === "function") {
      list.forEach(function (flow) {
        if (!flow || typeof flow !== "object") return;
        var hadGroups = Object.prototype.hasOwnProperty.call(flow, "nodeGroups");
        var before = hadGroups ? JSON.stringify(Array.isArray(flow.nodeGroups) ? flow.nodeGroups : []) : null;
        var normalized = window.ExtensionFlowGroupsCore.normalizeFlowNodeGroups(flow);
        flow.nodeGroups = normalized;
        var groupPositionsChanged = typeof window.ExtensionFlowGroupsCore.canonicalizeFlowGroupPositions === "function" && window.ExtensionFlowGroupsCore.canonicalizeFlowGroupPositions(flow);
        if ((hadGroups && before !== JSON.stringify(normalized)) || groupPositionsChanged) { flow.updatedAtInMs = Date.now(); changed = true; }
      });
    }
    if (changed) await saveFlows(list);
    return list;
  }
  async function saveFlows(flowList) {
    await storageSet(STORAGE_KEY, JSON.stringify({ state: { flowList: flowList }, version: 0 }));
  }
                                                                           
                                                                         
                                                                          
                                                             
  function describeTriggerShort(trigger) {
    trigger = trigger || {};
    var t = trigger.type || "keyword";
    if (t === "keyword") {
      var kws = (trigger.keywordRules && trigger.keywordRules[0] && trigger.keywordRules[0].keywords) || [];
      return kws.length ? "Palavra-chave: " + kws.slice(0, 2).join(", ") + (kws.length > 2 ? "…" : "") : "Palavra-chave (nenhuma configurada)";
    }
    var importedModes = Array.isArray(trigger.activationTypes) ? trigger.activationTypes.filter(Boolean) : [];
    if (importedModes.length > 1) return "Vários acionamentos (" + importedModes.length + ")";
    if (t === "messageReceived") return "Qualquer mensagem recebida";
    if (t === "newChat") return "Nova conversa";
    if (t === "newDay") return "Primeira mensagem do dia";
    if (t === "columnMoved") return "Contato movido de coluna";
    if (t === "funnelCompleted") return "Funil finalizado";
    if (t === "followUpSent") return "FollowUp enviado";
    if (t === "scheduleSent") return "Agendamento enviado";
    if (t === "orderChanged") return "Encomenda alterada";
    if (t === "manual") return "Início manual";
    return "Gatilho";
  }
  function fmtRelativeUpdated(ms) {
    if (!ms) return "";
    var diffMin = Math.round((Date.now() - ms) / 60000);
    if (diffMin < 1) return "Atualizado agora";
    if (diffMin < 60) return "Atualizado há " + diffMin + " min";
    var diffH = Math.round(diffMin / 60);
    if (diffH < 24) return "Atualizado há " + diffH + "h";
    var diffD = Math.round(diffH / 24);
    if (diffD < 30) return "Atualizado há " + diffD + "d";
    return "Atualizado em " + new Date(ms).toLocaleDateString("pt-BR");
  }

  async function loadRunningCounts() {
    var raw = await storageGet(RUNNING_STORAGE_KEY);
    var state = parsePersisted(raw);
    var list = (state && state.runningList) || [];
    var counts = {};
    list.forEach(function (r) {
      if (r.status === "running" || r.status === "waitingForInput") counts[r.flowId] = (counts[r.flowId] || 0) + 1;
    });
    return counts;
  }

  var rootEl = null;

  function normalizeAutomationName(value){return String(value||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").trim().toLocaleLowerCase("pt-BR");}
  async function validateFlowMetadataName(name, excludeId) {
    var flows = await loadFlows(), key = normalizeAutomationName(name);
    return flows.some(function (item) { return item && String(item.id) !== String(excludeId || "") && normalizeAutomationName(item.name) === key; })
      ? "Já existe um Fluxo com esse nome. Escolha outro nome para continuar." : true;
  }
  async function openFlowMetadataModal(flow, mode) {
    var modal = window.__extAutomationMetadataModal;
    if (!modal || typeof modal.open !== "function") throw new Error("A janela de metadados do Fluxo não está disponível.");
    var creating = mode === "create" || !flow;
    return modal.open({
      title: creating ? "Criar novo Fluxo" : "Editar Fluxo",
      confirmLabel: creating ? "Criar Fluxo" : "Salvar alterações",
      nameLabel: "Nome",
      name: flow && flow.name || "Novo fluxo",
      nameMaxLength: 160,
      namePlaceholder: "Nome do Fluxo",
      description: flow && flow.description || "",
      descriptionMaxLength: 300,
      descriptionPlaceholder: "Explique a finalidade deste Fluxo",
      color: flow && flow.color || "#10b981",
      defaultColor: "#10b981",
      hint: "A cor identifica este Fluxo nos cards e seletores. Gatilhos e etapas não são alterados.",
      emptyNameMessage: "Digite um nome para continuar.",
      validateName: function (name) { return validateFlowMetadataName(name, flow && flow.id); }
    });
  }
  async function updateFlowMetadata(flow) {
    var values = await openFlowMetadataModal(flow, "edit");
    if (!values) return null;
    var all = await loadFlows(), target = all.find(function (item) { return item.id === flow.id; });
    if (!target) throw new Error("O Fluxo não foi encontrado.");
    target.name = values.name;
    target.description = values.description;
    target.color = values.color;
    target.updatedAtInMs = Date.now();
    await saveFlows(all);
    return target;
  }

  function newEmptyFlow() {
    var now = Date.now();
                                                                         
                                                                          
                                                                          
                                         
    var startId = uid();
    return {
      id: uid(), name: "Novo fluxo", description: "", color: "#10b981", isActive: false, startNodeId: startId, favorite: false,
      trigger: { isCaseSensitive: false, keywordRules: [{ type: "contains", keywords: [] }], sendToContacts: true, sendToGroups: false },
      nodes: [{ id: startId, type: "start", position: { x: 90, y: 170 }, data: {}, nextNodeIds: [], nextNodeIdOnExpiration: null, nextNodeIdOnDifferentAnswer: null, expirationTimeoutInMs: null }],
      createdAtInMs: now, updatedAtInMs: now
    };
  }

  async function createAndOpenFlow() {
    var values = await openFlowMetadataModal(null, "create");
    if (!values) return null;
    var flows = await loadFlows();
    var flow = newEmptyFlow();
    flow.name = values.name;
    flow.description = values.description;
    flow.color = values.color;
    flows.push(flow);
    await saveFlows(flows);
    if (window.__extPlaySystemSound) window.__extPlaySystemSound("success");
    await openFlowCanvas(flow);
    return flow;
  }

  function duplicateFlowDefinition(flow) {
    var copy = JSON.parse(JSON.stringify(flow));
    var nodeIdMap = {};
    (copy.nodes || []).forEach(function (node) { nodeIdMap[node.id] = uid(); });
    function mapNodeId(id) { return id && nodeIdMap[id] ? nodeIdMap[id] : null; }
    (copy.nodes || []).forEach(function (node) {
      var oldId = node.id;
      node.id = nodeIdMap[oldId];
      node.nextNodeIds = (node.nextNodeIds || []).map(mapNodeId).filter(Boolean);
      node.nextNodeIdOnExpiration = mapNodeId(node.nextNodeIdOnExpiration);
      node.nextNodeIdOnDifferentAnswer = mapNodeId(node.nextNodeIdOnDifferentAnswer);
      node.nextNodeIdOnConditionFalse = mapNodeId(node.nextNodeIdOnConditionFalse);
      if (node.data && Array.isArray(node.data.weights)) {
        node.data.weights.forEach(function (weight) { if (weight) weight.nextNodeId = mapNodeId(weight.nextNodeId); });
      }
    });
    copy.id = uid();
    copy.name = (flow.name || "Fluxo") + " — Cópia";
    copy.startNodeId = mapNodeId(flow.startNodeId);
    if (window.ExtensionFlowGroupsCore && typeof window.ExtensionFlowGroupsCore.remapNodeGroups === "function") {
      copy.nodeGroups = window.ExtensionFlowGroupsCore.remapNodeGroups(Array.isArray(flow.nodeGroups) ? flow.nodeGroups : [], nodeIdMap, uid);
    } else {
      copy.nodeGroups = [];
    }
    copy.isActive = false;
    copy.favorite = false;
    copy.createdAtInMs = Date.now();
    copy.updatedAtInMs = copy.createdAtInMs;
    return copy;
  }

  var DAY_LABELS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  var DAY_FULL_NAMES = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

  function resolveStartInspectorHost(host) {
    var candidate = host || rootEl || document.body;
    if (!candidate) return document.body;
    if (candidate.matches && candidate.matches(".extuifRfWrap")) return candidate;
    var rfWrap = candidate.querySelector && candidate.querySelector(".extuifRfWrap");
    if (rfWrap) return rfWrap;
    if (rootEl && rootEl.querySelector) {
      var rootRfWrap = rootEl.querySelector(".extuifRfWrap");
      if (rootRfWrap) return rootRfWrap;
    }
    return candidate;
  }

  function openStartInspector(flow, host) {
    host = resolveStartInspectorHost(host);
    var previousOverlay = host && host.querySelector ? host.querySelector(".extuifStartInspectorOverlay") : null;
    if (previousOverlay) previousOverlay.remove();
    var previousInspector = host && host.querySelector ? host.querySelector(".extuifStartInspector") : null;
    if (previousInspector) previousInspector.remove();
    flow.trigger = flow.trigger || {};

    var overlay = el("div", { class: "extuifStartInspectorOverlay", "data-start-config-overlay": "1" });
    function makeStartHeaderIcon() {
      return el("span", { class: "extuifStartInspectorHeaderIcon", "aria-hidden": "true" }, [icon("play")]);
    }
    var modal = el("section", { class: "extuifStartInspector", role: "dialog", "aria-modal": "true", "aria-label": "Configuração inicial do Fluxo", tabindex: "-1" });
    var header = el("header", { class: "extuifStartInspectorHeader" });
    var headerLeft = el("div", { class: "extuifStartInspectorHeaderLeft" }, [
      makeStartHeaderIcon(),
      el("div", { class: "extuifStartInspectorHeading" }, [
        el("span", { class: "extuifStartInspectorEyebrow", text: "FLUXO · INÍCIO" }),
        el("h3", { text: "Configuração inicial" }),
        el("p", { class: "extuifStartInspectorHeaderSubtitle", text: "Defina como este fluxo começa e quais condições precisam ser atendidas." })
      ])
    ]);
    header.appendChild(headerLeft);
    var closeBtn = el("button", { type: "button", class: "extuifStartInspectorClose", text: "×", "aria-label": "Fechar configuração do Início" });
    header.appendChild(closeBtn);
    modal.appendChild(header);

    var savingTrigger = false;
    var activeSection = "trigger";
    function closeTrigger() { if (savingTrigger) return false; overlay.remove(); return true; }
    closeBtn.addEventListener("click", function () { closeTrigger(); });

    var body = el("div", { class: "extuifStartInspectorBody" });

    var sectionMeta = {
      trigger: { title: "Gatilho", subtitle: "Evento que inicia o fluxo", description: "Defina qual evento inicia este Fluxo e, quando necessário, configure os critérios desse evento.", icon: "zap" },
      audience: { title: "Público", subtitle: "Contatos e grupos", description: "Defina em quais tipos de conversa este Fluxo pode iniciar.", icon: "users" },
      availability: { title: "Disponibilidade", subtitle: "Dias e horários", description: "Defina os dias e horários em que novos disparos automáticos podem iniciar.", icon: "calendar" },
      conditions: { title: "Condições", subtitle: "Filtros de entrada", description: "Defina filtros avaliados antes de permitir que o contato entre neste Fluxo.", icon: "filter" },
      advanced: { title: "Avançado", subtitle: "Ações após o gatilho", description: "Configure ações auxiliares executadas somente depois que o evento e as condições forem aceitos.", icon: "settings" }
    };
    var sectionOrder = ["trigger", "audience", "availability", "conditions", "advanced"];
    var summaryEls = {};
    var sectionPages = {};
    var navButtons = {};

    function makeIconBox(name, extraClass) {
      return el("span", { class: "extuifStartInspectorIconBox" + (extraClass ? " " + extraClass : "") }, [icon(name)]);
    }
    function makeInfoCard(title, text, tone) {
      var card = el("div", { class: "extuifStartInspectorInfoCard" + (tone ? " extuifStartInspectorInfoCard--" + tone : "") });
      card.appendChild(icon("info"));
      var copy = el("div", { class: "extuifStartInspectorInfoCopy" });
      if (title) copy.appendChild(el("strong", { text: title }));
      copy.appendChild(el("span", { text: text }));
      card.appendChild(copy);
      return card;
    }
    function makeFieldHelp(text) { return el("small", { class: "extuifStartInspectorFieldHelp", text: text }); }
    function makeFlowSwitch(input, extraClass) {
      return el("label", { class: "extuiSwitch" + (extraClass ? " " + extraClass : "") }, [input, el("span", { class: "track", "aria-hidden": "true" })]);
    }
    function makeToggleRow(title, description, input, extraClass) {
      var copy = el("span", { class: "extuifStartInspectorToggleCopy" }, [
        el("strong", { text: title }), el("small", { text: description })
      ]);
      return el("div", { class: "extuifStartInspectorToggleRow" + (extraClass ? " " + extraClass : "") }, [copy, makeFlowSwitch(input)]);
    }
    function makeSectionHero(sectionId) {
      var meta = sectionMeta[sectionId];
      return el("div", { class: "extuifStartInspectorSectionHero" }, [
        makeIconBox(meta.icon),
        el("div", { class: "extuifStartInspectorSectionHeroCopy" }, [
          el("h3", { text: meta.title }),
          el("p", { text: meta.description })
        ])
      ]);
    }
    function makeSectionNav() {
      var nav = el("nav", { class: "extuifStartInspectorTabs", role: "tablist", "aria-label": "Seções da configuração inicial" });
      sectionOrder.forEach(function (sectionId) {
        var meta = sectionMeta[sectionId];
        var btn = el("button", { type: "button", class: "extuifStartInspectorTab", role: "tab", "data-start-section": sectionId, "aria-selected": "false", "aria-controls": "extuifStartTabPanel-" + sectionId, text: meta.title });
        btn.addEventListener("click", function () { showStartInspectorSection(sectionId); });
        navButtons[sectionId] = btn;
        nav.appendChild(btn);
      });
      return nav;
    }

    var sectionNav = makeSectionNav();
    modal.appendChild(sectionNav);
    var detailPagesHost = el("div", { class: "extuifStartInspectorDetailPages" });
    body.appendChild(detailPagesHost);
    modal.appendChild(body);

    function createPage(sectionId) {
      var meta = sectionMeta[sectionId];
      var page = el("section", { class: "extuifStartInspectorPage", id: "extuifStartTabPanel-" + sectionId, role: "tabpanel", "aria-labelledby": "", "data-start-page-section": sectionId });
      page.hidden = true;
      sectionPages[sectionId] = page;
      detailPagesHost.appendChild(page);
      return page;
    }

    var triggerPage = createPage("trigger");
    var triggerTypeCard = el("div", { class: "extuifStartInspectorConceptField extuifStartInspectorTriggerTypeField extuifStartInspectorTriggerTypeCard" });
    triggerTypeCard.appendChild(el("label", { text: "Tipo de gatilho" }));
    var triggerTypeSelect = el("select", { "aria-label": "Tipo de gatilho" });
    var triggerOptions = [
      { value: "keyword", label: "Palavra-chave" },
      { value: "messageReceived", label: "Qualquer mensagem recebida" },
      { value: "newChat", label: "Nova conversa (primeira mensagem)" },
      { value: "newDay", label: "Primeira mensagem do dia" },
      { value: "columnMoved", label: "Contato movido para coluna do CRM" },
      { value: "funnelCompleted", label: "Funil finalizado" },
      { value: "followUpSent", label: "FollowUp enviado" },
      { value: "scheduleSent", label: "Agendamento enviado" },
      { value: "orderChanged", label: "Encomenda criada ou alterada" },
      { value: "manual", label: "Manual (botão)" }
    ];
    triggerOptions.forEach(function (opt) {
      var o = el("option", { value: opt.value, text: opt.label });
      if ((flow.trigger.type || "keyword") === opt.value) o.setAttribute("selected", "selected");
      triggerTypeSelect.appendChild(o);
    });
    triggerTypeCard.appendChild(triggerTypeSelect);
    var triggerTypeHelp = makeFieldHelp("");
    triggerTypeCard.appendChild(triggerTypeHelp);
    triggerPage.appendChild(triggerTypeCard);

    var keywordFieldsWrap = el("div", { class: "extuifStartInspectorConceptField extuifKeywordFields extuifStartInspectorFieldGroup" });
    keywordFieldsWrap.appendChild(el("label", { text: "Palavras-chave (separadas por vírgula)" }));
    var keywordsInput = el("textarea", { rows: "3", maxlength: "500", placeholder: "Ex.: orçamento, preço, planos, atendimento" });
    var firstRule = flow.trigger.keywordRules[0] || { type: "contains", keywords: [] };
    keywordsInput.value = (firstRule.keywords || []).join(", ");
    keywordFieldsWrap.appendChild(keywordsInput);
    var keywordMeta = el("div", { class: "extuifStartInspectorInputMeta" }, [
      el("small", { text: "Use termos que seus clientes realmente digitariam." }),
      el("small", { class: "extuifStartInspectorCharCount", text: String(keywordsInput.value.length) + "/500" })
    ]);
    keywordFieldsWrap.appendChild(keywordMeta);
    keywordFieldsWrap.appendChild(el("label", { text: "Tipo de regra" }));
    var typeSelect = el("select", { "aria-label": "Tipo de regra" });
    var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
    var ruleLabels = { contains: "Contém", notContains: "Não contém", equals: "É igual a", startsWith: "Começa com", endsWith: "Termina com" };
    ["contains", "notContains", "equals", "startsWith", "endsWith"].forEach(function (t) {
      var opt = el("option", { value: t, text: formHelpers ? formHelpers.operatorLabel(t) : ruleLabels[t] });
      if (t === firstRule.type) opt.setAttribute("selected", "selected");
      typeSelect.appendChild(opt);
    });
    keywordFieldsWrap.appendChild(typeSelect);
    var ruleHelp = makeFieldHelp("");
    keywordFieldsWrap.appendChild(ruleHelp);
    triggerPage.appendChild(keywordFieldsWrap);
    var triggerTip = makeInfoCard("Dica", "Use regras simples e previsíveis. Quanto mais específico for o gatilho, menor a chance de acionamentos inesperados.", "tip");
    triggerPage.appendChild(triggerTip);

    var columnTriggerFieldsWrap = el("div", { class: "extuifColumnTriggerFields extuifStartInspectorColumnTriggerStack extuifStartInspectorFieldGroup" });
    columnTriggerFieldsWrap.appendChild(el("label", { text: "CRM" }));
    var columnTriggerCrmSelect = el("select", {});
    columnTriggerFieldsWrap.appendChild(columnTriggerCrmSelect);
    columnTriggerFieldsWrap.appendChild(el("label", { text: "Coluna" }));
    var columnTriggerColumnSelect = el("select", {});
    columnTriggerFieldsWrap.appendChild(columnTriggerColumnSelect);
    columnTriggerFieldsWrap.appendChild(makeFieldHelp("O Fluxo será iniciado quando um contato entrar na coluna escolhida."));
    triggerPage.appendChild(columnTriggerFieldsWrap);

    var crmListForTrigger = [];
    var savedTriggerData = flow.trigger.data || {};
    function populateColumnSelect(crmId, selectedColumnId) {
      columnTriggerColumnSelect.innerHTML = "";
      var crm = crmListForTrigger.find(function (c) { return c.id === crmId; });
      columnTriggerColumnSelect.appendChild(el("option", { value: "", text: "Escolha uma coluna" }));
      ((crm && crm.columns) || []).forEach(function (col) {
        var o = el("option", { value: col.id, text: col.title });
        if (col.id === selectedColumnId) o.setAttribute("selected", "selected");
        columnTriggerColumnSelect.appendChild(o);
      });
      updateStartInspectorSummaries();
    }
    columnTriggerCrmSelect.addEventListener("change", function () { populateColumnSelect(columnTriggerCrmSelect.value, null); });

    var funnelTriggerFieldsWrap = el("div", { class: "extuifColumnTriggerFields extuifEventTriggerFields extuifStartInspectorConceptField extuifStartInspectorFieldGroup" });
    funnelTriggerFieldsWrap.appendChild(el("label", { text: "Funil de origem" }));
    var funnelTriggerSelect = el("select", {});
    funnelTriggerSelect.appendChild(el("option", { value: "", text: "Qualquer funil" }));
    funnelTriggerFieldsWrap.appendChild(funnelTriggerSelect);
    funnelTriggerFieldsWrap.appendChild(makeFieldHelp("Escolha um Funil específico ou deixe em Qualquer funil para reagir a qualquer sequência concluída."));
    triggerPage.appendChild(funnelTriggerFieldsWrap);
    chrome.storage.local.get("EXTUI:extappFunnelStore", function (res) {
      var raw = res && res["EXTUI:extappFunnelStore"], parsed = null;
      try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; } catch (_) { parsed = null; }
      var funnels = parsed && parsed.state && Array.isArray(parsed.state.funnelList) ? parsed.state.funnelList : [];
      funnels.slice().sort(function (a, b) { return String(a.name || "").localeCompare(String(b.name || "")); }).forEach(function (funnel) {
        if (!funnel || !funnel.id) return;
        var option = el("option", { value: String(funnel.id), text: String(funnel.name || "Funil") });
        if (String(savedTriggerData.sourceId || "") === String(funnel.id)) option.setAttribute("selected", "selected");
        funnelTriggerSelect.appendChild(option);
      });
      updateStartInspectorSummaries();
    });

    var audiencePage = createPage("audience");
    var contactsInput = el("input", { type: "checkbox", "aria-label": "Enviar para contatos" });
    contactsInput.checked = flow.trigger.sendToContacts !== undefined ? flow.trigger.sendToContacts : true;
    audiencePage.appendChild(makeToggleRow("Enviar para contatos", "Permite que o Fluxo inicie em conversas individuais.", contactsInput, "extuifStartInspectorAudienceOption"));
    var groupsInput = el("input", { type: "checkbox", "aria-label": "Enviar para grupos" });
    groupsInput.checked = flow.trigger.sendToGroups !== undefined ? flow.trigger.sendToGroups : false;
    audiencePage.appendChild(makeToggleRow("Enviar para grupos", "Permite que o Fluxo inicie em conversas de grupos do WhatsApp.", groupsInput, "extuifStartInspectorAudienceOption"));
    audiencePage.appendChild(makeInfoCard("Dica", "Você pode ativar contatos, grupos ou ambos. As regras de disponibilidade e condições serão aplicadas ao público selecionado.", "tip"));

    var availabilityPage = createPage("availability");
    var availabilityScheduleCard = el("div", { class: "extuifStartInspectorScheduleCard" });
    availabilityPage.appendChild(availabilityScheduleCard);
    availabilityScheduleCard.appendChild(el("div", { class: "extuifStartInspectorSubheading" }, [
      el("strong", { text: "Dias de atendimento" }),
      el("small", { text: "Selecione os dias em que este Fluxo pode iniciar. Nenhum selecionado equivale a todos." })
    ]));
    var activeDays = (flow.trigger.activeDays || []).slice();
    var dayChipsWrap = el("div", { class: "extuifDayChips extuifStartInspectorDayChips" });
    DAY_LABELS.forEach(function (label, dayIndex) {
      var isOn = activeDays.indexOf(dayIndex) >= 0;
      var chip = el("div", { class: "extuifDayChip" + (isOn ? " extuifDayChip--on" : ""), text: label, title: DAY_FULL_NAMES[dayIndex], role: "checkbox", tabindex: "0", "aria-label": DAY_FULL_NAMES[dayIndex], "aria-checked": isOn ? "true" : "false" });
      chip.addEventListener("click", function () {
        var pos = activeDays.indexOf(dayIndex);
        if (pos >= 0) { activeDays.splice(pos, 1); chip.classList.remove("extuifDayChip--on"); chip.setAttribute("aria-checked", "false"); }
        else { activeDays.push(dayIndex); chip.classList.add("extuifDayChip--on"); chip.setAttribute("aria-checked", "true"); }
        updateStartInspectorSummaries();
      });
      chip.addEventListener("keydown", function (event) { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); chip.click(); } });
      dayChipsWrap.appendChild(chip);
    });
    availabilityScheduleCard.appendChild(dayChipsWrap);
    availabilityScheduleCard.appendChild(el("div", { class: "extuifStartInspectorSubheading extuifStartInspectorSubheading--spaced" }, [
      el("strong", { text: "Horário de atendimento" }),
      el("small", { text: "Deixe os horários vazios para não restringir por horário." })
    ]));
    var hoursRow = el("div", { class: "extuifHoursRow extuifStartInspectorHoursRow" });
    var fromInput = el("input", { type: "time", "aria-label": "Horário inicial" });
    fromInput.value = (flow.trigger.activeHours && flow.trigger.activeHours.from) || "";
    var toInput = el("input", { type: "time", "aria-label": "Horário final" });
    toInput.value = (flow.trigger.activeHours && flow.trigger.activeHours.to) || "";
    hoursRow.appendChild(el("div", {}, [el("span", { text: "Horário de início" }), fromInput]));
    hoursRow.appendChild(el("div", {}, [el("span", { text: "Horário de término" }), toInput]));
    availabilityScheduleCard.appendChild(hoursRow);
    var weeklyToggleInput = el("input", { type: "checkbox", "aria-label": "Usar horário diferente por dia da semana" });
    var savedWeeklyHours = flow.trigger.weeklyHours || null;
    weeklyToggleInput.checked = !!savedWeeklyHours;
    availabilityScheduleCard.appendChild(makeToggleRow("Usar horário diferente por dia da semana", "Permite configurar um intervalo específico para cada dia.", weeklyToggleInput, "extuifStartInspectorScheduleToggle"));
    var weeklyWrap = el("div", { class: "extuifWeeklyHoursWrap extuifStartInspectorWeeklyHours" });
    var weeklyRows = DAY_FULL_NAMES.map(function (dayName, dayIndex) {
      var saved = (savedWeeklyHours && savedWeeklyHours[dayIndex]) || { active: dayIndex !== 0, from: "00:00", to: "23:59" };
      var rowActive = el("input", { type: "checkbox", "aria-label": "Ativar " + dayName }); rowActive.checked = saved.active !== false;
      var rowFrom = el("input", { type: "time", "aria-label": "Início em " + dayName }); rowFrom.value = saved.from || "00:00";
      var rowTo = el("input", { type: "time", "aria-label": "Fim em " + dayName }); rowTo.value = saved.to || "23:59";
      var copyHoursBtn = el("button", { type: "button", class: "extuifStartInspectorCopyHours", text: "Copiar para todos", "aria-label": "Copiar horário de " + dayName + " para todos os dias" });
      copyHoursBtn.addEventListener("click", function () {
        weeklyRows.forEach(function (item) { item.from.value = rowFrom.value; item.to.value = rowTo.value; });
        updateStartInspectorSummaries();
      });
      var row = el("div", { class: "extuifWeeklyHoursRow" }, [el("label", {}, [rowActive, el("span", { text: dayName })]), rowFrom, rowTo, copyHoursBtn]);
      weeklyWrap.appendChild(row);
      return { active: rowActive, from: rowFrom, to: rowTo, copy: copyHoursBtn };
    });
    availabilityScheduleCard.appendChild(weeklyWrap);
    function updateWeeklyVisibility() { weeklyWrap.style.display = weeklyToggleInput.checked ? "" : "none"; updateStartInspectorSummaries(); }
    weeklyToggleInput.addEventListener("change", updateWeeklyVisibility);
    var availabilityStatusText = el("span", { text: "" });
    availabilityPage.appendChild(makeInfoCard("Dica", "Defina uma disponibilidade realista para evitar automações fora do horário desejado.", "tip"));
    updateWeeklyVisibility();

    var conditionsPage = createPage("conditions");
    conditionsPage.appendChild(makeInfoCard("Use condições para tornar seu fluxo mais inteligente", "Execute este Fluxo apenas quando as condições configuradas forem atendidas. Assim você evita entradas indesejadas e aumenta a relevância da automação.", "success"));
    var crmGateToggle = el("input", { type: "checkbox", "aria-label": "Restringir por coluna do CRM" });
    var savedCrmGate = flow.trigger.crmGate || null;
    crmGateToggle.checked = !!savedCrmGate;
    var conditionConceptCard = el("section", { class: "extuifStartInspectorConditionConceptCard" });
    var conditionConceptHeader = el("div", { class: "extuifStartInspectorConditionConceptHeader" }, [
      makeIconBox("users", "extuifStartInspectorStatusIcon"),
      el("div", { class: "extuifStartInspectorConditionConceptCopy" }, [
        el("strong", { text: "Só responder se o contato estiver numa coluna específica do CRM" }),
        el("small", { text: "O Fluxo será iniciado apenas se o contato estiver na coluna selecionada do CRM." })
      ]),
      makeFlowSwitch(crmGateToggle, "extuifStartInspectorConditionSwitch")
    ]);
    conditionConceptCard.appendChild(conditionConceptHeader);
    var crmGateWrap = el("div", { class: "extuifColumnTriggerFields extuifStartInspectorConditionCard extuifStartInspectorConditionSettingFields" });
    crmGateWrap.appendChild(el("label", { text: "CRM" }));
    var crmGateCrmSelect = el("select", {});
    crmGateWrap.appendChild(crmGateCrmSelect);
    crmGateWrap.appendChild(el("label", { text: "Coluna do CRM" }));
    var crmGateColumnSelect = el("select", {});
    crmGateWrap.appendChild(crmGateColumnSelect);
    crmGateWrap.appendChild(makeFieldHelp("O contato precisa estar nesta coluna no momento em que o gatilho for acionado."));
    conditionConceptCard.appendChild(crmGateWrap);
    conditionsPage.appendChild(conditionConceptCard);
    function populateCrmGateColumnSelect(crmId, selectedColumnId) {
      crmGateColumnSelect.innerHTML = "";
      var crm = crmListForTrigger.find(function (c) { return c.id === crmId; });
      crmGateColumnSelect.appendChild(el("option", { value: "", text: "Escolha uma coluna" }));
      ((crm && crm.columns) || []).forEach(function (col) {
        var o = el("option", { value: col.id, text: col.title });
        if (col.id === selectedColumnId) o.setAttribute("selected", "selected");
        crmGateColumnSelect.appendChild(o);
      });
      updateStartInspectorSummaries();
    }
    crmGateCrmSelect.addEventListener("change", function () { populateCrmGateColumnSelect(crmGateCrmSelect.value, null); });
    function updateCrmGateVisibility() { crmGateWrap.style.display = crmGateToggle.checked ? "" : "none"; updateStartInspectorSummaries(); }
    crmGateToggle.addEventListener("change", updateCrmGateVisibility);
    updateCrmGateVisibility();

    chrome.storage.local.get("EXTUI:CrmStore", function (res) {
      var raw = res && res["EXTUI:CrmStore"], parsed = null;
      try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; } catch (e) { parsed = null; }
      crmListForTrigger = (parsed && parsed.state && parsed.state.crmList) || [];
      columnTriggerCrmSelect.innerHTML = "";
      columnTriggerCrmSelect.appendChild(el("option", { value: "", text: "Escolha um CRM" }));
      crmListForTrigger.forEach(function (c) {
        var o = el("option", { value: c.id, text: c.name });
        if (c.id === savedTriggerData.crmId) o.setAttribute("selected", "selected");
        columnTriggerCrmSelect.appendChild(o);
      });
      populateColumnSelect(savedTriggerData.crmId, savedTriggerData.columnId);
      crmGateCrmSelect.innerHTML = "";
      crmGateCrmSelect.appendChild(el("option", { value: "", text: "Escolha um CRM" }));
      crmListForTrigger.forEach(function (c) {
        var o = el("option", { value: c.id, text: c.name });
        if (savedCrmGate && c.id === savedCrmGate.crmId) o.setAttribute("selected", "selected");
        crmGateCrmSelect.appendChild(o);
      });
      populateCrmGateColumnSelect(savedCrmGate && savedCrmGate.crmId, savedCrmGate && savedCrmGate.columnId);
      updateStartInspectorSummaries();
    });

    var advancedPage = createPage("advanced");
    var webhookToggle = el("input", { type: "checkbox", "aria-label": "Ativar notificação externa" });
    webhookToggle.checked = !!flow.trigger.webhook;
    var advancedCard = el("section", { class: "extuifStartInspectorAdvancedCard extuifStartInspectorWebhookCard" });
    advancedCard.appendChild(el("div", { class: "extuifStartInspectorWebhookHeader" }, [
      el("div", { class: "extuifStartInspectorWebhookHeading" }, [
        el("strong", { text: "Notificação externa" }),
        el("p", { text: "Configure uma URL para ser acionada depois que este Fluxo for aceito pelas regras de entrada." })
      ]),
      el("div", { class: "extuifStartInspectorWebhookToggleRow" }, [makeFlowSwitch(webhookToggle, "extuifStartInspectorWebhookToggle"), el("span", {}, [el("strong", { text: "Ativar notificação externa" }), el("small", { text: "Envia uma solicitação HTTP para a URL informada." })])])
    ]));
    advancedCard.appendChild(el("div", { class: "extuifStartInspectorWebhookExplainer" }, [
      icon("info"),
      el("div", {}, [el("strong", { text: "Como funciona?" }), el("span", { text: "Quando o Fluxo for iniciado, a notificação externa será executada usando o contrato atual do Fluxo, sem alterar as demais condições." })])
    ]));
    advancedCard.appendChild(el("label", { text: "URL de destino" }));
    var webhookInput = el("input", { type: "url", placeholder: "https://seu-dominio.com/webhook", "aria-label": "URL da notificação externa" });
    webhookInput.value = flow.trigger.webhook || "";
    advancedCard.appendChild(webhookInput);
    advancedCard.appendChild(makeFieldHelp("Informe a URL completa que receberá a notificação. HTTPS é recomendado."));
    advancedPage.appendChild(advancedCard);
    function updateWebhookEnabledState() {
      webhookInput.disabled = !webhookToggle.checked;
      advancedCard.classList.toggle("is-disabled", !webhookToggle.checked);
      updateStartInspectorSummaries();
    }
    webhookToggle.addEventListener("change", updateWebhookEnabledState);
    updateWebhookEnabledState();

    function triggerTypeDescription(value) {
      return {
        keyword: "Inicia quando a mensagem recebida corresponde à regra de palavras-chave configurada.",
        messageReceived: "Inicia quando qualquer mensagem recebida for aceita pelas demais regras do Fluxo.",
        newChat: "Inicia na primeira mensagem de uma nova conversa.",
        newDay: "Inicia na primeira mensagem recebida do contato naquele dia.",
        columnMoved: "Inicia quando um contato é movido para a coluna de CRM escolhida.",
        funnelCompleted: "Inicia quando um Funil é concluído.",
        followUpSent: "Inicia depois que um FollowUp é enviado.",
        scheduleSent: "Inicia depois que um agendamento é enviado.",
        orderChanged: "Inicia quando uma Encomenda é criada ou alterada.",
        manual: "Não inicia automaticamente; o Fluxo depende de acionamento manual."
      }[value] || "Defina o evento que inicia o Fluxo.";
    }
    function ruleDescription(value) {
      return {
        contains: "A mensagem precisa conter pelo menos uma das palavras-chave, em qualquer parte do texto.",
        notContains: "A mensagem não pode conter nenhuma das palavras-chave informadas.",
        equals: "A mensagem precisa ser exatamente igual a uma das palavras-chave informadas.",
        startsWith: "A mensagem precisa começar com uma das palavras-chave informadas.",
        endsWith: "A mensagem precisa terminar com uma das palavras-chave informadas."
      }[value] || "A regra define como as palavras-chave serão comparadas.";
    }
    function updateTriggerFieldsVisibility() {
      keywordFieldsWrap.style.display = triggerTypeSelect.value === "keyword" ? "" : "none";
      columnTriggerFieldsWrap.style.display = triggerTypeSelect.value === "columnMoved" ? "" : "none";
      funnelTriggerFieldsWrap.style.display = triggerTypeSelect.value === "funnelCompleted" ? "" : "none";
      triggerTypeHelp.textContent = triggerTypeDescription(triggerTypeSelect.value);
      ruleHelp.textContent = ruleDescription(typeSelect.value);
      triggerTip.style.display = triggerTypeSelect.value === "keyword" ? "" : "none";
      updateStartInspectorSummaries();
    }
    triggerTypeSelect.addEventListener("change", updateTriggerFieldsVisibility);
    typeSelect.addEventListener("change", updateTriggerFieldsVisibility);
    keywordsInput.addEventListener("input", function () { keywordMeta.querySelector(".extuifStartInspectorCharCount").textContent = String(keywordsInput.value.length) + "/500"; updateStartInspectorSummaries(); });
    funnelTriggerSelect.addEventListener("change", updateStartInspectorSummaries);
    columnTriggerColumnSelect.addEventListener("change", updateStartInspectorSummaries);
    updateTriggerFieldsVisibility();

    function optionText(select) { var option = select && select.options && select.options[select.selectedIndex]; return option ? option.textContent : ""; }
    function audienceSummary() {
      if (contactsInput.checked && groupsInput.checked) return "Contatos e grupos ativados";
      if (contactsInput.checked) return "Contatos ativados · Grupos desativados";
      if (groupsInput.checked) return "Contatos desativados · Grupos ativados";
      return "Contatos e grupos desativados";
    }
    function availabilitySummary() {
      var days = activeDays.length ? activeDays.slice().sort(function (a, b) { return a - b; }).map(function (idx) { return DAY_FULL_NAMES[idx].slice(0, 3); }).join(", ") : "Todos os dias";
      var hours = fromInput.value && toInput.value && fromInput.value !== toInput.value ? fromInput.value + "–" + toInput.value : "Sem restrição";
      if (weeklyToggleInput.checked) return "Horários diferentes por dia";
      return days + " · " + hours;
    }
    function updateStartInspectorSummaries() {
      if (!triggerTypeSelect || !typeSelect || !contactsInput || !groupsInput || !fromInput || !toInput || !weeklyToggleInput || !crmGateToggle || !crmGateCrmSelect || !crmGateColumnSelect || !webhookInput || !webhookToggle) return;
      var triggerLabel = optionText(triggerTypeSelect) || "Gatilho";
      if (triggerTypeSelect.value === "keyword") triggerLabel += " · " + (optionText(typeSelect) || "Regra");
      else if (triggerTypeSelect.value === "columnMoved" && columnTriggerColumnSelect.value) triggerLabel += " · " + optionText(columnTriggerColumnSelect);
      else if (triggerTypeSelect.value === "funnelCompleted") triggerLabel += " · " + (optionText(funnelTriggerSelect) || "Qualquer funil");
      if (summaryEls.trigger) summaryEls.trigger.textContent = triggerLabel;
      if (summaryEls.audience) summaryEls.audience.textContent = audienceSummary();
      if (summaryEls.availability) summaryEls.availability.textContent = availabilitySummary();
      if (summaryEls.conditions) summaryEls.conditions.textContent = crmGateToggle.checked ? ((optionText(crmGateCrmSelect) || "CRM") + (crmGateColumnSelect.value ? " · " + optionText(crmGateColumnSelect) : "")) : "Sem condições adicionais";
      if (summaryEls.advanced) summaryEls.advanced.textContent = webhookToggle.checked && webhookInput.value.trim() ? "Notificação externa configurada" : "Sem ações após o gatilho";
      availabilityStatusText.textContent = availabilitySummary();
    }
    [contactsInput, groupsInput, fromInput, toInput, crmGateCrmSelect, crmGateColumnSelect, webhookInput, webhookToggle].forEach(function (control) {
      control.addEventListener("change", updateStartInspectorSummaries);
      control.addEventListener("input", updateStartInspectorSummaries);
    });
    updateStartInspectorSummaries();

    function showStartInspectorSection(sectionId) {
      activeSection = sectionOrder.indexOf(sectionId) >= 0 ? sectionId : "trigger";
      sectionOrder.forEach(function (id) {
        var active = id === activeSection;
        if (sectionPages[id]) sectionPages[id].hidden = !active;
        if (navButtons[id]) {
          navButtons[id].classList.toggle("is-active", active);
          navButtons[id].setAttribute("aria-selected", active ? "true" : "false");
          navButtons[id].setAttribute("tabindex", active ? "0" : "-1");
        }
      });
      body.scrollTop = 0;
      var page = sectionPages[activeSection];
      var focusTarget = page && page.querySelector("select, input:not([type=checkbox]), textarea, button");
      if (focusTarget) setTimeout(function () { try { focusTarget.focus(); } catch (_) {} }, 0);
    }

    var actions = el("div", { class: "extuifStartInspectorActions" });
    var secondaryBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" });
    secondaryBtn.addEventListener("click", function () { closeTrigger(); });
    var saveBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Salvar" });
    saveBtn.addEventListener("click", async function () {
      if (savingTrigger) return;
      savingTrigger = true;
      saveBtn.disabled = true;
      secondaryBtn.disabled = true;
      modal.setAttribute("aria-busy", "true");
      var previousTrigger = JSON.parse(JSON.stringify(flow.trigger || {}));
      try {
        var keywords = keywordsInput.value.split(",").map(function (k) { return k.trim(); }).filter(Boolean);
        var nextTrigger = JSON.parse(JSON.stringify(flow.trigger || {}));
        nextTrigger.type = triggerTypeSelect.value;
        nextTrigger.activationTypes = [triggerTypeSelect.value];
        nextTrigger.keywordRules = [{ type: typeSelect.value, keywords: keywords }];
        nextTrigger.sendToContacts = contactsInput.checked;
        nextTrigger.sendToGroups = groupsInput.checked;
        nextTrigger.activeDays = activeDays.slice();
        nextTrigger.activeHours = (fromInput.value && toInput.value && fromInput.value !== toInput.value) ? { from: fromInput.value, to: toInput.value } : null;
        nextTrigger.webhook = webhookToggle.checked ? (webhookInput.value.trim() || null) : null;
        if (triggerTypeSelect.value === "columnMoved") nextTrigger.data = { crmId: columnTriggerCrmSelect.value, columnId: columnTriggerColumnSelect.value };
        else if (triggerTypeSelect.value === "funnelCompleted") nextTrigger.data = { sourceId: funnelTriggerSelect.value || "" };
        else nextTrigger.data = null;
        if (weeklyToggleInput.checked) {
          var weeklyHours = {};
          weeklyRows.forEach(function (row, dayIndex) { weeklyHours[dayIndex] = { active: row.active.checked, from: row.from.value || "00:00", to: row.to.value || "23:59" }; });
          nextTrigger.weeklyHours = weeklyHours;
        } else nextTrigger.weeklyHours = null;
        nextTrigger.crmGate = (crmGateToggle.checked && crmGateCrmSelect.value && crmGateColumnSelect.value) ? { crmId: crmGateCrmSelect.value, columnId: crmGateColumnSelect.value } : null;
        var all = await loadFlows();
        var idx = all.findIndex(function (f) { return f.id === flow.id; });
        var nextFlow = cloneFlowSnapshot(flow);
        nextFlow.trigger = nextTrigger;
        if (idx >= 0) all[idx] = nextFlow;
        await saveFlows(all);
        flow.trigger = nextTrigger;
        pushFlowHistorySnapshot(flow);
        var canvasWrap = host && host.closest ? host.closest(".extuifCanvasWrap") : null;
        if (!canvasWrap && rootEl && rootEl.querySelector) canvasWrap = rootEl.querySelector(".extuifCanvasWrap");
        var undoControl = canvasWrap && canvasWrap.querySelector('[data-extuif-undo="1"]');
        var redoControl = canvasWrap && canvasWrap.querySelector('[data-extuif-redo="1"]');
        if (undoControl) undoControl.disabled = false;
        if (redoControl) redoControl.disabled = true;
        savingTrigger = false;
        closeTrigger();
      } catch (err) {
        flow.trigger = previousTrigger;
        savingTrigger = false;
        saveBtn.disabled = false;
        secondaryBtn.disabled = false;
        modal.removeAttribute("aria-busy");
        toast(err && err.message ? err.message : "Não foi possível salvar o gatilho.", true);
      }
    });
    actions.appendChild(secondaryBtn);
    actions.appendChild(saveBtn);
    modal.appendChild(actions);
    overlay.appendChild(modal);
    host.appendChild(overlay);
    overlay.addEventListener("pointerdown", function (event) { if (event.target === overlay && !savingTrigger) closeTrigger(); });
    modal.addEventListener("keydown", function (event) { if (event.key === "Escape" && !savingTrigger) { event.preventDefault(); closeTrigger(); } });
    showStartInspectorSection("trigger");
    if (navButtons.trigger) try { navButtons.trigger.focus(); } catch (_) {}
  }


  function openFlowSimulator(flow, host) {
    host = resolveStartInspectorHost(host);
    var core = window.ExtensionFlowSimulatorCore;
    if (!core) { toast("O Simulador de Fluxos ainda não está disponível.", true); return; }
    var previous = host && host.querySelector ? host.querySelector(".extuifSimulatorOverlay") : null;
    if (previous) previous.remove();

    var simulatorPrefs = { showLogs:false, speed:"instant", autoScroll:true, showConditionDetails:false, showNodeDetails:false, pauseOnDecision:false, fixedRandom:false };
    var simulatorRandom = Math.random;
    function simulatorSeedHash(value) {
      var hash = 2166136261, text = String(value || "");
      for (var i = 0; i < text.length; i++) { hash ^= text.charCodeAt(i); hash = Math.imul(hash, 16777619); }
      return hash >>> 0;
    }
    function simulatorSeededRandom(seed) {
      var state = simulatorSeedHash(seed) || 0x6d2b79f5;
      return function () {
        state += 0x6D2B79F5;
        var t = state;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
      };
    }
    function simulatorDelayScale() { return simulatorPrefs.speed === "realtime" ? 1 : simulatorPrefs.speed === "accelerated" ? 0.1 : 0; }

    var simulatorLibraryConfig = {
      sendAudio: { key: "EXTUI:audioStore", listField: "audioList", kind: "audio" },
      sendImage: { key: "EXTUI:mediaStore", listField: "mediaList", kind: "image" },
      sendVideo: { key: "EXTUI:mediaStore", listField: "mediaList", kind: "video" },
      sendSticker: { key: "EXTUI:stickerStore", listField: "stickerList", kind: "sticker" },
      sendDocument: { key: "EXTUI:documentStore", listField: "documentList", kind: "document" },
      sendMedia: { key: "EXTUI:mediaStore", listField: "mediaList", kind: "media" }
    };
    function parseSimulatorStored(raw) {
      if (raw == null || raw === "") return null;
      try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (_) { return null; }
    }
    function simulatorCatalogList(raw, listField) {
      var parsed = parseSimulatorStored(raw);
      var state = parsed && parsed.state && typeof parsed.state === "object" ? parsed.state : parsed;
      return state && Array.isArray(state[listField]) ? state[listField] : [];
    }
    function simulatorDataUrl(raw, mimeType) {
      if (!raw) return Promise.resolve("");
      if (window.ExtensionMediaStore && typeof window.ExtensionMediaStore.isRef === "function" && window.ExtensionMediaStore.isRef(raw) && typeof window.ExtensionMediaStore.previewUrl === "function") {
        return Promise.resolve(window.ExtensionMediaStore.previewUrl(raw)).catch(function () { return ""; });
      }
      if (typeof raw !== "string") return Promise.resolve("");
      if (/^(data:|blob:|https?:)/i.test(raw)) return Promise.resolve(raw);
      if (mimeType && /^[A-Za-z0-9+/=\s]+$/.test(raw)) return Promise.resolve("data:" + mimeType + ";base64," + raw.replace(/\s+/g, ""));
      return Promise.resolve("");
    }
    async function resolveSimulatorLibraryItem(nodeType, itemId, itemKind) {
      itemId = String(itemId || "");
      if (!itemId) return null;
      var cfg = simulatorLibraryConfig[nodeType] || null;
      if (nodeType === "sendMedia" && itemKind === "audio") cfg = simulatorLibraryConfig.sendAudio;
      if (nodeType === "sendMedia" && itemKind === "document") cfg = simulatorLibraryConfig.sendDocument;
      if (!cfg) return null;
      var values = await Promise.all([storageGet(cfg.key), storageGet(itemId)]);
      var list = simulatorCatalogList(values[0], cfg.listField);
      var meta = list.find(function (item) { return item && String(item.id || "") === itemId; }) || null;
      var content = parseSimulatorStored(values[1]) || {};
      var name = String((meta && (meta.name || meta.fileName || meta.displayName)) || content.name || content.fileName || "Item da Biblioteca");
      var mimeType = String(content.mimeType || content.type || "");
      var fileName = String(content.fileName || content.name || name || "");
      var kind = cfg.kind;
      if (kind === "media") {
        var mediaKind = String((meta && meta.mediaKind) || content.mediaKind || "").toLowerCase();
        if (mediaKind === "image" || mediaKind === "video") kind = mediaKind;
        else if (/^video\//i.test(mimeType) || /\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/i.test(fileName)) kind = "video";
        else kind = "image";
      }
      var source = content.data || content.base64 || content.src || "";
      var url = await simulatorDataUrl(source, mimeType);
      return { id: itemId, name: name, fileName: fileName, mimeType: mimeType, kind: kind, url: url, caption: String(content.caption || "") };
    }
    function appendSimulatorMediaPreview(row, item) {
      if (!row || !item) return;
      var preview = el("div", { class: "extuifSimulatorMediaPreview extuifSimulatorMediaPreview--" + item.kind });
      var media = null;
      if (item.url && (item.kind === "image" || item.kind === "sticker")) media = el("img", { src: item.url, alt: item.name || "Mídia simulada" });
      else if (item.url && item.kind === "video") media = el("video", { src: item.url, controls: "controls", preload: "metadata", "aria-label": item.name || "Vídeo simulado" });
      else if (item.url && item.kind === "audio") media = el("audio", { src: item.url, controls: "controls", preload: "metadata", "aria-label": item.name || "Áudio simulado" });
      if (media) preview.appendChild(media);
      var copy = el("div", { class: "extuifSimulatorMediaCopy" }, [
        el("strong", { text: item.name || item.fileName || "Item da Biblioteca" }),
        item.fileName && item.fileName !== item.name ? el("small", { text: item.fileName }) : null,
        item.caption ? el("small", { text: item.caption }) : null
      ]);
      preview.appendChild(copy);
      row.appendChild(preview);
    }

    var overlay = el("div", { class: "extuifSimulatorOverlay", "data-extuif-simulator-overlay": "1" });
    var modal = el("section", { class: "extuifSimulator", role: "dialog", "aria-modal": "true", "aria-label": "Simulador do Fluxo", tabindex: "-1" });
    var header = el("header", { class: "extuifSimulatorHeader" });
    var heading = el("div", { class: "extuifSimulatorHeading" }, [
      el("span", { class: "extuifSimulatorHeaderIcon", "aria-hidden": "true" }, [icon("play")]),
      el("div", { class: "extuifSimulatorHeadingCopy" }, [
        el("span", { class: "extuifSimulatorEyebrow", text: "SIMULAÇÃO SEGURA" }),
        el("h3", { text: "Simulador" }),
        el("small", { text: String(flow && flow.name || "Fluxo") })
      ])
    ]);
    var logsInput = el("input", { type: "checkbox", "aria-label": "Mostrar logs da execução" }); logsInput.checked = false;
    var logsSwitch = el("label", { class: "extuiSwitch extuifSimulatorLogsSwitch" }, [logsInput, el("span", { class: "track" })]);
    var logsSegment = el("div", { class: "extuifSimulatorHeaderSegment extuifSimulatorLogsSegment" }, [el("span", { text: "Logs" }), logsSwitch]);
    var optionsDetails = el("details", { class: "extuifSimulatorOptions" });
    var optionsSummary = el("summary", { class: "extuifSimulatorHeaderSegment extuifSimulatorOptionsSummary" }, [el("span", { class: "extuifSimulatorOptionsGear", "aria-hidden": "true", text: "⚙" }), el("span", { text: "Outras opções" })]);
    var optionsMenu = el("div", { class: "extuifSimulatorOptionsMenu", role: "menu" });
    function simulatorMenuButton(label) { return el("button", { type: "button", class: "extuifSimulatorMenuButton", "data-sim-option-label": label, text: label }); }
    function simulatorMenuToggle(label) {
      var inputEl = el("input", { type: "checkbox", "aria-label": label });
      var row = el("label", { class: "extuifSimulatorMenuRow", "data-sim-option-label": label }, [el("span", { text: label }), el("span", { class: "extuiSwitch" }, [inputEl, el("span", { class: "track" })])]);
      return { row:row, input:inputEl };
    }
    var restartKeepScenarioBtn = simulatorMenuButton("Reiniciar mantendo o cenário");
    var speedSelect = el("select", { "aria-label": "Velocidade da simulação" }, [
      el("option", { value: "instant", text: "Instantânea" }),
      el("option", { value: "accelerated", text: "Acelerada (10×)" }),
      el("option", { value: "realtime", text: "Tempo real" })
    ]);
    var speedRow = el("label", { class: "extuifSimulatorMenuRow extuifSimulatorMenuRow--select", "data-sim-option-label": "Velocidade da simulação" }, [el("span", { text: "Velocidade da simulação" }), speedSelect]);
    var autoScrollOption = simulatorMenuToggle("Rolagem automática do chat");
    autoScrollOption.input.checked = true;
    var conditionDetailsOption = simulatorMenuToggle("Mostrar detalhes das condições");
    var nodeDetailsOption = simulatorMenuToggle("Mostrar detalhes dos nós");
    var pauseDecisionOption = simulatorMenuToggle("Pausar nos nós de decisão");
    var copyReportBtn = simulatorMenuButton("Copiar relatório da simulação");
    var fixedRandomOption = simulatorMenuToggle("Fixar aleatoriedade para teste");
    [restartKeepScenarioBtn, speedRow, autoScrollOption.row, conditionDetailsOption.row, nodeDetailsOption.row, pauseDecisionOption.row, copyReportBtn, fixedRandomOption.row].forEach(function (item) { optionsMenu.appendChild(item); });
    optionsDetails.appendChild(optionsSummary); optionsDetails.appendChild(optionsMenu);
    var headerControls = el("div", { class: "extuifSimulatorHeaderControls" }, [logsSegment, optionsDetails]);
    var closeBtn = el("button", { type: "button", class: "extuifSimulatorClose", "aria-label": "Fechar simulador", text: "×" });
    header.appendChild(heading); header.appendChild(headerControls); header.appendChild(closeBtn); modal.appendChild(header);

    var scenario = el("div", { class: "extuifSimulatorScenario" });
    var triggerType = flow && flow.trigger && flow.trigger.type || "keyword";
    var triggerLabels = {
      keyword: "Palavra-chave", messageReceived: "Mensagem recebida", newChat: "Nova conversa", newDay: "Primeira mensagem do dia",
      columnMoved: "Contato movido no CRM", funnelCompleted: "Funil finalizado", followUpSent: "FollowUp enviado",
      scheduleSent: "Agendamento enviado", orderChanged: "Encomenda criada/alterada", manual: "Manual"
    };
    var triggerSummary = el("div", { class: "extuifSimulatorTriggerSummary" }, [
      el("span", { class: "extuifSimulatorTriggerDot", "aria-hidden": "true" }),
      el("div", {}, [el("small", { text: "Gatilho" }), el("strong", { text: triggerLabels[triggerType] || triggerType })])
    ]);
    var status = el("strong", { class: "extuifSimulatorStatus", role: "status", "aria-live": "polite", text: "Pronto para simular" });
    var statusSummary = el("div", { class: "extuifSimulatorStatusSummary" }, [el("small", { text: "STATUS" }), status]);
    var resetBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifSimulatorReset", text: "Novo Teste" });
    scenario.appendChild(triggerSummary); scenario.appendChild(statusSummary); scenario.appendChild(resetBtn); modal.appendChild(scenario);

    var contextPanel = el("details", { class: "extuifSimulatorContext" });
    contextPanel.appendChild(el("summary", { text: "Cenário da simulação" }));
    var contextGrid = el("div", { class: "extuifSimulatorContextGrid" });
    var chatTypeSelect = el("select", { "aria-label": "Tipo de conversa simulada" }, [
      el("option", { value: "contact", text: "Contato individual" }),
      el("option", { value: "group", text: "Grupo" })
    ]);
    var nowInput = el("input", { type: "datetime-local", "aria-label": "Data e hora simuladas" });
    function pad2(v) { return String(v).padStart(2, "0"); }
    function localDateTimeValue(date) {
      date = date instanceof Date ? date : new Date();
      return date.getFullYear() + "-" + pad2(date.getMonth() + 1) + "-" + pad2(date.getDate()) + "T" + pad2(date.getHours()) + ":" + pad2(date.getMinutes());
    }
    nowInput.value = localDateTimeValue(new Date());
    var crmSelect = el("select", { "aria-label": "CRM simulado" }, [el("option", { value: "", text: "Sem CRM" })]);
    var columnSelect = el("select", { "aria-label": "Coluna simulada" }, [el("option", { value: "", text: "Sem coluna" })]);
    function field(label, control) { return el("label", { class: "extuifSimulatorContextField" }, [el("span", { text: label }), control]); }
    contextGrid.appendChild(field("Público", chatTypeSelect));
    contextGrid.appendChild(field("Data e hora", nowInput));
    contextGrid.appendChild(field("CRM atual", crmSelect));
    contextGrid.appendChild(field("Coluna atual", columnSelect));
    contextPanel.appendChild(contextGrid); modal.appendChild(contextPanel);

    var actionBar = el("div", { class: "extuifSimulatorActionBar" });
    var triggerBtn = el("button", { type: "button", class: "extui-btn extui-btn--secondary extuifSimulatorTriggerBtn", text: "Executar gatilho" });
    actionBar.appendChild(triggerBtn); modal.appendChild(actionBar);

    var transcript = el("div", { class: "extuifSimulatorTranscript", role: "log", "aria-live": "polite", "aria-label": "Eventos da simulação" });
    function scrollSimulatorTranscriptToEnd() {
      if (!simulatorPrefs.autoScroll) return;
      requestAnimationFrame(function () { transcript.scrollTop = transcript.scrollHeight; });
    }
    modal.appendChild(transcript);
    var simulatorInlineActions = el("div", { class: "extuifSimulatorInlineActions" });
    var continueDecisionBtn = el("button", { type: "button", class: "extui-btn extui-btn--secondary extuifSimulatorContinueDecisionBtn", text: "Continuar decisão" });
    continueDecisionBtn.hidden = true;
    var expireBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifSimulatorExpireBtn", text: "Simular tempo esgotado" });
    expireBtn.hidden = true;
    simulatorInlineActions.appendChild(continueDecisionBtn); simulatorInlineActions.appendChild(expireBtn); modal.appendChild(simulatorInlineActions);

    var composer = el("form", { class: "extuifSimulatorComposer" });
    var input = el("input", { type: "text", autocomplete: "off", placeholder: "Digite uma mensagem para o Fluxo...", "aria-label": "Mensagem simulada" });
    var sendBtn = el("button", { type: "submit", class: "extuifSimulatorSend", "aria-label": "Enviar mensagem simulada" }, [icon("chevronRight")]);
    composer.appendChild(input); composer.appendChild(sendBtn); modal.appendChild(composer);
    overlay.appendChild(modal); host.appendChild(overlay);

    var crmList = [];
    function populateColumns(crmId, selectedColumnId) {
      columnSelect.innerHTML = "";
      columnSelect.appendChild(el("option", { value: "", text: "Sem coluna" }));
      var crm = crmList.find(function (item) { return item && String(item.id) === String(crmId || ""); });
      ((crm && crm.columns) || []).forEach(function (col) {
        var option = el("option", { value: String(col.id || ""), text: String(col.title || col.name || "Coluna") });
        if (String(col.id || "") === String(selectedColumnId || "")) option.selected = true;
        columnSelect.appendChild(option);
      });
    }
    crmSelect.addEventListener("change", function () { populateColumns(crmSelect.value, ""); resetSession(); });
    columnSelect.addEventListener("change", function () { resetSession(); });
    chatTypeSelect.addEventListener("change", function () { resetSession(); });
    nowInput.addEventListener("change", function () { resetSession(); });
    try {
      chrome.storage.local.get("EXTUI:CrmStore", function (res) {
        var raw = res && res["EXTUI:CrmStore"], parsed = null;
        try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; } catch (_) { parsed = null; }
        crmList = parsed && parsed.state && Array.isArray(parsed.state.crmList) ? parsed.state.crmList : [];
        crmList.forEach(function (crm) { if (crm && crm.id) crmSelect.appendChild(el("option", { value: String(crm.id), text: String(crm.name || "CRM") })); });
        var gate = flow && flow.trigger && flow.trigger.crmGate;
        if (gate && gate.crmId) { crmSelect.value = String(gate.crmId); populateColumns(gate.crmId, gate.columnId); }
        resetSession();
      });
    } catch (_) {}

    var session = null;
    var simulatorExpirationTimer = null;
    var simulatorCountdownTimer = null;
    var simulatorDelayTimer = null;
    var simulatorDelayCountdownTimer = null;
    function simulatorSeedMaterial() {
      var ctx = readContext();
      return [String(flow && flow.id || "flow"), ctx.isGroupChat ? "group" : "contact", String(ctx.crmId || ""), String(ctx.columnId || ""), ctx.now instanceof Date ? ctx.now.toISOString() : String(ctx.now || "")].join("|");
    }
    function resetSimulatorRandom() { simulatorRandom = simulatorPrefs.fixedRandom ? simulatorSeededRandom(simulatorSeedMaterial()) : Math.random; }
    function simulatorCoreOptions() { return { random:simulatorRandom, pauseOnDecision:!!simulatorPrefs.pauseOnDecision, delayScale:simulatorDelayScale() }; }
    function formatSimulatorCountdown(ms) {
      var totalSeconds = Math.max(0, Math.ceil((Number(ms) || 0) / 1000));
      var minutes = Math.floor(totalSeconds / 60), seconds = totalSeconds % 60;
      return String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
    }
    function updateSimulatorCountdown() {
      if (!session) return;
      if (session.status === "waitingForInput" && session.expiresAtMs) {
        var inputLabel = formatSimulatorCountdown(Number(session.expiresAtMs) - Date.now());
        status.textContent = "Aguardando resposta · " + inputLabel;
        transcript.querySelectorAll(".extuifSimulatorCountdown").forEach(function (node) { node.textContent = "Tempo restante: " + inputLabel; });
      } else if (session.status === "waitingDelay" && session.resumeAtMs) {
        var delayLabel = formatSimulatorCountdown(Number(session.resumeAtMs) - Date.now());
        status.textContent = "Aguardando · " + delayLabel;
        transcript.querySelectorAll(".extuifSimulatorDelayCountdown").forEach(function (node) { node.textContent = "Tempo da simulação: " + delayLabel; });
      }
    }
    function clearSimulatorExpiration() {
      if (simulatorExpirationTimer) { clearTimeout(simulatorExpirationTimer); simulatorExpirationTimer = null; }
      if (simulatorCountdownTimer) { clearInterval(simulatorCountdownTimer); simulatorCountdownTimer = null; }
      if (simulatorDelayTimer) { clearTimeout(simulatorDelayTimer); simulatorDelayTimer = null; }
      if (simulatorDelayCountdownTimer) { clearInterval(simulatorDelayCountdownTimer); simulatorDelayCountdownTimer = null; }
    }
    function scheduleSimulatorExpiration() {
      clearSimulatorExpiration();
      if (!session) return;
      if (session.status === "waitingForInput" && session.expiresAtMs) {
        function armInput() {
          if (!session || session.status !== "waitingForInput" || !session.expiresAtMs) { clearSimulatorExpiration(); return; }
          var remaining = Number(session.expiresAtMs) - Date.now();
          if (remaining <= 0) { clearSimulatorExpiration(); syncSessionContext(); session = core.expireInput(flow, session, simulatorCoreOptions()); renderSession(); return; }
          simulatorExpirationTimer = setTimeout(armInput, Math.min(remaining, 2147483647));
        }
        armInput(); updateSimulatorCountdown(); simulatorCountdownTimer = setInterval(updateSimulatorCountdown, 250); return;
      }
      if (session.status === "waitingDelay" && session.resumeAtMs) {
        function armDelay() {
          if (!session || session.status !== "waitingDelay" || !session.resumeAtMs) { clearSimulatorExpiration(); return; }
          var remaining = Number(session.resumeAtMs) - Date.now();
          if (remaining <= 0) { clearSimulatorExpiration(); syncSessionContext(); session = core.resumeDelay(flow, session, simulatorCoreOptions()); renderSession(); return; }
          simulatorDelayTimer = setTimeout(armDelay, Math.min(remaining, 2147483647));
        }
        armDelay(); updateSimulatorCountdown(); simulatorDelayCountdownTimer = setInterval(updateSimulatorCountdown, 250);
      }
    }
    var messageTrigger = ["keyword", "messageReceived", "newChat", "newDay"].indexOf(triggerType) >= 0;
    function readContext() {
      var parsedNow = nowInput.value ? new Date(nowInput.value) : new Date();
      if (isNaN(parsedNow.getTime())) parsedNow = new Date();
      return { isGroupChat: chatTypeSelect.value === "group", now: parsedNow, crmId: crmSelect.value || "", columnId: columnSelect.value || "" };
    }
    function reasonLabel(reason) {
      return {
        AUDIENCE_GROUP_DISABLED: "Este Fluxo não aceita grupos no cenário atual.",
        AUDIENCE_CONTACT_DISABLED: "Este Fluxo não aceita contatos individuais no cenário atual.",
        SCHEDULE_BLOCKED: "A data/hora simulada está fora da disponibilidade configurada.",
        CRM_GATE_BLOCKED: "O contato simulado não está na coluna exigida pela condição de entrada.",
        TRIGGER_NOT_MATCHED: "A entrada não corresponde ao gatilho configurado."
      }[reason] || "A entrada foi bloqueada pelas regras do Fluxo.";
    }
    function formatDuration(ms) {
      ms = Math.max(0, Number(ms) || 0);
      if (ms >= 86400000 && ms % 86400000 === 0) return (ms / 86400000) + " dia(s)";
      if (ms >= 3600000 && ms % 3600000 === 0) return (ms / 3600000) + " hora(s)";
      if (ms >= 60000 && ms % 60000 === 0) return (ms / 60000) + " min";
      return Math.round(ms / 1000) + " s";
    }
    function eventNodeLabel(event) { return event && event.nodeId ? "Nó · " + flowIssueNodeLabel(flow, event.nodeId) : "Fluxo"; }
    function simulatorCrmName(crmId) { var crm = crmList.find(function (item) { return item && String(item.id || "") === String(crmId || ""); }); return crm ? String(crm.name || "CRM") : "CRM configurado"; }
    function simulatorColumnName(crmId, columnId) {
      var crm = crmList.find(function (item) { return item && String(item.id || "") === String(crmId || ""); });
      var col = crm && Array.isArray(crm.columns) ? crm.columns.find(function (item) { return item && String(item.id || "") === String(columnId || ""); }) : null;
      return col ? String(col.title || col.name || "Coluna") : "Coluna configurada";
    }
    function simulatorConditionDetail(event) {
      if (!event || event.nodeType !== "condition" || !event.nodeId) return "";
      var node = (flow.nodes || []).find(function (item) { return item && String(item.id || "") === String(event.nodeId); });
      if (!node) return "";
      if (node.data && node.data.conditionType === "inColumn") return simulatorCrmName(node.data.crmId) + " › " + simulatorColumnName(node.data.crmId, node.data.columnId) + " · " + (event.result ? "condição atendida" : "condição não atendida");
      return event.label ? String(event.label) : "Condição avaliada";
    }
    function simulatorEventIsTechnicalLog(event) {
      if (!event || event.kind === "message" || event.kind === "blocked" || event.kind === "error") return false;
      if (event.kind === "action" && event.itemId) return false;
      return true;
    }
    function simulatorEventTitle(event) {
      if (event.kind === "accepted") return "Gatilho aceito";
      if (event.kind === "blocked") return "Entrada bloqueada";
      if (event.kind === "branch") return event.label || "Ramificação";
      if (event.kind === "decisionPause") return "Decisão pausada";
      if (event.kind === "wait") return "Aguardar " + formatDuration(event.durationMs);
      if (event.kind === "prompt") return "Aguardando resposta";
      if (event.kind === "action") return event.text || "Ação simulada";
      if (event.kind === "system") return event.text || "Evento do Fluxo";
      if (event.kind === "error") return "Simulação interrompida";
      return event.text || "Evento";
    }
    function simulatorEventHasMedia(event) {
      return !!(event && event.kind === "action" && event.itemId && ["sendAudio","sendImage","sendVideo","sendSticker","sendDocument","sendMedia"].indexOf(String(event.nodeType || "")) >= 0);
    }
    function renderEvent(event) {
      var row;
      if (event.kind === "message") {
        row = el("div", { class: "extuifSimulatorMessage " + (event.direction === "in" ? "is-user" : "is-flow") });
        row.appendChild(el("span", { text: event.text || "" }));
        if (simulatorPrefs.showNodeDetails && event.nodeId) row.appendChild(el("small", { class: "extuifSimulatorNodeDetail", text: eventNodeLabel(event) }));
      } else {
        var tone = event.kind === "blocked" || event.kind === "error" ? " is-danger" : event.kind === "branch" ? " is-branch" : event.kind === "wait" ? " is-wait" : "";
        row = el("div", { class: "extuifSimulatorEvent" + tone });
        if (simulatorEventHasMedia(event)) row.classList.add("is-flow-media");
        var title = simulatorEventTitle(event);
        row.appendChild(el("strong", { text: title }));
        var detail = event.kind === "blocked" ? reasonLabel(event.reason) : (event.kind === "prompt" && event.expectedAnswer ? "Resposta esperada contém: “" + event.expectedAnswer + "”" : "");
        if (detail) row.appendChild(el("small", { text: detail }));
        if (simulatorPrefs.showConditionDetails) { var conditionDetail = simulatorConditionDetail(event); if (conditionDetail) row.appendChild(el("small", { class: "extuifSimulatorConditionDetail", text: conditionDetail })); }
        if (simulatorPrefs.showNodeDetails && event.nodeId) row.appendChild(el("small", { class: "extuifSimulatorNodeDetail", text: eventNodeLabel(event) }));
        if (event.kind === "prompt" && event.expiresAtMs) row.appendChild(el("small", { class: "extuifSimulatorCountdown", text: "Tempo restante: " + formatSimulatorCountdown(Number(event.expiresAtMs) - Date.now()) }));
        if (event.kind === "wait" && event.effectiveDurationMs) row.appendChild(el("small", { class: "extuifSimulatorDelayCountdown", text: "Tempo da simulação: " + formatSimulatorCountdown(event.effectiveDurationMs) }));
        if (event.kind === "action" && event.itemId) {
          var loading = el("small", { class: "extuifSimulatorMediaLoading", text: "Carregando item da Biblioteca…" });
          row.appendChild(loading);
          resolveSimulatorLibraryItem(event.nodeType, event.itemId, event.itemKind).then(function (item) {
            if (!row.isConnected) return;
            if (loading.isConnected) loading.remove();
            if (item) { appendSimulatorMediaPreview(row, item); scrollSimulatorTranscriptToEnd(); }
          }).catch(function () { if (loading.isConnected) loading.textContent = "Item da Biblioteca indisponível para prévia."; });
        }
      }
      transcript.appendChild(row);
    }
    function renderSession() {
      transcript.innerHTML = "";
      if (!session || !session.events.length) {
        transcript.appendChild(el("div", { class: "extuifSimulatorWelcome" }, [
          el("span", { class: "extuifSimulatorWelcomeIcon", "aria-hidden": "true" }, [icon("play")]),
          el("strong", { text: "Teste o caminho antes de ativar" }),
          el("p", { text: messageTrigger ? "Envie uma mensagem abaixo. O simulador aplicará o gatilho, público, disponibilidade, condições e ramificações sem enviar nada ao WhatsApp." : "Use “Executar gatilho” para iniciar. O simulador percorre condições e ramificações sem executar ações reais." }),
          el("small", { text: "Nós de IA são representados na simulação sem consumir API; ações externas, mídias e CRM não são executados de verdade." })
        ]));
      } else session.events.forEach(function (event) { if (simulatorPrefs.showLogs || !simulatorEventIsTechnicalLog(event)) renderEvent(event); });
      var st = session ? session.status : "idle";
      status.textContent = { idle:"Pronto para simular", running:"Executando", waitingForInput:"Aguardando resposta", waitingDelay:"Aguardando", pausedDecision:"Pausado em decisão", finished:"Fluxo concluído", needsHuman:"Transferido para humano", error:"Simulação interrompida" }[st] || st;
      if ((st === "waitingForInput" && session && session.expiresAtMs) || (st === "waitingDelay" && session && session.resumeAtMs)) updateSimulatorCountdown();
      expireBtn.hidden = st !== "waitingForInput";
      continueDecisionBtn.hidden = st !== "pausedDecision";
      simulatorInlineActions.hidden = expireBtn.hidden && continueDecisionBtn.hidden;
      var canType = st === "waitingForInput" || (messageTrigger && ["idle", "finished", "error", "needsHuman"].indexOf(st) >= 0);
      input.disabled = !canType; sendBtn.disabled = !canType;
      input.placeholder = st === "waitingForInput" ? "Digite a resposta simulada..." : (canType ? "Digite uma mensagem para o Fluxo..." : "Execute o gatilho para iniciar...");
      actionBar.hidden = messageTrigger;
      triggerBtn.hidden = messageTrigger;
      triggerBtn.disabled = ["waitingForInput","waitingDelay","pausedDecision","running"].indexOf(st) >= 0;
      speedSelect.disabled = ["waitingForInput","waitingDelay","pausedDecision","running"].indexOf(st) >= 0;
      scheduleSimulatorExpiration();
      scrollSimulatorTranscriptToEnd();
    }
    function resetSession() { resetSimulatorRandom(); session = core.createSession(flow, readContext()); renderSession(); }
    function resetScenarioToDefaults() {
      chatTypeSelect.value = "contact"; nowInput.value = localDateTimeValue(new Date());
      var gate = flow && flow.trigger && flow.trigger.crmGate;
      if (gate && gate.crmId && crmList.some(function (item) { return item && String(item.id || "") === String(gate.crmId); })) { crmSelect.value = String(gate.crmId); populateColumns(gate.crmId, gate.columnId); }
      else { crmSelect.value = ""; populateColumns("", ""); }
      contextPanel.open = false; resetSession();
    }
    function syncSessionContext() { if (!session) resetSession(); session.context = readContext(); }
    function buildSimulatorReport() {
      var ctx = readContext(), lines = ["ZVM - Automações · Relatório do Simulador", "Fluxo: " + String(flow && flow.name || "Fluxo"), "Status: " + status.textContent, "Público: " + (ctx.isGroupChat ? "Grupo" : "Contato individual"), "Data/hora simulada: " + (ctx.now instanceof Date ? ctx.now.toLocaleString("pt-BR") : String(ctx.now || "")), "CRM: " + (ctx.crmId ? simulatorCrmName(ctx.crmId) : "Sem CRM"), "Coluna: " + (ctx.columnId ? simulatorColumnName(ctx.crmId, ctx.columnId) : "Sem coluna"), "", "Eventos:"];
      (session && session.events || []).forEach(function (event, index) {
        var prefix = String(index + 1).padStart(2, "0") + ". ";
        if (event.kind === "message") lines.push(prefix + (event.direction === "in" ? "Público: " : "Fluxo: ") + String(event.text || "") + (event.nodeId ? " [" + flowIssueNodeLabel(flow, event.nodeId) + "]" : ""));
        else lines.push(prefix + simulatorEventTitle(event) + (event.nodeId ? " [" + flowIssueNodeLabel(flow, event.nodeId) + "]" : "") + (simulatorConditionDetail(event) ? " — " + simulatorConditionDetail(event) : ""));
      });
      return lines.join("\n");
    }
    function copySimulatorReport() {
      var text = buildSimulatorReport();
      var promise = navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(text) : Promise.reject(new Error("clipboard unavailable"));
      promise.then(function () { toast("Relatório da simulação copiado."); optionsDetails.open = false; }).catch(function () {
        try { var ta = document.createElement("textarea"); ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); toast("Relatório da simulação copiado."); optionsDetails.open = false; }
        catch (_) { toast("Não foi possível copiar o relatório da simulação.", true); }
      });
    }
    resetBtn.addEventListener("click", resetScenarioToDefaults);
    triggerBtn.addEventListener("click", function () {
      syncSessionContext();
      var options = { event: {} };
      if (triggerType === "funnelCompleted") options.event.sourceId = flow && flow.trigger && flow.trigger.data && flow.trigger.data.sourceId || "";
      if (triggerType === "columnMoved") {
        options.event.crmId = session.context.crmId;
        options.event.columnId = session.context.columnId;
      }
      Object.assign(options, simulatorCoreOptions()); session = core.fireTrigger(flow, session, triggerType, options); renderSession();
    });
    composer.addEventListener("submit", function (event) {
      event.preventDefault(); var text = input.value.trim(); if (!text || input.disabled) return;
      syncSessionContext(); session = core.submitMessage(flow, session, text, simulatorCoreOptions()); input.value = ""; renderSession();
    });
    expireBtn.addEventListener("click", function () { syncSessionContext(); session = core.expireInput(flow, session, simulatorCoreOptions()); renderSession(); });
    continueDecisionBtn.addEventListener("click", function () { syncSessionContext(); session = core.continueDecision(flow, session, simulatorCoreOptions()); renderSession(); });
    logsInput.addEventListener("change", function () { simulatorPrefs.showLogs = !!logsInput.checked; renderSession(); });
    restartKeepScenarioBtn.addEventListener("click", function () { optionsDetails.open = false; resetSession(); });
    speedSelect.addEventListener("change", function () { simulatorPrefs.speed = speedSelect.value || "instant"; });
    autoScrollOption.input.addEventListener("change", function () { simulatorPrefs.autoScroll = !!autoScrollOption.input.checked; if (simulatorPrefs.autoScroll) scrollSimulatorTranscriptToEnd(); });
    conditionDetailsOption.input.addEventListener("change", function () { simulatorPrefs.showConditionDetails = !!conditionDetailsOption.input.checked; renderSession(); });
    nodeDetailsOption.input.addEventListener("change", function () { simulatorPrefs.showNodeDetails = !!nodeDetailsOption.input.checked; renderSession(); });
    pauseDecisionOption.input.addEventListener("change", function () { simulatorPrefs.pauseOnDecision = !!pauseDecisionOption.input.checked; });
    copyReportBtn.addEventListener("click", copySimulatorReport);
    fixedRandomOption.input.addEventListener("change", function () { simulatorPrefs.fixedRandom = !!fixedRandomOption.input.checked; resetSimulatorRandom(); });
    closeBtn.addEventListener("click", function () { clearSimulatorExpiration(); overlay.remove(); });
    overlay.addEventListener("pointerdown", function (event) { if (event.target === overlay) { clearSimulatorExpiration(); overlay.remove(); } });
    modal.addEventListener("keydown", function (event) { if (event.key === "Escape") { event.preventDefault(); clearSimulatorExpiration(); overlay.remove(); } });
    resetSession();
    try { modal.focus(); } catch (_) {}
  }


  function findInvalidRandomizerNode(flow) {
    var randomizerNodes = (flow.nodes || []).filter(function (n) { return n.type === "randomizer"; });
    for (var i = 0; i < randomizerNodes.length; i++) {
      var weights = (randomizerNodes[i].data && randomizerNodes[i].data.weights) || [];
      if (weights.length < 2) return "Não é possível ativar: uma etapa Aleatorizar tem menos de 2 caminhos configurados. Adicione pelo menos mais um na área de montagem.";
      if (weights.length > 6) return "Não é possível ativar: uma etapa Aleatorizar tem mais de 6 caminhos configurados. Remova um deles antes de ativar.";
      if (weights.some(function (w) { return !w.nextNodeId; })) return "Não é possível ativar: uma etapa Aleatorizar tem caminho sem próximo passo conectado na área de montagem.";
      if (weights.some(function (w) { return !Number.isFinite(Number(w && w.weight)) || Number(w.weight) <= 0; })) return "Não é possível ativar: todos os caminhos de uma etapa Aleatorizar precisam ter peso maior que zero.";
    }
    return null;
  }

                                                                         
                                                                      
                                                                      
                                                                     
                                                                          
                                                                        
                                                                        
                                                                        
                                                                      
                                                                  
                                                                        
                                                                         
                                                
  function openRandomizerModal(flow) {
    var overlay = el("div", { class: "extuifModalOverlay" });
    var titleId = "extuifRandomizerModalTitle-" + Date.now();
    var modal = el("div", { class: "extuifModal", role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, tabindex: "-1" });
    modal.appendChild(el("h3", { id: titleId, text: "Aleatorizadores" }));
    var lifecycle = null;
    var savingRandomizer = false;
    function closeRandomizer(reason) { if (lifecycle) return lifecycle.close(reason || "action"); overlay.remove(); return true; }

    var randomizerNodes = (flow.nodes || []).filter(function (n) { return n.type === "randomizer"; });
    var selectByNodeId = {};

    if (!randomizerNodes.length) {
      modal.appendChild(el("p", { class: "extuifModalHint", text: 'Este fluxo ainda não tem nenhuma etapa “Aleatorizar”. Adicione uma na área de montagem (categoria Controle) e configure os caminhos e as chances por lá; o modo de cada etapa é definido aqui.' }));
    } else {
      modal.appendChild(el("p", { class: "extuifModalHint", text: '“Sortear a cada execução” escolhe novamente a cada vez, conforme as chances configuradas na etapa. “Fixo por contato” sempre escolhe o mesmo caminho para o mesmo contato nessa etapa, sem precisar guardar histórico.' }));
      randomizerNodes.forEach(function (node, index) {
        var weights = (node.data && node.data.weights) || [];
        var row = el("div", { class: "extuifRandomizerModalRow" });
        row.appendChild(el("label", { text: "Aleatorizar #" + (index + 1) + " · " + weights.length + (weights.length === 1 ? " ramo configurado" : " ramos configurados") }));
        var select = el("select", { "aria-label": "Modo do Aleatorizar #" + (index + 1) });
        [
          { value: "random", label: "Sortear a cada execução" },
          { value: "sticky", label: "Fixo por contato" }
        ].forEach(function (opt) {
          var o = el("option", { value: opt.value, text: opt.label });
          if ((node.data && node.data.mode === "sticky" ? "sticky" : "random") === opt.value) o.setAttribute("selected", "selected");
          select.appendChild(o);
        });
        row.appendChild(select);
        modal.appendChild(row);
        selectByNodeId[node.id] = select;
      });
    }

    var actions = el("div", { class: "extuifModalActions" });
    var cancelBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: randomizerNodes.length ? "Cancelar" : "Fechar" });
    cancelBtn.addEventListener("click", function () { closeRandomizer("cancel"); });
    actions.appendChild(cancelBtn);
    if (randomizerNodes.length) {
      var saveBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Salvar" });
      saveBtn.addEventListener("click", async function () {
        if (savingRandomizer) return;
        savingRandomizer = true;
        saveBtn.disabled = true;
        cancelBtn.disabled = true;
        modal.setAttribute("aria-busy", "true");
        var previousModes = randomizerNodes.map(function (node) { return node.data && node.data.mode; });
        try {
        randomizerNodes.forEach(function (node) {
          if (!node.data) node.data = {};
          node.data.mode = selectByNodeId[node.id].value === "sticky" ? "sticky" : "random";
        });
        var all = await loadFlows();
        var idx = all.findIndex(function (f) { return f.id === flow.id; });
        if (idx >= 0) all[idx] = flow;
        await saveFlows(all);
        savingRandomizer = false;
        closeRandomizer("save");
        openFlowCanvas(flow);                                                                                 
        } catch (err) {
          randomizerNodes.forEach(function (node, index) { if (!node.data) node.data = {}; if (previousModes[index] == null) delete node.data.mode; else node.data.mode = previousModes[index]; });
          savingRandomizer = false;
          saveBtn.disabled = false;
          cancelBtn.disabled = false;
          modal.removeAttribute("aria-busy");
          toast(err && err.message ? err.message : "Não foi possível salvar os aleatorizadores.", true);
        }
      });
      actions.appendChild(saveBtn);
    }
    modal.appendChild(actions);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    lifecycle = window.__extDialogLifecycle ? window.__extDialogLifecycle(overlay, modal, { initialFocus: function () { return randomizerNodes.length ? selectByNodeId[randomizerNodes[0].id] : cancelBtn; }, beforeClose: function () { return !savingRandomizer; } }) : null;
  }

  var flowSearchTerm = "";
  var flowSearchInputEl = null;
  function normalizeFlowSearch(value) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").trim();
  }
  function flowMatchesSearch(flow) {
    var term = normalizeFlowSearch(flowSearchTerm);
    if (!term) return true;
    return normalizeFlowSearch((flow && flow.name || "") + " " + (flow && flow.description || "")).indexOf(term) >= 0;
  }

  var flowRowsRenderSeqByList = typeof WeakMap === "function" ? new WeakMap() : null;
  function nextFlowRowsRenderSeq(listEl) {
    if (!flowRowsRenderSeqByList) return Date.now();
    var next = (flowRowsRenderSeqByList.get(listEl) || 0) + 1;
    flowRowsRenderSeqByList.set(listEl, next);
    return next;
  }
  function flowRowsRenderIsCurrent(listEl, seq) {
    if (!listEl || !listEl.isConnected || !rootEl || !rootEl.isConnected || !rootEl.contains(listEl)) return false;
    return !flowRowsRenderSeqByList || flowRowsRenderSeqByList.get(listEl) === seq;
  }
  async function renderFlowRows(listEl) {
    if (!listEl || !listEl.isConnected || !rootEl || !rootEl.contains(listEl)) return false;
    var seq = nextFlowRowsRenderSeq(listEl);
    var flows = await loadFlows();
    var runningCounts = await loadRunningCounts();
    if (!flowRowsRenderIsCurrent(listEl, seq)) return false;
    listEl.innerHTML = "";
    var visible = flows.filter(flowMatchesSearch);
    if (flows.length === 0) {
      listEl.appendChild(el("div", { class: "extuifEmpty" }, [
        icon("flow", "extuifEmptyIcon"),
        el("div", { class: "extuiFunnelEmptyTitle", text: "Crie seu primeiro fluxo" }),
        el("div", { class: "extuifEmptyText", text: "Monte uma automação visual com ações, condições e caminhos para cada cenário." }),
        el("button", { type: "button", class: "extui-btn extui-btn--primary", onClick: function () { createAndOpenFlow(); } }, [icon("plus"), el("span", { text: "Criar primeiro fluxo" })])
      ]));
      return;
    }
    if (visible.length === 0) {
      var emptySearch = el("div", { class: "extuifEmpty" }, [
        icon("search", "extuifEmptyIcon"),
        el("div", { class: "extuifEmptyText", text: "Nenhum fluxo encontrado para \"" + flowSearchTerm + "\"." })
      ]);
      var clearSearch = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Limpar busca" });
      clearSearch.addEventListener("click", function () { flowSearchTerm = ""; if (flowSearchInputEl) { flowSearchInputEl.value = ""; flowSearchInputEl.focus(); } renderFlowRows(listEl); });
      emptySearch.appendChild(clearSearch);
      listEl.appendChild(emptySearch);
      return;
    }
                                                                             
                                                                      
                                                                           
                                                                          
                                                                           
    visible.forEach(function (flow) {
      var row = el("div", { class: "extuifFlowRow" });
      row.style.setProperty("--extui-flow-accent", flow.color || "#10b981");
      var mainCol = el("div", { class: "extuifFlowMain" });
      var nameRow = el("div", { class: "extuifFlowNameRow" });
      nameRow.appendChild(el("div", { class: "extuifFlowName", text: flow.name }));
      var runningCount = runningCounts[flow.id] || 0;
      if (runningCount > 0) {
        nameRow.appendChild(el("div", { class: "extuifChip", text: runningCount + " em andamento" }));
      }
      var flowHealth = analyzeFlowGraph(flow);
      var healthText = flowHealth.errors.length && flowHealth.warnings.length ? flowHealth.errors.length + " erro(s) · " + flowHealth.warnings.length + " aviso(s)" : (flowHealth.errors.length ? flowHealth.errors.length + " erro(s)" : (flowHealth.warnings.length ? flowHealth.warnings.length + " aviso(s)" : "Saudável"));
      var healthChip = el("button", { type: "button", class: "extuifHealthChip " + (flowHealth.errors.length ? "is-error" : (flowHealth.warnings.length ? "is-warning" : "is-ok")), text: healthText, title: flowHealth.errors.length || flowHealth.warnings.length ? "Ver diagnóstico do fluxo" : "Estrutura do fluxo verificada", "aria-label": flowHealth.errors.length || flowHealth.warnings.length ? "Ver diagnóstico: " + healthText : "Fluxo saudável" });
      healthChip.addEventListener("click", function (event) { event.preventDefault(); event.stopPropagation(); openFlowDiagnostics(flow, flowHealth); });
      nameRow.appendChild(healthChip);
      mainCol.appendChild(nameRow);
      if (String(flow.description || "").trim()) mainCol.appendChild(el("div", { class: "extuifFlowDescription", text: flow.description }));
                                                                        
                                                                      
                                                            
      var nodeCount = (flow.nodes || []).length;
      var updatedLabel = fmtRelativeUpdated(flow.updatedAtInMs);
      mainCol.appendChild(el("div", { class: "extuifFlowMeta" }, [
        el("span", { class:"extuiAutomationMetaSteps", text: nodeCount + " etapa" + (nodeCount === 1 ? "" : "s") }),
        updatedLabel ? el("span", { class:"extuiAutomationMetaUpdated", text: updatedLabel }) : null
      ].filter(Boolean)));
      row.appendChild(mainCol);

                                                                   
                                                                           
                                                                        
                                        
      var activeSwitch = el("button", {
        type: "button", class: "extuiToggleTrack" + (flow.isActive ? " extuiOn" : ""),
        role: "switch", "aria-checked": String(flow.isActive),
        title: flow.isActive ? "Ativo" : "Pausado", "aria-label": (flow.isActive ? "Desativar" : "Ativar") + " fluxo " + flow.name
      }, [el("span", { class: "extuiToggleThumb" })]);
      activeSwitch.addEventListener("click", async function (e) {
        e.stopPropagation();
        var all = await loadFlows();
        var f = all.find(function (x) { return x.id === flow.id; });
                                                                             
                                                                          
                                                                    
        if (!f) { renderFlowRows(listEl); return; }
                                                                          
                                                                        
                                                                          
                                                                        
                                                                       
                                       
        if (!f.isActive) {
          var health = analyzeFlowGraph(f);
          if (!health.valid) { toast("Revise o Fluxo antes de ativar: " + health.errors[0].message, true); return; }
          var randomizerProblem = findInvalidRandomizerNode(f);
          if (randomizerProblem) { toast(randomizerProblem, true); return; }
        }
        f.isActive = !f.isActive;
        f.updatedAtInMs = Date.now();
        await saveFlows(all);
        toast(f.isActive ? "Fluxo ativado." : "Fluxo pausado.");
        renderFlowRows(listEl);
      });
      row.appendChild(activeSwitch);

      var actions = el("div", { class: "extuifFlowActions" });
      var favBtn = el("button", { class: "extuiItensIconBtn extuiFlowFavoriteBtn" + (flow.favorite ? " is-favorite" : ""), title: flow.favorite ? "Remover dos favoritos" : "Adicionar aos favoritos", "aria-label": (flow.favorite ? "Remover dos favoritos " : "Adicionar aos favoritos ") + flow.name, text: flow.favorite ? "★" : "☆" });
      favBtn.addEventListener("click", async function(e){e.stopPropagation();var all=await loadFlows(),f=all.find(function(x){return x.id===flow.id;});if(!f)return;f.favorite=!f.favorite;f.updatedAtInMs=Date.now();await saveFlows(all);renderFlowRows(listEl);});actions.appendChild(favBtn);
      var renameBtn = el("button", { class: "extuiItensIconBtn", title: "Editar Fluxo", "aria-label": "Editar fluxo " + flow.name }, [icon("edit")]);
      renameBtn.addEventListener("click", async function (e) {
        e.stopPropagation();
        try {
          var updated = await updateFlowMetadata(flow);
          if (updated) { toast("Fluxo atualizado."); renderFlowRows(listEl); }
        } catch (error) { toast(error && error.message || "Não foi possível atualizar o Fluxo.", true); }
      });
      actions.appendChild(renameBtn);
      var triggerBtn = el("button", { class: "extuiItensIconBtn", title: "Gatilho", "aria-label": "Configurar gatilho do fluxo " + flow.name }, [icon("zap")]);
      triggerBtn.addEventListener("click", function (e) {
        e.stopPropagation();
        openFlowCanvas(flow, { openStartInspectorOnMount: true }).catch(function (err) { toast(err && err.message || "Não foi possível abrir a configuração do Início.", true); });
      });
      actions.appendChild(triggerBtn);
      var testBtn = el("button", { type: "button", class: "extuiItensIconBtn", title: "Executar teste", "aria-label": "Executar teste do fluxo " + flow.name }, [icon("play")]);
      testBtn.addEventListener("click", function (e) {
        e.stopPropagation();
        var blockedReason = directContactTestBlockReason(flow);
        if (blockedReason) { toast(blockedReason, true); return; }
        openAutomationTestDialog({ flow: flow, onConfirm: function (contact) {
          return sendToWhatsAppTab("EXTUI_FLUXOS_START_MANUAL", { flowId: flow.id, phoneNumber: contact.value, isTest: true });
        } });
      });
      actions.appendChild(testBtn);
      var exportBtn = el("button", { type: "button", class: "extuifFlowExportBtn", title: "Exportar este Fluxo em .zflow", "aria-label": "Exportar fluxo " + flow.name, text: "⇩ Exportar" });
      exportBtn.addEventListener("click", function (e) { e.stopPropagation(); exportSingleFlow(flow).catch(function (err) { toast(err && err.message || "Não foi possível exportar o Fluxo.", true); }); });
      actions.appendChild(exportBtn);
      var duplicateBtn = el("button", { type: "button", class: "extuiItensIconBtn", title: "Duplicar", "aria-label": "Duplicar fluxo " + flow.name }, [icon("copy")]);
      duplicateBtn.addEventListener("click", async function (e) {
        e.stopPropagation();
        var all = await loadFlows();
        var source = all.find(function (item) { return item.id === flow.id; });
        if (!source) return;
        var duplicated = duplicateFlowDefinition(source);
        all.push(duplicated);
        await saveFlows(all);
        toast('Fluxo duplicado como "' + duplicated.name + '".');
        renderFlowRows(listEl);
      });
      actions.appendChild(duplicateBtn);
      var delBtn = el("button", { class: "extuiItensIconBtn extuiItensIconBtn--danger", title: "Excluir", "aria-label": "Excluir fluxo " + flow.name }, [icon("trash")]);
      delBtn.addEventListener("click", async function (e) {
        e.stopPropagation();
        var action=window.__extTrashConfirm?await window.__extTrashConfirm({title:'Excluir fluxo?',message:'Você pode enviar "'+flow.name+'" para a Lixeira, criar um backup antes da exclusão ou apagar definitivamente.'}):(await extConfirm('Excluir o fluxo "' + flow.name + '"?', { danger: true })?'permanent':null);if(!action)return;
        var all = await loadFlows();
        if(action==='trash'&&window.__extTrashService)await window.__extTrashService.add({type:'flow',label:flow.name,payload:{item:flow}});
        await saveFlows(all.filter(function (x) { return x.id !== flow.id; }));
        toast(action==='trash'?"Fluxo enviado para a Lixeira.":"Fluxo excluído definitivamente.");
        renderFlowRows(listEl);
      });
      actions.appendChild(delBtn);
      row.appendChild(actions);

      row.addEventListener("click", function () { openFlowCanvas(flow); });
      listEl.appendChild(row);
    });
  }

  function extFlowDownloadFile(fileName, text, mime) {
    var blob = new Blob([text], { type: mime || "application/json" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = fileName; a.style.display = "none"; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }
  function extFlowSafeFilename(name) { return String(name || "fluxo").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "fluxo"; }
  async function exportSingleFlow(flow) {
    if (!window.ExtensionFlowPortability) throw new Error("Serviço de portabilidade de Fluxos indisponível.");
    var envelope = await window.ExtensionFlowPortability.exportFlow(flow, chrome.runtime.getManifest().version);
    extFlowDownloadFile(extFlowSafeFilename(flow.name) + ".zflow", JSON.stringify(envelope, null, 2), "application/x-zvm-flow+json");
    toast("Fluxo exportado em .zflow.");
  }
  async function importFlowFile(file) {
    if (!file) return null;
    if (!window.ExtensionFlowPortability) throw new Error("Serviço de portabilidade de Fluxos indisponível.");
    if (file.size > window.ExtensionFlowPortability.MAX_BYTES) throw new Error("O arquivo de Fluxo excede o limite permitido.");
    var text = await file.text();
    var report = await window.ExtensionFlowPortability.importAny(text);
    var flow = report.flow;
    var dependencyText = report.dependencies && report.dependencies.length ? "\n\nDependências detectadas: " + report.dependencies.length + ". Elas deverão ser revisadas antes de ativar." : "";
    var warningText = report.warnings && report.warnings.length ? "\nAvisos: " + report.warnings.slice(0, 4).map(function (warning) { return warning && typeof warning === "object" ? String(warning.message || warning.code || "Aviso de importação") : String(warning); }).join(" · ") : "";
    var ok = await window.extConfirm("Importar “" + flow.name + "”?\n\n" + (flow.nodes || []).length + " etapas. O Fluxo será importado pausado para revisão." + dependencyText + warningText, { okLabel: "Importar fluxo" });
    if (!ok) return null;
    flow.isActive = false;
    var all = await loadFlows(); all.push(flow); await saveFlows(all);
    toast("Fluxo importado e mantido pausado para revisão.");
    return flow;
  }
  async function createTemplateFlow(templateId) {
    var core = window.ExtensionFlowTemplatesCore;
    if (!core) throw new Error("Biblioteca de modelos de Fluxos indisponível.");
    var tpl = core.list().find(function (item) { return item.id === templateId; });
    if (!tpl) throw new Error("Modelo de Fluxo não encontrado.");
    var ok = await window.extConfirm("Criar o modelo “" + tpl.name + "”?\n\n" + tpl.description + "\n\nEle será criado pausado para você revisar antes de ativar.", { okLabel: "Criar modelo" });
    if (!ok) return null;
    var flow = core.instantiate(tpl.id); flow.isActive = false;
    var all = await loadFlows(); all.push(flow); await saveFlows(all);
    toast("Modelo criado com " + flow.nodes.length + " etapas.");
    await openFlowCanvas(flow);
    return flow;
  }

  function openFlowTemplatesModal() {
    var core = window.ExtensionFlowTemplatesCore;
    if (!core) { toast("Biblioteca de modelos de Fluxos indisponível.", true); return; }
    var templates = core.list();
    var overlay = el("div", { class: "extuifModalOverlay" });
    var titleId = "extuifTemplatesTitle-" + Date.now();
    var modal = el("div", { class: "extuifModal extuifTemplateModal", role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, tabindex: "-1" });
    modal.appendChild(el("div", { class: "extuifTemplateModalHead" }, [
      el("div", {}, [
        el("span", { class: "extuifTemplateEyebrow", text: "MODELOS PRONTOS" }),
        el("h3", { id: titleId, text: "Comece com um Fluxo completo" }),
        el("p", { text: "Use um modelo como ponto de partida. Todos são criados pausados, editáveis e podem ser exportados em .zflow." })
      ])
    ]));
    var grid = el("div", { class: "extuifTemplateGrid" });
    var lifecycle = null, busy = false;
    function close(reason) { if (busy) return false; if (lifecycle) return lifecycle.close(reason || "action"); overlay.remove(); return true; }
    templates.forEach(function (tpl) {
      var card = el("button", { type: "button", class: "extuifTemplateCard" + (tpl.recommended ? " is-recommended" : ""), "aria-label": "Criar modelo " + tpl.name });
      var top = el("div", { class: "extuifTemplateCardTop" });
      top.appendChild(el("span", { class: "extuifTemplateBadge", text: tpl.badge || "Modelo" }));
      top.appendChild(el("span", { class: "extuifTemplateSteps", text: String(tpl.nodeCount || "") + " etapas" }));
      card.appendChild(top);
      card.appendChild(el("strong", { text: tpl.name }));
      card.appendChild(el("p", { text: tpl.description }));
      card.appendChild(el("span", { class: "extuifTemplateCreate", text: tpl.recommended ? "Criar modelo destaque →" : "Criar este modelo →" }));
      card.addEventListener("click", async function () {
        if (busy) return;
        busy = true; modal.setAttribute("aria-busy", "true");
        try { var created = await createTemplateFlow(tpl.id); busy = false; if (created) close("created"); else modal.removeAttribute("aria-busy"); }
        catch (err) { busy = false; modal.removeAttribute("aria-busy"); toast(err && err.message || "Não foi possível criar o modelo.", true); }
      });
      grid.appendChild(card);
    });
    modal.appendChild(grid);
    var actions = el("div", { class: "extuifModalActions" });
    var cancel = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Fechar" });
    cancel.addEventListener("click", function () { close("cancel"); });
    actions.appendChild(cancel); modal.appendChild(actions); overlay.appendChild(modal); document.body.appendChild(overlay);
    lifecycle = window.__extDialogLifecycle ? window.__extDialogLifecycle(overlay, modal, { initialFocus: function () { return grid.querySelector("button"); }, beforeClose: function () { return !busy; } }) : null;
    if (!lifecycle) { var first = grid.querySelector("button"); if (first) first.focus(); }
  }

  async function renderFlowList() {
    document.body.classList.remove("extuiFluxosCanvasMode");
    try {
      var flowListUrl = new URL(location.href);
      if (flowListUrl.searchParams.has("flowId")) {
        flowListUrl.searchParams.delete("flowId");
        history.replaceState({ extappSection: "fluxos" }, "", flowListUrl.pathname + (flowListUrl.searchParams.toString() ? "?" + flowListUrl.searchParams.toString() : "") + flowListUrl.hash);
      }
    } catch (_) {}
    rootEl.innerHTML = "";
    if (window.__extDashboardShell && window.__extDashboardShell.refreshSectionChrome) window.__extDashboardShell.refreshSectionChrome();
    var wrap = el("div", { class: "extuifSection" });
    var historyBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Histórico", title: "Abrir histórico de execuções" });
    historyBtn.addEventListener("click", function () { if (window.__extDashboardShell) window.__extDashboardShell.showSection("atividades", { force: true }); });
    var templatesBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Modelos" });
    var importBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Importar .zflow" });
    var importInput = el("input", { type: "file", accept: ".zflow,.json,application/json,application/x-zvm-flow+json", hidden: "hidden" });
    var newFlowBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "+ Novo fluxo", "data-extui-academy-target": "flow-new" });
    var header = el("div", { class: "extuifHeader", "data-extui-academy-target": "flow-overview" }, [
      el("h2", { text: "Fluxos" }),
      el("div", { class: "extuiFunnelHeaderActions" }, [historyBtn, templatesBtn, importBtn, newFlowBtn])
    ]);
    header.appendChild(importInput);
    templatesBtn.addEventListener("click", openFlowTemplatesModal);
    importBtn.addEventListener("click", function () { importInput.value = ""; importInput.click(); });
    importInput.addEventListener("change", function () { var file = importInput.files && importInput.files[0]; importFlowFile(file).then(function (flow) { if (flow) renderFlowList(); }).catch(function (err) { toast(err && err.message || "Não foi possível importar o Fluxo.", true); }); });
    newFlowBtn.addEventListener("click", function () { createAndOpenFlow(); });
    wrap.appendChild(header);

                                                                         
                                                                          
                         
    var searchWrap = el("div", { class: "extuiSearch extuifSearchInput" }, [icon("search")]);
    var searchInput = el("input", { type: "search", placeholder: "Buscar fluxo pelo nome...", autocomplete: "off", "aria-label": "Buscar fluxo pelo nome" });
    searchInput.value = flowSearchTerm;
    flowSearchInputEl = searchInput;
    searchWrap.appendChild(searchInput);
    wrap.appendChild(searchWrap);

    var list = el("div", { class: "extuifFlowList" });
    wrap.appendChild(list);
    rootEl.appendChild(wrap);

    searchInput.addEventListener("input", function () {
      flowSearchTerm = searchInput.value;
      renderFlowRows(list);
    });

    await renderFlowRows(list);
  }

  var NODE_TYPES = [
    { type: "start", label: "Início", icon: "▶", colorKey: "start" },
    { type: "sendText", label: "Enviar Mensagem", icon: "💬", colorKey: "text" },
    { type: "sendAudio", label: "Enviar Áudio", icon: "♫", colorKey: "media" },
    { type: "sendImage", label: "Enviar Imagem", icon: "▣", colorKey: "media" },
    { type: "sendVideo", label: "Enviar Vídeo", icon: "▷", colorKey: "media" },
    { type: "sendSticker", label: "Enviar Figurinha", icon: "◇", colorKey: "media" },
    { type: "sendDocument", label: "Enviar Documento", icon: "▤", colorKey: "media" },
    { type: "sendPix", label: "Enviar PIX", icon: "◇", colorKey: "text" },
    { type: "sendList", label: "Enviar Lista", icon: "☷", colorKey: "text" },
    { type: "sendContact", label: "Enviar Contato", icon: "●", colorKey: "text" },
    { type: "sendSignature", label: "Enviar Assinatura", icon: "✎", colorKey: "text" },
    { type: "sendQuickResponse", label: "Respostas Rápidas", icon: "⚡", colorKey: "text" },
    { type: "sendMedia", label: "Enviar mídia", icon: "🖼", colorKey: "media" },
    { type: "aiGenerate", label: "Gerar com IA", icon: "✦", colorKey: "ai" },
    { type: "aiAgent", label: "Executar Agente", icon: "⚙", colorKey: "ai" },
    { type: "userInput", label: "Esperar resposta", icon: "⏳", colorKey: "input" },
    { type: "randomizer", label: "Aleatorizar", icon: "🎲", colorKey: "randomizer" },
    { type: "end", label: "Fim", icon: "■", colorKey: "end" },
    { type: "moveToColumn", label: "Mover para coluna", icon: "🏷", colorKey: "column" },
    { type: "condition", label: "Condição CRM", icon: "❓", colorKey: "condition" },
    { type: "delay", label: "Aguardar", icon: "⏱", colorKey: "intervalo" },
    { type: "endHuman", label: "Transferir para humano", icon: "🧑‍💻", colorKey: "endHuman" }
  ];

  var currentEditorHandle = null;
  var flowHistoryKeydownCleanup = null;
  function detachFlowHistoryKeydown() {
    if (!flowHistoryKeydownCleanup) return;
    var cleanup = flowHistoryKeydownCleanup;
    flowHistoryKeydownCleanup = null;
    cleanup();
  }
  var fluxosEditorLoadPromise = null;
  function ensureFluxosEditorLoaded() {
    if (window.ExtensionFlowsEditor && typeof window.ExtensionFlowsEditor.mount === "function") return Promise.resolve(window.ExtensionFlowsEditor);
    if (fluxosEditorLoadPromise) return fluxosEditorLoadPromise;
    fluxosEditorLoadPromise = new Promise(function (resolve, reject) {
      var script = document.createElement("script");
      script.src = "../../app/dashboard/features/flows/editor.js";
      script.async = true;
      script.dataset.extuiLazyModule = "fluxos-editor";
      script.onload = function () {
        if (window.ExtensionFlowsEditor && typeof window.ExtensionFlowsEditor.mount === "function") resolve(window.ExtensionFlowsEditor);
        else reject(new Error("Editor visual de Fluxos não inicializou."));
      };
      script.onerror = function () { reject(new Error("Não foi possível carregar o editor visual de Fluxos.")); };
      document.head.appendChild(script);
    }).catch(function (err) { fluxosEditorLoadPromise = null; throw err; });
    return fluxosEditorLoadPromise;
  }
  var flowHistory = null;
  var suppressFlowPersist = false;
  var FLOW_HISTORY_LIMIT = 50;
  function cloneFlowSnapshot(flow) { return JSON.parse(JSON.stringify(flow || {})); }
  function flowSnapshotSignature(flow) { var copy = cloneFlowSnapshot(flow); delete copy.updatedAtInMs; return JSON.stringify(copy); }
  function ensureFlowHistory(flow, preserve) {
    if (preserve && flowHistory && flowHistory.flowId === String(flow && flow.id || "")) return flowHistory;
    flowHistory = { flowId: String(flow && flow.id || ""), past: [], present: cloneFlowSnapshot(flow), future: [] };
    return flowHistory;
  }
  function pushFlowHistorySnapshot(flow) {
    var history = ensureFlowHistory(flow, true), next = cloneFlowSnapshot(flow);
    if (flowSnapshotSignature(next) === flowSnapshotSignature(history.present)) { history.present = next; return false; }
    history.past.push(cloneFlowSnapshot(history.present));
    if (history.past.length > FLOW_HISTORY_LIMIT) history.past.splice(0, history.past.length - FLOW_HISTORY_LIMIT);
    history.present = next; history.future = []; return true;
  }
  async function persistFlowSnapshot(flow) {
    var all = await loadFlows(), idx = all.findIndex(function (item) { return item && item.id === flow.id; });
    if (idx >= 0) all[idx] = flow; else all.push(flow);
    await saveFlows(all);
  }
  var flowExpanded = false;
  function applyFlowExpandedMode() { document.body.classList.toggle("extuiFluxosExpandedMode", !!flowExpanded); }
  function setFlowExpanded(next) { flowExpanded = !!next; applyFlowExpandedMode(); var wrap = rootEl && rootEl.querySelector(".extuifCanvasWrap"); if (wrap) wrap.classList.toggle("extuifCanvasWrap--expanded", flowExpanded); var btn = rootEl && rootEl.querySelector("[data-extuif-expand]"); if (btn) { btn.classList.toggle("active", flowExpanded); btn.title = flowExpanded ? "Sair do editor expandido" : "Expandir editor"; var label=btn.querySelector("span:last-child"); if(label) label.textContent=flowExpanded ? "Sair" : "Expandir"; } }

  async function openFlowCanvas(flow, options) {
    options = options || {};
    if (ensureStructuralStart(flow)) await persistFlowSnapshot(flow);
    ensureFlowHistory(flow, options.preserveHistory === true);
    try { await ensureFluxosEditorLoaded(); }
    catch (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_EDITOR_LOAD_FAILED",err); toast(err.message || "Não foi possível carregar o editor de Fluxos.", true); return; }
    document.body.classList.add("extuiFluxosCanvasMode");
    detachFlowHistoryKeydown();
    if (currentEditorHandle) { currentEditorHandle.unmount(); currentEditorHandle = null; }
    rootEl.innerHTML = "";
    if (window.__extDashboardShell && window.__extDashboardShell.refreshSectionChrome) window.__extDashboardShell.refreshSectionChrome();

    var wrap = el("div", { class: "extuifCanvasWrap" + (flowExpanded ? " extuifCanvasWrap--expanded" : "") });
    var toolbar = el("div", { class: "extuifCanvasToolbar" });
    var backBtn = el("button", { type: "button", class: "extuifCanvasBackBtn", "aria-label": "Voltar para a lista de fluxos" }, [
      icon("arrowLeft"),
      el("span", { text: "Voltar" })
    ]);
    backBtn.addEventListener("click", function () {
      detachFlowHistoryKeydown();
      if (currentEditorHandle) { currentEditorHandle.unmount(); currentEditorHandle = null; }
      setFlowExpanded(false);
      renderFlowList();
    });
    var titleBlock = el("div", { class: "extuifCanvasTitleBlock extuifCanvasTitleBlock--single" }, [
      el("div", { class: "extuifCanvasTitle", text: flow.name })
    ]);
    var context = el("div", { class: "extuifCanvasContext" });
    function updateCanvasContext(currentFlow) {
      var count = (currentFlow.nodes || []).length;
      context.innerHTML = "";
      context.appendChild(el("span", {
        class: "extuifCanvasState" + (currentFlow.isActive ? " extuifCanvasState--active" : ""),
        text: currentFlow.isActive ? "Ativo" : "Pausado"
      }));
      context.appendChild(el("span", {
        class: "extuifCanvasMeta",
        text: count + " etapa" + (count === 1 ? "" : "s")
      }));
    }
    updateCanvasContext(flow);

    var titleCluster = el("div", { class: "extuifCanvasTitleCluster" }, [
      titleBlock,
      context
    ]);
    var toolbarActions = el("div", { class: "extuifCanvasActions" });
    var selectionModeActive = false;
    var selectionBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn extuifCanvasSelectionBtn", title: "Ativar modo de seleção múltipla", "aria-label": "Ativar modo de seleção múltipla", "aria-pressed": "false", "data-extuif-selection": "1" }, [icon("selection"), el("span", { text: "Seleção Múltipla" })]);
    function updateSelectionButton() {
      selectionBtn.classList.toggle("active", selectionModeActive);
      selectionBtn.setAttribute("aria-pressed", selectionModeActive ? "true" : "false");
      selectionBtn.title = selectionModeActive ? "Desativar modo de seleção múltipla" : "Ativar modo de seleção múltipla";
      selectionBtn.setAttribute("aria-label", selectionBtn.title);
    }
    selectionBtn.addEventListener("click", function () {
      selectionModeActive = !selectionModeActive;
      updateSelectionButton();
      if (currentEditorHandle && typeof currentEditorHandle.setSelectionMode === "function") currentEditorHandle.setSelectionMode(selectionModeActive);
    });
    toolbarActions.appendChild(selectionBtn);
    updateSelectionButton();
    var undoBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn", title: "Desfazer (Ctrl+Z)", "aria-label": "Desfazer última alteração", "data-extuif-undo": "1" }, [el("span", { "aria-hidden": "true", text: "↶" }), el("span", { text: "Desfazer" })]);
    var redoBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn", title: "Refazer (Ctrl+Shift+Z)", "aria-label": "Refazer última alteração", "data-extuif-redo": "1" }, [el("span", { "aria-hidden": "true", text: "↷" }), el("span", { text: "Refazer" })]);
    function updateHistoryButtons() { var h = ensureFlowHistory(flow, true), liveChanged = flowSnapshotSignature(flow) !== flowSnapshotSignature(h.present); undoBtn.disabled = !liveChanged && !h.past.length; redoBtn.disabled = !h.future.length; }
    async function applyFlowHistory(direction) {
      var h = ensureFlowHistory(flow, true), live = cloneFlowSnapshot(flow), target = null;
      if (direction === "undo") {
        if (flowSnapshotSignature(live) !== flowSnapshotSignature(h.present)) { h.future.unshift(live); target = cloneFlowSnapshot(h.present); }
        else if (h.past.length) { h.future.unshift(cloneFlowSnapshot(h.present)); target = h.past.pop(); h.present = cloneFlowSnapshot(target); }
      } else if (direction === "redo" && h.future.length) {
        h.past.push(cloneFlowSnapshot(h.present)); if (h.past.length > FLOW_HISTORY_LIMIT) h.past.shift(); target = h.future.shift(); h.present = cloneFlowSnapshot(target);
      }
      if (!target) { updateHistoryButtons(); return; }
      target.updatedAtInMs = Date.now(); h.present = cloneFlowSnapshot(target);
      suppressFlowPersist = true;
      try { if (currentEditorHandle) { currentEditorHandle.unmount(); currentEditorHandle = null; } await persistFlowSnapshot(target); }
      finally { suppressFlowPersist = false; }
      await openFlowCanvas(target, { preserveHistory: true });
    }
    undoBtn.addEventListener("click", function () { applyFlowHistory("undo").catch(function (err) { toast(err && err.message || "Não foi possível desfazer a alteração.", true); }); });
    redoBtn.addEventListener("click", function () { applyFlowHistory("redo").catch(function (err) { toast(err && err.message || "Não foi possível refazer a alteração.", true); }); });
    toolbarActions.appendChild(undoBtn); toolbarActions.appendChild(redoBtn); updateHistoryButtons();
    var expandBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn extuifCanvasExpandBtn", title: "Expandir editor", "data-extuif-expand": "1" }, [icon("expand"), el("span", { text: "Expandir" })]);
    expandBtn.addEventListener("click", function () { setFlowExpanded(!flowExpanded); });
    var organizeBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn", title: "Organizar etapas automaticamente" }, [
      icon("sparkles"),
      el("span", { text: "Organizar" })
    ]);
    organizeBtn.addEventListener("click", async function () {
      if (!layoutFlowNodesForReview(flow)) return;
      pushFlowHistorySnapshot(flow); updateHistoryButtons();
      flow.layoutRevision = 2;
      flow.updatedAtInMs = Date.now();
      organizeBtn.disabled = true;
      try {
        var all = await loadFlows();
        var idx = all.findIndex(function (item) { return item && item.id === flow.id; });
        if (idx >= 0) all[idx] = flow; else all.push(flow);
        await saveFlows(all);
        toast("Etapas organizadas automaticamente.");
        await openFlowCanvas(flow, { preserveHistory: true });
      } catch (err) {
        organizeBtn.disabled = false;
        toast(err && err.message || "Não foi possível organizar o Fluxo.", true);
      }
    });
    toolbarActions.appendChild(organizeBtn);
    var triggerBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn", title: "Configurar gatilho", "data-extuif-trigger": "1" }, [
      icon("zap"),
      el("span", { text: "Gatilho" })
    ]);
    triggerBtn.addEventListener("click", function () { if (currentEditorHandle && typeof currentEditorHandle.openStartInspector === "function") currentEditorHandle.openStartInspector(); else openStartInspector(flow, wrap); });
    toolbarActions.appendChild(triggerBtn);
    var randomizerBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn", title: "Configurar aleatorizadores" }, [
      icon("shuffle"),
      el("span", { text: "Caminhos" })
    ]);
    randomizerBtn.addEventListener("click", function () { openRandomizerModal(flow); });
    toolbarActions.appendChild(randomizerBtn);
    var canvasExportBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasActionBtn", title: "Exportar este Fluxo em .zflow", "aria-label": "Exportar este Fluxo em .zflow" }, [
      el("span", { "aria-hidden": "true", text: "⇩" }),
      el("span", { text: "Exportar" })
    ]);
    canvasExportBtn.addEventListener("click", function () { exportSingleFlow(flow).catch(function (err) { toast(err && err.message || "Não foi possível exportar o Fluxo.", true); }); });
    toolbarActions.appendChild(canvasExportBtn);
    toolbarActions.appendChild(expandBtn);

    toolbar.appendChild(backBtn);
    toolbar.appendChild(el("span", { class: "extuifCanvasToolbarDivider", "aria-hidden": "true" }));
    toolbar.appendChild(titleCluster);
    var simulatorBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuifCanvasSimulatorBtn", title: "Simular este Fluxo", "aria-label": "Abrir Simulador do Fluxo", "data-extuif-simulator": "1" }, [icon("play"), el("span", { text: "Simulador" })]);
    simulatorBtn.addEventListener("click", function () { openFlowSimulator(flow, wrap); });
    toolbar.appendChild(simulatorBtn);
    toolbar.appendChild(toolbarActions);
    wrap.appendChild(toolbar);

    function flowHistoryKeydown(event) {
      if (event.defaultPrevented || !(event.ctrlKey || event.metaKey) || event.altKey) return;
      var target = event.target, tag = target && target.tagName && target.tagName.toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select" || target && target.isContentEditable || target && target.closest && target.closest('[role="dialog"]')) return;
      var key = String(event.key || "").toLowerCase();
      if (key !== "z" && key !== "y") return;
      var redo = key === "y" || (key === "z" && event.shiftKey);
      event.preventDefault(); (redo ? redoBtn : undoBtn).click();
    }
    document.addEventListener("keydown", flowHistoryKeydown, true);
    flowHistoryKeydownCleanup = function () { document.removeEventListener("keydown", flowHistoryKeydown, true); };

    var flowStage = el("div", { class: "extuifFlowStage" });
    var mountPoint = el("div", { class: "extuifReactMount" });
    flowStage.appendChild(mountPoint);
    wrap.appendChild(flowStage);
    rootEl.appendChild(wrap);

    try {
      currentEditorHandle = window.ExtensionFlowsEditor.mount(mountPoint, {
        flow: flow,
        nodeTypeDefs: NODE_TYPES,
        onPersist: async function (updatedFlow) {
          if (suppressFlowPersist) return;
          updateCanvasContext(updatedFlow);
          pushFlowHistorySnapshot(updatedFlow); updateHistoryButtons();
          var all = await loadFlows();
          var idx = all.findIndex(function (f) { return f.id === updatedFlow.id; });
          if (idx >= 0) all[idx] = updatedFlow; else all.push(updatedFlow);
          await saveFlows(all);
        },
        onSelectionModeChange: function (active) {
          selectionModeActive = !!active;
          updateSelectionButton();
        },
        onStartConfigure: function (configuredFlow, startNode) {
          var existingStartOverlay = wrap.querySelector(".extuifStartInspectorOverlay");
          var existingStartInspector = wrap.querySelector(".extuifStartInspector");
          if (!startNode) { if (existingStartOverlay) existingStartOverlay.remove(); else if (existingStartInspector) existingStartInspector.remove(); return; }
          openStartInspector(flow, wrap);
        }
      });
      if (options.openStartInspectorOnMount && currentEditorHandle && typeof currentEditorHandle.openStartInspector === "function") currentEditorHandle.openStartInspector();
      if (options.focusNodeId) setTimeout(function () { try { var escaped = window.CSS && CSS.escape ? CSS.escape(String(options.focusNodeId)) : String(options.focusNodeId).replace(/"/g, '\"'); var nodeEl = wrap.querySelector('.react-flow__node[data-id="' + escaped + '"]'); if (nodeEl) { nodeEl.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window })); } } catch (_) {} }, 90);
    } catch (err) {
      detachFlowHistoryKeydown();
      currentEditorHandle = null;
      setFlowExpanded(false);
      document.body.classList.remove("extuiFluxosCanvasMode");
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_EDITOR_MOUNT_FAILED",err);
      toast(err&&err.message||"Não foi possível abrir o editor de Fluxos.",true);
      try { await renderFlowList(); } catch (renderError) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_LIST_RECOVERY_FAILED",renderError); }
    }
  }

                                                                         
                                                                            
                            
  async function renderFluxosSection(container) {
    detachFlowHistoryKeydown();
    if (currentEditorHandle) { currentEditorHandle.unmount(); currentEditorHandle = null; }
    document.body.classList.remove("extuiFluxosCanvasMode");
    flowExpanded = false; applyFlowExpandedMode();
    container.innerHTML = "";
    rootEl = container;
    flowSearchTerm = "";
    flowSearchInputEl = null;
    var requestedFlowId = null;
    try { requestedFlowId = new URLSearchParams(location.search).get("flowId"); } catch (_) {}
    if (requestedFlowId) {
      var flows = await loadFlows();
      var requestedFlow = flows.find(function (flow) { return String(flow && flow.id || "") === requestedFlowId; });
      if (requestedFlow) return openFlowCanvas(requestedFlow);
      toast("O Fluxo solicitado não foi encontrado.", true);
    }
    return renderFlowList();
  }

  function renderFunisSection(container) {
    container.innerHTML = "";
    var requestedFunnelId = null;
    try { requestedFunnelId = new URLSearchParams(location.search).get("funnelId"); } catch (_) {}
    return window.ExtensionFunnelsUI.render(container, { funnelId: requestedFunnelId });
  }

  document.addEventListener("ext:dashboard-section-change", function (event) { if (!event.detail || event.detail.section !== "fluxos") { detachFlowHistoryKeydown(); flowExpanded = false; applyFlowExpandedMode(); document.body.classList.remove("extuiFluxosCanvasMode"); } });
  function scheduleExternalFlowRefresh(meta) {
    if (meta && meta.local === true) return;
    var shell = window.__extDashboardShell;
    if (!shell || !rootEl || !rootEl.isConnected || shell.getCurrentSection() !== "fluxos" || currentEditorHandle) return;
    Promise.resolve(renderFlowList()).catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_EXTERNAL_REFRESH_FAILED",err); });
  }
  if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
    window.ExtensionStorage.subscribe(STORAGE_KEY, function (_newValue, _oldValue, _key, meta) { scheduleExternalFlowRefresh(meta); });
    window.ExtensionStorage.subscribe(RUNNING_STORAGE_KEY, function (_newValue, _oldValue, _key, meta) { scheduleExternalFlowRefresh(meta); });
  } else if (globalThis.chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes || (!changes[STORAGE_KEY] && !changes[RUNNING_STORAGE_KEY])) return;
      scheduleExternalFlowRefresh({ local: false, area: area });
    });
  }

  window.__extDashboardShell.registerSection("fluxos", renderFluxosSection);
  window.__extDashboardShell.registerSection("funis", renderFunisSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
