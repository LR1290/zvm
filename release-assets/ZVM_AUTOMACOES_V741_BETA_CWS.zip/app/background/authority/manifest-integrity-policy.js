(function(root){
  "use strict";
  var TOP_LEVEL_BROWSER_MANAGED_FIELDS=Object.freeze(["key"]);
  var MANAGED_SET=new Set(TOP_LEVEL_BROWSER_MANAGED_FIELDS);
  function normalizeValue(value,depth){
    if(value===null||typeof value==="string"||typeof value==="boolean")return value;
    if(typeof value==="number"){
      if(!Number.isFinite(value))throw new Error("MANIFEST_CANONICAL_NUMBER_INVALID");
      return value;
    }
    if(Array.isArray(value))return value.map(function(item){return normalizeValue(item,depth+1);});
    if(value&&typeof value==="object"){
      var out={};
      Object.keys(value).sort(function(a,b){return a<b?-1:a>b?1:0;}).forEach(function(key){
        if(depth===0&&MANAGED_SET.has(key))return;
        var child=value[key];
        if(child===undefined)throw new Error("MANIFEST_CANONICAL_UNDEFINED");
        out[key]=normalizeValue(child,depth+1);
      });
      return out;
    }
    throw new Error("MANIFEST_CANONICAL_TYPE_INVALID");
  }
  function normalize(manifest){
    if(!manifest||typeof manifest!=="object"||Array.isArray(manifest))throw new Error("MANIFEST_CANONICAL_ROOT_INVALID");
    return normalizeValue(manifest,0);
  }
  function canonicalize(manifest){return JSON.stringify(normalize(manifest));}
  function canonicalBytes(manifest){return new TextEncoder().encode(canonicalize(manifest));}
  root.__extManifestIntegrityPolicy=Object.freeze({
    schema:1,
    mode:"manifest-json-v1",
    browserManagedTopLevelFields:TOP_LEVEL_BROWSER_MANAGED_FIELDS,
    normalize:normalize,
    canonicalize:canonicalize,
    canonicalBytes:canonicalBytes
  });
})(self);
