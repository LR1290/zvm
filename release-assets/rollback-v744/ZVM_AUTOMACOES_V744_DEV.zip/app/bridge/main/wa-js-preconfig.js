(function(){var c=window.WPPConfig&&typeof window.WPPConfig==="object"?window.WPPConfig:{};window.WPPConfig=Object.assign({},c,{linkPreviewApiServers:[],disableGoogleAnalytics:true});})();
