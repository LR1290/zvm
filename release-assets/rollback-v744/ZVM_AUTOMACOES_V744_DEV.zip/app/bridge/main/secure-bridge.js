;
try{
                                                                      
  
                                                                     
                                                                           
                                                                              
                                                                             
                                       
  
                                                                                       

(function () {
  "use strict";

  var __extExistingBridgeDescriptor = Object.getOwnPropertyDescriptor(window, "__extWppBridge");
  if (__extExistingBridgeDescriptor && __extExistingBridgeDescriptor.configurable === false && __extExistingBridgeDescriptor.writable === false && __extExistingBridgeDescriptor.value && __extExistingBridgeDescriptor.value.__extSecureBridgeV2 === true && Object.isFrozen(__extExistingBridgeDescriptor.value)) return;

  var RPC_CHANNEL = "WPP";
  var RPC_REQUEST_MODEL = "WPP";
  var RPC_RESPONSE_MODEL = "WPP-RESPONSE";
  var RPC_CHUNK_SIZE = 524288;
  var registry = Object.create(null);
  var adapters = Object.create(null);
  var subscribers = Object.create(null);
  var _eventsBound = false;
  var _fullReadyBound = false;

  function safeBoolCall(fn, ctx) {
    if (typeof fn !== "function") return null;
    try { return fn.call(ctx) === true; } catch (_) { return null; }
  }

  function hasSendSurface(wpp) {
    return !!(wpp && wpp.chat && typeof wpp.chat.sendTextMessage === "function" && typeof wpp.chat.sendFileMessage === "function");
  }

  function operationalState(wpp) {
    if (!wpp) return { ready:false, rawReady:false, graphReady:false, authenticated:null, mainReady:null, sendSurface:false, activeChat:false };
    var rawReady = wpp.isReady === true;
    var graphReady = rawReady;
    try {
      graphReady = graphReady || !!(wpp.loader && wpp.loader.isFullReady === true);
      graphReady = graphReady || !!(wpp.webpack && wpp.webpack.isFullReady === true);
    } catch (_) {}

    if (!graphReady) {
      return { ready:false, rawReady:rawReady, graphReady:false, authenticated:null, mainReady:null, sendSurface:false, activeChat:false };
    }

    var authenticated = safeBoolCall(wpp.conn && wpp.conn.isAuthenticated, wpp.conn);
    var mainReady = safeBoolCall(wpp.conn && wpp.conn.isMainReady, wpp.conn);
    var sendSurface = hasSendSurface(wpp);
    var activeChat = false;
    if (sendSurface && wpp.chat && typeof wpp.chat.getActiveChat === "function") {
      try { activeChat = !!wpp.chat.getActiveChat(); } catch (_) { activeChat = false; }
    }
    var ready = rawReady || graphReady || (sendSurface && authenticated === true) || (sendSurface && mainReady === true) || (sendSurface && activeChat);
    return { ready:!!ready, rawReady:rawReady, graphReady:graphReady, authenticated:authenticated, mainReady:mainReady, sendSurface:sendSurface, activeChat:activeChat };
  }

  function getRawWpp(required) {
    var wpp = window.WPP;
    if (required !== false && !operationalState(wpp).ready) {
      var err = new Error("WPP não está pronto");
      err.code = "WPP_NOT_READY";
      throw err;
    }
    return wpp || null;
  }

  function isReady() {
    return operationalState(getRawWpp(false)).ready;
  }

  function isFullReady() {
    var wpp = getRawWpp(false);
    if (!wpp) return false;
    if (wpp.loader && wpp.loader.isFullReady === true) return true;
    if (wpp.webpack && wpp.webpack.isFullReady === true) return true;
    return operationalState(wpp).ready;
  }

  function makeCorrelationId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return "ext-wpp:" + Date.now() + ":" + Math.random().toString(36).slice(2, 12);
  }


  function waitUntilReady(timeoutMs) {
    timeoutMs = Number(timeoutMs);
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) timeoutMs = 30000;
    if (isReady()) return Promise.resolve(true);
    return new Promise(function (resolve, reject) {
      var done = false;
      var started = Date.now();
      var wpp = getRawWpp(false);
      function finish(ok, error) {
        if (done) return;
        done = true;
        if (ok) { bindWppEvents(); resolve(true); }
        else reject(error || new Error("Timeout aguardando WPP"));
      }
      function check() {
        if (done) return;
        if (isReady()) return finish(true);
        if (Date.now() - started >= timeoutMs) {
          var err = new Error("Timeout aguardando WPP ficar pronto");
          err.code = "WPP_READY_TIMEOUT";
          return finish(false, err);
        }
        setTimeout(check, 200);
      }
      if (wpp && wpp.loader && typeof wpp.loader.onReady === "function") {
        try { wpp.loader.onReady(function () { if (isReady()) finish(true); }); } catch (e) {}
      }
      if (wpp && wpp.webpack && typeof wpp.webpack.onReady === "function") {
        try { wpp.webpack.onReady(function () { if (isReady()) finish(true); }); } catch (e2) {}
      }
      check();
    });
  }

  function waitUntilFullReady(timeoutMs) {
    timeoutMs = Number(timeoutMs);
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) timeoutMs = 45000;
    if (isFullReady()) return Promise.resolve(true);
    return waitUntilReady(timeoutMs).then(function () {
      return new Promise(function (resolve, reject) {
        var done = false;
        var started = Date.now();
        var wpp = getRawWpp();
        function finish(ok) {
          if (done) return;
          done = true;
          if (ok) resolve(true);
          else {
            var err = new Error("Timeout aguardando WPP full-ready");
            err.code = "WPP_FULL_READY_TIMEOUT";
            reject(err);
          }
        }
        if (wpp.loader && typeof wpp.loader.onFullReady === "function") {
          try { wpp.loader.onFullReady(function () { finish(true); }); } catch (e) {}
        }
        (function check() {
          if (done) return;
          if (isFullReady()) return finish(true);
          if (Date.now() - started >= timeoutMs) return finish(false);
          setTimeout(check, 250);
        })();
      });
    });
  }

  function getPath(root, path) {
    var parts = path.split(".");
    var owner = root;
    for (var i = 0; i < parts.length - 1; i++) {
      owner = owner && owner[parts[i]];
      if (!owner) break;
    }
    return { owner: owner, key: parts[parts.length - 1], value: owner && owner[parts[parts.length - 1]] };
  }

  function callWpp(path, args, required) {
    var wpp = getRawWpp(required !== false);
    if (!wpp) {
      var absent = new Error("WPP indisponível para " + path);
      absent.code = "WPP_UNAVAILABLE";
      throw absent;
    }
    var resolved = getPath(wpp, path);
    if (!resolved.owner || typeof resolved.value !== "function") {
      var err = new Error("WA-JS não expõe " + path);
      err.code = "WPP_METHOD_UNAVAILABLE";
      err.path = path;
      throw err;
    }
    return resolved.value.apply(resolved.owner, args || []);
  }

  function toSerializedId(value) {
    if (!value) return value;
    if (typeof value === "string") return value;
    if (value._serialized) return value._serialized;
    if (value.id && value.id._serialized) return value.id._serialized;
    if (typeof value.toString === "function") return value.toString();
    return String(value);
  }

  function normalizePhone(value) {
    return String(value == null ? "" : value).replace(/@[^\s]+$/, "").replace(/\D/g, "").slice(0, 20);
  }

  function widDto(value) {
    var serialized = toSerializedId(value);
    if (!serialized) return null;
    serialized = String(serialized);
    var at = serialized.lastIndexOf("@");
    var user = value && value.user != null ? String(value.user) : (at >= 0 ? serialized.slice(0, at) : normalizePhone(serialized));
    var server = value && value.server != null ? String(value.server) : (at >= 0 ? serialized.slice(at + 1) : "c.us");
    return { _serialized: serialized, user: user, server: server };
  }

  function contactDto(contact) {
    if (!contact || typeof contact !== "object") return contact || null;
    var id = widDto(contact.id || contact.wid || contact);
    return {
      id: id,
      name: contact.name || "",
      pushname: contact.pushname || "",
      formattedName: contact.formattedName || "",
      verifiedName: contact.verifiedName || "",
      notifyName: contact.notifyName || "",
      isMyContact: contact.isMyContact === true,
      isBusiness: contact.isBusiness === true,
      isEnterprise: contact.isEnterprise === true,
      isUser: contact.isUser === true,
      isGroup: contact.isGroup === true
    };
  }

  function chatDto(chat) {
    if (!chat || typeof chat !== "object") return chat || null;
    var contact = null;
    try { contact = contactDto(chat.contact); } catch (_) { contact = null; }
    return {
      id: widDto(chat.id || chat),
      name: chat.name || "",
      formattedTitle: chat.formattedTitle || "",
      unreadCount: Number(chat.unreadCount || 0),
      archive: chat.archive === true || chat.archived === true,
      isReadOnly: chat.isReadOnly === true,
      contact: contact
    };
  }

  function normalizeJid(value) {
    var serialized = toSerializedId(value);
    if (!serialized) return null;
    serialized = String(serialized);
    if (serialized.indexOf("@") >= 0) return serialized;
    var digits = normalizePhone(serialized);
    return digits ? digits + "@c.us" : null;
  }

  function payloadId(payload) {
    if (payload && typeof payload === "object" && !Array.isArray(payload)) return payload.id || payload.jid || payload.phone || payload.chatId || payload.contactId || payload.messageId;
    return payload;
  }

  function normalizeLabel(label) {
    if (!label) return label;
    return {
      id: label.id && (label.id._serialized || label.id) || label.id,
      name: label.name || "",
      color: label.color != null ? label.color : label.hexColor,
      count: label.count != null ? label.count : undefined
    };
  }

  function jsonSafe(value) {
    if (value === undefined) return null;
    var text;
    try { text = JSON.stringify(value); } catch (err) {
      var e = new Error("Resultado não serializável");
      e.code = "WPP_RESULT_NOT_SERIALIZABLE";
      throw e;
    }
    if (text === undefined) {
      var e2 = new Error("Resultado não serializável");
      e2.code = "WPP_RESULT_NOT_SERIALIZABLE";
      throw e2;
    }
    try { return JSON.parse(text); } catch (err2) { return value; }
  }

  function blobToBase64(value) {
    if (typeof value === "string") return Promise.resolve(value);
    if (!value) return Promise.resolve(value);
    if (typeof FileReader === "undefined" || typeof Blob === "undefined" || !(value instanceof Blob)) return Promise.resolve(value);
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(reader.error || new Error("Falha ao converter mídia")); };
      reader.readAsDataURL(value);
    });
  }

  function define(type, action, handler, dependency) {
    registry[type + "." + action] = { type: type, action: action, handler: handler, dependency: dependency || null };
  }


  function invoke(type, action, payload, meta) {
    var entry = registry[type + "." + action];
    if (!entry) {
      var hasType = Object.keys(registry).some(function (key) { return key.indexOf(type + ".") === 0; });
      var err = new Error(hasType ? ('Ação desconhecida: "' + action + '" para tipo "' + type + '"') : ('Tipo desconhecido: "' + type + '"'));
      err.code = hasType ? "WPP_UNKNOWN_ACTION" : "WPP_UNKNOWN_TYPE";
      return Promise.reject(err);
    }
    function run() {
      try { return Promise.resolve(entry.handler(payload, meta || {})); }
      catch (err2) { return Promise.reject(err2); }
    }
    return run().catch(function (err3) {
      var code = err3 && err3.code;
      if (type !== "Webpack" && (code === "WPP_NOT_READY" || code === "WPP_UNAVAILABLE")) {
        return waitUntilReady(45000).then(run);
      }
      throw err3;
    });
  }

  async function request(req) {
    req = req || {};
    var id = req.id || makeCorrelationId();
    var sender = req.sender || "extension";
    try {
      var result = await invoke(req.type, req.action, req.payload, { id: id, sender: sender });
      return { channel: RPC_CHANNEL, model: RPC_RESPONSE_MODEL, id: id, sender: sender, ok: true, result: jsonSafe(result), error: null };
    } catch (err) {
      var message = err && err.message ? err.message : String(err);
      return { channel: RPC_CHANNEL, model: RPC_RESPONSE_MODEL, id: id, sender: sender, ok: false, result: null, error: message, code: err && err.code || null };
    }
  }

  function capabilities() {
    var out = {};
    Object.keys(registry).sort().forEach(function (key) {
      var entry = registry[key], dependency = entry.dependency || null;
      out[key] = { available: !dependency || !!adapters[dependency], dependency: dependency };
    });
    return out;
  }


  function requireAdapter(name) {
    var adapter = adapters[name];
    if (!adapter) {
      var err = new Error("Dependência indisponível: " + name);
      err.code = "DEPENDENCY_UNAVAILABLE";
      err.dependency = name;
      throw err;
    }
    return adapter;
  }

                                                                     
  define("Chat", "sendTxt", function (p) {
    p = p || {};
    return callWpp("chat.sendTextMessage", [p.id, p.msg, { createChat: true, detectMentioned: true, mentionedList: p.mentionedList || undefined }]);
  });
  define("Chat", "sendTextReplay", function (p) {
    p = p || {};
    return callWpp("chat.sendTextMessage", [p.id, p.msg, { quotedMsg: p.replayID, createChat: true, detectMentioned: true }]);
  });
  define("Chat", "sendImage", function (p) {
    p = p || {};
    return callWpp("chat.sendFileMessage", [p.id, p.base64, { type: "image", caption: p.msg || undefined, mentionedList: p.mentionedList || undefined, isViewOnce: !!p.isViewOnce, isHD: true, mimetype: p.mimeType || undefined, filename: p.name || undefined }]);
  });
  define("Chat", "sendDoc", function (p) {
    p = p || {};
    return callWpp("chat.sendFileMessage", [p.id, p.base64, { type: "document", filename: p.name, mimetype: p.mimeType || undefined }]);
  });
  define("Chat", "sendVideo", function (p) {
    p = p || {};
    return callWpp("chat.sendFileMessage", [p.id, p.base64, { type: "video", caption: p.msg || undefined, mentionedList: p.mentionedList || undefined, isPtv: !!p.microVideo, isViewOnce: !!p.isViewOnce, mimetype: p.mimeType || undefined, filename: p.name || undefined }]);
  });
  define("Chat", "sendAudio", function (p) {
    p = p || {};
    return callWpp("chat.sendFileMessage", [p.id, p.base64, { type: "audio", isPtt: p.isPtt !== false, isViewOnce: !!p.isViewOnce, mimetype: p.mimeType || undefined, filename: p.name || undefined }]);
  });
  define("Chat", "sendContact", function (p) { p = p || {}; return callWpp("chat.sendVCardContactMessage", [p.id, { id: p.phone, name: p.name }, {}]); });
  define("Chat", "sendListMessage", function (p) { p = p || {}; return callWpp("chat.sendListMessage", [p.id, p.options]); });
  define("Chat", "sendPixKeyMessage", function (p) { p = p || {}; var rawType = String(p.keyType || "EVP").trim().toUpperCase(); var aliases = { TELEFONE:"PHONE", CELULAR:"PHONE", PHONE:"PHONE", CPF:"CPF", CNPJ:"CNPJ", EMAIL:"EMAIL", E_MAIL:"EMAIL", EVP:"EVP", ALEATORIA:"EVP", RANDOM:"EVP" }; var keyType = aliases[rawType] || "EVP"; return callWpp("chat.sendPixKeyMessage", [p.id, { keyType: keyType, name: p.name, key: p.key }, {}]); });
  define("Chat", "sendGroupInviteMessage", async function (p) {
    p = p || {};
    var code = await callWpp("group.getInviteCode", [p.groupID]);
    return callWpp("chat.sendGroupInviteMessage", [p.id, { groupId: p.groupID, inviteCode: code }]);
  });
  define("Chat", "linkPreview", function (p) {
    p = p || {};
    return callWpp("chat.sendTextMessage", [p.id, p.link, { linkPreview: { title: p.title, description: p.description, url: p.link }, createChat: true }]);
  });
  define("Chat", "sticker", function (p) { p = p || {}; return callWpp("chat.sendFileMessage", [p.id, p.base64, { type: "sticker" }]); });
  define("Chat", "requestPhoneNumber", function (p) { return callWpp("chat.requestPhoneNumber", [payloadId(p)]); });
  define("Chat", "arquivar", function (p) { return callWpp("chat.archive", [payloadId(p)]); });
  define("Chat", "desarquivar", function (p) { return callWpp("chat.unarchive", [payloadId(p)]); });
  define("Chat", "openChatBottom", function (p) { return callWpp("chat.openChatBottom", [payloadId(p)]); });
  define("Chat", "getActiveChat", function (mode) {
    var chat = callWpp("chat.getActiveChat", []);
    if (!chat) return null;
    var id = chat.id || chat;
    if (mode === "@" || mode && mode.mode === "serialized") return toSerializedId(id);
    if (mode && mode.mode === "user") { var wid = widDto(id); return wid && wid.user || null; }
    return chatDto(chat);
  });
  define("Chat", "List", async function (filter) {
    var opts = filter && typeof filter === "object" ? Object.assign({}, filter) : {};
    var type = typeof filter === "string" ? filter : opts.type;
    delete opts.type;
    var list = await callWpp("chat.list", [opts]);
    list = Array.isArray(list) ? list : [];
    if (type === "onlyUsers" || type === "1:1") return list.filter(function (c) { return !(c.id && typeof c.id.isGroup === "function" && c.id.isGroup()) && !c.archive; });
    if (type === "onlyGroups" || type === "getContatosGrupos") return list.filter(function (c) { return c.id && typeof c.id.isGroup === "function" && c.id.isGroup(); });
    if (type === "onlyCommunities") return list.filter(function (c) { return !!(c.groupMetadata && (c.groupMetadata.isParentGroup || c.groupMetadata.isCommunity)); });
    if (type === "nao-lido") return list.filter(function (c) { return Number(c.unreadCount) > 0; });
    return list;
  });
  define("Chat", "markIsComposing", function (p) { p = p || {}; return callWpp("chat.markIsComposing", [p.id, p.timer]); });
  define("Chat", "markIsRecording", function (p) { p = p || {}; return callWpp("chat.markIsRecording", [p.id, p.timer]); });
  define("Chat", "markIsPaused", function (p) { return callWpp("chat.markIsPaused", [payloadId(p)]); });
  define("Chat", "openChatFromUnread", function () { return callWpp("chat.openChatFromUnread", []); });
  define("Chat", "markIsRead", function (p) { return callWpp("chat.markIsRead", [payloadId(p)]); });
  define("Chat", "markIsUnread", function (p) { return callWpp("chat.markIsUnread", [payloadId(p)]); });
  define("Chat", "getMessages", async function (p) {
    p = p || {};
    if (!p.disabledAwaitHydrate && getPath(getRawWpp(), "chat.find").value) { try { await callWpp("chat.find", [p.id]); } catch (e) {} }
    return callWpp("chat.getMessages", [p.id, { count: p.quant == null ? 50 : p.quant }]);
  });
  define("Chat", "getAllUnreadMessages", function (p) { p = p || {}; return callWpp("chat.getMessages", [p.id, { count: -1, onlyUnread: true }]); });
  define("Chat", "downloadMedia", async function (p) { return blobToBase64(await callWpp("chat.downloadMedia", [payloadId(p)])); });
  define("Chat", "downloadMediaResolved", async function (p) {
    p = p && typeof p === "object" ? p : { messageId: p };
    function text(value) { return String(value == null ? "" : value).trim(); }
    function decode(value) { value = text(value); if (!value) return ""; try { return decodeURIComponent(value); } catch (_) { return value; } }
    function keyString(value) {
      if (!value) return "";
      if (typeof value === "string") return value;
      if (value._serialized) return String(value._serialized);
      if (value.serialized) return String(value.serialized);
      var remote = value.remote || value.to || value.from || null;
      var remoteId = toSerializedId(remote);
      var token = value.id || value.messageId || value.stanzaId || "";
      if (remoteId && token && typeof value.fromMe !== "undefined") return String(value.fromMe === true ? "true" : "false") + "_" + String(remoteId) + "_" + String(token);
      try { var out = value.toString && value.toString(); if (out && out !== "[object Object]") return String(out); } catch (_) {}
      return "";
    }
    function tokenOf(value) {
      value = text(value);
      var match = value.match(/^(true|false)_(.+@[^_]+)_(.+)$/);
      return match && match[3] ? match[3] : value;
    }
    function fromMeOf(value) {
      var match = text(value).match(/^(true|false)_/);
      return match ? match[1] === "true" : null;
    }
    function typeOf(row) { return String(row && (row.type || row.typeName || row.msgType) || "").toLowerCase(); }
    function isAudio(row) {
      var type = typeOf(row), mime = String(row && (row.mimetype || row.mimeType || row.mediaData && row.mediaData.mimetype) || "").toLowerCase();
      return type === "ptt" || type === "audio" || type === "voice" || type === "voice_note" || type === "voicenote" || mime.indexOf("audio/") === 0 || row && (row.isPtt === true || row.isVoiceMessage === true);
    }
    async function forceBlob(value, mimeType) {
      if (!value) return null;
      var mime = String(mimeType || "application/octet-stream");
      if (typeof Blob !== "undefined" && value instanceof Blob) return value;
      try {
        if (typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer) return new Blob([value], { type: mime });
        if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView && ArrayBuffer.isView(value)) {
          var start = value.byteOffset || 0, end = start + value.byteLength;
          return new Blob([value.buffer.slice(start, end)], { type: mime });
        }
      } catch (_) {}
      try {
        if (typeof value.forceToBlob === "function") {
          var forced = await value.forceToBlob();
          var forcedBlob = await forceBlob(forced, mime);
          if (forcedBlob) return forcedBlob;
        }
      } catch (_) {}
      try {
        if (value.mediaBlob) {
          var nested = await forceBlob(value.mediaBlob, mime);
          if (nested) return nested;
        }
      } catch (_) {}
      try {
        if (value.blob) {
          var nestedBlob = await forceBlob(value.blob, mime);
          if (nestedBlob) return nestedBlob;
        }
      } catch (_) {}
      return null;
    }
    async function cachedBlob(row) {
      if (!row) return null;
      var mediaData = row.mediaData || row.__x_mediaData || null;
      if (!mediaData) return null;
      var mime = String(mediaData.mimetype || mediaData.mimeType || row.mimetype || row.mimeType || "application/octet-stream");
      var direct = await forceBlob(mediaData.mediaBlob || mediaData, mime);
      if (direct) return direct;
      var filehash = mediaData.filehash || mediaData.fileHash || row.filehash || row.fileHash || "";
      if (!filehash) return null;
      var raw = getRawWpp(), wa = raw && raw.whatsapp || {};
      try {
        if (wa.LruMediaStore && typeof wa.LruMediaStore.get === "function") {
          var lru = await wa.LruMediaStore.get(filehash);
          var lruBlob = await forceBlob(lru, mime);
          if (lruBlob) return lruBlob;
        }
      } catch (_) {}
      try {
        if (wa.MediaBlobCache && typeof wa.MediaBlobCache.get === "function") {
          var has = typeof wa.MediaBlobCache.has === "function" ? await wa.MediaBlobCache.has(filehash) : true;
          if (has) {
            var cached = await wa.MediaBlobCache.get(filehash);
            var cacheBlob = await forceBlob(cached, mime);
            if (cacheBlob) return cacheBlob;
          }
        }
      } catch (_) {}
      return null;
    }
    async function downloadLiveRow(row) {
      if (!row) return null;
      var blob = await cachedBlob(row);
      if (blob) return blob;
      try {
        if (typeof row.downloadMedia === "function") {
          var downloaded = await row.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
          var returnedBlob = await forceBlob(downloaded);
          if (returnedBlob) return returnedBlob;
          blob = await cachedBlob(row);
          if (blob) return blob;
        }
      } catch (_) {}
      return null;
    }
    var wanted = [], rawCandidates = [p.messageId, p.domId, p.id, p.messageKey];
    for (var c = 0; c < rawCandidates.length; c++) {
      var one = text(rawCandidates[c]), two = decode(one);
      if (one && wanted.indexOf(one) < 0) wanted.push(one);
      if (two && wanted.indexOf(two) < 0) wanted.push(two);
    }
    var active = null, chatId = text(p.chatId);
    try { active = await callWpp("chat.getActiveChat", []); } catch (_) {}
    if (!chatId) chatId = text(toSerializedId(active && (active.id || active)));
    var tokens = wanted.map(tokenOf).filter(Boolean), directions = wanted.map(fromMeOf).filter(function(v){ return v !== null; });
    var attempts = [];
    function addAttempt(value) { value = text(value); if (value && attempts.indexOf(value) < 0) attempts.push(value); }
    wanted.forEach(addAttempt);
    if (chatId) {
      for (var ti = 0; ti < tokens.length; ti++) {
        if (directions.length) for (var di = 0; di < directions.length; di++) addAttempt(String(directions[di] ? "true" : "false") + "_" + chatId + "_" + tokens[ti]);
        else { addAttempt("false_" + chatId + "_" + tokens[ti]); addAttempt("true_" + chatId + "_" + tokens[ti]); }
      }
    }
    var liveRows = [];
    if (chatId) {
      try {
        if (getPath(getRawWpp(), "chat.find").value) await callWpp("chat.find", [chatId]);
      } catch (_) {}
      try {
        var rows = await callWpp("chat.getMessages", [chatId, { count: 320, downloadMedia: false }]);
        if (rows && Array.isArray(rows.messages)) rows = rows.messages;
        if (Array.isArray(rows)) liveRows = rows;
      } catch (_) {}
    }
    var resolved = [];
    function addResolved(row) { if (row && resolved.indexOf(row) < 0) resolved.push(row); }
    for (var wi = 0; wi < wanted.length; wi++) {
      try { var direct = await callWpp("chat.getMessageById", [wanted[wi]]); if (direct) addResolved(direct); } catch (_) {}
    }
    for (var ri = liveRows.length - 1; ri >= 0; ri--) {
      var row = liveRows[ri], rowKey = keyString(row && (row.id || row.key || row.messageId)), rowToken = tokenOf(rowKey || row && row.id && (row.id.id || row.id.messageId));
      if (!rowToken || tokens.indexOf(rowToken) < 0) continue;
      if (!isAudio(row)) continue;
      addResolved(row);
      addAttempt(rowKey);
    }
    var lastError = null;
    for (var rr = 0; rr < resolved.length; rr++) {
      var resolvedRow = resolved[rr], resolvedKey = keyString(resolvedRow && (resolvedRow.id || resolvedRow.key || resolvedRow.messageId));
      addAttempt(resolvedKey);
      try {
        var liveMedia = await downloadLiveRow(resolvedRow);
        if (liveMedia) return blobToBase64(liveMedia);
      } catch (liveErr) { lastError = liveErr; }
    }
    for (var ai = 0; ai < attempts.length; ai++) {
      try {
        var media = await callWpp("chat.downloadMedia", [attempts[ai]]);
        if (media) return blobToBase64(media);
      } catch (err) { lastError = err; }
    }
    if (chatId) {
      try {
        var refreshed = await callWpp("chat.getMessages", [chatId, { count: 320, downloadMedia: false }]);
        if (refreshed && Array.isArray(refreshed.messages)) refreshed = refreshed.messages;
        if (Array.isArray(refreshed)) {
          for (var fi = refreshed.length - 1; fi >= 0; fi--) {
            var freshRow = refreshed[fi], freshKey = keyString(freshRow && (freshRow.id || freshRow.key || freshRow.messageId)), freshToken = tokenOf(freshKey || freshRow && freshRow.id && (freshRow.id.id || freshRow.id.messageId));
            if (!freshToken || tokens.indexOf(freshToken) < 0 || !isAudio(freshRow)) continue;
            try {
              var freshBlob = await downloadLiveRow(freshRow);
              if (freshBlob) return blobToBase64(freshBlob);
            } catch (freshErr) { lastError = freshErr; }
          }
        }
      } catch (refreshErr) { lastError = lastError || refreshErr; }
    }
    var fail = new Error(lastError && lastError.message ? lastError.message : "Não foi possível resolver a mídia desta mensagem de áudio.");
    fail.code = "WPP_MEDIA_RESOLVE_FAILED";
    throw fail;
  });
  define("Chat", "get", async function (p) {
    var id = payloadId(p), wpp = getRawWpp();
    var chat = wpp.chat && typeof wpp.chat.get === "function" ? callWpp("chat.get", [id]) : await callWpp("chat.find", [id]);
    return chatDto(chat);
  });
  define("Chat", "getMessageById", function (p) { return callWpp("chat.getMessageById", [payloadId(p)]); });
  define("Chat", "setInputText", function (p) { p = p || {}; return callWpp("chat.setInputText", [p.txt, p.id]); });

                                                                         
  define("Group", "getAllGroups", function () { return callWpp("group.getAllGroups", []); });
  define("Group", "getGroupsIAmAdmin", async function () {
    var groups = await callWpp("group.getAllGroups", []);
    var wpp = getRawWpp();
    if (!wpp.group || typeof wpp.group.iAmAdmin !== "function") return [];
    var out = [];
    for (var i = 0; i < groups.length; i++) {
      try { if (await wpp.group.iAmAdmin(groups[i].id || groups[i])) out.push(groups[i]); } catch (e) {}
    }
    return out;
  });
  define("Group", "getParticipants", function (p) { return callWpp("group.getParticipants", [payloadId(p)]); });
  define("Conn", "getMyUserId", function () { return callWpp("conn.getMyUserId", []); });
  define("Conn", "getMyUserLid", function () { return callWpp("conn.getMyUserLid", []); });
  define("Conn", "getMyDeviceId", function () { return callWpp("conn.getMyDeviceId", []); });
  define("Conn", "joinWebBeta", function (p) { var enabled = typeof p === "boolean" ? p : (p && typeof p.enabled === "boolean" ? p.enabled : true); return callWpp("conn.joinWebBeta", [enabled]); });
  define("Conn", "waVersion", function () {
    var wpp = getRawWpp();
    if (wpp.conn && typeof wpp.conn.getWAVersion === "function") return wpp.conn.getWAVersion();
    if (wpp.whatsapp && wpp.whatsapp.Debug && wpp.whatsapp.Debug.VERSION) return wpp.whatsapp.Debug.VERSION;
    return null;
  });

                                                                        
  define("Contact", "List", async function (filter) {
    var opts = filter && typeof filter === "object" ? Object.assign({}, filter) : {};
    var contacts = await callWpp("contact.list", [opts]);
    return Array.isArray(contacts) ? contacts.map(contactDto).filter(Boolean) : [];
  });

                                                                               
                                                                              
                                                                               
                                                                            
                                                                               
  define("Contact", "ListForCrm", async function () {
    var chats = await callWpp("chat.list", [{}]);
    chats = Array.isArray(chats) ? chats : [];
    var seen = Object.create(null), out = [];
    function idServer(id, serialized) {
      if (id && id.server) return String(id.server);
      var pos = String(serialized || "").indexOf("@");
      return pos >= 0 ? String(serialized).slice(pos + 1) : "";
    }
    function idUserPlain(id, serialized) {
      if (id && id.user != null) return String(id.user);
      var text = String(serialized || "");
      var pos = text.indexOf("@");
      return pos >= 0 ? text.slice(0, pos) : text.replace(/\D/g, "");
    }
    for (var i = 0; i < chats.length; i++) {
      var chat = chats[i];
      if (!chat || !chat.id) continue;
      var id = chat.id, serialized = toSerializedId(id), server = idServer(id, serialized);
      if (!serialized || server === "g.us" || server === "broadcast" || server === "newsletter") continue;
      var phoneNumber = null;
      if (server === "lid" || /@lid$/i.test(serialized)) {
        try {
          var lidEntry = await callWpp("contact.getPnLidEntry", [serialized]);
          var phoneWid = lidEntry && lidEntry.phoneNumber;
          phoneNumber = phoneWid && (phoneWid.id || phoneWid.user) || idUserPlain(phoneWid, toSerializedId(phoneWid)) || null;
        } catch (_) { phoneNumber = null; }
      } else {
        phoneNumber = idUserPlain(id, serialized) || null;
      }
      phoneNumber = String(phoneNumber || "").replace(/\D/g, "");
      if (!phoneNumber) continue;
      if (seen[phoneNumber]) continue;
      seen[phoneNumber] = true;

      var contact = null;
      try { contact = chat.contact || null; } catch (_) { contact = null; }
      if (!contact) { try { contact = await callWpp("contact.get", [serialized]); } catch (_) { contact = null; } }
      var name = "";
      try {
        name = contact && (contact.name || contact.verifiedName || contact.pushname || contact.formattedName || contact.notifyName) ||
          chat.name || chat.formattedTitle || chat.formattedName || chat.pushname || "";
      } catch (_) { name = ""; }
                                                                            
      if (!name) {
        try {
          var hydrated = await callWpp("contact.get", [serialized]);
          name = hydrated && (hydrated.name || hydrated.verifiedName || hydrated.pushname || hydrated.formattedName || hydrated.notifyName) || "";
        } catch (_) {}
      }
      out.push({ idStr: serialized, name: String(name || ""), phoneNumber: phoneNumber == null ? null : String(phoneNumber) });
    }
    return out;
  });
                                                                         
                                                                             
                                                                              
                                                                  
  define("Contact", "ListPlain", async function () {
    var contacts = await callWpp("contact.list", [{}]);
    contacts = Array.isArray(contacts) ? contacts : [];
    var seen = Object.create(null), out = [];
    for (var i = 0; i < contacts.length; i++) {
      var contact = contacts[i];
      if (!contact || !contact.id || contact.isMyContact === false) continue;
      var serialized = toSerializedId(contact.id);
      var server = contact.id.server || (serialized.indexOf("@") >= 0 ? serialized.split("@").pop() : "");
      if (!serialized || server === "g.us" || server === "broadcast" || server === "newsletter") continue;
      var phoneNumber = contact.id.user != null ? String(contact.id.user) : null;
      if (server === "lid" || /@lid$/i.test(serialized)) {
        try {
          var lidEntry = await callWpp("contact.getPnLidEntry", [serialized]);
          var phoneWid = lidEntry && lidEntry.phoneNumber;
          phoneNumber = phoneWid && (phoneWid.user || phoneWid.id) || null;
        } catch (_) { phoneNumber = null; }
      }
      var key = phoneNumber || serialized;if(seen[key])continue;seen[key]=true;
      var name = "";
      try { name = contact.name || contact.verifiedName || contact.pushname || contact.formattedName || contact.notifyName || ""; } catch (_) {}
      out.push({ idStr: serialized, name: String(name || ""), phoneNumber: phoneNumber == null ? null : String(phoneNumber) });
    }
    return out;
  });
  define("Contact", "getProfilePictureUrl", function (p) { return callWpp("contact.getProfilePictureUrl", [payloadId(p)]); });
  define("Contact", "queryExists", function (p) { return callWpp("contact.queryExists", [payloadId(p)]); });
  define("Contact", "getBusinessProfile", function (p) { return callWpp("contact.getBusinessProfile", [payloadId(p)]); });
  define("Contact", "save", function (p) { p = p || {}; return callWpp("contact.save", [p.contactId, p.name, p.options || {}]); });
  define("Contact", "remove", function (p) { return callWpp("contact.remove", [payloadId(p)]); });
  define("Contact", "get", function (p) { return contactDto(callWpp("contact.get", [payloadId(p)])); });
  define("Contact", "getPnLidEntry", function (p) { return callWpp("contact.getPnLidEntry", [payloadId(p)]); });

                                                                         
  function chatIds(list) { return (Array.isArray(list) ? list : []).map(function(c){ return toSerializedId(c && (c.id || c)); }).filter(Boolean); }
  async function setCustomChatList(filterFn, data, listOptions) {
    var list = await callWpp("chat.list", [listOptions || data && data.options || {}]);
    if (filterFn) list = list.filter(filterFn);
    var ids = chatIds(list);
    await callWpp("chat.setChatList", ["custom", ids]);
    return ids;
  }
  define("ListChat", "tudo", function () { return callWpp("chat.setChatList", ["all"]); });
  define("ListChat", "grupos", function () { return callWpp("chat.setChatList", ["group"]); });
  define("ListChat", "nao-lido", function () { return callWpp("chat.setChatList", ["unread"]); });
  define("ListChat", "1:1", function (p) { return setCustomChatList(null, p, { onlyUsers:true, onlyArchived:false }); });
  define("ListChat", "trasferencias", function (p) { var ids = new Set((p && p.ids || []).map(String)); return setCustomChatList(function (c) { return ids.has(toSerializedId(c.id)); }, p); });
  define("ListChat", "UserTabs", function (p) { p=p||{}; var ids=(p.ids||p.chatIds||[]).map(String).filter(Boolean); return callWpp("chat.setChatList", ["custom", ids]); });
  define("ListChat", "UserLabels", function (p) { p = p || {}; var labels = p.labelIds || p.labels || []; return callWpp("chat.setChatList", ["labels", labels]); });
  define("ListChat", "custom", async function (p) { p = p || {}; var ids = Array.isArray(p.ids || p.chatIds) ? (p.ids || p.chatIds).map(String).filter(Boolean) : null; if (!ids) { var list = await callWpp("chat.list", [p.options || p]); ids = chatIds(list); } return callWpp("chat.setChatList", ["custom", ids]); });

                                                                         
  define("Profile", "isBusiness", function () { return callWpp("profile.isBusiness", []); });
  define("Profile", "getMyProfileName", function () { return callWpp("profile.getMyProfileName", []); });
  define("Status", "sendTextStatus", function (p) { p = p || {}; return callWpp("status.sendTextStatus", [p.texto, { backgroundColor: p.color }]); });
  define("Status", "sendVideoStatus", function (p) { p = p || {}; return callWpp("status.sendVideoStatus", [p.base64]); });
  define("Status", "sendImageStatus", function (p) { p = p || {}; return callWpp("status.sendImageStatus", [p.base64]); });
  define("Status", "updateParticipants", function (p) {
    p = p || {};
    var ids = Array.isArray(p.ids) ? p.ids.filter(function (id) { return typeof id === "string" && /@(?:c\.us|lid)$/i.test(id); }) : [];
    return callWpp("status.updateParticipants", [ids]);
  });
  define("Labels", "getAllLabels", async function () { var labels = await callWpp("labels.getAllLabels", []); return (labels || []).map(normalizeLabel); });
  define("Labels", "getLabelById", async function (p) { return normalizeLabel(await callWpp("labels.getLabelById", [payloadId(p)])); });
  define("Labels", "addOrRemoveLabels", function (p) { p = p || {}; return callWpp("labels.addOrRemoveLabels", [p.id, p.label || p.labels]); });
  define("Labels", "editLabel", function (p) { p = p || {}; return callWpp("labels.editLabel", [p.id, p.options || {}]); });
  define("Labels", "deleteLabel", function (p) { return callWpp("labels.deleteLabel", [payloadId(p)]); });

                                                                         
  define("Utils", "contatoInit", async function (list) {
    list = Array.isArray(list) ? list : [];
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var item = Object.assign({}, list[i]);
      try {
        var c = await callWpp("contact.get", [item.id]);
        if (c && item.name && !c.name) c.name = item.name;
        item.contact = c || null;
      } catch (e) { item.contact = null; }
      out.push(item);
    }
    return out;
  });
  define("Utils", "contatoSave", async function (p) { p = p || {}; var c = await callWpp("contact.get", [p.id]); if (c) c.name = p.name; return c; });
  define("Utils", "listGroupParticipants", async function () {
    var groups = await callWpp("group.getAllGroups", []), out = [];
    for (var i = 0; i < groups.length; i++) {
      var gid = toSerializedId(groups[i].id || groups[i]);
      var participants = [];
      try { participants = await callWpp("group.getParticipants", [gid]); } catch (e) {}
      out.push({ group: groups[i], participants: participants });
    }
    return out;
  });
  define("Utils", "get-card", async function (p) {
    var id = payloadId(p), contact = await callWpp("contact.get", [id]), avatar = null, business = null;
    try { avatar = await callWpp("contact.getProfilePictureUrl", [id]); } catch (e) {}
    try { business = await callWpp("contact.getBusinessProfile", [id]); } catch (e2) {}
    return { id: id, contact: contact || null, avatar: avatar || null, businessProfile: business || null };
  });
  define("Utils", "getContato", async function (p) {
    var id = payloadId(p), card = await invoke("Utils", "get-card", id), chat = null;
    try { chat = await callWpp("chat.find", [id]); } catch (e) {}
    return { card: card, lastMessage: chat && chat.lastMessage || null, unread: chat && chat.unreadCount || 0, chat: chat };
  });
  define("Utils", "get-crmContatos", async function (list) {
    list = Array.isArray(list) ? list : [];
    var labels = await invoke("Labels", "getAllLabels", null).catch(function () { return []; });
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var item = Object.assign({}, list[i]);
      var id = item.id || item.chatId || item.phoneNumber;
      try {
        var c = await callWpp("contact.get", [id]);
        item.name = item.name || c && (c.name || c.pushname || c.formattedName) || "";
      } catch (e) {}
      item.allLabels = labels;
      out.push(item);
    }
    return out;
  });

                                                                        
  define("Webpack", "isReady", function () { return isReady(); });
  define("Webpack", "isFullReady", function () { return isFullReady(); });
  define("Webpack", "probe", function () {
    var wpp = getRawWpp(false);
    function has(path) { try { return typeof getPath(wpp, path).value === "function"; } catch (_) { return false; } }
    var version = null;
    var state = operationalState(wpp);
    try {
      if (wpp && wpp.conn && typeof wpp.conn.getWAVersion === "function") version = wpp.conn.getWAVersion();
      else if (wpp && wpp.whatsapp && wpp.whatsapp.Debug && wpp.whatsapp.Debug.VERSION) version = wpp.whatsapp.Debug.VERSION;
    } catch (_) {}
    return {
      ready: state.ready,
      rawReady: state.rawReady,
      graphReady: state.graphReady,
      authenticated: state.authenticated,
      mainReady: state.mainReady,
      sendSurface: state.sendSurface,
      activeChat: state.activeChat,
      fullReady: isFullReady(),
      waVersion: version,
      commands: {
        sendText: has("chat.sendTextMessage"),
        sendFile: has("chat.sendFileMessage"),
        sendContact: has("chat.sendVCardContactMessage"),
        sendList: has("chat.sendListMessage"),
        sendPix: has("chat.sendPixKeyMessage"),
        sendGroupInvite: has("chat.sendGroupInviteMessage") && has("group.getInviteCode"),
        statusImage: has("status.sendImageStatus"),
        statusVideo: has("status.sendVideoStatus"),
        statusText: has("status.sendTextStatus")
      }
    };
  });
  define("BlockList", "blockContact", function (p) { return callWpp("blocklist.blockContact", [payloadId(p)]); });
  define("BlockList", "unblockContact", function (p) { return callWpp("blocklist.unblockContact", [payloadId(p)]); });

                                                                         
  define("Functions", "FixChats", function (p) {
    p = p || {};
    var id = p.pin || p.id;
    var action = String(p.action || "").toLowerCase();
    return action === "unpin" || action === "remove" || action === "0" ? callWpp("chat.unpin", [id]) : callWpp("chat.pin", [id]);
  }, "substitui mutação chat.pin por API pública pin/unpin");
  define("Functions", "sendTextChat", function (p) { var a = requireAdapter("DomMessageAdapter"); return a.sendTextChat(p || {}); }, "DomMessageAdapter");
  define("Functions", "downloadMediaByActiveChat", function (p) { var a = requireAdapter("DomMessageAdapter"); return a.downloadMediaByActiveChat(p); }, "DomMessageAdapter");
  define("Functions", "getMessageByDomId", function (p) { var a = requireAdapter("DomMessageAdapter"); return a.getMessageByDomId(p); }, "DomMessageAdapter");

                                                                        
  define("DomSelector", "set", function (p) { var a = requireAdapter("DomSelector"); return a.set(p); }, "DomAdapter/RemoteConfig");
  define("IA", "text", function (p) { var a = requireAdapter("IA"); return a.text(p); }, "IA WhatsApp-agent adapter");

                                                                         
  define("Whatsapp", "theme", function (theme) {
    theme = typeof theme === "object" && theme ? theme.theme : theme;
    theme = theme === "dark" ? "dark" : "light";
    if (document.documentElement) document.documentElement.setAttribute("data-ext-wa-theme", theme);
    if (document.body) document.body.setAttribute("data-ext-wa-theme", theme);
    return theme;
  });
  define("Whatsapp", "getBrowserID", function () { return callWpp("whatsapp.Browser.id", []); });
  define("Whatsapp", "version", async function () {
    var whatsapp = await invoke("Conn", "waVersion", null).catch(function () { return null; });
    return { whatsapp: whatsapp, domSelector: adapters.DomSelector && adapters.DomSelector.version || null, runtimeBuild: "secure-bridge-v1" };
  });
  define("Whatsapp", "getUserContact", async function (p) {
    var id = payloadId(p), serialized = toSerializedId(id);
    if (serialized && serialized.indexOf("@lid") >= 0) {
      try {
        var phone = await callWpp("whatsapp.ApiContact.getPhoneNumber", [serialized]);
        if (phone) return toSerializedId(phone);
      } catch (e) {
        try {
          var entry = await callWpp("contact.getPnLidEntry", [serialized]);
          if (entry && entry.phoneNumber) return toSerializedId(entry.phoneNumber);
        } catch (e2) {}
      }
    }
    var user = serialized ? serialized.split("@")[0] : String(id || "").replace(/\D/g, "");
    return user ? user + "@c.us" : null;
  });

                                                                        
  function emit(eventName, payload) {
    var list = subscribers[eventName] ? subscribers[eventName].slice() : [];
    for (var i = 0; i < list.length; i++) {
      try { list[i](payload); } catch (err) { }
    }
  }

  function on(eventName, handler) {
    if (!subscribers[eventName]) subscribers[eventName] = [];
    subscribers[eventName].push(handler);
    return function () {
      var list = subscribers[eventName] || [];
      var idx = list.indexOf(handler);
      if (idx >= 0) list.splice(idx, 1);
    };
  }

  function normalizeEvent(eventName, data) {
    if (eventName === "chat.new_message") {
      var id = data && data.id;
      return { data: data, msgID: toSerializedId(id), author: toSerializedId(data && (data.author || data.from)) };
    }
    if (eventName === "chat.active_chat") return chatDto(data);
    if (eventName === "chat.presence_change") return { data: data };
    return data;
  }

  function bindWppEvents() {
    if (_eventsBound || !isReady()) return;
    var wpp = getRawWpp();
    _eventsBound = true;
    if (typeof wpp.on === "function") {
      ["chat.new_message", "chat.active_chat", "chat.presence_change", "conn.stream_info_changed"].forEach(function (name) {
        try { wpp.on(name, function (data) { emit(name, normalizeEvent(name, data)); }); } catch (e) {}
      });
      try {
        wpp.on("chat.update_label", async function (data) {
          var labels = [];
          try { labels = await invoke("Labels", "getAllLabels", null); } catch (e) {}
          emit("chat.update_label", { data: data, all_labels: labels });
        });
      } catch (e2) {}
    }
    if (!_fullReadyBound && wpp.loader && typeof wpp.loader.onFullReady === "function") {
      _fullReadyBound = true;
      try { wpp.loader.onFullReady(function () { emit("webpack.full_ready", { ready: true }); }); } catch (e3) {}
    } else if (!_fullReadyBound && wpp.webpack && typeof wpp.webpack.onReady === "function") {
      _fullReadyBound = true;
      try { wpp.webpack.onReady(function () { emit("webpack.full_ready", { ready: true }); }); } catch (e4) {}
    }
  }

                                                                           
                                                                           
                                                                          
                                                                             
                                                                  

                                                                            
                                                                                 
  var bridge = {
    __extSecureBridgeV2: true,
    version: "1.1.0-secure",
    isReady: isReady,
    isFullReady: isFullReady,
    waitUntilReady: waitUntilReady,
    waitUntilFullReady: waitUntilFullReady,
    invoke: invoke,
    request: request,
    capabilities: capabilities,
    normalize: Object.freeze({ phone: normalizePhone, jid: normalizeJid }),
    on: on,
    events: Object.freeze(["chat.new_message", "chat.active_chat", "webpack.full_ready", "chat.presence_change", "chat.update_label", "conn.stream_info_changed"]),
    constants: Object.freeze({ channel: RPC_CHANNEL, requestModel: RPC_REQUEST_MODEL, responseModel: RPC_RESPONSE_MODEL, chunkSize: RPC_CHUNK_SIZE })
  };
  Object.freeze(bridge);

  var __extBridgeDescriptor = Object.getOwnPropertyDescriptor(window, "__extWppBridge");
  if (__extBridgeDescriptor && __extBridgeDescriptor.configurable === false && __extBridgeDescriptor.value !== bridge) throw new Error("EXTAPP_WPP_BRIDGE_SLOT_LOCKED");
  Object.defineProperty(window, "__extWppBridge", { value: bridge, writable: false, configurable: false, enumerable: false });
  try { window.dispatchEvent(new CustomEvent("ext:wpp-bridge-ready", { detail: { version: bridge.version } })); } catch (_) {}

                                                                             
                                                                              
  var _extuiBootReadyHooksBound = false;
  var _extuiBootWakeBound = false;
  var _extuiBootRetryTimer = null;
  var _extuiBootAttempts = 0;
  function extBootBindWake() {
    if (_extuiBootWakeBound) return;
    _extuiBootWakeBound = true;
    var wake = function () {
      if (_eventsBound) return;
      if (document.visibilityState === "hidden") return;
      _extuiBootAttempts = 0;
      bootBind();
    };
    window.addEventListener("focus", wake);
    document.addEventListener("visibilitychange", wake);
    document.addEventListener("wppconnect_ready", wake);
  }
  function bootBind() {
    if (_eventsBound) { if (_extuiBootRetryTimer) clearTimeout(_extuiBootRetryTimer); _extuiBootRetryTimer = null; return; }
    if (isReady()) { bindWppEvents(); return; }
    var wpp = getRawWpp(false);
    if (!_extuiBootReadyHooksBound && wpp) {
      _extuiBootReadyHooksBound = true;
      if (wpp.loader && typeof wpp.loader.onReady === "function") {
        try { wpp.loader.onReady(function () { if (isReady()) bindWppEvents(); else bootBind(); }); } catch (e) {}
      }
      if (wpp.webpack && typeof wpp.webpack.onReady === "function") {
        try { wpp.webpack.onReady(function () { if (isReady()) bindWppEvents(); else bootBind(); }); } catch (e2) {}
      }
    }
    extBootBindWake();
    if (_extuiBootRetryTimer || _extuiBootAttempts >= 64) return;
    var attempt = _extuiBootAttempts++;
    var delay = attempt < 4 ? 140 : (attempt < 12 ? 320 : (attempt < 28 ? 700 : 1200));
    _extuiBootRetryTimer = setTimeout(function () { _extuiBootRetryTimer = null; bootBind(); }, delay);
  }
  bootBind();
})();
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
