(function () {
  "use strict";

  var OPTIONS_KEY = "EXTUI:extappOptionsStore";
                                                                    
                                         
  var ICON_SUN = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>';
  var ICON_MOON = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>';

  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      chrome.storage.local.get(key, function (res) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        resolve(res ? res[key] : undefined);
      });
    });
  }
  function storageSet(key, value) {
    return new Promise(function (resolve, reject) {
      var obj = {}; obj[key] = value;
      chrome.storage.local.set(obj, function () {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        resolve();
      });
    });
  }
  async function loadOptions() {
    var raw = await storageGet(OPTIONS_KEY);
    return raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : { theme: "dark" };
  }
  function showStatus(message) {
    var statusEl = document.getElementById("extuipStatus");
    statusEl.textContent = String(message || "Não foi possível concluir a ação.");
    statusEl.classList.add("extuiShow");
  }

                                                                         
                                                                        
                                                                          
                                                    
  document.getElementById("extuipVersion").textContent = (chrome.runtime.getManifest().version) || "-";

  var themeBtn = document.getElementById("extuipThemeBtn");
  var themeIcon = document.getElementById("extuipThemeIcon");
  var logoImg = document.getElementById("extuipLogo");
  function applyAccessibility(opts) {
    opts = opts || {};
    var scale = Math.max(100, Math.min(200, Math.round(Number(opts.accessibilityTextScale) || 110)));
    var ratio = scale / 100;
    var enhanced = opts.accessibilityContrast !== "standard";
    var colorAssist = opts.accessibilityColorAssist !== false;
    var el = document.documentElement;
    el.setAttribute("data-extui-a11y-text-scale", String(scale));
    el.setAttribute("data-extui-a11y-contrast", enhanced ? "enhanced" : "standard");
    el.setAttribute("data-extui-a11y-color-assist", String(colorAssist));
    el.style.setProperty("--extui-a11y-text-scale", String(ratio));
    el.style.setProperty("--extui-a11y-text-floor", (11.5 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-micro-size", (12 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-label-size", (13 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-caption-size", (13.5 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-body-size", (14 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-section-size", (13 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-heading-size", (18 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-display-size", (24 * ratio).toFixed(2) + "px");
    el.style.setProperty("--extui-text-control-size", (14 * ratio).toFixed(2) + "px");
    if (enhanced) el.setAttribute("data-extui-popup-enhanced", "true"); else el.removeAttribute("data-extui-popup-enhanced");
  }
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-extui-theme", theme);
    themeIcon.innerHTML = theme === "light" ? ICON_SUN : ICON_MOON;
    themeBtn.setAttribute("aria-label", theme === "light" ? "Mudar para tema escuro" : "Mudar para tema claro");
                                                                            
                                                                           
                                                                        
                                                        
    logoImg.src = chrome.runtime.getURL("assets/brand/logo-icon-" + (theme === "light" ? "light" : "dark") + ".png");
  }

  loadOptions().then(function (opts) { applyTheme(opts.theme || "dark"); applyAccessibility(opts); }).catch(function () { applyTheme("dark"); applyAccessibility({}); });

  themeBtn.addEventListener("click", async function () {
    try {
      var opts = await loadOptions();
      var next = opts.theme === "light" ? "dark" : "light";
      opts.theme = next;
      await storageSet(OPTIONS_KEY, opts);
      applyTheme(next);
      applyAccessibility(opts);
    } catch (error) {
      showStatus("Não foi possível salvar o tema. Tente novamente.");
    }
  });

  document.getElementById("extuipOpenShellBtn").addEventListener("click", function () {
    chrome.runtime.sendMessage({ type: "EXTUI_S0_C", forceNetwork: false }, function (response) {
      if (!chrome.runtime.lastError && response && response.ok && response.result && response.result.authorized === true) {
        chrome.tabs.create({ url: chrome.runtime.getURL("pages/dashboard/index.html") }, function () {
          if (chrome.runtime.lastError) { showStatus("Não foi possível abrir o Painel de Controle agora."); return; }
          window.close();
        });
        return;
      }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        if (chrome.runtime.lastError) { showStatus("Não foi possível localizar o WhatsApp Web agora."); return; }
        var tab = (tabs || [])[0];
        if (tab && tab.id != null) {
          chrome.tabs.update(tab.id, { active: true }, function (activeTab) {
            if (chrome.runtime.lastError) { showStatus("Não foi possível ativar a aba do WhatsApp Web."); return; }
            if (chrome.windows && chrome.windows.update) chrome.windows.update(activeTab && activeTab.windowId != null ? activeTab.windowId : tab.windowId, { focused: true }, function () { void chrome.runtime.lastError; });
            window.close();
          });
          return;
        }
        chrome.tabs.create({ url: "https://web.whatsapp.com/", active: true }, function () {
          if (chrome.runtime.lastError) { showStatus("Não foi possível abrir o WhatsApp Web agora."); return; }
          window.close();
        });
      });
    });
  });

  document.getElementById("extuipToggleBarBtn").addEventListener("click", function () {
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
      var statusEl = document.getElementById("extuipStatus");
      if (chrome.runtime.lastError) { statusEl.textContent = "Não foi possível localizar o WhatsApp Web agora."; statusEl.classList.add("extuiShow"); return; }
      var tab = (tabs || [])[0];
      if (!tab) {
        statusEl.textContent = "Abra o WhatsApp Web em outra aba primeiro.";
        statusEl.classList.add("extuiShow");
        return;
      }
      chrome.tabs.sendMessage(tab.id, { __extToggleNavBar: true }, function () {
        if (chrome.runtime.lastError) { statusEl.textContent = "A barra ainda não está pronta nesta aba. Aguarde o WhatsApp terminar de carregar e tente novamente."; statusEl.classList.add("extuiShow"); return; }
        window.close();
      });
    });
  });
})();
