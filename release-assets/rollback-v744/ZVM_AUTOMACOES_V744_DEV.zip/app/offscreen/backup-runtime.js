(function(){
  "use strict";
  if (self.__extBackupOffscreenBooted) return;
  self.__extBackupOffscreenBooted = true;

  var URLS = new Map();

  function allowed(sender){ var base=chrome.runtime.getURL(""); return !!sender && sender.id === chrome.runtime.id && !sender.tab && (!sender.url || String(sender.url).indexOf(base) === 0); }
  function safeTempName(raw){
    var name=String(raw||"");
    return /^extapp-backup-job-[A-Za-z0-9_-]{8,160}\.(?:zip|json|extbackup)$/.test(name) ? name : "";
  }
  async function release(token){
    var rec=URLS.get(String(token||""));
    if(!rec) return false;
    URLS.delete(String(token||""));
    try{ URL.revokeObjectURL(rec.url); }catch(_){}
    if(rec.opfsName){
      try{ var root=await navigator.storage.getDirectory(); await root.removeEntry(rec.opfsName); }catch(_){}
    }
    return true;
  }
  async function openArtifact(opfsName,mimeType){
    opfsName=safeTempName(opfsName);
    if(!opfsName) throw new Error("Arquivo temporário de backup inválido.");
    if(!navigator.storage||typeof navigator.storage.getDirectory!=="function") throw new Error("Armazenamento temporário do navegador indisponível.");
    var root=await navigator.storage.getDirectory();
    var handle=await root.getFileHandle(opfsName,{create:false});
    var file=await handle.getFile();
    var blob=file.type?file:new Blob([file],{type:String(mimeType||"application/octet-stream")});
    var token="extuibu-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,9);
    var url=URL.createObjectURL(blob);
    URLS.set(token,{url:url,opfsName:opfsName});
    setTimeout(function(){ release(token); },2*60*60*1000);
    return {token:token,url:url,sizeBytes:Number(file.size)||0};
  }

  chrome.runtime.onMessage.addListener(function(msg,sender,respond){
    if(!msg||typeof msg.type!=="string"||msg.target!=="ext-backup-offscreen") return;
    if(!allowed(sender)){respond({ok:false,code:"BACKUP_OFFSCREEN_UNAUTHORIZED",error:"Origem não autorizada."});return;}
    if(msg.type==="EXTUI_BACKUP_OFFSCREEN_RELEASE"){
      Promise.resolve(release(msg.token)).then(function(ok){respond({ok:true,released:ok});}).catch(function(){respond({ok:true,released:false});});
      return true;
    }
    if(msg.type!=="EXTUI_BACKUP_OFFSCREEN_OPEN") return;
    Promise.resolve(openArtifact(msg.opfsName,msg.mimeType)).then(function(result){respond({ok:true,url:result.url,token:result.token,sizeBytes:result.sizeBytes});}).catch(function(err){respond({ok:false,code:err&&err.code||"BACKUP_OFFSCREEN_FAILED",error:err&&err.message||String(err)});});
    return true;
  });
})();
