try{
(function (root, factory) {
  "use strict";
  var memoryCore = root && root.__extAiMemoryCore;
  var api = factory(memoryCore);
  if (root) root.__extAiAutomationRuntime = api;
})(typeof window !== "undefined" ? window : null, function (memoryCore) {
  "use strict";

  var OUTPUT_LIMIT_CHARS = 60000;

  function flowError(code, message) {
    var error = new Error(message);
    error.code = code;
    return error;
  }

  function firstNext(node) { return node && node.nextNodeIds && node.nextNodeIds[0] || null; }

  async function execute(node, instance, dependencies) {
    var data = node && node.data || {};
    if (!data.providerId) throw flowError("integration_not_configured", "Configure o serviço de IA desta etapa.");
    if (!String(data.prompt || "").trim()) throw flowError("ai_prompt_required", "Informe as instruções desta etapa de IA.");
    if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");

    var requestId = dependencies.createRequestId();
    var instructions = await dependencies.resolveTemplate(data.instructions || "");
    var input = await dependencies.resolveTemplate(data.prompt || "");
    if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");
    var knowledge = [];
    var memory = [];
    var memoryUnavailable = false;
    var conversation = [];
    var toolIds = data.mode === "assistant" && data.tools && Array.isArray(data.tools.enabled) ? data.tools.enabled.slice() : [];
    var toolContext = null;
    var media = null;
    dependencies.onRequestStart(requestId);
    var result;
    try {
      if (data.knowledge && data.knowledge.mode === "base") {
        if (typeof dependencies.retrieveKnowledge !== "function") throw flowError("KNOWLEDGE_RETRIEVAL_FAILED", "A Base de Conhecimento não está disponível no momento.");
        var knowledgeOutcome = await dependencies.retrieveKnowledge({ requestId: requestId, executionId: instance.id, baseId: data.knowledge.baseId, query: input });
        if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");
        if (!knowledgeOutcome || !Array.isArray(knowledgeOutcome.knowledge)) throw flowError("KNOWLEDGE_RETRIEVAL_FAILED", "Não foi possível consultar a Base de Conhecimento.");
        knowledge = knowledgeOutcome.knowledge;
        if (typeof dependencies.onKnowledgeLoaded === "function") dependencies.onKnowledgeLoaded(knowledge.length, knowledgeOutcome.baseName || "");
      }
      if (data.memory && data.memory.mode === "customer") {
        var memoryOutcome = typeof dependencies.loadMemory === "function" ? await dependencies.loadMemory(data.memory) : { entries: [], unavailable: true };
        if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");
        memory = memoryCore && typeof memoryCore.normalizeRuntimeMemory === "function"
          ? memoryCore.normalizeRuntimeMemory(memoryOutcome && memoryOutcome.entries)
          : [];
        memoryUnavailable = !!(memoryOutcome && memoryOutcome.unavailable);
        if (typeof dependencies.onMemoryLoaded === "function") dependencies.onMemoryLoaded(memory.length, memoryUnavailable);
      }
      if (data.context && data.context.mode === "recent") {
        if (typeof dependencies.loadConversation !== "function") throw flowError("AI_CONTEXT_UNAVAILABLE", "Não foi possível carregar o contexto recente desta conversa.");
        conversation = await dependencies.loadConversation(data.context);
        if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");
        if (!Array.isArray(conversation)) throw flowError("AI_CONTEXT_UNAVAILABLE", "Não foi possível carregar o contexto recente desta conversa.");
        if (typeof dependencies.onContextLoaded === "function") dependencies.onContextLoaded(conversation.length);
      }
      if (toolIds.length) {
        if (typeof dependencies.resolveToolContext !== "function") throw flowError("AI_TOOL_CONTEXT_UNAVAILABLE", "Não foi possível resolver o contato atual para as ferramentas.");
        toolContext = await dependencies.resolveToolContext(toolIds);
        if (dependencies.isCancelled()) throw flowError("AI_TOOL_CANCELLED", "A execução foi cancelada.");
      }


      var multimodal = data.multimodal || {};
      if ((multimodal.image || multimodal.audio) && typeof dependencies.prepareMedia === "function") {
        media = await dependencies.prepareMedia();
        if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");
        if (media && media.kind === "image" && !multimodal.image) media = null;
        if (media && media.kind === "audio" && !multimodal.audio) media = null;
        if (media && typeof dependencies.onMediaLoaded === "function") dependencies.onMediaLoaded(media.kind);
      }
      dependencies.onWaiting(true);
      var request = {
        requestId: requestId,
        executionId: instance.id,
        providerId: data.providerId,
        model: data.model || null,
        instructions: instructions,
        input: input,
        options: {}
      };
      if (media) request.media = media;
      if (toolIds.length) {
        request.assistantId = data.assistantId;
        request.tools = toolIds;
        request.toolContext = toolContext || {};
      }
      if (knowledge.length) request.knowledge = knowledge;
      if (memory.length) request.memory = memory;
      if (conversation.length) request.conversation = conversation;
      result = await dependencies.generate(request);
    } finally {
      dependencies.onRequestEnd(requestId);
      dependencies.onWaiting(false);
    }

    if (dependencies.isCancelled()) throw flowError("ai_cancelled", "A execução foi cancelada.");
    if (result && result.tools && typeof dependencies.onToolsUsed === "function") dependencies.onToolsUsed(result.tools);
    var text = result && typeof result.text === "string" ? result.text.trim() : "";
    if (!text) throw flowError("ai_empty_response", "O serviço de IA retornou uma resposta vazia.");
    if (text.length > OUTPUT_LIMIT_CHARS) throw flowError("ai_response_too_long", "A resposta de IA excede o limite seguro para envio.");
    await dependencies.sendText(text);
    return firstNext(node);
  }

  return Object.freeze({ OUTPUT_LIMIT_CHARS: OUTPUT_LIMIT_CHARS, execute: execute, isCancellationError: function (error) { return !!(error && (error.code === "ai_cancelled" || error.code === "AI_TOOL_CANCELLED")); } });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
