try{
(function (root, factory) {
  "use strict";
  var contextCore = root && root.__extAiConversationContext;
  var memoryCore = root && root.__extAiMemoryCore;
  var crmCore = root && root.__extCrmProfessionalCore;
  var api = factory(contextCore, memoryCore, crmCore);
  if (root) root.__extAiAutomationContact = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (contextCore, memoryCore, crmCore) {
  "use strict";

  function contactError(code, message) { var error = new Error(message); error.code = code; return error; }
  function ensureActive(options) {
    if (options.isCancelled && options.isCancelled()) throw contactError("ai_cancelled", "A execução foi cancelada.");
  }
  function phoneDigits(chatId) {
    var at = String(chatId || "").indexOf("@");
    var head = at >= 0 ? String(chatId).slice(0, at) : String(chatId || "");
    return head.replace(/\D/g, "") || null;
  }

  async function resolvePhoneDigits(chatId, getSendEngine) {
    var value = String(chatId || "");
    if (value.indexOf("@lid") < 0) return phoneDigits(value);
    var engine = getSendEngine && getSendEngine();
    if (!engine || !engine.contact || typeof engine.contact.getPnLidEntry !== "function") return null;
    try {
      var entry = await engine.contact.getPnLidEntry(value);
      var phone = entry && entry.phoneNumber && (entry.phoneNumber._serialized || entry.phoneNumber.user);
      return phone ? String(phone).replace(/\D/g, "") || null : null;
    } catch (error) {
      return null;
    }
  }

  function localDateTime() {
    var now = new Date();
    var offsetMinutes = -now.getTimezoneOffset();
    var sign = offsetMinutes >= 0 ? "+" : "-";
    var absolute = Math.abs(offsetMinutes);
    return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().replace("Z", sign + String(Math.floor(absolute / 60)).padStart(2, "0") + ":" + String(absolute % 60).padStart(2, "0"));
  }

  function create(options) {
    options = options || {};
    var chatId = String(options.chatId || "");
    if (!chatId) throw contactError("AI_CONTACT_REQUIRED", "O contato atual não está disponível para a execução de IA.");
    if (typeof options.storageGet !== "function") throw contactError("AI_CONTACT_STORAGE_UNAVAILABLE", "O contexto do contato não está disponível.");

    async function resolveCurrentPhone() {
      ensureActive(options);
      var value = await resolvePhoneDigits(chatId, options.getSendEngine);
      ensureActive(options);
      return value;
    }

    async function loadMemory(memoryRequest) {
      ensureActive(options);
      if (!memoryCore || String(chatId).indexOf("@g.us") >= 0) return { entries: [], unavailable: true };
      try {
        var phone = await resolveCurrentPhone();
        if (!phone) return { entries: [], unavailable: true };
        var subjectKey = await memoryCore.deriveSubjectKey(phone);
        ensureActive(options);
        if (!subjectKey) return { entries: [], unavailable: true };
        var stored = await options.storageGet(memoryCore.STORE_KEY);
        ensureActive(options);
        var rawEntries = memoryCore.listForSubject(stored, subjectKey);
        var agentId = memoryRequest && memoryRequest.agentId || null;
        return { entries: memoryCore.normalizeRuntimeMemory(rawEntries, agentId), unavailable: false };
      } catch (error) {
        if (error && error.code === "ai_cancelled") throw error;
        return { entries: [], unavailable: true };
      }
    }

    function loadConversation(config) {
      ensureActive(options);
      if (!contextCore || typeof contextCore.fetchRecent !== "function") return Promise.reject(contactError("AI_CONTEXT_UNAVAILABLE", "Não foi possível carregar o contexto recente desta conversa."));
      return contextCore.fetchRecent({
        chatId: chatId,
        messageCount: config && config.messageCount,
        isCancelled: function () { return !!(options.isCancelled && options.isCancelled()); },
        getMessages: function (currentChatId, requestOptions) {
          ensureActive(options);
          if (typeof options.getMessages === "function") return options.getMessages(currentChatId, requestOptions);
          var engine = options.getSendEngine && options.getSendEngine();
          if (!engine || !engine.chat || typeof engine.chat.getMessages !== "function") return Promise.reject(contactError("AI_CONTEXT_UNAVAILABLE", "O WhatsApp ainda não está pronto para carregar as mensagens recentes."));
          return engine.chat.getMessages(currentChatId, requestOptions);
        }
      });
    }

    async function resolveToolContext() {
      ensureActive(options);
      if (!memoryCore || !crmCore) throw contactError("AI_TOOL_CONTEXT_UNAVAILABLE", "Não foi possível resolver o contato atual para as ferramentas.");
      var phone = await resolveCurrentPhone();
      var subjectKey = phone ? await memoryCore.deriveSubjectKey(phone) : null;
      ensureActive(options);
      var crmRaw = await options.storageGet(options.crmStoreKey || "EXTUI:CrmStore");
      ensureActive(options);
      var crmState = crmCore.normalizeCrmState(crmRaw);
      var memberships = phone ? crmCore.findContactsByPhone(crmRaw, phone) : [];
      var preferred = memberships.filter(function (entry) { return entry.crmId === crmState.selectedCrmId; });
      var membership = preferred.length === 1 ? preferred[0] : (memberships.length === 1 ? memberships[0] : null);
      return Object.freeze({
        crmContactId: membership && membership.crmContactId || "",
        crmId: membership && membership.crmId || "",
        memorySubjectKey: subjectKey || "",
        localDateTime: localDateTime()
      });
    }

    return Object.freeze({
      chatId: chatId,
      resolvePhoneDigits: resolveCurrentPhone,
      loadMemory: loadMemory,
      loadConversation: loadConversation,
      resolveToolContext: resolveToolContext
    });
  }

  return Object.freeze({ create: create, resolvePhoneDigits: resolvePhoneDigits });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
