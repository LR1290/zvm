try{
(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extAiMediaInput = api;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this), function () {
  "use strict";


  var IMAGE_TYPES = Object.freeze(["image"]);
  var AUDIO_TYPES = Object.freeze(["ptt", "audio"]);
  var LIMITS = Object.freeze({
    image: Object.freeze({ maxSourceBytes: 8 * 1024 * 1024, maxDimension: 1600, jpegQuality: 0.82, maxOutputBytes: 6 * 1024 * 1024 }),
    audio: Object.freeze({ maxSourceBytes: 8 * 1024 * 1024, maxDurationSeconds: 120 })
  });
  var DOWNLOAD_TIMEOUT_MS = 20000;

  function mediaError(code, message) { var error = new Error(message); error.code = code; return error; }
  function cancelledError() { return mediaError("ai_cancelled", "A execução foi cancelada."); }
  function kindForType(type) {
    if (IMAGE_TYPES.indexOf(type) >= 0) return "image";
    if (AUDIO_TYPES.indexOf(type) >= 0) return "audio";
    return null;
  }


  function extractTriggerMedia(msg) {
    if (!msg || msg.fromMe) return null;
    var kind = kindForType(msg.type);
    if (!kind) return null;
    var mimeType = (typeof msg.mimetype === "string" && msg.mimetype) || (msg.mediaData && typeof msg.mediaData.mimetype === "string" ? msg.mediaData.mimetype : "");
    if (!mimeType) return null;
    var msgId = msg.id && typeof msg.id._serialized === "string" ? msg.id._serialized : (typeof msg.id === "string" ? msg.id : "");
    if (!msgId) return null;
    var duration = Number.isFinite(Number(msg.duration)) ? Number(msg.duration) : null;
    var chatId = msg.from && typeof msg.from._serialized === "string" ? msg.from._serialized : (typeof msg.from === "string" ? msg.from : "");
    return { kind: kind, msgId: msgId, mimeType: mimeType, duration: duration, chatId: chatId };
  }

  function withTimeout(promise, ms, buildTimeoutError) {
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        reject(buildTimeoutError());
      }, ms);
      Promise.resolve(promise).then(function (value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      }, function (error) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(error);
      });
    });
  }


  function arrayBufferToBase64(buffer) {
    var bytes = new Uint8Array(buffer);
    var binary = "";
    var chunkSize = 0x8000;
    for (var i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
    }
    if (typeof btoa === "function") return btoa(binary);
    if (typeof Buffer !== "undefined") return Buffer.from(binary, "binary").toString("base64");
    throw mediaError("AI_MEDIA_UNSUPPORTED", "Não foi possível codificar a mídia neste ambiente.");
  }
  function blobToBase64(blob) {
    return Promise.resolve(blob.arrayBuffer()).then(arrayBufferToBase64);
  }


  async function defaultResizeImage(blob) {
    var limits = LIMITS.image;
    if (typeof createImageBitmap !== "function") {
      var raw = await blobToBase64(blob);
      return { mimeType: blob.type || "image/jpeg", dataBase64: raw };
    }
    var bitmap = await createImageBitmap(blob);
    try {
      var scale = Math.min(1, limits.maxDimension / Math.max(bitmap.width, bitmap.height));
      var width = Math.max(1, Math.round(bitmap.width * scale));
      var height = Math.max(1, Math.round(bitmap.height * scale));
      var canvas;
      if (typeof OffscreenCanvas !== "undefined") canvas = new OffscreenCanvas(width, height);
      else { canvas = document.createElement("canvas"); canvas.width = width; canvas.height = height; }
      var ctx = canvas.getContext("2d");
      ctx.drawImage(bitmap, 0, 0, width, height);
      var outBlob = typeof canvas.convertToBlob === "function"
        ? await canvas.convertToBlob({ type: "image/jpeg", quality: limits.jpegQuality })
        : await new Promise(function (resolve) { canvas.toBlob(resolve, "image/jpeg", limits.jpegQuality); });
      if (!outBlob) throw mediaError("AI_MEDIA_UNSUPPORTED", "Não foi possível processar esta imagem.");
      if (outBlob.size > limits.maxOutputBytes) throw mediaError("AI_MEDIA_TOO_LARGE", "A imagem excede o limite seguro de tamanho após compressão.");
      var dataBase64 = await blobToBase64(outBlob);
      return { mimeType: "image/jpeg", dataBase64: dataBase64 };
    } finally {
      if (bitmap && typeof bitmap.close === "function") bitmap.close();
    }
  }


  async function prepareMedia(ref, dependencies) {
    var deps = dependencies || {};
    var isCancelled = typeof deps.isCancelled === "function" ? deps.isCancelled : function () { return false; };
    var downloadMedia = deps.downloadMedia || (typeof window !== "undefined" && window.ExtensionChatBridge && window.ExtensionChatBridge.chat && window.ExtensionChatBridge.chat.downloadMedia);
    var resizeImage = deps.resizeImage || defaultResizeImage;
    if (!ref || !ref.kind || !ref.msgId) return null;
    if (isCancelled()) throw cancelledError();
    var limits = LIMITS[ref.kind];
    if (!limits) throw mediaError("AI_MEDIA_UNSUPPORTED", "Este tipo de mídia não pode ser usado nesta etapa.");
    if (ref.kind === "audio" && ref.duration != null && ref.duration > limits.maxDurationSeconds) {
      throw mediaError("AI_MEDIA_TOO_LARGE", "O áudio excede a duração máxima suportada (" + limits.maxDurationSeconds + "s).");
    }
    if (typeof downloadMedia !== "function") throw mediaError("AI_MEDIA_DOWNLOAD_FAILED", "Não foi possível acessar a mídia desta mensagem.");
    var blob;
    try {
      blob = await withTimeout(downloadMedia(ref.msgId), deps.timeoutMs || DOWNLOAD_TIMEOUT_MS, function () { return mediaError("AI_MEDIA_DOWNLOAD_FAILED", "O download da mídia excedeu o tempo limite."); });
    } catch (error) {
      if (error && error.code) throw error;
      throw mediaError("AI_MEDIA_DOWNLOAD_FAILED", "Não foi possível baixar a mídia desta mensagem.");
    }
    if (isCancelled()) throw cancelledError();
    if (!blob || typeof blob.size !== "number" || !blob.size) throw mediaError("AI_MEDIA_DOWNLOAD_FAILED", "Não foi possível baixar a mídia desta mensagem.");
    if (blob.size > limits.maxSourceBytes) throw mediaError("AI_MEDIA_TOO_LARGE", "O arquivo excede o limite seguro de tamanho.");
    if (ref.kind === "image") {
      var normalized = await resizeImage(blob);
      if (isCancelled()) throw cancelledError();
      return { kind: "image", mimeType: normalized.mimeType, dataBase64: normalized.dataBase64 };
    }
    var dataBase64 = await blobToBase64(blob);
    if (isCancelled()) throw cancelledError();
    return { kind: "audio", mimeType: blob.type || ref.mimeType || "audio/ogg", dataBase64: dataBase64 };
  }

  return Object.freeze({
    LIMITS: LIMITS,
    DOWNLOAD_TIMEOUT_MS: DOWNLOAD_TIMEOUT_MS,
    extractTriggerMedia: extractTriggerMedia,
    prepareMedia: prepareMedia,

    arrayBufferToBase64: arrayBufferToBase64,
    defaultResizeImage: defaultResizeImage
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
