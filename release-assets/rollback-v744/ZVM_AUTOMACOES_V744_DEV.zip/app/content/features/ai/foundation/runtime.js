try{
(function (root, factory) {
  "use strict";
  var contextCore = root && root.__extAiConversationContext;
  var memoryCore = root && root.__extAiMemoryCore;
  var knowledgeCore = root && root.__extKnowledgeCore;
  var toolsCore = root && root.__extAiToolsRegistry;
  var createClient = factory(contextCore, memoryCore, knowledgeCore, toolsCore);
  if (root && root.addEventListener && root.postMessage) {
    var runtimeClient = createClient({ target: root });
    root.__extAiRuntime = runtimeClient;
    root.addEventListener("pagehide", function () {
      try { runtimeClient.destroy(); }
      catch (error) { if (root.__extReportRuntimeError) root.__extReportRuntimeError("AI_RUNTIME_TEARDOWN_FAILED", error); }
    });
  }
})(typeof window !== "undefined" ? window : null, function (contextCore, memoryCore, knowledgeCore, toolsCore) {
  "use strict";

  var DEFAULT_CLIENT_TIMEOUT_MS = 65000;

  function aiError(code, message, retryable, provider, details) {
    var error = new Error(message || "Não foi possível gerar a resposta com IA.");
    error.code = code || "unknown_error";
    error.retryable = retryable === true;
    error.provider = typeof provider === "string" ? provider : null;
    if (details && Number.isFinite(Number(details.httpStatus))) error.httpStatus = Number(details.httpStatus);
    if (details && typeof details.providerErrorCode === "string") error.providerErrorCode = details.providerErrorCode;
    if (details && typeof details.providerErrorType === "string") error.providerErrorType = details.providerErrorType;
    return error;
  }

  function publicRequest(raw) {
    raw = raw || {};
    var request = {
      requestId: typeof raw.requestId === "string" ? raw.requestId : "",
      executionId: typeof raw.executionId === "string" ? raw.executionId : "",
      providerId: typeof raw.providerId === "string" ? raw.providerId : "",
      model: typeof raw.model === "string" ? raw.model : null,
      instructions: typeof raw.instructions === "string" ? raw.instructions : "",
      input: typeof raw.input === "string" ? raw.input : "",
      options: raw.options && typeof raw.options === "object" ? { maxOutputTokens: raw.options.maxOutputTokens } : {}
    };
    var conversation = contextCore ? contextCore.normalizeConversation(raw.conversation, 20) : [];
    if (conversation.length) request.conversation = conversation;
    var memory = memoryCore ? memoryCore.normalizeRuntimeMemory(raw.memory) : [];
    if (memory.length) request.memory = memory;
    var knowledge = knowledgeCore ? knowledgeCore.normalizeRuntimeKnowledge(raw.knowledge) : [];
    if (knowledge.length) request.knowledge = knowledge;
    var tools = toolsCore && toolsCore.normalizeEnabledToolIds ? toolsCore.normalizeEnabledToolIds(raw.tools) : [];
    if (typeof raw.assistantId === "string" && raw.assistantId.trim()) request.assistantId = raw.assistantId.trim().slice(0, 160);
    if (tools.length && request.assistantId) {
      request.tools = tools;
      var context = raw.toolContext && typeof raw.toolContext === "object" ? raw.toolContext : {};
      request.toolContext = {
        crmContactId: typeof context.crmContactId === "string" ? context.crmContactId.slice(0, 160) : "",
        crmId: typeof context.crmId === "string" ? context.crmId.slice(0, 160) : "",
        memorySubjectKey: typeof context.memorySubjectKey === "string" && /^sha256:[a-f0-9]{64}$/.test(context.memorySubjectKey) ? context.memorySubjectKey : "",
        localDateTime: typeof context.localDateTime === "string" ? context.localDateTime.slice(0, 80) : ""
      };
    }
    if (raw.agentControl && typeof raw.agentControl === "object" && request.assistantId) {
      request.agentControl = {
        agentId: typeof raw.agentControl.agentId === "string" ? raw.agentControl.agentId.slice(0, 160) : "",
        agentRunId: typeof raw.agentControl.agentRunId === "string" ? raw.agentControl.agentRunId.slice(0, 200) : "",
        step: Number(raw.agentControl.step),
        maxSteps: Number(raw.agentControl.maxSteps),
        toolCallLimit: Number(raw.agentControl.toolCallLimit)
      };
    }


    if (raw.media && typeof raw.media === "object" && (raw.media.kind === "image" || raw.media.kind === "audio") && typeof raw.media.mimeType === "string" && typeof raw.media.dataBase64 === "string") {
      request.media = { kind: raw.media.kind, mimeType: raw.media.mimeType.slice(0, 100), dataBase64: raw.media.dataBase64 };
    }
    return request;
  }
  function publicKnowledgeRequest(raw) {
    raw = raw || {};
    return {
      requestId: typeof raw.requestId === "string" ? raw.requestId : "",
      executionId: typeof raw.executionId === "string" ? raw.executionId : "",
      baseId: typeof raw.baseId === "string" ? raw.baseId : "",
      query: typeof raw.query === "string" ? raw.query : ""
    };
  }

  function createClient(options) {
    options = options || {};
    var target = options.target;
    var timeoutMs = Number(options.timeoutMs) || DEFAULT_CLIENT_TIMEOUT_MS;
    var pending = new Map();
    var runtimeRoot = target || (typeof window !== "undefined" ? window : null);

    function settle(requestId, outcome, error) {
      var record = pending.get(requestId);
      if (!record) return false;
      pending.delete(requestId);
      clearTimeout(record.timer);
      if (error) record.reject(error);
      else record.resolve(outcome);
      return true;
    }

    function responseError(response) {
      return aiError(response && response.errorCode, response && response.userMessage, response && response.retryable, response && response.provider, response);
    }

    function sendRuntime(message, callback) {
      try {
        runtimeRoot.chrome.runtime.sendMessage(message, function (response) {
          var last = runtimeRoot.chrome.runtime.lastError;
          if (last) { callback(null, aiError("runtime_error", last.message || "O recurso de IA não respondeu.", true)); return; }
          callback(response || null, null);
        });
      } catch (error) { callback(null, aiError("runtime_error", error && error.message || String(error), true)); }
    }

    function sendCancel(requestId, executionId) {
      sendRuntime({ type: "EXTUI_AI_CANCEL", requestId: requestId, executionId: executionId || "" }, function () {});
      sendRuntime({ type: "EXTUI_KNOWLEDGE_RETRIEVAL_CANCEL", requestId: requestId, executionId: executionId || "" }, function () {});
    }

    function beginDirect(requestId, executionId, message, timeoutText) {
      var requestMeta=message&&message.request||{};
      function traceAi(status,errorCode){try{if(runtimeRoot.__extTraceRuntime)runtimeRoot.__extTraceRuntime("AI_DIRECT",{requestId:requestId,executionId:executionId,provider:requestMeta.providerId,model:requestMeta.model,status:status,errorCode:errorCode});}catch(_){}}
      traceAi("start");
      return new Promise(function (resolve, reject) {
        var timer = setTimeout(function () {
          if (!pending.has(requestId)) return;
          pending.delete(requestId);
          traceAi("timeout","timeout");
          reject(aiError("timeout", timeoutText, true));
          sendCancel(requestId, executionId);
        }, timeoutMs);
        pending.set(requestId, { resolve: resolve, reject: reject, timer: timer, executionId: executionId });
        sendRuntime(message, function (response, transportError) {
          if (!pending.has(requestId)) return;
          if (transportError) { traceAi("transport_error",transportError.code||"runtime_error"); settle(requestId, null, transportError); return; }
          if (!response || response.ok !== true) { var directError=responseError(response); traceAi("error",directError&&directError.code); settle(requestId, null, directError); return; }
          traceAi("success");
          settle(requestId, response.result);
        });
      });
    }

    function cancel(requestId, executionId) {
      var record = pending.get(requestId);
      var effectiveExecutionId = executionId || record && record.executionId || "";
      if (record) settle(requestId, null, aiError("ai_cancelled", "A geração de IA foi cancelada.", false));
      sendCancel(requestId, effectiveExecutionId);
      return !!record;
    }

    function generate(raw) {
      var request = publicRequest(raw);
      if (!request.requestId || !request.executionId) return Promise.reject(aiError("ai_request_id_required", "A solicitação de IA é inválida."));
      if (pending.has(request.requestId)) return Promise.reject(aiError("ai_request_conflict", "Esta solicitação de IA já está em andamento."));
      return beginDirect(request.requestId, request.executionId, { type: "EXTUI_AI_GENERATE", request: request }, "A geração de IA excedeu o tempo limite.");
    }

    function transcribeAudio(raw) {
      raw = raw || {};
      var request = { requestId: typeof raw.requestId === "string" ? raw.requestId : "", executionId: typeof raw.executionId === "string" ? raw.executionId : "", providerId: typeof raw.providerId === "string" ? raw.providerId : "", model: typeof raw.model === "string" ? raw.model : null, language: typeof raw.language === "string" ? raw.language : null, media: raw.media && raw.media.kind === "audio" ? { kind: "audio", mimeType: String(raw.media.mimeType || "audio/ogg").slice(0, 100), dataBase64: String(raw.media.dataBase64 || "") } : null };
      if (!request.requestId || !request.executionId || !request.providerId || !request.media || !request.media.dataBase64) return Promise.reject(aiError("invalid_request", "A solicitação de transcrição é inválida."));
      if (pending.has(request.requestId)) return Promise.reject(aiError("ai_request_conflict", "Esta solicitação já está em andamento."));
      return beginDirect(request.requestId, request.executionId, { type: "EXTUI_AI_TRANSCRIBE", request: request }, "A transcrição excedeu o tempo limite.");
    }

    function retrieveKnowledge(raw) {
      var request = publicKnowledgeRequest(raw);
      if (!request.requestId || !request.executionId || !request.baseId || !request.query.trim()) return Promise.reject(aiError("KNOWLEDGE_RETRIEVAL_FAILED", "A solicitação de Knowledge é inválida."));
      if (pending.has(request.requestId)) return Promise.reject(aiError("ai_request_conflict", "Esta solicitação já está em andamento."));
      return beginDirect(request.requestId, request.executionId, { type: "EXTUI_KNOWLEDGE_RETRIEVE", request: request }, "A consulta à Base de Conhecimento excedeu o tempo limite.");
    }

    function cancelExecution(executionId) {
      var requestIds = [];
      pending.forEach(function (record, requestId) { if (record.executionId === executionId) requestIds.push(requestId); });
      requestIds.forEach(function (requestId) { cancel(requestId, executionId); });
      return requestIds.length;
    }

    function endAgentRun(agentRunId, executionId) {
      if (typeof agentRunId !== "string" || !agentRunId) return false;
      sendRuntime({ type: "EXTUI_AI_AGENT_END", agentRunId: agentRunId.slice(0, 200), executionId: typeof executionId === "string" ? executionId : "" }, function () {});
      return true;
    }

    function destroy() {
      Array.from(pending.keys()).forEach(function (requestId) { cancel(requestId); });
    }

    return Object.freeze({ generate: generate, transcribeAudio: transcribeAudio, retrieveKnowledge: retrieveKnowledge, cancel: cancel, cancelExecution: cancelExecution, endAgentRun: endAgentRun, pendingCount: function () { return pending.size; }, destroy: destroy });
  }

  createClient.DEFAULT_CLIENT_TIMEOUT_MS = DEFAULT_CLIENT_TIMEOUT_MS;
  return createClient;
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
