;(function(){
  "use strict";
  if(window.__extCreateEnviosPanelDomainCore)return;
  window.__extCreateEnviosPanelDomainCore=function(deps){
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,NAV_ICONS=deps.navIcons||{},ACTIVITY_TYPE_META=deps.activityTypeMeta||{},ACTIVITY_ACTIVE_STATUSES=deps.activeStatuses||{},ACTIVITY_STATUS_LABEL=deps.statusLabels||{},ACTIVITY_CANCELABLE_TYPES=deps.cancelableTypes||{},extActivityCancel=deps.activityCancel,extActivityReconcile=deps.activityReconcile,extActivityNotify=deps.activityNotify,extActivityTrack=deps.activityTrack,extActivityList=deps.activityList,extActivityClearFinished=deps.activityClearFinished,extActivityHydrate=deps.activityHydrate,extActivitySubscribe=deps.activitySubscribe,extFormatCountdown=deps.formatCountdown,extPanelOwn=deps.panelOwn,extEmptyState=deps.emptyState,extGet=deps.get,extSet=deps.set,toast=deps.toast,escHtml=deps.escHtml,iconChip=deps.iconChip;
    if([buildPanelShell,extActivityList,extEmptyState,toast,escHtml,iconChip].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do domínio Envios inválidas.");

    function extFormatActivityTime(ms) {
      if (!ms) return "";
      var diff = Date.now() - ms;
      if (diff < 60000) return "Agora";
      if (diff < 3600000) return "Há " + Math.max(1, Math.round(diff / 60000)) + " min";
      return new Date(ms).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    }


    function extActivityRow(a) {
      var meta = ACTIVITY_TYPE_META[a.type] || { label: a.type || "Operação", accent: "#9ba39e", icon: NAV_ICONS.envios };
      var row = document.createElement("div");
      row.className = "extActivityRow";

      var head = document.createElement("div");
      head.className = "extuiActivityRowHead";
      head.insertAdjacentHTML("beforeend", iconChip(meta.accent, meta.icon, true));
      var textWrap = document.createElement("div");
      textWrap.className = "extuiDockedPanelRowText";
      var glyph = a.status === "success" ? '<span class="extuiActivityGlyph extuiActivityGlyph--success">✓</span> '
        : a.status === "error" ? '<span class="extuiActivityGlyph extuiActivityGlyph--error">!</span> '
        : a.status === "cancelled" ? '<span class="extuiActivityGlyph extuiActivityGlyph--cancelled">–</span> '
        : a.status === "interrupted" ? '<span class="extuiActivityGlyph extuiActivityGlyph--interrupted">⚠</span> ' : "";
      textWrap.innerHTML =
        '<div class="extuiDockedPanelRowTitle">' + glyph + escHtml(a.title) + '</div>' +
        '<div class="extuiDockedPanelRowMeta">' + (a.source === "test" ? '<span class="extuiActivityTestBadge">Teste real</span> ' : '') + escHtml(meta.label) + ((a.targetLabel && a.type !== "fluxo" && a.type !== "funil") ? " • " + escHtml(a.targetLabel) : "") + '</div>';
      head.appendChild(textWrap);
      var timeEl = document.createElement("div");
      timeEl.className = "extuiActivityTime";
      timeEl.textContent = a.status === "success" ? "Enviado " + extFormatActivityTime(a.finishedAt)
        : a.status === "error" ? "Falhou " + extFormatActivityTime(a.finishedAt)
        : a.status === "cancelled" ? "Cancelado " + extFormatActivityTime(a.finishedAt)
        : a.status === "interrupted" ? "Interrompido " + extFormatActivityTime(a.finishedAt)
        : extFormatActivityTime(a.startedAt);
      head.appendChild(timeEl);
      row.appendChild(head);

      if (ACTIVITY_ACTIVE_STATUSES[a.status]) {
        var prog = document.createElement("div");
        prog.className = "extuiActivityProgress";


        var countdownAttr = a.nextActionAt ? ' data-next-action-at="' + a.nextActionAt + '"' : "";
        var countdownText = a.nextActionAt ? "Próximo envio em " + extFormatCountdown(a.nextActionAt - Date.now()) : "";
        if (typeof a.current === "number" && typeof a.total === "number" && a.total > 0) {
          var pct = Math.max(0, Math.min(100, Math.round((a.current / a.total) * 100)));
          prog.innerHTML = '<div class="extuiActivityProgressText">' + a.current + ' de ' + a.total + '</div>' +
            '<div class="extuiActivityProgressBar"><div class="extuiActivityProgressFill" style="width:' + pct + '%"></div></div>' +
            (countdownText ? '<div class="extuiActivityProgressText extuiActivityCountdown"' + countdownAttr + '>' + countdownText + '</div>' : "");
        } else if (countdownText) {
          prog.innerHTML = '<div class="extuiActivityProgressText extuiActivityCountdown"' + countdownAttr + '>' + countdownText + '</div>';
        } else if (a.progressLabel) {
          prog.innerHTML = '<div class="extuiActivityProgressText">' + escHtml(a.progressLabel) + '</div>';
        } else if (a.status === "waiting") {
          prog.innerHTML = '<div class="extuiActivityProgressText extuiActivityProgressText--waiting">Aguardando resposta</div>';
        } else if (a.status === "running") {
          prog.innerHTML = '<div class="extuiActivityProgressText">Processando</div>';
        } else {
          prog.innerHTML = '<div class="extuiActivityProgressText">' + (ACTIVITY_STATUS_LABEL[a.status] || "Em execução") + '</div>';
        }
        row.appendChild(prog);


        if (ACTIVITY_CANCELABLE_TYPES[a.type]) {
          var actionsRow = document.createElement("div");
          actionsRow.className = "extuiActivityActions";
          var cancelBtn = document.createElement("button");
          cancelBtn.type = "button"; cancelBtn.className = "extuiNavDangerBtn extuiActivityCancelBtn"; cancelBtn.textContent = "Cancelar";
          cancelBtn.addEventListener("click", async function () {
            if (!await window.extConfirm("Cancelar esta execução? Os próximos passos pendentes não serão enviados. Mensagens já enviadas não são afetadas.", { danger: true })) return;
            cancelBtn.disabled = true;
            var ok = await extActivityCancel(a);
            if (!ok) {


              await extActivityReconcile();
              extActivityNotify();
              toast("Não foi possível cancelar agora.", true);
              cancelBtn.disabled = false;
            }
          });
          actionsRow.appendChild(cancelBtn);
          row.appendChild(actionsRow);
        }
      } else if (a.status === "error" && a.errorMessage) {
        var errEl = document.createElement("div");
        errEl.className = "extuiActivityError";
        errEl.textContent = a.errorMessage;
        row.appendChild(errEl);
      }
      return row;
    }


    async function buildEnviosPanel() {
      var root = buildPanelShell({
        id: "extuiNavEnviosPanel", title: "Envios", accent: "#ec4899", icon: NAV_ICONS.envios, eyebrow: "Operação",
        hint: "Acompanhe operações da extensão em tempo real.",
        size: "md"
      });
      var body = root.querySelector(".extuiNavPanelBody");


      var cancelAllWrap = document.createElement("div");
      cancelAllWrap.className = "extuiEnviosCancelAllWrap";
      var cancelAllBtn = document.createElement("button");
      cancelAllBtn.type = "button";


      cancelAllBtn.className = "extuiNavDangerBtn";
      cancelAllBtn.textContent = "Cancelar tudo";
      var cancelAllSub = document.createElement("div");
      cancelAllSub.className = "extuiEnviosCancelAllSub";
      cancelAllSub.textContent = "Interrompe disparos em massa, fluxos e funis em andamento, em todos os chats.";
      cancelAllBtn.addEventListener("click", async function () {
        var confirmed = await window.extConfirm(
          "Cancelar todos os envios? Isso vai interromper TODOS os disparos em massa, fluxos e funis em andamento, em todos os chats. Essa ação não pode ser desfeita.",
          { danger: true, okLabel: "Cancelar todos", cancelLabel: "Voltar" }
        );
        if (!confirmed) return;
        try {
          var flowCount = typeof window.__extFluxosCancelAll === "function" ? await window.__extFluxosCancelAll() : 0;
          var funnelCount = typeof window.__extFunnelsCancelAll === "function" ? await window.__extFunnelsCancelAll() : 0;
          var queue = (await extGet("ext:bulkQueue")) || [];
          var pendingDispatch = queue.filter(function (it) { return it.state === "queued" || it.state === "retrying" || it.state === "sending"; }).length;
          if (pendingDispatch > 0) await extSet("ext:bulkQueueCancelRequested", true);
          var parts = [];
          if (flowCount) parts.push(flowCount + " fluxo(s)");
          if (funnelCount) parts.push(funnelCount + " funil(is)");
          if (pendingDispatch) parts.push(pendingDispatch + " disparo(s) em massa");
          toast(parts.length ? "Cancelado(s): " + parts.join(", ") + "." : "Nada em andamento.");
        } catch (err) { toast("Falha ao cancelar.", true); }
      });
      cancelAllWrap.appendChild(cancelAllBtn);
      cancelAllWrap.appendChild(cancelAllSub);
      body.appendChild(cancelAllWrap);

      var listWrap = document.createElement("div");
      listWrap.className = "extuiEnviosHistoryWrap";
      body.appendChild(listWrap);

      function render() {
        listWrap.innerHTML = "";
        var active = extActivityList().filter(function (a) { return ACTIVITY_ACTIVE_STATUSES[a.status]; });
        var finished = extActivityList().filter(function (a) { return !ACTIVITY_ACTIVE_STATUSES[a.status]; });
        cancelAllWrap.hidden = active.length === 0;
        cancelAllBtn.textContent = active.length > 1 ? "Cancelar todas (" + active.length + ")" : "Cancelar tudo";
        var controlSection = cancelAllWrap.closest(".extPanelSection--controls");
        if (controlSection) controlSection.hidden = active.length === 0;

        if (active.length === 0 && finished.length === 0) {
          listWrap.appendChild(extEmptyState("#ec4899", NAV_ICONS.envios, "Nenhum envio no histórico", "Quando a extensão executar mensagens, fluxos, funis ou outras automações, a atividade aparecerá aqui.", null, null, { sober: true }));
          return;
        }
        if (active.length > 0) {
          listWrap.insertAdjacentHTML("beforeend", '<div class="extuiNavSectionLabel">Em andamento</div>');
          var activeList = document.createElement("div");
          activeList.className = "extuiDockedPanelList";
          active.forEach(function (a) { activeList.appendChild(extActivityRow(a)); });
          listWrap.appendChild(activeList);
        }
        if (finished.length > 0) {
          var recentHeader = document.createElement("div");
          recentHeader.className = "extuiActivityHistoryToolbar";
          var clearBtn = document.createElement("button");
          clearBtn.type = "button"; clearBtn.className = "extuiActivityClearBtn"; clearBtn.textContent = "Limpar concluídos";
          clearBtn.addEventListener("click", async function () { await extActivityClearFinished(); });
          recentHeader.appendChild(clearBtn);
          listWrap.appendChild(recentHeader);
          var recentList = document.createElement("div");
          recentList.className = "extuiDockedPanelList";
          finished.forEach(function (a) { recentList.appendChild(extActivityRow(a)); });
          listWrap.appendChild(recentList);
        }
      }

      extActivityHydrate().then(extActivityReconcile).then(render);
      extPanelOwn(root, extActivitySubscribe(function () { if (root.classList.contains("extuiOpen")) render(); }));


      var countdownRuntime = { timer: null, observer: null };
      function tickCountdowns() {
        root.querySelectorAll(".extuiActivityCountdown[data-next-action-at]").forEach(function (el) {
          var t = parseInt(el.getAttribute("data-next-action-at"), 10);
          if (!t) return;
          el.textContent = "Próximo envio em " + extFormatCountdown(t - Date.now());
        });
      }
      countdownRuntime.observer = new MutationObserver(function () {
        var isOpen = root.classList.contains("extuiOpen");
        if (isOpen && !countdownRuntime.timer) {
          extActivityReconcile().then(render);
          tickCountdowns();
          countdownRuntime.timer = setInterval(tickCountdowns, 1000);
        } else if (!isOpen && countdownRuntime.timer) {
          clearInterval(countdownRuntime.timer);
          countdownRuntime.timer = null;
        }
      });
      countdownRuntime.observer.observe(root, { attributes: true, attributeFilter: ["class"] });
      extPanelOwn(root, function () {
        if (countdownRuntime.observer) { countdownRuntime.observer.disconnect(); countdownRuntime.observer = null; }
        if (countdownRuntime.timer) { clearInterval(countdownRuntime.timer); countdownRuntime.timer = null; }
      });

      return root;
    }
    return Object.freeze({buildEnviosPanel:buildEnviosPanel,formatActivityTime:extFormatActivityTime,activityRow:extActivityRow});
  };
})();
