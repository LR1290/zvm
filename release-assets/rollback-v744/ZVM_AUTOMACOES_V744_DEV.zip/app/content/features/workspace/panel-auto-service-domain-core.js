;(function () {
  "use strict";
  if (window.__extCreateAutoServicePanelDomainCore) return;
  window.__extCreateAutoServicePanelDomainCore = function (deps) {
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,panelBrand=deps.panelBrand||{},panelBody=deps.panelBody,choiceDeck=deps.choiceDeck,field=deps.field,formSection=deps.formSection,emptyState=deps.emptyState,set=deps.set,panelOnKeyChange=deps.panelOnKeyChange,escHtml=deps.escHtml,toast=deps.toast;
    if([buildPanelShell,panelBody,choiceDeck,field,formSection,emptyState,set,panelOnKeyChange,escHtml,toast].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do domínio Autoatendimento inválidas.");
    
    function extAutoRulesFromLoaded(loaded){return loaded&&Array.isArray(loaded.rules)?loaded.rules:[];}
    async function buildAutoServicePanel(){
      var root=buildPanelShell({id:"extuiNavAutoServicePanel",title:"Autoatendimento",accent:panelBrand.autoService.accent,icon:panelBrand.autoService.icon,eyebrow:"Automação",hint:"Responda automaticamente usando regras.",size:"md",tutorialKey:"autoatendimento"});
      root.classList.add("extuiNavPanel--designer");
      var body=panelBody(root),form=document.createElement("form");
      form.className="extuiCrmQuickComposer extuiAutoServiceQuickForm extuiPanelFormSurface";
      var name=document.createElement("input");name.placeholder="Ex.: Boas-vindas, preço ou horário";
      var trigger=document.createElement("select");
      [["keyword","Contém palavra-chave"],["message_Received","Mensagem exata"],["day_Message","Primeira mensagem do dia"],["customer_Message","Primeira mensagem do contato"]].forEach(function(x){trigger.appendChild(new Option(x[1],x[0]));});
      var triggerDeck=choiceDeck(trigger,[
        {value:"keyword",title:"Palavra-chave",desc:"Contém um termo",icon:'<path d="M10 13a5 5 0 1 1 3.5-8.5A5 5 0 0 1 10 13Z"/><path d="m14 10 7 7-4 4-7-7"/><path d="m17 13 2-2"/>'},
        {value:"message_Received",title:"Mensagem exata",desc:"Texto idêntico",icon:'<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/>'},
        {value:"day_Message",title:"Primeira do dia",desc:"Uma vez por dia",icon:'<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/><path d="M12 2v2M12 20v2"/>'},
        {value:"customer_Message",title:"Primeiro contato",desc:"Início da conversa",icon:'<circle cx="9" cy="8" r="4"/><path d="M3 20c0-4 3-6 6-6"/><path d="M17 10v6M14 13h6"/>'}
      ],2);
      triggerDeck.setAttribute("aria-label","Quando o Autoatendimento deve responder");
      var values=document.createElement("textarea");values.placeholder="Digite uma palavra ou mensagem por linha";
      var response=document.createElement("textarea");response.placeholder="Escreva a resposta que a extensão enviará automaticamente";
      var groups=document.createElement("input");groups.type="checkbox";
      var save=document.createElement("button");save.type="submit";save.className="extuiNavPrimaryBtn extuiPanelSubmitBtn";save.textContent="Criar regra";
      var nameField=field("Nome da regra",name,"Use um nome curto para localizar esta automação depois.");
      var triggerField=field("Quando responder",trigger);triggerField.classList.add("extuiFieldGroup--choice");triggerField.appendChild(triggerDeck);
      var valuesField=field("Condições",values,"Para primeira mensagem do dia ou do contato, este campo pode ficar vazio.");
      var responseField=field("Resposta automática",response,"Esta mensagem será enviada quando a condição da regra for atendida.");
      nameField.classList.add("extuiAutoField","extuiAutoField--name"); triggerField.classList.add("extuiAutoField","extuiAutoField--trigger"); valuesField.classList.add("extuiAutoField","extuiAutoField--condition"); responseField.classList.add("extuiAutoField","extuiAutoField--response");
      var identityBlock=document.createElement("section");identityBlock.className="extuiPanelFormBlock extuiAutoBlock extuiAutoBlock--identity";identityBlock.appendChild(formSection("Identificação","Dê um nome e escolha o tipo de gatilho."));identityBlock.appendChild(nameField);identityBlock.appendChild(triggerField);
      var conditionBlock=document.createElement("section");conditionBlock.className="extuiPanelFormBlock extuiAutoBlock extuiAutoBlock--condition";conditionBlock.appendChild(formSection("Condição","Informe o que precisa acontecer para disparar a regra."));conditionBlock.appendChild(valuesField);
      var responseBlock=document.createElement("section");responseBlock.className="extuiPanelFormBlock extuiAutoBlock extuiAutoBlock--response";responseBlock.appendChild(formSection("Resposta","Defina o conteúdo que a extensão enviará automaticamente."));responseBlock.appendChild(responseField);
      var behaviorBlock=document.createElement("section");behaviorBlock.className="extuiPanelFormBlock extuiAutoBlock extuiAutoBlock--behavior";behaviorBlock.appendChild(formSection("Alcance","Escolha onde esta automação poderá atuar.")); var grow=document.createElement("label");grow.className="extuiNavToggleRow extuiPanelToggleCard";grow.innerHTML='<div class="extuiNavToggleText"><div class="title">Responder em grupos</div><div class="desc">Mantenha desligado se a regra deve atuar apenas em conversas individuais.</div></div>';grow.appendChild(groups);behaviorBlock.appendChild(grow);behaviorBlock.appendChild(save);
      form.appendChild(identityBlock);form.appendChild(conditionBlock);form.appendChild(responseBlock);form.appendChild(behaviorBlock);body.appendChild(form);
      var list=document.createElement("div");list.className="extuiAutoServiceList";body.appendChild(list);
    
      function syncTriggerField(){var noValues=trigger.value==="day_Message"||trigger.value==="customer_Message";valuesField.classList.toggle("extuiFieldGroup--optional",noValues);}
      trigger.addEventListener("change",syncTriggerField);syncTriggerField();
      async function readLoaded(){if(!window.__extAutoService)throw new Error("Autoatendimento ainda não ficou pronto.");return window.__extAutoService.loadRules();}
      async function writeLoaded(loaded){var raw=loaded.parsed||{};if(raw.state&&typeof raw.state==="object"){if(Array.isArray(raw.state.rules))raw.state.rules=loaded.rules;else if(Array.isArray(raw.state.triggerList))raw.state.triggerList=loaded.rules;else if(Array.isArray(raw.state.triggers))raw.state.triggers=loaded.rules;else raw.state.rules=loaded.rules;}else{raw.schemaVersion=raw.schemaVersion||1;raw.rules=loaded.rules;}await set(loaded.key,typeof loaded.parsed==="string"?JSON.stringify(raw):raw);}
      form.addEventListener("submit",async function(ev){
        ev.preventDefault();
        if(!name.value.trim()||!response.value.trim()){toast("Informe nome e resposta da regra.",true);return;}
        save.disabled=true;
        try{
          var loaded=await readLoaded(),arr=extAutoRulesFromLoaded(loaded).slice(),vals=values.value.split(/\r?\n|,/).map(function(v){return v.trim();}).filter(Boolean);
          arr.push({id:"auto-"+Date.now().toString(36),nome:name.value.trim(),active:true,acionamento:{type:trigger.value,propriedades:{values:vals}},regras:{responderGrupos:{active:groups.checked}},actions:[{type:"txt",properties:{mensagem:response.value.trim()}}],usedLenght:0});
          loaded.rules=arr;loaded.parsed=loaded.parsed||{schemaVersion:1,rules:[]};await writeLoaded(loaded);toast("Regra criada.");name.value="";values.value="";response.value="";groups.checked=false;render();
        }catch(e){toast(e.message||"Falha ao criar regra.",true);}
        finally{save.disabled=false;}
      });
      async function render(){
        list.innerHTML="";
        try{
          var loaded=await readLoaded(),rules=extAutoRulesFromLoaded(loaded);
          var label=document.createElement("div");label.className="extuiNavSectionLabel";label.textContent="Regras existentes";list.appendChild(label);
          if(!rules.length){list.appendChild(emptyState(panelBrand.autoService.accent,panelBrand.autoService.icon,"Nenhuma regra","Crie sua primeira automação usando o formulário acima.",null,null,{sober:true}));return;}
          rules.forEach(function(rule){
            var row=document.createElement("div");row.className="extuiDockedPanelRow extuiAutoServiceRow";
            var txt=document.createElement("div");txt.className="extuiDockedPanelRowText";
            var state=rule.active===false?"Pausada":"Ativa";
            txt.innerHTML='<div class="extuiDockedPanelRowTitle">'+escHtml(rule.nome||rule.name||"Regra")+'</div><div class="extuiDockedPanelRowMeta">'+escHtml(state)+' · '+escHtml((rule.acionamento&&rule.acionamento.type)||rule.triggerType||"acionamento")+' · '+String(Number(rule.usedLenght)||0)+' uso(s)</div>';
            row.appendChild(txt);
            var actions=document.createElement("div");actions.className="extuiOrdersDockActions";
            var toggle=document.createElement("button");toggle.type="button";toggle.className="extuiNavSecondaryBtn";toggle.textContent=rule.active===false?"Ativar":"Pausar";toggle.addEventListener("click",async function(){rule.active=rule.active===false;await writeLoaded(loaded);render();});
            var del=document.createElement("button");del.type="button";del.className="extuiNavDangerBtn";del.textContent="Excluir";del.addEventListener("click",async function(){if(!(await window.extConfirm("Excluir esta regra?",{danger:true})))return;loaded.rules=rules.filter(function(r){return r!==rule;});await writeLoaded(loaded);render();});
            actions.appendChild(toggle);actions.appendChild(del);row.appendChild(actions);list.appendChild(row);
          });
        }catch(e){list.appendChild(emptyState(panelBrand.autoService.accent,panelBrand.autoService.icon,"Autoatendimento indisponível",e.message||"Recarregue o WhatsApp.",null,null,{sober:true}));}
      }
      render();panelOnKeyChange(root,"EXTUI:extappAutoServiceStore",render);return root;
    }
    return Object.freeze({buildAutoServicePanel:buildAutoServicePanel});
  };
})();
