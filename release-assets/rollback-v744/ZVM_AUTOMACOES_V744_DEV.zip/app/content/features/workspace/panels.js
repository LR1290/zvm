;
try{


(function () {
  "use strict";

  if (window.__extSidebarNavBooted) return;
  window.__extSidebarNavBooted = true;

  var __extWorkspaceStaticData = window.__extWorkspaceStaticData;
  if (!__extWorkspaceStaticData) throw new Error("Dados estáticos do workspace não foram carregados.");


  var installPanelDialogCore=window.__extInstallPanelDialogCore;
  if(typeof installPanelDialogCore!=="function")throw new Error("Core de diálogos dos painéis não foi carregado.");
  installPanelDialogCore();


  var createPanelBridgeCore=window.__extCreatePanelBridgeCore;
  if(typeof createPanelBridgeCore!=="function")throw new Error("Bridge dos painéis não foi carregado.");
  var panelBridgeCore=createPanelBridgeCore({getOptionsKey:function(){return typeof OPTIONS_KEY==="string"?OPTIONS_KEY:"EXTUI:extappOptionsStore";}});
  var extBridgeCall=panelBridgeCore.bridgeCall,extGet=panelBridgeCore.get,extSet=panelBridgeCore.set,extCrmProfessionalOperation=panelBridgeCore.crmProfessionalOperation,openShellHtml=panelBridgeCore.openShellHtml;
  window.__extOpenShellHtml=openShellHtml;


  var createPanelLifecycleCore=window.__extCreatePanelLifecycleCore;
  if(typeof createPanelLifecycleCore!=="function")throw new Error("Lifecycle dos painéis não foi carregado.");
  var panelLifecycleCore=createPanelLifecycleCore();
  var extOnKeyChange=panelLifecycleCore.onKeyChange,extPanelOwn=panelLifecycleCore.own,extPanelResetOwnedLifecycle=panelLifecycleCore.resetOwned,extPanelOnKeyChange=panelLifecycleCore.onPanelKeyChange,extPanelResetBuilderLifecycle=panelLifecycleCore.resetBuilder,extPanelDispose=panelLifecycleCore.dispose;


  function toast(message, isError) { return window.__extNotify(message, !!isError); }

  var createPanelChatServicesCore=window.__extCreatePanelChatServicesCore;
  if(typeof createPanelChatServicesCore!=="function")throw new Error("Serviços de chat dos painéis não foram carregados.");
  var panelChatServices=createPanelChatServicesCore();
  var extGetActiveContactContext=panelChatServices.getActiveContactContext,extInvokeCapability=panelChatServices.invokeCapability,extRunConversationAction=panelChatServices.runConversationAction;
  if(window.__extPanelSessionDraft&&typeof window.__extPanelSessionDraft.setContextProvider==="function")window.__extPanelSessionDraft.setContextProvider(extGetActiveContactContext);
  window.__extInvokeChatCapability=function(name,context){return extInvokeCapability(name,context||{});};
  if(window.__extEventBus&&typeof window.__extEventBus.on==="function")window.__extEventBus.on("ActiveChatChanged",function(){extGetActiveContactContext().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("CUSTOMER_ACTIVE_CHAT_SYNC_FAILED",err);});});
  setTimeout(function(){extGetActiveContactContext().catch(function(){});},1200);

  var createPanelRuntimeStateCore=window.__extCreatePanelRuntimeStateCore;
  if(typeof createPanelRuntimeStateCore!=="function")throw new Error("Estado de runtime dos painéis não foi carregado.");
  var panelRuntimeState=createPanelRuntimeStateCore();

  var PANEL_BRAND = __extWorkspaceStaticData.PANEL_BRAND;


  var NAV_ICONS = __extWorkspaceStaticData.NAV_ICONS;
  var createPanelUiPrimitivesCore=window.__extCreatePanelUiPrimitivesCore;
  if(typeof createPanelUiPrimitivesCore!=="function")throw new Error("Primitivas UI dos painéis não foram carregadas.");
  var panelUiPrimitives=createPanelUiPrimitivesCore({navIcons:NAV_ICONS});
  var parsePersisted=panelUiPrimitives.parsePersisted,escHtml=panelUiPrimitives.escHtml,extField=panelUiPrimitives.field,vectorNavChip=panelUiPrimitives.vectorNavChip,extEmptyState=panelUiPrimitives.emptyState;
  var extBuildSwitch=panelUiPrimitives.buildSwitch,extPaintSwitch=panelUiPrimitives.paintSwitch,extRepaintAllSwitches=panelUiPrimitives.repaintAllSwitches,extPanelFormSection=panelUiPrimitives.formSection,extPanelChoiceDeck=panelUiPrimitives.choiceDeck,iconChip=panelUiPrimitives.iconChip;


  var activityCore=window.__extCreatePanelActivityCore({panelBrand:PANEL_BRAND,navIcons:NAV_ICONS,get:extGet,set:extSet,toast:toast});
  var ACTIVITY_ACTIVE_STATUSES=activityCore.activeStatuses,ACTIVITY_TYPE_META=activityCore.typeMeta,ACTIVITY_STATUS_LABEL=activityCore.statusLabels,ACTIVITY_CANCELABLE_TYPES=activityCore.cancelableTypes;
  var extActivitySubscribe=activityCore.subscribe,extActivityHydrate=activityCore.hydrate,extActivityTrack=activityCore.track,extActivityCounts=activityCore.counts,extActivityClearFinished=activityCore.clearFinished,extActivityCancel=activityCore.cancel,extFormatCountdown=activityCore.formatCountdown,extActivityReconcile=activityCore.reconcile;
  var extActivityList=activityCore.list;
  window.__extActivityTrack=extActivityTrack;




  var createChatContextOverlayCore=window.__extCreateChatContextOverlayCore;
  if(typeof createChatContextOverlayCore!=="function")throw new Error("Core de overlays da conversa não foi carregado.");
  var chatContextOverlayCore=createChatContextOverlayCore({activitySubscribe:extActivitySubscribe,activityHydrate:extActivityHydrate,activityList:extActivityList,activityCancel:extActivityCancel,activityTrack:extActivityTrack,activeStatuses:ACTIVITY_ACTIVE_STATUSES,cancelableTypes:ACTIVITY_CANCELABLE_TYPES,typeMeta:ACTIVITY_TYPE_META,getActiveContactContext:extGetActiveContactContext,crmMemberships:function(list,phone){return extCrmWorkspaceMemberships(list,phone);},chatActions:__extWorkspaceStaticData.CHAT_ACTIONS,chatToolMeta:__extWorkspaceStaticData.CHAT_TOOL_META,runConversationAction:extRunConversationAction,escHtml:escHtml,toast:toast});
  var extChatTargetDigits=chatContextOverlayCore.targetDigits;
  chatContextOverlayCore.start();
  chatContextOverlayCore.installPagehide();

  var extWorkspaceContextFactory = window.__extCreateWorkspaceContext;
  if (typeof extWorkspaceContextFactory !== "function") throw new Error("O contexto do workspace não foi carregado.");
  var workspaceContext = extWorkspaceContextFactory({ getActivePanel: function () { return extWorkspace && extWorkspace.activePanel; } });
  var RESIZE_DIRS = workspaceContext.resizeDirs;
  var extClampNum = workspaceContext.clampNum;
  var extClampWorkspaceRect = workspaceContext.clampRect;
  var extApplyWorkspaceRect = workspaceContext.applyRect;
  var extSetWorkspaceVisibility = workspaceContext.setVisibility;
  var extNormalizePanelOpenMode = workspaceContext.normalizePanelOpenMode;
  var extPanelOpenMode = workspaceContext.panelOpenMode;
  var extSetPanelOpenMode = workspaceContext.setPanelOpenMode;
  var extRefreshPanelDockHost = workspaceContext.refreshDockHost;
  var extDeactivatePanelDockHost = workspaceContext.deactivateDockHost;
  var extReleasePanelFromDock = workspaceContext.releaseFromDock;
  var extApplyPanelOpenModeToRoot = workspaceContext.applyOpenMode;
  var extCenterWorkspace = workspaceContext.center;
  var attachWorkspaceResize = workspaceContext.attachResize;
  var attachWorkspaceDrag = workspaceContext.attachDrag;


  var panelLayoutCore = window.__extPanelLayoutCore;
  if (!panelLayoutCore) throw new Error("O núcleo de layout dos painéis não foi carregado.");
  var panelBody = panelLayoutCore.panelBody;
  var extInstallPanelScrollContract = panelLayoutCore.installScrollContract;
  var extPanelDecorate = panelLayoutCore.decorate;
  var extPanelAdopt = panelLayoutCore.adopt;
  panelLifecycleCore.setLayoutDispose(panelLayoutCore.dispose);


  var panelCommandOrchestrator=null;
  function extSyncActiveNavButtons(){return panelCommandOrchestrator?panelCommandOrchestrator.syncActiveNavButtons():undefined;}

  var extPanelShellFactory = window.__extCreatePanelShellCore;
  if (typeof extPanelShellFactory !== "function") throw new Error("O núcleo do shell dos painéis não foi carregado.");
  var panelShellCore = extPanelShellFactory({
    navIcons: NAV_ICONS,
    resizeDirs: RESIZE_DIRS,
    resetBuilderLifecycle: extPanelResetBuilderLifecycle,
    setVisibility: extSetWorkspaceVisibility,
    registerRoot: function (id, root) { return workspaceContext.registerRoot(id, root); },
    attachResize: attachWorkspaceResize,
    attachDrag: attachWorkspaceDrag,
    installScrollContract: extInstallPanelScrollContract,
    centerWorkspace: extCenterWorkspace,
    decorate: extPanelDecorate,
    panelBody: panelBody,
    syncNav: function () { return extSyncActiveNavButtons(); },
    getWorkspace: function () { return extWorkspace; },
    openTools: function () { return extCoreCommandHostOpenBuilt("ferramentas", buildChatToolsPanel, { ensureOpen: true, source: "panel-back" }); },
    bridgeCall: extBridgeCall,
    alertFn: function (message) { return window.extAlert(message); },
    getNavTrigger: function (panelId) { return _navButtonsByPanelId[panelId]; },
    panelState: panelRuntimeState
  });
  var buildPanelShell = panelShellCore.build;
  var pushPanelSubview = panelShellCore.pushSubview;
  var popPanelSubview = panelShellCore.popSubview;
  var focusPanelOnOpen = panelShellCore.focusOnOpen;
  var restoreFocusAfterPanelClose = panelShellCore.restoreFocusAfterClose;




  var extWorkspaceControllerFactory = window.__extCreatePanelWorkspaceController;
  if (typeof extWorkspaceControllerFactory !== "function") throw new Error("O controlador do workspace dos painéis não foi carregado.");
  var extWorkspace = extWorkspaceControllerFactory({
    adopt: extPanelAdopt,
    applyOpenMode: extApplyPanelOpenModeToRoot,
    setVisibility: extSetWorkspaceVisibility,
    focusOnOpen: focusPanelOnOpen,
    pushSubview: pushPanelSubview,
    popSubview: popPanelSubview,
    hasSubviews: panelShellCore.hasSubviews,
    peekSubview: panelShellCore.peekSubview,
    releaseFromDock: extReleasePanelFromDock,
    deactivateDockHost: extDeactivatePanelDockHost,
    syncNav: function () { return extSyncActiveNavButtons(); },
    restoreFocusAfterClose: restoreFocusAfterPanelClose,
    collapseRail: function () { if (window.__extCollapseRailForPanel) window.__extCollapseRailForPanel(); },
    scheduleQuickItems: function () { if (window.__extQuickItemsScheduleReposition) window.__extQuickItemsScheduleReposition(); }
  });
  extWorkspace.installEscapeHandler();
  window.__extWorkspace = extWorkspace;


  window.__extBuildPanelShell = buildPanelShell;
  function closeAllPanels() { extWorkspace.close(); }


  var OPTIONS_KEY = "EXTUI:extappOptionsStore";
  var OPTIONS_DEFAULTS = {
    theme: "light", themeStateVersion: 7, accessibilityTextScale: 110, accessibilityContrast: "enhanced", accessibilityColorAssist: true, customColors: null, hideItemsBar: false, showOnlyFavoritesOnItemsBar: false,
    askToSendSingleItem: true, askToSendFlows: true, askToSendFunnels: true,
    shouldAvoidWhatsappAutoScroll: false,


    mode: "auto", visualTheme: "padrao", fontFamily: "system", motion: "auto", radiusPreset: "default",
    iconTheme: "monochrome", icon3dColor: "olive",
    quickShelfUseIconTheme: false,
    quickShelfEnabled: true,
    quickShelfVisibility: {},
    sidebarMainIconSize: 36,
    sidebarPlacement: "left-native",
    rightSidebarPanelsFollowRail: false,
    disparosIconSize: 38,
    dashboardUseSidebarIconSize: false,
    dashboardMenuIconSize: 28,


    floatingWindowMovable: true,
    floatingWindowResizable: false,
    floatingWorkspaceLayoutVersion: 4,
    panelOpenMode: "docked"
  };
  var NEW_INSTALL_OPTIONS_DEFAULTS = Object.assign({}, OPTIONS_DEFAULTS);
  var optionsRuntime=window.__extCreatePanelOptionsRuntimeCore({optionsKey:OPTIONS_KEY,optionsDefaults:OPTIONS_DEFAULTS,newInstallOptionsDefaults:NEW_INSTALL_OPTIONS_DEFAULTS,clampNum:extClampNum,workspaceContext:workspaceContext,repaintAllSwitches:extRepaintAllSwitches,normalizePanelOpenMode:extNormalizePanelOpenMode,setPanelOpenMode:extSetPanelOpenMode,onKeyChange:extOnKeyChange,get:extGet,applyMenuVisibility:function(opts){return extApplyMenuVisibility(opts);}});
  var extParseOptionsPayload=optionsRuntime.parseOptionsPayload,applySidebarPlacementToDocument=optionsRuntime.applySidebarPlacement,applyFloatingWorkspaceSettingsToDocument=optionsRuntime.applyFloatingSettings;


  var MENU_CONFIG_ITEMS = __extWorkspaceStaticData.MENU_CONFIG_ITEMS;
  var QUICK_MENU_CONFIG_ITEMS = __extWorkspaceStaticData.QUICK_MENU_CONFIG_ITEMS;




  var __extPanelSystemMenusCore=window.__extCreatePanelSystemMenusCore({
    buildPanelShell:buildPanelShell,panelBody:panelBody,navIcons:NAV_ICONS,panelBrand:PANEL_BRAND,iconChip:iconChip,escHtml:escHtml,toast:toast,openShellHtml:openShellHtml,workspace:extWorkspace,ensurePanel:ensurePanel,syncNav:extSyncActiveNavButtons,
    normalizePanelOpenMode:extNormalizePanelOpenMode,panelOpenMode:extPanelOpenMode,setPanelOpenMode:extSetPanelOpenMode,set:extSet,get:extGet,optionsKey:OPTIONS_KEY,optionsDefaults:OPTIONS_DEFAULTS,parseOptionsPayload:extParseOptionsPayload,
    applySidebarPlacement:applySidebarPlacementToDocument,applyFloatingSettings:applyFloatingWorkspaceSettingsToDocument,buildSwitch:extBuildSwitch,menuConfigItems:MENU_CONFIG_ITEMS,
    getConfigureMenuBuilder:function(){return buildConfigureMenuPanel;},getConfigureQuickMenuBuilder:function(){return buildConfigureQuickMenuPanel;}
  });
  var buildSystemPanel=__extPanelSystemMenusCore.buildSystemPanel;
  var buildMenusPanelsPanel=__extPanelSystemMenusCore.buildMenusPanelsPanel;
  var extConfigureToggleRow=__extPanelSystemMenusCore.configureToggleRow;
  var extApplyMenuVisibility=__extPanelSystemMenusCore.applyMenuVisibility;
  var EXTUI_QUICK_MENU_ICON=__extPanelSystemMenusCore.quickMenuIcon;
  var __extPanelMenuOrganizerCore=window.__extCreatePanelMenuOrganizerCore({
    buildPanelShell:buildPanelShell,panelBody:panelBody,workspace:extWorkspace,ensurePanel:ensurePanel,buildMenusPanelsPanel:buildMenusPanelsPanel,syncNav:extSyncActiveNavButtons,
    configureToggleRow:extConfigureToggleRow,get:extGet,set:extSet,toast:toast,escHtml:escHtml,navIcons:NAV_ICONS,quickMenuIcon:EXTUI_QUICK_MENU_ICON,optionsKey:OPTIONS_KEY,
    optionsDefaults:OPTIONS_DEFAULTS,newInstallOptionsDefaults:NEW_INSTALL_OPTIONS_DEFAULTS,quickMenuConfigItems:QUICK_MENU_CONFIG_ITEMS
  });
  var buildConfigureMenuPanel=__extPanelMenuOrganizerCore.buildConfigureMenuPanel;
  var buildConfigureQuickMenuPanel=__extPanelMenuOrganizerCore.buildConfigureQuickMenuPanel;


  var createPanelSystemDomainCore = window.__extCreatePanelSystemDomainCore;
  if (typeof createPanelSystemDomainCore !== "function") throw new Error("Domínio de Sistema dos painéis não foi carregado.");
  var panelSystemDomain = createPanelSystemDomainCore({
    get:extGet,set:extSet,bridgeCall:extBridgeCall,onKeyChange:extOnKeyChange,buildPanelShell:buildPanelShell,panelBody:panelBody,navIcons:NAV_ICONS,panelBrand:PANEL_BRAND,emptyState:extEmptyState,escHtml:escHtml,pushSubview:pushPanelSubview,iconChip:iconChip,openShellHtml:openShellHtml,toast:toast,panelOnKeyChange:extPanelOnKeyChange,webhookEventDefs:__extWorkspaceStaticData.WEBHOOK_EVENT_DEFS,parsePersisted:parsePersisted
  });
  var buildNotificationsPanel = panelSystemDomain.buildNotificationsPanel;
  var buildWebhooksPanel = panelSystemDomain.buildWebhooksPanel;
  var extLoadNotifications = panelSystemDomain.loadNotifications;
  var extRefreshNotificationBadge = panelSystemDomain.refreshNotificationBadge;
  var extBindNotificationRefresh = panelSystemDomain.bindNotificationRefresh;
  var extMaybeShowUrgentNotification = panelSystemDomain.maybeShowUrgentNotification;


  var createAgendaPanelDomainCore = window.__extCreateAgendaPanelDomainCore;
  if (typeof createAgendaPanelDomainCore !== "function") throw new Error("Domínio Agenda não foi carregado.");
  var agendaDomain = createAgendaPanelDomainCore({
    get:extGet,set:extSet,buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,field:extField,parsePersisted:parsePersisted,emptyState:extEmptyState,iconChip:iconChip,escHtml:escHtml,toast:toast,panelOnKeyChange:extPanelOnKeyChange,navigateRail:function(key, options){ return extNavigateRail(key, options); },agendaItemStores:__extWorkspaceStaticData.AGENDA_ITEM_STORES
  });
  var SCHEDULE_KEY=agendaDomain.scheduleKey, QUICK_ITEMS_RECENTS_KEY=agendaDomain.quickItemsRecentsKey, AGENDA_ITEM_STORES=agendaDomain.agendaItemStores, AGENDA_STATUS_LABELS=agendaDomain.agendaStatusLabels;
  var appendPrioritizedItemOptions=agendaDomain.appendPrioritizedItemOptions, loadSchedules=agendaDomain.loadSchedules, saveSchedules=agendaDomain.saveSchedules, fmtDateTime=agendaDomain.fmtDateTime;
  var buildAgendaPanel=agendaDomain.buildAgendaPanel, scheduleViaAgenda=agendaDomain.scheduleViaAgenda;
  window.__extScheduleViaAgenda=scheduleViaAgenda;


  var CRM_KEY = "EXTUI:CrmStore";
  var CRM_PROFESSIONAL_KEY = "EXTUI:crmProfessionalStore";
  var createFollowUpPanelDomainCore=window.__extCreateFollowUpPanelDomainCore;
  if(typeof createFollowUpPanelDomainCore!=="function")throw new Error("Domínio FollowUp não foi carregado.");
  var followUpDomain=createFollowUpPanelDomainCore({get:extGet,set:extSet,parsePersisted:parsePersisted,buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,field:extField,buildSwitch:extBuildSwitch,formSection:extPanelFormSection,agendaItemStores:AGENDA_ITEM_STORES,quickItemsRecentsKey:QUICK_ITEMS_RECENTS_KEY,appendPrioritizedItemOptions:appendPrioritizedItemOptions,crmKey:CRM_KEY,emptyState:extEmptyState,escHtml:escHtml,iconChip:iconChip,toast:toast,panelOnKeyChange:extPanelOnKeyChange});
  var FOLLOWUP_KEY=followUpDomain.followUpKey,FOLLOWUP_QUEUE_KEY=followUpDomain.followUpQueueKey;
  var loadFollowUpQueue=followUpDomain.loadQueue,saveFollowUpQueue=followUpDomain.saveQueue;
  var buildFollowUpPanel=followUpDomain.buildFollowUpPanel;


  var createAutomationResourceCore=window.__extCreateAutomationResourceCore;
  if(typeof createAutomationResourceCore!=="function")throw new Error("Núcleo de recursos de automação não foi carregado.");
  var automationResourceCore=createAutomationResourceCore({});
  var extAutomationExecutionMessage=automationResourceCore.executionMessage;
  var extAutomationResourceTitle=automationResourceCore.resourceTitle;
  var extAutomationResourceStepCount=automationResourceCore.stepCount;
  var extAutomationResourceTrigger=automationResourceCore.triggerLabel;

  var flowsDomain=window.__extCreateFlowsPanelDomainCore({panelState:panelRuntimeState,buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,get:extGet,set:extSet,parsePersisted:parsePersisted,panelOnKeyChange:extPanelOnKeyChange,workspace:extWorkspace,getActiveContactContext:extGetActiveContactContext,toast:toast,executionMessage:extAutomationExecutionMessage,emptyState:extEmptyState,resourceTitle:extAutomationResourceTitle,stepCount:extAutomationResourceStepCount,triggerLabel:extAutomationResourceTrigger,buildSwitch:extBuildSwitch,openShellHtml:openShellHtml,iconChip:iconChip,escHtml:escHtml});
  var buildFluxosPanel=flowsDomain.buildFluxosPanel;

  var funnelsDomain=window.__extCreateFunnelsPanelDomainCore({panelState:panelRuntimeState,buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,get:extGet,parsePersisted:parsePersisted,panelOnKeyChange:extPanelOnKeyChange,workspace:extWorkspace,getActiveContactContext:extGetActiveContactContext,toast:toast,executionMessage:extAutomationExecutionMessage,emptyState:extEmptyState,resourceTitle:extAutomationResourceTitle,stepCount:extAutomationResourceStepCount,openShellHtml:openShellHtml,iconChip:iconChip,escHtml:escHtml});
  var buildFunisPanel=funnelsDomain.buildFunisPanel;
  var enviosDomain=window.__extCreateEnviosPanelDomainCore({buildPanelShell:buildPanelShell,navIcons:NAV_ICONS,activityTypeMeta:ACTIVITY_TYPE_META,activeStatuses:ACTIVITY_ACTIVE_STATUSES,statusLabels:ACTIVITY_STATUS_LABEL,cancelableTypes:ACTIVITY_CANCELABLE_TYPES,activityCancel:extActivityCancel,activityReconcile:extActivityReconcile,activityNotify:activityCore.notify,activityTrack:extActivityTrack,activityList:extActivityList,activityClearFinished:extActivityClearFinished,activityHydrate:extActivityHydrate,activitySubscribe:extActivitySubscribe,formatCountdown:extFormatCountdown,panelOwn:extPanelOwn,emptyState:extEmptyState,get:extGet,set:extSet,toast:toast,escHtml:escHtml,iconChip:iconChip});
  var buildEnviosPanel=enviosDomain.buildEnviosPanel;


  var createCrmMainDomainCore=window.__extCreateCrmMainDomainCore;
  if(typeof createCrmMainDomainCore!=="function")throw new Error("Núcleo principal de CRM não foi carregado.");
  var crmMainDomain=createCrmMainDomainCore({buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,get:extGet,set:extSet,parsePersisted:parsePersisted,crmProfessionalOperation:extCrmProfessionalOperation,panelOnKeyChange:extPanelOnKeyChange,panelOwn:extPanelOwn,emptyState:extEmptyState,field:extField,toast:toast,escHtml:escHtml,openShellHtml:openShellHtml,fmtDateTime:fmtDateTime,iconChip:iconChip,navigateRail:function(key,options){return extNavigateRail(key,options);},crmKey:CRM_KEY,crmProfessionalKey:CRM_PROFESSIONAL_KEY,scheduleKey:SCHEDULE_KEY,followUpQueueKey:FOLLOWUP_QUEUE_KEY,followUpKey:FOLLOWUP_KEY});
  var buildCrmPanel=crmMainDomain.buildCrmPanel;





  var ordersDomain=window.__extCreateOrdersPanelDomainCore({buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,panelBody:panelBody,field:extField,emptyState:extEmptyState,getActiveContactContext:extGetActiveContactContext,formSection:extPanelFormSection,confirm:window.extConfirm,panelOnKeyChange:extPanelOnKeyChange,toast:toast,openShellHtml:openShellHtml,iconChip:iconChip,escHtml:escHtml});
  var buildOrdersPanel=ordersDomain.buildOrdersPanel;
  var deliveryDomain=window.__extCreateDeliveryPanelDomainCore({panelState:panelRuntimeState,buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,panelBody:panelBody,emptyState:extEmptyState,field:extField,confirm:window.extConfirm,getActiveContactContext:extGetActiveContactContext,formSection:extPanelFormSection,panelOnKeyChange:extPanelOnKeyChange,toast:toast,openShellHtml:openShellHtml,iconChip:iconChip,escHtml:escHtml});
  var buildDeliveryPanel=deliveryDomain.buildDeliveryPanel;
  var crmFunnelDomain=window.__extCreateCrmFunnelPanelDomainCore({buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,panelBody:panelBody,get:extGet,set:extSet,emptyState:extEmptyState,panelOnKeyChange:extPanelOnKeyChange,field:extField,openShellHtml:openShellHtml,escHtml:escHtml,crmKey:CRM_KEY,crmProfessionalKey:CRM_PROFESSIONAL_KEY});
  var buildCrmFunnelPanel=crmFunnelDomain.buildCrmFunnelPanel;

  var createStatusPanelDomainCore=window.__extCreateStatusPanelDomainCore;
  if(typeof createStatusPanelDomainCore!=="function")throw new Error("Domínio Status não foi carregado.");
  var statusDomain=createStatusPanelDomainCore({buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,panelBody:panelBody,choiceDeck:extPanelChoiceDeck,field:extField,formSection:extPanelFormSection,emptyState:extEmptyState,panelOnKeyChange:extPanelOnKeyChange,fmtDateTime:fmtDateTime,escHtml:escHtml,toast:toast});
  var buildStatusPanel=statusDomain.buildStatusPanel;
  var createAutoServicePanelDomainCore=window.__extCreateAutoServicePanelDomainCore;
  if(typeof createAutoServicePanelDomainCore!=="function")throw new Error("Domínio Autoatendimento não foi carregado.");
  var autoServiceDomain=createAutoServicePanelDomainCore({buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,panelBody:panelBody,choiceDeck:extPanelChoiceDeck,field:extField,formSection:extPanelFormSection,emptyState:extEmptyState,set:extSet,panelOnKeyChange:extPanelOnKeyChange,escHtml:escHtml,toast:toast});
  var buildAutoServicePanel=autoServiceDomain.buildAutoServicePanel;

  var CHAT_TOOL_GROUPS = __extWorkspaceStaticData.CHAT_TOOL_GROUPS;
  var CHAT_ACTIONS = __extWorkspaceStaticData.CHAT_ACTIONS;
  var CHAT_TOOLS_PREFS_KEY="EXTUI:chatToolsHubPrefs";



  var CHAT_TOOL_META = __extWorkspaceStaticData.CHAT_TOOL_META;

  var createProductivityDomainCore = window.__extCreateProductivityDomainCore;
  if (typeof createProductivityDomainCore !== "function") throw new Error("Domínio de produtividade não foi carregado.");
  var productivityDomain = createProductivityDomainCore({
    panelState: panelRuntimeState,
    chatToolMeta: CHAT_TOOL_META, panelBrand: PANEL_BRAND, buildPanelShell: buildPanelShell, panelBody: panelBody, field: extField,
    invokeCapability: extInvokeCapability, getActiveContactContext: extGetActiveContactContext, toast: toast, iconChip: iconChip, escHtml: escHtml, emptyState: extEmptyState
  });
  var buildNotesStandalonePanel = productivityDomain.buildNotesPanel;
  var buildReminderStandalonePanel = productivityDomain.buildReminderPanel;
  var buildGoogleCalendarStandalonePanel = productivityDomain.buildGoogleCalendarPanel;
  var buildSignatureStandalonePanel = productivityDomain.buildSignaturePanel;
  var buildTextAssistantStandalonePanel = productivityDomain.buildTextAssistantPanel;
  var buildTextReplaceStandalonePanel = productivityDomain.buildTextReplacePanel;
  var buildGlobalLabelsPanel = productivityDomain.buildGlobalLabelsPanel;
  var createChatToolsPanelDomainCore=window.__extCreateChatToolsPanelDomainCore;
  if(typeof createChatToolsPanelDomainCore!=="function")throw new Error("Domínio Ferramentas não foi carregado.");
  var chatToolsDomain=createChatToolsPanelDomainCore({panelState:panelRuntimeState,buildPanelShell:buildPanelShell,panelBrand:PANEL_BRAND,panelBody:panelBody,prefsKey:CHAT_TOOLS_PREFS_KEY,get:extGet,set:extSet,toolGroups:CHAT_TOOL_GROUPS,iconChip:iconChip,escHtml:escHtml,toast:toast,panelDecorate:extPanelDecorate,ownLifecycle:extPanelOwn});
  var buildChatToolsPanel=chatToolsDomain.buildChatToolsPanel;



  var createActionsGoogleDomainCore = window.__extCreateActionsGoogleDomainCore;
  if (typeof createActionsGoogleDomainCore !== "function") throw new Error("Domínio Google não foi carregado.");
  var actionsGoogleDomain = createActionsGoogleDomainCore({ panelBrand: PANEL_BRAND, buildPanelShell: buildPanelShell, panelBody: panelBody, escHtml: escHtml });
  var buildGooglePanel = actionsGoogleDomain.buildGooglePanel;



  var createPanelRegistry = window.__extCreatePanelRegistry;
  if (typeof createPanelRegistry !== "function") throw new Error("Registro de painéis não foi carregado.");
  var panelRegistry = createPanelRegistry({ dispose: extPanelDispose });
  function ensurePanel(name, builder) { return panelRegistry.ensure(name, builder); }
  function extPrunePanelRegistry() { panelRegistry.prune(); }
  var createRailNavigationCore = window.__extCreateRailNavigationCore;
  if (typeof createRailNavigationCore !== "function") throw new Error("Navegação da barra lateral não foi carregada.");
  function resolveRailCommandId(key) {
    var entry = panelBuilderCatalog && panelBuilderCatalog.get(key);
    if (entry) return entry.commandId;
    if (key === "itens") return "items.open";
    if (key === "disparos") return "broadcast.open";
    if (key === "salvar") return "export-contacts.open";
    return null;
  }
  var railNavigation = createRailNavigationCore({
    resolveCommandId: resolveRailCommandId,
    isSidebarEnabled: function () { return window.__EXT_SIDEBAR_ENABLED__ === true; },
    getCommandHost: function () { return window.ExtensionCore && window.ExtensionCore.CommandHost; }
  });
  var extNavigateRail = railNavigation.navigate;
  window.__extRailNavigation = Object.freeze({ navigate: railNavigation.navigate, has: railNavigation.has });


  function extCoreCommandHostPanelState(panel) {
    return { available: true, active: !!(panel && extWorkspace.isOpen(panel)) };
  }
  function extCoreCommandHostSetPanelOrigin(panel, payload) {
    if (!panel) return;
    payload = payload || {};
    var origin = panelRuntimeState.setOrigin(panel, payload);
    var back = panel.querySelector && panel.querySelector("[data-back]");
    if (back) {
      back.hidden = false;
      back.title = origin === "tools" ? "Voltar para Ferramentas" : "Fechar painel";
      back.setAttribute("aria-label", back.title);
    }
  }
  function extCoreCommandHostOpenBuilt(cacheKey, builder, payload) {
    payload = payload || {};
    return ensurePanel(cacheKey, builder).then(async function (panel) {
      extCoreCommandHostSetPanelOrigin(panel, payload);
      var active = extWorkspace.isOpen(panel);
      if (active && payload.toggle === true && payload.ensureOpen !== true) {
        extWorkspace.close();
        return { ok: true, active: false };
      }
      try { await panelRuntimeState.refresh(panel); } catch (_) {}
      if (!active) extWorkspace.open(panel);
      return { ok: true, active: true };
    });
  }
  async function extCommandHostOpenExternal(panelId, controllerKey, payload) {
    payload = payload || {};
    var panel = document.getElementById(panelId);
    if (panel && extWorkspace.isOpen(panel)) {
      extCoreCommandHostSetPanelOrigin(panel, payload);
      if (payload.toggle === true && payload.ensureOpen !== true) {
        extWorkspace.close();
        return { ok: true, active: false };
      }
      return { ok: true, active: true };
    }
    var registry = window.ExtensionCore && window.ExtensionCore.PanelControllers;
    var controller = registry && registry[controllerKey];
    if (!controller || typeof controller.open !== "function") {
      var unavailable = new Error("Recurso ainda não está pronto nesta aba.");
      unavailable.code = "EXT_COMMAND_UNAVAILABLE";
      throw unavailable;
    }
    extWorkspace.close();
    await Promise.resolve(controller.open());
    panel = document.getElementById(panelId);
    if (panel) extCoreCommandHostSetPanelOrigin(panel, payload);
    return { ok: true, active: !!(panel && extWorkspace.isOpen(panel)) };
  }
  function extCoreCommandHostOpenDashboard(payload) {
    payload = payload || {};
    return Promise.resolve(openShellHtml(payload.section || null, {
      focus: payload.focus || null,
      crmContactId: payload.crmContactId || null,
      crmCopilot: payload.crmCopilot === true,
      reuseExisting: payload.reuseExisting !== false
    })).then(function () { return { ok: true, active: false }; });
  }
  function extCommandHostExportContacts(payload) {
    payload = Object.assign({}, payload || {}, { ensureOpen: true });
    return extCommandHostOpenExternal("ext-items-panel-root", "items", payload).then(function () {
      var registry = window.ExtensionCore && window.ExtensionCore.PanelControllers;
      var itemsController = registry && registry.items;
      if (!itemsController || typeof itemsController.exportContacts !== "function") {
        var unavailable = new Error("Exportação de contatos indisponível.");
        unavailable.code = "EXT_COMMAND_UNAVAILABLE";
        throw unavailable;
      }
      itemsController.exportContacts();
      return { ok: true, active: true };
    });
  }
  var quickResponseDomain=window.__extCreateQuickResponsePanelDomainCore({panelState:panelRuntimeState,buildPanelShell:buildPanelShell,panelBody:panelBody,iconChip:iconChip,get:extGet,crmKey:CRM_KEY,getActiveContactContext:extGetActiveContactContext,emptyState:extEmptyState,field:extField,panelOnKeyChange:extPanelOnKeyChange,workspace:extWorkspace,escHtml:escHtml,toast:toast,confirm:window.extConfirm});
  var EXTUI_QR_ACCENT=quickResponseDomain.accent,EXTUI_QR_ICON=quickResponseDomain.icon,buildQuickResponsePanel=quickResponseDomain.buildQuickResponsePanel;








  var createClientHelperCore=window.__extCreateClientHelperCore;
  if(typeof createClientHelperCore!=="function")throw new Error("Core de helpers do cliente não foi carregado.");
  var clientHelperCore=createClientHelperCore({escHtml:escHtml,get:extGet,set:extSet,countryFallback:__extWorkspaceStaticData.EXTUI_CLIENT_COUNTRY_FALLBACK,brStates:__extWorkspaceStaticData.EXTUI_CLIENT_BR_STATES,brDdds:__extWorkspaceStaticData.EXTUI_CLIENT_BR_DDDS,leadSourceOptions:__extWorkspaceStaticData.EXTUI_CLIENT_LEAD_SOURCE_OPTIONS});
  var extQrDownloadXls=clientHelperCore.extQrDownloadXls;
  var extClientWait=clientHelperCore.extClientWait;
  var extClientDigits=clientHelperCore.extClientDigits;
  var extClientPhoneType=clientHelperCore.extClientPhoneType;
  var extClientDetectBrazilPhoneType=clientHelperCore.extClientDetectBrazilPhoneType;
  var extClientNormalizeBrazilLocal=clientHelperCore.extClientNormalizeBrazilLocal;
  var extClientMaskLocalPhone=clientHelperCore.extClientMaskLocalPhone;
  var extClientMaskCep=clientHelperCore.extClientMaskCep;
  var extClientEmojiFlag=clientHelperCore.extClientEmojiFlag;
  var extClientCountryDialMeta=clientHelperCore.extClientCountryDialMeta;
  var extClientInferCountryFromPhone=clientHelperCore.extClientInferCountryFromPhone;
  var extClientParsePhoneParts=clientHelperCore.extClientParsePhoneParts;
  var extClientBuildPhoneRecord=clientHelperCore.extClientBuildPhoneRecord;
  var extClientStateName=clientHelperCore.extClientStateName;
  var extClientDraftStore=clientHelperCore.extClientDraftStore;
  var extClientQueueDraftWrite=clientHelperCore.extClientQueueDraftWrite;
  var extClientReadDraft=clientHelperCore.extClientReadDraft;
  var extClientWriteDraft=clientHelperCore.extClientWriteDraft;
  var extClientClearDraft=clientHelperCore.extClientClearDraft;
  var extClientFindDddMeta=clientHelperCore.extClientFindDddMeta;
  var extClientPopulateLeadSourceList=clientHelperCore.extClientPopulateLeadSourceList;
  var extEnableMiddleGrabScroll=clientHelperCore.extEnableMiddleGrabScroll;
  var extClientLoadCountryList=clientHelperCore.extClientLoadCountryList;
  var extClientPopulateCountrySelect=clientHelperCore.extClientPopulateCountrySelect;
  var extClientUpdateCountryDisplay=clientHelperCore.extClientUpdateCountryDisplay;
  var extClientFillStateSelect=clientHelperCore.extClientFillStateSelect;
  var extClientUpdateStateDisplay=clientHelperCore.extClientUpdateStateDisplay;
  var extClientFetchJson=clientHelperCore.extClientFetchJson;
  var extClientLoadCities=clientHelperCore.extClientLoadCities;
  var extClientPopulateCityList=clientHelperCore.extClientPopulateCityList;
  var extClientLookupCep=clientHelperCore.extClientLookupCep;



  var createQuickClientContentCore=window.__extCreateQuickClientContentCore;
  if(typeof createQuickClientContentCore!=="function")throw new Error("Core do cadastro rápido do cliente não foi carregado.");
  var quickClientContentCore=createQuickClientContentCore({clientHelpers:clientHelperCore,getActiveContactContext:extGetActiveContactContext,emptyState:extEmptyState,field:extField,iconChip:iconChip,escHtml:escHtml,toast:toast,accent:EXTUI_QR_ACCENT,icon:EXTUI_QR_ICON,brDdds:__extWorkspaceStaticData.EXTUI_CLIENT_BR_DDDS});
  var extRenderQuickClientContent=quickClientContentCore.render;



  function extCoreCommandHostQuickResponse(payload) {
    return extCoreCommandHostOpenBuilt("quick-response",buildQuickResponsePanel,payload);
  }
  function extCoreCommandHostOpenLabels(payload) { return extCoreCommandHostOpenBuilt("labels", buildGlobalLabelsPanel, payload || {}); }

  var createChatWorkspaceRegistryCore=window.__extCreateChatWorkspaceRegistryCore;
  if(typeof createChatWorkspaceRegistryCore!=="function")throw new Error("Registry de workspaces do chat não foi carregado.");
  var chatWorkspaceRegistry=createChatWorkspaceRegistryCore({escHtml:escHtml});
  var extCloseChatWorkspace=chatWorkspaceRegistry.close;
  var extShowCachedChatWorkspace=chatWorkspaceRegistry.showCached;
  var extOpenChatWorkspace=chatWorkspaceRegistry.open;
  var extToggleChatWorkspace=chatWorkspaceRegistry.toggle;

  var createClientWorkspaceCore=window.__extCreateClientWorkspaceCore;
  if(typeof createClientWorkspaceCore!=="function")throw new Error("Core do workspace do cliente não foi carregado.");
  var clientWorkspaceCore=createClientWorkspaceCore({registry:chatWorkspaceRegistry,openChatWorkspace:extOpenChatWorkspace,showCached:extShowCachedChatWorkspace,getActiveContactContext:extGetActiveContactContext,renderQuickClientContent:extRenderQuickClientContent,escHtml:escHtml,toast:toast,openCrmWorkspace:function(){return extOpenCrmWorkspace();},openLabelsWorkspace:function(){return extOpenLabelsWorkspace();},openOrdersWorkspace:function(){return extOpenOrdersWorkspace();},openNotesWorkspace:function(){return extOpenNotesWorkspace();},openAgendaWorkspace:function(){return extOpenAgendaWorkspace();}});
  var extOpenClientWorkspace=clientWorkspaceCore.open;

  var createChatWorkspaceLaunchersCore=window.__extCreateChatWorkspaceLaunchersCore;
  if(typeof createChatWorkspaceLaunchersCore!=="function")throw new Error("Launchers dos workspaces da conversa não foram carregados.");
  var chatWorkspaceLaunchers=createChatWorkspaceLaunchersCore({agendaItemStores:AGENDA_ITEM_STORES,agendaStatusLabels:AGENDA_STATUS_LABELS,quickItemsRecentsKey:QUICK_ITEMS_RECENTS_KEY,get:extGet,parsePersisted:parsePersisted,appendPrioritizedItemOptions:appendPrioritizedItemOptions,getActiveContactContext:extGetActiveContactContext,openChatWorkspace:extOpenChatWorkspace,loadSchedules:loadSchedules,saveSchedules:saveSchedules,fmtDateTime:fmtDateTime,field:extField,escHtml:escHtml,toast:toast,openShellHtml:openShellHtml,crmKey:CRM_KEY,chatTargetDigits:extChatTargetDigits,enableMiddleGrabScroll:extEnableMiddleGrabScroll});
  var extAgendaStartOfWeek=chatWorkspaceLaunchers.agendaStartOfWeek,extAgendaContactSchedules=chatWorkspaceLaunchers.agendaContactSchedules,extAgendaPopulateItems=chatWorkspaceLaunchers.agendaPopulateItems;
  var extOpenAgendaWorkspace=chatWorkspaceLaunchers.openAgenda,extOpenNotesWorkspace=chatWorkspaceLaunchers.openNotes,extCrmWorkspaceMemberships=chatWorkspaceLaunchers.crmMemberships,extOpenCrmWorkspace=chatWorkspaceLaunchers.openCrm,extSafeLabelColor=chatWorkspaceLaunchers.safeLabelColor,extOpenLabelsWorkspace=chatWorkspaceLaunchers.openLabels,extOpenOrdersWorkspace=chatWorkspaceLaunchers.openOrders;

  var quickResponseWorkspaceCore=window.__extCreateQuickResponseWorkspaceCore({getActiveContactContext:extGetActiveContactContext,openChatWorkspace:extOpenChatWorkspace,closeChatWorkspace:extCloseChatWorkspace,openManager:extCoreCommandHostQuickResponse,onKeyChange:extOnKeyChange,escHtml:escHtml,toast:toast,setWorkspaceDisposer:chatWorkspaceRegistry.setDisposer});
  var extOpenQuickResponseWorkspace=quickResponseWorkspaceCore.openQuickResponseWorkspace;

  var createPanelCommandOrchestratorCore=window.__extCreatePanelCommandOrchestratorCore;
  if(typeof createPanelCommandOrchestratorCore!=="function")throw new Error("Orquestrador de comandos dos painéis não foi carregado.");
  panelCommandOrchestrator=createPanelCommandOrchestratorCore({
    PANEL_BRAND:PANEL_BRAND,NAV_ICONS:NAV_ICONS,CHAT_TOOL_META:CHAT_TOOL_META,buildCrmPanel:buildCrmPanel,buildCrmFunnelPanel:buildCrmFunnelPanel,buildOrdersPanel:buildOrdersPanel,buildDeliveryPanel:buildDeliveryPanel,buildEnviosPanel:buildEnviosPanel,buildFluxosPanel:buildFluxosPanel,buildFunisPanel:buildFunisPanel,buildQuickResponsePanel:buildQuickResponsePanel,buildFollowUpPanel:buildFollowUpPanel,buildAgendaPanel:buildAgendaPanel,buildAutoServicePanel:buildAutoServicePanel,buildStatusPanel:buildStatusPanel,buildChatToolsPanel:buildChatToolsPanel,buildNotesStandalonePanel:buildNotesStandalonePanel,buildReminderStandalonePanel:buildReminderStandalonePanel,buildGoogleCalendarStandalonePanel:buildGoogleCalendarStandalonePanel,buildSignatureStandalonePanel:buildSignatureStandalonePanel,buildTextAssistantStandalonePanel:buildTextAssistantStandalonePanel,buildTextReplaceStandalonePanel:buildTextReplaceStandalonePanel,buildGlobalLabelsPanel:buildGlobalLabelsPanel,buildGooglePanel:buildGooglePanel,buildNotificationsPanel:buildNotificationsPanel,buildSystemPanel:buildSystemPanel,buildWebhooksPanel:buildWebhooksPanel,extToggleChatWorkspace:extToggleChatWorkspace,extOpenCrmWorkspace:extOpenCrmWorkspace,extOpenOrdersWorkspace:extOpenOrdersWorkspace,extOpenQuickResponseWorkspace:extOpenQuickResponseWorkspace,extOpenClientWorkspace:extOpenClientWorkspace,extOpenLabelsWorkspace:extOpenLabelsWorkspace,extOpenAgendaWorkspace:extOpenAgendaWorkspace,extOpenNotesWorkspace:extOpenNotesWorkspace,extCoreCommandHostPanelState:extCoreCommandHostPanelState,extCoreCommandHostOpenBuilt:extCoreCommandHostOpenBuilt,extCommandHostOpenExternal:extCommandHostOpenExternal,extCoreCommandHostOpenLabels:extCoreCommandHostOpenLabels,extCoreCommandHostOpenDashboard:extCoreCommandHostOpenDashboard,extCommandHostExportContacts:extCommandHostExportContacts,extCoreCommandHostQuickResponse:extCoreCommandHostQuickResponse,extWorkspace:extWorkspace,extActivityList:extActivityList,ACTIVITY_ACTIVE_STATUSES:ACTIVITY_ACTIVE_STATUSES,extLoadNotifications:extLoadNotifications,syncOnboardingNavContext:function(){return typeof extSyncOnboardingNavContext==="function"?extSyncOnboardingNavContext():undefined;}
  });
  var panelBuilderCatalog=panelCommandOrchestrator.catalog;
  var _navButtonsByPanelId=panelCommandOrchestrator.navButtonsByPanelId;
  window.__extSyncNavActive=extSyncActiveNavButtons;


  var createRailRuntimeCore=window.__extCreateRailRuntimeCore;
  if(typeof createRailRuntimeCore!=="function")throw new Error("Runtime da rail não foi carregado.");
  var railRuntime=createRailRuntimeCore({navIcons:NAV_ICONS,optionsDefaults:OPTIONS_DEFAULTS,newInstallOptionsDefaults:NEW_INSTALL_OPTIONS_DEFAULTS,optionsKey:OPTIONS_KEY,bridgeCall:extBridgeCall,get:extGet,set:extSet,applyMenuVisibility:extApplyMenuVisibility,vectorNavChip:vectorNavChip,openShellHtml:openShellHtml,closeAllPanels:closeAllPanels,refreshPanelDockHost:extRefreshPanelDockHost,applyWorkspaceRect:extApplyWorkspaceRect,clampWorkspaceRect:extClampWorkspaceRect,prunePanelRegistry:extPrunePanelRegistry,syncActiveNavButtons:extSyncActiveNavButtons,activityCounts:extActivityCounts,activityHydrate:extActivityHydrate,activitySubscribe:extActivitySubscribe,bindNotificationRefresh:extBindNotificationRefresh,refreshNotificationBadge:extRefreshNotificationBadge,maybeShowUrgentNotification:extMaybeShowUrgentNotification,navigateRail:extNavigateRail,workspace:extWorkspace,panelBuilderCatalog:panelBuilderCatalog,railNavigation:railNavigation,ensurePanel:ensurePanel,navButtonsByPanelId:_navButtonsByPanelId,toast:toast,initOnboarding:function(){return extInitOnboarding();}});
  var extHydrateOnboardingLogo=railRuntime.hydrateOnboardingLogo,extArmRailBootGate=railRuntime.armBootGate,extResetRailViewLifecycle=railRuntime.resetViewLifecycle;

  var onboardingAcademyCore=window.__extCreateOnboardingAcademyCore({staticData:__extWorkspaceStaticData,navIcons:NAV_ICONS,get:extGet,set:extSet,onKeyChange:extOnKeyChange,hydrateOnboardingLogo:extHydrateOnboardingLogo,openShellHtml:openShellHtml,toast:toast,escHtml:escHtml,closeAllPanels:closeAllPanels});
  var extInitOnboarding=onboardingAcademyCore.init,extSyncOnboardingNavContext=onboardingAcademyCore.syncNavContext;
  optionsRuntime.start();


  var createPanelBootstrapTailCore=window.__extCreatePanelBootstrapTailCore;
  if(typeof createPanelBootstrapTailCore!=="function")throw new Error("Bootstrap final dos painéis não foi carregado.");
  var panelBootstrapTail=createPanelBootstrapTailCore({railRuntime:railRuntime,panelRegistry:panelRegistry,disposePanel:extPanelDispose,chatWorkspaceRegistry:chatWorkspaceRegistry,closeChatWorkspace:extCloseChatWorkspace});
  panelBootstrapTail.start();
})();
}catch(bootError){window.__extRecordBootError(bootError);}
