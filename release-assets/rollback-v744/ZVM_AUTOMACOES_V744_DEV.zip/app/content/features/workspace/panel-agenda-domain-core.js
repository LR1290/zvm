;(function () {
  "use strict";
  if (window.__extCreateAgendaPanelDomainCore) return;
  window.__extCreateAgendaPanelDomainCore = function (deps) {
    deps = deps || {};
    var get = deps.get, set = deps.set, buildPanelShell = deps.buildPanelShell, panelBrand = deps.panelBrand || {}, field = deps.field, parsePersisted = deps.parsePersisted, emptyState = deps.emptyState, iconChip = deps.iconChip, escHtml = deps.escHtml, toast = deps.toast, panelOnKeyChange = deps.panelOnKeyChange, navigateRail = deps.navigateRail;
    var scheduleKey = deps.scheduleKey || "EXTUI:extappScheduleStore", quickItemsRecentsKey = deps.quickItemsRecentsKey || "EXTUI:quickItemsRecents", agendaItemStores = deps.agendaItemStores || {}, agendaStatusLabels = deps.agendaStatusLabels || { scheduled: "Agendado", sent: "Enviado", error: "Erro", cancelled: "Cancelado" };
    if ([get,set,buildPanelShell,field,parsePersisted,emptyState,iconChip,escHtml,toast,panelOnKeyChange,navigateRail].some(function(fn){return typeof fn!=="function";})) throw new TypeError("Dependências do domínio Agenda inválidas.");
    
    function appendPrioritizedItemOptions(select, type, list, recents) {
      var recentRank = {};
      (Array.isArray(recents) ? recents : []).forEach(function (recent, index) { if (recent && recent.type === type) recentRank[recent.id] = index; });
      var ranked = list.map(function (item, index) {
        return { item: item, favorite: !!item.favorite, recentRank: Object.prototype.hasOwnProperty.call(recentRank, item.id) ? recentRank[item.id] : Infinity, index: index };
      }).sort(function (a, b) {
        if (a.favorite !== b.favorite) return a.favorite ? -1 : 1;
        if (a.recentRank !== b.recentRank) return a.recentRank - b.recentRank;
        return a.index - b.index;
      });
      [
        { label: "Favoritos", entries: ranked.filter(function (entry) { return entry.favorite; }) },
        { label: "Recentes", entries: ranked.filter(function (entry) { return !entry.favorite && entry.recentRank !== Infinity; }) },
        { label: "Todos", entries: ranked.filter(function (entry) { return !entry.favorite && entry.recentRank === Infinity; }) }
      ].forEach(function (group) {
        if (!group.entries.length) return;
        var optgroup = document.createElement("optgroup"); optgroup.label = group.label;
        group.entries.forEach(function (entry) { optgroup.appendChild(new Option(entry.item.name || entry.item.id, entry.item.id)); });
        select.appendChild(optgroup);
      });
    }
    
    
    async function loadSchedules() {
      var raw = await get(scheduleKey);
      var parsed = null;
      try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; }
      catch (_) { parsed = null; }
      return (parsed && Array.isArray(parsed.list)) ? parsed.list : [];
    }
    
    async function saveSchedules(list) { await set(scheduleKey, JSON.stringify({ list: list })); }
    function parseLocalDateTimeStrict(value){
      var m=String(value||"").match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if(!m)return NaN;
      var y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]),h=Number(m[4]),mi=Number(m[5]),sec=Number(m[6]||0);
      var dt=new Date(y,mo-1,d,h,mi,sec,0);
      if(dt.getFullYear()!==y||dt.getMonth()!==mo-1||dt.getDate()!==d||dt.getHours()!==h||dt.getMinutes()!==mi||dt.getSeconds()!==sec)return NaN;
      return dt.getTime();
    }
    
    function fmtDateTime(ms) {
      var d = new Date(ms);
      return d.toLocaleDateString("pt-BR") + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    }
    
    
    async function filterVirtualMedia(cfg,list){if(!cfg||!cfg.virtualMediaKind)return list||[];var out=[];for(var i=0;i<(list||[]).length;i++){var item=list[i],kind=String(item&&item.mediaKind||"");if(kind!=="image"&&kind!=="video"){try{var raw=await get(String(item.id)),c=raw?(typeof raw==="string"?JSON.parse(raw):raw):{},mime=String(c.mimeType||c.type||"").toLowerCase(),name=String(c.fileName||c.name||item.name||"").toLowerCase(),data=String(c.data||c.base64||"");kind=c.mediaKind||(/^data:video\//i.test(data)||mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name)?"video":"image");}catch(_){kind="image";}}if(kind===cfg.virtualMediaKind)out.push(item);}return out;}

    async function buildAgendaPanel() {
      if(window.__extPlanGate)await window.__extPlanGate.requireActive();
      var freePlan=!!(window.__extPlanGate&&await window.__extPlanGate.isFree());
      var root = buildPanelShell({ id: "extuiNavAgendaPanel", title: "Agenda", accent: panelBrand.agenda.accent, icon: panelBrand.agenda.icon, eyebrow: "Automação", hint: "Agende o envio de um item para uma data e hora específicas.", size: "md" });
      var body = root.querySelector(".extuiNavPanelBody");
    
      var formWrap = document.createElement("div");
      formWrap.className = "extuiNavAgendaForm";
      var typeSelect = document.createElement("select");
      typeSelect.id = "extuiAgendaTypeSelect";
      Object.keys(agendaItemStores).filter(function(t){return !agendaItemStores[t].legacyOnly&&(!freePlan||!window.__extPlanGate||window.__extPlanGate.itemAllowed(t));}).forEach(function (t) { typeSelect.appendChild(new Option(agendaItemStores[t].label, t)); });
      var itemSelect = document.createElement("select");
      itemSelect.id = "extuiAgendaItemSelect";
      var phoneInput = document.createElement("input"); phoneInput.type = "text"; phoneInput.placeholder = "DDI+DDD+número"; phoneInput.setAttribute("data-agenda-phone", "true");
      var dateInput = document.createElement("input"); dateInput.type = "date"; dateInput.id = "extuiAgendaDateInput";
      var timeInput = document.createElement("input"); timeInput.type = "time";
      var addBtn = document.createElement("button"); addBtn.type = "button"; addBtn.className = "extuiNavPrimaryBtn"; addBtn.textContent = "Agendar";
      formWrap.appendChild(field("Tipo", typeSelect));
      formWrap.appendChild(field("Item", itemSelect));
      formWrap.appendChild(field("Telefone do contato", phoneInput));
      var dateTimeRow = document.createElement("div");
      dateTimeRow.style.display = "flex"; dateTimeRow.style.gap = "8px";
      var dateField = field("Data", dateInput); dateField.style.flex = "1";
      var timeField = field("Hora", timeInput); timeField.style.flex = "1";
      dateTimeRow.appendChild(dateField);
      dateTimeRow.appendChild(timeField);
      formWrap.appendChild(dateTimeRow);
      formWrap.appendChild(addBtn);
      body.appendChild(formWrap);
      var listEl = document.createElement("div");
      listEl.className = "extuiNavAgendaList";
      body.appendChild(listEl);
    
      async function refreshItemOptions() {
        itemSelect.innerHTML = "";
        var cfg = agendaItemStores[typeSelect.value];
        try {
          var values = await Promise.all([get(cfg.key), get(quickItemsRecentsKey)]);
          var raw = values[0];
          var state = parsePersisted(raw);
          var list = (state && state[cfg.listField]) || [];
          list = await filterVirtualMedia(cfg,list);
          if (list.length === 0) { itemSelect.appendChild(new Option("Nenhum item salvo", "")); return; }
          appendPrioritizedItemOptions(itemSelect, typeSelect.value, list, values[1]);
        } catch (err) { itemSelect.appendChild(new Option("Erro ao carregar", "")); }
      }
      typeSelect.addEventListener("change", refreshItemOptions);
      refreshItemOptions();
    
      async function renderList() {
        listEl.innerHTML = '<div class="extuiSideItensEmpty">Carregando...</div>';
        var schedules;
        try { schedules = await loadSchedules(); } catch (err) { listEl.innerHTML = '<div class="extuiSideItensEmpty">Erro ao carregar</div>'; return; }
        if (schedules.length === 0) { listEl.innerHTML = ""; listEl.appendChild(emptyState(panelBrand.agenda.accent, panelBrand.agenda.icon, "Nada agendado ainda", "Escolha um item e uma data/hora no formulário acima para agendar o primeiro envio.", null, null, { sober: true })); return; }
        listEl.innerHTML = "";
        schedules.sort(function (a, b) { return a.scheduleAtMs - b.scheduleAtMs; }).forEach(function (s) {
          var row = document.createElement("div");
          row.className = "extuiNavAgendaRow";
          row.innerHTML = iconChip(panelBrand.agenda.accent, panelBrand.agenda.icon, true) +
            '<div class="extuiNavAgendaRowMid"><div class="name">' + escHtml(s.itemName || s.itemId) + '</div>' +
            '<div class="meta">' + (s.targetChatName ? escHtml(s.targetChatName) + " · " : "") + escHtml(s.targetChatId) + " · " + escHtml(fmtDateTime(s.scheduleAtMs)) + '</div></div>' +
            '<span class="extuiAgendaStatus extuiAgendaStatus--' + escHtml(s.status) + '">' + escHtml(agendaStatusLabels[s.status] || s.status) + '</span>';
          if (s.status === "scheduled") {
            var cancelBtn = document.createElement("button");
            cancelBtn.type = "button"; cancelBtn.className = "extuiNavAgendaCancelBtn"; cancelBtn.textContent = "Cancelar";
            cancelBtn.addEventListener("click", async function () {
              if (!await window.extConfirm("Cancelar este agendamento?", { danger: true })) return;
              s.status = "cancelled";
              try { await saveSchedules(schedules); renderList(); } catch (err) { toast("Falha ao cancelar", true); }
            });
            row.appendChild(cancelBtn);
          }
          listEl.appendChild(row);
        });
      }
      renderList();
      panelOnKeyChange(root, scheduleKey, function () { if (root.classList.contains("extuiOpen")) renderList(); });
    
      addBtn.addEventListener("click", async function () {
        var itemId = itemSelect.value;
        var itemName = itemSelect.options[itemSelect.selectedIndex] ? itemSelect.options[itemSelect.selectedIndex].text : "";
        var phoneDigits = String(phoneInput.value || "").replace(/\D/g, "");
        if (!itemId) { toast("Escolha um item", true); return; }
        if (!phoneDigits) { toast("Informe o telefone", true); return; }
        if (!dateInput.value || !timeInput.value) { toast("Escolha data e hora", true); return; }
        var scheduleAtMs = parseLocalDateTimeStrict(dateInput.value + "T" + timeInput.value);
        if (!Number.isFinite(scheduleAtMs) || scheduleAtMs <= Date.now()) { toast("Escolha uma data/hora futura válida", true); return; }
        addBtn.disabled = true;
        try {
          var list = await loadSchedules();
          if(freePlan&&window.__extPlanGate){var activeCount=list.filter(function(x){return x&&["scheduled","retrying","sending"].indexOf(x.status)>=0;}).length;await window.__extPlanGate.requireScheduleCapacity(activeCount);}
          var conflict = list.some(function (s) { return s.status === "scheduled" && s.targetChatId === phoneDigits && Math.abs(s.scheduleAtMs - scheduleAtMs) < 60000; });
          if (conflict) { toast("Conflito de horário para esse número", true); addBtn.disabled = false; return; }
          list.push({ id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())), type: typeSelect.value, itemId: itemId, itemName: itemName, targetChatId: phoneDigits, targetChatName: "", scheduleAtMs: scheduleAtMs, status: "scheduled", createdAt: Date.now(), sentAt: null, errorMessage: null });
          await saveSchedules(list);
          if(freePlan&&window.__extPlanGate){var nextCount=list.filter(function(x){return x&&["scheduled","retrying","sending"].indexOf(x.status)>=0;}).length;try{await window.__extPlanGate.usageCommit("scheduleItem",nextCount);}catch(err){list=list.filter(function(x){return x&&x.id!==list[list.length-1].id;});await saveSchedules(list);throw err;}}
          toast("Agendado!");
          phoneInput.value = ""; dateInput.value = ""; timeInput.value = "";
        } catch (err) { toast("Falha ao agendar", true); }
        finally { addBtn.disabled = false; }
      });
      return root;
    }
    
    
    
    async function scheduleViaAgenda(type, itemId) {
      if(window.__extPlanGate)await window.__extPlanGate.requireActive();
      if (!agendaItemStores[type]) { toast("Este tipo de item não pode ser agendado.", true); return; }
      if(window.__extPlanGate&&await window.__extPlanGate.isFree()&&!window.__extPlanGate.itemAllowed(type)){await window.__extPlanGate.requirePaid("Este tipo de agendamento").catch(function(){});return;}
      var result = await navigateRail("agenda", { ensureOpen: true, source: "schedule" });
      if (!result || !result.panelReady) { toast("Agenda ainda não carregou - tente novamente em instantes.", true); return; }
      setTimeout(async function () {
        var typeSelectEl = document.getElementById("extuiAgendaTypeSelect");
        var itemSelectEl = document.getElementById("extuiAgendaItemSelect");
        var phoneInputEl = document.querySelector('#extuiNavAgendaPanel [data-agenda-phone="true"]');
        var dateInputEl = document.getElementById("extuiAgendaDateInput");
        if (!typeSelectEl || !itemSelectEl) return;
        typeSelectEl.value = type;
        typeSelectEl.dispatchEvent(new Event("change"));
    
    
        setTimeout(function () {
          if (itemSelectEl.querySelector('option[value="' + itemId + '"]')) itemSelectEl.value = itemId;
        }, 400);
        if (phoneInputEl && !phoneInputEl.value && window.ExtensionChatBridge && window.ExtensionChatBridge.isReady && window.ExtensionChatBridge.chat && typeof window.ExtensionChatBridge.chat.getActiveChat === "function") {
          try {
            var activeChat = await window.ExtensionChatBridge.chat.getActiveChat();
            if (activeChat && activeChat.id && activeChat.id.server === "c.us") phoneInputEl.value = activeChat.id.user;
          } catch (err) {                                                                            }
        }
        if (dateInputEl) dateInputEl.focus();
      }, 50);
    }
    return Object.freeze({ scheduleKey:scheduleKey, quickItemsRecentsKey:quickItemsRecentsKey, agendaItemStores:agendaItemStores, agendaStatusLabels:agendaStatusLabels, appendPrioritizedItemOptions:appendPrioritizedItemOptions, loadSchedules:loadSchedules, saveSchedules:saveSchedules, fmtDateTime:fmtDateTime, buildAgendaPanel:buildAgendaPanel, scheduleViaAgenda:scheduleViaAgenda });
  };
})();
