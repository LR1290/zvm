;(function(root,factory){"use strict";if(root)root.__extCreatePanelUiPrimitivesCore=factory;})(typeof window!=="undefined"?window:null,function(deps){
  "use strict";
  deps=deps||{};
  var NAV_ICONS=deps.navIcons||{};
  var primitiveRuntime={ fieldIdSeed:0, switchState:new WeakMap() };
  function parsePersisted(raw) {
    if (!raw) return null;
    try {
      var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
      return (parsed && parsed.state) || null;
    } catch (err) { return null; }
  }

  function escHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }


  function extField(labelText, controlEl, helperText) {
    var wrap = document.createElement("div");
    wrap.className = "extuiFieldGroup";
    var labelable = !!(controlEl && controlEl.tagName && /^(INPUT|SELECT|TEXTAREA)$/.test(controlEl.tagName));
    var label = document.createElement(labelable ? "label" : "span");
    label.className = "extuiFieldLabel";
    label.textContent = labelText;
    if (labelable) {
      if (!controlEl.id) controlEl.id = "extui-field-" + (++primitiveRuntime.fieldIdSeed);
      label.setAttribute("for", controlEl.id);
    }
    wrap.appendChild(label);
    wrap.appendChild(controlEl);
    if (helperText) {
      var helper = document.createElement("span");
      helper.className = "extuiFieldHelper";
      helper.textContent = helperText;
      helper.id = (controlEl && controlEl.id ? controlEl.id : "extui-field-help-" + (++primitiveRuntime.fieldIdSeed)) + "-help";
      if (controlEl && controlEl.setAttribute) {
        var describedBy = String(controlEl.getAttribute("aria-describedby") || "").trim();
        controlEl.setAttribute("aria-describedby", (describedBy ? describedBy + " " : "") + helper.id);
      }
      wrap.appendChild(helper);
    }
    return wrap;
  }


  function vectorNavChip(iconInner, iconKey) {
    var chip = document.createElement("span");
    chip.className = "extuiNavIconChip extuiNavVectorChip";
    chip.setAttribute("aria-hidden", "true");
    chip.setAttribute("data-extui-icon-key", String(iconKey || "fallback"));
    var safeIcon = (typeof iconInner === "string" && /<(?:path|rect|circle|line|polyline|polygon|ellipse)\b/i.test(iconInner)) ? iconInner : NAV_ICONS.sistema;
    chip.innerHTML = '<svg class="extuiNavVectorGlyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" focusable="false">' + safeIcon + '</svg>';
    var svg = chip.querySelector("svg");
    if (!svg || !svg.firstElementChild) {
      chip.innerHTML = '<svg class="extuiNavVectorGlyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" focusable="false">' + NAV_ICONS.sistema + '</svg>';
      chip.setAttribute("data-extui-icon-fallback", "true");
    }
    return chip;
  }


  function extEmptyState(accent, iconInner, heading, desc, ctaLabel, ctaFn, opts) {
    opts = opts || {};
    var wrap = document.createElement("div");
    wrap.className = "extEmptyState";
    var badge = document.createElement("div");
    badge.className = "extuiEmptyStateIcon" + (opts.sober ? " extuiEmptyStateIconSober" : "");
    badge.style.setProperty("--c", accent);
    badge.innerHTML = '<svg viewBox="0 0 24 24" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">' + iconInner + '</svg>';
    wrap.appendChild(badge);
    wrap.appendChild(Object.assign(document.createElement("div"), { className: "extuiEmptyStateHeading", textContent: heading }));
    if (desc) wrap.appendChild(Object.assign(document.createElement("div"), { className: "extuiEmptyStateDesc", textContent: desc }));
    if (ctaLabel) {
      var btn = document.createElement("button");
      btn.type = "button"; btn.className = "extui-btn extui-btn--primary"; btn.textContent = ctaLabel;
      btn.addEventListener("click", ctaFn);
      wrap.appendChild(btn);
    }
    return wrap;
  }


  function extBuildSwitch(checked, onToggle) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "extuiSwitch";
    btn.setAttribute("role", "switch");
    var knob = document.createElement("span");
    knob.className = "extuiSwitchKnob";
    btn.appendChild(knob);
    primitiveRuntime.switchState.set(btn, !!checked);
    extPaintSwitch(btn);
    btn.addEventListener("click", async function () {
      if (btn.disabled || btn.getAttribute("aria-busy") === "true") return;
      var previous = !!primitiveRuntime.switchState.get(btn);
      var next = !previous;
      primitiveRuntime.switchState.set(btn, next);
      extPaintSwitch(btn);
      btn.disabled = true;
      btn.setAttribute("aria-busy", "true");
      var ok = true;
      try {
        if (typeof onToggle === "function") ok = await onToggle(next, previous);
      } catch (_) {
        ok = false;
      } finally {
        if (ok === false) {
          primitiveRuntime.switchState.set(btn, previous);
          extPaintSwitch(btn);
        }
        btn.disabled = false;
        btn.removeAttribute("aria-busy");
      }
    });
    return btn;
  }


  function extPaintSwitch(btn) {
    var on = !!primitiveRuntime.switchState.get(btn);
    btn.setAttribute("aria-checked", String(on));
    var knob = btn.querySelector(".extuiSwitchKnob");
    btn.style.setProperty("background", on ? "var(--extui-primary, #00c85a)" : "var(--extui-card-2, #151515)");
    btn.style.setProperty("border-color", on ? "var(--extui-primary, #00c85a)" : "var(--extui-border, #1e1e1e)");


    if (knob) knob.style.setProperty("transform", on ? "translateX(21px)" : "translateX(0)");
  }
  function extRepaintAllSwitches(scope) { (scope || document).querySelectorAll(".extuiSwitch").forEach(extPaintSwitch); }


  function extPanelFormSection(title, desc) {
    var head = document.createElement("div");
    head.className = "extuiPanelFormSectionHead";
    var copy = document.createElement("div");
    copy.className = "extuiPanelFormSectionCopy";
    var strong = document.createElement("strong");
    strong.textContent = title || "";
    copy.appendChild(strong);
    if (desc) {
      var small = document.createElement("span");
      small.textContent = desc;
      copy.appendChild(small);
    }
    head.appendChild(copy);
    return head;
  }

  function extPanelChoiceDeck(select, items, columns) {
    var deck = document.createElement("div");
    deck.className = "extPanelChoiceDeck";
    deck.style.setProperty("--extui-choice-columns", String(columns || items.length || 2));
    deck.setAttribute("role", "radiogroup");
    select.classList.add("extuiPanelChoiceNative");
    select.setAttribute("aria-hidden", "true");
    select.tabIndex = -1;
    var buttons = [];
    items.forEach(function (item) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "extuiPanelChoiceCard";
      btn.setAttribute("role", "radio");
      btn.dataset.value = item.value;
      btn.innerHTML = '<span class="extuiPanelChoiceIcon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + item.icon + '</svg></span><span class="extuiPanelChoiceText"><strong>' + escHtml(item.title) + '</strong>' + (item.desc ? '<small>' + escHtml(item.desc) + '</small>' : '') + '</span><span class="extuiPanelChoiceCheck"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 10 3 3 7-7"/></svg></span>';
      btn.addEventListener("click", function () {
        if (select.value === item.value) return;
        select.value = item.value;
        select.dispatchEvent(new Event("change", { bubbles: true }));
      });
      buttons.push(btn);
      deck.appendChild(btn);
    });
    function sync() {
      buttons.forEach(function (btn) {
        var active = btn.dataset.value === select.value;
        btn.classList.toggle("extuiActive", active);
        btn.setAttribute("aria-checked", String(active));
        btn.tabIndex = active ? 0 : -1;
      });
    }
    select.addEventListener("change", sync);
    deck.addEventListener("keydown", function (ev) {
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].indexOf(ev.key) < 0) return;
      var current = Math.max(0, buttons.findIndex(function (btn) { return btn.dataset.value === select.value; }));
      var step = ev.key === "ArrowLeft" || ev.key === "ArrowUp" ? -1 : 1;
      var next = (current + step + buttons.length) % buttons.length;
      ev.preventDefault();
      buttons[next].click();
      buttons[next].focus();
    });
    sync();
    return deck;
  }
  function iconChip(accent, svgInner, small) {


    return '<span class="extuiNavIconChip' + (small ? " extuiNavIconChip--sm" : "") + '" style="--c:' + accent + ';">' +
      '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + svgInner + '</svg>' +
      '</span>';
  }



  return Object.freeze({
    parsePersisted:parsePersisted,escHtml:escHtml,field:extField,vectorNavChip:vectorNavChip,emptyState:extEmptyState,
    buildSwitch:extBuildSwitch,paintSwitch:extPaintSwitch,repaintAllSwitches:extRepaintAllSwitches,
    formSection:extPanelFormSection,choiceDeck:extPanelChoiceDeck,iconChip:iconChip
  });
});
