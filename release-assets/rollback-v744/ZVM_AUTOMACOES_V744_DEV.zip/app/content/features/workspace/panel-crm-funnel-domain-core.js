;(function(){
  "use strict";
  if(window.__extCreateCrmFunnelPanelDomainCore)return;
  window.__extCreateCrmFunnelPanelDomainCore=function(deps){
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,PANEL_BRAND=deps.panelBrand||{},panelBody=deps.panelBody,extGet=deps.get,extSet=deps.set,extEmptyState=deps.emptyState,extPanelOnKeyChange=deps.panelOnKeyChange,extField=deps.field,openShellHtml=deps.openShellHtml,escHtml=deps.escHtml,CRM_KEY=deps.crmKey||"EXTUI:CrmStore",CRM_PROFESSIONAL_KEY=deps.crmProfessionalKey||"EXTUI:crmProfessionalStore";
    if([buildPanelShell,panelBody,extGet,extSet,extEmptyState,extPanelOnKeyChange,extField,openShellHtml,escHtml].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do domínio Funil CRM inválidas.");

    function buildCrmFunnelPanel(){
      var root=buildPanelShell({id:"extuiNavCrmFunnelPanel",title:"Funil CRM",accent:PANEL_BRAND.crmFunnel.accent,icon:PANEL_BRAND.crmFunnel.icon,eyebrow:"Análise",hint:"Veja os principais indicadores do CRM sem sair da conversa.",size:"md",tutorialKey:"crm-funnel",footer:true});
      var body=panelBody(root),content=document.createElement("div");content.className="extuiCrmFunnelDock extuiAnalyticsSurface";body.appendChild(content);
      var footer=root.querySelector("[data-extui-panel-footer]");if(footer){footer.hidden=false;footer.classList.add("extuiCrmFunnelFooter");}
      var open=document.createElement("button");open.type="button";open.className="extuiNavSecondaryBtn extuiCrmFunnelOpenFull";open.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19V9M10 19V5M16 19v-7M22 19H2"/></svg><span>Abrir análise completa</span>';if(footer)footer.appendChild(open);else body.appendChild(open);
      function parse(v,fallback){try{if(typeof v==="string")v=JSON.parse(v);return v==null?fallback:v;}catch(_){return fallback;}}
      function num(v){var n=Number(v);return Number.isFinite(n)?n:0;}
      function money(v){try{return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL",maximumFractionDigits:2}).format(num(v));}catch(_){return "R$ "+num(v).toFixed(2).replace(".",",");}}
      function digits(v){return String(v||"").replace(/\D/g,"");}
      function profileArray(raw){var q=parse(raw,[]);if(Array.isArray(q))return q;if(q&&Array.isArray(q.perfil))return q.perfil;if(q&&Array.isArray(q.list))return q.list;return [];}
      function crmListFromRaw(raw){var q=parse(raw,{});var list=q&&q.state&&Array.isArray(q.state.crmList)?q.state.crmList:(q&&Array.isArray(q.crmList)?q.crmList:[]);return list.filter(function(c){return c&&Number(c.archivedAtInMs||0)<=0;});}
      function legacyValueIndex(raw){var out={};profileArray(raw).forEach(function(x){if(!x||typeof x!=="object")return;var phone=digits(x.userID||x.phoneNumber||x.phone||x.number||x.id);if(phone.length<8)return;var v=num(x.valNegocio!=null?x.valNegocio:(x.dealValue!=null?x.dealValue:(x.valorNegocio!=null?x.valorNegocio:x.value)));if(v)out[phone]=v;});return out;}
      function professionalValue(proStore,crm,item){if(!proStore||!crm||!item)return 0;var board=(proStore.boards||{})[crm.id]||{},defs=Array.isArray(board.fieldDefinitions)?board.fieldDefinitions:[],fields=defs.filter(function(d){return d&&d.type==="number"&&/(valor|neg[oó]cio|receita|ticket|revenue|deal)/i.test(String(d.label||d.id||""));});if(!fields.length)return 0;var prof=proStore.contacts&&proStore.contacts[item.id];if(!prof||!prof.fieldValues)return 0;return fields.reduce(function(sum,d){return sum+num(prof.fieldValues[d.id]);},0);}
      function itemValue(item,legacy,proStore,crm){var direct=num(item&&((item.valNegocio!=null&&item.valNegocio)||(item.dealValue!=null&&item.dealValue)||(item.businessValue!=null&&item.businessValue)||(item.contact&&item.contact.valNegocio)));if(direct)return direct;var pv=professionalValue(proStore,crm,item);if(pv)return pv;return legacy[digits(item&&item.contact&&item.contact.phoneNumber)]||0;}
      function stagesFor(crm,legacy,proStore){return(crm.columns||[]).map(function(c,i){var contacts=(c.items||[]).length,value=(c.items||[]).reduce(function(sum,item){return sum+itemValue(item,legacy,proStore,crm);},0);return{id:c.id,label:c.title||("Etapa "+(i+1)),contacts:contacts,value:value,color:c.color||c.hexColor||["#10b981","#38bdf8","#8b5cf6","#f59e0b","#f43f5e","#14b8a6"][i%6]};});}
      async function render(){
        var values=await Promise.all([extGet(CRM_KEY),extGet(CRM_PROFESSIONAL_KEY),extGet("EXTUI:profileStore"),extGet("EXTUI:crmFunnelAnalyticsStore")]);
        var list=crmListFromRaw(values[0]),core=window.__extCrmProfessionalCore,pro=core?core.normalizeStore(values[1]):parse(values[1],{}),legacy=legacyValueIndex(values[2]),prefs=parse(values[3],{})||{};
        content.innerHTML="";
        if(!list.length){
          var empty=extEmptyState(PANEL_BRAND.crmFunnel.accent,PANEL_BRAND.crmFunnel.icon,"Nenhum CRM disponível","Crie um CRM para começar a acompanhar conversão e distribuição por etapa.","Criar CRM",function(){openShellHtml("crm",{crmView:"hub",crmCreate:true,newTab:true});},{sober:true});content.appendChild(empty);open.disabled=true;open.onclick=null;return;
        }
        var select=document.createElement("select");list.forEach(function(c){select.appendChild(new Option(c.name||c.id,c.id));});select.value=list.some(function(c){return String(c.id)===String(prefs.crmId||"");})?String(prefs.crmId):String(list[0].id);
        var selector=extField("CRM analisado",select,"A pirâmide mostra a distribuição atual por etapa.");selector.classList.add("extuiCrmFunnelSelector");content.appendChild(selector);
        var chart=document.createElement("div");chart.className="extuiCrmFunnelMini";content.appendChild(chart);
        function paint(){
          chart.innerHTML="";var crm=list.find(function(c){return String(c.id)===String(select.value);})||list[0],stages=stagesFor(crm,legacy,pro),total=stages.reduce(function(a,x){return a+x.contacts;},0),totalValue=stages.reduce(function(a,x){return a+x.value;},0),first=stages[0]&&stages[0].contacts||0,last=stages[stages.length-1]&&stages[stages.length-1].contacts||0,conversion=first?last/first*100:0,ticket=total?totalValue/total:0;
          var k=document.createElement("div");k.className="extuiCrmFunnelMiniKpis";[[String(total),"Contatos"],[conversion.toLocaleString("pt-BR",{maximumFractionDigits:1})+"%","Conversão"],[money(ticket),"Ticket médio"],[money(totalValue),"Receita"]].forEach(function(x){var card=document.createElement("div");card.className="extuiMetricCard";card.innerHTML='<span>'+escHtml(x[1])+'</span><strong>'+escHtml(x[0])+'</strong>';k.appendChild(card);});chart.appendChild(k);
          if(!stages.length){chart.appendChild(extEmptyState(PANEL_BRAND.crmFunnel.accent,PANEL_BRAND.crmFunnel.icon,"Sem etapas","Este CRM ainda não possui etapas configuradas.",null,null,{sober:true}));return;}
          var pyramid=document.createElement("div");pyramid.className="extuiCrmFunnelPyramidMini";var max=Math.max.apply(Math,stages.map(function(x){return x.contacts;}).concat([1]));stages.forEach(function(stage,i){var seg=document.createElement("div");seg.className="extuiCrmFunnelPyramidSegment";seg.style.width=Math.max(24,stage.contacts/max*100)+"%";seg.style.setProperty("--stage-color",stage.color);seg.title=stage.label+" · "+stage.contacts+" contato(s) · "+money(stage.value);seg.innerHTML='<span>'+escHtml(stage.label)+'</span><strong>'+stage.contacts+'</strong>';pyramid.appendChild(seg);});chart.appendChild(pyramid);
          var legend=document.createElement("div");legend.className="extuiCrmFunnelMiniLegend";stages.forEach(function(stage){var row=document.createElement("div");row.innerHTML='<i style="--stage-color:'+escHtml(stage.color)+'"></i><span title="'+escHtml(stage.label)+'">'+escHtml(stage.label)+'</span><strong>'+stage.contacts+' · '+escHtml(money(stage.value))+'</strong>';legend.appendChild(row);});chart.appendChild(legend);
        }
        select.addEventListener("change",async function(){prefs.crmId=select.value;await extSet("EXTUI:crmFunnelAnalyticsStore",JSON.stringify(Object.assign({},prefs,{crmId:select.value})));paint();});
        open.disabled=false;open.onclick=async function(){try{await extSet("EXTUI:crmFunnelAnalyticsStore",JSON.stringify(Object.assign({},prefs,{crmId:select.value})));}catch(_){}openShellHtml("crm-funnel",{crmId:select.value,reuseExisting:true});};paint();
      }
      function renderFailure(error){content.innerHTML="";content.appendChild(extEmptyState(PANEL_BRAND.crmFunnel.accent,PANEL_BRAND.crmFunnel.icon,"Não foi possível carregar a análise","Tente novamente. Se o problema continuar, recarregue o WhatsApp Web.","Tentar novamente",function(){rerender();},{sober:true}));open.disabled=true;open.onclick=null;}
      function rerender(){return render().catch(renderFailure);}
      rerender();extPanelOnKeyChange(root,CRM_KEY,rerender);extPanelOnKeyChange(root,CRM_PROFESSIONAL_KEY,rerender);return root;
    }
    return Object.freeze({buildCrmFunnelPanel:buildCrmFunnelPanel});
  };
})();
