;
(function () {
  "use strict";
  if (window.__extCreateWorkspaceContext) return;
  window.__extCreateWorkspaceContext = function (config) {
    config = config || {};
    var getActivePanel = typeof config.getActivePanel === "function" ? config.getActivePanel : function () { return null; };
    var minWidth = 420, minHeight = 320, viewportMargin = 16, chatAnchorGap = 5;
    var sizeHints = { sm: { width: 660, height: 620 }, md: { width: 780, height: 720 }, lg: { width: 920, height: 780 } };
    var resizeDirs = ["n", "ne", "e", "se", "s", "sw", "w", "nw"];
    var dragExcludeSelector = "button, input, select, textarea, a, [role='menu'], [role='menuitem'], .extuiWorkspaceResizeHandle";
    var state = { movable: false, resizable: false, roots: Object.create(null), panelOpenMode: "docked", dockHost: null };

    function clampNum(v, min, max) { return Math.min(Math.max(v, min), max); }
    function viewport() {
      var left = 0, right = window.innerWidth;
      if (window.__EXT_SIDEBAR_ENABLED__ === true) {
        var v2 = document.getElementById("ext-sidebar-host");
        if (v2 && v2.isConnected && !v2.hidden) {
          var vr = v2.getBoundingClientRect();
          if (vr.width > 0) {
            var v2OnRight = v2.getAttribute("data-placement") === "right-conversation" || document.documentElement.getAttribute("data-extui-sidebar-placement") === "right-conversation";
            if (v2OnRight) right = Math.min(right, Math.floor(vr.left));
            else left = Math.max(left, Math.ceil(vr.right));
          }
        }
      } else {
        var rail = document.getElementById("extapp-sidebar-nav-root");
        if (rail && !rail.classList.contains("extuiNavBarHidden")) {
          var rr = rail.getBoundingClientRect();
          if (rr.width > 0) {
            if (rail.getAttribute("data-extui-dock-side") === "left-native") left = Math.max(left, Math.ceil(rr.right));
            else right = Math.min(right, Math.floor(rr.left));
          }
        }
      }
      return { left: left, right: right, width: Math.max(0, right - left), height: window.innerHeight };
    }
    function clampRect(rect) {
      var vp = viewport();
      var margin = Math.min(viewportMargin, Math.max(6, Math.floor(Math.min(vp.width, vp.height) * 0.025)));
      var maxW = Math.max(240, vp.width - margin * 2);
      var maxH = Math.max(260, vp.height - margin * 2);
      var minW = Math.min(minWidth, maxW);
      var minH = Math.min(minHeight, maxH);
      var width = clampNum(rect.width, minW, maxW);
      var height = clampNum(rect.height, minH, maxH);
      var left = clampNum(rect.left, vp.left + margin, Math.max(vp.left + margin, vp.right - width - margin));
      var top = clampNum(rect.top, margin, Math.max(margin, vp.height - height - margin));
      return { left: left, top: top, width: width, height: height };
    }
    function applyRect(root, rect) {
      root.style.left = rect.left + "px";
      root.style.top = rect.top + "px";
      root.style.width = rect.width + "px";
      root.style.height = rect.height + "px";
    }
    function setVisibility(root, open) {
      if (!root) return;
      root.classList.toggle("extuiOpen", !!open);
      root.hidden = !open;
      root.setAttribute("aria-hidden", open ? "false" : "true");
      try { root.inert = !open; } catch (_) {}
    }
    function normalizePanelOpenMode(value) { return value === "floating" ? "floating" : "docked"; }
    function panelOpenMode() { return normalizePanelOpenMode(state.panelOpenMode); }
    function panelDockWidth() { return clampNum(Math.round(window.innerWidth * 0.31), 440, 560); }
    function panelDockTargetRect(ctx) {
      var app = document.getElementById("app");
      var main = document.getElementById("main");
      var side = document.getElementById("side");
      var appRect = app && app.getBoundingClientRect ? app.getBoundingClientRect() : null;
      var mainRect = main && main.getBoundingClientRect ? main.getBoundingClientRect() : null;
      var sideRect = side && side.getBoundingClientRect ? side.getBoundingClientRect() : null;
      var left = appRect && appRect.width > 0 ? appRect.left : 0;
      var right = mainRect && mainRect.width > 0 ? mainRect.left : (sideRect && sideRect.width > 0 ? sideRect.right : left + panelDockWidth());
      var top = appRect && appRect.height > 0 ? appRect.top : 0;
      var bottom = appRect && appRect.height > 0 ? appRect.bottom : window.innerHeight;
      if (ctx && ctx.rail && ctx.v2 && appRect && appRect.width > 0) {
        var rr = ctx.rail.getBoundingClientRect();
        var railOnRight = ctx.rail.getAttribute("data-placement") === "right-conversation" || document.documentElement.getAttribute("data-extui-sidebar-placement") === "right-conversation";
        var followRightRail = railOnRight && document.documentElement.getAttribute("data-extui-right-panels-follow-rail") === "true";
        if (!railOnRight) left = Math.max(left, rr.right);
        else if (followRightRail) {
          right = Math.min(appRect.right, rr.left);
          var conversationLeft = mainRect && mainRect.width > 0 ? mainRect.left : Math.max(appRect.left, right - panelDockWidth());
          left = Math.max(conversationLeft, right - panelDockWidth());
        } else right = Math.min(right, rr.left);
      }
      var width = Math.max(0, right - left);
      if (width < 320) {
        width = panelDockWidth();
        if (ctx && ctx.rail) {
          var fallbackRail = ctx.rail.getBoundingClientRect();
          var fallbackRight = ctx.v2 && (ctx.rail.getAttribute("data-placement") === "right-conversation" || document.documentElement.getAttribute("data-extui-sidebar-placement") === "right-conversation");
          left = fallbackRight ? Math.max(0, fallbackRail.left - width) : Math.max(0, fallbackRail.right);
        }
      }
      return { left: Math.round(left), top: Math.round(top), width: Math.round(width), height: Math.max(320, Math.round(bottom - top)) };
    }
    function clearInlineRect(root) {
      if (!root) return;
      ["left","right","top","bottom","width","height","maxWidth","maxHeight"].forEach(function (name) { root.style.removeProperty(name.replace(/[A-Z]/g, function (m) { return "-" + m.toLowerCase(); })); });
    }
    function panelDockContext() {
      var v2Rail = window.__EXT_SIDEBAR_ENABLED__ === true ? document.getElementById("ext-sidebar-host") : null;
      if (v2Rail && v2Rail.isConnected) return { rail: v2Rail, parent: document.body, v2: true };
      var rail = document.getElementById("extapp-sidebar-nav-root");
      if (!rail || !rail.isConnected || rail.classList.contains("extuiNavBarHidden")) return null;
      var parent = rail.parentElement;
      if (!parent) return null;
      return { rail: rail, parent: parent, v2: false };
    }
    function ensureDockHost() {
      var host = state.dockHost && state.dockHost.isConnected ? state.dockHost : document.getElementById("extapp-panel-dock-host");
      if (!host) {
        host = document.createElement("aside");
        host.id = "extapp-panel-dock-host";
        host.className = "extuiPanelDockHost";
        host.setAttribute("aria-label", "Painel extensão - Automações acoplado");
        host.hidden = true;
      }
      state.dockHost = host;
      var ctx = panelDockContext();
      if (ctx && ctx.rail.classList.contains("extuiInlineDock")) {
        host.classList.remove("extuiPanelDockHost--fallback");
        host.style.removeProperty("left"); host.style.removeProperty("top"); host.style.removeProperty("height");
        if (host.parentElement !== ctx.parent || host.previousElementSibling !== ctx.rail) ctx.parent.insertBefore(host, ctx.rail.nextSibling);
      } else {
        if (host.parentElement !== document.body) document.body.appendChild(host);
        host.classList.add("extuiPanelDockHost--fallback");
        var target = panelDockTargetRect(ctx);
        host.style.left = target.left + "px";
        host.style.top = target.top + "px";
        host.style.setProperty("height", target.height + "px");
        host.style.setProperty("--extui-panel-dock-width", target.width + "px");
      }
      if (!host.classList.contains("extuiPanelDockHost--fallback")) host.style.setProperty("--extui-panel-dock-width", panelDockWidth() + "px");
      return host;
    }
    function deactivateDockHost() {
      var host = state.dockHost || document.getElementById("extapp-panel-dock-host");
      if (host) host.hidden = true;
    }
    function releaseFromDock(root) {
      if (!root) return;
      if (root.parentElement && root.parentElement.id === "extapp-panel-dock-host") document.body.appendChild(root);
      root.classList.remove("extuiPanelDocked");
      root.classList.add("extuiPanelFloating");
      root.setAttribute("data-extui-panel-mode", "floating");
    }
    function dockPanel(root) {
      if (!root) return;
      var host = ensureDockHost();
      host.hidden = false;
      if (root.parentElement !== host) host.appendChild(root);
      clearInlineRect(root);
      root.classList.remove("extuiPanelFloating");
      root.classList.add("extuiPanelDocked");
      root.setAttribute("data-extui-panel-mode", "docked");
    }
    function placeFloatingNearRightRail(root) {
      if (!root || document.documentElement.getAttribute("data-extui-sidebar-placement") !== "right-conversation" || document.documentElement.getAttribute("data-extui-right-panels-follow-rail") !== "true") return;
      var rail = document.getElementById("ext-sidebar-host"), main = document.getElementById("main");
      if (!rail || !rail.isConnected || !main) return;
      var rr = rail.getBoundingClientRect(), mr = main.getBoundingClientRect(), pr = root.getBoundingClientRect();
      var gap = 8, available = Math.max(0, rr.left - mr.left - gap * 2);
      if (available < 360 || pr.width <= 0) return;
      var width = Math.min(pr.width, available), height = pr.height;
      var left = Math.max(mr.left + gap, rr.left - gap - width);
      var top = clampNum(pr.top, viewportMargin, Math.max(viewportMargin, window.innerHeight - height - viewportMargin));
      applyRect(root, { left: left, top: top, width: width, height: height });
    }
    function chatAreaRect() {
      var main = document.getElementById("main");
      if (!main) return null;
      var footer = main.querySelector("footer");
      if (!footer) return null;
      var mainRect = main.getBoundingClientRect();
      var footerRect = footer.getBoundingClientRect();
      if (!mainRect.width || !mainRect.height || !footerRect.width) return null;
      var header = main.querySelector("header");
      var headerRect = header ? header.getBoundingClientRect() : null;
      var top = (headerRect && headerRect.width) ? headerRect.bottom : mainRect.top;
      return { left: mainRect.left, width: mainRect.width, top: top, bottom: footerRect.top };
    }
    function center(root, sizeKey) {
      var hint = sizeHints[sizeKey] || sizeHints.md;
      var chat = chatAreaRect();
      if (chat && chat.width > 0 && chat.bottom > chat.top) {
        var availableHeight = Math.max(minHeight, chat.bottom - chat.top - chatAnchorGap * 2);
        var width = Math.min(hint.width, Math.max(360, chat.width - 28));
        var height = Math.min(hint.height, Math.max(minHeight, availableHeight));
        if (sizeKey === "lg" && chat.width > 1180) width = Math.min(1040, chat.width - 36);
        if (sizeKey === "sm" && chat.width < 620) width = Math.max(360, chat.width - 20);
        var anchored = clampRect({ width: width, height: height, left: chat.left + (chat.width - width) / 2, top: chat.top + Math.max(chatAnchorGap, (availableHeight - height) / 2) });
        applyRect(root, anchored);
        return;
      }
      var vp = viewport();
      var widthFallback = Math.min(hint.width, Math.max(360, vp.width - 32));
      var heightFallback = Math.min(hint.height, Math.max(minHeight, vp.height - 32));
      applyRect(root, clampRect({ width: widthFallback, height: heightFallback, left: vp.left + (vp.width - widthFallback) / 2, top: (vp.height - heightFallback) / 2 }));
    }
    function floatPanel(root) {
      if (!root) return;
      releaseFromDock(root);
      deactivateDockHost();
      center(root, (root.getAttribute&&root.getAttribute("data-panel-size-key")) || "md");
      placeFloatingNearRightRail(root);
    }
    function applyOpenMode(root) {
      if (!root) return;
      if (panelOpenMode() === "docked") dockPanel(root); else floatPanel(root);
    }
    function setPanelOpenMode(value, reflow) {
      var next = normalizePanelOpenMode(value);
      var changed = next !== state.panelOpenMode;
      state.panelOpenMode = next;
      document.documentElement.setAttribute("data-extui-panel-open-mode", next);
      var active = getActivePanel();
      if (reflow !== false && active) applyOpenMode(active);
      if (changed) window.dispatchEvent(new CustomEvent("ext:panel-open-mode", { detail: { mode: next } }));
      return next;
    }
    function refreshDockHost() {
      var active = getActivePanel();
      if (panelOpenMode() !== "docked" || !active) return;
      var host = ensureDockHost();
      host.hidden = false;
      if (active.parentElement !== host) host.appendChild(active);
    }
    function reflowForSidebar() {
      var active = getActivePanel();
      if (window.__EXT_SIDEBAR_ENABLED__ !== true || !active) return;
      if (panelOpenMode() === "docked") refreshDockHost(); else floatPanel(active);
    }
    function resetGeometry() {
      Object.keys(state.roots).forEach(function (id) {
        var root = state.roots[id];
        if (root && document.body.contains(root)) center(root, (root.getAttribute&&root.getAttribute("data-panel-size-key")) || "md");
      });
    }
    function registerRoot(id, root) { if (id && root) state.roots[id] = root; return root; }
    function attachResize(root) {
      resizeDirs.forEach(function (dir) {
        var handle = root.querySelector('[data-resize-dir="' + dir + '"]');
        if (!handle) return;
        handle.addEventListener("pointerdown", function (ev) {
          if (!state.resizable || root.getAttribute("data-extui-panel-mode") === "docked") return;
          if (typeof ev.button === "number" && ev.button !== 0) return;
          ev.preventDefault();
          var startRect = root.getBoundingClientRect();
          var startX = ev.clientX, startY = ev.clientY;
          try { handle.setPointerCapture(ev.pointerId); } catch (err) {}
          function onMove(mv) {
            var dx = mv.clientX - startX, dy = mv.clientY - startY;
            var vp = viewport();
            var margin = Math.min(viewportMargin, Math.max(6, Math.floor(Math.min(vp.width, vp.height) * 0.025)));
            var maxW = Math.max(240, vp.width - margin * 2), maxH = Math.max(260, vp.height - margin * 2);
            var minW = Math.min(minWidth, maxW), minH = Math.min(minHeight, maxH);
            var width = startRect.width, height = startRect.height, left = startRect.left, top = startRect.top;
            if (dir.indexOf("e") !== -1) width = clampNum(startRect.width + dx, minW, maxW);
            if (dir.indexOf("w") !== -1) { width = clampNum(startRect.width - dx, minW, maxW); left = startRect.left + startRect.width - width; }
            if (dir.indexOf("s") !== -1) height = clampNum(startRect.height + dy, minH, maxH);
            if (dir.indexOf("n") !== -1) { height = clampNum(startRect.height - dy, minH, maxH); top = startRect.top + startRect.height - height; }
            left = clampNum(left, vp.left + margin, Math.max(vp.left + margin, vp.right - width - margin));
            top = clampNum(top, margin, Math.max(margin, vp.height - height - margin));
            applyRect(root, { left: left, top: top, width: width, height: height });
          }
          function onUp() {
            handle.removeEventListener("pointermove", onMove);
            handle.removeEventListener("pointerup", onUp);
            handle.removeEventListener("pointercancel", onUp);
            try { handle.releasePointerCapture(ev.pointerId); } catch (err) {}
          }
          handle.addEventListener("pointermove", onMove);
          handle.addEventListener("pointerup", onUp);
          handle.addEventListener("pointercancel", onUp);
        });
      });
    }
    function attachDrag(root) {
      var handle = root.querySelector("[data-extui-drag-handle]");
      if (!handle) return;
      handle.addEventListener("pointerdown", function (ev) {
        if (!state.movable || root.getAttribute("data-extui-panel-mode") === "docked") return;
        if (typeof ev.button === "number" && ev.button !== 0) return;
        if (ev.target.closest && ev.target.closest(dragExcludeSelector)) return;
        ev.preventDefault();
        var startRect = root.getBoundingClientRect();
        var startX = ev.clientX, startY = ev.clientY;
        try { handle.setPointerCapture(ev.pointerId); } catch (err) {}
        function onMove(mv) {
          var vp = viewport();
          var dx = mv.clientX - startX, dy = mv.clientY - startY;
          var margin = Math.min(viewportMargin, Math.max(6, Math.floor(Math.min(vp.width, vp.height) * 0.025)));
          root.style.left = clampNum(startRect.left + dx, vp.left + margin, Math.max(vp.left + margin, vp.right - startRect.width - margin)) + "px";
          root.style.top = clampNum(startRect.top + dy, margin, Math.max(margin, vp.height - startRect.height - margin)) + "px";
        }
        function onUp() {
          handle.removeEventListener("pointermove", onMove);
          handle.removeEventListener("pointerup", onUp);
          handle.removeEventListener("pointercancel", onUp);
          try { handle.releasePointerCapture(ev.pointerId); } catch (err) {}
        }
        handle.addEventListener("pointermove", onMove);
        handle.addEventListener("pointerup", onUp);
        handle.addEventListener("pointercancel", onUp);
      });
    }
    function setInteractionSettings(movable, resizable) {
      var prevMovable = state.movable, prevResizable = state.resizable;
      state.movable = movable === true;
      state.resizable = resizable === true;
      document.documentElement.setAttribute("data-extui-workspace-movable", String(state.movable));
      document.documentElement.setAttribute("data-extui-workspace-resizable", String(state.resizable));
      if ((prevMovable !== state.movable || prevResizable !== state.resizable) && !state.movable && !state.resizable) resetGeometry();
    }
    function onWindowResize() {
      var active = getActivePanel();
      if (!active) return;
      if (panelOpenMode() === "docked") { refreshDockHost(); return; }
      applyRect(active, clampRect(active.getBoundingClientRect()));
    }
    window.addEventListener("ext:sidebar-v2-layout", reflowForSidebar);
    window.addEventListener("ext:sidebar-v2-visibility", reflowForSidebar);
    window.addEventListener("resize", onWindowResize);
    return Object.freeze({
      resizeDirs: resizeDirs.slice(),
      clampNum: clampNum,
      clampRect: clampRect,
      applyRect: applyRect,
      setVisibility: setVisibility,
      normalizePanelOpenMode: normalizePanelOpenMode,
      panelOpenMode: panelOpenMode,
      setPanelOpenMode: setPanelOpenMode,
      refreshDockHost: refreshDockHost,
      deactivateDockHost: deactivateDockHost,
      releaseFromDock: releaseFromDock,
      applyOpenMode: applyOpenMode,
      center: center,
      resetGeometry: resetGeometry,
      registerRoot: registerRoot,
      attachResize: attachResize,
      attachDrag: attachDrag,
      setInteractionSettings: setInteractionSettings
    });
  };
})();
