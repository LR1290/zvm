;(function(){
  "use strict";
  if(window.__extCreateCrmMainDomainCore)return;
  window.__extCreateCrmMainDomainCore=function(deps){
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,PANEL_BRAND=deps.panelBrand||{},extGet=deps.get,extSet=deps.set,parsePersisted=deps.parsePersisted,extCrmProfessionalOperation=deps.crmProfessionalOperation,extPanelOnKeyChange=deps.panelOnKeyChange,extPanelOwn=deps.panelOwn,extEmptyState=deps.emptyState,extField=deps.field,toast=deps.toast,escHtml=deps.escHtml,openShellHtml=deps.openShellHtml,fmtDateTime=deps.fmtDateTime,iconChip=deps.iconChip,navigateRail=deps.navigateRail;
    var CRM_KEY=deps.crmKey,CRM_PROFESSIONAL_KEY=deps.crmProfessionalKey,SCHEDULE_KEY=deps.scheduleKey,FOLLOWUP_QUEUE_KEY=deps.followUpQueueKey,FOLLOWUP_KEY=deps.followUpKey;
    if([buildPanelShell,extGet,extSet,parsePersisted,extCrmProfessionalOperation,extPanelOnKeyChange,extPanelOwn,extEmptyState,extField,toast,escHtml,openShellHtml,fmtDateTime,iconChip,navigateRail].some(function(fn){return typeof fn!=="function";})||!CRM_KEY||!CRM_PROFESSIONAL_KEY||!SCHEDULE_KEY||!FOLLOWUP_QUEUE_KEY||!FOLLOWUP_KEY)throw new TypeError("Dependências do domínio CRM inválidas.");
    function parseLocalDateTimeStrict(value){
      var m=String(value||"").match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if(!m)return NaN;
      var y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]),h=Number(m[4]),mi=Number(m[5]),sec=Number(m[6]||0);
      var dt=new Date(y,mo-1,d,h,mi,sec,0);
      if(dt.getFullYear()!==y||dt.getMonth()!==mo-1||dt.getDate()!==d||dt.getHours()!==h||dt.getMinutes()!==mi||dt.getSeconds()!==sec)return NaN;
      return dt.getTime();
    }

  async function buildCrmPanel() {
      var root = buildPanelShell({ id: "extuiNavCrmPanel", title: "CRM", accent: PANEL_BRAND.crm.accent, icon: PANEL_BRAND.crm.icon, eyebrow: "Contato atual", hint: "Veja e atualize o CRM do contato atual.", size: "lg" });
      var body = root.querySelector(".extuiNavPanelBody");
      var tabs = document.createElement("div");
      tabs.className = "extuiCrmTabBar";
      tabs.setAttribute("role", "tablist");
      tabs.setAttribute("aria-label", "CRM");
      var contactTab = document.createElement("button");
      contactTab.type = "button";
      contactTab.className = "extuiCrmTab extuiActive";
      contactTab.textContent = "CONTATO E CRM";
      contactTab.setAttribute("role", "tab");
      contactTab.id = "extuiCrmTabContact";
      contactTab.setAttribute("aria-selected", "true");
      contactTab.setAttribute("aria-controls", "extuiCrmPaneContact");
      contactTab.tabIndex = 0;
      var crmsTab = document.createElement("button");
      crmsTab.type = "button";
      crmsTab.className = "extuiCrmTab";
      crmsTab.textContent = "CRMs";
      crmsTab.setAttribute("role", "tab");
      crmsTab.id = "extuiCrmTabCrms";
      crmsTab.setAttribute("aria-selected", "false");
      crmsTab.setAttribute("aria-controls", "extuiCrmPaneCrms");
      crmsTab.tabIndex = -1;
      tabs.appendChild(contactTab);
      tabs.appendChild(crmsTab);
      body.appendChild(tabs);
      var panes = document.createElement("div");
      panes.className = "extuiCrmTabPanes";
      var contactPane = document.createElement("div");
      contactPane.className = "extuiCrmTabPane extuiCrmContactPane extuiActive";
      contactPane.id = "extuiCrmPaneContact";
      contactPane.setAttribute("role", "tabpanel");
      contactPane.setAttribute("aria-labelledby", "extuiCrmTabContact");
      var content = document.createElement("div");
      content.className = "extuiCrmContactContext";
      contactPane.appendChild(content);
      var crmsPane = document.createElement("div");
      crmsPane.className = "extuiCrmTabPane extuiCrmHubPane";
      crmsPane.id = "extuiCrmPaneCrms";
      crmsPane.setAttribute("role", "tabpanel");
      crmsPane.setAttribute("aria-labelledby", "extuiCrmTabCrms");
      crmsPane.hidden = true;
      panes.appendChild(contactPane);
      panes.appendChild(crmsPane);
      body.appendChild(panes);
      var lastContextKey = "";
  
      function setTab(name) {
        var contactActive = name !== "crms";
        contactTab.classList.toggle("extuiActive", contactActive);
        crmsTab.classList.toggle("extuiActive", !contactActive);
        contactTab.setAttribute("aria-selected", contactActive ? "true" : "false");
        crmsTab.setAttribute("aria-selected", contactActive ? "false" : "true");
        contactTab.tabIndex = contactActive ? 0 : -1;
        crmsTab.tabIndex = contactActive ? -1 : 0;
        contactPane.classList.toggle("extuiActive", contactActive);
        crmsPane.classList.toggle("extuiActive", !contactActive);
        contactPane.hidden = !contactActive;
        crmsPane.hidden = contactActive;
        if (!contactActive) reloadCrmsTab();
      }
      contactTab.addEventListener("click", function () { setTab("contact"); });
      crmsTab.addEventListener("click", function () { setTab("crms"); });
      tabs.addEventListener("keydown", function (ev) {
        var buttons=[contactTab,crmsTab],index=buttons.indexOf(document.activeElement);if(index<0)return;
        if(ev.key==="ArrowRight")index=(index+1)%buttons.length;else if(ev.key==="ArrowLeft")index=(index-1+buttons.length)%buttons.length;else if(ev.key==="Home")index=0;else if(ev.key==="End")index=buttons.length-1;else return;
        ev.preventDefault();var next=buttons[index];setTab(next===crmsTab?"crms":"contact");next.focus();
      });
  
      async function getActiveContactContext() {
        if (!window.ExtensionChatBridge || !window.ExtensionChatBridge.isReady || !window.ExtensionChatBridge.chat || typeof window.ExtensionChatBridge.chat.getActiveChat !== "function") return null;
        var chat = await window.ExtensionChatBridge.chat.getActiveChat();
        if (!chat || !chat.id) return null;
        var chatId = (chat.id && chat.id._serialized) || String(chat.id);
        if (chatId.indexOf("@g.us") !== -1) return { group: true };
        var phone = chat.id && chat.id.server === "c.us" ? chat.id.user : null;
        if (!phone && chatId.indexOf("@lid") !== -1 && window.ExtensionChatBridge.contact && typeof window.ExtensionChatBridge.contact.getPnLidEntry === "function") {
          try {
            var lidEntry = await window.ExtensionChatBridge.contact.getPnLidEntry(chatId);
            phone = lidEntry && lidEntry.phoneNumber && lidEntry.phoneNumber.id;
          } catch (err) { phone = null; }
        }
        var contact = chat.contact || null;
        if (!contact && window.ExtensionChatBridge.contact && typeof window.ExtensionChatBridge.contact.get === "function") {
          try { contact = await window.ExtensionChatBridge.contact.get(chatId); } catch (err) { contact = null; }
        }
        var name = (contact && (contact.name || contact.pushname || contact.verifiedName || contact.formattedName)) || chat.name || chat.formattedTitle || phone || "Contato";
        var avatar = null;
        if (window.ExtensionChatBridge.contact && typeof window.ExtensionChatBridge.contact.getProfilePictureUrl === "function") {
          try { avatar = await window.ExtensionChatBridge.contact.getProfilePictureUrl(chatId); } catch (err) { avatar = null; }
        }
        return { chatId: chatId, phone: phone ? String(phone).replace(/\D/g, "") : null, name: name, avatar: avatar || null };
      }
  
      function crmListFromStore(raw) {
        var parsed = raw;
        try { if (typeof parsed === "string") parsed = JSON.parse(parsed); } catch (_) { parsed = null; }
        var list = parsed && parsed.state && Array.isArray(parsed.state.crmList) ? parsed.state.crmList : (parsed && Array.isArray(parsed.crmList) ? parsed.crmList : []);
        return list.filter(function (crm) { return crm && Number(crm.archivedAtInMs || 0) <= 0; });
      }
  
      function findMembership(crmList, phone) {
        for (var i = 0; i < crmList.length; i++) {
          var crm = crmList[i];
          for (var j = 0; j < (crm.columns || []).length; j++) {
            var column = crm.columns[j];
            var item = (column.items || []).find(function (candidate) { return candidate.contact && String(candidate.contact.phoneNumber || "").replace(/\D/g, "") === phone; });
            if (item) return { crm: crm, column: column, item: item };
          }
        }
        return null;
      }
  
      function crmContactCount(crm) {
        return (crm.columns || []).reduce(function (total, column) { return total + ((column.items || []).length || 0); }, 0);
      }
  
      function crmAccent(crm) {
        var value = String(crm && crm.hexColor || "");
        return /^#[0-9a-f]{6}$/i.test(value) ? value : PANEL_BRAND.crm.accent;
      }
  
      var crmsTabReloadState = { seq: 0 };
      async function reloadCrmsTab() {
        var reloadSeq = ++crmsTabReloadState.seq;
        try {
          var crmList = crmListFromStore(await extGet(CRM_KEY));
          if (reloadSeq !== crmsTabReloadState.seq || !root.isConnected) return;
          crmsPane.innerHTML = "";
          var toolbar = document.createElement("div");
          toolbar.className = "extuiCrmHubToolbar";
          var manager = document.createElement("button");
          manager.type = "button";
          manager.className = "extuiNavPrimaryBtn extuiCrmHubManagerBtn";
          manager.textContent = "Abrir Gerenciador de CRMs";
          manager.addEventListener("click", function () { openShellHtml("crm", { crmView: "hub", newTab: true }); });
          toolbar.appendChild(manager);
          crmsPane.appendChild(toolbar);
          if (!crmList.length) {
            crmsPane.appendChild(extEmptyState(PANEL_BRAND.crm.accent, PANEL_BRAND.crm.icon, "Nenhum CRM criado", "Crie seu primeiro CRM no Painel de Controle para começar.", "Criar CRM", function () { openShellHtml("crm", { crmView: "hub", crmCreate: true, newTab: true }); }, { sober: true }));
            return;
          }
          var grid = document.createElement("div");
          grid.className = "extuiCrmHubGridCompact";
          crmList.forEach(function (crm) {
            var card = document.createElement("button");
            card.type = "button";
            card.className = "extuiCrmHubCardCompact";
            card.style.setProperty("--extui-crm-accent", crmAccent(crm));
            card.setAttribute("aria-label", "Abrir CRM " + (crm.name || "CRM"));
            card.title = crm.name || "CRM";
            var glyph = document.createElement("span");
            glyph.className = "extuiCrmHubCardGlyph";
            glyph.innerHTML = iconChip(crmAccent(crm), PANEL_BRAND.crm.icon, true);
            var title = document.createElement("strong");
            title.className = "extuiCrmHubCardTitle";
            title.textContent = crm.name || "CRM";
            title.title = crm.name || "CRM";
            var meta = document.createElement("span");
            meta.className = "extuiCrmHubCardMeta";
            meta.textContent = (crm.columns || []).length + " etapas · " + crmContactCount(crm) + " contatos";
            card.appendChild(glyph);
            card.appendChild(title);
            card.appendChild(meta);
            card.addEventListener("click", function () { openShellHtml("crm", { crmId: crm.id, crmView: "kanban", newTab: true }); });
            grid.appendChild(card);
          });
          crmsPane.appendChild(grid);
        } catch (err) {
          crmsPane.innerHTML = "";
          crmsPane.appendChild(extEmptyState(PANEL_BRAND.crm.accent, PANEL_BRAND.crm.icon, "Não foi possível carregar os CRMs", "Tente novamente em alguns instantes.", "Tentar novamente", reloadCrmsTab, { sober: true }));
        }
      }
  
      function crmColumnEventId() {
        return "crm-event:" + (crypto.randomUUID ? crypto.randomUUID() : (Date.now().toString(36) + ":" + Math.random().toString(36).slice(2) + ":" + Math.random().toString(36).slice(2)));
      }
      function pushCrmColumnEvent(crmId, columnId, contactId) {
        var event = { id: crmColumnEventId(), crmId: crmId, columnId: columnId, contactId: contactId, atMs: Date.now() };
        function request() {
          return new Promise(function (resolve, reject) {
            var settled = false, timer = setTimeout(function () { if (settled) return; settled = true; var err = new Error("A fila de automação do CRM demorou demais para responder."); err.code = "CRM_COLUMN_EVENT_QUEUE_TIMEOUT"; reject(err); }, 7000);
            try {
              chrome.runtime.sendMessage({ type: "EXTUI_COLUMN_EVENT_QUEUE", action: "enqueue", event: event }, function (response) {
                if (settled) return; settled = true; clearTimeout(timer);
                if (chrome.runtime.lastError) { var transport = new Error(chrome.runtime.lastError.message || "A fila de automação do CRM foi interrompida."); transport.code = "CRM_COLUMN_EVENT_QUEUE_TRANSPORT"; reject(transport); return; }
                if (!response || response.ok !== true) { var error = new Error(response && response.userMessage || "Não foi possível registrar a movimentação do CRM para automação."); error.code = response && response.errorCode || "CRM_COLUMN_EVENT_QUEUE_FAILED"; reject(error); return; }
                resolve(response.result || null);
              });
            } catch (error) { if (!settled) { settled = true; clearTimeout(timer); reject(error); } }
          });
        }
        return request().catch(async function (error) {
          if (!error || ["CRM_COLUMN_EVENT_QUEUE_TIMEOUT", "CRM_COLUMN_EVENT_QUEUE_TRANSPORT"].indexOf(error.code) < 0) throw error;
          await new Promise(function (resolve) { setTimeout(resolve, 120); });
          return request();
        });
      }
  
      function nextOperationalDates(phone, schedules, queue, rules) {
        var scheduleCandidates = [];
        var followUpCandidates = [];
        schedules.forEach(function (schedule) {
          if (schedule.status === "scheduled" && String(schedule.targetChatId || "").replace(/\D/g, "") === phone) scheduleCandidates.push({ at: schedule.scheduleAtMs });
        });
        queue.forEach(function (entry) {
          if (entry.status !== "pending" || String(entry.phoneNumber || "").replace(/\D/g, "") !== phone) return;
          var rule = rules.find(function (item) { return item.id === entry.followUpId; });
          if (!rule) return;
          var timing = (rule.acionamento && rule.acionamento.timing) || {};
          var waitMs = ((timing.days || 0) * 86400 + (timing.hours || 0) * 3600 + (timing.minutes || 0) * 60) * 1000;
          followUpCandidates.push({ at: (entry.enqueuedAtMs || Date.now()) + waitMs, label: rule.nome || "Follow-up" });
        });
        scheduleCandidates.sort(function (a, b) { return a.at - b.at; });
        followUpCandidates.sort(function (a, b) { return a.at - b.at; });
        return { schedule: scheduleCandidates[0] || null, followUp: followUpCandidates[0] || null };
      }
  
      var crmReloadState = { seq: 0 };
      async function reload(force) {
        if (!force && !root.classList.contains("extuiOpen")) return;
        var reloadSeq = ++crmReloadState.seq;
        try {
          var context = await getActiveContactContext();
          if (reloadSeq !== crmReloadState.seq || !root.isConnected) return;
          if (!context) { lastContextKey = "none"; content.classList.add("extuiCrmContactContext--empty"); content.innerHTML = ""; content.appendChild(extEmptyState(PANEL_BRAND.crm.accent, PANEL_BRAND.crm.icon, "Abra uma conversa", "Selecione uma conversa individual para ver o contexto deste contato.", null, null, { sober: true })); return; }
          if (context.group) { lastContextKey = "group"; content.classList.add("extuiCrmContactContext--empty"); content.innerHTML = ""; content.appendChild(extEmptyState(PANEL_BRAND.crm.accent, PANEL_BRAND.crm.icon, "Conversa em grupo", "O contexto operacional do CRM está disponível para contatos individuais.", null, null, { sober: true })); return; }
          content.classList.remove("extuiCrmContactContext--empty");
          var values = await Promise.all([extGet(CRM_KEY), extGet(SCHEDULE_KEY), extGet(FOLLOWUP_QUEUE_KEY), extGet(FOLLOWUP_KEY), extGet(CRM_PROFESSIONAL_KEY)]);
          if (reloadSeq !== crmReloadState.seq || !root.isConnected) return;
          var crmStore = values[0] ? (typeof values[0] === "string" ? JSON.parse(values[0]) : values[0]) : { state: { crmList: [] }, version: 0 };
          var crmList = crmListFromStore(crmStore);
          var schedulesRaw = values[1] ? (typeof values[1] === "string" ? JSON.parse(values[1]) : values[1]) : null;
          var schedules = (schedulesRaw && schedulesRaw.list) || [];
          var queue = (parsePersisted(values[2]) || {}).queue || [];
          var rules = (parsePersisted(values[3]) || {}).followUpList || [];
          var membership = findMembership(crmList, context.phone);
          var professionalCore = window.__extCrmProfessionalCore;
          var professionalStore = professionalCore ? professionalCore.normalizeStore(values[4]) : null;
          var professionalSummary = membership && professionalCore ? professionalCore.createDockedContactSummary(crmStore, professionalStore, membership.item.id, { now: Date.now() }) : null;
          var nextDates = context.phone ? nextOperationalDates(context.phone, schedules, queue, rules) : { schedule: null, followUp: null };
          var contextKey = [context.chatId, membership && membership.crm.id, membership && membership.column.id, nextDates.schedule && nextDates.schedule.at, nextDates.followUp && nextDates.followUp.at].join(":");
          if (!force && contextKey === lastContextKey) return;
          lastContextKey = contextKey;
          content.innerHTML = "";
  
          var identity = document.createElement("div"); identity.className = "extuiCrmContactIdentity";
          var avatar = document.createElement("div"); avatar.className = "extuiCrmContactAvatar";
          if (context.avatar) { var image = document.createElement("img"); image.src = context.avatar; image.alt = ""; avatar.appendChild(image); }
          else avatar.textContent = String(context.name || "?").trim().charAt(0).toUpperCase();
          var identityText = document.createElement("div"); identityText.className = "extuiCrmContactIdentityText";
          identityText.innerHTML = '<strong>' + escHtml(context.name) + '</strong>' + (context.phone ? '<span>+' + escHtml(context.phone) + '</span>' : '');
          identity.appendChild(avatar); identity.appendChild(identityText); content.appendChild(identity);
  
          var facts = document.createElement("div"); facts.className = "extuiCrmContactFacts";
          if (membership) {
            facts.innerHTML = '<div><span>CRM atual</span><strong>' + escHtml(membership.crm.name || membership.crm.id) + '</strong></div>' +
              '<div><span>Lista atual</span><strong>' + escHtml(membership.column.title || membership.column.id) + '</strong></div>';
          }
          if (nextDates.schedule) facts.innerHTML += '<div><span>Próximo agendamento</span><strong>' + escHtml(fmtDateTime(nextDates.schedule.at)) + '</strong></div>';
          if (nextDates.followUp) facts.innerHTML += '<div><span>Próximo follow-up</span><strong>' + escHtml(nextDates.followUp.label) + ' · ' + escHtml(fmtDateTime(nextDates.followUp.at)) + '</strong></div>';
          if (professionalSummary && professionalSummary.nextTask) facts.innerHTML += '<div><span>Próxima tarefa</span><strong>' + escHtml(professionalSummary.nextTask.title) + (professionalSummary.nextTask.dueAtMs ? ' · ' + escHtml(fmtDateTime(professionalSummary.nextTask.dueAtMs)) : '') + '</strong></div>';
          if (professionalSummary && professionalSummary.latestNote) facts.innerHTML += '<div><span>Última nota</span><strong>' + escHtml(professionalSummary.latestNote.text) + '</strong></div>';
          if (facts.children.length) content.appendChild(facts);
  
          if (!crmList.length) {
            var noCrmNotice = document.createElement("div"); noCrmNotice.className = "extuiCrmNoCrmNotice";
            var noCrmCopy = document.createElement("div"); noCrmCopy.className = "extuiCrmNoCrmNoticeCopy";
            var noCrmTitle = document.createElement("strong"); noCrmTitle.textContent = "Crie um CRM para começar";
            var noCrmText = document.createElement("span"); noCrmText.textContent = "Você precisa de um CRM para organizar este contato em uma lista ou etapa.";
            var noCrmButton = document.createElement("button"); noCrmButton.type = "button"; noCrmButton.className = "extuiNavSecondaryBtn extuiCrmNoCrmCreate"; noCrmButton.textContent = "Criar CRM";
            noCrmButton.addEventListener("click", function () { openShellHtml("crm", { crmView: "hub", crmCreate: true, newTab: true }); });
            noCrmCopy.appendChild(noCrmTitle); noCrmCopy.appendChild(noCrmText); noCrmNotice.appendChild(noCrmCopy); noCrmNotice.appendChild(noCrmButton); content.appendChild(noCrmNotice);
          }
  
          var crmAction = document.createElement("div"); crmAction.className = "extuiCrmContactAction";
          var selectorGrid = document.createElement("div"); selectorGrid.className = "extuiCrmSelectorGrid";
          var crmField = document.createElement("label"); crmField.className = "extuiCrmSelectorField";
          var crmLabel = document.createElement("span"); crmLabel.textContent = "CRM";
          var crmSelect = document.createElement("select"); crmSelect.setAttribute("aria-label", "CRM");
          var columnField = document.createElement("label"); columnField.className = "extuiCrmSelectorField";
          var columnLabel = document.createElement("span"); columnLabel.textContent = "Lista / Etapa";
          var columnSelect = document.createElement("select"); columnSelect.setAttribute("aria-label", "Lista ou etapa do CRM");
          if (!crmList.length) {
            crmSelect.appendChild(new Option("Nenhum CRM criado", ""));
            crmSelect.disabled = true;
            columnSelect.appendChild(new Option("—", ""));
            columnSelect.disabled = true;
          }
          crmList.forEach(function (crm) { crmSelect.appendChild(new Option(crm.name || crm.id, crm.id)); });
          function fillColumns(crmId, selectedColumnId) {
            columnSelect.innerHTML = "";
            var selectedCrm = crmList.find(function (crm) { return crm.id === crmId; });
            (selectedCrm && selectedCrm.columns || []).forEach(function (column) { columnSelect.appendChild(new Option(column.title || column.id, column.id)); });
            if (!columnSelect.options.length) columnSelect.appendChild(new Option("—", ""));
            if (selectedColumnId && Array.prototype.some.call(columnSelect.options, function (option) { return option.value === selectedColumnId; })) columnSelect.value = selectedColumnId;
            columnSelect.disabled = !selectedCrm || !(selectedCrm.columns || []).length;
          }
          if (membership && crmList.some(function (crm) { return crm.id === membership.crm.id; })) crmSelect.value = membership.crm.id;
          else if (crmList[0]) crmSelect.value = crmList[0].id;
          fillColumns(crmSelect.value, membership && membership.crm.id === crmSelect.value ? membership.column.id : null);
          crmField.appendChild(crmLabel); crmField.appendChild(crmSelect);
          columnField.appendChild(columnLabel); columnField.appendChild(columnSelect);
          selectorGrid.appendChild(crmField); selectorGrid.appendChild(columnField);
          crmAction.appendChild(selectorGrid);
          var crmBtn = document.createElement("button"); crmBtn.type = "button"; crmBtn.className = "extuiNavPrimaryBtn"; crmBtn.textContent = membership ? "Mover de etapa" : "Adicionar ao CRM";
          function syncCrmAction() { crmBtn.disabled = !context.phone || !crmSelect.value || !columnSelect.value; }
          crmSelect.addEventListener("change", function () { fillColumns(crmSelect.value, null); syncCrmAction(); });
          columnSelect.addEventListener("change", syncCrmAction);
          syncCrmAction();
          crmBtn.addEventListener("click", async function () {
            var targetCrm = crmList.find(function (crm) { return crm.id === crmSelect.value; });
            var targetColumn = targetCrm && (targetCrm.columns || []).find(function (column) { return column.id === columnSelect.value; });
            if (!targetColumn) return;
            if (membership && membership.crm.id === targetCrm.id && membership.column.id === targetColumn.id) { toast("O contato já está nesta lista."); return; }
            var card = membership ? membership.item : { id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())), contact: { name: context.name, phoneNumber: context.phone, avatar: context.avatar || null }, createdBy: "WhatsApp", createdAtInMs: Date.now() };
            if (membership) membership.column.items = (membership.column.items || []).filter(function (item) { return item.id !== membership.item.id; });
            targetColumn.items = targetColumn.items || [];
            targetColumn.items.push(card);
            await extSet(CRM_KEY, JSON.stringify(crmStore));
            await pushCrmColumnEvent(targetCrm.id, targetColumn.id, card.id);
            await extCrmProfessionalOperation({ type: "event.add", crmContactId: card.id, event: membership ? { type: "column_moved", title: "Etapa alterada", description: membership.column.title + " → " + targetColumn.title, metadata: { fromColumnId: membership.column.id, toColumnId: targetColumn.id } } : { type: "crm_entry", title: "Contato adicionado ao CRM", description: targetCrm.name + " · " + targetColumn.title, metadata: { boardId: targetCrm.id, columnId: targetColumn.id } } });
            toast(membership ? "Contato movido de etapa." : "Contato adicionado ao CRM.");
            reload(true);
          });
          crmAction.appendChild(crmBtn); content.appendChild(crmAction);
  
          var quickActions = document.createElement("div"); quickActions.className = "extuiCrmQuickActions";
          var scheduleBtn = document.createElement("button"); scheduleBtn.type = "button"; scheduleBtn.className = "extuiNavSecondaryBtn"; scheduleBtn.textContent = "Agendar"; scheduleBtn.disabled = !context.phone;
          scheduleBtn.addEventListener("click", function () {
            Promise.resolve(navigateRail("agenda", { source: "crm-quick-action", ensureOpen: true })).then(function () {
              setTimeout(function () { var input = document.querySelector("#extuiNavAgendaPanel [data-agenda-phone]"); if (input) { input.value = context.phone; input.focus(); } }, 0);
            }).catch(function (err) { toast(err&&err.message||"Não foi possível abrir a Agenda.", true); });
          });
          function taskUid() { return crypto.randomUUID ? crypto.randomUUID() : "crm-task-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7); }
          function actionLabel(action) {
            if (!action || !action.type || action.type === "none") return "Manual";
            if (action.type === "saved") return "Enviar " + ({ message:"mensagem", audio:"áudio", media:"mídia", sticker:"figurinha", document:"documento" }[action.itemType] || "item salvo");
            if (action.type === "flow") return "Executar fluxo";
            if (action.type === "funnel") return "Executar funil";
            if (action.type === "moveCRM") return "Mover no CRM";
            return "Ação programada";
          }
          async function scheduleTaskAction(taskId, taskTitle, dueAtMs, action) {
            if (!action || action.type === "none") return null;
            if (!window.__extAgendaService || typeof window.__extAgendaService.schedule !== "function") throw new Error("A Agenda ainda não está disponível.");
            if (!dueAtMs || dueAtMs <= Date.now()) throw new Error("Escolha um prazo futuro para programar a ação.");
            var input = { targetChatId: context.phone, targetChatName: context.name, scheduleAtMs: dueAtMs, itemName: taskTitle, crmTaskRef: { crmContactId: membership.item.id, taskId: taskId } };
            if (action.type === "saved") Object.assign(input, { type: action.itemType, itemId: action.itemId, itemName: action.itemName || taskTitle });
            else if (action.type === "flow") Object.assign(input, { type: "flow", itemId: action.itemId, itemName: action.itemName || taskTitle });
            else if (action.type === "funnel") Object.assign(input, { type: "funnel", itemId: action.itemId, itemName: action.itemName || taskTitle });
            else if (action.type === "moveCRM") Object.assign(input, { type: "crm-task-action", actions: [{ type: "addCRM", properties: { crmID: action.crmId, abaID: action.columnId } }], itemName: action.itemName || "Mover contato no CRM" });
            return window.__extAgendaService.schedule(input);
          }
          async function cancelTaskSchedule(task) {
            if (task && task.actionScheduleId && window.__extAgendaService && typeof window.__extAgendaService.cancel === "function") {
              try { await window.__extAgendaService.cancel(task.actionScheduleId); } catch (_) {}
            }
          }
          function openNoteComposer() {
            var existing = content.querySelector(".extuiCrmQuickComposer"); if (existing) existing.remove();
            var form = document.createElement("form"); form.className = "extuiCrmQuickComposer extuiCrmNoteComposer";
            var title = document.createElement("input"); title.type = "text"; title.maxLength = 120; title.placeholder = "Título da nota"; title.setAttribute("aria-label", "Título da nota");
            var text = document.createElement("textarea"); text.placeholder = "Escreva a nota"; text.setAttribute("aria-label", "Conteúdo da nota");
            var bar = document.createElement("div"); bar.className = "extuiCrmQuickComposerActions";
            var cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "extuiNavSecondaryBtn"; cancel.textContent = "Cancelar"; cancel.addEventListener("click", function () { form.remove(); });
            var save = document.createElement("button"); save.type = "submit"; save.className = "extuiNavPrimaryBtn"; save.textContent = "Salvar";
            bar.appendChild(cancel); bar.appendChild(save); form.appendChild(extField("Título", title)); form.appendChild(extField("Nota", text)); form.appendChild(bar); quickActions.after(form); title.focus();
            form.addEventListener("submit", async function (event) { event.preventDefault(); var bodyText = text.value.trim(); if (!bodyText) { toast("Escreva a nota antes de salvar.", true); return; } save.disabled = true; try { await extCrmProfessionalOperation({ type: "note.add", crmContactId: membership.item.id, note: { title: title.value.trim(), text: bodyText, author: "Usuário local" } }); toast("Nota salva."); form.remove(); reload(true); } catch (error) { toast(error.message || "Falha ao salvar nota.", true); save.disabled = false; } });
          }
          async function openTaskComposer() {
            var existing = content.querySelector(".extuiCrmQuickComposer"); if (existing) existing.remove();
            var form = document.createElement("form"); form.className = "extuiCrmQuickComposer extuiCrmTaskComposer";
            var title = document.createElement("input"); title.type = "text"; title.maxLength = 160; title.placeholder = "Título da tarefa";
            var objective = document.createElement("textarea"); objective.placeholder = "Objetivo / o que precisa ser feito";
            var due = document.createElement("input"); due.type = "datetime-local";
            var priority = document.createElement("select"); [["low","Baixa"],["normal","Normal"],["high","Alta"]].forEach(function (x) { priority.appendChild(new Option(x[1], x[0])); }); priority.value = "normal";
            var actionType = document.createElement("select"); [["none","Nenhuma · tarefa manual"],["message","Enviar mensagem salva"],["audio","Enviar áudio salvo"],["media","Enviar mídia salva"],["sticker","Enviar figurinha salva"],["document","Enviar documento salvo"],["flow","Executar Fluxo"],["funnel","Executar Funil"],["moveCRM","Mover contato no CRM"]].forEach(function (x) { actionType.appendChild(new Option(x[1], x[0])); });
            var actionConfig = document.createElement("div"); actionConfig.className = "extuiCrmTaskActionConfig";
            form.appendChild(extField("Título", title)); form.appendChild(extField("Objetivo / o que fazer", objective));
            var taskMeta = document.createElement("div"); taskMeta.className = "extuiCrmTaskMetaGrid"; taskMeta.appendChild(extField("Prazo", due)); taskMeta.appendChild(extField("Prioridade", priority)); form.appendChild(taskMeta);
            form.appendChild(extField("Ação programada (opcional)", actionType, "A ação usa Agenda e as automações já existentes da extensão.")); form.appendChild(actionConfig);
            async function fillActionConfig() {
              actionConfig.innerHTML = ""; var type = actionType.value; if (type === "none") return;
              if (["message","audio","media","sticker","document"].indexOf(type) >= 0) {
                var map = { message:["EXTUI:textMessageStore","textMessageList"], audio:["EXTUI:audioStore","audioList"], media:["EXTUI:mediaStore","mediaList"], sticker:["EXTUI:stickerStore","stickerList"], document:["EXTUI:documentStore","documentList"] }, cfg = map[type], raw = parsePersisted(await extGet(cfg[0])) || {}, list = Array.isArray(raw[cfg[1]]) ? raw[cfg[1]] : [], sel = document.createElement("select");
                list.forEach(function (item) { sel.appendChild(new Option(item.name || item.title || "Item salvo", item.id)); }); if (!list.length) sel.appendChild(new Option("Nenhum item salvo", "")); sel.dataset.actionItem = "saved"; actionConfig.appendChild(extField("Item salvo", sel));
              } else if (type === "flow" || type === "funnel") {
                var key = type === "flow" ? "EXTUI:extappFlowStore" : "EXTUI:extappFunnelStore", field = type === "flow" ? "flowList" : "funnelList", raw2 = parsePersisted(await extGet(key)) || {}, list2 = Array.isArray(raw2[field]) ? raw2[field] : [], sel2 = document.createElement("select");
                list2.forEach(function (item) { sel2.appendChild(new Option(item.name || item.title || (type === "flow" ? "Fluxo" : "Funil"), item.id)); }); if (!list2.length) sel2.appendChild(new Option(type === "flow" ? "Nenhum fluxo" : "Nenhum funil", "")); sel2.dataset.actionItem = type; actionConfig.appendChild(extField(type === "flow" ? "Fluxo" : "Funil", sel2));
              } else if (type === "moveCRM") {
                var crmSel = document.createElement("select"), colSel = document.createElement("select"); crmList.forEach(function (crm) { crmSel.appendChild(new Option(crm.name || crm.id, crm.id)); });
                function cols() { colSel.innerHTML = ""; var crm = crmList.find(function (c) { return String(c.id) === String(crmSel.value); }); (crm && crm.columns || []).forEach(function (c) { colSel.appendChild(new Option(c.title || c.id, c.id)); }); if (!colSel.options.length) colSel.appendChild(new Option("Nenhuma etapa", "")); }
                crmSel.addEventListener("change", cols); cols(); crmSel.dataset.actionCrm = "1"; colSel.dataset.actionColumn = "1"; var grid = document.createElement("div"); grid.className = "extuiCrmTaskMetaGrid"; grid.appendChild(extField("CRM", crmSel)); grid.appendChild(extField("Lista / Etapa", colSel)); actionConfig.appendChild(grid);
              }
            }
            actionType.addEventListener("change", fillActionConfig); await fillActionConfig();
            var bar = document.createElement("div"); bar.className = "extuiCrmQuickComposerActions"; var cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "extuiNavSecondaryBtn"; cancel.textContent = "Cancelar"; cancel.addEventListener("click", function () { form.remove(); }); var save = document.createElement("button"); save.type = "submit"; save.className = "extuiNavPrimaryBtn"; save.textContent = "Criar tarefa"; bar.appendChild(cancel); bar.appendChild(save); form.appendChild(bar); quickActions.after(form); title.focus();
            form.addEventListener("submit", async function (event) {
              event.preventDefault(); var taskTitle = title.value.trim(), dueAt = due.value ? parseLocalDateTimeStrict(due.value) : null; if (due.value&&!Number.isFinite(dueAt)) { toast("Prazo com data ou horário local inválido.", true); return; } if (!taskTitle) { toast("Informe o título da tarefa.", true); return; }
              var action = { type: "none" }, type = actionType.value;
              if (type !== "none") {
                if (!dueAt || dueAt <= Date.now()) { toast("Escolha um prazo futuro para a ação programada.", true); return; }
                if (["message","audio","media","sticker","document","flow","funnel"].indexOf(type) >= 0) { var sel = actionConfig.querySelector("select[data-action-item]"); if (!sel || !sel.value) { toast("Selecione o item da ação.", true); return; } action = { type: ["message","audio","media","sticker","document"].indexOf(type)>=0 ? "saved" : type, itemType: ["message","audio","media","sticker","document"].indexOf(type)>=0 ? type : undefined, itemId: sel.value, itemName: sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : "" }; }
                else if (type === "moveCRM") { var cs = actionConfig.querySelector("select[data-action-crm]"), ls = actionConfig.querySelector("select[data-action-column]"); if (!cs || !cs.value || !ls || !ls.value) { toast("Selecione o CRM e a etapa.", true); return; } action = { type: "moveCRM", crmId: cs.value, columnId: ls.value, itemName: "Mover para " + (ls.options[ls.selectedIndex] ? ls.options[ls.selectedIndex].text : "etapa") }; }
              }
              save.disabled = true; var taskId = taskUid(); try {
                await extCrmProfessionalOperation({ type: "task.add", crmContactId: membership.item.id, task: { id: taskId, title: taskTitle, description: objective.value.trim(), dueAtMs: dueAt, status: "open", priority: priority.value, action: action.type === "none" ? null : action, actionStatus: action.type === "none" ? "none" : "scheduled" } });
                if (action.type !== "none") { try { var scheduled = await scheduleTaskAction(taskId, taskTitle, dueAt, action); await extCrmProfessionalOperation({ type: "task.update", crmContactId: membership.item.id, taskId: taskId, patch: { actionScheduleId: scheduled.id, actionStatus: "scheduled" } }); } catch (scheduleError) { await extCrmProfessionalOperation({ type: "task.update", crmContactId: membership.item.id, taskId: taskId, patch: { actionStatus: "error" } }); throw scheduleError; } }
                toast(action.type === "none" ? "Tarefa criada." : "Tarefa e ação programada criadas."); form.remove(); reload(true);
              } catch (error) { toast(error.message || "Falha ao criar tarefa.", true); save.disabled = false; }
            });
          }
          var noteBtn = document.createElement("button"); noteBtn.type = "button"; noteBtn.className = "extuiNavSecondaryBtn"; noteBtn.textContent = "Adicionar nota"; noteBtn.disabled = !membership; noteBtn.addEventListener("click", openNoteComposer);
          var taskBtn = document.createElement("button"); taskBtn.type = "button"; taskBtn.className = "extuiNavSecondaryBtn"; taskBtn.textContent = "Criar tarefa"; taskBtn.disabled = !membership; taskBtn.addEventListener("click", function () { openTaskComposer().catch(function (error) { toast(error.message || "Falha ao abrir tarefa.", true); }); });
          var copilotBtn = document.createElement("button"); copilotBtn.type = "button"; copilotBtn.className = "extuiNavSecondaryBtn"; copilotBtn.textContent = "Copiloto IA"; copilotBtn.disabled = !membership; copilotBtn.addEventListener("click", function () { openShellHtml("crm", { crmContactId: membership && membership.item.id, crmCopilot: true, reuseExisting: true }); });
          var openBtn = document.createElement("button"); openBtn.type = "button"; openBtn.className = "extuiNavSecondaryBtn"; openBtn.textContent = "Abrir perfil completo"; openBtn.disabled = !membership; openBtn.addEventListener("click", function () { openShellHtml("crm", { crmContactId: membership && membership.item.id, reuseExisting: true }); });
          quickActions.appendChild(scheduleBtn); quickActions.appendChild(noteBtn); quickActions.appendChild(taskBtn); quickActions.appendChild(copilotBtn); quickActions.appendChild(openBtn); content.appendChild(quickActions);
  
          if (membership && professionalStore) {
            var profile = professionalStore.contacts && professionalStore.contacts[membership.item.id] ? professionalStore.contacts[membership.item.id] : { notes: [], tasks: [] };
            var managers = document.createElement("div"); managers.className = "extuiCrmInlineManagers";
            function localDateTimeValue(ms) {
              if (!ms) return "";
              var date = new Date(Number(ms));
              if (!Number.isFinite(date.getTime())) return "";
              var local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
              return local.toISOString().slice(0, 16);
            }
            function makeManager(title, count, open) {
              var details = document.createElement("details"); details.className = "extuiCrmInlineManager"; details.open = open;
              var summary = document.createElement("summary"); summary.className = "extuiCrmInlineManagerSummary";
              var label = document.createElement("span"); label.textContent = title;
              var badge = document.createElement("strong"); badge.textContent = String(count);
              summary.appendChild(label); summary.appendChild(badge); details.appendChild(summary);
              var list = document.createElement("div"); list.className = "extuiCrmInlineManagerList"; details.appendChild(list);
              managers.appendChild(details);
              return list;
            }
            var notesList = Array.isArray(profile.notes) ? profile.notes.slice().sort(function (a, b) { return Number(b.updatedAtMs || b.createdAtMs || 0) - Number(a.updatedAtMs || a.createdAtMs || 0); }) : [];
            var notesManager = makeManager("Notas", notesList.length, notesList.length > 0);
            if (!notesList.length) {
              var notesEmpty = document.createElement("div"); notesEmpty.className = "extuiCrmInlineEmpty"; notesEmpty.textContent = "Nenhuma nota registrada para este contato."; notesManager.appendChild(notesEmpty);
            }
            notesList.forEach(function (note) {
              var row = document.createElement("article"); row.className = "extuiCrmInlineRow extuiCrmInlineNote";
              var copy = document.createElement("div"); copy.className = "extuiCrmInlineRowCopy";
              var fallbackTitle = String(note.title || "").trim() || (String(note.text || "").trim().slice(0, 42) || "Nota");
              var noteTitle = document.createElement("strong"); noteTitle.textContent = fallbackTitle; noteTitle.title = fallbackTitle;
              var text = document.createElement("p"); text.textContent = note.text || "";
              var meta = document.createElement("small"); meta.textContent = (note.author || "Usuário local") + " · " + (note.updatedAtMs ? fmtDateTime(note.updatedAtMs) : "Sem data");
              copy.appendChild(noteTitle); copy.appendChild(text); copy.appendChild(meta);
              var actions = document.createElement("div"); actions.className = "extuiCrmInlineRowActions";
              var edit = document.createElement("button"); edit.type = "button"; edit.className = "extuiCrmInlineIconBtn"; edit.title = "Editar nota"; edit.setAttribute("aria-label", "Editar nota"); edit.textContent = "✎";
              edit.addEventListener("click", function () {
                row.innerHTML = "";
                var form = document.createElement("form"); form.className = "extuiCrmInlineEditForm";
                var titleInput = document.createElement("input"); titleInput.type = "text"; titleInput.maxLength = 120; titleInput.value = note.title || ""; titleInput.placeholder = "Título da nota"; titleInput.setAttribute("aria-label", "Título da nota");
                var input = document.createElement("textarea"); input.value = note.text || ""; input.setAttribute("aria-label", "Conteúdo da nota");
                var bar = document.createElement("div"); bar.className = "extuiCrmInlineEditActions";
                var cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "extuiNavSecondaryBtn"; cancel.textContent = "Cancelar"; cancel.addEventListener("click", function () { reload(true); });
                var save = document.createElement("button"); save.type = "submit"; save.className = "extuiNavPrimaryBtn"; save.textContent = "Salvar";
                bar.appendChild(cancel); bar.appendChild(save); form.appendChild(titleInput); form.appendChild(input); form.appendChild(bar); row.appendChild(form); titleInput.focus();
                form.addEventListener("submit", async function (event) { event.preventDefault(); var value = input.value.trim(); if (!value) return; save.disabled = true; try { await extCrmProfessionalOperation({ type: "note.update", crmContactId: membership.item.id, noteId: note.id, patch: { title: titleInput.value.trim(), text: value, author: "Usuário local" } }); toast("Nota atualizada."); reload(true); } catch (error) { toast(error.message, true); save.disabled = false; } });
              });
              var remove = document.createElement("button"); remove.type = "button"; remove.className = "extuiCrmInlineIconBtn is-danger"; remove.title = "Excluir nota"; remove.setAttribute("aria-label", "Excluir nota"); remove.textContent = "×";
              remove.addEventListener("click", async function () { if (!(await window.extConfirm("Excluir esta nota?", { danger: true }))) return; try { await extCrmProfessionalOperation({ type: "note.remove", crmContactId: membership.item.id, noteId: note.id }); toast("Nota excluída."); reload(true); } catch (error) { toast(error.message, true); } });
              actions.appendChild(edit); actions.appendChild(remove); row.appendChild(copy); row.appendChild(actions); notesManager.appendChild(row);
            });
  
            var tasksList = Array.isArray(profile.tasks) ? profile.tasks.slice().sort(function (a, b) { return (a.status === "completed") - (b.status === "completed") || Number(a.dueAtMs || Infinity) - Number(b.dueAtMs || Infinity); }) : [];
            var tasksManager = makeManager("Tarefas", tasksList.length, tasksList.length > 0);
            if (!tasksList.length) {
              var tasksEmpty = document.createElement("div"); tasksEmpty.className = "extuiCrmInlineEmpty"; tasksEmpty.textContent = "Nenhuma tarefa registrada para este contato."; tasksManager.appendChild(tasksEmpty);
            }
            tasksList.forEach(function (task) {
              var row = document.createElement("article"); row.className = "extuiCrmInlineRow extuiCrmInlineTask" + (task.status === "completed" ? " is-completed" : "");
              var toggle = document.createElement("input"); toggle.type = "checkbox"; toggle.checked = task.status === "completed"; toggle.setAttribute("aria-label", (toggle.checked ? "Reabrir " : "Concluir ") + (task.title || "tarefa"));
              toggle.addEventListener("change", async function () { toggle.disabled = true; try { var patch = { status: toggle.checked ? "completed" : "open" }; if (toggle.checked && task.actionScheduleId && task.actionStatus === "scheduled") { await cancelTaskSchedule(task); patch.actionStatus = "cancelled"; } await extCrmProfessionalOperation({ type: "task.update", crmContactId: membership.item.id, taskId: task.id, patch: patch }); toast(toggle.checked ? "Tarefa concluída." : "Tarefa reaberta."); reload(true); } catch (error) { toast(error.message, true); toggle.checked = !toggle.checked; toggle.disabled = false; } });
              var copy = document.createElement("div"); copy.className = "extuiCrmInlineRowCopy";
              var title = document.createElement("strong"); title.textContent = task.title || "Tarefa";
              var objectiveText = String(task.description || "").trim(); if (objectiveText) { var objective = document.createElement("p"); objective.className = "extuiCrmTaskObjective"; objective.textContent = objectiveText; copy.appendChild(title); copy.appendChild(objective); } else copy.appendChild(title);
              var metaParts = []; metaParts.push(task.dueAtMs ? "Prazo · " + fmtDateTime(task.dueAtMs) : (task.status === "completed" ? "Concluída" : "Sem prazo")); metaParts.push("Prioridade · " + ({low:"Baixa",normal:"Normal",high:"Alta"}[task.priority]||"Normal")); if (task.action) metaParts.push(actionLabel(task.action) + (task.actionStatus === "error" ? " · erro" : task.actionStatus === "executed" ? " · executada" : task.actionStatus === "cancelled" ? " · cancelada" : " · programada"));
              var meta = document.createElement("small"); meta.textContent = metaParts.join(" · "); copy.appendChild(meta);
              var actions = document.createElement("div"); actions.className = "extuiCrmInlineRowActions";
              var edit = document.createElement("button"); edit.type = "button"; edit.className = "extuiCrmInlineIconBtn"; edit.title = "Editar tarefa"; edit.setAttribute("aria-label", "Editar tarefa"); edit.textContent = "✎";
              edit.addEventListener("click", function () {
                row.innerHTML = "";
                var form = document.createElement("form"); form.className = "extuiCrmInlineEditForm";
                var input = document.createElement("input"); input.type = "text"; input.value = task.title || ""; input.setAttribute("aria-label", "Título da tarefa");
                var objective = document.createElement("textarea"); objective.value = task.description || ""; objective.placeholder = "Objetivo / o que precisa ser feito"; objective.setAttribute("aria-label", "Objetivo da tarefa");
                var due = document.createElement("input"); due.type = "datetime-local"; due.value = localDateTimeValue(task.dueAtMs); due.setAttribute("aria-label", "Prazo da tarefa");
                var priorityEdit = document.createElement("select"); [["low","Baixa"],["normal","Normal"],["high","Alta"]].forEach(function(x){ priorityEdit.appendChild(new Option(x[1],x[0])); }); priorityEdit.value = ["low","normal","high"].indexOf(task.priority)>=0 ? task.priority : "normal"; priorityEdit.setAttribute("aria-label","Prioridade da tarefa");
                var bar = document.createElement("div"); bar.className = "extuiCrmInlineEditActions";
                var cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "extuiNavSecondaryBtn"; cancel.textContent = "Cancelar"; cancel.addEventListener("click", function () { reload(true); });
                var save = document.createElement("button"); save.type = "submit"; save.className = "extuiNavPrimaryBtn"; save.textContent = "Salvar";
                bar.appendChild(cancel); bar.appendChild(save); form.appendChild(input); form.appendChild(objective); var editMeta=document.createElement("div"); editMeta.className="extuiCrmTaskMetaGrid"; editMeta.appendChild(extField("Prazo",due)); editMeta.appendChild(extField("Prioridade",priorityEdit)); form.appendChild(editMeta); form.appendChild(bar); row.appendChild(form); input.focus();
                form.addEventListener("submit", async function (event) { event.preventDefault(); var value = input.value.trim(); if (!value) return; save.disabled = true; try { var nextDue = due.value ? parseLocalDateTimeStrict(due.value) : null;if(due.value&&!Number.isFinite(nextDue))throw new Error("Prazo com data ou horário local inválido.");var patch = { title: value, description: objective.value.trim(), dueAtMs: nextDue, priority: priorityEdit.value }; if (task.action && task.actionStatus !== "executed") { await cancelTaskSchedule(task); if (nextDue && nextDue > Date.now()) { var nextSchedule = await scheduleTaskAction(task.id, value, nextDue, task.action); patch.actionScheduleId = nextSchedule.id; patch.actionStatus = "scheduled"; } else { patch.actionScheduleId = null; patch.actionStatus = "cancelled"; } } await extCrmProfessionalOperation({ type: "task.update", crmContactId: membership.item.id, taskId: task.id, patch: patch }); toast("Tarefa atualizada."); reload(true); } catch (error) { toast(error.message, true); save.disabled = false; } });
              });
              var remove = document.createElement("button"); remove.type = "button"; remove.className = "extuiCrmInlineIconBtn is-danger"; remove.title = "Excluir tarefa"; remove.setAttribute("aria-label", "Excluir tarefa"); remove.textContent = "×";
              remove.addEventListener("click", async function () { if (!(await window.extConfirm("Excluir esta tarefa?", { danger: true }))) return; try { await cancelTaskSchedule(task); await extCrmProfessionalOperation({ type: "task.remove", crmContactId: membership.item.id, taskId: task.id }); toast("Tarefa excluída."); reload(true); } catch (error) { toast(error.message, true); } });
              actions.appendChild(edit); actions.appendChild(remove); row.appendChild(toggle); row.appendChild(copy); row.appendChild(actions); tasksManager.appendChild(row);
            });
            content.appendChild(managers);
          }
        } catch (err) { content.innerHTML = '<div class="extuiSideItensEmpty">Não foi possível carregar o contato atual.</div>'; }
      }
      reload(true);
      reloadCrmsTab();
      var crmEventBus=window.__extEventBus;
      if(crmEventBus&&typeof crmEventBus.on==="function")extPanelOwn(root,crmEventBus.on("ActiveChatChanged",function(){if(root.classList.contains("extuiOpen"))reload(true);}));
      var crmRefreshTimer=setInterval(function () { if(!document.hidden&&root.classList.contains("extuiOpen"))reload(false); }, 90000);
      extPanelOwn(root,function(){clearInterval(crmRefreshTimer);});
      extPanelOnKeyChange(root, CRM_KEY, function () { reload(true); reloadCrmsTab(); });
      extPanelOnKeyChange(root, SCHEDULE_KEY, function () { reload(true); });
      extPanelOnKeyChange(root, FOLLOWUP_QUEUE_KEY, function () { reload(true); });
      extPanelOnKeyChange(root, CRM_PROFESSIONAL_KEY, function () { reload(true); });
      return root;
    }

    return Object.freeze({buildCrmPanel:buildCrmPanel});
  };
})();
