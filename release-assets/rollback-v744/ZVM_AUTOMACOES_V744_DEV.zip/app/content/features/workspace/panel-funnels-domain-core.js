;(function(){
  "use strict";
  if(window.__extCreateFunnelsPanelDomainCore)return;
  window.__extCreateFunnelsPanelDomainCore=function(deps){
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,PANEL_BRAND=deps.panelBrand||{},extGet=deps.get,parsePersisted=deps.parsePersisted,extPanelOnKeyChange=deps.panelOnKeyChange,extWorkspace=deps.workspace,extGetActiveContactContext=deps.getActiveContactContext,toast=deps.toast,extAutomationExecutionMessage=deps.executionMessage,extEmptyState=deps.emptyState,extAutomationResourceTitle=deps.resourceTitle,extAutomationResourceStepCount=deps.stepCount,openShellHtml=deps.openShellHtml,panelState=deps.panelState,iconChip=deps.iconChip,escHtml=deps.escHtml;
    if([buildPanelShell,extGet,parsePersisted,extPanelOnKeyChange,extGetActiveContactContext,toast,extAutomationExecutionMessage,extEmptyState,extAutomationResourceTitle,extAutomationResourceStepCount,openShellHtml,iconChip,escHtml].some(function(fn){return typeof fn!=="function";})||!extWorkspace||!panelState)throw new TypeError("Dependências do domínio Funis inválidas.");
    var FUNNEL_KEY=deps.funnelKey||"EXTUI:extappFunnelStore";


    async function buildFunisPanel() {
      var root = buildPanelShell({
        id: "extuiNavFunisPanel", title: "Funis", accent: PANEL_BRAND.funis.accent, icon: PANEL_BRAND.funis.icon, eyebrow: "Automação",
        hint: "Execute sequências prontas e acompanhe o que já está rodando.",
        size: "md", footer: true
      });
      var body = root.querySelector(".extuiNavPanelBody");
      var footer = root.querySelector("[data-extui-panel-footer]");
      var summary = document.createElement("div"); summary.className = "extuiAutomationResourceSummary"; body.appendChild(summary);
      var listEl = document.createElement("div"); listEl.className = "extuiDockedPanelList extuiAutomationResourceList"; body.appendChild(listEl);
      var reloadSeq = 0;
      if (footer) {
        footer.hidden = false;
        var manage = document.createElement("button"); manage.type = "button"; manage.className = "extuiNavSecondaryBtn extuiAutomationManageBtn"; manage.textContent = "Abrir editor de Funis";
        manage.addEventListener("click", function () { openShellHtml("funis", { reuseExisting: true }); }); footer.appendChild(manage);
      }

      async function executeFunnel(funnel, button) {
        var ctx = await extGetActiveContactContext();
        if (!ctx || !ctx.chatId) { toast("Abra uma conversa antes de executar o Funil.", true); return; }
        var allowed = await window.extConfirm('Executar o funil "' + String(funnel.name || "Funil") + '" na conversa atual? A sequência pode começar a enviar mensagens reais imediatamente.', { okLabel: "Executar agora", cancelLabel: "Cancelar" });
        if (!allowed) return;
        button.disabled = true;
        try { await window.__extFunnelsStartManually(funnel.id, ctx.chatId, { isTest: false }); toast("Funil iniciado na conversa atual."); reload(); }
        catch (error) { toast(extAutomationExecutionMessage(error, "funnel"), true); }
        finally { button.disabled = false; }
      }

      async function reload() {
        var seq = ++reloadSeq;
        listEl.innerHTML = '<div class="extuiSideItensEmpty">Carregando...</div>';
        var raw, funnels;
        try { raw = await extGet(FUNNEL_KEY); if (seq !== reloadSeq) return; var state = parsePersisted(raw); funnels = (state && state.funnelList) || []; }
        catch (err) { if (seq !== reloadSeq) return; listEl.innerHTML = '<div class="extuiSideItensEmpty">Erro ao carregar</div>'; summary.textContent = ""; return; }
        var funnelRunningCounts = Object.create(null);
        if (typeof window.__extFunnelsCountRunningByFunnelId === "function") {
          await Promise.all(funnels.map(async function (funnel) {
            try { funnelRunningCounts[funnel.id] = Number(await window.__extFunnelsCountRunningByFunnelId(funnel.id)) || 0; }
            catch (_) { funnelRunningCounts[funnel.id] = 0; }
          }));
        }
        if (seq !== reloadSeq) return;
        var runningCount = funnels.reduce(function (total, funnel) { return total + (funnelRunningCounts[funnel.id] || 0); }, 0);
        summary.innerHTML = '<span><strong>' + funnels.length + '</strong> cadastrado(s)</span><span><strong>' + runningCount + '</strong> em execução</span>';
        if (funnels.length === 0) { listEl.innerHTML = ""; listEl.appendChild(extEmptyState(PANEL_BRAND.funis.accent, PANEL_BRAND.funis.icon, "Nenhum funil cadastrado", "Crie uma sequência no Painel de Controle e ela aparecerá aqui pronta para uso.", "Criar primeiro Funil", function(){ openShellHtml("funis", { reuseExisting: true }); }, { sober: true })); return; }
        listEl.innerHTML = "";
        funnels.forEach(function (f) {
          var row = document.createElement("div"); row.className = "extuiDockedPanelRow extuiResourceCard extuiResourceCard--funnel";
          var running = funnelRunningCounts[f.id] || 0;
          var funnelTitle = extAutomationResourceTitle(f, f.id || "Funil");
          var funnelSteps = extAutomationResourceStepCount(f, "funnel");
          row.title = funnelTitle;
          row.innerHTML = iconChip(PANEL_BRAND.funis.accent,PANEL_BRAND.funis.icon,true) + '<div class="extuiResourceCardCopy"><div class="extuiDockedPanelRowTitle" title="'+escHtml(funnelTitle)+'">' + escHtml(funnelTitle) + '</div><div class="extuiDockedPanelRowMeta"><span class="extuiResourceBadge">' + funnelSteps + ' etapa(s)</span><span class="extuiResourceMetaText">Sequência</span>' + (running ? '<span class="extuiAutomationStateBadge is-running">' + running + ' executando</span>' : '') + '</div></div>';
          var actions = document.createElement("div"); actions.className = "extuiPanelRowActions extuiAutomationResourceActions";
          var run = document.createElement("button"); run.type = "button"; run.className = "extuiNavPrimaryBtn"; run.textContent = "Executar"; run.title = "Executar na conversa atual"; run.addEventListener("click", function () { executeFunnel(f, run); });
          var edit = document.createElement("button"); edit.type = "button"; edit.className = "extuiNavSecondaryBtn"; edit.textContent = "Editar"; edit.addEventListener("click", function () { openShellHtml("funis", { funnelId: f.id, reuseExisting: true }); });
          actions.appendChild(run); actions.appendChild(edit); row.appendChild(actions); listEl.appendChild(row);
        });
      }
      panelState.setRefresh(root, reload);
      reload();
      extPanelOnKeyChange(root, FUNNEL_KEY, function () { if (root.isConnected) { if (extWorkspace.isOpen(root)) reload(); else panelState.markDirty(root, true); } });
      extPanelOnKeyChange(root, "EXTUI:extappFunnelRunningStore", function () { if (root.isConnected) { if (extWorkspace.isOpen(root)) reload(); else panelState.markDirty(root, true); } });
      return root;
    }
    return Object.freeze({buildFunisPanel:buildFunisPanel,funnelKey:FUNNEL_KEY});
  };
})();
