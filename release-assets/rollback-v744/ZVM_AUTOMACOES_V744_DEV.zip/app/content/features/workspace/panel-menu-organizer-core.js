;
(function () {
  "use strict";
  if (window.__extCreatePanelMenuOrganizerCore) return;
  window.__extCreatePanelMenuOrganizerCore = function (config) {
    config = config || {};
    var buildPanelShell=config.buildPanelShell;
    var panelBody=config.panelBody;
    var extWorkspace=config.workspace;
    var ensurePanel=config.ensurePanel;
    var buildMenusPanelsPanel=config.buildMenusPanelsPanel;
    var extSyncActiveNavButtons=config.syncNav;
    var extConfigureToggleRow=config.configureToggleRow;
    var extGet=config.get;
    var extSet=config.set;
    var toast=config.toast;
    var escHtml=config.escHtml;
    var NAV_ICONS=config.navIcons||{};
    var EXTUI_QUICK_MENU_ICON=config.quickMenuIcon||"";
    var OPTIONS_KEY=config.optionsKey;
    var OPTIONS_DEFAULTS=config.optionsDefaults||{};
    var NEW_INSTALL_OPTIONS_DEFAULTS=config.newInstallOptionsDefaults||{};
    var QUICK_MENU_CONFIG_ITEMS=config.quickMenuConfigItems||[];
    var menusPanelsReturnBound=new WeakSet();
    function extConfigureMenuBackToMenusPanels(root){
      var back=root.querySelector("[data-back]");
      if(back&&!menusPanelsReturnBound.has(back)){menusPanelsReturnBound.add(back);back.hidden=false;back.title="Voltar a Menus & Painéis";back.addEventListener("click",async function(ev){ev.preventDefault();ev.stopImmediatePropagation();var parent=await ensurePanel("menus-paineis",buildMenusPanelsPanel);extWorkspace.open(parent);extSyncActiveNavButtons();},true);}
    }
    async function buildConfigureMenuPanel() {
      var root=buildPanelShell({id:"extuiNavConfigureMenuPanel",title:"Configurar Menu",accent:"#f59e0b",icon:NAV_ICONS.configurarMenu,eyebrow:"Menus & Painéis",hint:"Arraste os atalhos e separadores para montar a Sidebar do seu jeito.",size:"md",tutorialKey:"configurar-menu"});
      var body=panelBody(root);body.innerHTML="";extConfigureMenuBackToMenusPanels(root);
      var v2Storage=window.__EXT_SIDEBAR_ENABLED__===true&&window.ExtensionUI&&window.ExtensionUI.sidebarStorage?window.ExtensionUI.sidebarStorage:null;
      var registry=window.ExtensionUI&&window.ExtensionUI.sidebarRegistry?window.ExtensionUI.sidebarRegistry:null;
      var icons=window.ExtensionUI&&window.ExtensionUI.sidebarIcons?window.ExtensionUI.sidebarIcons:null;
      var constants=window.ExtensionUI&&window.ExtensionUI.sidebarConstants?window.ExtensionUI.sidebarConstants:null;
      var workspace=window.ExtensionUI&&window.ExtensionUI.workspaceProfile?window.ExtensionUI.workspaceProfile:null;
      if(!v2Storage||!registry){var unavailable=document.createElement("div");unavailable.className="extuiMenuDnDUnavailable";unavailable.innerHTML='<strong>Configuração da Sidebar indisponível</strong><span>Recarregue o WhatsApp Web para inicializar a Sidebar atual.</span>';body.appendChild(unavailable);return root;}
      var state=await v2Storage.load();
      var allKeys=(typeof registry.configurableKeys==="function"?registry.configurableKeys():registry.pinEligibleKeys().concat(["tools","notifications"])).filter(function(key,index,list){return list.indexOf(key)===index;});
      var labelFallback={items:"Itens",crm:"CRM",broadcast:"Disparo em massa",flow:"Fluxos",funnel:"Funis",followup:"FollowUp",activity:"Envios","quick-response":"Respostas Rápidas","auto-service":"Autoatendimento",orders:"Encomendas",delivery:"Entregas","crm-funnel":"Funil CRM","text-assistant":"Assistente de texto","text-replace":"Substituição de texto",export:"Exportar contatos",google:"Google",status:"Status",agenda:"Agenda",notes:"Notas",reminder:"Lembrete",signature:"Assinatura","google-calendar":"Google Calendar",webhooks:"Webhooks","theme-toggle":"Alterar Modo",tools:"Ferramentas",labels:"Etiquetas",notifications:"Notificações"};
      var factoryVisible=["items","crm","broadcast","flow","funnel","followup","activity","quick-response","auto-service","orders","delivery","crm-funnel","text-assistant","text-replace","export","google"];
      var factoryFixed=["notifications"];
      var factoryHidden=["status","agenda","notes","reminder","signature","google-calendar","webhooks","theme-toggle","tools","labels"];
      var saveQueue=Promise.resolve();
      var draggedKey="";
      var live=document.createElement("div");live.className="extuiMenuDnDLive";live.setAttribute("aria-live","polite");live.setAttribute("aria-atomic","true");body.appendChild(live);
  
      var intro=document.createElement("section");intro.className="extuiMenuDnDIntro";
      intro.innerHTML='<div><strong>Organize do seu jeito</strong><span>Arraste os botões entre as áreas. Adicione separadores somente onde quiser criar uma divisão visual na Sidebar.</span></div>';
      var introActions=document.createElement("div");introActions.className="extuiMenuDnDIntroActions";
      var addSeparatorBtn=document.createElement("button");addSeparatorBtn.type="button";addSeparatorBtn.className="extuiNavSecondaryBtn extuiMenuAddSeparatorBtn";addSeparatorBtn.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16"/><path d="M12 6v12"/></svg><span>Adicionar separador</span>';
      introActions.appendChild(addSeparatorBtn);intro.appendChild(introActions);body.appendChild(intro);
  
      function isSeparatorKey(key){return !!(registry&&typeof registry.isSeparatorKey==="function"&&registry.isSeparatorKey(key));}
      function separatorKeys(){return (Array.isArray(state.separators)?state.separators:[]).filter(function(key,index,list){return isSeparatorKey(key)&&list.indexOf(key)===index;});}
      function layoutKeys(){return allKeys.concat(separatorKeys());}
      function itemFor(key){return registry.get(key)||null;}
      function labelFor(key){if(isSeparatorKey(key))return "Separador";var item=itemFor(key);return item&&item.label||labelFallback[key]||key;}
      function iconFor(key){if(isSeparatorKey(key))return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12h18"/></svg>';var item=itemFor(key);return icons&&item?icons.svg(item.icon):'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/></svg>';}
      function normalizeOrder(keys){var allowed=layoutKeys(),out=[];(Array.isArray(keys)?keys:[]).concat(allowed).forEach(function(key){if(allowed.indexOf(key)>=0&&out.indexOf(key)<0)out.push(key);});return out;}
      function currentLists(){var order=normalizeOrder(state.order),visibleSet=new Set(Array.isArray(state.pinned)?state.pinned:[]),fixedSet=new Set(Array.isArray(state.footerPinned)?state.footerPinned:[]),visible=[],fixed=[],hidden=[];order.forEach(function(key){if(fixedSet.has(key))fixed.push(key);else if(visibleSet.has(key))visible.push(key);else if(isSeparatorKey(key))visible.push(key);else hidden.push(key);});return{visible:visible,fixed:fixed,hidden:hidden};}
      function layoutState(visible,fixed,hidden,separators){separators=(Array.isArray(separators)?separators:[]).filter(function(key,index,list){return isSeparatorKey(key)&&list.indexOf(key)===index;});var separatorSet=new Set(separators),allowed=function(key){return allKeys.indexOf(key)>=0||separatorSet.has(key);};visible=(Array.isArray(visible)?visible:[]).filter(function(key,index,list){return allowed(key)&&list.indexOf(key)===index;});fixed=(Array.isArray(fixed)?fixed:[]).filter(function(key,index,list){return allowed(key)&&visible.indexOf(key)<0&&list.indexOf(key)===index;});hidden=(Array.isArray(hidden)?hidden:[]).filter(function(key,index,list){return allKeys.indexOf(key)>=0&&visible.indexOf(key)<0&&fixed.indexOf(key)<0&&list.indexOf(key)===index;});allKeys.forEach(function(key){if(visible.indexOf(key)<0&&fixed.indexOf(key)<0&&hidden.indexOf(key)<0)hidden.push(key);});separators.forEach(function(key){if(visible.indexOf(key)<0&&fixed.indexOf(key)<0)visible.push(key);});return{visible:visible,fixed:fixed,hidden:hidden,separators:separators};}
      function announce(text){live.textContent=String(text||"");}
      async function commit(visible,fixed,hidden,message,separatorsOverride){var separators=Array.isArray(separatorsOverride)?separatorsOverride.slice():separatorKeys(),layout=layoutState(visible,fixed,hidden,separators);saveQueue=saveQueue.catch(function(){}).then(async function(){state=await v2Storage.save(Object.assign({},state,{schemaVersion:constants&&constants.SCHEMA_VERSION||15,pinned:layout.visible.slice(),footerPinned:layout.fixed.slice(),order:layout.visible.concat(layout.fixed,layout.hidden),separators:layout.separators.slice()}));render();if(message)announce(message);return state;});return saveQueue;}
  
      var zoneVisible=buildZone("visible","Visíveis na Sidebar","Arraste aqui os botões e separadores que devem aparecer. A posição define a ordem.");
      var zoneFixed=buildZone("fixed","Visíveis e fixados na Sidebar","Itens desta área permanecem acima de Sistema.");
      var zoneHidden=buildZone("hidden","Ocultos","Botões desta área não ocupam espaço na Sidebar e podem ser movidos de volta quando você quiser.");
      body.appendChild(zoneVisible.wrap);body.appendChild(zoneFixed.wrap);body.appendChild(zoneHidden.wrap);
  
      function buildZone(kind,title,desc){var wrap=document.createElement("section");wrap.className="extuiMenuDnDZone extuiMenuDnDZone--"+kind;wrap.dataset.zone=kind;var head=document.createElement("div");head.className="extuiMenuDnDZoneHead";var copy=document.createElement("div");copy.innerHTML='<strong>'+escHtml(title)+'</strong><span>'+escHtml(desc)+'</span>';var count=document.createElement("span");count.className="extuiMenuDnDCount";head.appendChild(copy);head.appendChild(count);var grid=document.createElement("div");grid.className="extuiMenuDnDGrid";grid.dataset.zone=kind;wrap.appendChild(head);wrap.appendChild(grid);
        [wrap,grid].forEach(function(target){target.addEventListener("dragover",function(ev){if(!draggedKey)return;if(kind==="hidden"&&isSeparatorKey(draggedKey)){if(ev.dataTransfer)ev.dataTransfer.dropEffect="none";return;}ev.preventDefault();if(ev.dataTransfer)ev.dataTransfer.dropEffect="move";wrap.classList.add("is-drop-zone");});target.addEventListener("dragleave",function(ev){if(!wrap.contains(ev.relatedTarget))wrap.classList.remove("is-drop-zone");});target.addEventListener("drop",function(ev){if(!draggedKey)return;ev.preventDefault();ev.stopPropagation();wrap.classList.remove("is-drop-zone");if(kind==="hidden"&&isSeparatorKey(draggedKey)){announce("Separadores não ficam ocultos. Exclua o bloco se não precisar mais dele.");return;}dropAtEnd(kind,draggedKey);});});
        return{wrap:wrap,head:head,count:count,grid:grid};}
  
      function makeTile(key,kind,index){var separator=isSeparatorKey(key),tile=document.createElement("div");tile.className="extuiMenuDnDTile"+(separator?" is-separator":"");tile.draggable=true;tile.tabIndex=0;tile.setAttribute("role","button");tile.dataset.key=key;tile.dataset.zone=kind;tile.setAttribute("aria-label",labelFor(key)+". Arraste para mover ou reordenar.");tile.innerHTML='<span class="extuiMenuDnDIcon">'+iconFor(key)+'</span><span class="extuiMenuDnDLabel"></span><span class="extuiMenuDnDGrip" aria-hidden="true">⋮⋮</span>';tile.querySelector('.extuiMenuDnDLabel').textContent=labelFor(key);
        if(separator){var del=document.createElement("button");del.type="button";del.className="extuiMenuDnDDelete";del.title="Excluir separador";del.setAttribute("aria-label","Excluir separador");del.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M7 7l1 13h8l1-13"/><path d="M10 11v5M14 11v5"/></svg>';del.addEventListener("click",function(ev){ev.preventDefault();ev.stopPropagation();deleteSeparator(key);});tile.appendChild(del);}
        tile.addEventListener("dragstart",function(ev){draggedKey=key;tile.classList.add("is-dragging");document.documentElement.classList.add("extuiMenuDnDDragging");if(ev.dataTransfer){ev.dataTransfer.effectAllowed="move";ev.dataTransfer.setData("text/plain",key);try{ev.dataTransfer.setData("application/x-ext-menu-key",key);}catch(_){}}});
        tile.addEventListener("dragend",function(){draggedKey="";tile.classList.remove("is-dragging");document.documentElement.classList.remove("extuiMenuDnDDragging");document.querySelectorAll('.extuiMenuDnDZone.is-drop-zone,.extuiMenuDnDTile.is-drop-target').forEach(function(el){el.classList.remove("is-drop-zone","is-drop-target");});});
        tile.addEventListener("dragover",function(ev){if(!draggedKey||draggedKey===key)return;if(kind==="hidden"&&isSeparatorKey(draggedKey))return;ev.preventDefault();ev.stopPropagation();tile.classList.add("is-drop-target");if(ev.dataTransfer)ev.dataTransfer.dropEffect="move";});
        tile.addEventListener("dragleave",function(){tile.classList.remove("is-drop-target");});
        tile.addEventListener("drop",function(ev){if(!draggedKey||draggedKey===key)return;ev.preventDefault();ev.stopPropagation();tile.classList.remove("is-drop-target");if(kind==="hidden"&&isSeparatorKey(draggedKey)){announce("Separadores não ficam ocultos. Exclua o bloco se não precisar mais dele.");return;}dropBefore(kind,draggedKey,key);});
        tile.addEventListener("keydown",function(ev){if(ev.target&&ev.target.closest&&ev.target.closest("button"))return;if(ev.key!=="Enter"&&ev.key!==" ")return;ev.preventDefault();var lists=currentLists(),visible=lists.visible.slice(),fixed=lists.fixed.slice(),hidden=lists.hidden.slice();if(separator){if(kind==="visible"){visible=visible.filter(function(x){return x!==key;});fixed.push(key);commit(visible,fixed,hidden,"Separador movido para a área fixa.");}else{fixed=fixed.filter(function(x){return x!==key;});visible.push(key);commit(visible,fixed,hidden,"Separador movido para a área principal.");}return;}if(kind==="hidden"){hidden=hidden.filter(function(x){return x!==key;});visible.push(key);commit(visible,fixed,hidden,labelFor(key)+" exibido na Sidebar.");return;}if(kind==="visible")visible=visible.filter(function(x){return x!==key;});if(kind==="fixed")fixed=fixed.filter(function(x){return x!==key;});hidden.push(key);commit(visible,fixed,hidden,labelFor(key)+" movido para Ocultos.");});
        return tile;}
      function dropAtEnd(kind,key){var lists=currentLists(),visible=lists.visible.filter(function(x){return x!==key;}),fixed=lists.fixed.filter(function(x){return x!==key;}),hidden=lists.hidden.filter(function(x){return x!==key;});if(kind==="hidden"&&isSeparatorKey(key)){announce("Separadores não ficam ocultos. Exclua o bloco se não precisar mais dele.");return;}(kind==="visible"?visible:kind==="fixed"?fixed:hidden).push(key);commit(visible,fixed,hidden,labelFor(key)+(kind==="visible"?" exibido na Sidebar.":kind==="fixed"?" fixado na Sidebar.":" movido para Ocultos."));}
      function dropBefore(kind,key,targetKey){if(kind==="hidden"&&isSeparatorKey(key)){announce("Separadores não ficam ocultos. Exclua o bloco se não precisar mais dele.");return;}var lists=currentLists(),visible=lists.visible.filter(function(x){return x!==key;}),fixed=lists.fixed.filter(function(x){return x!==key;}),hidden=lists.hidden.filter(function(x){return x!==key;}),list=kind==="visible"?visible:kind==="fixed"?fixed:hidden,at=list.indexOf(targetKey);if(at<0)at=list.length;list.splice(at,0,key);var zoneLabel=kind==="visible"?"Visíveis":kind==="fixed"?"Fixados":"Ocultos";commit(visible,fixed,hidden,labelFor(key)+" movido para a posição "+(at+1)+" em "+zoneLabel+".");}
      function newSeparatorKey(){return "separator:"+Date.now().toString(36)+Math.random().toString(36).slice(2,7);}
      function addSeparator(){var lists=currentLists(),key=newSeparatorKey(),separators=separatorKeys();while(separators.indexOf(key)>=0)key=newSeparatorKey();separators.push(key);lists.visible.push(key);commit(lists.visible,lists.fixed,lists.hidden,"Separador adicionado. Arraste-o para a posição desejada.",separators);}
      function deleteSeparator(key){if(!isSeparatorKey(key))return;var lists=currentLists(),separators=separatorKeys().filter(function(x){return x!==key;});commit(lists.visible.filter(function(x){return x!==key;}),lists.fixed.filter(function(x){return x!==key;}),lists.hidden,"Separador excluído.",separators);}
      function render(){var lists=currentLists();zoneVisible.grid.innerHTML="";zoneFixed.grid.innerHTML="";zoneHidden.grid.innerHTML="";lists.visible.forEach(function(key,index){zoneVisible.grid.appendChild(makeTile(key,"visible",index));});lists.fixed.forEach(function(key,index){zoneFixed.grid.appendChild(makeTile(key,"fixed",index));});lists.hidden.forEach(function(key,index){zoneHidden.grid.appendChild(makeTile(key,"hidden",index));});zoneVisible.count.textContent=String(lists.visible.length);zoneFixed.count.textContent=String(lists.fixed.length);zoneHidden.count.textContent=String(lists.hidden.length);zoneVisible.wrap.classList.toggle("is-empty",lists.visible.length===0);zoneFixed.wrap.classList.toggle("is-empty",lists.fixed.length===0);zoneHidden.wrap.classList.toggle("is-empty",lists.hidden.length===0);}
      addSeparatorBtn.addEventListener("click",addSeparator);
  
      var restore=document.createElement("section");restore.className="extuiMenuDnDRestore";
      var restoreCopy=document.createElement("div");restoreCopy.innerHTML='<strong>Restaurar configuração</strong><span>Reaplique o menu recomendado pelo modelo atual ou volte ao padrão de fábrica. Os separadores personalizados serão removidos.</span>';
      var restoreActions=document.createElement("div");restoreActions.className="extuiMenuDnDRestoreActions";
      var modelBtn=document.createElement("button");modelBtn.type="button";modelBtn.className="extuiNavSecondaryBtn";modelBtn.textContent="Usar menu do modelo";
      var factoryBtn=document.createElement("button");factoryBtn.type="button";factoryBtn.className="extuiNavSecondaryBtn";factoryBtn.textContent="Padrão de fábrica";
      restoreActions.appendChild(modelBtn);restoreActions.appendChild(factoryBtn);restore.appendChild(restoreCopy);restore.appendChild(restoreActions);body.appendChild(restore);
      var modelPreset=null;
      if(workspace){try{var ws=await workspace.load(),ordered=workspace.orderedKeys(ws);if((!Array.isArray(ordered)||!ordered.length)&&ws&&Array.isArray(ws.activeModels)&&ws.activeModels.length&&ws.activeModels.indexOf("custom")<0){ordered=[];ws.activeModels.forEach(function(id){var keys=workspace.models&&workspace.models[id]||[];keys.forEach(function(key){if(ordered.indexOf(key)<0)ordered.push(key);});});if(ordered.indexOf("activity")<0)ordered.push("activity");}if(Array.isArray(ordered)&&ordered.length){modelPreset=ordered.filter(function(key,index,list){return allKeys.indexOf(key)>=0&&factoryFixed.indexOf(key)<0&&list.indexOf(key)===index;});}}catch(_){modelPreset=null;}}
      if(!modelPreset||!modelPreset.length){modelBtn.disabled=true;modelBtn.title="Nenhum modelo aplicado possui uma configuração de Sidebar disponível.";}else{modelBtn.title="Restaura os botões recomendados pelo modelo aplicado.";}
      modelBtn.addEventListener("click",async function(){if(!modelPreset||!modelPreset.length)return;var hidden=allKeys.filter(function(key){return modelPreset.indexOf(key)<0&&factoryFixed.indexOf(key)<0;});await commit(modelPreset,factoryFixed,hidden,"Menu do modelo aplicado restaurado.",[]);});
      factoryBtn.addEventListener("click",async function(){await commit(factoryVisible,factoryFixed,factoryHidden,"Padrão de fábrica restaurado.",[]);});
      render();
      return root;
    }
    async function buildConfigureQuickMenuPanel(){
      var quickIcon=EXTUI_QUICK_MENU_ICON;
      var root=buildPanelShell({id:"extuiNavConfigureQuickMenuPanel",title:"Configurar Menu Rápido",accent:"#22d3ee",icon:quickIcon,eyebrow:"Menus & Painéis",hint:"Controle o Menu Rápido e escolha quais atalhos ficam visíveis.",size:"sm",tutorialKey:"configurar-menu-rapido"});
      var body=panelBody(root);body.innerHTML="";var opts=Object.assign({},NEW_INSTALL_OPTIONS_DEFAULTS);try{var raw=await extGet(OPTIONS_KEY);if(raw)opts=Object.assign({},OPTIONS_DEFAULTS,typeof raw==="string"?JSON.parse(raw):raw);}catch(_){}
      opts.quickShelfVisibility=opts.quickShelfVisibility&&typeof opts.quickShelfVisibility==="object"?opts.quickShelfVisibility:{};if(typeof opts.quickShelfEnabled!=="boolean")opts.quickShelfEnabled=true;
      if(!Object.prototype.hasOwnProperty.call(opts.quickShelfVisibility,"quick-items.open")&&opts.hideItemsBar===true){opts.quickShelfVisibility["quick-items.open"]=false;try{await extSet(OPTIONS_KEY,{hideItemsBar:false,quickShelfVisibility:opts.quickShelfVisibility});opts.hideItemsBar=false;}catch(_){}}
      extConfigureMenuBackToMenusPanels(root);
      var master=document.createElement("div");master.className="extuiQuickMenuMaster";master.appendChild(extConfigureToggleRow("Exibir Menu Rápido","Oculta ou mostra todo o menu rápido sem apagar as escolhas individuais.",opts.quickShelfEnabled!==false,async function(on){try{opts.quickShelfEnabled=on;await extSet(OPTIONS_KEY,{quickShelfEnabled:on,quickShelfVisibility:opts.quickShelfVisibility});return true;}catch(e){toast("Falha ao salvar a configuração do Menu Rápido.",true);return false;}}));body.appendChild(master);
      var grid=document.createElement("div");grid.className="extuiMenuToggleGrid extuiMenuToggleGrid--quick";body.appendChild(grid);
      var quickItemsPrefRow=null;
      function syncQuickItemsPreferenceState(){if(!quickItemsPrefRow)return;var enabled=opts.quickShelfVisibility["quick-items.open"]!==false;var sw=quickItemsPrefRow.querySelector(".extuiSwitch");quickItemsPrefRow.classList.toggle("extuiIsDisabled",!enabled);if(sw){sw.disabled=!enabled;sw.setAttribute("aria-disabled",String(!enabled));}var hint=quickItemsPrefRow.querySelector(".extuiQuickItemsPreferenceHint");if(hint)hint.textContent=enabled?"Ao abrir Itens Rápidos, mostra primeiro apenas os itens favoritados. Você pode alternar para todos no próprio painel.":"Ative Itens Rápidos no Menu Rápido para usar esta preferência.";}
      QUICK_MENU_CONFIG_ITEMS.forEach(function(item){var enabled=opts.quickShelfVisibility[item[0]]!==false;grid.appendChild(extConfigureToggleRow(item[1],"Exibir este botão no Menu Rápido.",enabled,async function(on){try{opts.quickShelfVisibility[item[0]]=on;await extSet(OPTIONS_KEY,{quickShelfEnabled:opts.quickShelfEnabled!==false,quickShelfVisibility:opts.quickShelfVisibility,hideItemsBar:false});if(item[0]==="quick-items.open")syncQuickItemsPreferenceState();return true;}catch(e){toast("Falha ao salvar o Menu Rápido.",true);return false;}}));});
      var pref=document.createElement("section");pref.className="extuiQuickItemsPreferenceSection";var prefHead=document.createElement("div");prefHead.className="extuiQuickItemsPreferenceHead";prefHead.innerHTML='<strong>Itens Rápidos</strong><span>Defina como o painel compacto de itens salvos deve abrir.</span>';pref.appendChild(prefHead);quickItemsPrefRow=extConfigureToggleRow("Abrir mostrando apenas favoritos","",opts.showOnlyFavoritesOnItemsBar===true,async function(on){try{opts.showOnlyFavoritesOnItemsBar=on;await extSet(OPTIONS_KEY,{showOnlyFavoritesOnItemsBar:on});return true;}catch(e){toast("Falha ao salvar a preferência de Itens Rápidos.",true);return false;}});var desc=quickItemsPrefRow.querySelector(".desc");if(desc){desc.classList.add("extuiQuickItemsPreferenceHint");}pref.appendChild(quickItemsPrefRow);body.appendChild(pref);syncQuickItemsPreferenceState();
      return root;
    }
    return Object.freeze({
      buildConfigureMenuPanel: buildConfigureMenuPanel,
      buildConfigureQuickMenuPanel: buildConfigureQuickMenuPanel
    });
  };
})();
