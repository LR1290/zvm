;(function(root){
  "use strict";
  var D=root.__extWorkspaceStaticData||(root.__extWorkspaceStaticData={});
  var PANEL_BRAND=D.PANEL_BRAND,NAV_ICONS=D.NAV_ICONS;
  if(!PANEL_BRAND||!NAV_ICONS)throw new Error("Dados-base do workspace não foram carregados.");
  D.CHAT_TOOL_GROUPS=[
    {title:"Conteúdo",items:[["rail:items","Itens","items"]]},
    {title:"Gestão",items:[["rail:crm","CRM","crm"],["rail:crm-funnel","Funil CRM","crm-funnel"],["rail:orders","Encomendas","orders"],["rail:delivery","Entregas","delivery"]]},
    {title:"Automação",items:[["rail:activity","Envios","activity"],["rail:broadcast","Disparo em massa","broadcast"],["rail:flow","Fluxos","flow"],["rail:funnel","Funis","funnel"]]},
    {title:"Produtividade",items:[["rail:quick-response","Respostas Rápidas","quick-response"],["rail:labels","Gerenciar Etiquetas","labels-manager"],["rail:followup","FollowUp","followup"],["rail:auto-service","Autoatendimento","auto-service"],["rail:status","Status","status"],["rail:export","Exportar Contatos","export"],["rail:agenda","Agenda","agenda"],["rail:notes","Notas","notes"],["rail:reminder","Lembrete","reminder"],["rail:google-calendar","Google Calendar","google-calendar"],["rail:signature","Assinatura","signature"],["rail:text-assistant","Assistente de texto","text-assistant"],["rail:text-replace","Substituição de texto","text-replace"],["rail:google","Google","google"]]},
    {title:"Sistema",items:[["rail:webhooks","Webhooks","webhooks"]]}
  ];
  D.CHAT_ACTIONS=[
    {id:"arquivar_contato",title:"Arquivar Contato",actionType:"arquivar"},
    {id:"desarquivar_contato",title:"Desarquivar Contato",actionType:"desarquivar"},
    {id:"marcar_lida",title:"Marcar Como Lida",actionType:"marcarLido"},
    {id:"marcar_nao_lida",title:"Marcar Como Não Lida",actionType:"marcarNaoLido"},
    {id:"bloquear_contato",title:"Bloquear Contato",actionType:"bloquear"},
    {id:"desbloquear_contato",title:"Desbloquear Contato",actionType:"desbloquear"},
    {id:"insert_name",title:"Inserir Nome",capability:"insert_name"}
  ];
  D.CHAT_TOOL_META={
    encomendas:{accent:"#f97316",desc:"Encomendas e rastreios deste contato",icon:PANEL_BRAND.orders.icon},
    notes:{accent:"#eab308",desc:"Registre informações importantes da conversa",icon:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h6"/>'},
    lembrete:{accent:"#38bdf8",desc:"Programe um lembrete ligado ao contato",icon:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 1.5"/><path d="M9 2h6"/>'},
    agendamento:{accent:PANEL_BRAND.agenda.accent,desc:"Agende o envio de um item",icon:PANEL_BRAND.agenda.icon},
    google_calendario:{accent:"#4285f4",desc:"Crie um evento no Google Calendar",icon:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 9h18"/><path d="m9 15 2 2 4-4"/>'},
    arquivar_contato:{accent:"#38bdf8",desc:"Arquive a conversa atual sem excluir o contato",icon:'<path d="M4 7h16v13H4z"/><path d="M3 4h18v3H3z"/><path d="M9 11h6"/>'},
    desarquivar_contato:{accent:"#38bdf8",desc:"Retire a conversa atual do arquivo",icon:'<path d="M4 7h16v13H4z"/><path d="M3 4h18v3H3z"/><path d="m9 14 3-3 3 3"/><path d="M12 11v6"/>'},
    marcar_lida:{accent:"#22c55e",desc:"Marque a conversa atual como lida",icon:'<path d="m3 12 4 4L17 6"/><path d="m11 14 2 2 8-8"/>'},
    marcar_nao_lida:{accent:"#f59e0b",desc:"Marque a conversa atual como não lida",icon:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/><circle cx="18" cy="6" r="3"/>'},
    bloquear_contato:{accent:"#ef4444",desc:"Bloqueie o contato da conversa atual",icon:'<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>'},
    desbloquear_contato:{accent:"#22c55e",desc:"Desbloqueie o contato da conversa atual",icon:'<path d="M7 11V8a5 5 0 0 1 9.5-2"/><rect x="5" y="11" width="14" height="10" rx="2"/><path d="m10 16 1.5 1.5L15 14"/>'},
    traducao_com_IA:{accent:"#8b5cf6",desc:"Traduza texto com IA e insira na conversa",icon:'<path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/>'},
    signature:{accent:"#14b8a6",desc:"Insira uma assinatura cadastrada",icon:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/>'},
    chat_assistant:{accent:"#6366f1",desc:"Corrija e melhore um texto antes de enviar",icon:'<path d="m12 3-1.7 4.3L6 9l4.3 1.7L12 15l1.7-4.3L18 9l-4.3-1.7z"/><path d="m19 15-.8 2.2L16 18l2.2.8L19 21l.8-2.2L22 18l-2.2-.8z"/>'},
    insert_name:{accent:"#22c55e",desc:"Insira o nome do contato no composer",icon:'<circle cx="9" cy="7" r="4"/><path d="M3 21c0-4 3-6 6-6"/><path d="M16 11v6M13 14h6"/>'},
    replace_text:{accent:"#f59e0b",desc:"Crie atalhos que expandem para textos completos",icon:'<path d="M20 7h-9"/><path d="m16 3 4 4-4 4"/><path d="M4 17h9"/><path d="m8 13-4 4 4 4"/>'},
    init_fluxo:{accent:PANEL_BRAND.fluxos.accent,desc:"Inicie manualmente um fluxo no chat atual",icon:PANEL_BRAND.fluxos.icon},
    status:{accent:PANEL_BRAND.status.accent,desc:"Publique ou agende um Status do WhatsApp",icon:PANEL_BRAND.status.icon},
    autoatendimento:{accent:PANEL_BRAND.autoService.accent,desc:"Gerencie respostas automáticas por gatilho",icon:PANEL_BRAND.autoService.icon},
    webhooks:{accent:PANEL_BRAND.webhooks.accent,desc:"Envie eventos da extensão para seus sistemas",icon:PANEL_BRAND.webhooks.icon},
  };
  D.WEBHOOK_EVENT_DEFS=[
    { id: "messages", title: "Mensagem recebida", desc: "Toda mensagem recebida (não enviada por você).", accent: "#a855f7", icon: '<path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"/>' },
    { id: "labels", title: "Etiqueta alterada", desc: "Etiqueta adicionada, removida ou renomeada num chat.", accent: "#d946ef", icon: NAV_ICONS.etiquetas },
    { id: "newChat", title: "Nova conversa", desc: "Primeira mensagem de um contato novo.", accent: "#38bdf8", icon: '<path d="M2 21a8 8 0 0 1 13.292-6"/><circle cx="10" cy="8" r="5"/><path d="M19 16v6"/><path d="M22 19h-6"/>' },
    { id: "agendamento", title: "Agendamento enviado", desc: "Um item da Agenda foi efetivamente enviado.", accent: "#22d3ee", icon: PANEL_BRAND.agenda.icon },
    { id: "fluxo", title: "Fluxo disparado", desc: "Qualquer Fluxo foi acionado.", accent: "#fb923c", icon: PANEL_BRAND.fluxos.icon },
    { id: "metaAds", title: "Meta Ads", desc: "Mensagem originada por anúncio/contexto Meta.", accent: "#60a5fa", icon: NAV_ICONS.webhook || PANEL_BRAND.webhooks.icon },
    { id: "respostaRapida", title: "Resposta rápida enviada", desc: "Uma resposta rápida foi enviada.", accent: "#34d399", icon: PANEL_BRAND.quickreply && PANEL_BRAND.quickreply.icon || NAV_ICONS.itens },
    { id: "crm", title: "Movimento no CRM", desc: "Contato movimentado entre etapas do CRM.", accent: "#f59e0b", icon: PANEL_BRAND.crm.icon },
    { id: "autoAtendimento", title: "Autoatendimento", desc: "Uma regra de autoatendimento foi acionada.", accent: "#2dd4bf", icon: PANEL_BRAND.autoatendimento && PANEL_BRAND.autoatendimento.icon || NAV_ICONS.ferramentas },
    { id: "followup", title: "FollowUp executado", desc: "Uma regra de FollowUp foi enviada ou terminou com erro.", accent: "#818cf8", icon: PANEL_BRAND.followup && PANEL_BRAND.followup.icon || NAV_ICONS.ferramentas },
    { id: "orders", title: "Encomenda alterada", desc: "Uma encomenda foi criada, atualizada ou teve rastreio enviado.", accent: "#f59e0b", icon: PANEL_BRAND.orders && PANEL_BRAND.orders.icon || NAV_ICONS.ferramentas },
    { id: "scheduleFailed", title: "Falha de agendamento", desc: "Um item da Agenda atingiu erro definitivo de envio.", accent: "#fb7185", icon: PANEL_BRAND.agenda.icon },
    { id: "funnelCompleted", title: "Funil finalizado", desc: "Uma execução de Funil terminou normalmente.", accent: "#34d399", icon: PANEL_BRAND.funis.icon }
  ];
})(window);
