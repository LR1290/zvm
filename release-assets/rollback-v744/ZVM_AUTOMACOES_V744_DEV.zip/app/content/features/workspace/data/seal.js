;(function(root){
  "use strict";
  if(!root.__extWorkspaceStaticData) throw new Error("Dados estáticos ausentes.");
  Object.freeze(root.__extWorkspaceStaticData);
})(window);
