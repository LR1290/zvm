;(function(root){
  "use strict";
  var D=root.__extWorkspaceStaticData||(root.__extWorkspaceStaticData={});
  D.PANEL_BRAND={
    ajustes: { accent: "#94a3b8", icon: '<path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"/><circle cx="12" cy="12" r="3"/>' },
    agenda: { accent: "#22d3ee", icon: '<path d="M8 2v3"/><path d="M16 2v3"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>' },
    followup: { accent: "#6366f1", icon: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>' },
    fluxos: { accent: "#fb923c", icon: '<rect width="8" height="8" x="3" y="3" rx="2"/><path d="M7 11v4a2 2 0 0 0 2 2h4"/><rect width="8" height="8" x="13" y="13" rx="2"/>' },
    funis: { accent: "#f43f5e", icon: '<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>' },
    crm: { accent: "#eab308", icon: '<path d="M5 3v14"/><path d="M12 3v8"/><path d="M19 3v18"/>' },
    crmFunnel: { accent: "#06b6d4", icon: '<path d="M3 4h18l-7 8v6l-4 2v-8z"/><path d="M7 8h10"/>' },
    orders: { accent: "#f97316", icon: '<path d="m16.5 9.4-9-5.19"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" x2="12" y1="22" y2="12"/>' },
    delivery: { accent: "#14b8a6", icon: '<path d="M3 7h11v8H3z"/><path d="M14 10h3l4 4v1h-7z"/><circle cx="7.5" cy="18" r="1.5"/><circle cx="17.5" cy="18" r="1.5"/>' },
    tools: { accent: "#8b5cf6", icon: '<path d="M14.7 6.3a1 1 0 0 0 0-1.4l-1.6-1.6a1 1 0 0 0-1.4 0l-1.2 1.2 3 3z"/><path d="m13.5 7.5-9.2 9.2a2.1 2.1 0 0 0 3 3l9.2-9.2"/><path d="M16 5 19 2"/><path d="m15 14 4 4"/><path d="m17 12 4 4"/>' },
    google: { accent: "#34a853", icon: '<text x="12" y="16.2" text-anchor="middle" font-size="15.5" font-family="Arial,Helvetica,sans-serif" font-weight="800" fill="currentColor" stroke="none">G</text>' },
    status: { accent: "#22c55e", icon: '<circle cx="12" cy="12" r="9"/><path d="M8 12h8"/><path d="M12 8v8"/>' },
    autoService: { accent: "#0ea5e9", icon: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>' },
    webhooks: { accent: "#0ea5e9", icon: '<path d="M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2"/><path d="m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06"/><path d="m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8"/>' }
  };
  D.NAV_ICONS={
    disparos: '<path d="M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"/><path d="M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14"/><path d="M8 6v8"/>',
    itens: '<rect x="4" y="4" width="6" height="6" rx="1.35"/><rect x="14" y="4" width="6" height="6" rx="1.35"/><rect x="4" y="14" width="6" height="6" rx="1.35"/><rect x="14" y="14" width="6" height="6" rx="1.35"/>',


    respostaRapida: '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
    salvar: '<path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/>',
    etiquetas: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" data-fill="1"/>',
    close: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',


    envios: '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
    sistema: '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
    notificacoes: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
    integracoes: '<path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a6 6 0 0 1-12 0V8Z"/><path d="M4 8h16"/>',
    personalizacao: '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
    backup: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',
    configurarMenu: '<path d="M4 6h16"/><path d="M4 12h10"/><path d="M4 18h7"/><circle cx="18" cy="12" r="2"/><circle cx="15" cy="18" r="2"/>',
    tutorial: '<path d="m10 8 6 4-6 4Z"/><rect x="2" y="5" width="20" height="14" rx="4"/>'
  };
  D.MENU_CONFIG_ITEMS=[
    ["itens","Itens"],["crm","CRM"],["crm-funnel","Funil CRM"],["encomendas","Encomendas"],["delivery","Entregas"],
    ["envios","Envios"],["disparos","Disparo em massa"],["fluxos","Fluxos"],["funis","Funis"],
    ["resposta-rapida","Respostas Rápidas"],["followup","FollowUp"],["autoatendimento","Autoatendimento"],["status","Status"],["ferramentas","Ferramentas"],
    ["agenda","Agenda"],["notas","Notas"],["lembrete","Lembrete"],["google-calendar","Google Calendar"],["assinatura","Assinatura"],["assistente-texto","Assistente de texto"],["substituicao-texto","Substituição de texto"],
    ["salvar","Exportar contatos"],["google","Google"],["webhooks","Webhooks"]
  ];
  D.QUICK_MENU_CONFIG_ITEMS=[
    ["client.open","Cliente"],["crm.open","CRM"],["orders.open","Encomendas"],["note.open","Notas"],
    ["agenda.open","Agenda"],["labels.open","Etiquetas"],["quick-response.open","Respostas Rápidas"],["quick-items.open","Itens Rápidos"]
  ];
  D.AGENDA_ITEM_STORES={
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList", label: "Mensagem" },
    audio: { key: "EXTUI:audioStore", listField: "audioList", label: "Áudio" },
    image: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Vídeo", virtualMediaKind: "video" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem/Vídeo (legado)", legacyOnly: true },
    document: { key: "EXTUI:documentStore", listField: "documentList", label: "Documento" },
    funnel: { key: "EXTUI:extappFunnelStore", listField: "funnelList", label: "Funil" }
  };
})(window);
