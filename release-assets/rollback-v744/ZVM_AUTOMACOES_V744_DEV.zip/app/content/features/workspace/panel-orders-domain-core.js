;(function(){
  "use strict";
  if(window.__extCreateOrdersPanelDomainCore)return;
  window.__extCreateOrdersPanelDomainCore=function(deps){
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,PANEL_BRAND=deps.panelBrand||{},panelBody=deps.panelBody,extField=deps.field,extEmptyState=deps.emptyState,extGetActiveContactContext=deps.getActiveContactContext,extPanelFormSection=deps.formSection,extConfirm=deps.confirm,extPanelOnKeyChange=deps.panelOnKeyChange,toast=deps.toast,openShellHtml=deps.openShellHtml,iconChip=deps.iconChip,escHtml=deps.escHtml;
    if([buildPanelShell,panelBody,extField,extEmptyState,extGetActiveContactContext,extPanelFormSection,extConfirm,extPanelOnKeyChange,toast,openShellHtml,iconChip,escHtml].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do domínio Encomendas inválidas.");

    async function buildOrdersPanel() {
      var root=buildPanelShell({id:"extuiNavOrdersPanel",title:"Encomendas",accent:PANEL_BRAND.orders.accent,icon:PANEL_BRAND.orders.icon,eyebrow:"Contato atual",hint:"Acompanhe encomendas e rastreios do contato atual.",size:"lg",tutorialKey:"encomendas",footer:true});
      var body=panelBody(root), content=document.createElement("div");content.className="extuiOrdersDock";body.appendChild(content);
      var footer=root.querySelector("[data-extui-panel-footer]");if(footer){footer.hidden=false;footer.classList.add("extuiOrdersFooter");}
      var footerActions=document.createElement("div");footerActions.className="extuiOrdersFooterActions";
      var shellBtn=document.createElement("button");shellBtn.type="button";shellBtn.className="extuiNavSecondaryBtn extuiOrdersOpenDashboard";shellBtn.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 8h8M8 12h8M8 16h5"/></svg><span>Abrir Encomendas no Painel de Controle</span>';
      shellBtn.addEventListener("click",function(){openShellHtml("encomendas",{reuseExisting:true});});
      footerActions.appendChild(shellBtn);if(footer)footer.appendChild(footerActions);else body.appendChild(footerActions);
      async function reload(){
        if(!root.classList.contains("extuiOpen")&&content.dataset.loaded==="1")return;
        content.dataset.loaded="1";content.innerHTML="";
        var ctx=await extGetActiveContactContext();
        if(!ctx||ctx.group||!ctx.phone){content.appendChild(extEmptyState(PANEL_BRAND.orders.accent,PANEL_BRAND.orders.icon,"Abra uma conversa individual","As encomendas são vinculadas ao contato da conversa atual.",null,null,{sober:true}));return;}
        var identity=document.createElement("div");identity.className="extuiOrdersContactCard";identity.innerHTML=iconChip(PANEL_BRAND.orders.accent,PANEL_BRAND.orders.icon,true)+'<div><span>Contato atual</span><strong>'+escHtml(ctx.name)+'</strong><small>+'+escHtml(ctx.phone)+'</small></div>';content.appendChild(identity);
        var orders=window.__extOrdersService?await window.__extOrdersService.list(ctx.phone):[];
        var form=document.createElement("form");form.className="extuiOrdersQuickForm extuiPanelFormSurface";
        form.appendChild(extPanelFormSection("Nova encomenda","Cadastre os dados essenciais. Escolha uma transportadora pronta ou use OUTRO para digitar manualmente."));
        var carrierPresets=["Correios","Jadlog","Loggi","Mercado Envios","Kangu"];
        var name=document.createElement("input");name.placeholder="Ex.: Encomenda #1042";
        var carrier=document.createElement("input");carrier.placeholder="Selecione uma transportadora ou use OUTRO";
        var tracking=document.createElement("input");tracking.placeholder="Ex.: BR123456789";
        var save=document.createElement("button");save.type="submit";save.className="extuiNavPrimaryBtn extuiPanelSubmitBtn";save.textContent="Adicionar encomenda";
        var nameField=extField("Nome da encomenda",name);nameField.classList.add("extuiOrdersField","extuiOrdersField--wide");
        var carrierField=extField("Transportadora",carrier);carrierField.classList.add("extuiOrdersField","extuiOrdersField--carrier");
        var trackingField=extField("Código de rastreio",tracking);trackingField.classList.add("extuiOrdersField","extuiOrdersField--tracking");
        var presetBar=document.createElement("div");presetBar.className="extuiOrdersCarrierPresets";
        carrierPresets.forEach(function(label){var btn=document.createElement("button");btn.type="button";btn.className="extuiOrdersCarrierPreset";btn.textContent=label;btn.addEventListener("click",function(){carrier.value=label;carrier.dispatchEvent(new Event("input",{bubbles:true}));carrier.focus();});presetBar.appendChild(btn);});
        var other=document.createElement("button");other.type="button";other.className="extuiOrdersCarrierPreset extuiOrdersCarrierPreset--other";other.textContent="Outro";other.addEventListener("click",function(){carrier.value="";carrier.focus();});presetBar.appendChild(other);carrierField.appendChild(presetBar);
        form.appendChild(nameField);form.appendChild(carrierField);form.appendChild(trackingField);form.appendChild(save);content.appendChild(form);
        form.addEventListener("submit",async function(ev){ev.preventDefault();if(!name.value.trim())return;save.disabled=true;try{var central=window.ExtensionCustomerStore?await window.ExtensionCustomerStore.findByPhone(ctx.phone):null;await window.__extOrdersService.create({contactId:ctx.phone,customerName:central&&central.name||ctx.name||"",name:name.value.trim(),carrier:carrier.value.trim(),trackingCode:tracking.value.trim(),status:"open"});toast("Encomenda criada.");}catch(e){toast(e.message||"Falha ao criar encomenda.",true);}finally{save.disabled=false;}});
        var listHead=document.createElement("div");listHead.className="extuiOrdersListHead";listHead.innerHTML='<div><span>Encomendas deste contato</span><strong>'+orders.length+'</strong></div>';content.appendChild(listHead);
        var list=document.createElement("div");list.className="extuiOrdersDockList";content.appendChild(list);
        if(!orders.length){list.appendChild(extEmptyState(PANEL_BRAND.orders.accent,PANEL_BRAND.orders.icon,"Nenhuma encomenda","Cadastre a primeira encomenda deste contato acima.",null,null,{sober:true}));return;}
        orders.sort(function(a,b){return Number(b.updatedAt||0)-Number(a.updatedAt||0);}).forEach(function(o){
          var row=document.createElement("div");row.className="extuiDockedPanelRow extuiOrdersDockRow";
          var text=document.createElement("div");text.className="extuiDockedPanelRowText";
          var statusLabel=window.__extOrdersService&&typeof window.__extOrdersService.statusLabel==="function"?window.__extOrdersService.statusLabel(o):({open:"Nova",processing:"Em preparo",shipped:"Em entrega",delivered:"Entregue",cancelled:"Cancelada"}[o.status]||"Nova");
          text.innerHTML='<div class="extuiDockedPanelRowTitle">'+escHtml(o.name||"Encomenda")+'</div><div class="extuiDockedPanelRowMeta">'+escHtml(o.carrier||"Transportadora não informada")+(o.trackingCode?' · '+escHtml(o.trackingCode):' · Sem código de rastreio')+'</div><span class="extuiOrderStatusBadge">'+escHtml(statusLabel)+'</span>';
          row.appendChild(text);
          var actions=document.createElement("div");actions.className="extuiOrdersDockActions";
          if(o.trackingCode){var send=document.createElement("button");send.type="button";send.className="extuiNavSecondaryBtn";send.textContent="Enviar rastreio";send.addEventListener("click",async function(){try{await window.__extOrdersService.sendTracking(o.id,ctx.phone);toast("Rastreio enviado.");}catch(e){toast(e.message,true);}});actions.appendChild(send);}
          var del=document.createElement("button");del.type="button";del.className="extuiNavDangerBtn";del.textContent="Excluir";del.addEventListener("click",async function(){if(!(await window.extConfirm("Excluir esta encomenda?",{danger:true})))return;del.disabled=true;try{await window.__extOrdersService.remove(o.id,ctx.phone);toast("Encomenda excluída.");}catch(err){toast(err&&err.message||"Falha ao excluir a encomenda.",true);}finally{del.disabled=false;}});actions.appendChild(del);
          row.appendChild(actions);list.appendChild(row);
        });
      }
      function safeReload(){return Promise.resolve(reload()).catch(function(err){content.innerHTML="";content.appendChild(extEmptyState(PANEL_BRAND.orders.accent,PANEL_BRAND.orders.icon,"Encomendas indisponíveis",err&&err.message||"Não foi possível carregar as encomendas agora.",null,null,{sober:true}));if(window.__extReportRuntimeError)window.__extReportRuntimeError("ORDERS_PANEL_RELOAD_FAILED",err);});}safeReload();extPanelOnKeyChange(root,"EXTUI:ordersStore",function(){safeReload();});return root;
    }
    return Object.freeze({buildOrdersPanel:buildOrdersPanel});
  };
})();
