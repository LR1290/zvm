;(function(){
  "use strict";
  if(window.__extCreateFlowsPanelDomainCore)return;
  window.__extCreateFlowsPanelDomainCore=function(deps){
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,PANEL_BRAND=deps.panelBrand||{},extGet=deps.get,extSet=deps.set,parsePersisted=deps.parsePersisted,extPanelOnKeyChange=deps.panelOnKeyChange,extWorkspace=deps.workspace,extGetActiveContactContext=deps.getActiveContactContext,toast=deps.toast,extAutomationExecutionMessage=deps.executionMessage,extEmptyState=deps.emptyState,extAutomationResourceTitle=deps.resourceTitle,extAutomationResourceStepCount=deps.stepCount,extAutomationResourceTrigger=deps.triggerLabel,extBuildSwitch=deps.buildSwitch,openShellHtml=deps.openShellHtml,panelState=deps.panelState,iconChip=deps.iconChip,escHtml=deps.escHtml;
    if([buildPanelShell,extGet,extSet,parsePersisted,extPanelOnKeyChange,extGetActiveContactContext,toast,extAutomationExecutionMessage,extEmptyState,extAutomationResourceTitle,extAutomationResourceStepCount,extAutomationResourceTrigger,extBuildSwitch,openShellHtml,iconChip,escHtml].some(function(fn){return typeof fn!=="function";})||!extWorkspace||!panelState)throw new TypeError("Dependências do domínio Fluxos inválidas.");
    var FLOW_KEY=deps.flowKey||"EXTUI:extappFlowStore";

    async function buildFluxosPanel() {
      var root = buildPanelShell({
        id: "extuiNavFluxosPanel", title: "Fluxos", accent: PANEL_BRAND.fluxos.accent, icon: PANEL_BRAND.fluxos.icon, eyebrow: "Automação",
        hint: "Ative, execute ou edite seus fluxos sem perder a conversa atual.",
        size: "md", footer: true
      });
      var body = root.querySelector(".extuiNavPanelBody");
      var footer = root.querySelector("[data-extui-panel-footer]");
      var summary = document.createElement("div");
      summary.className = "extuiAutomationResourceSummary";
      body.appendChild(summary);
      var listEl = document.createElement("div");
      listEl.className = "extuiDockedPanelList extuiAutomationResourceList";
      body.appendChild(listEl);
      var reloadSeq = 0;
      if (footer) {
        footer.hidden = false;
        var manage = document.createElement("button");
        manage.type = "button"; manage.className = "extuiNavSecondaryBtn extuiAutomationManageBtn";
        manage.textContent = "Abrir editor de Fluxos";
        manage.addEventListener("click", function () { openShellHtml("fluxos", { reuseExisting: true }); });
        footer.appendChild(manage);
      }

      async function executeFlow(flow, button) {
        var ctx = await extGetActiveContactContext();
        if (!ctx || !ctx.chatId) { toast("Abra uma conversa antes de executar o Fluxo.", true); return; }
        var allowed = await window.extConfirm('Executar o fluxo "' + String(flow.name || "Fluxo") + '" na conversa atual? Ele pode enviar mensagens reais imediatamente.', { okLabel: "Executar agora", cancelLabel: "Cancelar" });
        if (!allowed) return;
        button.disabled = true;
        try {
          await window.__extFluxosStartFlowManually(flow.id, ctx.chatId, { isTest: false });
          toast("Fluxo iniciado na conversa atual.");
          reload();
        } catch (error) { toast(extAutomationExecutionMessage(error, "flow"), true); }
        finally { button.disabled = false; }
      }

      async function reload() {
        var seq = ++reloadSeq;
        listEl.innerHTML = '<div class="extuiSideItensEmpty">Carregando...</div>';
        var raw, flows;
        try { raw = await extGet(FLOW_KEY); if (seq !== reloadSeq) return; var state = parsePersisted(raw); flows = (state && state.flowList) || []; }
        catch (err) { if (seq !== reloadSeq) return; listEl.innerHTML = '<div class="extuiSideItensEmpty">Erro ao carregar</div>'; summary.textContent = ""; return; }
        var activeCount = flows.filter(function (flow) { return flow && flow.isActive === true; }).length;
        var flowRunningCounts = Object.create(null);
        if (typeof window.__extFluxosCountRunningByFlowId === "function") {
          await Promise.all(flows.map(async function (flow) {
            try { flowRunningCounts[flow.id] = Number(await window.__extFluxosCountRunningByFlowId(flow.id)) || 0; }
            catch (_) { flowRunningCounts[flow.id] = 0; }
          }));
        }
        if (seq !== reloadSeq) return;
        var runningCount = flows.reduce(function (total, flow) { return total + (flowRunningCounts[flow.id] || 0); }, 0);
        summary.innerHTML = '<span><strong>' + flows.length + '</strong> cadastrado(s)</span><span><strong>' + activeCount + '</strong> ativo(s)</span><span><strong>' + runningCount + '</strong> em execução</span>';
        if (flows.length === 0) { listEl.innerHTML = ""; listEl.appendChild(extEmptyState(PANEL_BRAND.fluxos.accent, PANEL_BRAND.fluxos.icon, "Nenhum fluxo cadastrado", "Crie um Fluxo no Painel de Controle e ele aparecerá aqui pronto para uso.", "Criar primeiro Fluxo", function(){ openShellHtml("fluxos", { reuseExisting: true }); }, { sober: true })); return; }
        listEl.innerHTML = "";
        flows.forEach(function (f) {
          var row = document.createElement("div"); row.className = "extuiDockedPanelRow extuiResourceCard extuiResourceCard--flow";
          var running = flowRunningCounts[f.id] || 0;
          var flowTitle = extAutomationResourceTitle(f, f.id || "Fluxo");
          var flowSteps = extAutomationResourceStepCount(f, "flow");
          row.title = flowTitle;
          row.innerHTML = iconChip(PANEL_BRAND.fluxos.accent,PANEL_BRAND.fluxos.icon,true) +
            '<div class="extuiResourceCardCopy"><div class="extuiDockedPanelRowTitle" title="'+escHtml(flowTitle)+'">' + escHtml(flowTitle) + '</div>' +
            '<div class="extuiDockedPanelRowMeta"><span class="extuiResourceBadge">' + flowSteps + ' etapa(s)</span><span class="extuiResourceMetaText">'+escHtml(extAutomationResourceTrigger(f))+'</span><span class="extuiAutomationStateBadge ' + (f.isActive ? 'is-active' : 'is-paused') + '">' + (f.isActive ? 'Ativo' : 'Pausado') + '</span>' + (running ? '<span class="extuiAutomationStateBadge is-running">' + running + ' executando</span>' : '') + '</div></div>';
          var actions = document.createElement("div"); actions.className = "extuiPanelRowActions extuiAutomationResourceActions";
          var run = document.createElement("button"); run.type = "button"; run.className = "extuiNavPrimaryBtn"; run.textContent = "Executar"; run.title = "Executar na conversa atual"; run.addEventListener("click", function () { executeFlow(f, run); });
          var edit = document.createElement("button"); edit.type = "button"; edit.className = "extuiNavSecondaryBtn"; edit.textContent = "Editar"; edit.addEventListener("click", function () { openShellHtml("fluxos", { flowId: f.id, reuseExisting: true }); });
          var stateBadge = row.querySelector(".extuiAutomationStateBadge:not(.is-running)");
          var sw = extBuildSwitch(f.isActive, async function (next, previous) {
            try {
              var latestRaw = await extGet(FLOW_KEY);
              var latestState = parsePersisted(latestRaw) || {};
              var latestFlows = Array.isArray(latestState.flowList) ? latestState.flowList : [];
              var targetFlow = latestFlows.find(function (item) { return item && item.id === f.id; });
              if (!targetFlow) { toast("Este Fluxo não existe mais. Atualizando a lista...", true); reload(); return false; }
              targetFlow.isActive = next;
              targetFlow.updatedAtInMs = Date.now();
              await extSet(FLOW_KEY, JSON.stringify({ state: { flowList: latestFlows }, version: 0 }));
              f.isActive = next;
              if (previous !== next) activeCount += next ? 1 : -1;
              if (stateBadge) {
                stateBadge.classList.toggle("is-active", next);
                stateBadge.classList.toggle("is-paused", !next);
                stateBadge.textContent = next ? "Ativo" : "Pausado";
              }
              if (sw) sw.setAttribute("aria-label", (next ? "Desativar " : "Ativar ") + "fluxo " + flowTitle);
              summary.innerHTML = '<span><strong>' + flows.length + '</strong> cadastrado(s)</span><span><strong>' + activeCount + '</strong> ativo(s)</span><span><strong>' + runningCount + '</strong> em execução</span>';
              toast(next ? "Fluxo ativado!" : "Fluxo pausado!");
              return true;
            } catch (err) { toast("Não foi possível salvar o estado do Fluxo.", true); return false; }
          });
          sw.setAttribute("aria-label",(f.isActive?"Desativar ":"Ativar ")+"fluxo "+flowTitle);
          actions.appendChild(run); actions.appendChild(edit); actions.appendChild(sw); row.appendChild(actions); listEl.appendChild(row);
        });
      }
      panelState.setRefresh(root, reload);
      reload();
      extPanelOnKeyChange(root, FLOW_KEY, function () { if (root.isConnected) { if (extWorkspace.isOpen(root)) reload(); else panelState.markDirty(root, true); } });
      extPanelOnKeyChange(root, "EXTUI:extappFlowRunningStore", function () { if (root.isConnected) { if (extWorkspace.isOpen(root)) reload(); else panelState.markDirty(root, true); } });
      return root;
    }
    return Object.freeze({buildFluxosPanel:buildFluxosPanel,flowKey:FLOW_KEY});
  };
})();
