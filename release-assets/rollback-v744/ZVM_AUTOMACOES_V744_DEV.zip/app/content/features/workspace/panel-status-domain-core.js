;(function () {
  "use strict";
  if (window.__extCreateStatusPanelDomainCore) return;
  window.__extCreateStatusPanelDomainCore = function (deps) {
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,panelBrand=deps.panelBrand||{},panelBody=deps.panelBody,choiceDeck=deps.choiceDeck,field=deps.field,formSection=deps.formSection,emptyState=deps.emptyState,panelOnKeyChange=deps.panelOnKeyChange,fmtDateTime=deps.fmtDateTime,escHtml=deps.escHtml,toast=deps.toast;
    if([buildPanelShell,panelBody,choiceDeck,field,formSection,emptyState,panelOnKeyChange,fmtDateTime,escHtml,toast].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do domínio Status inválidas.");
    function parseLocalDateTimeStrict(value){
      var m=String(value||"").match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if(!m)return NaN;
      var y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]),h=Number(m[4]),mi=Number(m[5]),sec=Number(m[6]||0);
      var dt=new Date(y,mo-1,d,h,mi,sec,0);
      if(dt.getFullYear()!==y||dt.getMonth()!==mo-1||dt.getDate()!==d||dt.getHours()!==h||dt.getMinutes()!==mi||dt.getSeconds()!==sec)return NaN;
      return dt.getTime();
    }
    
    async function buildStatusPanel(){
      var root=buildPanelShell({id:"extuiNavStatusPanel",title:"Status",accent:panelBrand.status.accent,icon:panelBrand.status.icon,eyebrow:"WhatsApp",hint:"Publique ou agende um Status.",size:"md",tutorialKey:"status"});
      root.classList.add("extuiNavPanel--designer");
      var body=panelBody(root),form=document.createElement("form");
      form.className="extuiCrmQuickComposer extuiStatusQuickForm extuiPanelFormSurface";
    
      var type=document.createElement("select");
      [["text","Texto"],["image","Foto"],["video","Vídeo"]].forEach(function(x){type.appendChild(new Option(x[1],x[0]));});
      var typeDeck=choiceDeck(type,[
        {value:"text",title:"Texto",desc:"",icon:'<path d="M5 6h14M12 6v12M8.5 18h7"/>'},
        {value:"image",title:"Foto",desc:"",icon:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>'},
        {value:"video",title:"Vídeo",desc:"",icon:'<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-2v8l-4-2z"/>'}
      ],3);
      typeDeck.setAttribute("aria-label","Formato do Status");
      var text=document.createElement("textarea");text.placeholder="Escreva o texto do seu status";
      var file=document.createElement("input");file.type="file";
      var color=document.createElement("input");color.type="color";color.value="#00a884";
      var when=document.createElement("input");when.type="datetime-local";
    
      var privacy=document.createElement("select");
      [["contacts","Meus contatos"],["except","Meus contatos, exceto..."],["only","Apenas compartilhar com..."]].forEach(function(x){privacy.appendChild(new Option(x[1],x[0]));});
      var privacyBox=document.createElement("div");privacyBox.className="extuiStatusPrivacyBox";privacyBox.hidden=true;
      var privacyHead=document.createElement("div");privacyHead.className="extuiStatusPrivacyHead";
      var privacyTitle=document.createElement("div");privacyTitle.className="extuiStatusPrivacyTitle";
      var privacyCount=document.createElement("span");privacyCount.className="extuiStatusPrivacyCount";
      privacyHead.appendChild(privacyTitle);privacyHead.appendChild(privacyCount);
      var privacySearch=document.createElement("input");privacySearch.type="search";privacySearch.placeholder="Buscar contato por nome ou número";privacySearch.className="extuiStatusPrivacySearch";privacySearch.setAttribute("aria-label","Buscar contato para privacidade do Status");
      var privacyActions=document.createElement("div");privacyActions.className="extuiStatusPrivacyActions";
      var selectAll=document.createElement("button");selectAll.type="button";selectAll.className="extuiNavSecondaryBtn";selectAll.textContent="Marcar todos";
      var clearAll=document.createElement("button");clearAll.type="button";clearAll.className="extuiNavSecondaryBtn";clearAll.textContent="Limpar";
      privacyActions.appendChild(selectAll);privacyActions.appendChild(clearAll);
      var privacyList=document.createElement("div");privacyList.className="extuiStatusPrivacyList";
      privacyBox.appendChild(privacyHead);privacyBox.appendChild(privacySearch);privacyBox.appendChild(privacyActions);privacyBox.appendChild(privacyList);
    
      var submit=document.createElement("button");submit.type="submit";submit.className="extuiNavPrimaryBtn extuiPanelSubmitBtn";submit.textContent="Publicar agora";
      var typeField=field("Formato",type),textField=field("Texto",text),colorField=field("Cor de fundo",color),fileField=field("Arquivo",file,"Imagens e vídeos são enviados diretamente ao Status do WhatsApp."),privacyField=field("Quem pode ver",privacy,"A privacidade é aplicada antes de cada publicação, inclusive em status agendados."),whenField=field("Agendar",when,"Opcional. Deixe vazio para publicar imediatamente.");
      typeField.classList.add("extuiFieldGroup--choice","extuiStatusField","extuiStatusField--type");
      textField.classList.add("extuiStatusField","extuiStatusField--text");
      colorField.classList.add("extuiFieldGroup--compact","extuiStatusField","extuiStatusField--color");
      fileField.classList.add("extuiStatusField","extuiStatusField--file");
      privacyField.classList.add("extuiStatusField","extuiStatusField--privacy");
      whenField.classList.add("extuiStatusField","extuiStatusField--when");
      privacyBox.classList.add("extuiStatusField","extuiStatusField--privacyBox");
      submit.classList.add("extuiStatusField","extuiStatusField--submit");
      typeField.appendChild(typeDeck);
      var contentBlock=document.createElement("section");contentBlock.className="extuiStatusBlock extuiStatusBlock--content";
      contentBlock.appendChild(formSection("1. Conteúdo","Escolha o formato e prepare o que será publicado."));
      contentBlock.appendChild(typeField);
      var contentDynamic=document.createElement("div");contentDynamic.className="extuiStatusContentDynamic";contentDynamic.appendChild(textField);contentDynamic.appendChild(colorField);contentDynamic.appendChild(fileField);contentBlock.appendChild(contentDynamic);
      var privacyBlock=document.createElement("section");privacyBlock.className="extuiStatusBlock extuiStatusBlock--privacy";
      privacyBlock.appendChild(formSection("2. Privacidade","Defina a audiência antes do envio."));privacyBlock.appendChild(privacyField);privacyBlock.appendChild(privacyBox);
      var publishBlock=document.createElement("section");publishBlock.className="extuiStatusBlock extuiStatusBlock--publish";
      publishBlock.appendChild(formSection("3. Publicação","Envie agora ou programe uma data e horário."));
      var publishControls=document.createElement("div");publishControls.className="extuiStatusPublishControls";publishControls.appendChild(whenField);publishControls.appendChild(submit);publishBlock.appendChild(publishControls);
      form.appendChild(contentBlock);form.appendChild(privacyBlock);form.appendChild(publishBlock);body.appendChild(form);
      var queueBlock=document.createElement("section");queueBlock.className="extuiStatusBlock extuiStatusBlock--queue";queueBlock.appendChild(formSection("Agendados","Acompanhe os Status programados para depois."));
      var list=document.createElement("div");list.className="extuiStatusQueue";queueBlock.appendChild(list);body.appendChild(queueBlock);
    
      var privacyContacts=null,privacyLoading=false,privacySelected=Object.create(null);
      function selectedIds(){return Object.keys(privacySelected).filter(function(id){return privacySelected[id]===true;});}
      function updatePrivacyCount(){var n=selectedIds().length;privacyCount.textContent=n+(n===1?" selecionado":" selecionados");}
      function privacyContactLabel(c){return String(c&&c.name||c&&c.phoneNumber||c&&c.idStr||"Contato");}
      function renderPrivacyContacts(){
        privacyList.innerHTML="";updatePrivacyCount();
        if(privacyLoading){var loading=document.createElement("div");loading.className="extuiStatusPrivacyState";loading.textContent="Carregando contatos...";privacyList.appendChild(loading);return;}
        if(!Array.isArray(privacyContacts)){var unavailable=document.createElement("div");unavailable.className="extuiStatusPrivacyState";unavailable.textContent="Não foi possível carregar os contatos.";privacyList.appendChild(unavailable);return;}
        var term=privacySearch.value.trim().toLowerCase();
        var filtered=privacyContacts.filter(function(c){return !term||privacyContactLabel(c).toLowerCase().indexOf(term)>=0||String(c.phoneNumber||"").indexOf(term)>=0;});
        if(!filtered.length){var empty=document.createElement("div");empty.className="extuiStatusPrivacyState";empty.textContent="Nenhum contato encontrado.";privacyList.appendChild(empty);return;}
        filtered.forEach(function(c){
          if(!c||!c.idStr)return;
          var row=document.createElement("label");row.className="extuiStatusPrivacyContact";
          var cb=document.createElement("input");cb.type="checkbox";cb.checked=privacySelected[c.idStr]===true;
          var copy=document.createElement("span");copy.className="extuiStatusPrivacyContactText";
          var name=document.createElement("strong");name.textContent=privacyContactLabel(c);
          var phone=document.createElement("small");phone.textContent=String(c.phoneNumber||"");
          copy.appendChild(name);if(phone.textContent)copy.appendChild(phone);
          cb.addEventListener("change",function(){if(cb.checked)privacySelected[c.idStr]=true;else delete privacySelected[c.idStr];updatePrivacyCount();});
          row.appendChild(cb);row.appendChild(copy);privacyList.appendChild(row);
        });
      }
      async function loadPrivacyContacts(){
        if(Array.isArray(privacyContacts)||privacyLoading)return;
        privacyLoading=true;renderPrivacyContacts();
        try{
          var bridge=window.__extWppBridge;if(!bridge)throw new Error("O WhatsApp ainda não está pronto.");
          var rows=await bridge.invoke("Contact","ListPlain",{});rows=Array.isArray(rows)?rows:[];
          var seen=Object.create(null);
          privacyContacts=rows.filter(function(c){if(!c||!c.idStr||seen[c.idStr])return false;seen[c.idStr]=true;return true;}).sort(function(a,b){return privacyContactLabel(a).localeCompare(privacyContactLabel(b),"pt-BR",{sensitivity:"base"});});
        }catch(e){privacyContacts=null;toast(e&&e.message||"Falha ao carregar contatos.",true);}
        finally{privacyLoading=false;renderPrivacyContacts();}
      }
      function syncPrivacy(){
        var custom=privacy.value!=="contacts";privacyBox.hidden=!custom;
        privacyTitle.textContent=privacy.value==="except"?"Quem não poderá ver":"Quem poderá ver";
        if(custom)loadPrivacyContacts();
        updatePrivacyCount();
      }
      privacy.addEventListener("change",syncPrivacy);privacySearch.addEventListener("input",renderPrivacyContacts);
      selectAll.addEventListener("click",function(){if(!Array.isArray(privacyContacts))return;privacyContacts.forEach(function(c){if(c&&c.idStr)privacySelected[c.idStr]=true;});renderPrivacyContacts();});
      clearAll.addEventListener("click",function(){privacySelected=Object.create(null);renderPrivacyContacts();});
    
      function sync(){
        var media=type.value!=="text";
        textField.hidden=media;colorField.hidden=media;fileField.hidden=!media;
        file.accept=type.value==="image"?"image/*":type.value==="video"?"video/*":"";
        submit.textContent=when.value?"Agendar status":"Publicar agora";
      }
      type.addEventListener("change",function(){file.value="";sync();});when.addEventListener("change",sync);sync();syncPrivacy();
      function fileData(f){return new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(r.result);};r.onerror=function(){reject(new Error("Não foi possível ler o arquivo."));};r.readAsDataURL(f);});}
    
      form.addEventListener("submit",async function(ev){
        ev.preventDefault();submit.disabled=true;
        try{
          var job={type:type.value,privacyMode:privacy.value,privacyContactIds:selectedIds()};
          if(privacy.value==="only"&&!job.privacyContactIds.length)throw new Error("Selecione pelo menos um contato em 'Apenas compartilhar com...'.");
          if(type.value==="text"){
            if(!text.value.trim())throw new Error("Escreva o texto do status.");job.text=text.value.trim();job.color=color.value;
          }else{
            var f=file.files&&file.files[0];if(!f)throw new Error("Selecione uma "+(type.value==="image"?"foto":"vídeo")+".");
            if(type.value==="image"&&!/^image\//i.test(f.type||""))throw new Error("Selecione um arquivo de imagem válido.");
            if(type.value==="video"&&!/^video\//i.test(f.type||""))throw new Error("Selecione um arquivo de vídeo válido.");
            if(f.size>12*1024*1024)throw new Error("O arquivo deve ter no máximo 12 MB nesta tela.");
            job.base64=await fileData(f);job.fileName=f.name;job.mimeType=f.type;
          }
          if(when.value){job.runAt=parseLocalDateTimeStrict(when.value);if(!Number.isFinite(job.runAt))throw new Error("Data ou horário local inválido.");await window.__extStatusService.schedule(job);toast("Status agendado.");}
          else{await window.__extStatusService.send(job);toast("Status publicado.");}
          text.value="";file.value="";when.value="";sync();renderList();
        }catch(e){toast(e.message||"Falha ao publicar status.",true);}
        finally{submit.disabled=false;}
      });
    
      async function renderList(){
        list.innerHTML="";var jobs=window.__extStatusService?await window.__extStatusService.list():[];
        var pending=jobs.filter(function(j){return j.status==="pending";}).sort(function(a,b){return Number(a.runAt)-Number(b.runAt);});
        if(!pending.length){
          list.appendChild(emptyState(panelBrand.status.accent,panelBrand.status.icon,"Nenhum status agendado","Quando você programar uma publicação, ela aparecerá aqui.",null,null,{sober:true}));
          return;
        }
        var label=document.createElement("div");label.className="extuiNavSectionLabel";label.textContent="Agendados";list.appendChild(label);
        pending.forEach(function(j){var row=document.createElement("div");row.className="extuiDockedPanelRow";var privacyLabel=j.privacyMode==="only"?"Apenas selecionados":j.privacyMode==="except"?"Contatos, exceto selecionados":"Meus contatos";row.innerHTML='<div class="extuiDockedPanelRowText"><div class="extuiDockedPanelRowTitle">'+escHtml(j.type==="text"?(j.text||"Status de texto"):(j.fileName||j.type))+'</div><div class="extuiDockedPanelRowMeta">'+escHtml(fmtDateTime(j.runAt))+" · "+escHtml(privacyLabel)+'</div></div>';list.appendChild(row);});
      }
      renderList();panelOnKeyChange(root,"EXTUI:statusScheduleStore",renderList);return root;
    }
    return Object.freeze({buildStatusPanel:buildStatusPanel});
  };
})();
