;
(function () {
  "use strict";
  if (window.__extCreatePanelSystemMenusCore) return;
  window.__extCreatePanelSystemMenusCore = function (config) {
    config=config||{};
    var buildPanelShell=config.buildPanelShell;var panelBody=config.panelBody;var NAV_ICONS=config.navIcons||{};var PANEL_BRAND=config.panelBrand||{};
    var iconChip=config.iconChip;var escHtml=config.escHtml;var toast=config.toast;var openShellHtml=config.openShellHtml;var extWorkspace=config.workspace;var ensurePanel=config.ensurePanel;var extSyncActiveNavButtons=config.syncNav;
    var extNormalizePanelOpenMode=config.normalizePanelOpenMode;var extPanelOpenMode=config.panelOpenMode;var extSetPanelOpenMode=config.setPanelOpenMode;var extSet=config.set;var extGet=config.get;var OPTIONS_KEY=config.optionsKey;var OPTIONS_DEFAULTS=config.optionsDefaults||{};
    var extParseOptionsPayload=config.parseOptionsPayload;var applySidebarPlacementToDocument=config.applySidebarPlacement;var applyFloatingWorkspaceSettingsToDocument=config.applyFloatingSettings;var extBuildSwitch=config.buildSwitch;var MENU_CONFIG_ITEMS=config.menuConfigItems||[];
    var EXTUI_MENUS_PANELS_ICON='<path d="M4 6h10M18 6h2M4 12h3M11 12h9M4 18h7M15 18h5"/><circle cx="16" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="13" cy="18" r="2"/>';
    var EXTUI_QUICK_MENU_ICON='<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>';
    function buildConfigureMenuPanel(){var fn=config.getConfigureMenuBuilder&&config.getConfigureMenuBuilder();if(typeof fn!=="function")throw new Error("Configurar Menu indisponível.");return fn.apply(null,arguments);}
    function buildConfigureQuickMenuPanel(){var fn=config.getConfigureQuickMenuBuilder&&config.getConfigureQuickMenuBuilder();if(typeof fn!=="function")throw new Error("Configurar Menu Rápido indisponível.");return fn.apply(null,arguments);}
    function extBuildPanelModeSetting(mode) {
      var card=document.createElement("section");card.className="extuiPanelModeSetting";
      var copy=document.createElement("div");copy.className="extuiPanelModeSettingCopy";
      var title=document.createElement("strong");title.textContent="Abertura dos Painéis";
      var desc=document.createElement("span");desc.textContent="Escolha entre uma coluna integrada ao WhatsApp ou janelas soltas.";
      copy.appendChild(title);copy.appendChild(desc);
      var group=document.createElement("div");group.className="extuiPanelModeSegment";group.setAttribute("role","radiogroup");group.setAttribute("aria-label","Abertura dos Painéis");
      [["docked","Acoplado"],["floating","Flutuante"]].forEach(function(item){
        var btn=document.createElement("button");btn.type="button";btn.className="extuiPanelModeSegmentButton";btn.dataset.mode=item[0];btn.textContent=item[1];btn.setAttribute("role","radio");group.appendChild(btn);
      });
      function paint(value){value=extNormalizePanelOpenMode(value);group.querySelectorAll(".extuiPanelModeSegmentButton").forEach(function(btn){var on=btn.dataset.mode===value;btn.classList.toggle("extuiActive",on);btn.setAttribute("aria-checked",String(on));btn.tabIndex=on?0:-1;});}
      paint(mode);
      group.addEventListener("click",async function(ev){
        var btn=ev.target.closest(".extuiPanelModeSegmentButton");if(!btn||btn.disabled)return;
        var next=extNormalizePanelOpenMode(btn.dataset.mode);if(next===extPanelOpenMode())return;
        group.querySelectorAll("button").forEach(function(b){b.disabled=true;});
        try{await extSet(OPTIONS_KEY,{panelOpenMode:next});extSetPanelOpenMode(next,true);paint(next);toast(next==="docked"?"Painéis acoplados à Sidebar.":"Painéis em janelas flutuantes.");}
        catch(e){paint(extPanelOpenMode());toast("Não foi possível salvar o modo de abertura dos painéis.",true);}
        finally{group.querySelectorAll("button").forEach(function(b){b.disabled=false;});}
      });
      group.addEventListener("keydown",function(ev){var buttons=Array.from(group.querySelectorAll(".extuiPanelModeSegmentButton")),index=buttons.indexOf(document.activeElement);if(index<0)return;if(ev.key==="ArrowRight")index=(index+1)%buttons.length;else if(ev.key==="ArrowLeft")index=(index-1+buttons.length)%buttons.length;else return;ev.preventDefault();buttons[index].focus();buttons[index].click();});
      card.appendChild(copy);card.appendChild(group);return card;
    }
    async function extLoadMenusPanelsAppearance(){
      return extParseOptionsPayload(await extGet(OPTIONS_KEY));
    }
    async function extSaveMenusPanelsAppearance(opts){
      var patch={
        sidebarPlacement:opts.sidebarPlacement,sidebarPlacementUserSet:opts.sidebarPlacementUserSet===true,sidebarPlacementVersion:2,
        rightSidebarPanelsFollowRail:opts.rightSidebarPanelsFollowRail===true,
        floatingWindowMovable:opts.floatingWindowMovable===true,floatingWindowResizable:opts.floatingWindowResizable===true,floatingWorkspaceLayoutVersion:4
      };
      var saved=await extSet(OPTIONS_KEY,patch);saved=extParseOptionsPayload(saved||Object.assign({},opts,patch));applySidebarPlacementToDocument(saved.sidebarPlacement);document.documentElement.setAttribute("data-extui-right-panels-follow-rail",String(saved.rightSidebarPanelsFollowRail===true));applyFloatingWorkspaceSettingsToDocument(saved.floatingWindowMovable,saved.floatingWindowResizable);return saved;
    }
    function extBuildSidebarPlacementSetting(opts){
      var card=document.createElement("section");card.className="extuiPanelModeSetting extuiPanelPreferenceSetting extuiSidebarPlacementSetting";
      var copy=document.createElement("div");copy.className="extuiPanelModeSettingCopy";copy.innerHTML='<strong>Posição da Sidebar</strong><span>À esquerda, ocupa uma coluna antes do menu do WhatsApp; à direita, fica ao lado da conversa.</span>';
      var controls=document.createElement("div");controls.className="extuiPanelPreferenceControls";
      var group=document.createElement("div");group.className="extuiPanelModeSegment";group.setAttribute("role","radiogroup");group.setAttribute("aria-label","Posição da Sidebar");
      [["left-native","Esquerda do menu do WhatsApp"],["right-conversation","Direita da conversa"]].forEach(function(item){var btn=document.createElement("button");btn.type="button";btn.className="extuiPanelModeSegmentButton";btn.dataset.placement=item[0];btn.textContent=item[1];btn.setAttribute("role","radio");group.appendChild(btn);});
      var followRow=extConfigureToggleRow("Abrir painéis junto à Sidebar","Na posição direita, os painéis avançam a partir da Sidebar sobre a área da conversa.",opts.rightSidebarPanelsFollowRail===true,async function(next){var previous=opts.rightSidebarPanelsFollowRail;opts.rightSidebarPanelsFollowRail=next;try{opts=await extSaveMenusPanelsAppearance(opts);paint();return true;}catch(_){opts.rightSidebarPanelsFollowRail=previous;toast("Não foi possível salvar a posição de abertura dos painéis.",true);return false;}});
      followRow.classList.add("extuiPanelPreferenceToggle");
      function paint(){var value=opts.sidebarPlacement==="right-conversation"?"right-conversation":"left-native";group.querySelectorAll(".extuiPanelModeSegmentButton").forEach(function(btn){var on=btn.dataset.placement===value;btn.classList.toggle("extuiActive",on);btn.setAttribute("aria-checked",String(on));btn.tabIndex=on?0:-1;});followRow.hidden=value!=="right-conversation";}
      group.addEventListener("click",async function(ev){var btn=ev.target.closest(".extuiPanelModeSegmentButton");if(!btn||btn.disabled)return;var next=btn.dataset.placement;if(next===opts.sidebarPlacement)return;var previous=opts.sidebarPlacement;group.querySelectorAll("button").forEach(function(b){b.disabled=true;});opts.sidebarPlacement=next;opts.sidebarPlacementUserSet=true;opts.sidebarPlacementVersion=2;try{opts=await extSaveMenusPanelsAppearance(opts);paint();toast(next==="right-conversation"?"Sidebar movida para a direita da conversa.":"Sidebar movida para a esquerda do menu do WhatsApp.");}catch(_){opts.sidebarPlacement=previous;paint();toast("Não foi possível salvar a posição da Sidebar.",true);}finally{group.querySelectorAll("button").forEach(function(b){b.disabled=false;});}});
      group.addEventListener("keydown",function(ev){var buttons=Array.from(group.querySelectorAll(".extuiPanelModeSegmentButton")),index=buttons.indexOf(document.activeElement);if(index<0)return;if(ev.key==="ArrowRight")index=(index+1)%buttons.length;else if(ev.key==="ArrowLeft")index=(index-1+buttons.length)%buttons.length;else return;ev.preventDefault();buttons[index].focus();buttons[index].click();});
      controls.appendChild(group);controls.appendChild(followRow);card.appendChild(copy);card.appendChild(controls);paint();return card;
    }
    function extBuildFloatingWindowsSetting(opts){
      var card=document.createElement("section");card.className="extuiPanelModeSetting extuiPanelPreferenceSetting extuiFloatingWindowsSetting is-collapsed";
      var disclosure=document.createElement("button");disclosure.type="button";disclosure.className="extuiFloatingWindowsDisclosure";disclosure.setAttribute("aria-expanded","false");disclosure.setAttribute("aria-controls","extuiFloatingWindowsControls");
      var copy=document.createElement("div");copy.className="extuiPanelModeSettingCopy";copy.innerHTML='<strong>Janelas Flutuantes</strong><span>Defina como os painéis soltos podem ser reposicionados e redimensionados.</span>';
      var chevron=document.createElement("span");chevron.className="extuiFloatingWindowsChevron";chevron.setAttribute("aria-hidden","true");chevron.textContent="⌄";
      disclosure.appendChild(copy);disclosure.appendChild(chevron);
      var controls=document.createElement("div");controls.id="extuiFloatingWindowsControls";controls.className="extuiPanelPreferenceControls extuiFloatingWindowsControls";controls.hidden=true;
      controls.appendChild(extConfigureToggleRow("Permitir mover os painéis","Arraste janelas flutuantes para reposicioná-las.",opts.floatingWindowMovable===true,async function(next){var previous=opts.floatingWindowMovable;opts.floatingWindowMovable=next;opts.floatingWorkspaceLayoutVersion=4;try{opts=await extSaveMenusPanelsAppearance(opts);return true;}catch(_){opts.floatingWindowMovable=previous;toast("Não foi possível salvar a movimentação das janelas.",true);return false;}}));
      controls.appendChild(extConfigureToggleRow("Permitir redimensionar os painéis","Ajuste manualmente o tamanho das janelas flutuantes.",opts.floatingWindowResizable===true,async function(next){var previous=opts.floatingWindowResizable;opts.floatingWindowResizable=next;opts.floatingWorkspaceLayoutVersion=4;try{opts=await extSaveMenusPanelsAppearance(opts);return true;}catch(_){opts.floatingWindowResizable=previous;toast("Não foi possível salvar o redimensionamento das janelas.",true);return false;}}));
      Array.from(controls.children).forEach(function(row){row.classList.add("extuiPanelPreferenceToggle");});
      disclosure.addEventListener("click",function(){var expanded=disclosure.getAttribute("aria-expanded")==="true",next=!expanded;disclosure.setAttribute("aria-expanded",String(next));controls.hidden=!next;card.classList.toggle("is-collapsed",!next);});
      card.appendChild(disclosure);card.appendChild(controls);return card;
    }
    function extSystemMenuRow(icon, accent, title, desc, onClick) {
      var row=document.createElement("button");row.type="button";row.className="extuiDockedPanelRow extSystemMenuRow";
      row.innerHTML=iconChip(accent,icon,true)+'<div class="extuiDockedPanelRowText"><div class="extuiDockedPanelRowTitle">'+escHtml(title)+'</div><div class="extuiDockedPanelRowMeta">'+escHtml(desc||"")+'</div></div><svg class="extuiSystemMenuChevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>';
      row.addEventListener("click",async function(ev){
        ev.preventDefault();ev.stopPropagation();
        if(row.disabled)return;row.disabled=true;row.setAttribute("aria-busy","true");
        try{await onClick(ev);}catch(err){toast("Não foi possível abrir esta opção. Recarregue o WhatsApp e tente novamente.",true);}
        finally{row.disabled=false;row.removeAttribute("aria-busy");}
      });return row;
    }
    async function extOpenSystemDestination(section,focus){
      var response=await openShellHtml(section,{reuseExisting:true,focus:focus||null});
  
  
      if(response&&response.ok!==false){extWorkspace.close();extSyncActiveNavButtons();}
      return response;
    }
    var systemReturnBound=new WeakSet();
    function extPanelBackToSystem(root){
      var back=root.querySelector("[data-back]");
      if(back&&!systemReturnBound.has(back)){systemReturnBound.add(back);back.hidden=false;back.title="Voltar ao Sistema";back.addEventListener("click",async function(ev){ev.preventDefault();ev.stopImmediatePropagation();var system=await ensurePanel("sistema",buildSystemPanel);extWorkspace.open(system);extSyncActiveNavButtons();},true);}
    }
    async function buildMenusPanelsPanel(){
      var root=buildPanelShell({id:"extuiNavMenusPanelsPanel",title:"Menus & Painéis",accent:"#14b8a6",icon:EXTUI_MENUS_PANELS_ICON,eyebrow:"Sistema",hint:"Controle a abertura, a posição da Sidebar, as janelas flutuantes e a organização dos menus.",size:"sm",tutorialKey:"menus-paineis"});
      var body=panelBody(root);body.innerHTML="";extPanelBackToSystem(root);
      var appearance;try{appearance=await extLoadMenusPanelsAppearance();}catch(_){appearance=Object.assign({},OPTIONS_DEFAULTS);}
      body.appendChild(extBuildPanelModeSetting(extPanelOpenMode()));
      body.appendChild(extBuildSidebarPlacementSetting(appearance));
      body.appendChild(extBuildFloatingWindowsSetting(appearance));
      body.appendChild(extSystemMenuRow(NAV_ICONS.configurarMenu,"#f59e0b","Configurar Menu","Escolha quais atalhos aparecem e a ordem na Sidebar.",async function(){var panel=await ensurePanel("configurar-menu",buildConfigureMenuPanel);extWorkspace.open(panel);}));
      body.appendChild(extSystemMenuRow(EXTUI_QUICK_MENU_ICON,"#22d3ee","Configurar Menu Rápido","Escolha quais atalhos aparecem no Menu Rápido.",async function(){var panel=await ensurePanel("configurar-menu-rapido",buildConfigureQuickMenuPanel);extWorkspace.open(panel);}));
      return root;
    }
    async function buildSystemPanel() {
      var root=buildPanelShell({id:"extuiNavSystemPanel",title:"Sistema",accent:"#64748b",icon:NAV_ICONS.sistema,eyebrow:"Extensão",hint:"Integrações, personalização, ajustes, cópias de segurança e menus.",size:"sm",tutorialKey:"sistema"});
      var body=panelBody(root);body.innerHTML="";
      var metaOfficialRow=extSystemMenuRow(NAV_ICONS.integracoes,"#1877f2","Meta Oficial","WhatsApp Business Platform oficial com a conta do próprio cliente.",function(){return extOpenSystemDestination("meta-oficial");});metaOfficialRow.classList.add("extSystemMenuRow--featured");body.appendChild(metaOfficialRow);
      body.appendChild(extSystemMenuRow(NAV_ICONS.integracoes,"#0ea5e9","Integrações","Serviços de IA, webhooks e outras integrações.",function(){return extOpenSystemDestination("integracoes");}));
      body.appendChild(extSystemMenuRow(NAV_ICONS.personalizacao,"#8b5cf6","Personalização","Modo, temas, tipografia e ícones.",function(){return extOpenSystemDestination("personalizacao");}));
      body.appendChild(extSystemMenuRow(PANEL_BRAND.ajustes.icon,PANEL_BRAND.ajustes.accent,"Ajustes","Preferências operacionais da extensão.",function(){return extOpenSystemDestination("ajustes");}));
      body.appendChild(extSystemMenuRow(NAV_ICONS.backup,"#10b981","Cópia de Segurança","Exportação, importação e cópia automática.",function(){return extOpenSystemDestination("backup");}));
      body.appendChild(extSystemMenuRow(EXTUI_MENUS_PANELS_ICON,"#14b8a6","Menus & Painéis","Abertura dos painéis e configuração dos menus da Sidebar e Menu Rápido.",async function(){var panel=await ensurePanel("menus-paineis",buildMenusPanelsPanel);extWorkspace.open(panel);}));
      return root;
    }
    function extApplyMenuVisibility(options) {
      options=options||{};var visibility=options.menuVisibility&&typeof options.menuVisibility==="object"?options.menuVisibility:{};
      MENU_CONFIG_ITEMS.forEach(function(item){var el=document.querySelector('[data-extui-nav-key="'+item[0]+'"]');if(el)el.style.display=visibility[item[0]]===false?"none":"";});
    }
    function extConfigureToggleRow(label,desc,enabled,onToggle){
      var row=document.createElement("div");row.className="extuiNavToggleRow";var txt=document.createElement("div");txt.className="extuiNavToggleText";txt.innerHTML='<div class="title">'+escHtml(label)+'</div><div class="desc">'+escHtml(desc||"")+'</div>';var sw=extBuildSwitch(enabled,onToggle);sw.setAttribute("aria-label",label);row.appendChild(txt);row.appendChild(sw);return row;
    }
    return Object.freeze({buildSystemPanel:buildSystemPanel,buildMenusPanelsPanel:buildMenusPanelsPanel,configureToggleRow:extConfigureToggleRow,applyMenuVisibility:extApplyMenuVisibility,quickMenuIcon:EXTUI_QUICK_MENU_ICON,menusPanelsIcon:EXTUI_MENUS_PANELS_ICON});
  };
})();
