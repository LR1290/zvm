;(function(){
  "use strict";
  if(window.__extCreateAutomationResourceCore)return;
  window.__extCreateAutomationResourceCore=function(deps){
    deps=deps||{};


    function extAutomationExecutionMessage(error, kind) {
      var raw = String(error && error.message || error || "").trim();
      if (!raw) return "Não foi possível iniciar " + (kind === "flow" ? "o Fluxo." : "o Funil.");
      if (/flow not found/i.test(raw)) return "Este Fluxo não existe mais. Atualize a lista e tente novamente.";
      if (/flow has no start node/i.test(raw)) return "Este Fluxo não possui uma etapa inicial válida. Abra o editor e revise a automação.";
      if (/a flow is already running for chat/i.test(raw)) return "Já existe um Fluxo em execução nesta conversa. Aguarde ou cancele a execução atual antes de iniciar outro.";
      if (/flow does not allow group chats/i.test(raw)) return "Este Fluxo não está configurado para grupos.";
      if (/flow does not allow direct contacts/i.test(raw)) return "Este Fluxo não está configurado para contatos individuais.";
      if (/funnel not found/i.test(raw)) return "Este Funil não existe mais. Atualize a lista e tente novamente.";
      if (/funnel has no items/i.test(raw)) return "Este Funil ainda não possui etapas. Abra o editor e adicione pelo menos uma etapa.";
      if (/this funnel is already running for chat/i.test(raw)) return "Este Funil já está em execução nesta conversa.";
      return raw;
    }


    function extAutomationResourceTitle(item, fallback) {
      return String(item && (item.name || item.title || item.label) || fallback || "Automação").trim() || String(fallback || "Automação");
    }

    function extAutomationResourceStepCount(item, kind) {
      if (!item || typeof item !== "object") return 0;
      var candidates = kind === "flow" ? [item.nodes, item.steps, item.actions] : [item.items, item.steps, item.actions];
      for (var i=0;i<candidates.length;i++) if (Array.isArray(candidates[i])) return candidates[i].length;
      return 0;
    }

    function extAutomationResourceTrigger(flow) {
      var trigger = flow && (flow.trigger || flow.gatilho || flow.triggerType);
      if (trigger && typeof trigger === "object") trigger = trigger.type || trigger.kind || trigger.mode;
      trigger = String(trigger || "manual").toLowerCase();
      if (trigger === "manual" || trigger === "inicio-manual" || trigger === "start-manual") return "Manual";
      if (trigger.indexOf("crm") >= 0) return "CRM";
      if (trigger.indexOf("message") >= 0 || trigger.indexOf("mensagem") >= 0) return "Mensagem";
      return trigger ? trigger.charAt(0).toUpperCase()+trigger.slice(1) : "Manual";
    }
    return Object.freeze({executionMessage:extAutomationExecutionMessage,resourceTitle:extAutomationResourceTitle,stepCount:extAutomationResourceStepCount,triggerLabel:extAutomationResourceTrigger});
  };
})();
