;(function () {
  "use strict";
  if (window.__extCreateCommandHostCore) return;
  window.__extCreateCommandHostCore = function (options) {
    options = options || {};
    var handlers = options.handlers || Object.create(null);
    var resolveState = typeof options.state === "function" ? options.state : function () { return { available: false, active: false }; };
    var getPlanGate = typeof options.getPlanGate === "function" ? options.getPlanGate : function () { return window.__extPlanGate || null; };
    function has(id) { return typeof handlers[id] === "function"; }
    function list() { return Object.keys(handlers); }
    function state(id) { return resolveState(id); }
    function execute(id, payload) {
      var handler = handlers[id];
      if (!handler) {
        var unknown = new Error("Comando desconhecido: " + id);
        unknown.code = "EXTAPP_UNKNOWN_COMMAND";
        return Promise.reject(unknown);
      }
      var gate = getPlanGate();
      return Promise.resolve(gate ? gate.requireCommand(id) : true).then(function () { return handler(payload || {}); });
    }
    return Object.freeze({ version: "1.0.0", has: has, list: list, state: state, execute: execute });
  };
})();
