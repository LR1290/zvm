;
(function () {
  "use strict";
  if (window.__extCreatePanelWorkspaceController) return;
  window.__extCreatePanelWorkspaceController = function (config) {
    config = config || {};
    var adopt = typeof config.adopt === "function" ? config.adopt : function (root) { return root; };
    var applyOpenMode = typeof config.applyOpenMode === "function" ? config.applyOpenMode : function () {};
    var setVisibility = typeof config.setVisibility === "function" ? config.setVisibility : function () {};
    var focusOnOpen = typeof config.focusOnOpen === "function" ? config.focusOnOpen : function () {};
    var popSubview = typeof config.popSubview === "function" ? config.popSubview : function () {};
    var releaseFromDock = typeof config.releaseFromDock === "function" ? config.releaseFromDock : function () {};
    var deactivateDockHost = typeof config.deactivateDockHost === "function" ? config.deactivateDockHost : function () {};
    var syncNav = typeof config.syncNav === "function" ? config.syncNav : function () {};
    var restoreFocusAfterClose = typeof config.restoreFocusAfterClose === "function" ? config.restoreFocusAfterClose : function () {};
    var collapseRail = typeof config.collapseRail === "function" ? config.collapseRail : function () {};
    var scheduleQuickItems = typeof config.scheduleQuickItems === "function" ? config.scheduleQuickItems : function () {};
    var shellHasSubviews = typeof config.hasSubviews === "function" ? config.hasSubviews : function () { return false; };
    var shellPeekSubview = typeof config.peekSubview === "function" ? config.peekSubview : function () { return null; };
    var controller = {
      activePanel: null,
      open: function (root) {
        if (!root) return false;
        adopt(root);
        var wasOpen = root.classList.contains("extuiOpen") && !root.hidden;
        controller.close();
        if (wasOpen) return false;
        applyOpenMode(root);
        var mainScroll = root.querySelector(".extuiPanelBody");
        if (mainScroll) mainScroll.scrollTop = 0;
        setVisibility(root, true);
        controller.activePanel = root;
        collapseRail();
        focusOnOpen(root);
        if (mainScroll) {
          mainScroll.scrollTop = 0;
          requestAnimationFrame(function () { if (controller.activePanel === root) mainScroll.scrollTop = 0; });
        }
        syncNav();
        window.dispatchEvent(new CustomEvent("ext:panel-state", { detail: { panelId: root.id || null, open: true } }));
        scheduleQuickItems();
        return true;
      },
      close: function () {
        var closedIds = [];
        document.querySelectorAll(".extuiNavPanel").forEach(function (panel) {
          if (panel.classList.contains("extuiOpen") || !panel.hidden) {
            if (panel.id) closedIds.push(panel.id);
            setVisibility(panel, false);
            while (shellHasSubviews(panel)) popSubview(panel);
            if (panel.parentElement && panel.parentElement.id === "extapp-panel-dock-host") releaseFromDock(panel);
          }
        });
        controller.activePanel = null;
        deactivateDockHost();
        syncNav();
        closedIds.forEach(function (panelId) {
          window.dispatchEvent(new CustomEvent("ext:panel-state", { detail: { panelId: panelId, open: false } }));
        });
        scheduleQuickItems();
      },
      isOpen: function (root) { return !!(root && root.classList.contains("extuiOpen") && !root.hidden); },
      pushSubview: function (title, renderFn, meta) { if (controller.activePanel) config.pushSubview(controller.activePanel, title, renderFn, meta); },
      popSubview: function () { if (controller.activePanel && shellHasSubviews(controller.activePanel)) popSubview(controller.activePanel); },
      hasSubviews: function (root) { return shellHasSubviews(root || controller.activePanel); },
      peekSubview: function (root) { return shellPeekSubview(root || controller.activePanel); }
    };
    controller.installEscapeHandler = function () {
      if (controller._escapeInstalled) return;
      controller._escapeInstalled = true;
      document.addEventListener("keydown", function (ev) {
        if (ev.key !== "Escape") return;
        var openPanel = document.querySelector(".extuiNavPanel.extuiOpen");
        if (!openPanel) return;
        ev.stopPropagation();
        if (shellHasSubviews(openPanel)) { controller.popSubview(); return; }
        var panelId = openPanel.id;
        controller.close();
        syncNav();
        restoreFocusAfterClose(panelId);
      });
    };
    return controller;
  };
})();
