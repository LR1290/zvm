;(function(){
  "use strict";
  if(typeof window.__extFindComposeAnchor==="function")return;
  function extComposeVisible(node){
    if(!node||!node.isConnected||typeof node.getBoundingClientRect!=="function")return false;
    var r=node.getBoundingClientRect();
    return r.width>24&&r.height>12&&r.bottom>0&&r.top<window.innerHeight;
  }
  function findComposeMain(){
    var main=document.getElementById("main");
    if(main&&main.isConnected)return main;
    var selectors=['[role="main"]','[data-testid="conversation-panel-wrapper"]','[data-testid="conversation-panel-body"]'];
    for(var i=0;i<selectors.length;i++){try{var node=document.querySelector(selectors[i]);if(node&&node.isConnected)return node;}catch(_){}}
    return null;
  }
  function findComposeAnchor(){
    var main=findComposeMain();
    if(!main)return null;
    var footers=[];try{footers=Array.prototype.slice.call(main.querySelectorAll("footer"));}catch(_){}
    for(var fi=footers.length-1;fi>=0;fi--){if(extComposeVisible(footers[fi]))return footers[fi];}
    var selectors=['[contenteditable="true"][role="textbox"]','div[contenteditable="true"][data-tab]','[data-testid="conversation-compose-box-input"]','textarea'];
    var input=null;
    for(var si=0;si<selectors.length&&!input;si++){try{var nodes=main.querySelectorAll(selectors[si]);for(var ni=nodes.length-1;ni>=0;ni--){if(extComposeVisible(nodes[ni])){input=nodes[ni];break;}}}catch(_){}}
    if(!input)return null;
    var mainRect=main.getBoundingClientRect(),best=input.parentElement||input,node=best,depth=0;
    while(node&&node!==main&&depth<10){var rect=node.getBoundingClientRect();if(rect.width>=Math.max(180,mainRect.width*.38)&&rect.height>=30&&rect.height<=280&&rect.bottom>=mainRect.bottom-300)best=node;node=node.parentElement;depth+=1;}
    return extComposeVisible(best)?best:input;
  }
  window.__extFindComposeAnchor=findComposeAnchor;
})();
