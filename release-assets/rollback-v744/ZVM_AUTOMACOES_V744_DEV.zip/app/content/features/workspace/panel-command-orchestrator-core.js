;(function(){
  "use strict";
  if(window.__extCreatePanelCommandOrchestratorCore)return;
  window.__extCreatePanelCommandOrchestratorCore=function(deps){
    deps=deps||{};
    var PANEL_BRAND=deps.PANEL_BRAND;
    var NAV_ICONS=deps.NAV_ICONS;
    var CHAT_TOOL_META=deps.CHAT_TOOL_META;
    var buildCrmPanel=deps.buildCrmPanel;
    var buildCrmFunnelPanel=deps.buildCrmFunnelPanel;
    var buildOrdersPanel=deps.buildOrdersPanel;
    var buildDeliveryPanel=deps.buildDeliveryPanel;
    var buildEnviosPanel=deps.buildEnviosPanel;
    var buildFluxosPanel=deps.buildFluxosPanel;
    var buildFunisPanel=deps.buildFunisPanel;
    var buildQuickResponsePanel=deps.buildQuickResponsePanel;
    var buildFollowUpPanel=deps.buildFollowUpPanel;
    var buildAgendaPanel=deps.buildAgendaPanel;
    var buildAutoServicePanel=deps.buildAutoServicePanel;
    var buildStatusPanel=deps.buildStatusPanel;
    var buildActionsPanel=deps.buildActionsPanel;
    var buildChatToolsPanel=deps.buildChatToolsPanel;
    var buildNotesStandalonePanel=deps.buildNotesStandalonePanel;
    var buildReminderStandalonePanel=deps.buildReminderStandalonePanel;
    var buildGoogleCalendarStandalonePanel=deps.buildGoogleCalendarStandalonePanel;
    var buildSignatureStandalonePanel=deps.buildSignatureStandalonePanel;
    var buildTextAssistantStandalonePanel=deps.buildTextAssistantStandalonePanel;
    var buildTextReplaceStandalonePanel=deps.buildTextReplaceStandalonePanel;
    var buildGlobalLabelsPanel=deps.buildGlobalLabelsPanel;
    var buildGooglePanel=deps.buildGooglePanel;
    var buildNotificationsPanel=deps.buildNotificationsPanel;
    var buildSystemPanel=deps.buildSystemPanel;
    var buildWebhooksPanel=deps.buildWebhooksPanel;
    var extToggleChatWorkspace=deps.extToggleChatWorkspace;
    var extOpenCrmWorkspace=deps.extOpenCrmWorkspace;
    var extOpenOrdersWorkspace=deps.extOpenOrdersWorkspace;
    var extOpenQuickResponseWorkspace=deps.extOpenQuickResponseWorkspace;
    var extOpenClientWorkspace=deps.extOpenClientWorkspace;
    var extOpenLabelsWorkspace=deps.extOpenLabelsWorkspace;
    var extOpenAgendaWorkspace=deps.extOpenAgendaWorkspace;
    var extOpenNotesWorkspace=deps.extOpenNotesWorkspace;
    var extCoreCommandHostPanelState=deps.extCoreCommandHostPanelState;
    var extCoreCommandHostOpenBuilt=deps.extCoreCommandHostOpenBuilt;
    var extCommandHostOpenExternal=deps.extCommandHostOpenExternal;
    var extCoreCommandHostOpenLabels=deps.extCoreCommandHostOpenLabels;
    var extCoreCommandHostOpenDashboard=deps.extCoreCommandHostOpenDashboard;
    var extCommandHostExportContacts=deps.extCommandHostExportContacts;
    var extCoreCommandHostQuickResponse=deps.extCoreCommandHostQuickResponse;
    var extWorkspace=deps.extWorkspace;
    var extActivityList=deps.extActivityList;
    var ACTIVITY_ACTIVE_STATUSES=deps.ACTIVITY_ACTIVE_STATUSES;
    var extLoadNotifications=deps.extLoadNotifications;
    var syncOnboardingNavContext=typeof deps.syncOnboardingNavContext==="function"?deps.syncOnboardingNavContext:function(){};
    if(typeof extCoreCommandHostPanelState!=="function")throw new TypeError("Dependência de estado do CommandHost inválida.");
    var createPanelBuilderCatalog = window.__extCreatePanelBuilderCatalog;
    if (typeof createPanelBuilderCatalog !== "function") throw new Error("Catálogo de builders não foi carregado.");
    var panelBuilderCatalog = createPanelBuilderCatalog();
    function registerBuiltPanel(definition, specialHandler) {
      var handler = typeof specialHandler === "function" ? specialHandler : function (payload) { return extCoreCommandHostOpenBuilt(definition.key, definition.builder, payload); };
      return panelBuilderCatalog.register(Object.assign({}, definition, { handler: handler }));
    }
    registerBuiltPanel({key:"crm",commandId:"crm.open",category:"clientes",panelId:"extuiNavCrmPanel",accent:PANEL_BRAND.crm.accent,icon:PANEL_BRAND.crm.icon,title:"CRM",desc:"Veja e edite rapidamente onde o contato aberto está no seu funil",builder:buildCrmPanel},function(payload){return payload&&payload.source==="chat-quick-actions"?extToggleChatWorkspace("crm",extOpenCrmWorkspace):extCoreCommandHostOpenBuilt("crm",buildCrmPanel,payload);});
    registerBuiltPanel({key:"crm-funnel",commandId:"crm-funnel.open",category:"clientes",panelId:"extuiNavCrmFunnelPanel",accent:PANEL_BRAND.crmFunnel.accent,icon:PANEL_BRAND.crmFunnel.icon,title:"Funil CRM",desc:"Análise de contatos, conversão e etapas do CRM",builder:buildCrmFunnelPanel});
    registerBuiltPanel({key:"encomendas",commandId:"orders.open",category:"clientes",panelId:"extuiNavOrdersPanel",accent:PANEL_BRAND.orders.accent,icon:PANEL_BRAND.orders.icon,title:"Encomendas",desc:"Pedidos e rastreios do contato atual",builder:buildOrdersPanel},function(payload){return payload&&payload.source==="chat-quick-actions"?extToggleChatWorkspace("orders",extOpenOrdersWorkspace):extCoreCommandHostOpenBuilt("encomendas",buildOrdersPanel,payload);});
    registerBuiltPanel({key:"delivery",commandId:"delivery.open",category:"clientes",panelId:"extuiNavDeliveryPanel",accent:PANEL_BRAND.delivery.accent,icon:PANEL_BRAND.delivery.icon,title:"Entregas",desc:"Entregas, etapas e avisos do contato atual",builder:buildDeliveryPanel});
    registerBuiltPanel({key:"envios",commandId:"activity.open",category:"principal",panelId:"extuiNavEnviosPanel",accent:"#ec4899",icon:NAV_ICONS.envios,title:"Envios",desc:"Acompanhe em tempo real as atividades executadas pela extensão",builder:buildEnviosPanel});
    registerBuiltPanel({key:"fluxos",commandId:"flow.open",category:"automacao",panelId:"extuiNavFluxosPanel",accent:PANEL_BRAND.fluxos.accent,icon:PANEL_BRAND.fluxos.icon,title:"Fluxos",desc:"Automação disparada por palavra-chave ou nova conversa",builder:buildFluxosPanel});
    registerBuiltPanel({key:"funis",commandId:"funnel.open",category:"automacao",panelId:"extuiNavFunisPanel",accent:PANEL_BRAND.funis.accent,icon:PANEL_BRAND.funis.icon,title:"Funis",desc:"Sequência de itens com intervalo fixo entre cada um",builder:buildFunisPanel});
    registerBuiltPanel({key:"resposta-rapida",commandId:"quick-response.open",category:"comunicacao",panelId:"extuiQuickResponsePanel",accent:"#00a884",icon:NAV_ICONS.respostaRapida,title:"Respostas Rápidas",desc:"Respostas prontas com mensagens e ações executadas em sequência",builder:buildQuickResponsePanel},function(payload){return payload&&payload.source==="chat-quick-actions"?extToggleChatWorkspace("quick-responses",extOpenQuickResponseWorkspace):extCoreCommandHostQuickResponse(payload);});
    registerBuiltPanel({key:"followup",commandId:"followup.open",category:"automacao",panelId:"extuiNavFollowUpPanel",accent:PANEL_BRAND.followup.accent,icon:PANEL_BRAND.followup.icon,title:"FollowUp",desc:"Dispara automaticamente depois que o contato fica parado numa coluna do CRM",builder:buildFollowUpPanel});
    registerBuiltPanel({key:"autoatendimento",commandId:"auto-service.open",category:"produtividade",panelId:"extuiNavAutoServicePanel",accent:PANEL_BRAND.autoService.accent,icon:PANEL_BRAND.autoService.icon,title:"Autoatendimento",desc:"Regras automáticas para mensagens recebidas",builder:buildAutoServicePanel});
    registerBuiltPanel({key:"status",commandId:"status.open",category:"produtividade",panelId:"extuiNavStatusPanel",accent:PANEL_BRAND.status.accent,icon:PANEL_BRAND.status.icon,title:"Status",desc:"Publicar ou agendar Status do WhatsApp",builder:buildStatusPanel});
    registerBuiltPanel({key:"ferramentas",commandId:"tools.open",category:"produtividade",panelId:"extuiNavChatToolsPanel",accent:PANEL_BRAND.tools.accent,icon:PANEL_BRAND.tools.icon,title:"Ferramentas",desc:"Acesso a outros painéis e recursos da Sidebar",builder:buildChatToolsPanel});
    registerBuiltPanel({key:"agenda",commandId:"agenda.open",category:"automacao",panelId:"extuiNavAgendaPanel",accent:PANEL_BRAND.agenda.accent,icon:PANEL_BRAND.agenda.icon,title:"Agenda",desc:"Agendar o envio de um item para uma data/hora específica",builder:buildAgendaPanel},function(payload){return payload&&payload.source==="chat-quick-actions"?extToggleChatWorkspace("agenda",extOpenAgendaWorkspace):extCoreCommandHostOpenBuilt("agenda",buildAgendaPanel,payload);});
    registerBuiltPanel({key:"notas",commandId:"note.open",category:"produtividade",panelId:"extuiNavNotesPanel",accent:CHAT_TOOL_META.notes.accent,icon:CHAT_TOOL_META.notes.icon,title:"Notas",desc:CHAT_TOOL_META.notes.desc,builder:buildNotesStandalonePanel},function(payload){return payload&&payload.source==="chat-quick-actions"?extToggleChatWorkspace("notes",extOpenNotesWorkspace):extCoreCommandHostOpenBuilt("notas",buildNotesStandalonePanel,payload);});
    registerBuiltPanel({key:"lembrete",commandId:"reminder.open",category:"produtividade",panelId:"extuiNavReminderPanel",accent:CHAT_TOOL_META.lembrete.accent,icon:CHAT_TOOL_META.lembrete.icon,title:"Lembrete",desc:CHAT_TOOL_META.lembrete.desc,builder:buildReminderStandalonePanel});
    registerBuiltPanel({key:"google-calendar",commandId:"google-calendar.open",category:"produtividade",panelId:"extuiNavGoogleCalendarPanel",accent:CHAT_TOOL_META.google_calendario.accent,icon:CHAT_TOOL_META.google_calendario.icon,title:"Google Calendar",desc:CHAT_TOOL_META.google_calendario.desc,builder:buildGoogleCalendarStandalonePanel});
    registerBuiltPanel({key:"assinatura",commandId:"signature.open",category:"produtividade",panelId:"extuiNavSignaturePanel",accent:CHAT_TOOL_META.signature.accent,icon:CHAT_TOOL_META.signature.icon,title:"Assinatura",desc:CHAT_TOOL_META.signature.desc,builder:buildSignatureStandalonePanel});
    registerBuiltPanel({key:"assistente-texto",commandId:"text-assistant.open",category:"produtividade",panelId:"extuiNavTextAssistantPanel",accent:CHAT_TOOL_META.chat_assistant.accent,icon:CHAT_TOOL_META.chat_assistant.icon,title:"Assistente de texto",desc:CHAT_TOOL_META.chat_assistant.desc,builder:buildTextAssistantStandalonePanel});
    registerBuiltPanel({key:"substituicao-texto",commandId:"text-replace.open",category:"produtividade",panelId:"extuiNavTextReplacePanel",accent:CHAT_TOOL_META.replace_text.accent,icon:CHAT_TOOL_META.replace_text.icon,title:"Substituição de texto",desc:CHAT_TOOL_META.replace_text.desc,builder:buildTextReplaceStandalonePanel});
    registerBuiltPanel({key:"labels",commandId:"labels.open",category:"produtividade",panelId:"extuiNavLabelsPanel",accent:"#22c55e",icon:NAV_ICONS.etiquetas,title:"Etiquetas",desc:"Gerencie as etiquetas globais do WhatsApp Business",builder:buildGlobalLabelsPanel},function(payload){return payload&&payload.source==="chat-quick-actions"?extToggleChatWorkspace("labels",extOpenLabelsWorkspace):extCoreCommandHostOpenBuilt("labels",buildGlobalLabelsPanel,payload);});
    registerBuiltPanel({key:"google",commandId:"google.open",category:"produtividade",panelId:"extuiNavGooglePanel",accent:PANEL_BRAND.google.accent,icon:PANEL_BRAND.google.icon,title:"Google",desc:"Atalhos Google úteis para CRM e trabalho comercial",builder:buildGooglePanel});
    registerBuiltPanel({key:"notificacoes",commandId:"notifications.open",category:"sistema",panelId:"extuiNavNotificationsPanel",accent:"#22c55e",icon:NAV_ICONS.notificacoes,title:"Notificações",desc:"Comunicados, atualizações e mensagens não lidas",builder:buildNotificationsPanel});
    registerBuiltPanel({key:"sistema",commandId:"system.open",category:"sistema",panelId:"extuiNavSystemPanel",accent:"#64748b",icon:NAV_ICONS.sistema,title:"Sistema",desc:"Integrações, personalização, ajustes, cópias de segurança e menus",builder:buildSystemPanel});
    registerBuiltPanel({key:"webhooks",commandId:"webhooks.open",category:"sistema",panelId:"extuiNavWebhooksPanel",accent:PANEL_BRAND.webhooks.accent,icon:PANEL_BRAND.webhooks.icon,title:"Webhooks",desc:"Envia um aviso para outro serviço quando um evento acontecer",builder:buildWebhooksPanel});
  
    function extOpenBroadcastShellEmbed(payload) {
      var api = window.__extBroadcastShellEmbed;
      if (!api || typeof api.open !== "function") { var error = new Error("Host incorporado de Disparos indisponível."); error.code = "EXT_BROADCAST_SHELL_EMBED_UNAVAILABLE"; throw error; }
      return api.open(payload || {});
    }
    var specialCommandHandlers = Object.freeze({
      "client.open": function (payload) { return payload && payload.source === "chat-quick-actions" ? extToggleChatWorkspace("client",extOpenClientWorkspace) : extOpenClientWorkspace(); },
      "items.open": function (payload) { return extCommandHostOpenExternal("ext-items-panel-root", "items", payload); },
      "broadcast.open": function (payload) { return extCommandHostOpenExternal("ext-broadcast-panel-root", "broadcast", payload); },
      "broadcast-shell.open": extOpenBroadcastShellEmbed,
      "dashboard.open": extCoreCommandHostOpenDashboard,
      "export-contacts.open": extCommandHostExportContacts
    });
    var commandHostOrder = [
      "crm.open","client.open","crm-funnel.open","items.open","broadcast.open","broadcast-shell.open","quick-response.open","note.open","reminder.open","google-calendar.open","signature.open","text-assistant.open","text-replace.open","labels.open","agenda.open","flow.open","funnel.open","followup.open","auto-service.open","status.open","tools.open","google.open","activity.open","notifications.open","orders.open","delivery.open","webhooks.open","system.open","dashboard.open","export-contacts.open"
    ];
    var extCommandHostHandlers = Object.create(null);
    commandHostOrder.forEach(function(commandId){
      var entry = panelBuilderCatalog.getByCommand(commandId);
      var handler = entry ? entry.handler : specialCommandHandlers[commandId];
      if (typeof handler !== "function") throw new Error("Handler não registrado: " + commandId);
      extCommandHostHandlers[commandId] = handler;
    });
    extCommandHostHandlers = Object.freeze(extCommandHostHandlers);
    function extCoreIsExportSubviewOpen() {
      var panel=document.getElementById("ext-items-panel-root");
      if(!panel||!extWorkspace.isOpen(panel)||typeof extWorkspace.peekSubview!=="function")return false;
      var top=extWorkspace.peekSubview(panel);
      return !!(top&&top.title==="Exportar contatos");
    }
    function extCoreCommandHostStateUnlocked(id) {
      var specialPanelIds = {
        "items.open":"ext-items-panel-root", "broadcast.open":"ext-broadcast-panel-root"
      };
      var catalogEntry = panelBuilderCatalog.getByCommand(id);
      var panelId = catalogEntry ? catalogEntry.panelId : specialPanelIds[id];
      if (!extCommandHostHandlers[id]) return { available: false, active: false };
      if (id === "broadcast-shell.open") { var embeddedApi = window.__extBroadcastShellEmbed; return { available: !!(embeddedApi && typeof embeddedApi.open === "function"), active: !!(embeddedApi && typeof embeddedApi.state === "function" && embeddedApi.state().active) }; }
      if (id === "export-contacts.open") return { available: true, active: extCoreIsExportSubviewOpen() };
      var base = extCoreCommandHostPanelState(panelId ? document.getElementById(panelId) : null);
      if (id === "items.open" && extCoreIsExportSubviewOpen()) base.active = false;
      if (id === "activity.open") {
        base.badge = extActivityList().filter(function (a) { return a && ACTIVITY_ACTIVE_STATUSES[a.status]; }).length;
        return base;
      }
      if (id === "notifications.open") {
        return extLoadNotifications(false).then(function (data) {
          base.badge = data.items.filter(function (item) { return !data.read[item.id]; }).length;
          return base;
        }).catch(function () { return base; });
      }
      return base;
    }
    function extCoreCommandHostState(id){
      if(!window.__extPlanGate)return Promise.resolve({available:false,active:false,locked:true,reason:"license"});
      return window.__extPlanGate.state().then(function(plan){if(plan.locked)return{available:false,active:false,locked:true,reason:"license"};if(plan.isFree&&!window.__extPlanGate.commandAllowed(id))return{available:true,active:false,locked:true,plan:"pro"};return extCoreCommandHostStateUnlocked(id);}).catch(function(){return{available:false,active:false,locked:true,reason:"license"};});
    }
    var createCommandHostCore = window.__extCreateCommandHostCore;
    if (typeof createCommandHostCore !== "function") throw new Error("CommandHost não foi carregado.");
    window.ExtensionCore = window.ExtensionCore || {};
    window.ExtensionCore.CommandHost = createCommandHostCore({
      handlers: extCommandHostHandlers,
      state: extCoreCommandHostState,
      getPlanGate: function () { return window.__extPlanGate || null; }
    });
  
    var _navButtonsByPanelId = {};
    function extSyncActiveNavButtons() {
      Object.keys(_navButtonsByPanelId).forEach(function (panelId) {
        var panelEl = document.getElementById(panelId);
        var isOpen = !!(panelEl && panelEl.classList.contains("extuiOpen"));
        var navButton = _navButtonsByPanelId[panelId];
        navButton.classList.toggle("extuiActive", isOpen);
        navButton.setAttribute("aria-pressed", String(isOpen));
        if (isOpen) navButton.setAttribute("aria-current", "page");
        else navButton.removeAttribute("aria-current");
      });
      syncOnboardingNavContext();
    }
    return Object.freeze({ catalog:panelBuilderCatalog, navButtonsByPanelId:_navButtonsByPanelId, syncActiveNavButtons:extSyncActiveNavButtons, handlers:extCommandHostHandlers, order:commandHostOrder.slice() });
  };
})();
