;(function(){
  "use strict";
  if (window.__extInstallPanelDialogCore) return;
  window.__extInstallPanelDialogCore=function(){
    if (!window.extModalPrompt) {
      window.extModalPrompt = function (message, opts) {
        opts = opts || {};
        return new Promise(function (resolve) {
          var previousFocus = document.activeElement;
          var overlay = document.createElement("div");
          overlay.className = "extuiDialogOverlay";
          var card = document.createElement("div");
          card.className = "extuiDialog";
          card.setAttribute("role", "dialog");
          card.setAttribute("aria-modal", "true");
          card.setAttribute("tabindex", "-1");
          card.setAttribute("aria-label", opts.title || (opts.cancel === false ? "Aviso" : "Confirmação"));
          var msg = document.createElement("p");
          msg.className = "extuiDialogMsg";
          msg.id = "extui-dialog-msg-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
          msg.textContent = message;
          card.setAttribute("aria-describedby", msg.id);
          var actions = document.createElement("div");
          actions.className = "extuiDialogActions";
          var closed = false;
          function close(result) {
            if (closed) return;
            closed = true;
            document.removeEventListener("keydown", onKey, true);
            overlay.remove();
            if (previousFocus && previousFocus.isConnected && typeof previousFocus.focus === "function") {
              try { previousFocus.focus({ preventScroll: true }); } catch (_) { previousFocus.focus(); }
            }
            resolve(result);
          }
          function focusableButtons() {
            return Array.from(actions.querySelectorAll('button:not([disabled])'));
          }
          function onKey(ev) {
            if (ev.key === "Escape") { ev.preventDefault(); close(false); return; }
            if (ev.key === "Enter") {
              var active = document.activeElement;
              if (active && active.tagName === "BUTTON" && card.contains(active)) return;
              ev.preventDefault(); close(true); return;
            }
            if (ev.key !== "Tab") return;
            var nodes = focusableButtons();
            if (!nodes.length) { ev.preventDefault(); card.focus(); return; }
            var first = nodes[0], last = nodes[nodes.length - 1];
            if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
            else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
          }
          if (opts.cancel !== false) {
            var cancelBtn = document.createElement("button");
            cancelBtn.type = "button";
            cancelBtn.className = "extui-btn extui-btn--ghost";
            cancelBtn.textContent = opts.cancelLabel || "Cancelar";
            cancelBtn.addEventListener("click", function () { close(false); });
            actions.appendChild(cancelBtn);
          }
          var okBtn = document.createElement("button");
          okBtn.type = "button";
          okBtn.className = "extui-btn " + (opts.danger ? "extui-btn--danger" : "extui-btn--primary");
          okBtn.textContent = opts.okLabel || "OK";
          okBtn.addEventListener("click", function () { close(true); });
          actions.appendChild(okBtn);
          card.appendChild(msg);
          card.appendChild(actions);
          overlay.appendChild(card);
          overlay.addEventListener("click", function (ev) { if (ev.target === overlay) close(false); });
          document.addEventListener("keydown", onKey, true);
          document.body.appendChild(overlay);
          overlay.style.position = "fixed";
          overlay.style.inset = "0";
          overlay.style.background = "rgba(4,8,6,.6)";
          overlay.style.zIndex = "var(--extui-z-overlay, 2147483004)";
          overlay.style.display = "flex";
          overlay.style.alignItems = "center";
          overlay.style.justifyContent = "center";
          card.style.background = "var(--extui-card, #0d0d0d)";
          card.style.border = "1px solid var(--extui-border, #1e1e1e)";
          card.style.borderRadius = "16px";
          card.style.padding = "22px";
          card.style.width = "340px";
          card.style.maxWidth = "calc(100vw - 40px)";
          card.style.boxShadow = "0 12px 40px -10px rgba(0,0,0,.6)";
          msg.style.color = "var(--extui-text, #e0e0e0)";
          actions.style.display = "flex";
          actions.style.justifyContent = "flex-end";
          actions.style.gap = "10px";
          actions.style.marginTop = "20px";
          actions.querySelectorAll("button").forEach(function (btn) {
            btn.style.border = "1px solid transparent";
            btn.style.borderRadius = "10px";
            btn.style.padding = "9px 16px";
            btn.style.fontSize = "13px";
            btn.style.fontWeight = "600";
            btn.style.cursor = "pointer";
            btn.style.fontFamily = "inherit";
          });
          okBtn.style.background = opts.danger ? "transparent" : "var(--extui-primary, #00c85a)";
          okBtn.style.color = opts.danger ? "var(--extui-danger, #f05060)" : "#04150b";
          okBtn.style.borderColor = opts.danger ? "rgba(240,80,96,.4)" : "transparent";
          if (opts.cancel !== false) {
            var cancelBtnEl = actions.querySelector("button:first-child");
            cancelBtnEl.style.background = "var(--extui-card-2, #151515)";
            cancelBtnEl.style.color = "var(--extui-text-dim, #a0a0a0)";
            cancelBtnEl.style.borderColor = "var(--extui-border, #1e1e1e)";
          }
          okBtn.focus();
        });
      };
      window.extConfirm = function (message, opts) { return window.extModalPrompt(message, Object.assign({}, opts, { cancel: true })); };
      window.extAlert = function (message, opts) { return window.extModalPrompt(message, Object.assign({}, opts, { cancel: false })); };
    }
    return Object.freeze({ prompt:window.extModalPrompt, confirm:window.extConfirm, alert:window.extAlert });
  };
})();
