;
try{


(function () {
  "use strict";

  if (window.__extQuickItemsDockBooted) return;
  window.__extQuickItemsDockBooted = true;
  var QUICK_ACTION_DOCK_ID = "extapp-chat-quick-actions-root";
  var VIEWPORT_MARGIN = 8;
  var quickShelfRuntime = {
    quickActionDock: null,
    searchQuery: "", onlyFavorites: false, defaultOnlyFavorites: false, activeCategoryType: "all", activeIndex: -1, currentResultPairs: [],
    externalAnchorEl: null, itemsCache: [], itemsLoaded: false, cacheLoadFailed: false, cacheLastError: null,
    cacheRetryTimer: 0, cacheRetryAttempt: 0, bootLoaded: true, recents: [], quickShelfEnabled: true, quickActionVisibility: {},
    sendingKeys: {}, toastWrap: null, recentsWriteChain: Promise.resolve(), previewCache: new Map(), previewToken: 0,
    previewDebounceTimer: null, previewCurrentKey: null, repositionScheduled: false, pulseTimer: 0, pulseCount: 0,
    observedFooter: null, footerResizeObserver: null, observedMain: null, observer: null, mutationDebounceTimer: 0, storageOff: null, runtimeActive: false, lifecycleBound: false,
    rootObserver: null, observedRoot: null, rootMutationTimer: 0, storageRetryTimer: 0, storageRetryAttempt: 0,
    missingAnchorRetryTimer: 0, missingAnchorAttempts: 0, lastComposeSeenAt: 0
  };
  function findComposeFooter() {
    return typeof window.__extFindComposeAnchor === "function" ? window.__extFindComposeAnchor() : null;
  }


  function extQiGetMany(keys) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.getMany(keys);
  }
  function extQiGet(key) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.get(key);
  }
  function extQiSet(key, value) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.set(key, value);
  }

  function onAnyQuickItemsKeyChange(fn) {
    if (!window.ExtensionStorage || typeof window.ExtensionStorage.subscribe !== "function") throw new Error("Serviço de armazenamento indisponível");
    return window.ExtensionStorage.subscribe("*", function (newValue, oldValue, key) { try { fn(key, newValue); } catch (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("QUICK_SHELF_SYNC_CALLBACK_FAILED", err); } });
  }


  function extQiIsContextInvalidatedError(err) {
    var msg = (err && err.message) || String(err || "");
    return /extension context invalidated/i.test(msg);
  }
  function extQiShowContextInvalidatedBanner() {
    if (document.getElementById("extuiContextInvalidatedBanner")) return;
    var banner = document.createElement("div");
    banner.id = "extuiContextInvalidatedBanner";
    banner.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#c22e44;color:#fff;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-size:13.5px;padding:10px 16px;display:flex;align-items:center;justify-content:center;gap:14px;box-shadow:0 2px 10px rgba(0,0,0,.3);";
    var text = document.createElement("span");
    text.textContent = "A extensão foi atualizada — recarregue esta aba do WhatsApp Web para concluir a atualização.";
    var reload = document.createElement("button");
    reload.type = "button";
    reload.textContent = "Recarregar agora";
    reload.style.cssText = "background:#fff;color:#c22e44;border:none;border-radius:6px;padding:8px 14px;font-weight:700;font-size:14px;cursor:pointer;flex-shrink:0;";
    reload.addEventListener("click", function () { location.reload(); });
    banner.appendChild(text); banner.appendChild(reload); document.body.appendChild(banner);
  }

  var QUICK_ITEM_TYPES = [
    { type: "message", key: "EXTUI:textMessageStore", listField: "textMessageList", label: "Mensagem", accent: "#ec4899", icon: '<path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"/>' },
    { type: "audio", key: "EXTUI:audioStore", listField: "audioList", label: "Áudio", accent: "#14b8a6", icon: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2"/><path d="M12 19v3"/>' },
    { type: "media", key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem/Vídeo (legado)", accent: "#84cc16", loaderOnly: true, icon: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="m21 16-4.5-4.5a2 2 0 0 0-2.8 0L5 20"/>' },
    { type: "image", key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem", accent: "#84cc16", virtualMediaKind: "image", icon: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="m21 16-4.5-4.5a2 2 0 0 0-2.8 0L5 20"/>' },
    { type: "video", key: "EXTUI:mediaStore", listField: "mediaList", label: "Vídeo", accent: "#3b82f6", virtualMediaKind: "video", icon: '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-2v8l-4-2z"/>' },
    { type: "sticker", key: "EXTUI:stickerStore", listField: "stickerList", label: "Figurinha", accent: "#f59e0b", icon: '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>' },
    { type: "document", key: "EXTUI:documentStore", listField: "documentList", label: "Documento", accent: "#f59e0b", icon: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>' },
    { type: "pix", key: "EXTUI:pixStore", listField: "pixList", label: "PIX", accent: "#32bcad", icon: '<path d="m12 3 3 3-3 3-3-3z"/><path d="m12 15 3 3-3 3-3-3z"/><path d="m3 12 3-3 3 3-3 3z"/><path d="m15 12 3-3 3 3-3 3z"/>' },
    { type: "interactive-list", key: "EXTUI:interactiveListStore", listField: "interactiveListList", label: "Lista", accent: "#06b6d4", icon: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3" cy="6" r="1"/><circle cx="3" cy="12" r="1"/><circle cx="3" cy="18" r="1"/>' },
    { type: "contact", key: "EXTUI:contactCardStore", listField: "contactList", label: "Contato", accent: "#6366f1", icon: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>' },
    { type: "signature", key: "EXTUI:signaturesStore", listField: "list", label: "Assinatura", accent: "#a78bfa", plainList: true, icon: '<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h5M8 16h8"/>' },
    { type: "flow", key: "EXTUI:extappFlowStore", listField: "flowList", label: "Fluxo", accent: "#fb923c", icon: '<rect width="8" height="8" x="3" y="3" rx="2"/><path d="M7 11v4a2 2 0 0 0 2 2h4"/><rect width="8" height="8" x="13" y="13" rx="2"/>' },
    { type: "funnel", key: "EXTUI:extappFunnelStore", listField: "funnelList", label: "Funil", accent: "#f43f5e", icon: '<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>' }
  ];
  var QUICK_ITEM_TYPE_BY_TYPE = {};
  QUICK_ITEM_TYPES.forEach(function (cfg) { QUICK_ITEM_TYPE_BY_TYPE[cfg.type] = cfg; });
  var QUICK_ITEM_KEY_TO_TYPE = {};
  QUICK_ITEM_TYPES.forEach(function (cfg) { QUICK_ITEM_KEY_TO_TYPE[cfg.key] = cfg.type; });
  var QUICK_LIBRARY_FILTERS = [
    { type:"message", label:"Mensagens" },{ type:"audio", label:"Áudios" },{ type:"image", label:"Imagens" },{ type:"video", label:"Vídeos" },{ type:"sticker", label:"Figurinhas" },{ type:"document", label:"Documentos" },{ type:"pix", label:"PIX" },{ type:"interactive-list", label:"Listas" },{ type:"contact", label:"Contatos" },{ type:"signature", label:"Assinaturas" },{ type:"flow", label:"Fluxos" },{ type:"funnel", label:"Funis" }
  ];

  function parsePersisted(raw) {
    if (!raw) return null;
    try {
      var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
      return (parsed && parsed.state) ? parsed.state : null;
    } catch (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("QUICK_SHELF_PERSISTED_STATE_INVALID", err); return null; }
  }


  var EXTUI_QI_COMBINING_MARKS_RE = new RegExp("[" + String.fromCharCode(768) + "-" + String.fromCharCode(879) + "]", "g");
  function extQiNormalizeForSearch(s) {
    return String(s || "").normalize("NFD").replace(EXTUI_QI_COMBINING_MARKS_RE, "").toLowerCase();
  }


  function normalizeQuickItem(type, raw) {
    var cfg = QUICK_ITEM_TYPE_BY_TYPE[type];
    var title = ((raw.name||raw.title) && String(raw.name||raw.title).trim()) || "(sem nome)";
    return {
      id: raw.id,
      type: type,
      title: title,
      subtitle: cfg.label,
      isFavorite: !!(raw.favorite || raw.isFavorite),
      raw: raw,
      searchTitle: extQiNormalizeForSearch(title),
      searchSubtitle: extQiNormalizeForSearch(cfg.label)
    };
  }

  var QUICK_ITEM_STORE_KEYS = Array.from(new Set(QUICK_ITEM_TYPES.map(function (cfg) { return cfg.key; })));


  var RECENTS_KEY = "EXTUI:quickItemsRecents";
  var RECENTS_MAX = 10;


  var OPTIONS_KEY = "EXTUI:extappOptionsStore";

  function quickMediaKind(item, content) {
    var kind=String(item&&item.mediaKind||content&&content.mediaKind||"").toLowerCase();
    if(kind==="image"||kind==="video")return kind;
    var mime=String(content&&content.mimeType||"").toLowerCase(),name=String(content&&content.fileName||item&&item.name||"").toLowerCase();
    if(mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name))return "video";
    return "image";
  }

  async function loadAllQuickItems() {
    var results = [];
    var byKey;
    try {
      byKey = await extQiGetMany(QUICK_ITEM_STORE_KEYS.concat([RECENTS_KEY, OPTIONS_KEY]));
    } catch (err) {
      quickShelfRuntime.cacheLoadFailed = true;
      quickShelfRuntime.cacheLastError = err;
      return results;
    }
    for (var ci=0; ci<QUICK_ITEM_TYPES.length; ci++) {
      var cfg=QUICK_ITEM_TYPES[ci];
      if (cfg.virtualMediaKind) continue;
      var list=[];
      if(cfg.type==="signature"&&window.ExtensionSignatureStore&&typeof window.ExtensionSignatureStore.list==="function"){
        try{list=await window.ExtensionSignatureStore.list();}catch(signatureError){quickShelfRuntime.cacheLoadFailed=true;quickShelfRuntime.cacheLastError=signatureError;return results;}
      }else{var rawStore=byKey[cfg.key],state=cfg.plainList?(typeof rawStore==="string"?(function(){try{return JSON.parse(rawStore);}catch(_){return null;}})():rawStore):parsePersisted(rawStore);list=(state&&Array.isArray(state[cfg.listField]))?state[cfg.listField]:[];}
      for (var li=0; li<list.length; li++) {
        var item=list[li]; if(!item||!item.id)continue;if(cfg.type==="signature"&&item.showInQuickMenu===false)continue;
        var type=cfg.type;
        if(type==="media"){var content=null;if(item.mediaKind!=="image"&&item.mediaKind!=="video"){try{content=safeParseMessageContent(await extQiGet(item.id));}catch(_){}}type=quickMediaKind(item,content);}
        results.push(normalizeQuickItem(type,item));
      }
    }
    quickShelfRuntime.recents = Array.isArray(byKey[RECENTS_KEY]) ? byKey[RECENTS_KEY] : [];
    applyOptionsPayload(byKey[OPTIONS_KEY]);
    return results;
  }

  var POPOVER_ID = "extapp-quick-items-popover-root";
  var POPOVER_GAP = 8;

  function syncQuickActionWorkspaceState(dock) {
    dock = dock || document.getElementById(QUICK_ACTION_DOCK_ID);
    if (!dock) return;
    var workspace = typeof window.__extGetActiveChatWorkspaceKey === "function"
      ? String(window.__extGetActiveChatWorkspaceKey() || "")
      : "";
    var activeCommand = {
      client: "client.open",
      crm: "crm.open",
      orders: "orders.open",
      notes: "note.open",
      agenda: "agenda.open",
      labels: "labels.open",
      "quick-responses": "quick-response.open"
    }[workspace] || "";
    Array.prototype.forEach.call(dock.querySelectorAll(".extuiChatQuickActionBtn[data-command]"), function (button) {
      if (button.getAttribute("data-command") === "quick-items.open") return;
      var active = !!activeCommand && button.getAttribute("data-command") === activeCommand;
      button.classList.toggle("is-workspace-active", active);
      button.setAttribute("aria-pressed", String(active));
    });
  }

  function buildQuickActionDock() {
    var existing = document.getElementById(QUICK_ACTION_DOCK_ID);
    if (existing) return existing;
    var dock = document.createElement("div");
    dock.id = QUICK_ACTION_DOCK_ID;
    dock.className = "extuiChatQuickActionDock";
    dock.setAttribute("role", "toolbar");
    dock.setAttribute("aria-label", "Ações rápidas da conversa");
    var defs = [
      { command: "client.open", label: "Cliente", title: "Cliente", accent: "#00a884", icon: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>' },
      { command: "crm.open", label: "CRM", title: "CRM do contato", accent: "#00a884", icon: '<path d="M5 3v14"/><path d="M12 3v8"/><path d="M19 3v18"/>' },
      { command: "orders.open", label: "Encomendas", title: "Encomendas do contato", accent: "#f59e0b", icon: '<path d="M6 7h12l-1 14H7L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/><path d="M9 11h6"/>' },
      { command: "note.open", label: "Notas", title: "Notas do contato", accent: "#e85b9e", icon: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h6"/>' },
      { command: "agenda.open", label: "Agenda", title: "Agenda do contato", accent: "#4f8df7", icon: '<path d="M8 2v3M16 2v3"/><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18"/>' },
      { command: "labels.open", label: "Etiquetas", title: "Etiquetas do contato", accent: "#f3a31b", icon: '<path d="M20.59 13.41 11 3.83V3H4v7h.83l9.58 9.59a2 2 0 0 0 2.82 0l3.36-3.36a2 2 0 0 0 0-2.82Z"/><circle cx="7.5" cy="6.5" r="1"/><path d="m15 14 1.5 1.5L19 13"/>' },
      { command: "quick-response.open", label: "Respostas Rápidas", title: "Respostas Rápidas", accent: "#a855f7", icon: '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="m8 9 1.5 1.5L12 8"/><path d="M14 12h3"/>' },
      { command: "quick-items.open", label: "Itens Rápidos", title: "Itens Rápidos", accent: "#00e676", icon: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>' }
    ];
    defs.forEach(function (def) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "extuiChatQuickActionBtn";
      btn.setAttribute("data-command", def.command);
      btn.setAttribute("data-label", def.label);
      btn.style.setProperty("--extui-quick-accent", def.accent || "#00a884");
      btn.setAttribute("aria-label", def.title);
      btn.setAttribute("aria-pressed", "false");
      if(def.command==="quick-items.open"){btn.setAttribute("aria-haspopup","dialog");btn.setAttribute("aria-expanded","false");btn.setAttribute("aria-controls",POPOVER_ID);}
      btn.title = def.title;
      btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + def.icon + '</svg>';
      btn.addEventListener("click", function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        if(def.command==="quick-items.open"){togglePopover(btn);return;}
        if (!window.ExtensionCore || !window.ExtensionCore.CommandHost || typeof window.ExtensionCore.CommandHost.execute !== "function") {
          showQuickItemsToast("Ação indisponível nesta aba.", "error");
          return;
        }
        if (btn.getAttribute("data-command-pending") === "1") return;
        btn.setAttribute("data-command-pending", "1");
        btn.setAttribute("aria-busy", "true");
        Promise.resolve(window.ExtensionCore.CommandHost.execute(def.command, { source: "chat-quick-actions" })).catch(function (err) {
          showQuickItemsToast(err && err.message ? err.message : "Não foi possível abrir a ação.", "error");
        }).finally(function () { btn.removeAttribute("data-command-pending"); btn.removeAttribute("aria-busy"); });
      });
      dock.appendChild(btn);
    });
    applyQuickActionVisibility(dock);
    document.body.appendChild(dock);
    syncQuickActionWorkspaceState(dock);
    return dock;
  }



  var popover = null;
  var popoverOpen = false;
  var _focusBeforePopover = null;

  function quickItemsRailButtonMarkup(filter) {
    var cfg=QUICK_ITEM_TYPE_BY_TYPE[filter.type]||{};
    return '<button type="button" class="extuiQuickItemsRailBtn" data-filter="'+filter.type+'" role="tab" aria-selected="false" tabindex="-1" aria-controls="extuiQuickItemsTabPanel">' +
      '<span class="extuiQuickItemsRailIcon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+(cfg.icon||'')+'</svg></span>' +
      '<span class="extuiQuickItemsRailLabel">'+filter.label+'</span></button>';
  }

  function quickItemsActiveFilter(){
    var type=String(quickShelfRuntime.activeCategoryType||"all");
    return type==="all"?"":type;
  }

  function quickItemsActiveLabel(){
    var type=quickItemsActiveFilter();
    if(!type)return "Todos";
    var match=QUICK_LIBRARY_FILTERS.find(function(x){return x.type===type;});
    return match?match.label:"Itens";
  }

  function quickItemMatchesActiveCategory(item){
    if(!item)return false;
    var type=String(quickShelfRuntime.activeCategoryType||"all");
    return type==="all"||item.type===type;
  }

  function setQuickItemsActiveCategory(type){
    type=String(type||"all");
    var valid=type==="all"||QUICK_LIBRARY_FILTERS.some(function(filter){return filter.type===type;});
    quickShelfRuntime.activeCategoryType=valid?type:"all";
    quickShelfRuntime.activeIndex=-1;
    quickShelfRuntime.currentResultPairs=[];
    if(popover){
      var body=popover.querySelector(".extuiQuickItemsPopoverBody");
      if(body)body.scrollTop=0;
    }
  }

  function quickItemsSearchPlaceholder(){
    var type=quickItemsActiveFilter();
    if(!type)return quickShelfRuntime.onlyFavorites?"Buscar favoritos...":"Buscar itens...";
    var nouns={message:"mensagens",audio:"áudios",image:"imagens",video:"vídeos",sticker:"figurinhas",document:"documentos",pix:"PIX","interactive-list":"listas",contact:"contatos",signature:"assinaturas",flow:"fluxos",funnel:"funis"};
    return "Buscar "+(nouns[type]||"itens")+"...";
  }

  function quickItemsCountLabel(count){
    count=Number(count)||0;
    var type=quickItemsActiveFilter();
    if(!type)return count+" "+(count===1?"item":"itens");
    var nouns={message:["mensagem","mensagens"],audio:["áudio","áudios"],image:["imagem","imagens"],video:["vídeo","vídeos"],sticker:["figurinha","figurinhas"],document:["documento","documentos"],pix:["PIX","PIX"],"interactive-list":["lista","listas"],contact:["contato","contatos"],signature:["assinatura","assinaturas"],flow:["fluxo","fluxos"],funnel:["funil","funis"]};
    var pair=nouns[type]||["item","itens"];
    return count+" "+(count===1?pair[0]:pair[1]);
  }

  function updateQuickItemsMainMeta(count){
    if(!popover)return;
    var title=popover.querySelector(".extuiQuickItemsMainTitle"),subtitle=popover.querySelector(".extuiQuickItemsMainSubtitle"),input=popover.querySelector(".extuiQuickItemsSearchInput");
    if(title)title.textContent=quickItemsActiveLabel();
    if(subtitle)subtitle.textContent=typeof count==="number"?quickItemsCountLabel(count):"";
    if(input){var placeholder=quickItemsSearchPlaceholder();input.setAttribute("placeholder",placeholder);input.setAttribute("aria-label",placeholder.replace(/\.\.\.$/,""));}
  }


  function buildPopover() {
    var existing = document.getElementById(POPOVER_ID);
    if (existing) return existing;
    var el = document.createElement("div");
    el.id = POPOVER_ID;
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-label", "Itens rápidos");
    el.setAttribute("tabindex", "-1");
    el.innerHTML =
      '<div class="extuiQuickItemsPopoverHeader">' +
      '  <span class="extuiQuickItemsPopoverTitle">Itens rápidos</span>' +
      '  <button type="button" class="extuiQuickItemsPopoverClose" aria-label="Fechar">' +
      '    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>' +
      '  </button>' +
      '</div>' +
      '<div class="extuiQuickItemsWorkspace">' +
      '  <nav class="extuiQuickItemsRail" aria-label="Categorias de Itens Rápidos">' +
      '    <div class="extuiQuickItemsRailList" role="tablist" aria-label="Categorias">' +
      '      <button type="button" class="extuiQuickItemsRailBtn" data-filter="all" role="tab" aria-selected="true" tabindex="0" aria-controls="extuiQuickItemsTabPanel"><span class="extuiQuickItemsRailIcon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg></span><span class="extuiQuickItemsRailLabel">Todos</span></button>' +
      QUICK_LIBRARY_FILTERS.map(quickItemsRailButtonMarkup).join('') +
      '    </div>' +
      '    <button type="button" class="extuiQuickItemsRailBtn extuiQuickItemsRailBtn--favorites" data-filter="favorites" aria-pressed="false" title="Quando ligado, serão mostrados apenas os itens favoritos da aba atual; em Todos, de todas as categorias."><span class="extuiQuickItemsRailIcon" aria-hidden="true">★</span><span class="extuiQuickItemsRailLabel">Favoritos</span></button>' +
      '  </nav>' +
      '  <section class="extuiQuickItemsMain" id="extuiQuickItemsTabPanel" role="tabpanel" aria-label="Itens filtrados">' +
      '    <div class="extuiQuickItemsMainHead">' +
      '      <div class="extuiQuickItemsMainMeta"><strong class="extuiQuickItemsMainTitle">Todos</strong><span class="extuiQuickItemsMainSubtitle"></span></div>' +
      '      <div class="extuiQuickItemsSearchRow extuiQuickItemsMainSearch">' +
      '        <span class="extuiQuickItemsSearchIcon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg></span>' +
      '        <input type="text" class="extuiQuickItemsSearchInput" placeholder="Buscar itens..." aria-label="Buscar itens" autocomplete="off" spellcheck="false" />' +
      '        <button type="button" class="extuiQuickItemsSearchClearBtn" aria-label="Limpar busca" style="display:none;">' +
      '          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>' +
      '        </button>' +
      '      </div>' +
      '    </div>' +
      '    <div class="extuiQuickItemsPopoverBody"></div>' +
      '  </section>' +
      '</div>';
    el.querySelector(".extuiQuickItemsPopoverClose").addEventListener("click", function (ev) {
      ev.stopPropagation();
      closePopover();
    });
    var searchInput = el.querySelector(".extuiQuickItemsSearchInput");
    var searchClearBtn = el.querySelector(".extuiQuickItemsSearchClearBtn");


    searchInput.addEventListener("input", function () {
      quickShelfRuntime.searchQuery = searchInput.value;
      searchClearBtn.style.display = quickShelfRuntime.searchQuery ? "" : "none";
      renderPopoverFromCache();
    });
    searchClearBtn.addEventListener("click", function (ev) {
      ev.stopPropagation();
      clearQuickItemsSearch();
      searchInput.focus();
    });
    Array.prototype.forEach.call(el.querySelectorAll(".extuiQuickItemsRailBtn"),function(button){button.addEventListener("click",function(ev){ev.stopPropagation();var filter=button.getAttribute("data-filter");if(filter==="favorites")quickShelfRuntime.onlyFavorites=!quickShelfRuntime.onlyFavorites;else setQuickItemsActiveCategory(filter);syncQuickItemsFilterUi();renderPopoverFromCache();});});
    var tablist=el.querySelector(".extuiQuickItemsRailList");
    tablist.addEventListener("keydown",function(ev){if(["ArrowDown","ArrowUp","Home","End"].indexOf(ev.key)<0)return;var tabs=Array.prototype.slice.call(tablist.querySelectorAll('[role="tab"]')),current=tabs.indexOf(document.activeElement);if(current<0)return;ev.preventDefault();var next=ev.key==="Home"?0:ev.key==="End"?tabs.length-1:(current+(ev.key==="ArrowDown"?1:-1)+tabs.length)%tabs.length;tabs[next].focus();tabs[next].click();});
    document.body.appendChild(el);
    return el;
  }


  function getPopoverAnchorRect() {
    if (quickShelfRuntime.externalAnchorEl && document.body.contains(quickShelfRuntime.externalAnchorEl)) return quickShelfRuntime.externalAnchorEl.getBoundingClientRect();
    return null;
  }

  function setTriggersExpanded(expanded) {
    if(quickShelfRuntime.externalAnchorEl&&document.body.contains(quickShelfRuntime.externalAnchorEl))quickShelfRuntime.externalAnchorEl.setAttribute("aria-expanded",String(expanded));
  }
  function syncQuickItemsFilterUi(){if(!popover)return;var active=String(quickShelfRuntime.activeCategoryType||"all");Array.prototype.forEach.call(popover.querySelectorAll(".extuiQuickItemsRailBtn"),function(button){var filter=button.getAttribute("data-filter"),on=filter==="favorites"?quickShelfRuntime.onlyFavorites:active===filter;button.classList.toggle("is-active",on);if(filter==="favorites")button.setAttribute("aria-pressed",String(on));else{button.setAttribute("aria-selected",String(on));button.setAttribute("tabindex",on?"0":"-1");}});updateQuickItemsMainMeta();}
  function syncQuickItemsDockState(){var button=document.querySelector('#'+QUICK_ACTION_DOCK_ID+' .extuiChatQuickActionBtn[data-command="quick-items.open"]');if(!button)return;button.classList.toggle("is-workspace-active",!!popoverOpen);button.setAttribute("aria-pressed",String(!!popoverOpen));button.setAttribute("aria-expanded",String(!!popoverOpen));}



  function computeQuickItemsPopoverPlacement(anchorRect,popRect,chatBounds,viewportWidth,viewportHeight) {
    var usableLeft = Math.max(VIEWPORT_MARGIN, chatBounds.left + VIEWPORT_MARGIN);
    var usableRight = Math.min(viewportWidth - VIEWPORT_MARGIN, chatBounds.right - VIEWPORT_MARGIN);
    if (usableRight <= usableLeft) { usableLeft = VIEWPORT_MARGIN; usableRight = viewportWidth - VIEWPORT_MARGIN; }
    var spaceLeft = anchorRect.left - POPOVER_GAP - usableLeft;
    var spaceRight = usableRight - anchorRect.right - POPOVER_GAP;
    var fitsLeft = spaceLeft >= popRect.width, fitsRight = spaceRight >= popRect.width;
    var maxLeft = Math.max(usableLeft, usableRight - popRect.width);
    if (fitsLeft || fitsRight) {
      var placeLeft = fitsLeft && (!fitsRight || spaceLeft >= spaceRight);
      var left = placeLeft ? anchorRect.left - popRect.width - POPOVER_GAP : anchorRect.right + POPOVER_GAP;
      left = clamp(left, usableLeft, maxLeft);
      var top = clamp(anchorRect.top - 6, VIEWPORT_MARGIN, viewportHeight - popRect.height - VIEWPORT_MARGIN);
      return {left:left,top:top,side:placeLeft?"left":"right"};
    }
    /* Narrow chat: when neither lateral side fits, use a vertical slot with
       the same 8px separation instead of clamping the panel through the dock. */
    var aboveSpace = Math.max(0, anchorRect.top - POPOVER_GAP - VIEWPORT_MARGIN);
    var belowSpace = Math.max(0, viewportHeight - VIEWPORT_MARGIN - anchorRect.bottom - POPOVER_GAP);
    var placeAbove = aboveSpace >= popRect.height || (aboveSpace >= belowSpace && belowSpace < popRect.height);
    var maxHeight = Math.max(0, placeAbove ? aboveSpace : belowSpace);
    var effectiveHeight = Math.min(popRect.height, maxHeight);
    var anchorWidth = Number(anchorRect.width) || Math.max(0, anchorRect.right-anchorRect.left);
    var centeredLeft = anchorRect.left + (anchorWidth - popRect.width) / 2;
    var verticalLeft = clamp(centeredLeft, usableLeft, maxLeft);
    var verticalTop = placeAbove ? anchorRect.top - POPOVER_GAP - effectiveHeight : anchorRect.bottom + POPOVER_GAP;
    verticalTop = clamp(verticalTop, VIEWPORT_MARGIN, Math.max(VIEWPORT_MARGIN, viewportHeight - effectiveHeight - VIEWPORT_MARGIN));
    return {left:verticalLeft,top:verticalTop,side:placeAbove?"above":"below",maxHeight:maxHeight};
  }

  function positionPopover() {
    if (!popover) return;
    var anchorRect = getPopoverAnchorRect();
    if (!anchorRect) return;

    popover.style.maxHeight = "";
    var popRect = popover.getBoundingClientRect();
    var maxAvailableHeight = Math.max(120, window.innerHeight - VIEWPORT_MARGIN * 2);
    if (popRect.height > maxAvailableHeight) {
      popover.style.maxHeight = maxAvailableHeight + "px";
      popRect = popover.getBoundingClientRect();
    }

    /* The popover is a lateral companion of the vertical Menu Rápido dock.
       Anchor it beside the trigger instead of above/below it so the two
       surfaces never stack on top of each other. */
    var footer = findComposeFooter();
    var main = document.getElementById("main");
    var boundsRect = footer && footer.getBoundingClientRect ? footer.getBoundingClientRect()
      : (main && main.getBoundingClientRect ? main.getBoundingClientRect() : { left: 0, right: window.innerWidth });
    var chatBounds = getEffectiveChatBounds(boundsRect);
    /* Keep the header visually close to the trigger. If the panel would
       leave the viewport, slide it vertically without changing the lateral gap. */
    var placement = computeQuickItemsPopoverPlacement(anchorRect,popRect,chatBounds,window.innerWidth,window.innerHeight);
    if ((placement.side === "above" || placement.side === "below") && placement.maxHeight > 0 && popRect.height > placement.maxHeight) {
      popover.style.maxHeight = Math.max(1, placement.maxHeight) + "px";
      popRect = popover.getBoundingClientRect();
      placement = computeQuickItemsPopoverPlacement(anchorRect,popRect,chatBounds,window.innerWidth,window.innerHeight);
    }
    popover.style.top = placement.top + "px";
    popover.style.left = placement.left + "px";
  }


  function clearQuickItemsSearch() {
    quickShelfRuntime.searchQuery = "";
    if (popover) {
      var input = popover.querySelector(".extuiQuickItemsSearchInput");
      var clearBtn = popover.querySelector(".extuiQuickItemsSearchClearBtn");
      if (input) input.value = "";
      if (clearBtn) clearBtn.style.display = "none";
    }
    renderPopoverFromCache();
  }


  function moveActiveIndex(delta) {
    var len = quickShelfRuntime.currentResultPairs.length;
    if (!len) return;
    quickShelfRuntime.activeIndex = quickShelfRuntime.activeIndex === -1
      ? (delta > 0 ? 0 : len - 1)
      : (quickShelfRuntime.activeIndex + delta + len) % len;
    applyActiveIndexHighlight();
  }


  function applyActiveIndexHighlight() {
    if (!popover) return;
    var body = popover.querySelector(".extuiQuickItemsPopoverBody");
    if (!body) return;
    var rows = body.querySelectorAll(".extuiQuickItemsRow[data-result-index]");
    for (var i = 0; i < rows.length; i++) {
      var active = Number(rows[i].getAttribute("data-result-index")) === quickShelfRuntime.activeIndex;
      rows[i].classList.toggle("extuiQiActiveResult", active);
      if (active) rows[i].scrollIntoView({ block: "nearest" });
    }


    schedulePreviewUpdate();
  }


  function sendActiveResult() {
    if (quickShelfRuntime.activeIndex < 0 || quickShelfRuntime.activeIndex >= quickShelfRuntime.currentResultPairs.length) return;
    handleQuickItemSend(quickShelfRuntime.currentResultPairs[quickShelfRuntime.activeIndex].item);
  }

  function onPopoverKeydown(ev) {
    if (ev.key === "Escape") {
      ev.stopPropagation();


      if (quickShelfRuntime.searchQuery) {
        clearQuickItemsSearch();
        var input = popover && popover.querySelector(".extuiQuickItemsSearchInput");
        if (input) input.focus();
      } else {
        closePopover();
      }
      return;
    }
    if (ev.target && ev.target.closest && ev.target.closest("button,summary")) return;
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      moveActiveIndex(1);
      return;
    }
    if (ev.key === "ArrowUp") {
      ev.preventDefault();
      moveActiveIndex(-1);
      return;
    }
    if (ev.key === "Enter") {
      ev.preventDefault();
      sendActiveResult();
      return;
    }
  }
  function onOutsidePointerDown(ev) {
    if (popover && popover.contains(ev.target)) return;
    if (quickShelfRuntime.externalAnchorEl && quickShelfRuntime.externalAnchorEl.contains(ev.target)) return;
    closePopover();
  }

  function openPopover(externalAnchorEl) {
    quickShelfRuntime.externalAnchorEl = externalAnchorEl || null;
    if (!getPopoverAnchorRect()) return;
    if (!popover) popover = buildPopover();
    popoverOpen = true;
    popover.style.display = "flex";
    quickShelfRuntime.onlyFavorites = quickShelfRuntime.defaultOnlyFavorites;
    quickShelfRuntime.activeCategoryType = "all";
    syncQuickItemsFilterUi();
    syncQuickItemsDockState();


    quickShelfRuntime.searchQuery = "";
    quickShelfRuntime.activeIndex = -1;
    var searchInput = popover.querySelector(".extuiQuickItemsSearchInput");
    var searchClearBtn = popover.querySelector(".extuiQuickItemsSearchClearBtn");
    if (searchInput) searchInput.value = "";
    if (searchClearBtn) searchClearBtn.style.display = "none";


    renderPopoverFromCache();
    positionPopover();
    setTriggersExpanded(true);
    _focusBeforePopover = document.activeElement;
    if (searchInput) searchInput.focus(); else popover.focus();
    document.addEventListener("keydown", onPopoverKeydown, true);
    document.addEventListener("pointerdown", onOutsidePointerDown, true);
  }

  function closePopover() {
    if (!popoverOpen) return;
    popoverOpen = false;
    if (popover) popover.style.display = "none";
    setTriggersExpanded(false);
    syncQuickItemsDockState();
    quickShelfRuntime.externalAnchorEl = null;
    document.removeEventListener("keydown", onPopoverKeydown, true);
    document.removeEventListener("pointerdown", onOutsidePointerDown, true);


    hidePreview();
    quickShelfRuntime.previewCache.clear();


    if (_focusBeforePopover && document.body.contains(_focusBeforePopover) && typeof _focusBeforePopover.focus === "function") {
      _focusBeforePopover.focus();
    }
    _focusBeforePopover = null;
    scheduleReposition();
  }

  function togglePopover(externalAnchorEl) {
    if (popoverOpen) closePopover(); else openPopover(externalAnchorEl);
  }









  function quickActionIsVisible(command){return quickShelfRuntime.quickActionVisibility[String(command||"")]!==false;}
  function applyQuickActionVisibility(dock){dock=dock||document.getElementById(QUICK_ACTION_DOCK_ID);if(!dock)return;Array.prototype.forEach.call(dock.querySelectorAll(".extuiChatQuickActionBtn[data-command]"),function(button){var on=quickActionIsVisible(button.getAttribute("data-command"));button.hidden=!on;button.style.display=on?"grid":"none";button.setAttribute("aria-hidden",String(!on));});}
  function quickCommandWorkspaceKey(command){return {"client.open":"client","crm.open":"crm","orders.open":"orders","note.open":"notes","agenda.open":"agenda","labels.open":"labels","quick-response.open":"quick-responses"}[String(command||"")]||"";}
  function applyOptionsPayload(raw) {
    var opts = null;
    if (raw) {
      try { opts = typeof raw === "string" ? JSON.parse(raw) : raw; } catch (err) { opts = null; }
    }
    quickShelfRuntime.quickShelfEnabled = !(opts && opts.quickShelfEnabled === false);
    quickShelfRuntime.defaultOnlyFavorites = !!(opts && opts.showOnlyFavoritesOnItemsBar === true);
    quickShelfRuntime.quickActionVisibility = opts && opts.quickShelfVisibility && typeof opts.quickShelfVisibility === "object" ? Object.assign({},opts.quickShelfVisibility) : {};
    if(!Object.prototype.hasOwnProperty.call(quickShelfRuntime.quickActionVisibility,"quick-items.open")&&opts&&opts.hideItemsBar===true)quickShelfRuntime.quickActionVisibility["quick-items.open"]=false;
    applyQuickActionVisibility();
    var active=typeof window.__extGetActiveChatWorkspaceKey==="function"?String(window.__extGetActiveChatWorkspaceKey()||""):"";
    if(active){var known=["client.open","crm.open","orders.open","note.open","agenda.open","labels.open","quick-response.open"];var activeVisible=known.some(function(cmd){return quickCommandWorkspaceKey(cmd)===active&&quickActionIsVisible(cmd);});if(known.some(function(cmd){return quickCommandWorkspaceKey(cmd)===active;})&&(!quickShelfRuntime.quickShelfEnabled||!activeVisible)){try{if(typeof window.__extCloseChatWorkspace==="function")window.__extCloseChatWorkspace();}catch(_){}}}
  }


  function sortForDisplay(items) {
    var favs = [], recentsExclFav = [], rest = [];
    var used = {};
    items.forEach(function (i) {
      if (i.isFavorite) { favs.push(i); used[quickItemKey(i)] = true; }
    });
    quickShelfRuntime.recents.forEach(function (r) {
      var key = r.type + ":" + r.id;
      if (used[key]) return;
      var match = findCachedItem(r.type, r.id);
      if (!match) return;
      recentsExclFav.push(match);
      used[key] = true;
    });
    items.forEach(function (i) {
      var key = quickItemKey(i);
      if (used[key]) return;
      rest.push(i);
    });
    return favs.concat(recentsExclFav, rest);
  }

  function findCachedItem(type, id) {
    for (var i = 0; i < quickShelfRuntime.itemsCache.length; i++) {
      if (quickShelfRuntime.itemsCache[i].type === type && quickShelfRuntime.itemsCache[i].id === id) return quickShelfRuntime.itemsCache[i];
    }
    return null;
  }


  function extQiFuzzyScore(query, text) {
    if (!query) return null;
    var idx = text.indexOf(query);
    if (idx === 0) return { tier: 0, index: 0, span: query.length, matches: extQiRange(0, query.length) };
    if (idx !== -1) return { tier: 1, index: idx, span: query.length, matches: extQiRange(idx, idx + query.length) };
    var matches = [];
    var ti = 0;
    for (var qi = 0; qi < query.length; qi++) {
      var found = -1;
      for (; ti < text.length; ti++) {
        if (text[ti] === query[qi]) { found = ti; ti++; break; }
      }
      if (found === -1) return null;
      matches.push(found);
    }
    return { tier: 2, index: matches[0], span: matches[matches.length - 1] - matches[0] + 1, matches: matches };
  }
  function extQiRange(start, end) { var a = []; for (var i = start; i < end; i++) a.push(i); return a; }


  function extQiBuildHighlightedLabel(label, matchedIndices) {
    var frag = document.createDocumentFragment();
    var matchSet = {};
    (matchedIndices || []).forEach(function (i) { matchSet[i] = true; });
    for (var i = 0; i < label.length; i++) {
      if (matchSet[i]) {
        var b = document.createElement("b");
        b.className = "extuiQuickItemsSearchMatch";
        b.textContent = label[i];
        frag.appendChild(b);
      } else {
        frag.appendChild(document.createTextNode(label[i]));
      }
    }
    return frag;
  }


  function buildQuickItemsViewList(items, query) {
    items=items.filter(quickItemMatchesActiveCategory);
    items=quickShelfRuntime.onlyFavorites?items.filter(function(item){return item&&item.isFavorite;}):items;
    var q = extQiNormalizeForSearch(query).trim();
    if (!q) {
      return sortForDisplay(items).map(function (i) { return { item: i, matches: null }; });
    }
    var favSet = {};
    items.forEach(function (i) { if (i.isFavorite) favSet[quickItemKey(i)] = true; });
    var recentRank = {};
    quickShelfRuntime.recents.forEach(function (r, idx) { recentRank[r.type + ":" + r.id] = idx; });

    var scored = [];
    items.forEach(function (item, origIdx) {
      var titleScore = extQiFuzzyScore(q, item.searchTitle);
      var subtitleScore = !titleScore ? extQiFuzzyScore(q, item.searchSubtitle) : null;
      var s = titleScore ? { field: 0, tier: titleScore.tier, index: titleScore.index, span: titleScore.span, matches: titleScore.matches }
            : subtitleScore ? { field: 1, tier: subtitleScore.tier, index: subtitleScore.index, span: subtitleScore.span, matches: null }
            : null;
      if (!s) return;
      var key = quickItemKey(item);
      scored.push({
        item: item, matches: s.matches, score: s, origIdx: origIdx,
        isFav: !!favSet[key],
        recentRank: recentRank.hasOwnProperty(key) ? recentRank[key] : Infinity
      });
    });
    scored.sort(function (a, b) {
      if (a.score.field !== b.score.field) return a.score.field - b.score.field;
      if (a.score.tier !== b.score.tier) return a.score.tier - b.score.tier;
      if (a.score.index !== b.score.index) return a.score.index - b.score.index;
      if (a.score.span !== b.score.span) return a.score.span - b.score.span;
      if (a.isFav !== b.isFav) return a.isFav ? -1 : 1;
      if (a.recentRank !== b.recentRank) return a.recentRank - b.recentRank;
      return a.origIdx - b.origIdx;
    });
    return scored.map(function (s) { return { item: s.item, matches: s.matches }; });
  }


  function quickItemKey(item) { return item.type + ":" + item.id; }

  function setItemSendState(key, state) {
    var els = document.querySelectorAll(".extuiQuickItemsRow[data-quick-item-key]");
    for (var i = 0; i < els.length; i++) {
      if (els[i].getAttribute("data-quick-item-key") !== key) continue;
      els[i].classList.remove("extuiQiSending", "extuiQiSendSuccess", "extuiQiSendError");
      if (state === "sending") els[i].classList.add("extuiQiSending");
      else if (state === "success") els[i].classList.add("extuiQiSendSuccess");
      else if (state === "error") els[i].classList.add("extuiQiSendError");
    }
  }

  function showQuickItemsToast(msg, variant) {
    if (variant !== "error") { if (typeof window.__extNotify === "function") window.__extNotify(msg, false); return; }
    if (!quickShelfRuntime.toastWrap) { quickShelfRuntime.toastWrap = document.createElement("div"); quickShelfRuntime.toastWrap.className = "extuiToastWrap"; document.body.appendChild(quickShelfRuntime.toastWrap); }
    var t = document.createElement("div"); t.className = "extuiToast extuiToast--error"; t.setAttribute("role","alert"); t.textContent = msg;
    quickShelfRuntime.toastWrap.appendChild(t); setTimeout(function () { t.remove(); }, 4200);
  }


  async function handleQuickItemSend(item, opts) {
    var key = quickItemKey(item);
    if (quickShelfRuntime.sendingKeys[key]) return;
    if (typeof window.__extItemsSendNow !== "function") {
      showQuickItemsToast("Motor de envio indisponível.", "error");
      return;
    }
    quickShelfRuntime.sendingKeys[key] = true;
    setItemSendState(key, "sending");
    var result = false;
    try {
      if(item.type==="signature"){
        if(!window.__extChatCapabilities||typeof window.__extChatCapabilities.invoke!=="function")throw new Error("O recurso de Assinaturas ainda não está disponível.");
        await window.__extChatCapabilities.invoke("signature",{id:item.id,insert:true});
        result=true;
      }else result = await window.__extItemsSendNow(item.type, item.id, { silent: true, skipConfirm: !!(opts && opts.skipConfirm) });
    } catch (err) {
      if (window.__extReportRuntimeError) window.__extReportRuntimeError("QUICK_SHELF_SEND_FAILED", err);
      result = { code: err && err.code || "SEND_FAILED", message: err && err.message || "Não foi possível enviar o item" };
    }
    delete quickShelfRuntime.sendingKeys[key];


    if (result === "cancelled") {
      setItemSendState(key, "idle");
      return;
    }
    var ok = result === true;
    setItemSendState(key, ok ? "success" : "error");
    var failure = !ok && result && typeof result === "object" ? result : null;
    var failureText = failure ? ("Falha [" + (failure.code || "SEND_FAILED") + "]: " + (failure.message || "Não foi possível enviar o item")) : "Não foi possível enviar o item";
    showQuickItemsToast(ok ? (item.title + (item.type==="signature"?" inserida":" enviado")) : failureText, ok ? "success" : "error");
    setTimeout(function () { setItemSendState(key, "idle"); }, 1600);


    if (ok) {
      recordQuickItemRecent(item);
      if (popoverOpen) renderPopoverFromCache();
    }
  }


  function recordQuickItemRecent(item) {
    var key = quickItemKey(item);
    quickShelfRuntime.recents = quickShelfRuntime.recents.filter(function (r) { return (r.type + ":" + r.id) !== key; });
    quickShelfRuntime.recents.unshift({ id: item.id, type: item.type, lastSentAt: Date.now() });
    if (quickShelfRuntime.recents.length > RECENTS_MAX) quickShelfRuntime.recents = quickShelfRuntime.recents.slice(0, RECENTS_MAX);
    var snapshot = quickShelfRuntime.recents;
    quickShelfRuntime.recentsWriteChain = quickShelfRuntime.recentsWriteChain.then(function () {
      return extQiSet(RECENTS_KEY, snapshot).catch(function (err) {
        if (window.__extReportRuntimeError) window.__extReportRuntimeError("QUICK_SHELF_RECENTS_WRITE_FAILED", err);
      });
    });
  }




  async function toggleQuickItemFavorite(item) {
    if(item&&item.type==="signature"&&window.ExtensionSignatureStore){
      try{
        var signature=await window.ExtensionSignatureStore.get(item.id);
        if(!signature){showQuickItemsToast("Item não está mais disponível.","error");return;}
        await window.ExtensionSignatureStore.save({id:signature.id,title:signature.name||signature.title||"Assinatura",text:signature.text||"",favorite:!signature.favorite,showInQuickMenu:signature.showInQuickMenu!==false,createdAt:signature.createdAt});
      }catch(signatureError){showQuickItemsToast("Não foi possível atualizar o favorito.","error");}
      return;
    }
    var cfg = QUICK_ITEM_TYPE_BY_TYPE[item.type];
    var byKey;
    try {
      byKey = await extQiGetMany([cfg.key]);
    } catch (err) {
      showQuickItemsToast("Não foi possível atualizar o favorito.", "error");
      return;
    }
    var rawStore=byKey[cfg.key],state=parsePersisted(rawStore);
    var list = (state && Array.isArray(state[cfg.listField])) ? state[cfg.listField] : [];
    var raw = list.filter(function (r) { return r && r.id === item.id; })[0];
    if (!raw) {
      showQuickItemsToast("Item não está mais disponível.", "error");
      return;
    }
    raw.favorite = !raw.favorite;
    var payload = {};
    payload[cfg.listField] = list;
    try {
      await extQiSet(cfg.key, JSON.stringify({ state: payload, version: 0 }));
    } catch (err) {
      showQuickItemsToast("Não foi possível atualizar o favorito.", "error");
    }
  }

  async function refreshQuickItemsCache() {
    quickShelfRuntime.cacheLoadFailed = false;
    quickShelfRuntime.cacheLastError = null;
    var items = await loadAllQuickItems();
    if (quickShelfRuntime.cacheLoadFailed) {
      quickShelfRuntime.itemsLoaded = false;
      scheduleReposition();
      if (extQiIsContextInvalidatedError(quickShelfRuntime.cacheLastError)) {
        if (quickShelfRuntime.cacheRetryTimer) { clearTimeout(quickShelfRuntime.cacheRetryTimer); quickShelfRuntime.cacheRetryTimer = 0; }
        extQiShowContextInvalidatedBanner();
        return;
      }
      if (!quickShelfRuntime.cacheRetryTimer) {
        var delay = Math.min(5000, 350 * Math.pow(2, Math.min(quickShelfRuntime.cacheRetryAttempt++, 4)));
        quickShelfRuntime.cacheRetryTimer = setTimeout(function () { quickShelfRuntime.cacheRetryTimer = 0; refreshQuickItemsCache().catch(function () {}); }, delay);
      }
      return;
    }
    quickShelfRuntime.cacheRetryAttempt = 0;
    if (quickShelfRuntime.cacheRetryTimer) { clearTimeout(quickShelfRuntime.cacheRetryTimer); quickShelfRuntime.cacheRetryTimer = 0; }
    quickShelfRuntime.itemsCache = items;
    quickShelfRuntime.itemsLoaded = true;
    scheduleReposition();
    if (popoverOpen) renderPopoverFromCache(true);
  }


  window.__extRefreshQuickItemsCache = refreshQuickItemsCache;


  function handleQuickItemsStorageChange(key, newValue) {
    if (key === OPTIONS_KEY) {
      var prevEnabled=quickShelfRuntime.quickShelfEnabled;
      applyOptionsPayload(newValue);
      if ((quickShelfRuntime.quickShelfEnabled!==prevEnabled)||!quickActionIsVisible("quick-items.open")) { if (popoverOpen) closePopover(); }
      scheduleReposition();
      return;
    }
    if (key === RECENTS_KEY) { refreshQuickItemsCache().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_SHELF_CACHE_REFRESH_FAILED",err);}); return; }
    if (!QUICK_ITEM_KEY_TO_TYPE[key]) return;
    refreshQuickItemsCache().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_SHELF_CACHE_REFRESH_FAILED",err);});
  }
  function bindQuickItemsStorage(){if(quickShelfRuntime.storageOff)return;quickShelfRuntime.storageOff=onAnyQuickItemsKeyChange(handleQuickItemsStorageChange);}

  function renderLoadingState(body) {
    body.innerHTML = '<div class="extuiQuickItemsStateMsg">Carregando itens...</div>';
  }


  function renderEmptyState(body, query) {
    var q = query && String(query).trim();
    if (!q) {


      body.innerHTML = '<div class="extuiQuickItemsStateMsg">'+(quickShelfRuntime.onlyFavorites?'Nenhum item favoritado ainda.':'Nenhum item salvo ainda.')+'</div>';
      return;
    }
    body.innerHTML = "";
    var wrap = document.createElement("div");
    wrap.className = "extuiQuickItemsStateMsg";
    var msg = document.createElement("div");
    msg.textContent = 'Nenhum resultado para "' + q + '".';
    wrap.appendChild(msg);
    var clearBtn = document.createElement("button");
    clearBtn.type = "button";
    clearBtn.className = "extuiQuickItemsSearchClearAction";
    clearBtn.textContent = "Limpar busca";
    clearBtn.addEventListener("click", function (ev) {
      ev.stopPropagation();
      clearQuickItemsSearch();
      var input = popover && popover.querySelector(".extuiQuickItemsSearchInput");
      if (input) input.focus();
    });
    wrap.appendChild(clearBtn);
    body.appendChild(wrap);
  }


  function quickItemInitials(title){
    var words=String(title||"").trim().split(/\s+/).filter(Boolean);if(!words.length)return "?";return (words[0].charAt(0)+(words.length>1?words[words.length-1].charAt(0):"")).toUpperCase().slice(0,2);
  }

  function appendQuickItemRow(list,pair,index){
    var item=pair.item,cfg=QUICK_ITEM_TYPE_BY_TYPE[item.type],row=document.createElement("div"),isContact=item.type==="contact";
    row.className="extuiQuickItemsRow";row.setAttribute("role","listitem");row.setAttribute("data-quick-item-key",quickItemKey(item));row.setAttribute("data-result-index",String(index));
    var iconMarkup=isContact?'<span class="extuiQuickItemsRowIcon extuiQuickItemsRowIcon--avatar" style="--c:'+cfg.accent+';"></span>':'<span class="extuiQuickItemsRowIcon" style="--c:'+cfg.accent+';"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+cfg.icon+'</svg></span>';
    row.innerHTML=iconMarkup+'<span class="extuiQuickItemsRowText"><span class="extuiQuickItemsRowTitle"></span><span class="extuiQuickItemsRowSubtitle">'+item.subtitle+'</span></span><button type="button" class="extuiQuickItemsFavBtn"></button><span class="extuiQuickItemSendState" aria-hidden="true"></span>';
    if(isContact)row.querySelector(".extuiQuickItemsRowIcon--avatar").textContent=quickItemInitials(item.title);
    var titleEl=row.querySelector(".extuiQuickItemsRowTitle");if(pair.matches)titleEl.appendChild(extQiBuildHighlightedLabel(item.title,pair.matches));else titleEl.textContent=item.title;
    var favBtn=row.querySelector(".extuiQuickItemsFavBtn");favBtn.classList.toggle("extuiIsFavorite",item.isFavorite);favBtn.textContent=item.isFavorite?"★":"☆";favBtn.setAttribute("aria-label",(item.isFavorite?"Remover ":"Adicionar ")+item.title+(item.isFavorite?" dos favoritos":" aos favoritos"));
    favBtn.addEventListener("click",function(ev){ev.stopPropagation();ev.preventDefault();toggleQuickItemFavorite(item);});
    row.addEventListener("click",function(){handleQuickItemSend(item,{skipConfirm:true});});row.addEventListener("mouseenter",function(){quickShelfRuntime.activeIndex=index;applyActiveIndexHighlight();});list.appendChild(row);
  }

  function renderQuickItemsList(body, pairs) {
    body.innerHTML = "";
    if(quickShelfRuntime.activeCategoryType!=="all"){
      pairs=pairs.filter(function(pair){return pair&&quickItemMatchesActiveCategory(pair.item);});
      var flat=document.createElement("div");flat.className="extuiQuickItemsList extuiQuickItemsList--flat";flat.setAttribute("role","list");flat.setAttribute("aria-label",quickItemsActiveLabel());
      pairs.forEach(function(pair,index){appendQuickItemRow(flat,pair,index);});body.appendChild(flat);return;
    }
    var groupOrder=QUICK_LIBRARY_FILTERS.map(function(x){return x.type;}),groupLabels={};QUICK_LIBRARY_FILTERS.forEach(function(x){groupLabels[x.type]=x.label;});
    var groups={};pairs.forEach(function(pair,index){var type=groupLabels[pair.item.type]?pair.item.type:"other";(groups[type]=groups[type]||[]).push({pair:pair,index:index});});
    var visibleOrder=groupOrder.concat(groups.other&&groups.other.length?["other"]:[]);
    visibleOrder.forEach(function(type){var rows=groups[type]||[];if(!rows.length)return;var disclosure=document.createElement("details");disclosure.className="extuiQuickItemsDisclosure";disclosure.open=true;var summary=document.createElement("summary");summary.className="extuiQuickItemsDisclosureSummary";summary.textContent=(groupLabels[type]||"Outros")+" ("+rows.length+")";disclosure.appendChild(summary);var list=document.createElement("div");list.className="extuiQuickItemsList";list.setAttribute("role","list");list.setAttribute("aria-label",groupLabels[type]||"Outros");rows.forEach(function(groupRow){appendQuickItemRow(list,groupRow.pair,groupRow.index);});disclosure.appendChild(list);body.appendChild(disclosure);});
  }

  function renderPopoverFromCache(preserveActive) {
    if (!popover) return;
    var body = popover.querySelector(".extuiQuickItemsPopoverBody");
    if (!body) return;
    var previousActiveItem = (preserveActive && quickShelfRuntime.activeIndex >= 0 && quickShelfRuntime.currentResultPairs[quickShelfRuntime.activeIndex])
      ? quickShelfRuntime.currentResultPairs[quickShelfRuntime.activeIndex].item : null;
    if (!quickShelfRuntime.itemsLoaded) {
      quickShelfRuntime.currentResultPairs = [];
      quickShelfRuntime.activeIndex = -1;
      hidePreview();
      updateQuickItemsMainMeta();
      renderLoadingState(body);
      return;
    }
    if (!quickShelfRuntime.itemsCache.length) {
      quickShelfRuntime.currentResultPairs = [];
      quickShelfRuntime.activeIndex = -1;
      hidePreview();
      updateQuickItemsMainMeta(0);
      renderEmptyState(body, null);
      return;
    }
    var pairs = buildQuickItemsViewList(quickShelfRuntime.itemsCache, quickShelfRuntime.searchQuery);
    quickShelfRuntime.currentResultPairs = pairs;
    updateQuickItemsMainMeta(pairs.length);
    if (!pairs.length) {
      quickShelfRuntime.activeIndex = -1;
      hidePreview();
      updateQuickItemsMainMeta(0);
      renderEmptyState(body, quickShelfRuntime.searchQuery);
      return;
    }
    if (previousActiveItem) {
      var keptIndex = -1;
      for (var i = 0; i < pairs.length; i++) {
        if (pairs[i].item.type === previousActiveItem.type && pairs[i].item.id === previousActiveItem.id) { keptIndex = i; break; }
      }
      quickShelfRuntime.activeIndex = keptIndex;
    } else {


      quickShelfRuntime.activeIndex = extQiNormalizeForSearch(quickShelfRuntime.searchQuery).trim() ? 0 : -1;
    }
    renderQuickItemsList(body, pairs);
    applyActiveIndexHighlight();
  }


  var PREVIEW_CACHE_MAX = 6;
  var PREVIEW_DEBOUNCE_MS = 150;

  function getPreviewEl() {
    return popover ? popover.querySelector(".extuiQuickItemsPreview") : null;
  }

  function hidePreview() {
    if (quickShelfRuntime.previewDebounceTimer) { clearTimeout(quickShelfRuntime.previewDebounceTimer); quickShelfRuntime.previewDebounceTimer = null; }
    quickShelfRuntime.previewCurrentKey = null;
    quickShelfRuntime.previewToken++;
    var el = getPreviewEl();
    if (el) { el.style.display = "none"; el.innerHTML = ""; }
  }


  function schedulePreviewUpdate() {
    if (quickShelfRuntime.previewDebounceTimer) { clearTimeout(quickShelfRuntime.previewDebounceTimer); quickShelfRuntime.previewDebounceTimer = null; }
    var pair = (quickShelfRuntime.activeIndex >= 0 && quickShelfRuntime.currentResultPairs[quickShelfRuntime.activeIndex]) ? quickShelfRuntime.currentResultPairs[quickShelfRuntime.activeIndex] : null;
    if (!pair) { hidePreview(); return; }
    var item = pair.item;
    if (quickItemKey(item) === quickShelfRuntime.previewCurrentKey) return;
    quickShelfRuntime.previewDebounceTimer = setTimeout(function () {
      quickShelfRuntime.previewDebounceTimer = null;
      renderPreviewForItem(item);
    }, PREVIEW_DEBOUNCE_MS);
  }

  function paintPreview(el, node) {
    el.innerHTML = "";
    el.appendChild(node);
    el.style.display = "flex";
  }


  function buildPreviewHeader(item, cfg) {
    var head = document.createElement("div");
    head.className = "extuiQuickItemsPreviewHead";
    head.innerHTML =
      '<span class="extuiQuickItemsPreviewIcon" style="--c:' + cfg.accent + ';"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + cfg.icon + '</svg></span>' +
      '<span class="extuiQuickItemsPreviewTitleWrap">' +
      '  <span class="extuiQuickItemsPreviewTitle"></span>' +
      '  <span class="extuiQuickItemsPreviewType"></span>' +
      '</span>';
    head.querySelector(".extuiQuickItemsPreviewTitle").textContent = item.title;
    head.querySelector(".extuiQuickItemsPreviewType").textContent = cfg.label;
    return head;
  }


  function buildLightPreviewNode(item, cfg, note) {
    var frag = document.createDocumentFragment();
    frag.appendChild(buildPreviewHeader(item, cfg));
    var body = document.createElement("div");
    body.className = "extuiQuickItemsPreviewBody";
    var line = document.createElement("div");
    line.className = "extuiQuickItemsPreviewNote";
    line.textContent = note;
    body.appendChild(line);
    frag.appendChild(body);
    return frag;
  }


  function buildFlowPreviewNode(item, cfg) {
    var frag = document.createDocumentFragment();
    frag.appendChild(buildPreviewHeader(item, cfg));
    var raw = item.raw || {};
    var nodes = Array.isArray(raw.nodes) ? raw.nodes : [];
    var body = document.createElement("div");
    body.className = "extuiQuickItemsPreviewBody";
    var line1 = document.createElement("div");
    line1.className = "extuiQuickItemsPreviewLine";
    line1.textContent = nodes.length + (nodes.length === 1 ? " passo" : " passos");
    body.appendChild(line1);
    if (raw.trigger && raw.trigger.type) {
      var line2 = document.createElement("div");
      line2.className = "extuiQuickItemsPreviewNote";
      line2.textContent = "Gatilho: " + raw.trigger.type;
      body.appendChild(line2);
    }
    frag.appendChild(body);
    return frag;
  }


  function buildFunnelPreviewNode(item, cfg) {
    var frag = document.createDocumentFragment();
    frag.appendChild(buildPreviewHeader(item, cfg));
    var raw = item.raw || {};
    var steps = Array.isArray(raw.items) ? raw.items : [];
    var body = document.createElement("div");
    body.className = "extuiQuickItemsPreviewBody";
    var line1 = document.createElement("div");
    line1.className = "extuiQuickItemsPreviewLine";
    line1.textContent = steps.length + (steps.length === 1 ? " passo" : " passos");
    body.appendChild(line1);
    var typeCounts = {};
    steps.forEach(function (s) { if (s && s.type) typeCounts[s.type] = (typeCounts[s.type] || 0) + 1; });
    var typeLabels = Object.keys(typeCounts).map(function (t) {
      var tCfg = QUICK_ITEM_TYPE_BY_TYPE[t];
      return typeCounts[t] + "x " + (tCfg ? tCfg.label : t);
    });
    if (typeLabels.length) {
      var line2 = document.createElement("div");
      line2.className = "extuiQuickItemsPreviewNote";
      line2.textContent = typeLabels.join(", ");
      body.appendChild(line2);
    }
    frag.appendChild(body);
    return frag;
  }

  function buildMessageStatusNode(item, cfg, text) {
    var frag = document.createDocumentFragment();
    frag.appendChild(buildPreviewHeader(item, cfg));
    var body = document.createElement("div");
    body.className = "extuiQuickItemsPreviewBody";
    var line = document.createElement("div");
    line.className = "extuiQuickItemsPreviewNote";
    line.textContent = text;
    body.appendChild(line);
    frag.appendChild(body);
    return frag;
  }


  function buildMessagePreviewNode(item, cfg, text) {
    var frag = document.createDocumentFragment();
    frag.appendChild(buildPreviewHeader(item, cfg));
    var body = document.createElement("div");
    body.className = "extuiQuickItemsPreviewBody";
    var textEl = document.createElement("div");
    textEl.className = "extuiQuickItemsPreviewText";
    textEl.textContent = text;
    body.appendChild(textEl);
    frag.appendChild(body);
    return frag;
  }

  function safeParseMessageContent(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (err) { return null; }
  }

  function setPreviewMessageCache(id, text) {
    if (quickShelfRuntime.previewCache.has(id)) quickShelfRuntime.previewCache.delete(id);
    quickShelfRuntime.previewCache.set(id, text);
    if (quickShelfRuntime.previewCache.size > PREVIEW_CACHE_MAX) {
      quickShelfRuntime.previewCache.delete(quickShelfRuntime.previewCache.keys().next().value);
    }
  }


  function renderMessagePreview(item, cfg, myToken) {
    var el = getPreviewEl();
    if (!el) return;
    var cached = quickShelfRuntime.previewCache.get(item.id);
    if (cached !== undefined) {
      paintPreview(el, buildMessagePreviewNode(item, cfg, cached));
      return;
    }
    var loadingTimer = setTimeout(function () {
      if (myToken !== quickShelfRuntime.previewToken) return;
      paintPreview(el, buildMessageStatusNode(item, cfg, "Carregando preview..."));
    }, 120);
    extQiGet(item.id).then(function (raw) {
      clearTimeout(loadingTimer);
      if (myToken !== quickShelfRuntime.previewToken) return;
      var content = safeParseMessageContent(raw);
      var text = content && typeof content.data === "string" ? content.data : null;
      if (text === null) { paintPreview(el, buildMessageStatusNode(item, cfg, "Preview indisponível")); return; }
      setPreviewMessageCache(item.id, text);
      paintPreview(el, buildMessagePreviewNode(item, cfg, text));
    }).catch(function (err) {
      clearTimeout(loadingTimer);
      if (myToken !== quickShelfRuntime.previewToken) return;
      paintPreview(el, buildMessageStatusNode(item, cfg, "Preview indisponível"));
    });
  }


  function renderInteractiveListPreview(item, cfg, myToken) {
    var target = getPreviewEl();
    if (!target) return;
    extQiGet(item.id).then(function (raw) {
      if (myToken !== quickShelfRuntime.previewToken) return;
      var content = safeParseMessageContent(raw) || {};
      var api = window.__extInteractiveList;
      var value = api ? api.normalize(content) : content;
      var total = api ? api.countRows(value) : (Array.isArray(value.sections) ? value.sections.reduce(function (sum, section) { return sum + (Array.isArray(section && section.rows) ? section.rows.length : 0); }, 0) : 0);
      var frag = document.createDocumentFragment();
      frag.appendChild(buildPreviewHeader(item, cfg));
      var body = document.createElement("div");
      body.className = "extuiQuickItemsPreviewBody";
      var message = document.createElement("div");
      message.className = "extuiQuickItemsPreviewText";
      message.textContent = value.description || "Lista interativa";
      body.appendChild(message);
      var note = document.createElement("div");
      note.className = "extuiQuickItemsPreviewNote";
      note.textContent = total + (total === 1 ? " opção" : " opções") + " · " + (value.buttonText || "Ver opções");
      body.appendChild(note);
      frag.appendChild(body);
      paintPreview(target, frag);
    }).catch(function () {
      if (myToken !== quickShelfRuntime.previewToken) return;
      paintPreview(target, buildMessageStatusNode(item, cfg, "Preview indisponível"));
    });
  }

  function renderPreviewForItem(item) {
    var el = getPreviewEl();
    if (!el) return;
    quickShelfRuntime.previewCurrentKey = quickItemKey(item);
    var myToken = ++quickShelfRuntime.previewToken;
    var cfg = QUICK_ITEM_TYPE_BY_TYPE[item.type];
    if (item.type === "flow") { paintPreview(el, buildFlowPreviewNode(item, cfg)); return; }
    if (item.type === "funnel") { paintPreview(el, buildFunnelPreviewNode(item, cfg)); return; }
    if (item.type === "audio") { paintPreview(el, buildLightPreviewNode(item, cfg, "Áudio salvo")); return; }
    if (item.type === "image") { paintPreview(el, buildLightPreviewNode(item, cfg, "Imagem salva")); return; }
    if (item.type === "video") { paintPreview(el, buildLightPreviewNode(item, cfg, "Vídeo salvo")); return; }
    if (item.type === "sticker") { paintPreview(el, buildLightPreviewNode(item, cfg, "Figurinha salva")); return; }
    if (item.type === "pix") { paintPreview(el, buildLightPreviewNode(item, cfg, "Chave PIX salva")); return; }
    if (item.type === "interactive-list") { renderInteractiveListPreview(item, cfg, myToken); return; }
    if (item.type === "contact") { paintPreview(el, buildLightPreviewNode(item, cfg, "Contato salvo")); return; }
    if (item.type === "document") { paintPreview(el, buildLightPreviewNode(item, cfg, "Documento salvo")); return; }
    if (item.type === "message") { renderMessagePreview(item, cfg, myToken); return; }
  }


  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }

  var DOCK_INSET = 8;

  function getEffectiveChatBounds(footerRect) {
    var left = footerRect.left;
    var right = footerRect.right;
    var rail = document.getElementById("extapp-sidebar-nav-root");
    if (rail) {
      var railRect = rail.getBoundingClientRect();
      if (railRect.width > 0 && railRect.right > left && railRect.left < right) {
        var railCenter = railRect.left + railRect.width / 2;
        var footerCenter = left + (right - left) / 2;
        if (railCenter < footerCenter) left = Math.max(left, railRect.right);
        else right = Math.min(right, railRect.left);
      }
    }
    return { left: left, right: Math.max(left, right) };
  }


  function getComposeOccupiedRect(footer) {
    var base=footer&&footer.getBoundingClientRect?footer.getBoundingClientRect():null;if(!base)return null;
    var main=document.getElementById("main"),mainRect=main&&main.getBoundingClientRect?main.getBoundingClientRect():null,top=base.top,left=base.left,right=base.right,bottom=base.bottom,replyActive=false;
    var node=footer,parentDepth=0;
    while(node&&node!==main&&parentDepth<7){
      var parent=node.parentElement;if(!parent)break;var r=parent.getBoundingClientRect();
      if(r.width>0&&r.height>0&&(!mainRect||r.width>=mainRect.width*.45)&&r.height<=320&&r.bottom>=base.bottom-24&&r.top<=top){top=Math.min(top,r.top);left=Math.min(left,r.left);right=Math.max(right,r.right);bottom=Math.max(bottom,r.bottom);}
      node=parent;parentDepth++;
    }
    if(main){
      var replySelectors=['[data-testid*="quoted" i]','[data-testid*="reply" i]','[aria-label*="responder" i]','[aria-label*="reply" i]'];
      replySelectors.forEach(function(selector){var list=[];try{list=main.querySelectorAll(selector);}catch(_){}for(var i=0;i<list.length;i++){var r=list[i].getBoundingClientRect();if(r.width<120||r.height<18||r.height>220)continue;if(r.bottom<base.top-190||r.top>base.bottom+20)continue;if(r.right<base.left||r.left>base.right)continue;top=Math.min(top,r.top);replyActive=true;}});
    }
    if(!replyActive&&base.top-top>26&&base.top-top<240)replyActive=true;
    return{top:top,left:left,right:right,bottom:bottom,width:Math.max(0,right-left),height:Math.max(0,bottom-top),replyActive:replyActive};
  }

  function quickShelfHasConversationSurface(){
    var main=document.getElementById("main");
    if(!main||!main.isConnected)return false;
    try{
      if(main.querySelector('[contenteditable="true"][role="textbox"],div[contenteditable="true"][data-tab],[data-testid="conversation-compose-box-input"],footer'))return true;
      if(main.querySelector('header,[data-testid*="conversation" i]'))return true;
    }catch(_){}
    return false;
  }
  function scheduleMissingAnchorRecovery(){
    if(!quickShelfRuntime.runtimeActive||quickShelfRuntime.missingAnchorRetryTimer)return;
    var attempt=quickShelfRuntime.missingAnchorAttempts++;
    var delay=attempt<8?Math.min(700,100+attempt*75):1200;
    quickShelfRuntime.missingAnchorRetryTimer=setTimeout(function(){
      quickShelfRuntime.missingAnchorRetryTimer=0;
      attachObserver();attachRootObserver();scheduleReposition();
    },delay);
  }
  function nodeTouchesCompose(node){
    if(!node||node.nodeType!==1)return false;
    try{if(node.matches&&node.matches('#main,footer,[contenteditable="true"],[data-testid="conversation-compose-box-input"],[role="main"]'))return true;}catch(_){}
    try{return !!(node.querySelector&&node.querySelector('#main,footer,[contenteditable="true"],[data-testid="conversation-compose-box-input"],[role="main"]'));}catch(_){return false;}
  }
  function rootMutationTouchesCompose(records){
    for(var i=0;i<records.length;i++){var r=records[i],j;for(j=0;j<r.addedNodes.length;j++)if(nodeTouchesCompose(r.addedNodes[j]))return true;for(j=0;j<r.removedNodes.length;j++)if(nodeTouchesCompose(r.removedNodes[j]))return true;}
    return false;
  }
  function attachRootObserver(){
    var root=document.body||document.documentElement;
    if(!root||root===quickShelfRuntime.observedRoot)return;
    if(quickShelfRuntime.rootObserver)quickShelfRuntime.rootObserver.disconnect();
    quickShelfRuntime.observedRoot=root;
    quickShelfRuntime.rootObserver=new MutationObserver(function(records){
      if(!rootMutationTouchesCompose(records))return;
      if(quickShelfRuntime.rootMutationTimer)clearTimeout(quickShelfRuntime.rootMutationTimer);
      quickShelfRuntime.rootMutationTimer=setTimeout(function(){quickShelfRuntime.rootMutationTimer=0;attachObserver();scheduleReposition();},60);
    });
    quickShelfRuntime.rootObserver.observe(root,{childList:true,subtree:true});
  }
  function reposition() {
    if (quickShelfRuntime.quickActionDock && !document.body.contains(quickShelfRuntime.quickActionDock)) quickShelfRuntime.quickActionDock = null;

    var footer = findComposeFooter();
    if (!footer) {
      var now=Date.now(),withinTransitionGrace=quickShelfRuntime.lastComposeSeenAt&&now-quickShelfRuntime.lastComposeSeenAt<2400&&quickShelfHasConversationSurface();
      if (!withinTransitionGrace&&quickShelfRuntime.quickActionDock) quickShelfRuntime.quickActionDock.style.display = "none";
      if (quickShelfRuntime.footerResizeObserver) { quickShelfRuntime.footerResizeObserver.disconnect(); quickShelfRuntime.footerResizeObserver = null; quickShelfRuntime.observedFooter = null; }
      if (!withinTransitionGrace&&popoverOpen) closePopover();
      scheduleMissingAnchorRecovery();
      return;
    }
    quickShelfRuntime.lastComposeSeenAt=Date.now();quickShelfRuntime.missingAnchorAttempts=0;
    if(quickShelfRuntime.missingAnchorRetryTimer){clearTimeout(quickShelfRuntime.missingAnchorRetryTimer);quickShelfRuntime.missingAnchorRetryTimer=0;}

    if (popoverOpen && footer !== quickShelfRuntime.observedFooter) closePopover();
    attachFooterResizeObserver(footer);

    if (!quickShelfRuntime.bootLoaded || !quickShelfRuntime.quickShelfEnabled) {
      if (quickShelfRuntime.quickActionDock) quickShelfRuntime.quickActionDock.style.display = "none";
      if (popoverOpen) closePopover();
      return;
    }

    var footerRect = footer.getBoundingClientRect();
    var composeRect = getComposeOccupiedRect(footer) || footerRect;
    var sidebarRight = document.documentElement.getAttribute("data-extui-sidebar-placement") === "right-conversation";
    var v2Host = document.getElementById("ext-sidebar-host");
    if (v2Host && v2Host.getAttribute("data-placement") === "right-conversation") sidebarRight = true;
    var expectedQuickCommands = ["client.open","crm.open","orders.open","note.open","agenda.open","labels.open","quick-response.open","quick-items.open"];
    if (quickShelfRuntime.quickActionDock) {
      var currentQuickButtons = Array.prototype.slice.call(quickShelfRuntime.quickActionDock.querySelectorAll(".extuiChatQuickActionBtn"));
      var dockIsCurrent = currentQuickButtons.length === expectedQuickCommands.length && currentQuickButtons.every(function (button, index) {
        return button.getAttribute("data-command") === expectedQuickCommands[index];
      });
      if (!dockIsCurrent) {
        try { quickShelfRuntime.quickActionDock.remove(); } catch (_) {}
        quickShelfRuntime.quickActionDock = null;
      }
    }
    if (!quickShelfRuntime.quickActionDock) quickShelfRuntime.quickActionDock = buildQuickActionDock();
    quickShelfRuntime.quickActionDock.style.display="flex";
    quickShelfRuntime.quickActionDock.style.visibility="visible";
    quickShelfRuntime.quickActionDock.style.opacity="1";
    quickShelfRuntime.quickActionDock.style.pointerEvents="auto";
    quickShelfRuntime.quickActionDock.style.position="fixed";
    quickShelfRuntime.quickActionDock.style.zIndex="var(--extui-z-quick-actions, 2147483001)";
    quickShelfRuntime.quickActionDock.classList.remove("is-chat-overlay-active");
    var quickButtons = Array.prototype.slice.call(quickShelfRuntime.quickActionDock.querySelectorAll(".extuiChatQuickActionBtn"));
    var visibleQuickButtons=[];
    quickButtons.forEach(function (button) {
      var on=quickActionIsVisible(button.getAttribute("data-command"));
      button.hidden=!on;
      button.style.display=on?"grid":"none";
      button.style.setProperty("visibility",on?"visible":"hidden");
      if(on)button.style.removeProperty("opacity");else button.style.setProperty("opacity","0");
      button.setAttribute("aria-hidden",String(!on));
      if(on)visibleQuickButtons.push(button);
    });
    if(!visibleQuickButtons.length){quickShelfRuntime.quickActionDock.style.display="none";if(popoverOpen)closePopover();return;}
    var actionCount = Math.max(1, visibleQuickButtons.length);
    var availableDockHeight = Math.max(0, window.innerHeight - VIEWPORT_MARGIN * 2);
    var dockSize = 44, dockGap = 9;
    var naturalHeight = actionCount * dockSize + Math.max(0, actionCount - 1) * dockGap;
    if (naturalHeight > availableDockHeight && availableDockHeight > 0) {
      dockGap = 4;
      dockSize = Math.max(28, Math.min(44, Math.floor((availableDockHeight - Math.max(0, actionCount - 1) * dockGap) / actionCount)));
    }
    quickShelfRuntime.quickActionDock.style.setProperty("--extui-quick-action-size", dockSize + "px");
    quickShelfRuntime.quickActionDock.style.setProperty("--extui-quick-action-gap", dockGap + "px");
    var dockRect = quickShelfRuntime.quickActionDock.getBoundingClientRect();
    var dockLeft;
    var railRect = v2Host && v2Host.getBoundingClientRect ? v2Host.getBoundingClientRect() : null;
    if (sidebarRight && railRect && railRect.width > 0) dockLeft = railRect.left - dockRect.width - 7;
    else if (sidebarRight) dockLeft = footerRect.left + DOCK_INSET;
    else dockLeft = footerRect.right - dockRect.width - DOCK_INSET;
    dockLeft=clamp(dockLeft,VIEWPORT_MARGIN,window.innerWidth-dockRect.width-VIEWPORT_MARGIN);
    var preferredDockTop=(window.innerHeight-dockRect.height)*.56;
    var dockTop = clamp(preferredDockTop, VIEWPORT_MARGIN, window.innerHeight-dockRect.height-VIEWPORT_MARGIN);
    quickShelfRuntime.quickActionDock.style.left=dockLeft+"px";
    quickShelfRuntime.quickActionDock.style.top=dockTop+"px";
    syncQuickItemsDockState();

    if (popoverOpen) positionPopover();
  }

  function scheduleReposition() {
    if (!quickShelfRuntime.runtimeActive) return;
    if (quickShelfRuntime.repositionScheduled) return;
    quickShelfRuntime.repositionScheduled = true;
    requestAnimationFrame(function () {
      quickShelfRuntime.repositionScheduled = false;
      reposition();
    });
  }


  function attachFooterResizeObserver(footer) {
    if (!footer || footer === quickShelfRuntime.observedFooter) return;
    if (quickShelfRuntime.footerResizeObserver) quickShelfRuntime.footerResizeObserver.disconnect();
    quickShelfRuntime.observedFooter = footer;
    quickShelfRuntime.footerResizeObserver = new ResizeObserver(function () {
      scheduleReposition();
    });
    quickShelfRuntime.footerResizeObserver.observe(footer);
  }


  function attachObserver() {
    attachRootObserver();
    var main = document.getElementById("main");
    if (!main || !main.isConnected || main === quickShelfRuntime.observedMain) return;
    if (quickShelfRuntime.observer) quickShelfRuntime.observer.disconnect();
    quickShelfRuntime.observedMain = main;
    quickShelfRuntime.observer = new MutationObserver(function (records) {
      if(!rootMutationTouchesCompose(records)) return;
      if (quickShelfRuntime.mutationDebounceTimer) clearTimeout(quickShelfRuntime.mutationDebounceTimer);
      quickShelfRuntime.mutationDebounceTimer = setTimeout(function () { quickShelfRuntime.mutationDebounceTimer = 0; scheduleReposition(); }, 120);
    });
    quickShelfRuntime.observer.observe(main, { childList: true, subtree: true });
  }


  function extQiPulse() {
    if (!quickShelfRuntime.runtimeActive) return;
    var footer = findComposeFooter(), main = document.getElementById("main");
    if (!document.hidden) {
      attachRootObserver(); attachObserver();
      var dockMissing = !quickShelfRuntime.quickActionDock || !document.body.contains(quickShelfRuntime.quickActionDock);
      var observerStale = !!main && main !== quickShelfRuntime.observedMain;
      var footerObserverStale = !!footer && footer !== quickShelfRuntime.observedFooter;
      var needsRecovery = !footer || dockMissing || observerStale || footerObserverStale;
      if(needsRecovery) scheduleReposition();
    }
    quickShelfRuntime.pulseCount += 1;
    var delay = document.hidden ? 30000 : (footer ? 15000 : (quickShelfRuntime.pulseCount < 24 ? 250 : 1000));
    quickShelfRuntime.pulseTimer = setTimeout(extQiPulse, delay);
  }
  window.addEventListener("resize", scheduleReposition);
  window.addEventListener("focus", scheduleReposition);
  window.addEventListener("ext:sidebar-v2-layout", scheduleReposition);
  window.addEventListener("ext:sidebar-v2-visibility", scheduleReposition);
  window.addEventListener("ext:panel-open-mode", scheduleReposition);
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { attachObserver(); scheduleReposition(); } });
  window.addEventListener("ext:wpp-readiness", function (ev) {
    var detail = ev && ev.detail || {};
    if (!detail.ready) return;
    attachObserver();
    scheduleReposition();
    refreshQuickItemsCache().catch(function () {});
  });
  window.__extQuickItemsScheduleReposition = scheduleReposition;

  function stopQuickItemsRuntime(){
    quickShelfRuntime.runtimeActive=false;
    if(quickShelfRuntime.pulseTimer){clearTimeout(quickShelfRuntime.pulseTimer);quickShelfRuntime.pulseTimer=0;}
    if(quickShelfRuntime.footerResizeObserver){quickShelfRuntime.footerResizeObserver.disconnect();quickShelfRuntime.footerResizeObserver=null;}
    if(quickShelfRuntime.mutationDebounceTimer){clearTimeout(quickShelfRuntime.mutationDebounceTimer);quickShelfRuntime.mutationDebounceTimer=0;}
    quickShelfRuntime.observedFooter=null;
    if(quickShelfRuntime.observer){quickShelfRuntime.observer.disconnect();quickShelfRuntime.observer=null;}
    quickShelfRuntime.observedMain=null;
    if(typeof quickShelfRuntime.storageOff==="function"){try{quickShelfRuntime.storageOff();}catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_SHELF_STORAGE_UNSUBSCRIBE_FAILED",err);}quickShelfRuntime.storageOff=null;}
    if(quickShelfRuntime.rootObserver){quickShelfRuntime.rootObserver.disconnect();quickShelfRuntime.rootObserver=null;}quickShelfRuntime.observedRoot=null;
    if(quickShelfRuntime.rootMutationTimer){clearTimeout(quickShelfRuntime.rootMutationTimer);quickShelfRuntime.rootMutationTimer=0;}
    if(quickShelfRuntime.missingAnchorRetryTimer){clearTimeout(quickShelfRuntime.missingAnchorRetryTimer);quickShelfRuntime.missingAnchorRetryTimer=0;}
    if(quickShelfRuntime.storageRetryTimer){clearTimeout(quickShelfRuntime.storageRetryTimer);quickShelfRuntime.storageRetryTimer=0;}
    quickShelfRuntime.missingAnchorAttempts=0;
  }
  function scheduleStorageRuntimeRetry(){
    if(quickShelfRuntime.storageRetryTimer)return;var attempt=quickShelfRuntime.storageRetryAttempt++;var delay=Math.min(5000,250*Math.pow(2,Math.min(attempt,4)));
    quickShelfRuntime.storageRetryTimer=setTimeout(function(){quickShelfRuntime.storageRetryTimer=0;startQuickItemsRuntime();},delay);
  }
  function startQuickItemsRuntime(){
    if(quickShelfRuntime.runtimeActive)return;quickShelfRuntime.runtimeActive=true;
    try{bindQuickItemsStorage();}catch(err){quickShelfRuntime.runtimeActive=false;if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_SHELF_STORAGE_SUBSCRIBE_FAILED",err);scheduleStorageRuntimeRetry();return;}
    quickShelfRuntime.storageRetryAttempt=0;if(quickShelfRuntime.storageRetryTimer){clearTimeout(quickShelfRuntime.storageRetryTimer);quickShelfRuntime.storageRetryTimer=0;}
    attachRootObserver();attachObserver();reposition();extQiPulse();refreshQuickItemsCache().catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_SHELF_CACHE_REFRESH_FAILED",err); });
  }
  function installQuickItemsLifecycle(){if(quickShelfRuntime.lifecycleBound)return;quickShelfRuntime.lifecycleBound=true;window.addEventListener("pagehide",stopQuickItemsRuntime);window.addEventListener("pageshow",function(){startQuickItemsRuntime();scheduleReposition();});window.addEventListener("online",scheduleReposition);}
  installQuickItemsLifecycle();
  if(window.__extBootPhases&&typeof window.__extBootPhases.when==="function")window.__extBootPhases.when(2,startQuickItemsRuntime);else startQuickItemsRuntime();
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
