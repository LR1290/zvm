;(function () {
  "use strict";
  if (window.__extCreateChatToolsPanelDomainCore) return;
  window.__extCreateChatToolsPanelDomainCore = function (deps) {
    deps=deps||{};
    var buildPanelShell=deps.buildPanelShell,panelBrand=deps.panelBrand||{},panelBody=deps.panelBody,prefsKey=deps.prefsKey||"EXTUI:chatToolsHubPrefs",get=deps.get,set=deps.set,toolGroups=deps.toolGroups||[],iconChip=deps.iconChip,escHtml=deps.escHtml,toast=deps.toast,panelDecorate=deps.panelDecorate,ownLifecycle=deps.ownLifecycle,panelState=deps.panelState;
    if([buildPanelShell,panelBody,get,set,iconChip,escHtml,toast,panelDecorate,ownLifecycle].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do domínio Ferramentas inválidas.");
    
    
    async function buildChatToolsPanel(){
      var root=buildPanelShell({id:"extuiNavChatToolsPanel",title:"Ferramentas",accent:panelBrand.tools.accent,icon:panelBrand.tools.icon,eyebrow:"Conversa",hint:"Acesse outros painéis da Sidebar, mesmo quando o atalho estiver oculto.",size:"md",tutorialKey:"ferramentas"});var body=panelBody(root);body.innerHTML="";
      var hubState={hideActive:false,sidebarState:null};
      function sidebarRegistry(){return window.ExtensionUI&&window.ExtensionUI.sidebarRegistry||null;}
      function sidebarStorage(){return window.ExtensionUI&&window.ExtensionUI.sidebarStorage||null;}
      function sidebarItem(key){var registry=sidebarRegistry();return registry&&typeof registry.get==="function"?registry.get(key):null;}
      function sidebarVisibleSet(){var registry=sidebarRegistry(),state=hubState.sidebarState;if(!registry||!state)return new Set();return new Set((registry.orderedPinned(state)||[]).map(String));}
      function railMeta(key,title){var item=sidebarItem(key);return {sidebarKey:key,sidebarItem:item,accent:"#00a884",desc:item&&item.label?"Abrir "+item.label+" na Sidebar":"Abrir "+title+" na Sidebar",icon:panelBrand.tools.icon};}
      async function loadHubState(){
        var storage=sidebarStorage();
        try{hubState.sidebarState=storage&&typeof storage.load==="function"?await storage.load():null;}catch(_){hubState.sidebarState=null;}
        try{var prefs=await get(prefsKey);if(typeof prefs==="string"){try{prefs=JSON.parse(prefs);}catch(_){prefs={};}}prefs=prefs&&prefs.state&&typeof prefs.state==="object"?prefs.state:(prefs&&typeof prefs==="object"?prefs:{});hubState.hideActive=prefs.hideActive===true;}catch(_){hubState.hideActive=false;}
        return hubState;
      }
      async function saveHideActive(value){hubState.hideActive=!!value;try{await set(prefsKey,{schemaVersion:1,state:{hideActive:hubState.hideActive,updatedAt:Date.now()}});}catch(_){}renderHub();}
      async function openSidebarKey(key){
        var item=sidebarItem(key);if(!item||!item.command)throw new Error("Painel indisponível neste momento.");
        var host=window.ExtensionCore&&window.ExtensionCore.CommandHost;
        if(!host||typeof host.execute!=="function")throw new Error("Navegação da Sidebar ainda não ficou pronta.");
        var payload=Object.assign({},item.payload||{},{ensureOpen:true,source:"chat-tools"});
        return host.execute(item.command,payload);
      }
      function toolCard(item){
        var id=item[0],title=item[1],meta=railMeta(item[2],title);
        var card=document.createElement("button");card.type="button";card.className="extuiToolCard";card.style.setProperty("--extui-tool-accent",meta.accent||"#00a884");if(meta.sidebarKey)card.dataset.sidebarKey=meta.sidebarKey;
        var iconHtml=meta.sidebarItem&&window.ExtensionUI&&window.ExtensionUI.sidebarIcons&&typeof window.ExtensionUI.sidebarIcons.svg==="function"?'<span class="extuiToolSidebarGlyph">'+window.ExtensionUI.sidebarIcons.svg(meta.sidebarItem.icon)+'</span>':iconChip(meta.accent||"#00a884",meta.icon,true);
        card.innerHTML='<span class="extuiToolCardIcon">'+iconHtml+'</span><span class="extuiToolCardCopy"><strong>'+escHtml(title)+'</strong><small>'+escHtml(meta.desc||"")+'</small></span><svg class="extuiToolCardArrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>';
        card.addEventListener("click",async function(ev){ev.preventDefault();ev.stopPropagation();if(card.disabled)return;card.disabled=true;card.setAttribute("aria-busy","true");try{await openSidebarKey(item[2]||String(id).slice(5));}catch(e){toast(e&&e.message||"Painel indisponível.",true);}finally{card.disabled=false;card.removeAttribute("aria-busy");}});
        return card;
      }
      function renderHub(){
        body.innerHTML="";
        var filter=document.createElement("section");filter.className="extuiToolsHubFilter";
        var copy=document.createElement("div");copy.className="extuiToolsHubFilterCopy";copy.innerHTML='<strong>Esconder Ativos</strong><span>Mostra apenas os painéis cujo botão está oculto da Sidebar.</span>';
        var toggle=document.createElement("label");toggle.className="extuiToolsHubSwitch";var input=document.createElement("input");input.type="checkbox";input.checked=hubState.hideActive;input.setAttribute("aria-label","Esconder painéis que já estão visíveis na Sidebar");var track=document.createElement("span");track.className="extuiToolsHubSwitchTrack";toggle.appendChild(input);toggle.appendChild(track);input.addEventListener("change",function(){saveHideActive(input.checked);});filter.appendChild(copy);filter.appendChild(toggle);body.appendChild(filter);
        var visible=sidebarVisibleSet(),shown=0;
        toolGroups.forEach(function(group){
          var items=group.items.filter(function(item){var key=item[2];return !(hubState.hideActive&&key&&visible.has(key));});if(!items.length)return;
          var section=document.createElement("section");section.className="extuiToolGroup";
          var head=document.createElement("div");head.className="extuiToolGroupHead";head.innerHTML='<span>'+escHtml(group.title)+'</span><small>'+items.length+' '+(items.length===1?'recurso':'recursos')+'</small>';section.appendChild(head);
          var grid=document.createElement("div");grid.className="extuiToolGrid";items.forEach(function(item){grid.appendChild(toolCard(item));shown++;});section.appendChild(grid);body.appendChild(section);
        });
        if(hubState.hideActive&&!shown){var note=document.createElement("div");note.className="extuiToolsHubAllVisible";note.textContent="Todos os painéis configuráveis já estão visíveis na Sidebar.";body.appendChild(note);}
        panelDecorate(root);
      }
      panelState.setRefresh(root,async function(){await loadHubState();renderHub();});
      var storage=sidebarStorage();if(storage&&typeof storage.subscribe==="function")ownLifecycle(root,storage.subscribe(function(next){hubState.sidebarState=next;if(root.classList.contains("extuiOpen"))renderHub();}));
      await loadHubState();renderHub();return root;
    }
    return Object.freeze({buildChatToolsPanel:buildChatToolsPanel});
  };
})();
