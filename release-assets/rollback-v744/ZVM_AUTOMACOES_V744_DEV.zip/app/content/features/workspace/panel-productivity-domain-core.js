;(function () {
  "use strict";
  if (window.__extCreateProductivityDomainCore) return;
  window.__extCreateProductivityDomainCore = function (deps) {
    deps = deps || {};
    var chatToolMeta = deps.chatToolMeta || {};
    var panelBrand = deps.panelBrand || {};
    var buildPanelShell = deps.buildPanelShell;
    var panelBody = deps.panelBody;
    var field = deps.field;
    var invokeCapability = deps.invokeCapability;
    var getActiveContactContext = deps.getActiveContactContext;
    var toast = deps.toast;
    var iconChip = deps.iconChip;
    var escHtml = deps.escHtml;
    var emptyState = deps.emptyState;
    var panelState = deps.panelState;
    if (typeof buildPanelShell !== "function" || typeof panelBody !== "function" || typeof field !== "function" || typeof invokeCapability !== "function" || typeof getActiveContactContext !== "function" || typeof toast !== "function" || typeof iconChip !== "function" || typeof escHtml !== "function" || typeof emptyState !== "function") throw new TypeError("Dependências do domínio de produtividade inválidas.");
    function parseLocalDateTimeStrict(value){
      var m=String(value||"").match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/);
      if(!m)return NaN;
      var y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]),h=Number(m[4]),mi=Number(m[5]),sec=Number(m[6]||0);
      var dt=new Date(y,mo-1,d,h,mi,sec,0);
      if(dt.getFullYear()!==y||dt.getMonth()!==mo-1||dt.getDate()!==d||dt.getHours()!==h||dt.getMinutes()!==mi||dt.getSeconds()!==sec)return NaN;
      return dt.getTime();
    }

    function standaloneToolFormPanel(spec) {
      spec = spec || {};
      var toolsBrand = panelBrand.tools || {};
      var meta = chatToolMeta[spec.toolId] || { accent: toolsBrand.accent, icon: toolsBrand.icon, desc: "Ferramenta da conversa" };
      var root = buildPanelShell({ id: spec.panelId, title: spec.title, accent: meta.accent, icon: meta.icon, eyebrow: spec.eyebrow || "Conversa", hint: spec.hint || meta.desc, size: spec.size || "sm", tutorialKey: spec.tutorialKey || "ferramentas" });
      var body = panelBody(root); body.innerHTML = "";
      var form = document.createElement("form"); form.className = "extuiCrmQuickComposer extuiToolForm extuiStandaloneToolForm";
      var controls = {};
      (spec.fields || []).forEach(function (f) {
        var isTextarea = f.type === "textarea", isSelect = f.type === "select";
        var input = isTextarea ? document.createElement("textarea") : (isSelect ? document.createElement("select") : document.createElement("input"));
        if (!isTextarea && !isSelect) input.type = f.type || "text";
        if (!isSelect) input.placeholder = f.placeholder || f.label || "";
        if (isSelect) (Array.isArray(f.options) ? f.options : []).forEach(function (option) { var node = document.createElement("option"); node.value = String(option && option.value || ""); node.textContent = String(option && option.label || option && option.value || ""); input.appendChild(node); });
        if (f.required) input.required = true;
        controls[f.name] = input;
        form.appendChild(field(f.label, input));
      });
      var btn = document.createElement("button"); btn.type = "submit"; btn.className = "extuiNavPrimaryBtn"; btn.textContent = spec.submitLabel || "Executar"; form.appendChild(btn); body.appendChild(form);
      var result = document.createElement("div"); result.className = "extuiToolResult extuiStandaloneToolResult"; result.hidden = true; body.appendChild(result);
      var insert = document.createElement("button"); insert.type = "button"; insert.className = "extuiNavSecondaryBtn"; insert.textContent = "Inserir na conversa"; insert.hidden = true; body.appendChild(insert);
      var lastText = "";
      insert.addEventListener("click", async function () { try { if (!lastText || !window.__extWppBridge) return; var ctx = await getActiveContactContext(); await window.__extWppBridge.invoke("Chat", "setInputText", { id: ctx && ctx.chatId || null, txt: lastText }); toast("Texto inserido na conversa."); } catch (e) { toast(e && e.message || "Não foi possível inserir o texto.", true); } });
      form.addEventListener("submit", async function (ev) { ev.preventDefault(); btn.disabled = true; insert.hidden = true; try { var out = await spec.onSubmit(controls); lastText = typeof out === "string" ? out : ""; if (spec.showResult !== false) { result.hidden = false; result.textContent = lastText || (out == null ? (spec.successText || "Ação concluída.") : JSON.stringify(out, null, 2)); } insert.hidden = !(spec.insertResult && lastText); toast(spec.successToast || "Ação concluída."); if (spec.resetOnSuccess === true) form.reset(); } catch (e) { result.hidden = false; result.textContent = e && e.message || String(e); toast(e && e.message || "Não foi possível executar.", true); } finally { btn.disabled = false; } });
      return root;
    }
    function buildNotesPanel() { return standaloneToolFormPanel({ panelId: "extuiNavNotesPanel", title: "Notas", toolId: "notes", hint: "Registre informações importantes ligadas à conversa atual.", fields: [{ name: "text", label: "Nota", type: "textarea", required: true }], submitLabel: "Salvar nota", showResult: false, resetOnSuccess: true, successToast: "Nota salva no cliente.", onSubmit: function (c) { return invokeCapability("notes", { text: c.text.value }); } }); }
    function buildReminderPanel() { return standaloneToolFormPanel({ panelId: "extuiNavReminderPanel", title: "Lembrete", toolId: "lembrete", hint: "Programe um lembrete ligado ao contato atual.", fields: [{ name: "text", label: "Texto", required: true }, { name: "at", label: "Data e hora", type: "datetime-local", required: true }], submitLabel: "Criar lembrete", showResult: false, resetOnSuccess: true, successToast: "Lembrete criado.", onSubmit: function (c) { var at=parseLocalDateTimeStrict(c.at.value);if(!Number.isFinite(at))throw new Error("Data ou horário local inválido.");return invokeCapability("lembrete", { text: c.text.value, at: at }); } }); }
    function buildGoogleCalendarPanel() { return standaloneToolFormPanel({ panelId: "extuiNavGoogleCalendarPanel", title: "Google Calendar", toolId: "google_calendario", hint: "Crie um compromisso no Google Calendar a partir da conversa.", fields: [{ name: "title", label: "Título", required: true }, { name: "start", label: "Início", type: "datetime-local", required: true }, { name: "end", label: "Fim", type: "datetime-local" }], submitLabel: "Abrir no Google Calendar", showResult: false, successToast: "Google Calendar aberto.", onSubmit: function (c) { var start=parseLocalDateTimeStrict(c.start.value),end=c.end.value?parseLocalDateTimeStrict(c.end.value):null;if(!Number.isFinite(start)||c.end.value&&!Number.isFinite(end))throw new Error("Data ou horário local inválido.");if(Number.isFinite(end)&&end<=start)throw new Error("O término precisa ser posterior ao início.");return invokeCapability("google_calendario", { title: c.title.value, start: start, end: end, open: true }); } }); }
    function buildTextAssistantPanel() { return standaloneToolFormPanel({ panelId: "extuiNavTextAssistantPanel", title: "Assistente de texto", toolId: "chat_assistant", hint: "Corrija e melhore um texto antes de enviar.", fields: [{ name: "text", label: "Texto", type: "textarea", required: true }], submitLabel: "Melhorar texto", insertResult: true, successToast: "Texto processado.", onSubmit: function (c) { return invokeCapability("chat_assistant", { text: c.text.value }); } }); }
    function buildTextReplacePanel() { return standaloneToolFormPanel({ panelId: "extuiNavTextReplacePanel", title: "Substituição de texto", toolId: "replace_text", hint: "Crie atalhos que expandem automaticamente para textos completos.", fields: [{ name: "from", label: "Atalho", required: true }, { name: "to", label: "Substituir por", type: "textarea", required: true }], submitLabel: "Salvar substituição", showResult: false, resetOnSuccess: true, successToast: "Substituição salva.", onSubmit: async function (c) { var st = await invokeCapability("replace_text", {}), items = st && st.items || []; items.push({ id: "rule-" + Date.now(), from: c.from.value, to: c.to.value, active: true }); return invokeCapability("replace_text", { action: "save", value: { items: items, isEnabled: true } }); } }); }
    function buildGlobalLabelsPanel() {
      var labelsIcon = '<path d="M4 4h6l8 8-6 6-8-8z"/><path d="M9 3h5l7 7-5 5"/><circle cx="7.5" cy="7.5" r="1"/>';
      var root = buildPanelShell({ panelId: "extuiNavLabelsPanel", id: "extuiNavLabelsPanel", title: "Etiquetas", accent: "#22c55e", icon: labelsIcon, eyebrow: "WHATSAPP BUSINESS", hint: "Gerencie as etiquetas disponíveis na sua conta.", size: "sm", tutorialKey: "ferramentas" });
      var body = panelBody(root); body.textContent = ""; root.classList.add("extuiGlobalLabelsPanel");
      var intro = document.createElement("div"); intro.className = "extuiGlobalLabelsIntro";
      var introCopy = document.createElement("div");
      var introTitle = document.createElement("strong"); introTitle.textContent = "Etiquetas da conta";
      var introText = document.createElement("span"); introText.textContent = "Renomeie ou exclua etiquetas globais. Para aplicar etiquetas ao contato aberto, use Cliente → Etiquetas.";
      introCopy.appendChild(introTitle); introCopy.appendChild(introText); intro.appendChild(introCopy);
      var toolbar = document.createElement("div"); toolbar.className = "extuiGlobalLabelsToolbar";
      var search = document.createElement("input"); search.type = "search"; search.className = "extuiNavFormInput"; search.placeholder = "Buscar etiqueta..."; search.setAttribute("aria-label", "Buscar etiqueta");
      var count = document.createElement("span"); count.className = "extuiGlobalLabelsCount"; count.textContent = "0 etiquetas";
      toolbar.appendChild(search); toolbar.appendChild(count); body.appendChild(intro); body.appendChild(toolbar);
      var list = document.createElement("div"); list.className = "extuiGlobalLabelsList"; body.appendChild(list); var labels = [];
      function bridge() { if (!window.ExtensionChatBridge || !window.ExtensionChatBridge.isReady || !window.ExtensionChatBridge.labels) throw new Error("O WhatsApp ainda não está pronto para carregar as etiquetas."); return window.ExtensionChatBridge.labels; }
      function render() {
        var query = String(search.value || "").trim().toLocaleLowerCase("pt-BR");
        var visible = labels.filter(function (label) { return !query || String(label && label.name || "").toLocaleLowerCase("pt-BR").indexOf(query) >= 0; });
        count.textContent = labels.length + (labels.length === 1 ? " etiqueta" : " etiquetas"); list.textContent = "";
        if (!visible.length) { list.appendChild(emptyState(query ? "Nenhuma etiqueta encontrada." : "Nenhuma etiqueta disponível na conta.")); return; }
        visible.forEach(function (label) {
          var row = document.createElement("article"); row.className = "extuiGlobalLabelRow";
          var swatch = document.createElement("span"); swatch.className = "extuiGlobalLabelSwatch"; swatch.style.background = String(label.hexColor || "#64748b");
          var input = document.createElement("input"); input.type = "text"; input.className = "extuiNavFormInput extuiGlobalLabelName"; input.value = String(label.name || ""); input.maxLength = 100; input.setAttribute("aria-label", "Nome da etiqueta " + String(label.name || ""));
          var actions = document.createElement("div"); actions.className = "extuiGlobalLabelActions";
          var save = document.createElement("button"); save.type = "button"; save.className = "extuiIconBtn"; save.title = "Salvar nome"; save.setAttribute("aria-label", "Salvar nome"); save.textContent = "✓";
          var remove = document.createElement("button"); remove.type = "button"; remove.className = "extuiIconBtn extuiGlobalLabelDelete"; remove.title = "Excluir etiqueta"; remove.setAttribute("aria-label", "Excluir etiqueta"); remove.textContent = "×";
          save.addEventListener("click", async function () { var name = input.value.trim(); if (!name) { toast("Informe um nome para a etiqueta.", true); return; } if (name === String(label.name || "")) return; save.disabled = true; try { await bridge().editLabel(label.id, { name: name }); label.name = name; toast("Etiqueta renomeada."); render(); } catch (e) { toast(e && e.message || "Não foi possível renomear a etiqueta.", true); } finally { save.disabled = false; } });
          remove.addEventListener("click", async function () { var ok = typeof window.extConfirm === "function" ? await window.extConfirm('Excluir a etiqueta "' + String(label.name || "") + '"? Isso a remove de todas as conversas.', { danger: true }) : window.confirm("Excluir esta etiqueta?"); if (!ok) return; remove.disabled = true; try { await bridge().deleteLabel(label.id); labels = labels.filter(function (candidate) { return String(candidate.id) !== String(label.id); }); toast("Etiqueta excluída."); render(); } catch (e) { toast(e && e.message || "Não foi possível excluir a etiqueta.", true); } finally { remove.disabled = false; } });
          actions.appendChild(save); actions.appendChild(remove); row.appendChild(swatch); row.appendChild(input); row.appendChild(actions); list.appendChild(row);
        });
      }
      async function reload() {
        list.textContent = "";
        var loading = document.createElement("div"); loading.className = "extuiPanelLoading"; loading.textContent = "Carregando etiquetas..."; list.appendChild(loading);
        try { labels = await bridge().getAllLabels(); labels = Array.isArray(labels) ? labels.slice().sort(function (a,b) { return String(a && a.name || "").localeCompare(String(b && b.name || ""), "pt-BR"); }) : []; render(); } catch (e) { list.textContent = ""; list.appendChild(emptyState(e && e.message || "Não foi possível carregar as etiquetas.")); }
      }
      search.addEventListener("input", render); panelState.setRefresh(root, reload); reload(); return root;
    }

    async function buildSignaturePanel() {
      var meta = chatToolMeta.signature, root = buildPanelShell({ id: "extuiNavSignaturePanel", title: "Assinatura", accent: meta.accent, icon: meta.icon, eyebrow: "Conversa", hint: "Crie, edite e insira assinaturas diretamente no campo de mensagem.", size: "sm", tutorialKey: "ferramentas" }), body = panelBody(root); body.innerHTML = "";
      var editingId = "";
      async function render() {
        body.innerHTML = "";
        var list = await invokeCapability("signature", {});
        list = Array.isArray(list) ? list : [];
        var form = document.createElement("form"); form.className = "extuiCrmQuickComposer extuiToolForm extuiStandaloneToolForm extuiSignatureManager";
        var signatureName = document.createElement("input"); signatureName.type = "text"; signatureName.maxLength = 120; signatureName.placeholder = "Ex.: Comercial";
        var signatureText = document.createElement("textarea"); signatureText.maxLength = 5000; signatureText.required = true; signatureText.placeholder = "Texto da assinatura";
        var saveButton = document.createElement("button"); saveButton.type = "submit"; saveButton.className = "extuiNavPrimaryBtn"; saveButton.textContent = editingId ? "Salvar assinatura" : "Adicionar assinatura";
        form.appendChild(field("Título", signatureName)); form.appendChild(field("Assinatura", signatureText)); form.appendChild(saveButton); body.appendChild(form);
        var cancelEdit = document.createElement("button"); cancelEdit.type = "button"; cancelEdit.className = "extuiNavSecondaryBtn"; cancelEdit.textContent = "Cancelar edição"; cancelEdit.hidden = !editingId; form.appendChild(cancelEdit);
        if (editingId) { var editing = list.find(function (item) { return String(item && item.id) === editingId; }); if (editing) { signatureName.value = String(editing.name || editing.title || ""); signatureText.value = String(editing.text || editing.texto || editing.value || ""); } else editingId = ""; }
        cancelEdit.addEventListener("click", function () { editingId = ""; render().catch(function (e) { toast(e && e.message || "Não foi possível atualizar as assinaturas.", true); }); });
        form.addEventListener("submit", async function (ev) { ev.preventDefault(); saveButton.disabled = true; try { await invokeCapability("signature", { action: "save", value: { id: editingId || undefined, title: signatureName.value, text: signatureText.value } }); editingId = ""; toast("Assinatura salva."); await render(); } catch (e) { toast(e && e.message || "Não foi possível salvar a assinatura.", true); } finally { saveButton.disabled = false; } });
        if (!list.length) { body.appendChild(emptyState(meta.accent, meta.icon, "Nenhuma assinatura", "Crie sua primeira assinatura acima para inseri-la rapidamente nas conversas.", null, null, { sober: true })); return; }
        list.forEach(function (sig) {
          var row = document.createElement("div"); row.className = "extuiDockedPanelRow extSystemMenuRow extuiSignatureDirectRow";
          var label = String(sig.name || sig.title || sig.text || "Assinatura");
          row.innerHTML = '<span class="extuiSystemMenuIcon">' + iconChip(meta.accent, meta.icon, true) + '</span><span class="extuiSystemMenuText"><span class="title">' + escHtml(label) + '</span><span class="desc">Inserir na conversa</span></span>';
          var insertButton = document.createElement("button"); insertButton.type = "button"; insertButton.className = "extuiNavSecondaryBtn"; insertButton.textContent = "Inserir";
          var editButton = document.createElement("button"); editButton.type = "button"; editButton.className = "extuiIconBtn"; editButton.title = "Editar assinatura"; editButton.setAttribute("aria-label", "Editar assinatura"); editButton.textContent = "✎";
          var removeButton = document.createElement("button"); removeButton.type = "button"; removeButton.className = "extuiIconBtn"; removeButton.title = "Excluir assinatura"; removeButton.setAttribute("aria-label", "Excluir assinatura"); removeButton.textContent = "×";
          insertButton.addEventListener("click", async function () { insertButton.disabled = true; try { await invokeCapability("signature", { id: sig.id, insert: true }); toast("Assinatura inserida."); } catch (e) { toast(e && e.message || "Não foi possível inserir a assinatura.", true); } finally { insertButton.disabled = false; } });
          editButton.addEventListener("click", function () { editingId = String(sig.id || ""); render().catch(function (e) { toast(e && e.message || "Não foi possível editar a assinatura.", true); }); });
          removeButton.addEventListener("click", async function () { var confirmed = typeof window.extConfirm === "function" ? await window.extConfirm('Excluir a assinatura "' + label + '"?', { danger: true }) : window.confirm('Excluir a assinatura "' + label + '"?'); if (!confirmed) return; removeButton.disabled = true; try { await invokeCapability("signature", { action: "remove", id: sig.id }); if (editingId === String(sig.id || "")) editingId = ""; toast("Assinatura excluída."); await render(); } catch (e) { toast(e && e.message || "Não foi possível excluir a assinatura.", true); } finally { removeButton.disabled = false; } });
          row.appendChild(insertButton); row.appendChild(editButton); row.appendChild(removeButton); body.appendChild(row);
        });
      }
      panelState.setRefresh(root, render); await render(); return root;
    }

    return Object.freeze({
      buildNotesPanel: buildNotesPanel,
      buildReminderPanel: buildReminderPanel,
      buildGoogleCalendarPanel: buildGoogleCalendarPanel,
      buildSignaturePanel: buildSignaturePanel,
      buildTextAssistantPanel: buildTextAssistantPanel,
      buildTextReplacePanel: buildTextReplacePanel,
      buildGlobalLabelsPanel: buildGlobalLabelsPanel
    });
  };
})();
