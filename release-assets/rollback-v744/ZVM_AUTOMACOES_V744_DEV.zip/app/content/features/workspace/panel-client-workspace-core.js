;(function(){
  "use strict";
  if(window.__extCreateClientWorkspaceCore)return;
  window.__extCreateClientWorkspaceCore=function(deps){
    deps=deps||{};
    var chatWorkspaceRegistry=deps.registry,extOpenChatWorkspace=deps.openChatWorkspace,extGetActiveContactContext=deps.getActiveContactContext,extRenderQuickClientContent=deps.renderQuickClientContent,escHtml=deps.escHtml,toast=deps.toast;
    var extOpenCrmWorkspace=deps.openCrmWorkspace,extOpenLabelsWorkspace=deps.openLabelsWorkspace,extOpenOrdersWorkspace=deps.openOrdersWorkspace,extOpenNotesWorkspace=deps.openNotesWorkspace,extOpenAgendaWorkspace=deps.openAgendaWorkspace;
    if(!chatWorkspaceRegistry||typeof chatWorkspaceRegistry.portalInto!=="function"||typeof chatWorkspaceRegistry.clearPortal!=="function"||typeof chatWorkspaceRegistry.setDisposer!=="function"||typeof chatWorkspaceRegistry.openForPortal!=="function"||[extOpenChatWorkspace,extGetActiveContactContext,extRenderQuickClientContent,escHtml,toast,extOpenCrmWorkspace,extOpenLabelsWorkspace,extOpenOrdersWorkspace,extOpenNotesWorkspace,extOpenAgendaWorkspace].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do workspace do cliente inválidas.");
    var hubStates=new WeakMap();

    async function extPortalChatWorkspaceInto(key,opener,host){
      key=String(key||"");
      await chatWorkspaceRegistry.openForPortal(key,opener);
      var child=chatWorkspaceRegistry.get(key);
      if(!child)throw new Error("Painel "+key+" indisponível.");
      chatWorkspaceRegistry.portalInto(key,host);
      chatWorkspaceRegistry.deactivateForPortal(key);
      return child;
    }

    async function extOpenClientWorkspace(){
      var ws=extOpenChatWorkspace({key:"client",title:"Cliente",eyebrow:"Atendimento",accent:"#00a884",icon:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',subtitle:"Cadastro e visão completa do cliente da conversa atual"});
      var existing=hubStates.get(ws);
      if(ws.reused&&existing&&typeof existing.activate==="function"){
        await existing.activate(existing.tab||"cadastro");
        return {ok:true,active:true,workspace:"client"};
      }

      var hub=document.createElement("div");hub.className="extuiClientHub";
      var tabs=document.createElement("div");tabs.className="extuiClientHubTabs";tabs.setAttribute("role","tablist");
      var stage=document.createElement("div");stage.className="extuiClientHubStage";
      hub.appendChild(tabs);hub.appendChild(stage);ws.body.appendChild(hub);

      var state={tab:"cadastro",refreshTimer:0,eventBusOff:null,activate:null,activationSeq:0},panes=Object.create(null),tabButtons=Object.create(null);
      hubStates.set(ws,state);
      var defs=[
        ["cadastro","Cadastro",null],
        ["crm","CRM",function(host){return extPortalChatWorkspaceInto("crm",extOpenCrmWorkspace,host);}],
        ["labels","Etiquetas",function(host){return extPortalChatWorkspaceInto("labels",extOpenLabelsWorkspace,host);}],
        ["orders","Encomendas",function(host){return extPortalChatWorkspaceInto("orders",extOpenOrdersWorkspace,host);}],
        ["notes","Notas",function(host){return extPortalChatWorkspaceInto("notes",extOpenNotesWorkspace,host);}],
        ["agenda","Agenda",function(host){return extPortalChatWorkspaceInto("agenda",extOpenAgendaWorkspace,host);}] 
      ];

      function commitTab(key){
        Object.keys(tabButtons).forEach(function(k){
          var on=k===key;
          tabButtons[k].classList.toggle("is-active",on);
          tabButtons[k].setAttribute("aria-selected",String(on));
          panes[k].hidden=!on;
        });
      }

      defs.forEach(function(def,index){
        var btn=document.createElement("button");btn.type="button";btn.className="extuiClientHubTab";btn.textContent=def[1];btn.dataset.tab=def[0];btn.setAttribute("role","tab");btn.setAttribute("aria-selected",String(index===0));
        tabs.appendChild(btn);tabButtons[def[0]]=btn;
        var pane=document.createElement("section");pane.className="extuiClientHubPane";pane.dataset.tabPane=def[0];pane.hidden=index!==0;pane.setAttribute("role","tabpanel");
        stage.appendChild(pane);panes[def[0]]=pane;
        btn.addEventListener("click",function(){activate(def[0]).catch(function(err){toast(err&&err.message||"Não foi possível abrir esta aba.",true);});});
      });

      async function reloadCadastro(force){
        var pane=panes.cadastro;if(!pane)return false;
        var ctx=null;try{ctx=await extGetActiveContactContext();}catch(_){ctx=null;}
        var chatId=ctx&&ctx.chatId?String(ctx.chatId):"";
        if(!force&&pane.dataset.loaded==="1"&&pane.dataset.chatId===chatId&&chatId)return true;
        pane.dataset.chatId=chatId;
        try{
          await extRenderQuickClientContent(pane);
          pane.dataset.loaded="1";pane.dataset.ready="1";
        }catch(err){
          pane.dataset.loaded="";pane.dataset.ready="";
          pane.innerHTML='<div class="extuiChatWorkspaceEmpty"><strong>Cliente indisponível</strong><span>'+escHtml(err&&err.message||"Recarregue o WhatsApp Web e tente novamente.")+'</span></div>';
        }
        return true;
      }

      function resetPortaledWorkspace(key,pane){
        var child=chatWorkspaceRegistry.clearPortal(key);
        if(child){
          try{if(child.overlay&&child.overlay.isConnected)child.overlay.remove();}catch(_){}
          chatWorkspaceRegistry.removePortaled(key);
        }
        if(pane){pane.innerHTML="";pane.dataset.chatId="";pane.dataset.ready="";}
      }

      async function prepareTab(key,forceContextRefresh){
        var pane=panes[key],def=defs.find(function(x){return x[0]===key;});
        if(!pane||!def)throw new Error("Aba do cliente indisponível.");
        if(key==="cadastro")return reloadCadastro(!!forceContextRefresh);
        var currentCtx=null;try{currentCtx=await extGetActiveContactContext();}catch(_){}
        var currentChatId=currentCtx&&currentCtx.chatId?String(currentCtx.chatId):"";
        var stale=forceContextRefresh||pane.dataset.chatId!==currentChatId;
        if(!stale&&pane.dataset.ready==="1"){
          var cachedChild=chatWorkspaceRegistry.get(key);
          if(cachedChild){
            chatWorkspaceRegistry.portalInto(key,pane);
            chatWorkspaceRegistry.deactivateForPortal(key);
            if(pane.childNodes&&pane.childNodes.length)return true;
          }
          pane.dataset.ready="";
        }
        if(pane.dataset.ready==="1"||chatWorkspaceRegistry.get(key))resetPortaledWorkspace(key,pane);
        pane.dataset.chatId=currentChatId;
        if(def[2])await def[2](pane);
        pane.dataset.ready="1";
        return true;
      }

      async function activate(key,forceContextRefresh){
        var requested=String(key||"cadastro");
        if(!panes[requested])requested="cadastro";
        if(!forceContextRefresh&&requested===state.tab&&panes[requested].dataset.ready==="1"){
          await prepareTab(requested,false);
          commitTab(requested);return true;
        }
        var seq=++state.activationSeq;
        await prepareTab(requested,!!forceContextRefresh);
        if(seq!==state.activationSeq)return false;
        state.tab=requested;
        commitTab(requested);
        return true;
      }

      state.activate=activate;
      commitTab("cadastro");
      if(window.__extEventBus&&typeof window.__extEventBus.on==="function")state.eventBusOff=window.__extEventBus.on("ActiveChatChanged",function(){
        if(!ws.overlay||!document.body.contains(ws.overlay))return;
        clearTimeout(state.refreshTimer);
        state.refreshTimer=setTimeout(function(){activate(state.tab||"cadastro",true).catch(function(){});},140);
      });
      chatWorkspaceRegistry.setDisposer("client",function(){
        if(state.refreshTimer){clearTimeout(state.refreshTimer);state.refreshTimer=0;}
        if(typeof state.eventBusOff==="function"){try{state.eventBusOff();}catch(_){}}
        state.eventBusOff=null;hubStates.delete(ws);
      });
      await activate("cadastro");
      return {ok:true,active:true,workspace:"client"};
    }
    return Object.freeze({portalInto:extPortalChatWorkspaceInto,open:extOpenClientWorkspace});
  };
})();
