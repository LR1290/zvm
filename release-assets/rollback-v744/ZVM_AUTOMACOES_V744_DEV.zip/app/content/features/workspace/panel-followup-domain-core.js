;(function () {
  "use strict";
  if (window.__extCreateFollowUpPanelDomainCore) return;
  window.__extCreateFollowUpPanelDomainCore = function (deps) {
    deps = deps || {};
    var get=deps.get,set=deps.set,parsePersisted=deps.parsePersisted,buildPanelShell=deps.buildPanelShell,panelBrand=deps.panelBrand||{},field=deps.field,buildSwitch=deps.buildSwitch,formSection=deps.formSection,agendaItemStores=deps.agendaItemStores||{},quickItemsRecentsKey=deps.quickItemsRecentsKey,appendPrioritizedItemOptions=deps.appendPrioritizedItemOptions,crmKey=deps.crmKey,emptyState=deps.emptyState,escHtml=deps.escHtml,toast=deps.toast,panelOnKeyChange=deps.panelOnKeyChange,iconChip=deps.iconChip;
    var followUpKey=deps.followUpKey||"EXTUI:extappFollowUpStore", followUpQueueKey=deps.followUpQueueKey||"EXTUI:extappFollowUpQueueStore";
    if ([get,set,parsePersisted,buildPanelShell,field,buildSwitch,formSection,appendPrioritizedItemOptions,emptyState,escHtml,toast,panelOnKeyChange,iconChip].some(function(fn){return typeof fn!=="function";})) throw new TypeError("Dependências do domínio FollowUp inválidas.");
    async function loadFollowUpRules() {
      var raw = await get(followUpKey);
      var state = parsePersisted(raw);
      return (state && state.followUpList) || [];
    }
    
    async function saveFollowUpRules(list) { await set(followUpKey, JSON.stringify({ state: { followUpList: list }, version: 0 })); }
    
    async function loadFollowUpQueue() {
      var raw = await get(followUpQueueKey);
      var state = parsePersisted(raw);
      return (state && state.queue) || [];
    }
    
    async function saveFollowUpQueue(queue) { await set(followUpQueueKey, JSON.stringify({ state: { queue: queue }, version: 0 })); }
    
    
    function fmtTiming(t) {
      var parts = [];
      if (t.days) parts.push(t.days + "d");
      if (t.hours) parts.push(t.hours + "h");
      if (t.minutes) parts.push(t.minutes + "min");
      return parts.length ? parts.join(" ") : "0min";
    }
    
    
    async function buildFollowUpPanel() {
      var root = buildPanelShell({ id: "extuiNavFollowUpPanel", title: "FollowUp", accent: panelBrand.followup.accent, icon: panelBrand.followup.icon, eyebrow: "Automação", hint: "Dispare ações quando um contato parar no CRM.", size: "md" });
      var body = root.querySelector(".extuiNavPanelBody");
    
      var formWrap = document.createElement("div");
      formWrap.className = "extuiFollowUpForm extuiPanelFormSurface";
      var nameInput = document.createElement("input"); nameInput.type = "text"; nameInput.placeholder = "Ex: Reengajar sem resposta";
      var crmSelect = document.createElement("select");
      var columnSelect = document.createElement("select");
      var triggerSelect = document.createElement("select");
      triggerSelect.appendChild(new Option("Depois de um tempo parado na coluna", "timing"));
      triggerSelect.appendChild(new Option("Assim que entrar na coluna", "onEnter"));
      var timingRow = document.createElement("div");
      timingRow.className = "delayPairRow";
      timingRow.style.display = "flex"; timingRow.style.gap = "8px";
      var daysInput = document.createElement("input"); daysInput.type = "number"; daysInput.min = "0"; daysInput.value = "0"; daysInput.title = "Dias";
      var hoursInput = document.createElement("input"); hoursInput.type = "number"; hoursInput.min = "0"; hoursInput.value = "0"; hoursInput.title = "Horas";
      var minutesInput = document.createElement("input"); minutesInput.type = "number"; minutesInput.min = "0"; minutesInput.value = "30"; minutesInput.title = "Minutos";
      [["Dias", daysInput], ["Horas", hoursInput], ["Minutos", minutesInput]].forEach(function (pair) {
        var wrap = document.createElement("div"); wrap.style.flex = "1"; wrap.style.display = "flex"; wrap.style.flexDirection = "column"; wrap.style.gap = "3px";
        if(!pair[1].id)pair[1].id="extui-followup-time-"+pair[0].toLowerCase();
        pair[1].setAttribute("aria-label",pair[0]+" de espera");
        var lab = document.createElement("label"); lab.setAttribute("for",pair[1].id);lab.textContent = pair[0]; lab.style.fontSize = "var(--extui-text-label-size, 13px)"; lab.style.color = "var(--extui-text-dim, #a0a0a0)";
        wrap.appendChild(lab); wrap.appendChild(pair[1]); timingRow.appendChild(wrap);
      });
      async function filterFollowMedia(cfg,list){if(!cfg||!cfg.virtualMediaKind)return list||[];var out=[];for(var i=0;i<(list||[]).length;i++){var item=list[i],kind=String(item&&item.mediaKind||"");if(kind!=="image"&&kind!=="video"){try{var raw=await get(String(item.id)),c=raw?(typeof raw==="string"?JSON.parse(raw):raw):{},mime=String(c.mimeType||c.type||"").toLowerCase(),name=String(c.fileName||c.name||item.name||"").toLowerCase(),data=String(c.data||c.base64||"");kind=c.mediaKind||(/^data:video\//i.test(data)||mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name)?"video":"image");}catch(_){kind="image";}}if(kind===cfg.virtualMediaKind)out.push(item);}return out;}
      var sendTypeSelect = document.createElement("select");
      Object.keys(agendaItemStores).filter(function(t){return !agendaItemStores[t].legacyOnly;}).forEach(function (t) { sendTypeSelect.appendChild(new Option(agendaItemStores[t].label, t)); });
      var itemSelect = document.createElement("select");
      var cancelRow = document.createElement("div");
      cancelRow.className = "extuiNavToggleRow";
      cancelRow.innerHTML = '<div class="extuiNavToggleText"><div class="title">Cancelar se responder</div><div class="desc">Se o contato mandar mensagem antes do disparo, a regra não dispara para ele.</div></div>';
      var cancelOnReplyValue = true;
      var cancelSwitch = buildSwitch(cancelOnReplyValue, function (next) { cancelOnReplyValue = next; return true; });
      cancelSwitch.setAttribute("aria-label","Cancelar se o contato responder");
      cancelRow.appendChild(cancelSwitch);
      var createBtn = document.createElement("button"); createBtn.type = "button"; createBtn.className = "extuiNavPrimaryBtn"; createBtn.textContent = "Criar regra";
    
    
      var identityBlock = document.createElement("section"); identityBlock.className = "extuiPanelFormBlock extuiFollowUpBlock extuiFollowUpBlock--identity";
      identityBlock.appendChild(formSection("Identificação", "Dê um nome claro para localizar esta automação."));
      var followNameField = field("Nome da regra", nameInput); followNameField.classList.add("extuiFollowUpField", "extuiFollowUpField--name"); identityBlock.appendChild(followNameField);
      var destinationBlock = document.createElement("section"); destinationBlock.className = "extuiPanelFormBlock extuiFollowUpBlock extuiFollowUpBlock--destination";
      destinationBlock.appendChild(formSection("Destino", "Escolha o CRM e a etapa observada pela regra."));
      var crmColumnRow = document.createElement("div"); crmColumnRow.className = "extuiFieldRow extuiFollowUpDestinationGrid";
      var crmField = field("CRM", crmSelect); var columnField = field("Coluna", columnSelect, "A regra observa contatos parados nesta coluna do CRM escolhido."); crmColumnRow.appendChild(crmField); crmColumnRow.appendChild(columnField); destinationBlock.appendChild(crmColumnRow);
      var timingBlock = document.createElement("section"); timingBlock.className = "extuiPanelFormBlock extuiFollowUpBlock extuiFollowUpBlock--timing";
      timingBlock.appendChild(formSection("Gatilho e tempo", "Defina quando o contato entra na fila de FollowUp."));
      var followTriggerField = field("Quando disparar", triggerSelect); followTriggerField.classList.add("extuiFollowUpField", "extuiFollowUpField--trigger"); timingBlock.appendChild(followTriggerField); timingRow.classList.add("extuiFollowUpTimingGrid"); timingBlock.appendChild(timingRow);
      var timingHelper = document.createElement("div"); timingHelper.className = "extuiFieldHelper"; timingHelper.textContent = "Tempo que o contato precisa ficar parado na coluna antes do disparo automático."; timingBlock.appendChild(timingHelper);
      var contentBlock = document.createElement("section"); contentBlock.className = "extuiPanelFormBlock extuiFollowUpBlock extuiFollowUpBlock--content";
      contentBlock.appendChild(formSection("Conteúdo", "Escolha o tipo e o item que será enviado automaticamente."));
      var followContentGrid = document.createElement("div"); followContentGrid.className = "extuiFieldRow extuiFollowUpContentGrid"; followContentGrid.appendChild(field("Tipo", sendTypeSelect)); followContentGrid.appendChild(field("Item/Funil", itemSelect)); contentBlock.appendChild(followContentGrid);
      var behaviorBlock = document.createElement("section"); behaviorBlock.className = "extuiPanelFormBlock extuiFollowUpBlock extuiFollowUpBlock--behavior";
      behaviorBlock.appendChild(formSection("Comportamento", "Controle o cancelamento automático antes do disparo.")); cancelRow.classList.add("extuiPanelToggleCard"); behaviorBlock.appendChild(cancelRow); createBtn.classList.add("extuiPanelSubmitBtn"); behaviorBlock.appendChild(createBtn);
      formWrap.appendChild(identityBlock); formWrap.appendChild(destinationBlock); formWrap.appendChild(timingBlock); formWrap.appendChild(contentBlock); formWrap.appendChild(behaviorBlock); body.appendChild(formWrap);
      var listEl = document.createElement("div"); listEl.className = "extuiNavAgendaList extuiFollowUpRules"; body.appendChild(listEl);
    
      function syncTimingVisibility() {
        var show = triggerSelect.value === "timing";
        timingRow.style.display = show ? "flex" : "none";
        timingHelper.style.display = show ? "block" : "none";
      }
      triggerSelect.addEventListener("change", syncTimingVisibility);
      syncTimingVisibility();
    
      var _crmList = [];
      async function loadCrmListForFollowUp() {
        var raw = await get(crmKey);
        var parsed = null;
        try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; }
        catch (_) { parsed = null; }
        return (parsed && parsed.state && parsed.state.crmList) || [];
      }
      async function refreshCrmOptions() {
        crmSelect.innerHTML = "";
        try {
          _crmList = await loadCrmListForFollowUp();
          if (_crmList.length === 0) { crmSelect.appendChild(new Option("Nenhum CRM criado", "")); columnSelect.innerHTML = ""; columnSelect.appendChild(new Option("—", "")); return; }
          _crmList.forEach(function (c) { crmSelect.appendChild(new Option(c.name || c.id, c.id)); });
          refreshColumnOptions();
        } catch (err) { crmSelect.appendChild(new Option("Erro ao carregar", "")); }
      }
      function refreshColumnOptions() {
        columnSelect.innerHTML = "";
        var crm = _crmList.find(function (c) { return c.id === crmSelect.value; });
        var columns = (crm && crm.columns) || [];
        if (columns.length === 0) { columnSelect.appendChild(new Option("Sem colunas", "")); return; }
    
    
        columns.forEach(function (col) { columnSelect.appendChild(new Option(col.title || "(sem nome)", col.id)); });
      }
      crmSelect.addEventListener("change", refreshColumnOptions);
    
      async function refreshItemOptions() {
        itemSelect.innerHTML = "";
        var cfg = agendaItemStores[sendTypeSelect.value];
        try {
          var values = await Promise.all([get(cfg.key), get(quickItemsRecentsKey)]);
          var raw = values[0];
          var state = parsePersisted(raw);
          var list = (state && state[cfg.listField]) || [];
          list = await filterFollowMedia(cfg,list);
          if (list.length === 0) { itemSelect.appendChild(new Option("Nenhum item salvo", "")); return; }
          appendPrioritizedItemOptions(itemSelect, sendTypeSelect.value, list, values[1]);
        } catch (err) { itemSelect.appendChild(new Option("Erro ao carregar", "")); }
      }
      sendTypeSelect.addEventListener("change", refreshItemOptions);
      refreshCrmOptions();
      refreshItemOptions();
    
      async function renderList() {
        listEl.innerHTML = '<div class="extuiSideItensEmpty">Carregando...</div>';
        var rules, queue;
        try { rules = await loadFollowUpRules(); queue = await loadFollowUpQueue(); }
        catch (err) { listEl.innerHTML = '<div class="extuiSideItensEmpty">Erro ao carregar</div>'; return; }
        if (rules.length === 0) { listEl.innerHTML = ""; listEl.appendChild(emptyState(panelBrand.followup.accent, panelBrand.followup.icon, "Nenhuma regra criada", "Crie uma regra acima para disparar automaticamente quando um contato ficar parado numa coluna do CRM.", null, null, { sober: true })); return; }
        listEl.innerHTML = "";
        rules.forEach(function (rule) {
          var crm = _crmList.find(function (c) { return c.id === rule.source.crmId; });
          var column = crm && crm.columns && crm.columns.find(function (c) { return c.id === rule.source.columnId; });
          var ruleQueue = queue.filter(function (q) { return q.followUpId === rule.id; });
          var pendingCount = ruleQueue.filter(function (q) { return q.status === "pending"; }).length;
          var sentCount = ruleQueue.filter(function (q) { return q.status === "sent"; }).length;
          var row = document.createElement("div");
          row.className = "extuiNavAgendaRow";
          row.innerHTML = iconChip(panelBrand.followup.accent, panelBrand.followup.icon, true) +
            '<div class="extuiNavAgendaRowMid"><div class="name">' + escHtml(rule.nome) + '</div>' +
    
    
            '<div class="meta">' + escHtml((crm && crm.name) || "CRM indisponível") + " → " + escHtml((column && column.title) || "Lista indisponível") +
            " · " + (rule.acionamento.type === "onEnter" ? "na entrada" : "após " + escHtml(fmtTiming(rule.acionamento.timing))) +
            '</div><div class="meta">' + pendingCount + " aguardando · " + sentCount + " enviado(s)</div></div>";
          var sw = buildSwitch(rule.active, async function (next, previous) {
            var nextRules = rules.map(function (candidate) {
              return candidate && candidate.id === rule.id ? Object.assign({}, candidate, { active: next }) : candidate;
            });
            try {
              await saveFollowUpRules(nextRules);
              rules = nextRules;
              rule.active = next;
              if (sw) sw.setAttribute("aria-label", (next ? "Desativar " : "Ativar ") + "regra " + String(rule.nome || "FollowUp"));
              toast(next ? "Regra ativada!" : "Regra desativada.");
              return true;
            } catch (err) {
              rule.active = previous;
              toast("Falha ao salvar", true);
              return false;
            }
          });
          sw.setAttribute("aria-label",(rule.active?"Desativar ":"Ativar ")+"regra "+String(rule.nome||"FollowUp"));
          row.appendChild(sw);
          var delBtn = document.createElement("button");
          delBtn.type = "button"; delBtn.className = "extuiNavAgendaCancelBtn"; delBtn.textContent = "Excluir";
          delBtn.addEventListener("click", async function () {
            if (!await window.extConfirm('Excluir a regra "' + rule.nome + '"? A fila de contatos aguardando dela também é removida.', { danger: true })) return;
            try {
              var freshRules = (await loadFollowUpRules()).filter(function (r) { return r.id !== rule.id; });
              await saveFollowUpRules(freshRules);
              var freshQueue = (await loadFollowUpQueue()).filter(function (q) { return q.followUpId !== rule.id; });
              await saveFollowUpQueue(freshQueue);
              toast("Regra excluída.");
              renderList();
            } catch (err) { toast("Falha ao excluir", true); }
          });
          row.appendChild(delBtn);
          listEl.appendChild(row);
        });
      }
      renderList();
      panelOnKeyChange(root, followUpKey, function () { if (root.classList.contains("extuiOpen")) renderList(); });
      panelOnKeyChange(root, followUpQueueKey, function () { if (root.classList.contains("extuiOpen")) renderList(); });
    
      createBtn.addEventListener("click", async function () {
        var nome = nameInput.value.trim();
        if (!nome) { toast("Dê um nome para a regra", true); return; }
        if (!crmSelect.value || !columnSelect.value) { toast("Escolha o CRM e a coluna", true); return; }
        if (!itemSelect.value) { toast("Escolha o que enviar", true); return; }
        createBtn.disabled = true;
        try {
          var rules = await loadFollowUpRules();
          rules.push({
            id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
            nome: nome,
            active: true,
            source: { crmId: crmSelect.value, columnId: columnSelect.value },
            acionamento: { type: triggerSelect.value, timing: { days: parseInt(daysInput.value, 10) || 0, hours: parseInt(hoursInput.value, 10) || 0, minutes: parseInt(minutesInput.value, 10) || 0 } },
            sendType: sendTypeSelect.value,
            itemId: itemSelect.value,
            cancelOnReply: cancelOnReplyValue
          });
          await saveFollowUpRules(rules);
          nameInput.value = "";
          renderList();
        } catch (err) { toast("Falha ao criar regra", true); }
        finally { createBtn.disabled = false; }
      });
      return root;
    }
    return Object.freeze({ followUpKey:followUpKey, followUpQueueKey:followUpQueueKey, loadRules:loadFollowUpRules, saveRules:saveFollowUpRules, loadQueue:loadFollowUpQueue, saveQueue:saveFollowUpQueue, buildFollowUpPanel:buildFollowUpPanel });
  };
})();
