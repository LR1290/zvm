;(function () {
  "use strict";
  if (window.__extCreateRailNavigationCore) return;
  window.__extCreateRailNavigationCore = function (options) {
    options = options || {};
    var resolveCommandId = typeof options.resolveCommandId === "function" ? options.resolveCommandId : function () { return null; };
    var commands = Object.create(null);
    var isSidebarEnabled = typeof options.isSidebarEnabled === "function" ? options.isSidebarEnabled : function () { return false; };
    var getCommandHost = typeof options.getCommandHost === "function" ? options.getCommandHost : function () { return null; };
    function emitReady(key, navigationOptions, result) {
      result = Object.assign({ key: key, panelId: null, open: false, panelReady: true }, result || {});
      window.dispatchEvent(new CustomEvent("ext:rail-navigation-ready", {
        detail: Object.assign({}, result, {
          source: navigationOptions.source || "programmatic",
          ensureOpen: navigationOptions.ensureOpen === true
        })
      }));
      return result;
    }
    async function navigate(key, navigationOptions) {
      navigationOptions = navigationOptions || {};
      if (isSidebarEnabled()) {
        var commandId = resolveCommandId(key);
        var host = getCommandHost();
        if (commandId && host && typeof host.has === "function" && host.has(commandId) && typeof host.execute === "function") {
          var result = await host.execute(commandId, Object.assign({}, navigationOptions, { source: navigationOptions.source || "programmatic" }));
          return emitReady(key, navigationOptions, result);
        }
      }
      var command = commands[key];
      if (!command) {
        var unavailable = new Error("O atalho solicitado ainda não está pronto nesta aba.");
        unavailable.code = "EXT_RAIL_COMMAND_UNAVAILABLE";
        throw unavailable;
      }
      return emitReady(key, navigationOptions, await command(navigationOptions));
    }
    function has(key) {
      if (isSidebarEnabled()) {
        var commandId = resolveCommandId(key);
        var host = getCommandHost();
        if (commandId && host && typeof host.has === "function") return !!host.has(commandId);
      }
      return typeof commands[key] === "function";
    }
    function register(key, command) {
      if (typeof command !== "function") throw new TypeError("Comando da barra lateral inválido.");
      commands[key] = command;
      return function () { if (commands[key] === command) delete commands[key]; };
    }
    function clear() { commands = Object.create(null); }
    return Object.freeze({ navigate: navigate, has: has, register: register, clear: clear });
  };
})();
