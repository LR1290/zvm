;(function(){
  "use strict";
  if(window.__extCreatePanelLifecycleCore)return;
  window.__extCreatePanelLifecycleCore=function(){
    var ownedByRoot=new WeakMap(),layoutDispose=function(){};
    function extOnKeyChange(key,fn){if(window.ExtensionStorage&&typeof window.ExtensionStorage.subscribe==="function")return window.ExtensionStorage.subscribe(key,function(newValue,oldValue,changedKey,meta){try{fn(newValue,oldValue,changedKey,meta);}catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("PANEL_STORAGE_SYNC_CALLBACK_FAILED",err);}});return function(){};}
    function owned(root){var list=ownedByRoot.get(root);if(!list){list=[];ownedByRoot.set(root,list);}return list;}
    function extPanelOwn(root,cleanup){if(!root||typeof cleanup!=="function")return cleanup;owned(root).push(cleanup);return cleanup;}
    function extPanelResetOwnedLifecycle(root){if(!root)return;var list=ownedByRoot.get(root);if(!list||!list.length)return;var cleanups=list.splice(0);for(var i=cleanups.length-1;i>=0;i--){try{cleanups[i]();}catch(_){}}}
    function extPanelOnKeyChange(root,key,fn){return extPanelOwn(root,extOnKeyChange(key,fn));}
    function extPanelResetBuilderLifecycle(root){if(root)extPanelResetOwnedLifecycle(root);}
    function setLayoutDispose(fn){layoutDispose=typeof fn==="function"?fn:function(){};}
    function extPanelDispose(root){if(!root)return;extPanelResetBuilderLifecycle(root);try{layoutDispose(root);}catch(_){}ownedByRoot.delete(root);if(root.parentElement)root.remove();}
    return Object.freeze({onKeyChange:extOnKeyChange,own:extPanelOwn,resetOwned:extPanelResetOwnedLifecycle,onPanelKeyChange:extPanelOnKeyChange,resetBuilder:extPanelResetBuilderLifecycle,dispose:extPanelDispose,setLayoutDispose:setLayoutDispose});
  };
})();
