;(function(){
  "use strict";
  if(window.__extCreatePanelActivityCore)return;
  window.__extCreatePanelActivityCore=function(deps){
    deps=deps||{};
    var PANEL_BRAND=deps.panelBrand||{},NAV_ICONS=deps.navIcons||{},extGet=deps.get,extSet=deps.set,toast=deps.toast;
    if(typeof extGet!=="function"||typeof extSet!=="function")throw new TypeError("Dependências do core de Atividades inválidas.");
    var ACTIVITY_KEY = "EXTUI:extappActivityStore";
    var ACTIVITY_ACTIVE_STATUSES = { queued: 1, running: 1, waiting: 1 };
    var ACTIVITY_FINISHED_CAP = 75;
    var ACTIVITY_FINISHED_MAX_AGE_MS = 24 * 60 * 60 * 1000;


    var ACTIVITY_TYPE_META = {
      message: { label: "Mensagem", accent: "#a855f7", icon: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>' },
      audio: { label: "Áudio", accent: "#14b8a6", icon: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2"/><path d="M12 19v3"/>' },
      image: { label: "Imagem", accent: "#84cc16", icon: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="m21 16-4.5-4.5a2 2 0 0 0-2.8 0L5 20"/>' },
      video: { label: "Vídeo", accent: "#3b82f6", icon: '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-2v8l-4-2z"/>' },
      media: { label: "Imagem/Vídeo (legado)", accent: "#84cc16", icon: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="m21 16-4.5-4.5a2 2 0 0 0-2.8 0L5 20"/>' },
      document: { label: "Documento", accent: "#f59e0b", icon: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>' },
      pix: { label: "PIX", accent: "#32bcad", icon: '<path d="m12 3 3 3-3 3-3-3z"/><path d="m12 15 3 3-3 3-3-3z"/><path d="m3 12 3-3 3 3-3 3z"/><path d="m15 12 3-3 3 3-3 3z"/>' },
      contact: { label: "Contato", accent: "#6366f1", icon: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>' },
      fluxo: { label: "Fluxo", accent: PANEL_BRAND.fluxos.accent, icon: PANEL_BRAND.fluxos.icon },
      funil: { label: "Funil", accent: PANEL_BRAND.funis.accent, icon: PANEL_BRAND.funis.icon },
      disparo: { label: "Disparo", accent: "#a855f7", icon: NAV_ICONS.disparos },
      agenda: { label: "Agenda", accent: PANEL_BRAND.agenda.accent, icon: PANEL_BRAND.agenda.icon },
      followup: { label: "FollowUp", accent: PANEL_BRAND.followup.accent, icon: PANEL_BRAND.followup.icon }
    };
    var ACTIVITY_STATUS_LABEL = { queued: "Na fila", running: "Em execução", waiting: "Aguardando", success: "Enviado", error: "Falhou", cancelled: "Cancelado", interrupted: "Interrompido" };


    var ENGINE_ACTIVE_STATUSES = { running: 1, waitingForInput: 1, waitingDelay: 1 };


    function extHumanizeActivityError(raw, errorCode, provider) {
      var aiMessages = {
        auth_failed: "A chave de acesso é inválida ou foi revogada.",
        access_denied: "Acesso negado ao recurso solicitado.",
        openai_credits_exhausted: "Os créditos do serviço de IA acabaram.",
        openai_model_unavailable: "Modelo indisponível para esta conta.",
        openai_invalid_request: "Modelo ou parâmetros recusados pela OpenAI.",
        openai_response_failed: "A OpenAI não concluiu a geração.",
        openai_response_incomplete: "A resposta foi interrompida antes de concluir.",
        rate_limited: "Limite temporário de solicitações atingido.",
        model_invalid: "Modelo configurado indisponível.",
        ai_empty_response: "Resposta vazia do provedor.",
        timeout: "Tempo limite excedido.",
        network_error: "Não foi possível alcançar o provedor.",
        provider_unavailable: "Provedor temporariamente indisponível.",
        integration_not_configured: "Conecte o serviço de IA em Assistentes IA > Conexões.",
        integration_not_ready: "A conexão de IA precisa ser revalidada em Assistentes IA > Conexões.",
        AI_AGENT_MODEL_TOOL_UNSUPPORTED: "O modelo escolhido não aceita as ferramentas obrigatórias do Agente. Selecione outro modelo em Assistentes IA.",
        AI_AGENT_CONTROL_REQUIRED: "O modelo respondeu sem o controle obrigatório do Agente. Selecione outro modelo compatível com uso de ferramentas.",
        AI_AGENT_RUNTIME_FAILED: "O Agente IA não conseguiu concluir esta execução.",
        AI_AGENT_STEP_LIMIT_EXCEEDED: "O Agente atingiu o limite seguro de etapas.",
        AI_AGENT_TOOL_LIMIT_EXCEEDED: "O Agente atingiu o limite seguro de ferramentas.",
        AI_AGENT_EMPTY_RESPONSE: "O Agente terminou sem produzir uma resposta."
      };
      if (aiMessages[errorCode]) { var providerNames={openai:"OpenAI",gemini:"Gemini",xai:"Grok"}; return (providerNames[provider] ? providerNames[provider] + " · " : "") + aiMessages[errorCode]; }
      var msg = String(raw || "").toLowerCase();
      if (msg.indexOf("mídia") !== -1 || msg.indexOf("media") !== -1 || msg.indexOf("imagem") !== -1 || msg.indexOf("video") !== -1 || msg.indexOf("vídeo") !== -1) return "Não foi possível enviar a mídia.";
      if (msg.indexOf("áudio") !== -1 || msg.indexOf("audio") !== -1) return "Não foi possível enviar o áudio.";
      if (msg.indexOf("documento") !== -1 || msg.indexOf("document") !== -1) return "Não foi possível enviar o documento.";
      if (msg.indexOf("motor de envio") !== -1 || msg.indexOf("wa-js") !== -1 || msg.indexOf("indispon") !== -1) return "O WhatsApp Web não estava pronto para enviar.";
      if (msg.indexOf("não encontrado") !== -1 || msg.indexOf("nao encontrado") !== -1 || msg.indexOf("not found") !== -1) return "O conteúdo configurado não foi encontrado.";
      if (msg.indexOf("chat") !== -1 || msg.indexOf("contato") !== -1 || msg.indexOf("conversa") !== -1) return "Não foi possível localizar o contato/conversa.";
      return "Não foi possível concluir o envio.";
    }

    var activityRuntime = {
      items: [],
      index: {},
      listeners: [],
      persistTimer: null,
      hydrated: false,
      hydratePromise: null
    };
    function extActivitySubscribe(fn) {
      if (typeof fn !== "function") return function () {};
      activityRuntime.listeners.push(fn);
      var active = true;
      return function () {
        if (!active) return;
        active = false;
        var index = activityRuntime.listeners.indexOf(fn);
        if (index >= 0) activityRuntime.listeners.splice(index, 1);
      };
    }

    function extPruneActivities(list) {
      var now = Date.now();
      var active = [];
      var finished = [];
      list.forEach(function (a) { (ACTIVITY_ACTIVE_STATUSES[a.status] ? active : finished).push(a); });
      finished.sort(function (a, b) { return (b.finishedAt || b.updatedAt || 0) - (a.finishedAt || a.updatedAt || 0); });
      finished = finished
        .filter(function (a) { return now - (a.finishedAt || a.updatedAt || 0) < ACTIVITY_FINISHED_MAX_AGE_MS; })
        .slice(0, ACTIVITY_FINISHED_CAP);
      return active.concat(finished);
    }

    function extActivityNotify() { activityRuntime.listeners.forEach(function (fn) { try { fn(); } catch (err) { } }); }

    function extActivityPersist(immediate) {
      clearTimeout(activityRuntime.persistTimer);
      var flush = function () {
        activityRuntime.items = extPruneActivities(activityRuntime.items);
        extSet(ACTIVITY_KEY, activityRuntime.items).catch(function (err) { });
      };


      if (immediate) flush(); else activityRuntime.persistTimer = setTimeout(flush, 700);
    }

    function extMergeActivityLists(stored, current) {
      var byId = new Map();
      (Array.isArray(stored) ? stored : []).forEach(function (a) { if (a && a.id) byId.set(a.id, a); });
      (Array.isArray(current) ? current : []).forEach(function (a) {
        if (!a || !a.id) return;
        var previous = byId.get(a.id);
        if (!previous || Number(a.updatedAt || a.startedAt || 0) >= Number(previous.updatedAt || previous.startedAt || 0)) byId.set(a.id, a);
      });
      return extPruneActivities(Array.from(byId.values()));
    }
    function extActivityHydrate() {
      if (activityRuntime.hydrated) return Promise.resolve();
      if (activityRuntime.hydratePromise) return activityRuntime.hydratePromise;
      activityRuntime.hydratePromise = (async function () {
        try {
          var stored = await extGet(ACTIVITY_KEY);
          activityRuntime.items = extMergeActivityLists(stored, activityRuntime.items);
          activityRuntime.index = {};
          activityRuntime.items.forEach(function (a, i) { activityRuntime.index[a.id] = i; });
        } catch (err) { }
        finally { activityRuntime.hydrated = true; activityRuntime.hydratePromise = null; }
        extActivityNotify();
      })();
      return activityRuntime.hydratePromise;
    }


    function extActivityTrack(evt) {
      if (!evt || !evt.id || !evt.action) return;
      try { if (window.__extTraceRuntime) window.__extTraceRuntime("ACTIVITY", { activityId: evt.id, executionId: evt.executionId, source: evt.source, action: evt.action, status: evt.status, provider: evt.provider, errorCode: evt.errorCode }); } catch (_) {}
      var idx = activityRuntime.index[evt.id];
      var rec = idx != null ? activityRuntime.items[idx] : null;
      var now = Date.now();
      if (evt.action === "start") {
        if (rec) return;
        rec = {
          id: evt.id, type: evt.type, source: evt.source || "",
          title: evt.title || (ACTIVITY_TYPE_META[evt.type] || {}).label || "Operação",
          targetLabel: evt.targetLabel || "",
          status: evt.status || "running",
          current: typeof evt.current === "number" ? evt.current : undefined,
          total: typeof evt.total === "number" ? evt.total : undefined,


          chatId: evt.chatId || undefined,


          executionId: evt.executionId || undefined,
          nextActionAt: evt.nextActionAt || undefined,
          progressLabel: typeof evt.progressLabel === "string" ? evt.progressLabel.slice(0, 80) : undefined,
          startedAt: now, updatedAt: now, finishedAt: undefined, errorMessage: undefined
        };
        activityRuntime.items.unshift(rec);
        activityRuntime.index = {}; activityRuntime.items.forEach(function (a, i) { activityRuntime.index[a.id] = i; });
        extActivityPersist(true);
      } else if (rec) {
        if (evt.action === "update") {
          if (typeof evt.current === "number") rec.current = evt.current;
          if (typeof evt.total === "number") rec.total = evt.total;
          if (evt.status) rec.status = evt.status;


          if ("nextActionAt" in evt) rec.nextActionAt = evt.nextActionAt || undefined;
          if ("progressLabel" in evt) rec.progressLabel = typeof evt.progressLabel === "string" ? evt.progressLabel.slice(0, 80) : undefined;
          if (typeof evt.memoryUsedCount === "number") rec.memoryUsedCount = Math.max(0, Math.min(20, Math.floor(evt.memoryUsedCount)));
          if (typeof evt.memoryUnavailable === "boolean") rec.memoryUnavailable = evt.memoryUnavailable;
          rec.updatedAt = now;
          extActivityPersist(false);
        } else if (evt.action === "success") {
          rec.status = "success"; rec.progressLabel = undefined; rec.updatedAt = now; rec.finishedAt = now;
          extActivityPersist(true);
        } else if (evt.action === "error") {
          rec.status = "error"; rec.progressLabel = undefined; rec.updatedAt = now; rec.finishedAt = now;
          rec.errorMessage = extHumanizeActivityError(evt.errorMessage, evt.errorCode, evt.provider);
          rec.errorCode = typeof evt.errorCode === "string" ? evt.errorCode.slice(0, 80) : undefined;
          rec.provider = ["openai","gemini","xai"].indexOf(evt.provider) >= 0 ? evt.provider : undefined;
          extActivityPersist(true);
        } else if (evt.action === "cancel") {
          rec.status = "cancelled"; rec.progressLabel = undefined; rec.updatedAt = now; rec.finishedAt = now;
          extActivityPersist(true);
        } else { return; }
      } else { return; }
      extActivityNotify();
    }
    function extActivityCounts() {
      var active = 0;
      activityRuntime.items.forEach(function (a) { if (ACTIVITY_ACTIVE_STATUSES[a.status]) active++; });
      return active;
    }

    async function extActivityClearFinished() {
      activityRuntime.items = activityRuntime.items.filter(function (a) { return ACTIVITY_ACTIVE_STATUSES[a.status]; });
      activityRuntime.index = {}; activityRuntime.items.forEach(function (a, i) { activityRuntime.index[a.id] = i; });
      extActivityPersist(true);
      extActivityNotify();
    }


    var ACTIVITY_CANCELABLE_TYPES = { fluxo: 1, funil: 1, disparo: 1, agenda: 1, followup: 1 };
    async function extActivityCancel(a) {


      if (a.type === "fluxo") {
        if (typeof window.__extFluxosCancelFlow !== "function" || (!a.chatId && !a.executionId)) return false;
        return !!(await window.__extFluxosCancelFlow(a.chatId, a.executionId));
      }
      if (a.type === "funil") {
        if (typeof window.__extFunnelsCancelFunnel !== "function" || (!a.chatId && !a.executionId)) return false;
        return !!(await window.__extFunnelsCancelFunnel(a.chatId, a.executionId));
      }
      if (a.type === "disparo") {
        if (typeof window.__extDisparosCancelCurrent !== "function") return false;
        await window.__extDisparosCancelCurrent();
        return true;
      }
      if (a.type === "agenda") {
        if (!window.__extAgendaService || typeof window.__extAgendaService.cancel !== "function") return false;
        return !!(await window.__extAgendaService.cancel(String(a.id||"").replace(/^agenda:/,"")));
      }
      if (a.type === "followup") {
        if (!window.__extFollowUpService || typeof window.__extFollowUpService.cancelQueue !== "function") return false;
        return !!(await window.__extFollowUpService.cancelQueue(String(a.id||"").replace(/^followup:/,"")));
      }
      return false;
    }


    function extFormatCountdown(remainMs) {
      var s = Math.max(0, Math.ceil(remainMs / 1000));
      if (s < 60) return s + "s";
      var totalMin = Math.floor(s / 60), rs = s % 60;
      if (totalMin < 60) return totalMin + "min" + (rs ? " " + rs + "s" : "");
      var totalH = Math.floor(totalMin / 60), rm = totalMin % 60;
      if (totalH < 24) return totalH + "h " + (rm < 10 ? "0" + rm : String(rm)) + "min";
      var d = Math.floor(totalH / 24), rh = totalH % 24;
      return d + "d" + (rh ? " " + rh + "h" : "");
    }


    function extParseRunningList(raw) {
      try {
        var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
        return (parsed && parsed.state && parsed.state.runningList) || [];
      } catch (err) { return []; }
    }
    async function extActivityReconcile() {
      var candidates = activityRuntime.items.filter(function (a) {
        return (a.type === "fluxo" || a.type === "funil") && ACTIVITY_ACTIVE_STATUSES[a.status];
      });
      if (!candidates.length) return;
      var needsFlows = candidates.some(function (a) { return a.type === "fluxo"; });
      var needsFunnels = candidates.some(function (a) { return a.type === "funil"; });
      var flowRunning = [], funnelRunning = [];
      try {
        if (needsFlows) flowRunning = extParseRunningList(await extGet("EXTUI:extappFlowRunningStore"));
        if (needsFunnels) funnelRunning = extParseRunningList(await extGet("EXTUI:extappFunnelRunningStore"));
      } catch (err) { return; }
      var now = Date.now();
      var changed = false;
      candidates.forEach(function (a) {
        var pool = a.type === "fluxo" ? flowRunning : funnelRunning;
        var stillExists = a.executionId
          ? pool.some(function (r) { return r.id === a.executionId && ENGINE_ACTIVE_STATUSES[r.status]; })
          : pool.some(function (r) { return r.chatId === a.chatId && ENGINE_ACTIVE_STATUSES[r.status]; });
        if (!stillExists) {
          a.status = "interrupted";
          a.updatedAt = now;
          a.finishedAt = now;
          changed = true;
        }
      });
      if (changed) extActivityPersist(true);
    }
    return Object.freeze({activityKey:ACTIVITY_KEY,activeStatuses:ACTIVITY_ACTIVE_STATUSES,typeMeta:ACTIVITY_TYPE_META,statusLabels:ACTIVITY_STATUS_LABEL,cancelableTypes:ACTIVITY_CANCELABLE_TYPES,humanizeError:extHumanizeActivityError,subscribe:extActivitySubscribe,notify:extActivityNotify,hydrate:extActivityHydrate,track:extActivityTrack,counts:extActivityCounts,clearFinished:extActivityClearFinished,cancel:extActivityCancel,formatCountdown:extFormatCountdown,reconcile:extActivityReconcile,list:function(){return activityRuntime.items.slice();}});
  };
})();
