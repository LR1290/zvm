;(function () {
  "use strict";
  if (window.__extCreatePanelOptionsRuntimeCore) return;
  window.__extCreatePanelOptionsRuntimeCore = function (deps) {
    deps = deps || {};
    var OPTIONS_KEY=deps.optionsKey, OPTIONS_DEFAULTS=deps.optionsDefaults || {}, NEW_INSTALL_OPTIONS_DEFAULTS=deps.newInstallOptionsDefaults || OPTIONS_DEFAULTS;
    var extClampNum=deps.clampNum, workspaceContext=deps.workspaceContext, extRepaintAllSwitches=deps.repaintAllSwitches;
    var extNormalizePanelOpenMode=deps.normalizePanelOpenMode, extSetPanelOpenMode=deps.setPanelOpenMode, extOnKeyChange=deps.onKeyChange, extGet=deps.get;
    var extApplyMenuVisibility=deps.applyMenuVisibility;
    if (!OPTIONS_KEY || [extClampNum,extRepaintAllSwitches,extNormalizePanelOpenMode,extSetPanelOpenMode,extOnKeyChange,extGet,extApplyMenuVisibility].some(function(fn){return typeof fn!=="function";}) || !workspaceContext || typeof workspaceContext.setInteractionSettings!=="function") throw new TypeError("Dependências do runtime de opções inválidas.");
    var optionsRuntime = { contextInvalidatedShown: false, started: false, unsubscribe: null };
    function isContextInvalidatedError(err) {
      var msg = (err && err.message) || String(err || "");
      return /extension context invalidated/i.test(msg);
    }
    function showContextInvalidatedBanner() {
      if (optionsRuntime.contextInvalidatedShown) return;
      optionsRuntime.contextInvalidatedShown = true;
      var banner = document.createElement("div");
      banner.id = "extuiContextInvalidatedBanner";
      banner.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#c22e44;color:#fff;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-size:13.5px;padding:10px 16px;display:flex;align-items:center;justify-content:center;gap:14px;box-shadow:0 2px 10px rgba(0,0,0,.3);";
      banner.innerHTML = '<span>A extensão foi atualizada — essa aba do WhatsApp Web precisa recarregar para voltar a funcionar (barra/botões param de responder até lá).</span>' +
        '<button type="button" id="extuiReloadTabBtn" style="background:#fff;color:#c22e44;border:none;border-radius:6px;padding:8px 14px;font-weight:700;font-size:14px;cursor:pointer;flex-shrink:0;">Recarregar agora</button>';
      document.body.appendChild(banner);
      document.getElementById("extuiReloadTabBtn").addEventListener("click", function () { location.reload(); });
    }
    
    
    var CUSTOM_THEME_VAR_MAP = { primary: "--extui-primary", primaryBright: "--extui-primary-bright", bg: "--extui-bg", card: "--extui-card", card2: "--extui-card-2", text: "--extui-text", textDim: "--extui-text-dim", border: "--extui-border" };
    
    
    var FONT_STACKS = { system: '-apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif', segoe: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif', arial: 'Arial, Helvetica, sans-serif' };
    
    
    function extNormalizeIconTheme(iconTheme) {
      return iconTheme === "3d" || iconTheme === "color" ? iconTheme : "monochrome";
    }
    function applyIconSettingsToDocument(iconTheme, sidebarMainIconSize, disparosIconSize) {
      document.documentElement.setAttribute("data-extui-icon-theme", extNormalizeIconTheme(iconTheme));
      var sidebarSize = extClampNum(Number(sidebarMainIconSize) || OPTIONS_DEFAULTS.sidebarMainIconSize, 16, 64);
      var disparosSize = extClampNum(Number(disparosIconSize) || OPTIONS_DEFAULTS.disparosIconSize, 16, 64);
      document.documentElement.style.setProperty("--extui-sidebar-icon-size", sidebarSize + "px");
      document.documentElement.style.setProperty("--extui-disparos-icon-size", disparosSize + "px");
    }
    
    
    function applyFloatingWorkspaceSettingsToDocument(movable, resizable) {
      workspaceContext.setInteractionSettings(movable, resizable);
    }
    function applySidebarPlacementToDocument(value) {
      var placement = value === "right-conversation" ? "right-conversation" : "left-native";
      document.documentElement.setAttribute("data-extui-sidebar-placement", placement);
      if (typeof window.__extScheduleRailLayout === "function") window.__extScheduleRailLayout();
    }
    function applyThemeToDocument(theme, customColors, fontFamily, motion, radiusPreset, iconTheme, sidebarMainIconSize, disparosIconSize) {
      var isCustom = theme === "custom";
      var baseTheme = isCustom ? "light" : (theme || "light");
      document.documentElement.setAttribute("data-extui-theme", baseTheme);
      Object.keys(CUSTOM_THEME_VAR_MAP).forEach(function (k) {
        if (isCustom && customColors && customColors[k]) document.documentElement.style.setProperty(CUSTOM_THEME_VAR_MAP[k], customColors[k]);
        else document.documentElement.style.removeProperty(CUSTOM_THEME_VAR_MAP[k]);
      });
      var stack = FONT_STACKS[fontFamily];
      if (stack) document.documentElement.style.setProperty("--extui-font-family", stack);
      else document.documentElement.style.removeProperty("--extui-font-family");
      document.documentElement.setAttribute("data-extui-motion", motion || "auto");
      document.documentElement.setAttribute("data-extui-radius", radiusPreset || "default");
      applyIconSettingsToDocument(iconTheme, sidebarMainIconSize, disparosIconSize);
      var panel = document.getElementById("extuiNavAjustesPanel");
      if (panel) panel.querySelectorAll(".extuiThemeRadioBtn").forEach(function (b) { b.classList.toggle("extuiActive", b.getAttribute("data-theme") === theme); });
      extRepaintAllSwitches();
    }
    function extParseOptionsPayload(raw) {
      try { return raw ? Object.assign({}, OPTIONS_DEFAULTS, typeof raw === "string" ? JSON.parse(raw) : raw) : NEW_INSTALL_OPTIONS_DEFAULTS; }
      catch (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("OPTIONS_PAYLOAD_PARSE_FAILED", err); throw err; }
    }
    function applyOptionsPayload(raw) {
      var opts=extParseOptionsPayload(raw);
      var panelOpenMode=extNormalizePanelOpenMode(opts.panelOpenMode);
      if (window.__extThemeSystem) { opts=window.__extThemeSystem.normalize(opts); window.__extThemeSystem.apply(opts); }
      else applyThemeToDocument(opts.mode === "dark" ? "dark" : "light", opts.customColors, opts.fontFamily, opts.motion, opts.radiusPreset, opts.iconTheme, opts.sidebarMainIconSize, opts.disparosIconSize);
      applyFloatingWorkspaceSettingsToDocument(opts.floatingWindowMovable, opts.floatingWindowResizable);
      applySidebarPlacementToDocument(opts.sidebarPlacement);
      extSetPanelOpenMode(panelOpenMode, true);
      extApplyMenuVisibility(opts);
    }
    
    
    function start(){
      if(optionsRuntime.started) return optionsRuntime.unsubscribe;
      optionsRuntime.started=true;
      optionsRuntime.unsubscribe=extOnKeyChange(OPTIONS_KEY, applyOptionsPayload);
      extGet(OPTIONS_KEY).then(applyOptionsPayload).catch(function (err) { if (isContextInvalidatedError(err)) { showContextInvalidatedBanner(); return; } if (window.__extReportRuntimeError) window.__extReportRuntimeError("OPTIONS_BOOT_LOAD_FAILED", err); });
      return optionsRuntime.unsubscribe;
    }
    return Object.freeze({ start:start, parseOptionsPayload:extParseOptionsPayload, applyOptionsPayload:applyOptionsPayload, applySidebarPlacement:applySidebarPlacementToDocument, applyFloatingSettings:applyFloatingWorkspaceSettingsToDocument, applyTheme:applyThemeToDocument, normalizeIconTheme:extNormalizeIconTheme });
  };
})();
