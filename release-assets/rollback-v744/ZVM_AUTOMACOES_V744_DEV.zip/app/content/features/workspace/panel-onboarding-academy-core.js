;(function () {
  "use strict";
  if (window.__extCreateOnboardingAcademyCore) return;
  window.__extCreateOnboardingAcademyCore = function (deps) {
    deps = deps || {};
    var __extWorkspaceStaticData = deps.staticData || {};
    var NAV_ICONS = deps.navIcons || {};
    var extGet = deps.get, extSet = deps.set, extOnKeyChange = deps.onKeyChange;
    var extHydrateOnboardingLogo = deps.hydrateOnboardingLogo, openShellHtml = deps.openShellHtml, toast = deps.toast, escHtml = deps.escHtml, closeAllPanels = deps.closeAllPanels;
    if ([extGet,extSet,extOnKeyChange,extHydrateOnboardingLogo,openShellHtml,toast,escHtml,closeAllPanels].some(function(fn){return typeof fn!=="function";})) throw new TypeError("Dependências do domínio Onboarding/Academy inválidas.");
    var ONBOARDING_STORAGE_KEY = "EXTUI:onboardingState";
    var ONBOARDING_VERSION = 5;
    var ACADEMY_LESSON_IDS = __extWorkspaceStaticData.ACADEMY_LESSON_IDS;
    var ONBOARDING_LAYOUT = { gap: 20, viewportEdge: 16, targetPadding: 8 };
    var onboardingRuntime = {
      state: { completedVersion: null, skippedVersion: null },
      accessLoaded: false,
      wppReady: false,
      eligibilityLoaded: false,
      dismissedThisSession: false,
      session: null,
      stateWrite: Promise.resolve(),
      academy: { queue: Promise.resolve(), operations: {}, results: {}, resultOrder: [] }
    };
    var _e1 = false;

    function extTutorialsOperational() {
      var availability = window.ExtensionCore && window.ExtensionCore.FeatureAvailability;
      if (!availability || typeof availability.isOperational !== "function") return false;
      try { return availability.isOperational("tutorials", { requireRegistered: true }) === true; }
      catch (_) { return false; }
    }
    
    var EXTUI_ACADEMY_NAV_LABELS = __extWorkspaceStaticData.EXTUI_ACADEMY_NAV_LABELS;
    var EXTUI_ACADEMY_NAV_V2 = __extWorkspaceStaticData.EXTUI_ACADEMY_NAV_V2;
    
    var ACADEMY_WHATSAPP_LESSONS = __extWorkspaceStaticData.ACADEMY_WHATSAPP_LESSONS;
    function extRefineSidebarWhatsappLesson() {
      var steps = ACADEMY_WHATSAPP_LESSONS["sidebar-whatsapp"] || [];
      steps.forEach(function (step) {
        if (!step) return;
        if (step.id === "sidebar-logo") {
          step.description = "Este é o botão que abre o Painel de Controle completo.";
          step.doNow = "Olhe para a logo a extensão destacada no topo da barra lateral.";
          step.expect = "Ao clicar nela, o Painel de Controle deve abrir sem tirar você da conversa atual.";
          step.tip = "Use esse botão para configurações, gestão e tarefas que precisam de mais espaço.";
          step.contextLabel = "Logo a extensão";
          return;
        }
        if (step.navKey) {
          var v2 = EXTUI_ACADEMY_NAV_V2[step.navKey] || null;
          var label = step.contextLabel || step.title || EXTUI_ACADEMY_NAV_LABELS[step.navKey] || step.navKey;
          step.contextLabel = label;
          step.focusNavOnly = true;
          step.autoOpen = false;
          step.firstAvailableOnly = true;
          step.v2Key = v2 && v2.key || null;
          step.v2Command = v2 && v2.command || null;
          step.v2Tray = v2 && v2.tray || null;
          step.selectors = [];
          if (step.v2Key) step.selectors.push('[data-extui-academy-target="v2-' + step.v2Key + '"]');
          if (step.v2Command) step.selectors.push('[data-command="' + step.v2Command + '"]');
          step.selectors.push('[data-extui-academy-target="rail-' + step.navKey + '"]');
          step.doNow = 'Este é o botão ' + label + '. Memorize o ícone destacado à esquerda.';
          step.expect = 'Ao clicar nesse ícone, o painel ' + label + ' deve abrir ao lado da conversa.';
          if (step.id === "sidebar-broadcast") step.warning = "Não inicie um disparo de teste só para avançar no tutorial.";
          return;
        }
        if (step.id === "sidebar-export") {
          step.contextLabel = "Exportar Contatos";
          step.focusNavOnly = true;
          step.autoOpen = false;
          step.firstAvailableOnly = true;
          step.v2Key = "export";
          step.v2Command = "export-contacts.open";
          step.selectors = ['[data-extui-academy-target="v2-export"]','[data-command="export-contacts.open"]','[data-extui-academy-target="rail-salvar"]'];
          step.description = "Este botão prepara a exportação de contatos do WhatsApp.";
          step.doNow = "Olhe para o ícone Exportar Contatos destacado à esquerda.";
          step.expect = "Ao clicar nele, a área de exportação deve abrir sem começar um download automaticamente.";
          step.tip = "Use o Painel de Controle quando quiser revisar origem, prévia e formato antes de exportar.";
        }
      });
    }
    extRefineSidebarWhatsappLesson();
    
    var ONBOARDING_STEPS = ACADEMY_WHATSAPP_LESSONS["sidebar-whatsapp"];
    
    function extNormalizeOnboardingState(raw) {
      if (typeof raw === "string") {
        try { raw = JSON.parse(raw); } catch (err) { raw = null; }
      }
      raw = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      function normalizeVersion(value) {
        if (value == null || value === "") return null;
        var version = Number(value);
        return Number.isFinite(version) && version >= 0 ? version : null;
      }
      var lessons = {};
      var legacyAcademy = (Number(raw.academyVersion) || 0) < ONBOARDING_VERSION;
      ACADEMY_LESSON_IDS.forEach(function (id) { lessons[id] = legacyAcademy ? false : !!(raw.lessons && raw.lessons[id]); });
      if (!legacyAcademy && raw.academyVersion == null && ((Number(raw.completedVersion) || 0) >= 1 || (Number(raw.skippedVersion) || 0) >= 1)) lessons["sidebar-whatsapp"] = true;
      if (legacyAcademy) { raw.currentLessonId = null; raw.currentStepId = null; raw.currentContext = null; raw.pendingTransition = null; raw.completedVersion = null; raw.skippedVersion = null; }
      var pending = raw.pendingTransition && typeof raw.pendingTransition === "object" ? raw.pendingTransition : null;
      if (pending && (typeof pending.id !== "string" || (pending.destinationContext !== "dashboard" && pending.destinationContext !== "whatsapp"))) pending = null;
      return Object.assign({}, raw, {
        completedVersion: normalizeVersion(raw.completedVersion),
        skippedVersion: normalizeVersion(raw.skippedVersion),
        academyVersion: normalizeVersion(raw.academyVersion),
        lessons: lessons,
        currentLessonId: ACADEMY_LESSON_IDS.indexOf(raw.currentLessonId) >= 0 ? raw.currentLessonId : null,
        currentStepId: typeof raw.currentStepId === "string" ? raw.currentStepId : null,
        currentContext: raw.currentContext === "whatsapp" || raw.currentContext === "dashboard" ? raw.currentContext : null,
        academyEntryMode: raw.academyEntryMode === "auto" ? "auto" : raw.academyEntryMode === "manual" ? "manual" : null,
        pendingTransition: pending,
        lastCompletedTransitionId: typeof raw.lastCompletedTransitionId === "string" ? raw.lastCompletedTransitionId : null
      });
    }
    
    function extOnboardingVersionHandled(state) {
      if ((state.academyVersion || 0) >= ONBOARDING_VERSION) {
        return (state.completedVersion || 0) >= ONBOARDING_VERSION ||
          (state.skippedVersion || 0) >= ONBOARDING_VERSION ||
          !!(state.lessons && state.lessons["sidebar-whatsapp"]) ||
          state.academyEntryMode === "manual";
      }
    
    
      return (state.completedVersion || 0) >= 1 || (state.skippedVersion || 0) >= 1;
    }
    
    function extOnboardingElementVisible(el) {
      if (!el || !el.isConnected) return false;
      var rect = el.getBoundingClientRect();
      var style = window.getComputedStyle(el);
      return rect.width > 1 && rect.height > 1 && style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0 && el.getAttribute("aria-hidden") !== "true";
    }
    
    function extOnboardingFindElement(selector) {
      function firstVisible(root) {
        if (!root || typeof root.querySelectorAll !== "function") return null;
        var nodes;
        try { nodes = root.querySelectorAll(selector); } catch (_) { return null; }
        for (var i = 0; i < nodes.length; i++) if (extOnboardingElementVisible(nodes[i])) return nodes[i];
        return null;
      }
      var el = firstVisible(document);
      if (el) return el;
      var v2 = document.getElementById("ext-sidebar-host");
      if (v2 && v2.shadowRoot) {
        var shadowEl = firstVisible(v2.shadowRoot);
        if (shadowEl) return shadowEl;
      }
      return null;
    }
    
    function extWaitForOnboardingTarget(step, timeoutMs) {
      timeoutMs = Math.max(250, Number(timeoutMs) || 5000);
      if (extOnboardingTargetRect(step)) return Promise.resolve(true);
      return new Promise(function (resolve) {
        var settled = false;
        var timer = setTimeout(function () { finish(false); }, timeoutMs);
        var observer = new MutationObserver(check);
        function finish(result) {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          observer.disconnect();
          resolve(result);
        }
        function check() { if (extOnboardingTargetRect(step)) finish(true); }
        try { observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "aria-hidden"] }); } catch (_) {}
        check();
      });
    }
    
    function extOnboardingStableTargetRect(step) {
      return new Promise(function (resolve) {
        var previous = null;
        var stableFrames = 0;
        var frames = 0;
        function sample() {
          var rect = extOnboardingTargetRect(step);
          if (!rect) { resolve(null); return; }
          var signature = [Math.round(rect.top), Math.round(rect.left), Math.round(rect.right), Math.round(rect.bottom)].join(":");
          stableFrames = signature === previous ? stableFrames + 1 : 0;
          previous = signature;
          frames++;
          if (stableFrames >= 2 || frames >= 12) { resolve(rect); return; }
          requestAnimationFrame(sample);
        }
        requestAnimationFrame(sample);
      });
    }
    
    function extOnboardingFirstTargetElement(step) {
      var found = null;
      (step && step.selectors || []).some(function (selector) {
        found = extOnboardingFindElement(selector);
        return !!found;
      });
      return found;
    }
    
    function extOnboardingTargetRect(step) {
      var elements = [];
      (step.selectors || []).some(function (selector) {
        var el = extOnboardingFindElement(selector);
        if (!el) return false;
        elements.push(el);
        return step.firstAvailableOnly === true;
      });
      if (!elements.length) return null;
    
      var rects = elements.map(function (el) { return el.getBoundingClientRect(); });
      return {
        top: Math.min.apply(Math, rects.map(function (rect) { return rect.top; })),
        right: Math.max.apply(Math, rects.map(function (rect) { return rect.right; })),
        bottom: Math.max.apply(Math, rects.map(function (rect) { return rect.bottom; })),
        left: Math.min.apply(Math, rects.map(function (rect) { return rect.left; }))
      };
    }
    
    function extOnboardingMask(root, name) {
      return root.querySelector('[data-extui-onboarding-mask="' + name + '"]');
    }
    
    function extSetRect(el, top, left, width, height) {
      el.style.top = Math.max(0, top) + "px";
      el.style.left = Math.max(0, left) + "px";
      el.style.width = Math.max(0, width) + "px";
      el.style.height = Math.max(0, height) + "px";
    }
    
    function extLayoutOnboarding() {
      var session = onboardingRuntime.session;
      if (!session || !session.root || !session.root.isConnected) return;
      session.layoutFrame = null;
    
      var root = session.root;
      var dialog = root.querySelector(".extuiOnboardingDialog");
      var viewportWidth = window.innerWidth;
      var viewportHeight = window.innerHeight;
      var targetRect = session.phase === "step" && !session.suspended ? extOnboardingTargetRect(ONBOARDING_STEPS[session.stepIndex]) : null;
      var dialogRect = dialog.getBoundingClientRect();
      var gap = ONBOARDING_LAYOUT.gap;
      var edge = ONBOARDING_LAYOUT.viewportEdge;
    
      root.classList.toggle("extuiOnboardingNoTarget", !targetRect);
      if (!targetRect) {
        extSetRect(extOnboardingMask(root, "full"), 0, 0, viewportWidth, viewportHeight);
        ["top", "left", "right", "bottom"].forEach(function (name) { extSetRect(extOnboardingMask(root, name), 0, 0, 0, 0); });
        root.querySelector(".extuiOnboardingSpotlight").style.display = "none";
        dialog.style.left = "50%";
        dialog.style.top = "50%";
        dialog.style.transform = "translate(-50%, -50%)";
        return;
      }
    
      var padding = ONBOARDING_LAYOUT.targetPadding;
      var focus = {
        top: Math.max(0, targetRect.top - padding),
        left: Math.max(0, targetRect.left - padding),
        right: Math.min(viewportWidth, targetRect.right + padding),
        bottom: Math.min(viewportHeight, targetRect.bottom + padding)
      };
      focus.width = Math.max(0, focus.right - focus.left);
      focus.height = Math.max(0, focus.bottom - focus.top);
    
      extSetRect(extOnboardingMask(root, "full"), 0, 0, 0, 0);
      extSetRect(extOnboardingMask(root, "top"), 0, 0, viewportWidth, focus.top);
      extSetRect(extOnboardingMask(root, "left"), focus.top, 0, focus.left, focus.height);
      extSetRect(extOnboardingMask(root, "right"), focus.top, focus.right, viewportWidth - focus.right, focus.height);
      extSetRect(extOnboardingMask(root, "bottom"), focus.bottom, 0, viewportWidth, viewportHeight - focus.bottom);
    
      var spotlight = root.querySelector(".extuiOnboardingSpotlight");
      extSetRect(spotlight, focus.top, focus.left, focus.width, focus.height);
      spotlight.style.display = "block";
    
      var fitsLeft = focus.left - gap - dialogRect.width >= edge;
      var fitsRight = focus.right + gap + dialogRect.width <= viewportWidth - edge;
      var left;
      var top;
      if (fitsLeft || fitsRight) {
        left = fitsLeft ? focus.left - gap - dialogRect.width : focus.right + gap;
        top = focus.top + (focus.height - dialogRect.height) / 2;
      } else {
        left = focus.left + (focus.width - dialogRect.width) / 2;
        top = focus.top - gap - dialogRect.height;
        if (top < edge) top = focus.bottom + gap;
      }
      left = Math.min(Math.max(edge, left), Math.max(edge, viewportWidth - dialogRect.width - edge));
      top = Math.min(Math.max(edge, top), Math.max(edge, viewportHeight - dialogRect.height - edge));
      dialog.style.left = left + "px";
      dialog.style.top = top + "px";
      dialog.style.transform = "none";
    }
    
    function extScheduleOnboardingLayout() {
      if (!onboardingRuntime.session || onboardingRuntime.session.layoutFrame) return;
      onboardingRuntime.session.layoutFrame = requestAnimationFrame(extLayoutOnboarding);
    }
    
    function extOnboardingProgressMarkup(index) {
      var dots = ONBOARDING_STEPS.map(function (_, dotIndex) {
        var stateClass = dotIndex < index ? " isComplete" : dotIndex === index ? " isCurrent" : "";
        return '<span class="extuiOnboardingProgressDot' + stateClass + '"></span>';
      }).join("");
      return '<div class="extuiOnboardingProgress" aria-label="Etapa ' + (index + 1) + ' de ' + ONBOARDING_STEPS.length + '">' +
        '<span>' + (index + 1) + ' de ' + ONBOARDING_STEPS.length + '</span><span class="extuiOnboardingProgressDots" aria-hidden="true">' + dots + '</span></div>';
    }
    
    function extOnboardingInfoMarkup(label, value, modifier) {
      if (!value) return "";
      return '<div class="extuiOnboardingInfo' + (modifier ? ' ' + modifier : '') + '"><strong>' + escHtml(label) + '</strong><span>' + escHtml(value) + '</span></div>';
    }
    
    function extOnboardingContextLabel(step) {
      if (!step) return "";
      return step.contextLabel || (step.navKey ? (EXTUI_ACADEMY_NAV_LABELS[step.navKey] || "") : "");
    }
    
    function extClearOnboardingNavContext() {
      document.querySelectorAll('.extuiNavIconBtn.extuiAcademyContextActive').forEach(function (btn) {
        btn.classList.remove('extuiAcademyContextActive');
        btn.removeAttribute('data-extui-academy-current');
      });
    }
    
    function extSyncOnboardingNavContext() {
      extClearOnboardingNavContext();
      var session = onboardingRuntime.session;
      if (!session || session.phase !== 'step') return;
      var step = ONBOARDING_STEPS[session.stepIndex];
      var key = session.expectedNavKey || (step && step.navKey) || null;
      if (!key) return;
      var btn = document.querySelector('.extuiNavIconBtn[data-extui-nav-key="' + key + '"]');
      if (!btn) return;
      btn.classList.add('extuiAcademyContextActive');
      btn.setAttribute('data-extui-academy-current', 'true');
    }
    
    function extRenderOnboarding() {
      var session = onboardingRuntime.session;
      if (!session) return;
      extSyncOnboardingNavContext();
      var dialog = session.root.querySelector(".extuiOnboardingDialog");
      var content;
    
    
      var closeBtnHtml = '<button type="button" class="extuiOnboardingCloseBtn" data-extui-onboarding-action="skip" aria-label="Fechar tutorial"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + NAV_ICONS.close + '</svg></button>';
    
      if (session.phase === "intro") {
    
    
        content = closeBtnHtml +
          '<div class="extuiOnboardingBrand" aria-hidden="true"><img class="extuiOnboardingLogoImg" width="24" height="24" alt=""><i></i></div>' +
          '<div class="extuiOnboardingEyebrow">GUIA RÁPIDO DA extensão</div>' +
          '<h2 id="extuiOnboardingTitle">Bem-vindo à ZVM - Automações</h2>' +
          '<p id="extuiOnboardingDescription">Um guia rápido pela interface real, mostrando onde ficam as principais ferramentas sem iniciar nenhuma ação comercial automaticamente.</p>' +
          '<div class="extuiOnboardingMeta">Progresso inicial · ' + Object.keys(onboardingRuntime.state.lessons || {}).filter(function (key) { return onboardingRuntime.state.lessons[key]; }).length + ' de ' + ACADEMY_LESSON_IDS.length + ' tutoriais</div>' +
          '<div class="extuiOnboardingActions"><button type="button" class="extuiOnboardingButton extuiOnboardingButton--ghost" data-extui-onboarding-action="skip">Explorar sozinho</button>' +
          '<button type="button" class="extuiOnboardingButton extuiOnboardingButton--primary" data-extui-onboarding-action="start">Começar tutorial</button></div>';
      } else if (session.phase === "final") {
    
    
        content = closeBtnHtml +
          '<div class="extuiOnboardingBrand extuiOnboardingBrand--complete" aria-hidden="true"><span>✓</span><i></i></div>' +
          '<div class="extuiOnboardingEyebrow">Guia concluído</div>' +
          '<h2 id="extuiOnboardingTitle">Pronto para usar a extensão</h2>' +
          '<p id="extuiOnboardingDescription">Seu progresso foi salvo. Aprofunde na Central de Aprendizado quando quiser, ou já comece a usar a extensão.</p>' +
          '<div class="extuiOnboardingActions extuiOnboardingActions--final">' +
          '<button type="button" class="extuiOnboardingButton extuiOnboardingButton--primary" data-extui-onboarding-action="complete">Abrir Central de Aprendizado</button>' +
          '<button type="button" class="extuiOnboardingButton extuiOnboardingButton--ghost" data-extui-onboarding-action="skip">Continuar sozinho</button>' +
          '</div>';
      } else {
        var step = ONBOARDING_STEPS[session.stepIndex];
        var missingTarget = session.suspended || !extOnboardingTargetRect(step);
        content = closeBtnHtml + extOnboardingProgressMarkup(session.stepIndex) +
          '<div class="extuiOnboardingEyebrow">CONHEÇA A extensão</div>' +
          '<h2 id="extuiOnboardingTitle">' + escHtml(step.title) + '</h2>' +
          '<p id="extuiOnboardingDescription">' + escHtml(step.description) + '</p>' +
          '<div class="extuiOnboardingDetails">' +
          extOnboardingInfoMarkup("Faça agora", step.doNow, "is-do") +
          extOnboardingInfoMarkup("No menu lateral", step.focusNavOnly === true ? "" : extOnboardingContextLabel(step), "is-context") +
          extOnboardingInfoMarkup("Você deve ver", step.expect, "is-expect") +
          extOnboardingInfoMarkup("Dica", step.tip, "is-tip") +
          extOnboardingInfoMarkup("Atenção", step.warning, "is-warning") +
          '</div>' +
          (missingTarget ? '<div class="extuiOnboardingFallback"><p>A área desta etapa ainda não está disponível. O progresso continua salvo.</p><button type="button" class="extuiOnboardingButton extuiOnboardingButton--ghost" data-extui-onboarding-action="return">Tentar novamente</button></div>' : "") +
          '<div class="extuiOnboardingFooter"><button type="button" class="extuiOnboardingSkip" data-extui-onboarding-action="skip">Pular tutorial</button>' +
          '<div class="extuiOnboardingNavActions"><button type="button" class="extuiOnboardingButton extuiOnboardingButton--ghost" data-extui-onboarding-action="back">Voltar</button>' +
          '<button type="button" class="extuiOnboardingButton extuiOnboardingButton--primary" data-extui-onboarding-action="next">Próximo</button></div></div>';
      }
    
      dialog.innerHTML = content;
      if (session.phase === "intro") {
        var onboardingLogoImg = dialog.querySelector(".extuiOnboardingLogoImg");
        if (onboardingLogoImg) extHydrateOnboardingLogo(onboardingLogoImg);
      }
      dialog.setAttribute("aria-labelledby", "extuiOnboardingTitle");
      dialog.setAttribute("aria-describedby", "extuiOnboardingDescription");
      extScheduleOnboardingLayout();
      requestAnimationFrame(function () {
        if (!onboardingRuntime.session || onboardingRuntime.session !== session || session.suspended) return;
        var preferred = dialog.querySelector('[data-extui-onboarding-action="' + (session.phase === "intro" ? "start" : session.phase === "final" ? "complete" : "next") + '"]');
        if (preferred) preferred.focus({ preventScroll: true });
      });
    }
    
    function extPersistOnboarding(patch) {
      var operation = onboardingRuntime.stateWrite.catch(function () {}).then(function () {
    
    
        return extGet(ONBOARDING_STORAGE_KEY).then(function (rawCurrent) {
          var current = extNormalizeOnboardingState(rawCurrent);
          var next = Object.assign({}, current, patch);
          if (patch.lessons) next.lessons = Object.assign({}, current.lessons || {}, patch.lessons);
          onboardingRuntime.state = extNormalizeOnboardingState(next);
          return extSet(ONBOARDING_STORAGE_KEY, onboardingRuntime.state).then(function () { return onboardingRuntime.state; });
        });
      });
      onboardingRuntime.stateWrite = operation.catch(function (err) {
      });
      return operation;
    }
    
    function extCloseOnboarding() {
      var session = onboardingRuntime.session;
      if (!session) return;
      if (session.layoutFrame) cancelAnimationFrame(session.layoutFrame);
      extClearOnboardingNavContext();
      window.removeEventListener("resize", extScheduleOnboardingLayout);
      window.removeEventListener("scroll", extScheduleOnboardingLayout, true);
      if (session.panelStateHandler) window.removeEventListener("ext:panel-state", session.panelStateHandler);
      if (session.railNavigationHandler) window.removeEventListener("ext:rail-navigation-ready", session.railNavigationHandler);
      document.removeEventListener("keydown", extHandleOnboardingKeydown, true);
      session.root.remove();
      onboardingRuntime.session = null;
      if (session.previousFocus && session.previousFocus.isConnected && typeof session.previousFocus.focus === "function") {
        session.previousFocus.focus({ preventScroll: true });
      }
    }
    
    function extDismissOnboarding(skipped) {
      var session = onboardingRuntime.session;
      if (!session || session.closing) return;
      session.closing = true;
      session.root.querySelectorAll("button").forEach(function (button) { button.disabled = true; });
      onboardingRuntime.dismissedThisSession = true;
      var persist = Promise.resolve();
      if (skipped) {
        persist = session.manual
          ? extPersistOnboarding({ currentLessonId: null, currentStepId: null, currentContext: null, pendingTransition: null })
          : extPersistOnboarding({ academyVersion: ONBOARDING_VERSION, skippedVersion: ONBOARDING_VERSION, currentLessonId: null, currentStepId: null, currentContext: null, pendingTransition: null });
      }
      persist.finally(extCloseOnboarding);
    }
    
    function extCompleteOnboarding() {
      if (!onboardingRuntime.session || onboardingRuntime.session.closing) return;
      onboardingRuntime.session.closing = true;
      onboardingRuntime.session.root.querySelectorAll("button").forEach(function (button) { button.disabled = true; });
      onboardingRuntime.dismissedThisSession = true;
      var lessonId = onboardingRuntime.session.lessonId || "sidebar-whatsapp";
      var lessonPatch = {}; lessonPatch[lessonId] = true;
      var transition = {
        id: "extuia-dashboard-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8),
        lessonId: lessonId,
        stepId: "complete",
        destinationContext: "dashboard",
        destinationRoute: "academy",
        destinationTarget: ".extuiaPage",
        requestedAt: Date.now()
      };
      extPersistOnboarding({
        academyVersion: ONBOARDING_VERSION,
        lessons: lessonPatch,
        currentLessonId: null,
        currentStepId: null,
        currentContext: "dashboard",
        pendingTransition: transition
      }).then(function (state) {
        var allComplete = ACADEMY_LESSON_IDS.every(function (id) { return state.lessons[id]; });
        if (allComplete && (state.completedVersion || 0) < ONBOARDING_VERSION) {
          return extPersistOnboarding({ completedVersion: ONBOARDING_VERSION });
        }
        return state;
      }).then(function () {
        extCloseOnboarding();
        openShellHtml("academy", { reuseExisting: true }).catch(function (err) { toast("Não foi possível abrir a Central de Aprendizado: " + err.message, true); });
      }).catch(function (err) {
        onboardingRuntime.session.closing = false;
        onboardingRuntime.session.root.querySelectorAll("button").forEach(function (button) { button.disabled = false; });
        toast("Não foi possível salvar a transição para o Painel de Controle: " + err.message, true);
      });
    }
    
    async function extActivateOnboardingPosition(session) {
      if (!onboardingRuntime.session || onboardingRuntime.session !== session) return;
      var step = session.phase === "step" ? ONBOARDING_STEPS[session.stepIndex] : null;
      session.suspended = false;
      session.expectedNavKey = step && step.navKey ? step.navKey : null;
      session.expectedPanelId = null;
      await extPersistOnboarding({
        currentStepId: session.phase === "intro" ? "welcome" : session.phase === "final" ? "complete" : (step.id || "step-" + session.stepIndex),
        currentContext: "whatsapp"
      });
      if (!onboardingRuntime.session || onboardingRuntime.session !== session) return;
      if (step) {
        try { await extPrepareOnboardingDestination(step); }
        catch (err) { session.suspended = true; }
      }
      if (onboardingRuntime.session === session) extRenderOnboarding();
    }
    
    function extHandleOnboardingAction(action) {
      var session = onboardingRuntime.session;
      if (!session) return;
      if (action === "skip") { extDismissOnboarding(true); return; }
      if (action === "start") {
        session.phase = "step"; session.stepIndex = 0;
        extPersistOnboarding({ academyVersion: ONBOARDING_VERSION, currentLessonId: session.lessonId }).then(function () {
          return extActivateOnboardingPosition(session);
        }).catch(function () { if (onboardingRuntime.session === session) { session.suspended = true; extRenderOnboarding(); } });
        return;
      }
      if (action === "complete") { extCompleteOnboarding(); return; }
      if (action === "return") {
        extActivateOnboardingPosition(session).catch(function () { if (onboardingRuntime.session === session) { session.suspended = true; extRenderOnboarding(); } });
        return;
      }
      if (action === "back") {
        if (session.stepIndex === 0) session.phase = "intro";
        else session.stepIndex--;
        extActivateOnboardingPosition(session).catch(function () { if (onboardingRuntime.session === session) { session.suspended = true; extRenderOnboarding(); } });
        return;
      }
      if (action === "next") {
        if (session.stepIndex >= ONBOARDING_STEPS.length - 1) session.phase = "final";
        else session.stepIndex++;
        extActivateOnboardingPosition(session).catch(function () { if (onboardingRuntime.session === session) { session.suspended = true; extRenderOnboarding(); } });
      }
    }
    
    function extHandleOnboardingKeydown(ev) {
      var session = onboardingRuntime.session;
      if (!session) return;
      if (ev.key === "Escape") {
        ev.preventDefault();
    
        extDismissOnboarding(false);
        return;
      }
    }
    
    function extStartOnboarding(manual, requestedLessonId, requestedStepId, transitionId) {
      if (!extTutorialsOperational()) return false;
      if (onboardingRuntime.session) {
        if (transitionId && onboardingRuntime.session.transitionId === transitionId) {
          var sameDialog = onboardingRuntime.session.root.querySelector(".extuiOnboardingDialog");
          if (sameDialog) sameDialog.focus({ preventScroll: true });
          return onboardingRuntime.session;
        }
        if (requestedLessonId) {
          extCloseOnboarding();
          return extStartOnboarding(manual, requestedLessonId, requestedStepId, transitionId);
        }
        var activeDialog = onboardingRuntime.session.root.querySelector(".extuiOnboardingDialog");
        if (activeDialog) activeDialog.focus({ preventScroll: true });
        return onboardingRuntime.session;
      }
      var lessonId = ACADEMY_WHATSAPP_LESSONS[requestedLessonId] ? requestedLessonId : "sidebar-whatsapp";
      ONBOARDING_STEPS = ACADEMY_WHATSAPP_LESSONS[lessonId];
      var requestedIndex = ONBOARDING_STEPS.findIndex(function (step, index) { return (step.id || "step-" + index) === requestedStepId; });
      var startWithIntro = lessonId === "sidebar-whatsapp" && (!requestedStepId || requestedStepId === "welcome");
      var requestedStep = ONBOARDING_STEPS[requestedIndex >= 0 ? requestedIndex : 0];
      if (!requestedStep || !requestedStep.navKey) closeAllPanels();
      var root = document.createElement("div");
      root.className = "extuiOnboardingRoot";
      root.innerHTML = '<div class="extOnboardingMask" data-extui-onboarding-mask="full"></div>' +
        '<div class="extOnboardingMask" data-extui-onboarding-mask="top"></div>' +
        '<div class="extOnboardingMask" data-extui-onboarding-mask="left"></div>' +
        '<div class="extOnboardingMask" data-extui-onboarding-mask="right"></div>' +
        '<div class="extOnboardingMask" data-extui-onboarding-mask="bottom"></div>' +
        '<div class="extuiOnboardingSpotlight" aria-hidden="true"></div>' +
        '<section class="extuiOnboardingDialog" role="dialog" aria-modal="false" tabindex="-1"></section>';
      document.body.appendChild(root);
      onboardingRuntime.session = {
        root: root,
        phase: startWithIntro ? "intro" : "step",
        stepIndex: requestedIndex >= 0 ? requestedIndex : 0,
        lessonId: lessonId,
        manual: !!manual,
        previousFocus: document.activeElement,
        layoutFrame: null,
        closing: false,
        transitionId: transitionId || null,
        suspended: false,
        expectedNavKey: requestedStep && requestedStep.navKey ? requestedStep.navKey : null,
        expectedPanelId: null,
        panelStateHandler: null,
        railNavigationHandler: null
      };
      root.addEventListener("click", function (ev) {
        var trigger = ev.target.closest("[data-extui-onboarding-action]");
        if (trigger) extHandleOnboardingAction(trigger.getAttribute("data-extui-onboarding-action"));
      });
      window.addEventListener("resize", extScheduleOnboardingLayout);
      window.addEventListener("scroll", extScheduleOnboardingLayout, true);
      onboardingRuntime.session.panelStateHandler = function (event) {
        var active = onboardingRuntime.session;
        if (!active || !event.detail || event.detail.open !== false) return;
        if (active.expectedPanelId && event.detail.panelId === active.expectedPanelId) {
          active.suspended = true;
          extRenderOnboarding();
        }
      };
      onboardingRuntime.session.railNavigationHandler = function (event) {
        var active = onboardingRuntime.session;
        var detail = event.detail || {};
        if (!active || detail.source !== "user") return;
        if (!active.expectedNavKey || detail.key !== active.expectedNavKey || detail.open === false) {
          active.suspended = true;
          extRenderOnboarding();
        }
      };
      window.addEventListener("ext:panel-state", onboardingRuntime.session.panelStateHandler);
      window.addEventListener("ext:rail-navigation-ready", onboardingRuntime.session.railNavigationHandler);
      document.addEventListener("keydown", extHandleOnboardingKeydown, true);
      extPersistOnboarding({
        academyVersion: ONBOARDING_VERSION,
        academyEntryMode: manual ? "manual" : "auto",
        currentLessonId: lessonId,
        currentStepId: startWithIntro ? "welcome" : (ONBOARDING_STEPS[onboardingRuntime.session.stepIndex].id || "step-" + onboardingRuntime.session.stepIndex),
        currentContext: "whatsapp"
      });
      extRenderOnboarding();
      return onboardingRuntime.session;
    }
    
    var EXTUI_ACADEMY_V2_NAV = __extWorkspaceStaticData.EXTUI_ACADEMY_V2_NAV;
    
    function extAcademyNavigateViaV2(key) {
      var def = EXTUI_ACADEMY_V2_NAV[key];
      var bus = window.ExtensionUI && window.ExtensionUI.commands;
      if (!def || !bus || typeof bus.execute !== "function" || !bus.has(def.command)) return null;
      return Promise.resolve(bus.execute(def.command, { source: "academy" })).then(function (result) {
        return Promise.resolve(bus.state(def.command, { source: "academy-state" })).catch(function () { return null; }).then(function (state) {
          var active = !!(result && result.active);
          if (state && state.state && typeof state.state.active === "boolean") active = state.state.active;
          var navigation = { key: key, panelId: def.panelId || null, open: active !== false, panelReady: !def.panelId || !!document.getElementById(def.panelId) };
          window.dispatchEvent(new CustomEvent("ext:rail-navigation-ready", { detail: Object.assign({}, navigation, { source: "academy", ensureOpen: true }) }));
          return navigation;
        });
      });
    }
    
    function extEnsureAcademyIconVisible(step) {
      if (!step || step.focusNavOnly !== true) return Promise.resolve(true);
      return Promise.resolve(!!extOnboardingFirstTargetElement(step));
    }
    
    function extPrepareOnboardingDestination(step) {
      if (!step) return Promise.resolve(true);
      if (step.focusNavOnly === true || step.autoOpen === false || !step.navKey) {
        if (onboardingRuntime.session) {
          onboardingRuntime.session.expectedNavKey = step.navKey || null;
          onboardingRuntime.session.expectedPanelId = null;
          onboardingRuntime.session.suspended = false;
        }
        return extEnsureAcademyIconVisible(step).then(function () {
          return extWaitForOnboardingTarget(step, 5000);
        }).then(function (ready) {
          if (!ready) throw new Error("O botão desta etapa não ficou disponível dentro do tempo esperado.");
          var target = extOnboardingFirstTargetElement(step);
          if (target && typeof target.scrollIntoView === "function") {
            try { target.scrollIntoView({ block: "center", inline: "nearest", behavior: "smooth" }); } catch (_) { target.scrollIntoView({ block: "center" }); }
          }
          return extOnboardingStableTargetRect(step).then(function (rect) {
            if (!rect) throw new Error("O botão desta etapa desapareceu antes de ficar estável.");
            return { key: step.navKey || null, panelId: null, open: false, panelReady: true, iconOnly: true };
          });
        });
      }
      var navigationPromise = window.__EXT_SIDEBAR_ENABLED__ === true ? extAcademyNavigateViaV2(step.navKey) : null;
      if (!navigationPromise) {
        var rail = window.__extRailNavigation;
        if (!rail || typeof rail.navigate !== "function" || !rail.has(step.navKey)) {
          return Promise.reject(new Error("O atalho desta etapa não está disponível."));
        }
        navigationPromise = rail.navigate(step.navKey, { ensureOpen: true, source: "academy" });
      }
      return navigationPromise.then(function (navigation) {
        if (!navigation || navigation.open !== true) {
          throw new Error("O painel desta etapa não pôde ser aberto.");
        }
        if (onboardingRuntime.session) {
          onboardingRuntime.session.expectedNavKey = step.navKey;
          onboardingRuntime.session.expectedPanelId = navigation.panelId || null;
          onboardingRuntime.session.suspended = false;
        }
        return extWaitForOnboardingTarget(step, 5000).then(function (ready) {
          if (!ready) throw new Error("O painel abriu, mas o alvo da etapa não ficou disponível dentro do tempo esperado.");
          var target = extOnboardingFirstTargetElement(step);
          if (target && typeof target.scrollIntoView === "function") {
            try { target.scrollIntoView({ block: "center", inline: "nearest", behavior: "smooth" }); } catch (_) { target.scrollIntoView({ block: "center" }); }
          }
          return extOnboardingStableTargetRect(step).then(function (rect) {
            if (!rect) throw new Error("O alvo da etapa desapareceu antes de ficar estável.");
            navigation.panelReady = true;
            return navigation;
          });
        });
      });
    }
    
    function extReplyToAcademyNavigate(transitionId, result) {
      return { transitionId: transitionId || null, result: result || {} };
    }
    
    function extNormalizeAcademyNavigate(raw) {
      raw = raw && typeof raw === "object" ? raw : {};
      var transition = raw.transition && typeof raw.transition === "object" ? raw.transition : null;
      var transitionId = raw.transitionId || (transition && transition.id) || null;
      if (typeof transitionId !== "string" || !transitionId.trim()) throw new Error("A transição da Academy é inválida.");
      var lessonId = ACADEMY_WHATSAPP_LESSONS[raw.lessonId] ? raw.lessonId : "sidebar-whatsapp";
      var steps = ACADEMY_WHATSAPP_LESSONS[lessonId];
      var requestedStepId = typeof raw.stepId === "string" && raw.stepId ? raw.stepId : "welcome";
      var startWithIntro = lessonId === "sidebar-whatsapp" && requestedStepId === "welcome";
      var stepIndex = steps.findIndex(function (step, index) { return (step.id || "step-" + index) === requestedStepId; });
      if (!startWithIntro && stepIndex < 0) stepIndex = 0;
      var step = startWithIntro ? null : steps[stepIndex];
      var panel = typeof raw.panel === "string" && raw.panel ? raw.panel : null;
      if (panel && (!step || step.navKey !== panel)) throw new Error("O painel solicitado não pertence a esta etapa da Academy.");
      return {
        transitionId: transitionId,
        lessonId: lessonId,
        stepId: startWithIntro ? "welcome" : (step.id || "step-" + stepIndex),
        panel: panel || (step && step.navKey) || null,
        step: step
      };
    }
    
    function extRememberAcademyCommandResult(transitionId, result) {
      onboardingRuntime.academy.results[transitionId] = result;
      onboardingRuntime.academy.resultOrder.push(transitionId);
      if (onboardingRuntime.academy.resultOrder.length > 48) {
        delete onboardingRuntime.academy.results[onboardingRuntime.academy.resultOrder.shift()];
      }
      return result;
    }
    
    function extAcademyRuntimeReady() {
      var loginUiClosed = !document.getElementById("extapp-login-overlay-root") && !document.getElementById("extapp-login-offline-root");
      var activeWppReady = onboardingRuntime.wppReady || !!(window.ExtensionChatBridge && window.ExtensionChatBridge.isReady);
      var v2Host = document.getElementById("ext-sidebar-host");
      var sidebarReady = window.__EXT_SIDEBAR_ENABLED__ === true
        ? !!(v2Host && v2Host.isConnected && !v2Host.hidden && window.ExtensionUI && window.ExtensionUI.commands)
        : !!document.getElementById("extapp-sidebar-nav-root");
      return onboardingRuntime.eligibilityLoaded && onboardingRuntime.accessLoaded && _e1 &&
        activeWppReady && loginUiClosed && sidebarReady;
    }
    
    function extWaitForAcademyRuntime() {
      if (extAcademyRuntimeReady()) return Promise.resolve(true);
      return new Promise(function (resolve, reject) {
        var timer = setTimeout(function () {
          cleanup();
          reject(new Error("O WhatsApp ainda não está pronto para abrir esta etapa."));
        }, 8000);
        function cleanup() {
          clearTimeout(timer);
          window.removeEventListener("ext:academy-runtime-ready", onReady);
        }
        function onReady() { cleanup(); resolve(true); }
        window.addEventListener("ext:academy-runtime-ready", onReady);
        if (extAcademyRuntimeReady()) onReady();
      });
    }
    
    async function extRunAcademyNavigate(command) {
      await extWaitForAcademyRuntime();
      var navigation = command.step ? await extPrepareOnboardingDestination(command.step) : { panelReady: true, panelId: null };
      var session = extStartOnboarding(true, command.lessonId, command.stepId, command.transitionId);
      if (session) {
        session.expectedNavKey = command.panel;
        session.expectedPanelId = navigation && navigation.panelId ? navigation.panelId : null;
        session.suspended = false;
      }
      await new Promise(function (resolve) { requestAnimationFrame(function () { requestAnimationFrame(resolve); }); });
      if (!session || !onboardingRuntime.session || onboardingRuntime.session !== session) throw new Error("A Academy não conseguiu montar a etapa.");
      var targetReady = !command.step || await extWaitForOnboardingTarget(command.step, 5000);
      if (command.step && command.step.navKey && !targetReady) throw new Error("O alvo da etapa não ficou disponível dentro do tempo esperado.");
      if (command.step && targetReady) await extOnboardingStableTargetRect(command.step);
      await extPersistOnboarding({ pendingTransition: null, lastCompletedTransitionId: command.transitionId });
      return { ok: true, panelReady: !command.panel || !!(navigation && navigation.panelReady), targetReady: targetReady };
    }
    
    function extSubmitAcademyNavigate(raw) {
      if (!extTutorialsOperational()) {
        var unavailable = new Error("FEATURE_UNAVAILABLE");
        unavailable.code = "FEATURE_UNAVAILABLE";
        return Promise.reject(unavailable);
      }
      var command;
      try { command = extNormalizeAcademyNavigate(raw); }
      catch (err) {
        var invalidId = raw && (raw.transitionId || (raw.transition && raw.transition.id));
        extReplyToAcademyNavigate(invalidId, { ok: false, error: err.message, panelReady: false, targetReady: false });
        return Promise.reject(err);
      }
      var transitionId = command.transitionId;
      var remembered = onboardingRuntime.academy.results[transitionId];
      if (remembered) {
        extReplyToAcademyNavigate(transitionId, remembered);
        return Promise.resolve(remembered);
      }
      var operation = onboardingRuntime.academy.operations[transitionId];
      if (!operation) {
        operation = onboardingRuntime.academy.queue.catch(function () {}).then(function () {
          return extRunAcademyNavigate(command);
        }).then(function (result) {
          return extRememberAcademyCommandResult(transitionId, result);
        });
        onboardingRuntime.academy.operations[transitionId] = operation;
        onboardingRuntime.academy.queue = operation.catch(function () {});
        operation.then(function () { delete onboardingRuntime.academy.operations[transitionId]; }, function () { delete onboardingRuntime.academy.operations[transitionId]; });
      }
    
    
      operation.then(function (result) {
        extReplyToAcademyNavigate(transitionId, result);
      }).catch(function (err) {
        extReplyToAcademyNavigate(transitionId, { ok: false, error: err && err.message ? err.message : String(err), panelReady: false, targetReady: false });
      });
      return operation;
    }

    if (globalThis.chrome && chrome.runtime && chrome.runtime.onMessage && typeof chrome.runtime.onMessage.addListener === "function" && !window.__extAcademyMessageBridgeBound) {
      window.__extAcademyMessageBridgeBound = true;
      chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
        if (!message || !sender || sender.id !== chrome.runtime.id || message.__extAcademyCommand !== true || !message.academyNavigate) return;
        var raw = message.academyNavigate;
        var transitionId = raw.transitionId || (raw.transition && raw.transition.id) || null;
        Promise.resolve(extSubmitAcademyNavigate(raw)).then(function (result) {
          result = result || {};
          sendResponse({ ok: result.ok === true, transitionId: transitionId, panelReady: result.panelReady === true, targetReady: result.targetReady === true, error: result.error || null });
        }).catch(function (err) {
          sendResponse({ ok: false, transitionId: transitionId, panelReady: false, targetReady: false, error: err && err.message ? err.message : String(err) });
        });
        return true;
      });
    }
    
    function extEvaluateOnboardingEligibility() {
      if (!extTutorialsOperational()) {
        if (onboardingRuntime.session) extCloseOnboarding();
        return false;
      }
      if (!extAcademyRuntimeReady()) return;
      window.dispatchEvent(new CustomEvent("ext:academy-runtime-ready"));
      if (onboardingRuntime.session) return;
      if (onboardingRuntime.state.currentContext === "whatsapp" && onboardingRuntime.state.currentLessonId && !onboardingRuntime.state.lessons[onboardingRuntime.state.currentLessonId]) {
        var pending = onboardingRuntime.state.pendingTransition;
        if (pending && pending.destinationContext === "whatsapp") {
          extSubmitAcademyNavigate({ transitionId: pending.id, transition: pending, lessonId: pending.lessonId, stepId: pending.stepId, panel: pending.panel || pending.destinationRoute || null });
        } else {
          var resumeLessonId = onboardingRuntime.state.currentLessonId;
          var resumeSteps = ACADEMY_WHATSAPP_LESSONS[resumeLessonId] || [];
          var resumeStepIndex = resumeSteps.findIndex(function (step, index) { return (step.id || "step-" + index) === onboardingRuntime.state.currentStepId; });
          var resumeStep = resumeStepIndex >= 0 ? resumeSteps[resumeStepIndex] : null;
          if (resumeStep && resumeStep.navKey) {
            extSubmitAcademyNavigate({
              transitionId: "extuia-resume-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8),
              lessonId: resumeLessonId,
              stepId: resumeStep.id || "step-" + resumeStepIndex,
              panel: resumeStep.navKey
            });
          } else {
            extStartOnboarding(onboardingRuntime.state.academyEntryMode !== "auto", resumeLessonId, onboardingRuntime.state.currentStepId);
          }
        }
        return;
      }
      if (!onboardingRuntime.dismissedThisSession && !extOnboardingVersionHandled(onboardingRuntime.state)) extStartOnboarding(false);
    }
    
    function _e2(value) {
      onboardingRuntime.accessLoaded = true;
      _e1 = !!(value && value.authorized === true);
      if (!_e1 && onboardingRuntime.session) extCloseOnboarding();
      extEvaluateOnboardingEligibility();
    }
    
    function extApplyOnboardingWppStatus(value) {
      onboardingRuntime.wppReady = value === "ready" && !!(window.ExtensionChatBridge && window.ExtensionChatBridge.isReady);
      extEvaluateOnboardingEligibility();
    }
    
    function _e3() {
      var service = window.__extS0;
      if (!service || typeof service._p !== "function") { _e2({ authorized: false, reason: "licenseServiceUnavailable" }); return Promise.resolve(false); }
      return Promise.resolve(service._p()).then(function (result) { _e2(result || { authorized: false, reason: "accessDenied" }); return !!(result && result.authorized); }).catch(function () { _e2({ authorized: false, reason: "accessCheckFailed" }); return false; });
    }
    
    function extInitOnboarding() {
      if (!extTutorialsOperational()) return false;
      extOnKeyChange("EXTUI:license", _e3);
      extOnKeyChange("EXTUI:wppStatus", extApplyOnboardingWppStatus);
      extOnKeyChange(ONBOARDING_STORAGE_KEY, function (value) {
        onboardingRuntime.state = extNormalizeOnboardingState(value);
        extEvaluateOnboardingEligibility();
      });
      _e3();
      Promise.all([extGet("EXTUI:wppStatus"), extGet(ONBOARDING_STORAGE_KEY)]).then(function (values) {
        onboardingRuntime.wppReady = values[0] === "ready" && !!(window.ExtensionChatBridge && window.ExtensionChatBridge.isReady);
        onboardingRuntime.state = extNormalizeOnboardingState(values[1]);
        onboardingRuntime.eligibilityLoaded = true;
        extEvaluateOnboardingEligibility();
      }).catch(function (err) {
      });
    }
    
    
    return Object.freeze({ init:extInitOnboarding, start:extStartOnboarding, submitAcademyNavigate:extSubmitAcademyNavigate, evaluateEligibility:extEvaluateOnboardingEligibility, applyWppStatus:extApplyOnboardingWppStatus, syncNavContext:extSyncOnboardingNavContext });
  };
})();
