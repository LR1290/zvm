;(function () {
  "use strict";
  if (window.__extCreatePanelRegistry) return;
  window.__extCreatePanelRegistry = function (options) {
    options = options || {};
    var dispose = typeof options.dispose === "function" ? options.dispose : function () {};
    var reattach = typeof options.reattach === "function" ? options.reattach : function (root) {
      if (!root || root.nodeType !== 1 || root.ownerDocument !== document || !document.body) return false;
      try { document.body.appendChild(root); return !!root.isConnected; } catch (_) { return false; }
    };
    var entries = Object.create(null);
    function ensure(name, builder) {
      name = String(name || "");
      var cached = entries[name];
      if (cached && cached.isConnected) return Promise.resolve(cached);
      if (cached && reattach(cached)) {
        if(window.__extPanelSessionDraft&&typeof window.__extPanelSessionDraft.restore==="function")Promise.resolve(window.__extPanelSessionDraft.restore(cached)).catch(function(){});
        return Promise.resolve(cached);
      }
      var preserve=cached&&window.__extPanelSessionDraft&&typeof window.__extPanelSessionDraft.persist==="function"?Promise.resolve(window.__extPanelSessionDraft.persist(cached)).catch(function(){return false;}):Promise.resolve(false);
      return preserve.then(function(){if(cached){dispose(cached);delete entries[name];}return Promise.resolve(builder());}).then(function (root) {
        entries[name] = root;
        if(window.__extPanelSessionDraft&&typeof window.__extPanelSessionDraft.restore==="function")Promise.resolve(window.__extPanelSessionDraft.restore(root)).catch(function(){});
        return root;
      });
    }
    function prune() {
      Object.keys(entries).forEach(function (name) {
        var root = entries[name];
        if (!root) { delete entries[name]; return; }
        if (!root.isConnected && reattach(root)) {
          if(window.__extPanelSessionDraft&&typeof window.__extPanelSessionDraft.restore==="function")Promise.resolve(window.__extPanelSessionDraft.restore(root)).catch(function(){});
          return;
        }
        if (!root.isConnected) {
          if(window.__extPanelSessionDraft&&typeof window.__extPanelSessionDraft.persist==="function")Promise.resolve(window.__extPanelSessionDraft.persist(root)).catch(function(){});
          dispose(root);
          delete entries[name];
        }
      });
    }
    function forEach(fn) {
      Object.keys(entries).forEach(function (name) { fn(entries[name], name); });
    }
    function get(name) { return entries[String(name || "")] || null; }
    return Object.freeze({ ensure: ensure, prune: prune, forEach: forEach, get: get });
  };
})();
