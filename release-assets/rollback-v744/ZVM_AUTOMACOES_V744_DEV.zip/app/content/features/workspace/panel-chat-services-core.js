;(function(){
  "use strict";
  if(window.__extCreatePanelChatServicesCore)return;
  window.__extCreatePanelChatServicesCore=function(){
    async function extGetActiveContactContext() {
      var chat=null,chatId="",contact=null,contactCard=null,businessProfile=null;
      try{
        if(window.ExtensionChatBridge&&window.ExtensionChatBridge.chat&&typeof window.ExtensionChatBridge.chat.getActiveChat==="function")chat=await window.ExtensionChatBridge.chat.getActiveChat();
      }catch(_){}
      if((!chat||!chat.id)&&window.__extWppBridge&&typeof window.__extWppBridge.invoke==="function"){
        try{chat=await window.__extWppBridge.invoke("Chat","getActiveChat","@");}catch(_){}
      }
      chatId=String(chat&&chat.id&&chat.id._serialized||chat&&chat._serialized||chat&&chat.id||"");
      if(!chatId&&window.__extWppBridge&&typeof window.__extWppBridge.invoke==="function"){
        try{var fallbackChat=await window.__extWppBridge.invoke("Chat","getActiveChat","@");chatId=String(fallbackChat&&fallbackChat.id&&fallbackChat.id._serialized||fallbackChat&&fallbackChat._serialized||fallbackChat&&fallbackChat.id||"");if(!chat)chat=fallbackChat;}catch(_){}
      }
      if(!chatId)return null;
      if(chatId.indexOf("@g.us")!==-1)return { group: true, chatId: chatId };
      var phone = chat&&chat.id&&chat.id.server === "c.us" ? chat.id.user : null;
      if(!phone&&/@c\.us$/.test(chatId))phone=String(chatId).split("@")[0].replace(/\D/g,"");
      if (!phone && chatId.indexOf("@lid") !== -1 && window.ExtensionChatBridge && window.ExtensionChatBridge.contact && typeof window.ExtensionChatBridge.contact.getPnLidEntry === "function") {
        try {
          var lidEntry = await window.ExtensionChatBridge.contact.getPnLidEntry(chatId),pn=lidEntry&&lidEntry.phoneNumber||null,pnId=pn&&pn.id||pn;
          phone = pnId&&typeof pnId==="object"?(pnId.user||pnId._serialized||""):pnId;
          if(typeof phone==="string"&&phone.indexOf("@")>=0)phone=phone.split("@")[0];
        } catch (_) { phone = null; }
      }
      contact = chat && chat.contact || null;
      if (!contact && window.ExtensionChatBridge && window.ExtensionChatBridge.contact && typeof window.ExtensionChatBridge.contact.get === "function") { try { contact = await window.ExtensionChatBridge.contact.get(chatId); } catch (_) {} }
      if(window.__extWppBridge&&typeof window.__extWppBridge.invoke==="function"){
        try{contactCard=await window.__extWppBridge.invoke("Utils","get-card",chatId);if(contactCard&&contactCard.contact)contact=contactCard.contact;businessProfile=contactCard&&contactCard.businessProfile||null;}catch(_){}
      }
      if(!phone&&contact){
        try{var contactId=contact.id||contact.wid||contact.phoneNumber||null;if(contactId&&typeof contactId==="object"&&contactId.server==="c.us"&&contactId.user)phone=contactId.user;else{var serialized=String(contactId&&contactId._serialized||"");if(serialized.indexOf("@c.us")>0)phone=serialized.split("@")[0];}}catch(_){}
      }
      var actualName = (contact && (contact.name || contact.pushname || contact.verifiedName || contact.formattedName)) || chat&&chat.name || chat&&chat.formattedTitle || phone || "Contato";
      var metadata=null;
      if(window.__extContactMetadataService&&typeof window.__extContactMetadataService.get==="function"){try{metadata=await window.__extContactMetadataService.get(chatId);}catch(_){}}
      var localAlias=String(metadata&&metadata.localAlias||"").trim();
      var name=localAlias||actualName;
      var result={ chatId: chatId, phone: phone ? String(phone).replace(/\D/g, "") : String(chatId).replace(/\D/g, ""), name: name, actualName: actualName, localAlias: localAlias, metadata: metadata||null, contact:contact||null, businessProfile:businessProfile||null, contactCard:contactCard||null, group: false };
      return result;
    }

    async function extInvokeCapability(name, context) {
      if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Ferramentas avançadas do chat");
      if (!window.__extChatCapabilities) throw new Error("Ferramentas do chat ainda não ficaram prontas.");
      return window.__extChatCapabilities.invoke(name, context || {});
    }

    async function extRunConversationAction(def){
      def=def||{};var ctx=await extGetActiveContactContext();if(!ctx||!ctx.chatId)throw new Error("Abra uma conversa antes de executar esta ação.");
      if((def.id==="bloquear_contato"||def.id==="desbloquear_contato")&&ctx.group)throw new Error("Esta ação está disponível somente para conversas individuais.");
      if(def.actionType){
        var executor=window.ExtensionCore&&window.ExtensionCore.ActionExecutor;if(!executor||typeof executor.execute!=="function")throw new Error("Executor de ações ainda não ficou pronto.");
        var out=await executor.execute([{id:"chat-header-action-"+Date.now().toString(36),type:def.actionType,properties:{}}],{source:"chat-header-actions",contactId:ctx.chatId,remetente:ctx.chatId,userID:ctx.chatId,interactive:true});
        if(!out||out.status!=="success"){var err=new Error(out&&out.error&&out.error.message||"Não foi possível executar esta ação.");err.code=out&&out.error&&out.error.code||"ACTION_FAILED";throw err;}return out;
      }
      if(def.capability==="insert_name")return extInvokeCapability("insert_name",{insert:true});
      throw new Error("Ação indisponível.");
    }

    return Object.freeze({ getActiveContactContext:extGetActiveContactContext, invokeCapability:extInvokeCapability, runConversationAction:extRunConversationAction });
  };
})();
