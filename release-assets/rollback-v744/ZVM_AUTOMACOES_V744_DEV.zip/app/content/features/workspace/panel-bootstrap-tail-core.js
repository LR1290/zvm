;(function(){
  "use strict";
  if(window.__extCreatePanelBootstrapTailCore)return;
  window.__extCreatePanelBootstrapTailCore=function(deps){
    deps=deps||{};
    var railRuntime=deps.railRuntime,panelRegistry=deps.panelRegistry,disposePanel=deps.disposePanel,chatWorkspaceRegistry=deps.chatWorkspaceRegistry,closeChatWorkspace=deps.closeChatWorkspace;
    if(!railRuntime||typeof railRuntime.handlePagehide!=="function"||typeof railRuntime.armBootGate!=="function"||!panelRegistry||typeof panelRegistry.forEach!=="function"||typeof disposePanel!=="function"||!chatWorkspaceRegistry||typeof chatWorkspaceRegistry.activeKey!=="function"||typeof closeChatWorkspace!=="function")throw new TypeError("Dependências do bootstrap final dos painéis inválidas.");
    var state={started:false,bootTimer:0};
    function activeChatWorkspaceKey(){return chatWorkspaceRegistry.activeKey();}
    function closeActiveChatWorkspace(){return closeChatWorkspace();}
    function handlePagehide(ev){
      railRuntime.handlePagehide(ev);
      if(ev&&ev.persisted)return;
      if(state.bootTimer){clearTimeout(state.bootTimer);state.bootTimer=0;}
      panelRegistry.forEach(function(root){if(root&&!root.isConnected)disposePanel(root);});
    }
    function start(){
      if(state.started)return false;
      state.started=true;
      window.__extGetActiveChatWorkspaceKey=activeChatWorkspaceKey;
      window.__extCloseChatWorkspace=closeActiveChatWorkspace;
      window.addEventListener("pagehide",handlePagehide);
      state.bootTimer=setTimeout(function(){state.bootTimer=0;railRuntime.armBootGate();},1600);
      return true;
    }
    function dispose(){
      if(!state.started)return false;
      state.started=false;
      window.removeEventListener("pagehide",handlePagehide);
      if(state.bootTimer){clearTimeout(state.bootTimer);state.bootTimer=0;}
      if(window.__extGetActiveChatWorkspaceKey===activeChatWorkspaceKey)delete window.__extGetActiveChatWorkspaceKey;
      if(window.__extCloseChatWorkspace===closeActiveChatWorkspace)delete window.__extCloseChatWorkspace;
      return true;
    }
    return Object.freeze({start:start,dispose:dispose,handlePagehide:handlePagehide});
  };
})();
