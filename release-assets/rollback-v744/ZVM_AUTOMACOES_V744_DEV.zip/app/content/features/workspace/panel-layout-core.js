;
(function () {
  "use strict";
  if (window.__extPanelLayoutCore) return;
  var scrollInstalled=new WeakSet(),layoutObservers=new WeakMap(),sectionContents=new WeakMap();
  function extPanelScrollableAncestor(body, target, deltaY) {
    var node = target && target.nodeType === 1 ? target : target && target.parentElement;
    while (node && node !== body) {
      if (node instanceof HTMLElement) {
        var style = window.getComputedStyle(node);
        if ((style.overflowY === "auto" || style.overflowY === "scroll") && node.scrollHeight > node.clientHeight + 1) {
          var canMove = deltaY > 0 ? node.scrollTop + node.clientHeight < node.scrollHeight - 1 : node.scrollTop > 1;
          if (canMove) return node;
        }
      }
      node = node.parentElement;
    }
    return null;
  }
  function extInstallPanelScrollContract(root) {
    if (!root || scrollInstalled.has(root)) return;
    scrollInstalled.add(root);
    root.addEventListener("wheel", function (ev) {
      if (!root.classList.contains("extuiOpen") || ev.ctrlKey || !ev.deltaY) return;
      var body = ev.target && ev.target.closest ? ev.target.closest(".extuiPanelBody,.extuiPanelSubview,.extuiNavPanelSubview") : null;
      if (!body || body.closest(".extuiPanelShell") !== root) return;
      if (extPanelScrollableAncestor(body, ev.target, ev.deltaY)) return;
      if (body.scrollHeight <= body.clientHeight + 1) return;
      var before = body.scrollTop;
      body.scrollTop += ev.deltaY;
      if (body.scrollTop !== before) {
        ev.preventDefault();
        ev.stopPropagation();
      }
    }, { passive: false, capture: true });
    root.addEventListener("keydown", function (ev) {
      if (!root.classList.contains("extuiOpen") || ev.altKey || ev.ctrlKey || ev.metaKey) return;
      var tag = ev.target && ev.target.tagName ? ev.target.tagName.toLowerCase() : "";
      if (tag === "input" || tag === "textarea" || tag === "select" || (ev.target && ev.target.isContentEditable)) return;
      var body = root.querySelector(".extuiPanelSubview:not([hidden]),.extuiNavPanelSubview:not([hidden]),.extuiPanelBody:not([hidden])");
      if (!body || body.scrollHeight <= body.clientHeight + 1) return;
      var amount = 0;
      if (ev.key === "PageDown") amount = Math.max(80, body.clientHeight * .82);
      else if (ev.key === "PageUp") amount = -Math.max(80, body.clientHeight * .82);
      else if (ev.key === "ArrowDown") amount = 42;
      else if (ev.key === "ArrowUp") amount = -42;
      else if (ev.key === "Home") { body.scrollTop = 0; ev.preventDefault(); return; }
      else if (ev.key === "End") { body.scrollTop = body.scrollHeight; ev.preventDefault(); return; }
      else return;
      body.scrollTop += amount;
      ev.preventDefault();
    });
  }

  function panelBody(root) { return root.querySelector("[data-extui-panel-body]"); }

  var EXTUI_PANEL_LAYOUT = {
    "ext-items-panel-root": { mode: "library", primary: "Seus itens", secondary: "Busca e filtros" },
    "ext-broadcast-panel-root": { mode: "workflow", primary: "Preparar disparo" },
    "extuiNavSystemPanel": { mode: "cards", primary: "Sistema" },
    "extuiNavConfigureMenuPanel": { mode: "settings", primary: "Atalhos da Sidebar" },
    "extuiNavNotificationsPanel": { mode: "notifications", primary: "Notificações" },
    "extuiNavAgendaPanel": { mode: "split", primary: "Novo agendamento", secondary: "Itens agendados" },
    "extuiNavFollowUpPanel": { mode: "stack", primary: "Nova regra", secondary: "Regras criadas" },
    "extuiNavFluxosPanel": { mode: "collection", primary: "Fluxos" },
    "extuiNavFunisPanel": { mode: "collection", primary: "Funis" },
    "extuiNavEnviosPanel": { mode: "activity", primary: "Em andamento", secondary: "Histórico" },
    "extuiNavCrmPanel": { mode: "crm", primary: null },
    "extuiNavOrdersPanel": { mode: "contact", primary: "Encomendas" },
    "extuiNavCrmFunnelPanel": { mode: "analytics", primary: "Funil CRM" },
    "extuiNavStatusPanel": { mode: "split", primary: "Criar status", secondary: "Fila e agendamentos" },
    "extuiNavAutoServicePanel": { mode: "stack", primary: "Nova regra", secondary: "Regras ativas" },
    "extuiNavChatToolsPanel": { mode: "tools", primary: "Ferramentas da conversa" },
    "extuiNavGooglePanel": { mode: "tools", primary: "Google para o trabalho" },
    "extuiNavWebhooksPanel": { mode: "collection", primary: "Avisos configurados" }
  };
  var panelLayoutLocks = new WeakSet();
  function extPanelElement(tag, className, text) {
    var el = document.createElement(tag);
    if (className) el.className = className;
    if (text != null) el.textContent = text;
    return el;
  }
  function extPanelSection(title, role) {
    var section = extPanelElement("section", "extPanelSection" + (role ? " extPanelSection--" + role : ""));
    if (title) {
      var head = extPanelElement("div", "extuiPanelSectionHead");
      var marker = extPanelElement("span", "extuiPanelSectionMarker");
      marker.setAttribute("aria-hidden", "true");
      head.appendChild(marker);
      head.appendChild(extPanelElement("h3", "extuiPanelSectionTitle", title));
      section.appendChild(head);
    }
    var content = extPanelElement("div", "extuiPanelSectionContent");
    section.appendChild(content);
    sectionContents.set(section,content);
    return section;
  }
  function extPanelSectionContent(section){return sectionContents.get(section)||section.querySelector(":scope > .extuiPanelSectionContent");}
  function extPanelMove(target, nodes) {
    (nodes || []).forEach(function (node) { if (node && node.parentNode) target.appendChild(node); });
  }
  function extPanelDirectChildren(body) {
    return Array.prototype.slice.call(body.children).filter(function (el) { return !el.classList.contains("extuiPanelCanvas"); });
  }
  function extPanelNormalizeRow(row) {
    if (!row) return;
    row.classList.add("extuiPanelRow");
    var main = row.querySelector(":scope > .extuiPanelRowMain");
    var actions = row.querySelector(":scope > .extuiPanelRowActions");
    if (!main) main = extPanelElement("div", "extuiPanelRowMain");
    if (!actions) actions = extPanelElement("div", "extuiPanelRowActions");
    var children = Array.prototype.slice.call(row.children).filter(function (child) { return child !== main && child !== actions; });
    var actionSelector = ".extuiSideItensActionBtn,.extuiSideItensMoreWrap,.extuiNavAgendaCancelBtn,.extuiActivityActions,.extuiOrdersDockActions,.extuiSystemMenuChevron,.extuiDockedPanelLink,.extuiNavDangerBtn,.extuiNavSecondaryBtn";
    children.forEach(function (child) {
      if (child.matches && child.matches(actionSelector)) actions.appendChild(child);
      else main.appendChild(child);
    });
    if (!main.parentNode) row.appendChild(main);
    if (actions.children.length && !actions.parentNode) row.appendChild(actions);
    if (!actions.children.length && actions.parentNode) actions.remove();
    row.dataset.extuiPanelRowNormalized = "1";
  }
  function extPanelNormalizeForms(root) {
    root.querySelectorAll(".extuiNavAgendaForm,.extuiCrmQuickComposer,.extuiOrdersQuickForm,.extuiPanelFormSurface,.extuiStatusQuickForm,.extuiAutoServiceQuickForm,.extuiToolForm,.extuiDisparosBody").forEach(function (form) { form.classList.add("extuiPanelForm"); });
    root.querySelectorAll(".extuiFieldGroup,.extField").forEach(function (field) { field.classList.add("extuiPanelField"); });
    root.querySelectorAll(".extuiPanelChoiceCard,.extuiPanelToggleCard,.extuiNavToggleRow,.extuiToolCard").forEach(function (card) { card.classList.add("extuiPanelOptionCard"); });
  }
  function extPanelLayoutBody(root) {
    if (!root || panelLayoutLocks.has(root)) return;
    var body = panelBody(root);
    if (!body) return;
    var spec = EXTUI_PANEL_LAYOUT[root.id] || { mode: "collection", primary: "Conteúdo" };
    var layout = body.querySelector(":scope > .extuiPanelCanvas");
    var nodes = extPanelDirectChildren(body);
    if (layout) {
      if (!nodes.length) return;
      if (spec.mode === "crm") { extPanelMove(layout, nodes); return; }
      var primary = layout.querySelector(".extPanelSection--main .extuiPanelSectionContent,.extPanelSection--primary .extuiPanelSectionContent,.extuiPanelSectionContent");
      var secondary = layout.querySelector(".extPanelSection--secondary .extuiPanelSectionContent");
      nodes.forEach(function (node) {
        var listLike = node.matches && node.matches(".extuiSideItensList,.extuiNavAgendaList,.extuiAutoServiceList,.extuiStatusQueue,.extuiDockedPanelList,.extuiNotificationList,.extuiOrdersDockList");
        if (spec.mode === "library" && listLike) {
          var library = layout.querySelector(".extPanelSection--main .extuiPanelSectionContent");
          (library || primary || body).appendChild(node);
        } else if ((spec.mode === "split" || spec.mode === "stack") && listLike && secondary) secondary.appendChild(node);
        else (primary || secondary || body).appendChild(node);
      });
      return;
    }
    if (!nodes.length) return;
    panelLayoutLocks.add(root);
    try {
      layout = extPanelElement("div", "extuiPanelCanvas extuiPanelCanvas--" + spec.mode);
      layout.setAttribute("data-extui-panel-layout", spec.mode);
      body.appendChild(layout);
      if (spec.mode === "crm") {
        extPanelMove(layout, nodes);
      } else if (spec.mode === "library") {
        var controls = extPanelSection(spec.secondary, "controls");
        var library = extPanelSection(spec.primary, "main");
        nodes.forEach(function (node) {
          if (node.matches && node.matches(".extuiSideItensList")) extPanelSectionContent(library).appendChild(node);
          else extPanelSectionContent(controls).appendChild(node);
        });
        layout.appendChild(controls); layout.appendChild(library);
      } else if (spec.mode === "split" || spec.mode === "stack") {
        var first = extPanelSection(spec.primary, "primary");
        var second = extPanelSection(spec.secondary, "secondary");
        if (spec.mode === "stack") {
          nodes.forEach(function (node) {
            var secondaryLike = node.matches && node.matches(".extuiNavAgendaList,.extuiAutoServiceList,.extuiDockedPanelList");
            (secondaryLike ? extPanelSectionContent(second) : extPanelSectionContent(first)).appendChild(node);
          });
          layout.appendChild(first); layout.appendChild(second);
          root.setAttribute("data-extui-panel-layout", spec.mode);
          return;
        }
        if (root.id === "extuiNavStatusPanel") {
          nodes.forEach(function (node) {
            var secondaryLike = node.matches && node.matches(".extuiStatusQueue");
            (secondaryLike ? extPanelSectionContent(second) : extPanelSectionContent(first)).appendChild(node);
          });
        } else if (root.id === "extuiNavAgendaPanel" || root.id === "extuiNavAutoServicePanel") {
          nodes.forEach(function (node) {
            var secondaryLike = node.matches && node.matches(".extuiNavAgendaList,.extuiAutoServiceList,.extuiDockedPanelList");
            (secondaryLike ? extPanelSectionContent(second) : extPanelSectionContent(first)).appendChild(node);
          });
        } else {
          var listIndex = nodes.findIndex(function (node, i) { return i > 0 && node.matches && node.matches(".extuiNavAgendaList,.extuiAutoServiceList,.extuiStatusQueue,.extuiDockedPanelList"); });
          var splitAt = listIndex > 0 ? listIndex : Math.max(1, Math.ceil(nodes.length / 2));
          extPanelMove(extPanelSectionContent(first), nodes.slice(0, splitAt));
          extPanelMove(extPanelSectionContent(second), nodes.slice(splitAt));
        }
        layout.appendChild(first); layout.appendChild(second);
      } else if (spec.mode === "activity") {
        var command = extPanelSection("Controle", "controls");
        var active = extPanelSection(spec.primary, "primary");
        var history = extPanelSection(spec.secondary, "secondary");
        nodes.forEach(function (node) {
          if (node.matches && node.matches(".extuiEnviosCancelAllWrap")) extPanelSectionContent(command).appendChild(node);
          else if (node.matches && node.matches(".extuiDockedPanelList") && !extPanelSectionContent(active).children.length) extPanelSectionContent(active).appendChild(node);
          else if (node.classList && node.classList.contains("extuiNavSectionLabel")) {
            var label = (node.textContent || "").toLowerCase();
            (label.indexOf("recente") >= 0 || label.indexOf("conclu") >= 0 ? extPanelSectionContent(history) : extPanelSectionContent(active)).appendChild(node);
          } else extPanelSectionContent(history).appendChild(node);
        });
        layout.appendChild(command); layout.appendChild(active); layout.appendChild(history);
      } else if (spec.mode === "notifications") {
        var tabs = extPanelSection(null, "controls");
        var inbox = extPanelSection(spec.primary, "main");
        nodes.forEach(function (node) { (node.matches && node.matches(".extuiNotificationTabs") ? extPanelSectionContent(tabs) : extPanelSectionContent(inbox)).appendChild(node); });
        layout.appendChild(tabs); layout.appendChild(inbox);
      } else {
        var single = extPanelSection(spec.primary, "main");
        extPanelMove(extPanelSectionContent(single), nodes);
        layout.appendChild(single);
      }
      root.setAttribute("data-extui-panel-layout", spec.mode);
    } finally { panelLayoutLocks.delete(root); }
  }
  function extPanelDecorate(root) {
    if (!root) return;
    root.classList.add("extuiPanelShell");
    root.querySelectorAll(".extuiDockedPanelRow,.extuiNavAgendaRow,.extActivityRow,.extNotificationCard,.extuiSideItensRow,.extuiAutoServiceRow,.extuiOrdersDockRow").forEach(extPanelNormalizeRow);
    root.querySelectorAll("input,select,textarea").forEach(function (el) { el.classList.add("extuiPanelControl"); });
    root.querySelectorAll(".extuiNavPrimaryBtn,.primary").forEach(function (el) { el.classList.add("extuiPanelPrimaryAction"); });
    root.querySelectorAll(".extuiNavSecondaryBtn,.secondary,.extuiNavGhostBtn").forEach(function (el) { el.classList.add("extuiPanelSecondaryAction"); });
    root.querySelectorAll(".extuiNavDangerBtn,.extuiNavAgendaCancelBtn").forEach(function (el) { el.classList.add("extuiPanelDangerAction"); });
    root.querySelectorAll(".extuiDockedPanelList,.extuiNavAgendaList,.extuiSideItensList,.extuiAutoServiceList,.extuiStatusQueue,.extuiNotificationList,.extuiOrdersDockList").forEach(function (el) { el.classList.add("extuiPanelList"); });
    extPanelNormalizeForms(root);
    root.querySelectorAll(".extPanelSection").forEach(function (section, index) {
      var content = section.querySelector(":scope > .extuiPanelSectionContent");
      var title = section.querySelector(":scope > .extuiPanelSectionHead .extuiPanelSectionTitle");
      var empty = !content || (!content.children.length && !(content.textContent || "").trim());
      section.classList.toggle("extPanelSection--empty", empty);
      if (title) {
        if (!title.id) title.id = (root.id || "extui-panel") + "-section-" + index;
        section.setAttribute("aria-labelledby", title.id);
      }
    });
    var activityPrimary = root.querySelector('.extuiPanelCanvas--activity > .extPanelSection--primary');
    root.classList.toggle('extuiPanelHasActiveQueue', !!(activityPrimary && !activityPrimary.classList.contains('extPanelSection--empty')));
  }
  function extPanelAdopt(root) {
    if (!root) return root;
    var wasOpen = root.classList.contains("extuiOpen");
    Array.prototype.slice.call(root.classList).forEach(function (name) { if (/^extuiWorkspaceV\d+$/.test(name)) root.classList.remove(name); });
    root.classList.add("extuiNavPanel", "extuiPanelShell");
    root.classList.toggle("extuiOpen", wasOpen);
    root.setAttribute("data-extui-panel-shell", "canonical");
    extPanelLayoutBody(root);
    extPanelDecorate(root);
    if (!layoutObservers.has(root)) {
      var body = panelBody(root);
      if (body) {
        var queued = false;
        var observer = new MutationObserver(function () {
          if (queued || panelLayoutLocks.has(root)) return;
          queued = true;
          requestAnimationFrame(function () {
            queued = false;
            if (!root.isConnected) return;
            var first = body.firstElementChild;
            if (!first || !first.classList.contains("extuiPanelCanvas")) extPanelLayoutBody(root);
            extPanelDecorate(root);
          });
        });
        observer.observe(body, { childList: true, subtree: true });
        layoutObservers.set(root,observer);
      }
    }
    return root;
  }
  function dispose(root){var observer=root&&layoutObservers.get(root);if(observer){try{observer.disconnect();}catch(_){}layoutObservers.delete(root);}if(root)scrollInstalled.delete(root);}
  window.__extPanelLayoutCore = Object.freeze({ panelBody: panelBody, installScrollContract: extInstallPanelScrollContract, decorate: extPanelDecorate, adopt: extPanelAdopt, dispose: dispose });
})();
