;(function(){
  "use strict";
  if(window.__extCreateQuickClientContentCore)return;
  window.__extCreateQuickClientContentCore=function(deps){
    deps=deps||{};var clientHelpers=deps.clientHelpers||{};
    var extGetActiveContactContext=deps.getActiveContactContext,extEmptyState=deps.emptyState,extField=deps.field,iconChip=deps.iconChip,escHtml=deps.escHtml,toast=deps.toast;
    var EXTUI_QR_ACCENT=deps.accent,EXTUI_QR_ICON=deps.icon,EXTUI_CLIENT_BR_DDDS=deps.brDdds||[];
    var extQrDownloadXls=clientHelpers.extQrDownloadXls;
    var extClientWait=clientHelpers.extClientWait;
    var extClientDigits=clientHelpers.extClientDigits;
    var extClientPhoneType=clientHelpers.extClientPhoneType;
    var extClientDetectBrazilPhoneType=clientHelpers.extClientDetectBrazilPhoneType;
    var extClientNormalizeBrazilLocal=clientHelpers.extClientNormalizeBrazilLocal;
    var extClientMaskLocalPhone=clientHelpers.extClientMaskLocalPhone;
    var extClientMaskCep=clientHelpers.extClientMaskCep;
    var extClientParsePhoneParts=clientHelpers.extClientParsePhoneParts;
    var extClientBuildPhoneRecord=clientHelpers.extClientBuildPhoneRecord;
    var extClientStateName=clientHelpers.extClientStateName;
    var extClientReadDraft=clientHelpers.extClientReadDraft;
    var extClientWriteDraft=clientHelpers.extClientWriteDraft;
    var extClientClearDraft=clientHelpers.extClientClearDraft;
    var extClientFindDddMeta=clientHelpers.extClientFindDddMeta;
    var extClientPopulateLeadSourceList=clientHelpers.extClientPopulateLeadSourceList;
    var extClientPopulateCountrySelect=clientHelpers.extClientPopulateCountrySelect;
    var extClientUpdateCountryDisplay=clientHelpers.extClientUpdateCountryDisplay;
    var extClientFillStateSelect=clientHelpers.extClientFillStateSelect;
    var extClientUpdateStateDisplay=clientHelpers.extClientUpdateStateDisplay;
    var extClientPopulateCityList=clientHelpers.extClientPopulateCityList;
    var extClientLookupCep=clientHelpers.extClientLookupCep;
    if([extGetActiveContactContext,extEmptyState,extField,iconChip,escHtml,toast].some(function(fn){return typeof fn!=="function";}))throw new TypeError("Dependências do conteúdo rápido do cliente inválidas.");
async function extRenderQuickClientContent(content){
      if(content&&typeof content.__extClientCaptureDraft==="function")try{content.__extClientCaptureDraft();}catch(_){}
      content.__extClientCaptureDraft=null;
      content.innerHTML="";
      var ctx=null;
      for(var extCtxAttempt=0;extCtxAttempt<20;extCtxAttempt++){ctx=await extGetActiveContactContext();if(ctx&&ctx.chatId)break;await extClientWait(250);}
      if(!ctx||ctx.group||!ctx.chatId){content.appendChild(extEmptyState(EXTUI_QR_ACCENT,EXTUI_QR_ICON,"Abra uma conversa individual","O cadastro é específico do cliente atualmente aberto.",null,null,{sober:true}));return;}
      if(!window.__extContactMetadataService){content.appendChild(extEmptyState(EXTUI_QR_ACCENT,EXTUI_QR_ICON,"Perfil indisponível","O serviço de dados do contato ainda não ficou pronto.",null,null,{sober:true}));return;}
      var service=window.__extContactMetadataService,storedMeta=await service.get(ctx.chatId)||{},draftMeta=await extClientReadDraft(ctx.chatId),meta=draftMeta?Object.assign({},storedMeta,draftMeta):storedMeta,profile=ctx.businessProfile&&typeof ctx.businessProfile==="object"?ctx.businessProfile:{},wrap=document.createElement("div");content.dataset.chatId=String(ctx.chatId||"");
      wrap.className="extuiQuickResponseClient extuiQuickResponseClientV2";

      function text(v){return typeof v==="string"?v.trim():"";}
      function first(obj,keys){for(var i=0;i<keys.length;i++){var v=obj&&obj[keys[i]];if(typeof v==="string"&&v.trim())return v.trim();}return "";}
      function addrText(v){if(typeof v==="string")return v.trim();if(v&&typeof v==="object")return [v.street||v.addressLine||v.address,v.number,v.complement].filter(Boolean).join(", ");return "";}
      function recId(prefix,i){return prefix+"-"+String(i+1);}
      function normalizeSimple(list,prefix){return(Array.isArray(list)?list:[]).map(function(x,i){x=x&&typeof x==="object"?x:{};var rawValue=text(x.value||x.email||x.phone),rec={id:String(x.id||recId(prefix,i)),label:text(x.label)||"Pessoal",value:rawValue};if(prefix==="phone"){var parsed=extClientParsePhoneParts(rawValue,text(x.ddi),text(x.ddd),x.phoneType,text(x.countryCode||x.country));rec.value=parsed.number;rec.ddi=parsed.ddi;rec.ddd=parsed.ddd;rec.phoneType=parsed.phoneType||extClientPhoneType(x.phoneType);rec.countryCode=text(x.countryCode||x.country)||parsed.countryCode||(parsed.ddi==="+55"?"BR":"");}return rec;}).filter(function(x){return prefix==="phone"?(x.value||x.ddd):x.value;});}
      function normalizeAddresses(list){return(Array.isArray(list)?list:[]).map(function(x,i){x=x&&typeof x==="object"?x:{};return{id:String(x.id||recId("address",i)),label:text(x.label)||"Residencial",value:text(x.value||x.address||x.street||x.addressLine),number:text(x.number),complement:text(x.complement),reference:text(x.reference),city:text(x.city),state:text(x.state),postalCode:text(x.postalCode||x.zip||x.cep)};}).filter(function(x){return x.value||x.number||x.complement||x.reference||x.city||x.state||x.postalCode;});}

      var profileEmailList=Array.isArray(profile.emails)?profile.emails:[],profileAddressList=Array.isArray(profile.addresses)?profile.addresses:[],autoEmail=first(profile,["email","emailAddress","businessEmail"])||text(profileEmailList[0]&&((profileEmailList[0].value||profileEmailList[0].email)||profileEmailList[0])),autoAddress=addrText(profile.address||profile.businessAddress||profileAddressList[0]||profile.location),autoCity=first(profile,["city","locality"])||first(profileAddressList[0]||{},["city","locality"]),autoState=first(profile,["state","region"])||first(profileAddressList[0]||{},["state","region"]),autoPostal=first(profile,["postalCode","zipCode","zip"])||first(profileAddressList[0]||{},["postalCode","zipCode","zip","cep"]),autoCompany=first(profile,["name","businessName","verifiedName"])||first(ctx.contact||{},["verifiedName"]),emails=normalizeSimple(meta.emails,"email"),phones=normalizeSimple(meta.phones,"phone"),addresses=normalizeAddresses(meta.addresses);
      if(!emails.length){var legacyEmail=text(meta.email)||autoEmail;if(legacyEmail)emails=[{id:"auto-email",label:"Pessoal",value:legacyEmail,_auto:!text(meta.email)}];}
      var extPhoneAutoRepair=false,extuiLidDigits=String(ctx.chatId||"").indexOf("@lid")>0?String(ctx.chatId).split("@")[0].replace(/\D+/g,""):"";
      if(phones.length&&ctx.phone&&extuiLidDigits){
        var poisonIndexes=[];phones.forEach(function(rec,idx){var built=extClientBuildPhoneRecord(rec);if(built&&built.full===extuiLidDigits)poisonIndexes.push(idx);});
        if(poisonIndexes.length){var parsedRepair=extClientParsePhoneParts(String(ctx.phone),"","");var firstPoison=poisonIndexes[0],oldRec=phones[firstPoison]||{};phones[firstPoison]={id:String(oldRec.id||"auto-phone"),label:text(oldRec.label)||"Pessoal",ddi:parsedRepair.ddi,ddd:parsedRepair.ddd,countryCode:parsedRepair.countryCode||(parsedRepair.ddi==="+55"?"BR":""),phoneType:parsedRepair.phoneType,value:parsedRepair.number,_auto:true};phones=phones.filter(function(_,idx){return poisonIndexes.indexOf(idx)<0||idx===firstPoison;});extPhoneAutoRepair=!draftMeta;}
      }
      if(!phones.length&&ctx.phone){var parsedPhone=extClientParsePhoneParts(String(ctx.phone),"","");phones=[{id:"auto-phone",label:"Pessoal",ddi:parsedPhone.ddi,ddd:parsedPhone.ddd,countryCode:parsedPhone.countryCode||(parsedPhone.ddi==="+55"?"BR":""),phoneType:parsedPhone.phoneType,value:parsedPhone.number,_auto:true}];if(extuiLidDigits&&extClientDigits(storedMeta&&storedMeta.phone||"")===extuiLidDigits)extPhoneAutoRepair=!draftMeta;}
      if(!addresses.length){var legacyAddress=text(meta.address)||autoAddress;if(legacyAddress||text(meta.city)||autoCity||text(meta.state)||autoState||text(meta.postalCode)||autoPostal)addresses=[{id:"auto-address",label:"Residencial",value:legacyAddress,city:text(meta.city)||autoCity,state:text(meta.state)||autoState,postalCode:text(meta.postalCode)||autoPostal,_auto:!text(meta.address)}];}

      var form=document.createElement("form");
      form.id="extuiClientCadastroForm";
      form.className="extuiQuickResponseClientForm extuiQuickResponseClientFormV2 extuiClientCadastroForm";

      var identity=document.createElement("div");
      identity.className="extuiQuickResponseClientIdentity extuiClientProfileSticky";
      identity.innerHTML=iconChip(EXTUI_QR_ACCENT,'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',true)+'<div class="extuiClientProfileStickyCopy"><span>Cliente atual</span><strong>'+escHtml(meta.localAlias||ctx.actualName||ctx.name)+'</strong><small>+'+escHtml(ctx.phone||"")+(meta.localAlias&&ctx.actualName?' · WhatsApp: '+escHtml(ctx.actualName):'')+'</small></div>';
      var actions=document.createElement("div");
      actions.className="extuiQuickResponseClientActions extuiQuickResponseClientActionsV2 extuiClientProfileStickyActions";
      var exportBtn=document.createElement("button");exportBtn.type="button";exportBtn.className="extuiNavSecondaryBtn";exportBtn.textContent="Exportar .xls";
      var save=document.createElement("button");save.type="submit";save.className="extuiNavPrimaryBtn";save.textContent="Salvar alterações";
      actions.appendChild(exportBtn);actions.appendChild(save);

      var status=document.createElement("div");
      status.className="extuiClientUnsavedHint extuiClientUnsavedHint--inline";
      status.innerHTML='<div class="extuiClientUnsavedCopy"><span class="extuiClientUnsavedDot"></span><strong>Alterações pendentes</strong><span>Salve para aplicar o cadastro.</span></div><div class="extuiClientUnsavedActions"><button type="button" class="extuiNavSecondaryBtn extuiClientUndoBtn">Desfazer Alterações</button></div>';
      identity.appendChild(status);identity.appendChild(actions);
      var stickyStack=document.createElement("div");
      stickyStack.className="extuiClientCadastroStickyStack";
      stickyStack.appendChild(identity);form.appendChild(stickyStack);

      var layout=document.createElement("div");layout.className="extuiClientCadastroLayout";
      var nav=document.createElement("nav");nav.className="extuiClientCadastroNav";nav.setAttribute("aria-label","Seções do cadastro do cliente");
      var panels=document.createElement("div");panels.className="extuiClientCadastroPanels";
      var panelMap={},tabMap={};
      [["identity","Identidade"],["contacts","Contatos"],["addresses","Endereços"],["acquisition","Aquisição"]].forEach(function(def,index){
        var btn=document.createElement("button");btn.type="button";btn.className="extuiClientCadastroTab"+(index===0?" is-active":"");btn.textContent=def[1];btn.dataset.clientProfileTab=def[0];btn.setAttribute("aria-selected",String(index===0));btn.setAttribute("role","tab");
        var panel=document.createElement("section");panel.className="extuiClientCadastroPanel";panel.dataset.clientProfilePanel=def[0];panel.hidden=index!==0;panel.setAttribute("role","tabpanel");
        btn.addEventListener("click",function(){Object.keys(tabMap).forEach(function(key){var on=key===def[0];tabMap[key].classList.toggle("is-active",on);tabMap[key].setAttribute("aria-selected",String(on));panelMap[key].hidden=!on;});});
        tabMap[def[0]]=btn;panelMap[def[0]]=panel;nav.appendChild(btn);panels.appendChild(panel);
      });
      layout.appendChild(nav);layout.appendChild(panels);form.appendChild(layout);

      var fields={};
      function field(host,name,label,type,placeholder,value){
        var input=type==="select"?document.createElement("select"):document.createElement("input");
        if(type!=="select")input.type=type||"text";
        input.placeholder=placeholder||"";input.value=value||"";fields[name]=input;
        var group=extField(label,input);group.classList.add("extuiClientProfileField");host.appendChild(group);return input;
      }
      function section(host,title,desc){
        var head=document.createElement("div");head.className="extuiClientProfileSectionHead";head.innerHTML='<div><strong>'+escHtml(title)+'</strong><span>'+escHtml(desc||"")+'</span></div>';host.appendChild(head);return head;
      }

      section(panelMap.identity,"Identidade","Informações principais do cliente. Dados encontrados no WhatsApp continuam editáveis.");
      var alias=field(panelMap.identity,"localAlias","Nome exibido pela extensão","text","Nome do cliente",meta.localAlias||ctx.actualName||ctx.name||"");
      if(alias.parentElement)alias.parentElement.classList.add("extuiClientProfileField--wide");
      var gender=field(panelMap.identity,"gender","Sexo","select","",meta.gender||"");
      [["","Não informado"],["feminino","Feminino"],["masculino","Masculino"],["outro","Outro"],["nao-informar","Prefere não informar"]].forEach(function(p){gender.appendChild(new Option(p[1],p[0]));});gender.value=meta.gender||"";
      field(panelMap.identity,"birthDate","Data de nascimento","date","",meta.birthDate||"");
      var language=field(panelMap.identity,"language","Idioma","select","",meta.language||"");
      [["","Automático"],["pt","Português"],["en","Inglês"],["es","Espanhol"]].forEach(function(p){language.appendChild(new Option(p[1],p[0]));});language.value=meta.language||"";
      field(panelMap.identity,"company","Empresa","text","Empresa/organização",meta.company||autoCompany||"");

      section(panelMap.acquisition,"Aquisição","Origem e período de relacionamento com este lead.");
      var leadSource=field(panelMap.acquisition,"leadSource","Origem do lead","text","Indicação, anúncio, Instagram...",meta.leadSource||"");
      var leadSourceList=document.createElement("datalist");leadSourceList.id="extuiClientLeadSourceList-"+Date.now().toString(36);leadSource.setAttribute("list",leadSourceList.id);extClientPopulateLeadSourceList(leadSourceList);
      if(leadSource.parentElement){leadSource.parentElement.classList.add("extuiClientProfileField--wide");leadSource.parentElement.appendChild(leadSourceList);}
      field(panelMap.acquisition,"entryDate","Data de entrada","date","",meta.entryDate||"");
      field(panelMap.acquisition,"exitDate","Data de saída","date","",meta.exitDate||"");

      function extClientAttachEditableCombo(input, options, menuClass){
        if(!input)return null;
        options=(Array.isArray(options)?options:[]).map(function(value){return String(value||"").trim();}).filter(Boolean);
        var parent=input.parentElement;if(!parent)return null;
        var wrap=document.createElement("div");wrap.className="extuiClientComboWrap"+(menuClass?" "+menuClass:"");
        parent.insertBefore(wrap,input);wrap.appendChild(input);
        var menu=document.createElement("div");menu.className="extuiClientComboMenu";menu.hidden=true;wrap.appendChild(menu);
        var open=false,closeTimer=0,useFilter=false,positionBound=false;
        function norm(value){return String(value||"").trim().toLowerCase();}
        function currentQuery(){return useFilter?norm(input.value):"";}
        function restoreHost(){if(wrap.isConnected&&menu.parentElement!==wrap)wrap.appendChild(menu);menu.classList.remove("is-portaled");menu.style.left="";menu.style.top="";menu.style.width="";menu.style.maxHeight="";}
        function positionMenu(){if(!open||menu.hidden||!input.isConnected)return;var r=input.getBoundingClientRect(),vw=Math.max(320,window.innerWidth||document.documentElement.clientWidth||0),vh=Math.max(320,window.innerHeight||document.documentElement.clientHeight||0),width=Math.min(Math.max(r.width,220),vw-24),left=Math.max(12,Math.min(r.left,vw-width-12)),below=vh-r.bottom-12,above=r.top-12,maxH=Math.min(300,Math.max(150,Math.max(below,above)));if(menu.parentElement!==document.body)document.body.appendChild(menu);menu.classList.add("is-portaled");menu.style.position="fixed";menu.style.width=Math.round(width)+"px";menu.style.left=Math.round(left)+"px";menu.style.maxHeight=Math.round(maxH)+"px";var useAbove=below<170&&above>below;requestAnimationFrame(function(){if(!open||!menu.isConnected)return;var h=Math.min(menu.scrollHeight||maxH,maxH),top=useAbove?Math.max(8,r.top-h-6):Math.min(vh-h-8,r.bottom+6);menu.style.top=Math.round(top)+"px";});}
        function bindPosition(){if(positionBound)return;positionBound=true;window.addEventListener("resize",positionMenu);document.addEventListener("scroll",positionMenu,true);}
        function unbindPosition(){if(!positionBound)return;positionBound=false;window.removeEventListener("resize",positionMenu);document.removeEventListener("scroll",positionMenu,true);}
        function closeNow(){open=false;menu.hidden=true;wrap.classList.remove("is-open");unbindPosition();restoreHost();}
        function paint(){
          var q=currentQuery(),active=norm(input.value),items=options.filter(function(value){return !q||norm(value).indexOf(q)>=0;});
          menu.innerHTML="";
          if(!items.length){var empty=document.createElement("div");empty.className="extuiClientComboEmpty";empty.textContent="Nenhuma opção encontrada.";menu.appendChild(empty);}else items.forEach(function(value){var opt=document.createElement("button");opt.type="button";opt.className="extuiClientComboOption"+(active&&active===norm(value)?" is-active":"");opt.setAttribute("aria-selected",active===norm(value)?"true":"false");opt.textContent=value;opt.addEventListener("mousedown",function(ev){ev.preventDefault();input.value=value;useFilter=false;closeNow();input.dispatchEvent(new Event("input",{bubbles:true}));input.dispatchEvent(new Event("change",{bubbles:true}));requestAnimationFrame(function(){try{input.focus();}catch(_){}});});menu.appendChild(opt);});
          menu.hidden=!open;wrap.classList.toggle("is-open",open);if(open){bindPosition();requestAnimationFrame(positionMenu);}else{unbindPosition();restoreHost();}
        }
        function openFull(){clearTimeout(closeTimer);open=true;useFilter=false;paint();}
        function closeSoon(){clearTimeout(closeTimer);closeTimer=setTimeout(closeNow,180);}
        input.setAttribute("role","combobox");input.setAttribute("aria-autocomplete","list");
        input.addEventListener("focus",openFull);input.addEventListener("click",openFull);
        input.addEventListener("input",function(){open=true;useFilter=true;paint();});
        input.addEventListener("keydown",function(ev){if(ev.key==="ArrowDown"){ev.preventDefault();open=true;useFilter=false;paint();var first=menu.querySelector(".extuiClientComboOption");if(first)first.focus();}else if(ev.key==="Escape")closeNow();});
        input.addEventListener("blur",closeSoon);
        return {wrap:wrap,menu:menu,paint:paint,close:closeNow};
      }

      function renderSimpleCollection(host,title,kind,list,inputType,placeholder){
        var block=document.createElement("section");block.className="extuiClientRecordManager";
        var head=document.createElement("div");head.className="extuiClientRecordManagerHead";head.innerHTML='<div><strong>'+escHtml(title)+'</strong><span>Adicione quantos registros precisar e dê um título para cada um.</span></div>';
        var add=document.createElement("button");add.type="button";add.className="extuiNavSecondaryBtn extuiClientRecordAdd";add.textContent="+ Adicionar";head.appendChild(add);block.appendChild(head);
        var rows=document.createElement("div");rows.className="extuiClientRecordRows";block.appendChild(rows);
        function paint(){
          rows.innerHTML="";
          list.forEach(function(rec,index){
            rec=rec&&typeof rec==="object"?rec:{};
            if(kind==="phone"){if(!rec.ddi)rec.ddi="+55";if(rec.ddi==="+55"){var recNormalized=extClientNormalizeBrazilLocal(rec.value,rec.phoneType);rec.phoneType=recNormalized.phoneType||extClientPhoneType(rec.phoneType)||"mobile";rec.value=extClientMaskLocalPhone(recNormalized.digits,rec.phoneType);}else if(rec.value)rec.value=extClientDigits(rec.value).slice(0,15);}
            var row=document.createElement("div");row.className="extuiClientRecordRow"+(rec._auto?" is-autofill":"")+(kind==="phone"?" extuiClientPhoneRow":"");row.dataset.recordKind=kind;
            var typeSelect=null;
            if(kind==="phone"){
              if(!rec.phoneType)rec.phoneType=extClientDetectBrazilPhoneType(rec.value,"");
              typeSelect=document.createElement("select");typeSelect.className="extuiClientPhoneType";typeSelect.setAttribute("aria-label","Tipo do telefone");typeSelect.appendChild(new Option("Celular","mobile"));typeSelect.appendChild(new Option("Fixo","landline"));typeSelect.value=extClientPhoneType(rec.phoneType)||"mobile";rec.phoneType=typeSelect.value;row.appendChild(typeSelect);
            }
            var phoneLabelOptions=["Pessoal","Trabalho","Comercial","Principal","WhatsApp","Recado","Outro"];
            var label=document.createElement("input");label.type="text";label.className="extuiClientRecordLabel";label.value=rec.label||"Pessoal";label.placeholder="Rótulo";label.setAttribute("aria-label","Rótulo do registro");
            label.addEventListener("input",function(){rec.label=label.value;rec._auto=false;markDirty(label);});
            row.appendChild(label);extClientAttachEditableCombo(label,phoneLabelOptions,"extuiClientComboWrap--phoneLabel");
            if(kind==="phone"){
              var ddiWrap=document.createElement("div");ddiWrap.className="extuiClientPhoneDdiWrap";
              var ddiDisplay=document.createElement("span");ddiDisplay.className="extuiClientPhoneDdiDisplay";ddiDisplay.textContent="🇧🇷 "+String(rec.ddi||"+55");
              var ddi=document.createElement("select");ddi.className="extuiClientPhoneDdi";ddi.setAttribute("aria-label","DDI");
              ddiWrap.appendChild(ddiDisplay);ddiWrap.appendChild(ddi);
              var dddWrap=document.createElement("div");dddWrap.className="extuiClientPhoneDddWrap";
              var ddd=document.createElement("input");ddd.type="text";ddd.className="extuiClientPhoneDdd";ddd.placeholder="DDD";ddd.inputMode="numeric";ddd.maxLength=rec.ddi==="+55"?2:4;ddd.value=String(rec.ddd||"").replace(/\D+/g,"").slice(0,ddd.maxLength);ddd.setAttribute("aria-label","DDD / código de área");ddd.title="Código de área quando existir no plano nacional; para países sem código de área, deixe vazio.";
              var dddDisplay=document.createElement("span");dddDisplay.className="extuiClientPhoneDddDisplay";
              var dddMenu=document.createElement("div");dddMenu.className="extuiClientPhoneDddMenu";dddMenu.hidden=true;
              dddWrap.appendChild(ddd);dddWrap.appendChild(dddDisplay);dddWrap.appendChild(dddMenu);
              var value=document.createElement("input");value.type="tel";value.className="extuiClientPhoneLocal";value.inputMode="numeric";value.value=rec.ddi==="+55"?extClientMaskLocalPhone(rec.value||"",rec.phoneType):extClientDigits(rec.value||"").slice(0,15);value.setAttribute("aria-label",title);
              var dddMenuOpen=false,dddCloseTimer=0,dddMenuFilterQuery="";
              function setDddDisplay(meta,digits){if(meta){var stateName=extClientStateName(meta.state||"");dddDisplay.textContent=meta.state||"BR";dddDisplay.title=(meta.code||digits||"")+": "+stateName;}else if((ddi.value||rec.ddi||"+55")==="+55"){dddDisplay.textContent="⌄";dddDisplay.title=digits?("DDD "+digits+" não encontrado na lista brasileira"):"Selecionar DDD";}else{dddDisplay.textContent="Área";dddDisplay.title="Código de área manual";}}
              function dddGroups(query){var q=String(query||"").trim().toLowerCase(),groups=[];EXTUI_CLIENT_BR_DDDS.forEach(function(groupMeta){var state=String(groupMeta&&groupMeta.state||"").toUpperCase(),stateName=extClientStateName(state),items=[];(Array.isArray(groupMeta&&groupMeta.values)?groupMeta.values:[]).forEach(function(rawCode){var code=String(rawCode==null?"":rawCode).replace(/\D+/g,"").slice(0,2);if(!code)return;var hay=(code+" "+state+" "+stateName).toLowerCase();if(q&&hay.indexOf(q)<0&&code.indexOf(q)!==0)return;items.push({ddd:code,code:code,state:state,stateName:stateName,city:stateName});});if(items.length){items.sort(function(a,b){return Number(a.ddd)-Number(b.ddd);});groups.push({state:state,stateName:stateName,items:items});}});return groups;}
              var dddPositionBound=false;
              function restoreDddMenuHost(){if(dddWrap.isConnected){if(dddMenu.parentElement!==dddWrap)dddWrap.appendChild(dddMenu);}else if(dddMenu.parentElement===document.body){dddMenu.remove();}dddMenu.classList.remove("is-portaled");dddMenu.style.left="";dddMenu.style.top="";dddMenu.style.bottom="";dddMenu.style.width="";dddMenu.style.maxHeight="";}
              function positionDddMenu(){if(!dddMenuOpen||dddMenu.hidden||!ddd.isConnected)return;var rect=ddd.getBoundingClientRect(),viewportW=Math.max(320,window.innerWidth||document.documentElement.clientWidth||0),availableAbove=Math.max(160,rect.top-18),maxHeight=Math.min(360,availableAbove),width=Math.min(Math.max(300,rect.width*2.35),viewportW-24),left=Math.max(12,Math.min(rect.left,viewportW-width-12));if(dddMenu.parentElement!==document.body)document.body.appendChild(dddMenu);dddMenu.classList.add("is-portaled");dddMenu.style.width=Math.round(width)+"px";dddMenu.style.left=Math.round(left)+"px";dddMenu.style.maxHeight=Math.round(maxHeight)+"px";dddMenu.style.bottom="auto";requestAnimationFrame(function(){if(!dddMenuOpen||!dddMenu.isConnected)return;var h=Math.min(dddMenu.scrollHeight||maxHeight,maxHeight),top=Math.max(8,rect.top-h-8);dddMenu.style.top=Math.round(top)+"px";});}
              function bindDddPosition(){if(dddPositionBound)return;dddPositionBound=true;window.addEventListener("resize",positionDddMenu);document.addEventListener("scroll",positionDddMenu,true);}
              function unbindDddPosition(){if(!dddPositionBound)return;dddPositionBound=false;window.removeEventListener("resize",positionDddMenu);document.removeEventListener("scroll",positionDddMenu,true);}
              function paintDddMenu(){var isBr=(ddi.value||rec.ddi||"+55")==="+55";var digits=String(ddd.value||"").replace(/\D+/g,"").slice(0,isBr?2:4);var meta=isBr?extClientFindDddMeta(digits):null;var query=isBr?String(dddMenuFilterQuery||"").replace(/\D+/g,"").slice(0,2):"";ddd.classList.toggle("is-invalid",!!(isBr&&digits&&!meta));dddWrap.classList.toggle("is-invalid-list",!!(isBr&&digits&&!meta));setDddDisplay(meta,digits);if(!isBr){dddMenuOpen=false;dddMenu.hidden=true;dddWrap.classList.remove("is-open");unbindDddPosition();restoreDddMenuHost();return;}var groups=dddGroups(query);dddMenu.innerHTML="";if(!groups.length){var empty=document.createElement("div");empty.className="extuiClientPhoneDddMenuEmpty";empty.textContent=query?"DDD não encontrado na lista brasileira.":"Nenhum DDD disponível.";dddMenu.appendChild(empty);}else{groups.forEach(function(group){var section=document.createElement("section");section.className="extuiClientPhoneDddGroup";var head=document.createElement("div");head.className="extuiClientPhoneDddGroupHead";head.textContent="BR "+group.state+" · "+group.stateName;section.appendChild(head);group.items.forEach(function(item){var opt=document.createElement("button");opt.type="button";opt.className="extuiClientPhoneDddOption"+(digits===item.ddd?" is-active":"");opt.innerHTML='<span class="extuiClientPhoneDddOptionCode">'+item.ddd+'</span><span class="extuiClientPhoneDddOptionLabel">'+item.stateName+'</span>';opt.addEventListener("mousedown",function(ev){ev.preventDefault();ddd.value=item.ddd;rec.ddd=item.ddd;rec._auto=false;dddMenuFilterQuery="";dddMenuOpen=false;paintDddMenu();markDirty(ddd);ddd.focus();});section.appendChild(opt);});dddMenu.appendChild(section);});}dddMenu.hidden=!dddMenuOpen;dddWrap.classList.toggle("is-open",dddMenuOpen);dddMenu.classList.toggle("is-invalid",!!(digits&&!meta));if(dddMenuOpen){bindDddPosition();positionDddMenu();}else{unbindDddPosition();restoreDddMenuHost();}}
              function applyDdiMode(){var isBr=(ddi.value||rec.ddi||"+55")==="+55";ddd.maxLength=isBr?2:4;ddd.placeholder=isBr?"DDD":"Área";dddWrap.classList.toggle("is-international",!isBr);if(isBr){ddd.value=String(ddd.value||"").replace(/\D+/g,"").slice(0,2);var normalized=extClientNormalizeBrazilLocal(value.value,rec.phoneType);rec.phoneType=normalized.phoneType||extClientPhoneType(rec.phoneType)||"mobile";if(typeSelect)typeSelect.value=rec.phoneType;value.value=extClientMaskLocalPhone(normalized.digits,rec.phoneType);value.placeholder=rec.phoneType==="landline"?"9999-9999":"9-9999-9999";}else{ddd.value=String(ddd.value||"").replace(/\D+/g,"").slice(0,4);ddd.classList.remove("is-invalid");value.value=extClientDigits(value.value).slice(0,15);value.placeholder="Número sem máscara";}rec.ddd=ddd.value;rec.value=value.value;paintDddMenu();}
              function openDddMenu(){clearTimeout(dddCloseTimer);dddMenuFilterQuery="";dddMenuOpen=true;paintDddMenu();}
              function closeDddMenuSoon(){clearTimeout(dddCloseTimer);dddCloseTimer=setTimeout(function(){dddMenuOpen=false;paintDddMenu();},160);}
              extClientPopulateCountrySelect(ddi,rec.ddi||"+55",function(){var selected=ddi.options[ddi.selectedIndex];rec.countryCode=selected&&selected.dataset.code||rec.countryCode||"";extClientUpdateCountryDisplay(ddiDisplay,ddi);applyDdiMode();},rec.countryCode||"");
              ddi.addEventListener("change",function(){rec.ddi=ddi.value||"+55";var selected=ddi.options[ddi.selectedIndex];rec.countryCode=selected&&selected.dataset.code||"";rec._auto=false;extClientUpdateCountryDisplay(ddiDisplay,ddi);applyDdiMode();markDirty(ddi);});
              ddd.addEventListener("focus",openDddMenu);ddd.addEventListener("click",openDddMenu);ddd.addEventListener("blur",closeDddMenuSoon);ddd.addEventListener("input",function(){var isBr=(ddi.value||rec.ddi||"+55")==="+55";ddd.value=String(ddd.value||"").replace(/\D+/g,"").slice(0,isBr?2:4);rec.ddd=ddd.value;rec._auto=false;dddMenuFilterQuery=ddd.value;dddMenuOpen=isBr;paintDddMenu();markDirty(ddd);});
              ddd.addEventListener("change",function(){var isBr=(ddi.value||rec.ddi||"+55")==="+55";ddd.value=String(ddd.value||"").replace(/\D+/g,"").slice(0,isBr?2:4);rec.ddd=ddd.value;rec._auto=false;dddMenuFilterQuery=ddd.value;paintDddMenu();markDirty(ddd);});
              ddd.addEventListener("keydown",function(ev){if(ev.key==="ArrowDown"||ev.key==="ArrowUp"){dddMenuFilterQuery="";dddMenuOpen=true;paintDddMenu();}});
              value.addEventListener("input",function(){var isBr=(ddi.value||rec.ddi||"+55")==="+55";if(isBr){var normalized=extClientNormalizeBrazilLocal(value.value,rec.phoneType);rec.phoneType=normalized.phoneType||extClientPhoneType(rec.phoneType)||"mobile";if(typeSelect)typeSelect.value=rec.phoneType;value.value=extClientMaskLocalPhone(normalized.digits,rec.phoneType);}else value.value=extClientDigits(value.value).slice(0,15);rec.value=value.value;rec._auto=false;markDirty(value);});
              if(typeSelect)typeSelect.addEventListener("change",function(){rec.phoneType=extClientPhoneType(typeSelect.value)||"mobile";rec._auto=false;if((ddi.value||rec.ddi||"+55")==="+55"){var normalized=extClientNormalizeBrazilLocal(value.value,rec.phoneType);value.value=extClientMaskLocalPhone(normalized.digits,rec.phoneType);rec.value=value.value;value.placeholder=rec.phoneType==="landline"?"9999-9999":"9-9999-9999";}markDirty(typeSelect);});
              applyDdiMode();
              row.appendChild(ddiWrap);row.appendChild(dddWrap);row.appendChild(value);
            }else{
              var value=document.createElement("input");value.type=inputType||"text";value.value=rec.value||"";value.placeholder=placeholder||"";value.setAttribute("aria-label",title);
              value.addEventListener("input",function(){rec.value=value.value;rec._auto=false;markDirty(value);});
              row.appendChild(value);
            }
            var remove=document.createElement("button");remove.type="button";remove.className="extuiClientRecordRemove";remove.textContent="×";remove.title="Remover registro";
            remove.addEventListener("click",function(){list.splice(index,1);paint();markDirty(block);});
            row.appendChild(remove);rows.appendChild(row);
          });
          if(!list.length){var empty=document.createElement("div");empty.className="extuiClientRecordEmpty";empty.textContent="Nenhum registro cadastrado.";rows.appendChild(empty);}
        }
        add.addEventListener("click",function(){list.push(kind==="phone"?{id:kind+"-"+Date.now().toString(36),label:"Pessoal",ddi:"+55",ddd:"",countryCode:"BR",phoneType:"mobile",value:""}:{id:kind+"-"+Date.now().toString(36),label:"Pessoal",value:""});paint();markDirty(block);var last=rows.querySelector('.extuiClientRecordRow:last-child input, .extuiClientRecordRow:last-child select');if(last)last.focus();});
        paint();host.appendChild(block);
      }

      function renderAddressCollection(host){
        var block=document.createElement("section");block.className="extuiClientRecordManager extuiClientAddressManager";
        var head=document.createElement("div");head.className="extuiClientRecordManagerHead";head.innerHTML='<div><strong>Endereços</strong><span>Use títulos como Residencial, Comercial ou Entrega.</span></div>';
        var add=document.createElement("button");add.type="button";add.className="extuiNavSecondaryBtn extuiClientRecordAdd";add.textContent="+ Adicionar";head.appendChild(add);block.appendChild(head);
        var rows=document.createElement("div");rows.className="extuiClientRecordRows";block.appendChild(rows);
        function paint(){
          rows.innerHTML="";
          addresses.forEach(function(rec,index){
            rec=rec&&typeof rec==="object"?rec:{};rec.postalCode=extClientMaskCep(rec.postalCode||"");
            var row=document.createElement("div");row.className="extuiClientAddressRow"+(rec._auto?" is-autofill":"");
            function fieldWrap(name,labelText){var group=document.createElement("label");group.className="extuiClientAddressField extuiClientAddressField--"+name;var cap=document.createElement("span");cap.textContent=labelText;group.appendChild(cap);return group;}
            var addressLabelOptions=["Residencial","Comercial","Entrega","Cobrança","Correspondência","Trabalho","Outro"];
            var titleGroup=fieldWrap("label","Rótulo"),titleInput=document.createElement("input");titleInput.type="text";titleInput.className="extuiClientAddressLabelInput";titleInput.value=rec.label||"Residencial";titleInput.placeholder="Ex.: Residencial";titleInput.addEventListener("input",function(){rec.label=titleInput.value;rec._auto=false;markDirty(titleInput);});titleGroup.appendChild(titleInput);row.appendChild(titleGroup);extClientAttachEditableCombo(titleInput,addressLabelOptions,"extuiClientComboWrap--addressLabel");
            var postalGroup=fieldWrap("postalCode","CEP"),postalInput=document.createElement("input");postalInput.type="text";postalInput.inputMode="numeric";postalInput.value=extClientMaskCep(rec.postalCode||"");postalInput.placeholder="00000-000";postalInput.addEventListener("input",function(){postalInput.value=extClientMaskCep(postalInput.value);rec.postalCode=postalInput.value;rec._auto=false;markDirty(postalInput);if(extClientDigits(postalInput.value).length===8){extClientLookupCep(postalInput.value).then(function(found){if(!found)return;rec.postalCode=found.postalCode||rec.postalCode;if(found.address&&!rec.value)valueInput.value=rec.value=found.address;if(found.complement&&!rec.complement){rec.complement=found.complement;complementInput.value=found.complement;}if(found.state){rec.state=found.state;stateSelect.value=found.state;extClientUpdateStateDisplay(stateDisplay,stateSelect);extClientPopulateCityList(cityList,found.state);}if(found.city){rec.city=found.city;cityInput.value=found.city;}markDirty(postalInput);}).catch(function(){});}});postalGroup.appendChild(postalInput);row.appendChild(postalGroup);
            var valueGroup=fieldWrap("value","LOGRADOURO"),valueInput=document.createElement("input");valueInput.type="text";valueInput.value=rec.value||"";valueInput.placeholder="Rua, Avenida, Praça, Alameda, Travessa, Estrada, ...";valueInput.addEventListener("input",function(){rec.value=valueInput.value;rec._auto=false;markDirty(valueInput);});valueGroup.appendChild(valueInput);row.appendChild(valueGroup);
            var numberGroup=fieldWrap("number","Número"),numberInput=document.createElement("input");numberInput.type="text";numberInput.inputMode="numeric";numberInput.maxLength=4;numberInput.value=String(rec.number||"").replace(/\D+/g,"").slice(0,4);numberInput.placeholder="0000";numberInput.addEventListener("input",function(){numberInput.value=String(numberInput.value||"").replace(/\D+/g,"").slice(0,4);rec.number=numberInput.value;rec._auto=false;markDirty(numberInput);});numberGroup.appendChild(numberInput);row.appendChild(numberGroup);
            var stateGroup=fieldWrap("state","Estado"),statePicker=document.createElement("div");statePicker.className="extuiClientAddressStatePicker";var stateDisplay=document.createElement("span");stateDisplay.className="extuiClientAddressStateDisplay";var stateSelect=document.createElement("select");stateSelect.className="extuiClientAddressState";extClientFillStateSelect(stateSelect,rec.state||"");extClientUpdateStateDisplay(stateDisplay,stateSelect);stateSelect.addEventListener("change",function(){rec.state=stateSelect.value;rec._auto=false;extClientUpdateStateDisplay(stateDisplay,stateSelect);extClientPopulateCityList(cityList,rec.state);markDirty(stateSelect);});statePicker.appendChild(stateDisplay);statePicker.appendChild(stateSelect);stateGroup.appendChild(statePicker);row.appendChild(stateGroup);
            var cityGroup=fieldWrap("city","Cidade"),cityInput=document.createElement("input");cityInput.type="text";cityInput.value=rec.city||"";cityInput.placeholder="Selecione ou digite";var cityList=document.createElement("datalist");cityList.id="extuiClientCityList-"+index+"-"+Date.now().toString(36);cityInput.setAttribute("list",cityList.id);extClientPopulateCityList(cityList,rec.state||"");cityInput.addEventListener("input",function(){rec.city=cityInput.value;rec._auto=false;markDirty(cityInput);});cityGroup.appendChild(cityInput);cityGroup.appendChild(cityList);row.appendChild(cityGroup);
            var complementGroup=fieldWrap("complement","Complemento"),complementInput=document.createElement("input");complementInput.type="text";complementInput.maxLength=80;complementInput.value=String(rec.complement||"").slice(0,80);complementInput.placeholder="Apto, bloco, sala...";complementInput.addEventListener("input",function(){complementInput.value=String(complementInput.value||"").slice(0,80);rec.complement=complementInput.value;rec._auto=false;markDirty(complementInput);});complementGroup.appendChild(complementInput);row.appendChild(complementGroup);
            var referenceGroup=fieldWrap("reference","Referência"),referenceInput=document.createElement("input");referenceInput.type="text";referenceInput.value=rec.reference||"";referenceInput.placeholder="Ponto de referência";referenceInput.addEventListener("input",function(){rec.reference=referenceInput.value;rec._auto=false;markDirty(referenceInput);});referenceGroup.appendChild(referenceInput);row.appendChild(referenceGroup);
            var remove=document.createElement("button");remove.type="button";remove.className="extuiClientRecordRemove";remove.textContent="×";remove.title="Remover endereço";remove.addEventListener("click",function(){addresses.splice(index,1);paint();markDirty(block);});row.appendChild(remove);rows.appendChild(row);
          });
          if(!addresses.length){var empty=document.createElement("div");empty.className="extuiClientRecordEmpty";empty.textContent="Nenhum endereço cadastrado.";rows.appendChild(empty);}
        }
        add.addEventListener("click",function(){addresses.push({id:"address-"+Date.now().toString(36),label:"Residencial",value:"",number:"",complement:"",reference:"",city:"",state:"",postalCode:""});paint();markDirty(block);});
        paint();host.appendChild(block);
      }

      section(panelMap.contacts,"Contatos","Telefones e e-mails podem ter títulos como Pessoal ou Comercial.");
      renderSimpleCollection(panelMap.contacts,"Telefones","phone",phones,"tel","Número de telefone");
      renderSimpleCollection(panelMap.contacts,"E-mails","email",emails,"email","cliente@exemplo.com");
      section(panelMap.addresses,"Endereços","Cadastre diferentes localizações do cliente sem ocupar a tela principal.");
      renderAddressCollection(panelMap.addresses);

      function cleanSimple(list){return list.map(function(x){var base={id:String(x.id||""),label:text(x.label)||"Pessoal",value:text(x.value)};if(x&&typeof x==="object"&&(x.ddi||x.ddd)){base.ddi=String(x.ddi||"+55");base.ddd=String(x.ddd||"").replace(/\D+/g,"").slice(0,base.ddi==="+55"?2:4);base.countryCode=text(x.countryCode)||(base.ddi==="+55"?"BR":"");base.phoneType=extClientPhoneType(x.phoneType)||(base.ddi==="+55"?extClientDetectBrazilPhoneType(x.value,""):"");if(base.ddi==="+55"){var normalized=extClientNormalizeBrazilLocal(base.value,base.phoneType);base.phoneType=normalized.phoneType||base.phoneType;base.value=extClientMaskLocalPhone(normalized.digits,base.phoneType);}}return base;}).filter(function(x){return x.ddi||x.ddd||x.value;});}
      function cleanAddresses(){return addresses.map(function(x){return{id:String(x.id||""),label:text(x.label)||"Residencial",value:text(x.value),number:String(x&&x.number||"").replace(/\D+/g,"").slice(0,4),complement:text(x&&x.complement).slice(0,80),reference:text(x&&x.reference),city:text(x.city),state:text(x.state).toUpperCase(),postalCode:extClientMaskCep(text(x.postalCode))};}).filter(function(x){return x.value||x.number||x.complement||x.reference||x.city||x.state||x.postalCode;});}
      function snapshot(){var out={};Object.keys(fields).forEach(function(k){out[k]=fields[k].value.trim?fields[k].value.trim():fields[k].value;});out.phones=cleanSimple(phones);out.emails=cleanSimple(emails);out.addresses=cleanAddresses();return out;}
      var persisted={localAlias:text(storedMeta.localAlias),gender:text(storedMeta.gender),birthDate:text(storedMeta.birthDate),language:text(storedMeta.language),company:text(storedMeta.company),leadSource:text(storedMeta.leadSource),entryDate:text(storedMeta.entryDate),exitDate:text(storedMeta.exitDate),phones:normalizeSimple(storedMeta.phones,"phone").map(function(x){return{id:x.id,label:x.label,value:x.value,ddi:x.ddi,ddd:x.ddd,countryCode:x.countryCode,phoneType:x.phoneType};}),emails:normalizeSimple(storedMeta.emails,"email").map(function(x){return{id:x.id,label:x.label,value:x.value};}),addresses:normalizeAddresses(storedMeta.addresses).map(function(x){return{id:x.id,label:x.label,value:x.value,number:x.number,complement:x.complement,reference:x.reference,city:x.city,state:x.state,postalCode:extClientMaskCep(x.postalCode)};})};
      if(!persisted.emails.length&&storedMeta.email)persisted.emails=[{id:"auto-email",label:"Pessoal",value:text(storedMeta.email)}];
      if(!persisted.addresses.length&&(storedMeta.address||storedMeta.city||storedMeta.state||storedMeta.postalCode||storedMeta.complement||storedMeta.reference))persisted.addresses=[{id:"auto-address",label:"Residencial",value:text(storedMeta.address),number:text(storedMeta.number),complement:text(storedMeta.complement),reference:text(storedMeta.reference),city:text(storedMeta.city),state:text(storedMeta.state),postalCode:extClientMaskCep(text(storedMeta.postalCode))}];
      if(extPhoneAutoRepair){var repairedPhone=phones[0]||{};storedMeta=Object.assign({},storedMeta,{phones:cleanSimple(phones),phone:(extClientBuildPhoneRecord(repairedPhone).full)||ctx.phone||""});persisted.phones=normalizeSimple(storedMeta.phones,"phone").map(function(x){return{id:x.id,label:x.label,value:x.value,ddi:x.ddi,ddd:x.ddd,countryCode:x.countryCode,phoneType:x.phoneType};});}
      var shouldBootstrapSave=(!draftMeta&&!Object.keys(storedMeta||{}).length)||extPhoneAutoRepair;
      var dirty=shouldBootstrapSave?false:JSON.stringify(snapshot())!==JSON.stringify(persisted);
      content.__extClientCaptureDraft=function(){try{if(ctx&&ctx.chatId)extClientWriteDraft(ctx.chatId,snapshot());}catch(_){}};

      var draftWriteTimer=0;
      var undoBtn=status.querySelector(".extuiClientUndoBtn");
      function paintDirty(){form.classList.toggle("is-dirty",dirty);status.hidden=!dirty;save.disabled=!dirty;if(undoBtn)undoBtn.disabled=!dirty;}
      function persistDraftSoon(){clearTimeout(draftWriteTimer);draftWriteTimer=setTimeout(function(){try{if(ctx&&ctx.chatId)extClientWriteDraft(ctx.chatId,snapshot());}catch(_){}} ,160);}
      function markDirty(target){dirty=true;if(target&&target.classList)target.classList.add("is-dirty");paintDirty();persistDraftSoon();}
      form.addEventListener("input",function(ev){if(ev.target&&ev.target.matches('input,select,textarea'))markDirty(ev.target);});
      form.addEventListener("change",function(ev){if(ev.target&&ev.target.matches('input,select,textarea'))markDirty(ev.target);});
      paintDirty();

      async function persistClientCadastro(options){
        options=options||{};
        if(!options.skipDirtyCheck&&!dirty)return false;
        save.disabled=true;if(undoBtn)undoBtn.disabled=true;
        try{
          var patch=snapshot(),firstEmail=patch.emails[0]||{},firstAddress=patch.addresses[0]||{},firstPhone=patch.phones[0]||{};
          patch.email=firstEmail.value||"";patch.address=[firstAddress.value||"",firstAddress.number||"",firstAddress.complement||""].filter(Boolean).join(", ");patch.number=firstAddress.number||"";patch.complement=firstAddress.complement||"";patch.reference=firstAddress.reference||"";patch.city=firstAddress.city||"";patch.state=firstAddress.state||"";patch.postalCode=firstAddress.postalCode||"";patch.whatsappName=ctx.actualName||"";patch.phone=(extClientBuildPhoneRecord(firstPhone).full)||ctx.phone||"";
          await service.set(ctx.chatId,patch);
          if(window.ExtensionCustomerStore&&typeof window.ExtensionCustomerStore.upsertFromMetadata==="function")await window.ExtensionCustomerStore.upsertFromMetadata(ctx.chatId,patch);
          await Promise.resolve(extClientClearDraft(ctx.chatId));
          if(window.__extLocalAliasOverlay&&typeof window.__extLocalAliasOverlay.refresh==="function")window.__extLocalAliasOverlay.refresh();
          if(!options.silent)toast("Cadastro do cliente salvo.");
          await extRenderQuickClientContent(content);
          return true;
        }catch(err){if(options.silent){dirty=true;paintDirty();}toast(err&&err.message||"Falha ao salvar cadastro.",true);save.disabled=false;if(undoBtn)undoBtn.disabled=!dirty;return false;}
      }

      exportBtn.addEventListener("click",function(){var snap=Object.assign({},storedMeta,snapshot());extQrDownloadXls(ctx,snap);});
      if(undoBtn)undoBtn.addEventListener("click",async function(){if(!dirty)return;var ok=window.extConfirm?await window.extConfirm("Descartar todas as alterações pendentes deste cadastro?",{danger:true,okLabel:"Desfazer alterações",cancelLabel:"Continuar editando"}):window.confirm("Descartar todas as alterações pendentes deste cadastro?");if(!ok)return;try{await Promise.resolve(extClientClearDraft(ctx.chatId));await extRenderQuickClientContent(content);}catch(err){toast(err&&err.message||"Não foi possível desfazer as alterações.",true);}});
      form.addEventListener("submit",async function(ev){
        ev.preventDefault();
        await persistClientCadastro();
      });

      wrap.appendChild(form);content.appendChild(wrap);
      if(shouldBootstrapSave){Promise.resolve().then(function(){return persistClientCadastro({silent:true,skipDirtyCheck:true});}).catch(function(){});}

    }
    return Object.freeze({render:extRenderQuickClientContent});
  };
})();
