;(function () {
  "use strict";
  if (window.__extCreatePanelBuilderCatalog) return;
  window.__extCreatePanelBuilderCatalog = function () {
    var byKey = Object.create(null);
    var byCommand = Object.create(null);
    var ordered = [];
    function register(definition) {
      definition = definition || {};
      var key = String(definition.key || "");
      var commandId = String(definition.commandId || "");
      if (!key || !commandId || typeof definition.builder !== "function" || typeof definition.handler !== "function") throw new TypeError("Definição de painel inválida.");
      if (byKey[key] || byCommand[commandId]) throw new Error("Definição de painel duplicada: " + key);
      var entry = Object.freeze({
        key: key, commandId: commandId, panelId: definition.panelId || null, category: definition.category || "geral",
        accent: definition.accent || "", icon: definition.icon || "", title: definition.title || key, desc: definition.desc || "",
        builder: definition.builder, handler: definition.handler
      });
      byKey[key] = entry;
      byCommand[commandId] = entry;
      ordered.push(entry);
      return entry;
    }
    function get(key) { return byKey[String(key || "")] || null; }
    function getByCommand(commandId) { return byCommand[String(commandId || "")] || null; }
    function list() { return ordered.slice(); }
    function nav(key) { var entry = get(key); if (!entry) throw new Error("Painel não registrado: " + key); return entry; }
    return Object.freeze({ register: register, get: get, getByCommand: getByCommand, list: list, nav: nav });
  };
})();
