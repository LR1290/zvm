;(function () {
  "use strict";
  if (window.__extCreatePanelSystemDomainCore) return;
  window.__extCreatePanelSystemDomainCore = function (options) {
    options = options || {};
    var get = options.get;
    var set = options.set;
    var bridgeCall = options.bridgeCall;
    var onKeyChange = options.onKeyChange;
    var buildPanelShell = options.buildPanelShell;
    var panelBody = options.panelBody;
    var navIcons = options.navIcons;
    var panelBrand = options.panelBrand;
    var emptyState = options.emptyState;
    var escHtml = options.escHtml;
    var pushSubview = options.pushSubview;
    var iconChip = options.iconChip;
    var openShellHtml = options.openShellHtml;
    var toast = options.toast;
    var panelOnKeyChange = options.panelOnKeyChange;
    var webhookEventDefs = options.webhookEventDefs || [];
    var notificationFeedKey = "EXTUI:notificationCenterFeed";
    var notificationReadKey = "EXTUI:notificationCenterRead";
    var webhookKey = "EXTUI:extappWebhookStore";
    var notificationRefreshBound = false;
    var notificationWaitingForBus = false;
    var urgentShown = false;
    function normalizeNotification(raw,index) {
      raw=raw&&typeof raw==="object"?raw:{};var when=raw.publishedAt||raw.createdAt||raw.date||new Date().toISOString();
      return {id:String(raw.id||raw.notificationId||("remote-"+index+"-"+when)),category:(raw.category==="updates"||raw.type==="update"||raw.type==="version")?"updates":"announcements",title:String(raw.title||raw.subject||"Comunicado"),body:String(raw.body||raw.message||raw.text||""),publishedAt:when,priority:String(raw.priority||"normal").toLowerCase()};
    }
    function notificationReadMap(raw){if(!raw)return{};if(typeof raw==="string"){try{return JSON.parse(raw)||{};}catch(_){return{};}}return typeof raw==="object"?raw:{};}
    async function loadNotifications(refresh) {
      var cached=[],read={};
      try{var pair=await Promise.all([get(notificationFeedKey),get(notificationReadKey)]);var c=pair[0];if(typeof c==="string")try{c=JSON.parse(c);}catch(_){};cached=Array.isArray(c)?c:[];read=notificationReadMap(pair[1]);}catch(_){}
      if(refresh!==false){try{var remote=await bridgeCall("notificationFeed");var list=Array.isArray(remote)?remote:(remote&&Array.isArray(remote.notifications)?remote.notifications:null);if(list){cached=list.map(normalizeNotification);await set(notificationFeedKey,cached);}}catch(_){} }
      cached=cached.map(normalizeNotification).sort(function(a,b){return new Date(b.publishedAt)-new Date(a.publishedAt);});return {items:cached,read:read};
    }
    async function markNotificationRead(id){var raw=await get(notificationReadKey),read=notificationReadMap(raw);read[id]=Date.now();await set(notificationReadKey,read);refreshNotificationBadge();}
    function formatNotificationDate(v){var d=new Date(v);if(isNaN(d.getTime()))return String(v||"");try{return d.toLocaleString("pt-BR",{dateStyle:"short",timeStyle:"short"});}catch(_){return d.toLocaleString("pt-BR");}}
    async function refreshNotificationBadge(){var data=await loadNotifications(false),n=data.items.filter(function(x){return !data.read[x.id];}).length,btn=document.querySelector('[data-extui-nav-key="notificacoes"]');if(!btn)return;var chip=btn.querySelector(".extuiNavIconChip"),badge=chip&&chip.querySelector(".extuiNotificationDot");if(!badge&&chip){badge=document.createElement("span");badge.className="extuiNotificationDot";chip.appendChild(badge);}if(badge){badge.hidden=n===0;badge.setAttribute("aria-label",n+" notificação(ões) não lida(s)");}}
    function bindNotificationRefresh(){
      if(notificationRefreshBound)return true;
      if(!window.__extEventBus){
        if(!notificationWaitingForBus){
          notificationWaitingForBus=true;
          window.addEventListener("ext:eventbus-ready",function(){notificationWaitingForBus=false;bindNotificationRefresh();},{once:true});
        }
        return false;
      }
      notificationRefreshBound=true;
      window.__extEventBus.on("RemoteNotificationTick",function(){loadNotifications(true).then(function(){return refreshNotificationBadge();}).catch(function(){});});
      onKeyChange(notificationFeedKey,function(){refreshNotificationBadge().catch(function(){});});
      onKeyChange(notificationReadKey,function(){refreshNotificationBadge().catch(function(){});});
      return true;
    }
    function notificationCard(item,isRead,onOpen){var card=document.createElement("button");card.type="button";card.className="extNotificationCard"+(isRead?"":" extuiUnread");var preview=item.body.replace(/\s+/g," ").trim();card.innerHTML='<div class="extuiNotificationCardHead"><strong>'+escHtml(item.title)+'</strong><time>'+escHtml(formatNotificationDate(item.publishedAt))+'</time></div><div class="extuiNotificationPreview">'+escHtml(preview)+'</div>';card.addEventListener("click",onOpen);return card;}
    async function buildNotificationsPanel(){
      var root=buildPanelShell({id:"extuiNavNotificationsPanel",title:"Notificações",accent:"#22c55e",icon:navIcons.notificacoes,eyebrow:"Central",hint:"Comunicados e atualizações da extensão.",size:"md",tutorialKey:"notificacoes"});
      var body=panelBody(root);body.innerHTML='<div class="extuiNotificationTabs" role="tablist" aria-label="Categorias de notificações"><button id="extuiNotificationsTabAnnouncements" role="tab" aria-controls="extuiNotificationsList" aria-selected="true" tabindex="0" data-tab="announcements" class="extuiActive">Comunicado</button><button id="extuiNotificationsTabUpdates" role="tab" aria-controls="extuiNotificationsList" aria-selected="false" tabindex="-1" data-tab="updates">Atualizações</button><button id="extuiNotificationsTabUnread" role="tab" aria-controls="extuiNotificationsList" aria-selected="false" tabindex="-1" data-tab="unread">Não lidas</button></div><div id="extuiNotificationsList" class="extuiNotificationList" role="tabpanel" aria-labelledby="extuiNotificationsTabAnnouncements"><div class="extuiNotificationLoading">Carregando notificações...</div></div>';
      var tab="announcements",tabs=body.querySelector(".extuiNotificationTabs"),list=body.querySelector(".extuiNotificationList");
      function selectTab(btn){tab=btn.dataset.tab;Array.from(tabs.querySelectorAll('[role="tab"]')).forEach(function(b){var active=b===btn;b.classList.toggle("extuiActive",active);b.setAttribute("aria-selected",String(active));b.tabIndex=active?0:-1;});list.setAttribute("aria-labelledby",btn.id);}
      async function render(refresh){var data=await loadNotifications(refresh);list.innerHTML="";var filtered=data.items.filter(function(x){return tab==="unread"?!data.read[x.id]:x.category===tab;});if(!filtered.length){list.appendChild(emptyState("#22c55e",navIcons.notificacoes,"Nada por aqui",tab==="unread"?"Você já leu todas as notificações.":"Nenhuma notificação disponível nesta categoria."));return;}filtered.forEach(function(item){list.appendChild(notificationCard(item,!!data.read[item.id],function(){markNotificationRead(item.id).catch(function(){});pushSubview(root,item.title,function(view){view.innerHTML='<div class="extuiNotificationDetail"><time>'+escHtml(formatNotificationDate(item.publishedAt))+'</time><div class="extuiNotificationBody">'+escHtml(item.body).replace(/\n/g,"<br>")+'</div></div>';});}));});refreshNotificationBadge();}
      tabs.querySelectorAll('[role="tab"]').forEach(function(btn){btn.addEventListener("click",function(){selectTab(btn);render(false);});});
      tabs.addEventListener("keydown",function(ev){var buttons=Array.from(tabs.querySelectorAll('[role="tab"]')),index=buttons.indexOf(document.activeElement);if(index<0)return;if(ev.key==="ArrowRight")index=(index+1)%buttons.length;else if(ev.key==="ArrowLeft")index=(index-1+buttons.length)%buttons.length;else if(ev.key==="Home")index=0;else if(ev.key==="End")index=buttons.length-1;else return;ev.preventDefault();selectTab(buttons[index]);buttons[index].focus();render(false);});
      await render(false);loadNotifications(true).then(function(){return render(false);}).catch(function(){});return root;
    }
    async function maybeShowUrgentNotification(){if(urgentShown)return;var data=await loadNotifications(false),item=data.items.find(function(x){return !data.read[x.id]&&(x.priority==="urgent"||x.priority==="high");});if(!item)return;var side=document.querySelector("#side");if(!side)return;urgentShown=true;var r=side.getBoundingClientRect(),overlay=document.createElement("section");overlay.className="extuiUrgentNotification";overlay.style.left=r.left+"px";overlay.style.top=r.top+"px";overlay.style.width=r.width+"px";overlay.style.height=r.height+"px";overlay.innerHTML='<button type="button" class="extuiUrgentNotificationClose" aria-label="Fechar">×</button><span class="extuiUrgentEyebrow">COMUNICADO IMPORTANTE</span><h2>'+escHtml(item.title)+'</h2><time>'+escHtml(formatNotificationDate(item.publishedAt))+'</time><div class="extuiUrgentBody">'+escHtml(item.body).replace(/\n/g,"<br>")+'</div>';overlay.querySelector("button").addEventListener("click",function(){markNotificationRead(item.id).catch(function(){});overlay.remove();});document.body.appendChild(overlay);}
    async function loadWebhookList(){var raw=await get(webhookKey);var state=options.parsePersisted(raw);return(state&&state.webhookList)||[];}
    async function buildWebhooksPanel(){
      var root=buildPanelShell({id:"extuiNavWebhooksPanel",title:"Webhooks",accent:panelBrand.webhooks.accent,icon:panelBrand.webhooks.icon,eyebrow:"Integrações",hint:"Consulte o estado dos Webhooks configurados.",size:"md"});
      var body=root.querySelector(".extuiNavPanelBody");
      async function renderRows(){body.innerHTML="";var list=[];try{list=await loadWebhookList();}catch(_){}var configured=new Map();list.forEach(function(cfg){if(cfg&&cfg.id)configured.set(String(cfg.id),cfg);});webhookEventDefs.forEach(function(def){var cfg=configured.get(def.id)||{};var row=document.createElement("div");row.className="extuiDockedPanelRow extSystemMenuRow";var left=document.createElement("div");left.className="extuiSystemMenuIcon";left.innerHTML=iconChip(def.accent,def.icon,true);var text=document.createElement("div");text.className="extuiSystemMenuText";var title=document.createElement("div");title.className="title";title.textContent=def.title;var meta=document.createElement("div");meta.className="desc";meta.textContent=cfg.active===true&&cfg.url?"Ativo · endereço configurado":"Inativo ou sem endereço configurado";text.appendChild(title);text.appendChild(meta);row.appendChild(left);row.appendChild(text);body.appendChild(row);});var manage=document.createElement("button");manage.type="button";manage.className="extuiNavPrimaryBtn";manage.textContent="Gerenciar avisos no Painel de Controle";manage.addEventListener("click",function(){openShellHtml("integrations",{reuseExisting:true,focus:"webhooks"}).catch(function(err){toast(err&&err.message||"Não foi possível abrir o Painel de Controle.",true);});});body.appendChild(manage);var note=document.createElement("div");note.className="extuiFieldHelper";note.textContent="Por segurança, tokens e permissões de rede nunca são solicitados dentro do contexto do WhatsApp Web.";body.appendChild(note);}
      renderRows();panelOnKeyChange(root,webhookKey,function(){if(root.classList.contains("extuiOpen"))renderRows();});return root;
    }
    return Object.freeze({buildNotificationsPanel:buildNotificationsPanel,buildWebhooksPanel:buildWebhooksPanel,loadNotifications:loadNotifications,refreshNotificationBadge:refreshNotificationBadge,bindNotificationRefresh:bindNotificationRefresh,maybeShowUrgentNotification:maybeShowUrgentNotification});
  };
})();
