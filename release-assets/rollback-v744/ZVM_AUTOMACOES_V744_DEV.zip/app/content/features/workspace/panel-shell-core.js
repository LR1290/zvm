;
(function () {
  "use strict";
  if (window.__extCreatePanelShellCore) return;
  window.__extCreatePanelShellCore = function (config) {
    config = config || {};
    var navIcons = config.navIcons || {};
    var resizeDirs = Array.isArray(config.resizeDirs) ? config.resizeDirs : [];
    var resetBuilderLifecycle = typeof config.resetBuilderLifecycle === "function" ? config.resetBuilderLifecycle : function () {};
    var setVisibility = typeof config.setVisibility === "function" ? config.setVisibility : function () {};
    var registerRoot = typeof config.registerRoot === "function" ? config.registerRoot : function () {};
    var attachResize = typeof config.attachResize === "function" ? config.attachResize : function () {};
    var attachDrag = typeof config.attachDrag === "function" ? config.attachDrag : function () {};
    var installScrollContract = typeof config.installScrollContract === "function" ? config.installScrollContract : function () {};
    var centerWorkspace = typeof config.centerWorkspace === "function" ? config.centerWorkspace : function () {};
    var decorate = typeof config.decorate === "function" ? config.decorate : function () {};
    var panelBody = typeof config.panelBody === "function" ? config.panelBody : function (root) { return root && root.querySelector ? root.querySelector(".extuiPanelBody") : null; };
    var syncNav = typeof config.syncNav === "function" ? config.syncNav : function () {};
    var getWorkspace = typeof config.getWorkspace === "function" ? config.getWorkspace : function () { return null; };
    var openTools = typeof config.openTools === "function" ? config.openTools : function () { return Promise.reject(new Error("Ferramentas indisponíveis.")); };
    var bridgeCall = typeof config.bridgeCall === "function" ? config.bridgeCall : function () { return Promise.reject(new Error("Bridge indisponível.")); };
    var alertFn = typeof config.alertFn === "function" ? config.alertFn : function () { return Promise.resolve(); };
    var getNavTrigger = typeof config.getNavTrigger === "function" ? config.getNavTrigger : function () { return null; };
    var panelState = config.panelState || null;
    var shellStates=new WeakMap();
    function shellState(root){var s=shellStates.get(root);if(!s){s={subviews:[],baseTitle:"",baseEyebrow:"",baseHint:"",sizeKey:"md",panelMeta:null};shellStates.set(root,s);}return s;}
    function hasSubviews(root){return !!(root&&shellState(root).subviews.length);}
    function peekSubview(root){var list=root?shellState(root).subviews:[];return list.length?list[list.length-1]:null;}
    function sizeKeyFor(root){return root?shellState(root).sizeKey:"md";}

    function trustedTutorialUrl(raw) {
      try {
        var parsed = new URL(String(raw || ""));
        if (parsed.protocol !== "https:") return null;
        var host = parsed.hostname.toLowerCase();
        if (["youtube.com","www.youtube.com","youtu.be","www.youtube-nocookie.com"].indexOf(host) < 0) return null;
        return parsed.toString();
      } catch (_) { return null; }
    }

    function applySubviewHeader(root, state) {
      state = state || {};
      var titleEl = root.querySelector("[data-extui-panel-title]");
      var eyebrowEl = root.querySelector("[data-extui-panel-eyebrow]");
      var hintEl = root.querySelector("[data-extui-panel-hint]");
      var base=shellState(root);
      if (titleEl) titleEl.textContent = state.title != null ? state.title : base.baseTitle;
      var eyebrow = state.eyebrow != null ? state.eyebrow : base.baseEyebrow;
      if (eyebrowEl) { eyebrowEl.textContent = eyebrow || ""; eyebrowEl.hidden = !eyebrow; }
      var hint = state.hint != null ? state.hint : base.baseHint;
      if (hintEl) { hintEl.textContent = hint || ""; hintEl.hidden = !hint; }
    }

    function pushSubview(root, title, renderFn, meta) {
      meta = meta || {};
      var wrap = document.createElement("div");
      wrap.className = "extuiNavPanelSubview";
      root.querySelector(".extuiNavPanelBody").before(wrap);
      root.querySelectorAll(":scope > .extuiNavPanelBody, :scope > .extuiNavPanelSubview").forEach(function (el) { el.hidden = true; });
      wrap.hidden = false;
      renderFn(wrap);
      wrap.classList.add("extuiPanelSubview");
      decorate(root);
      var base=shellState(root);
      var state = { title: title, el: wrap, eyebrow: Object.prototype.hasOwnProperty.call(meta,"eyebrow") ? meta.eyebrow : "", hint: Object.prototype.hasOwnProperty.call(meta,"hint") ? meta.hint : base.baseHint };
      base.subviews.push(state);
      root.querySelector("[data-back]").hidden = false;
      applySubviewHeader(root, state);
      var body = panelBody(root);
      if (body) body.scrollTop = 0;
      try { window.dispatchEvent(new CustomEvent("ext:panel-state", { detail: { panelId: root.id || null, open: true, subview: title } })); } catch (_) {}
    }

    function popSubview(root) {
      var base=shellState(root);
      var top = base.subviews.pop();
      if (top) top.el.remove();
      if (base.subviews.length) {
        var next = base.subviews[base.subviews.length - 1];
        root.querySelectorAll(":scope > .extuiNavPanelSubview").forEach(function (el) { el.hidden = el !== next.el; });
        applySubviewHeader(root, next);
      } else {
        root.querySelector(".extuiNavPanelBody").hidden = false;
        root.querySelector("[data-back]").hidden = !(panelState && panelState.backEnabled(root));
        applySubviewHeader(root, { title: base.baseTitle, eyebrow: base.baseEyebrow, hint: base.baseHint });
      }
      try { window.dispatchEvent(new CustomEvent("ext:panel-state", { detail: { panelId: root.id || null, open: true, subview: base.subviews.length ? base.subviews[base.subviews.length-1].title : null } })); } catch (_) {}
    }

    function focusOnOpen(root) {
      if (!root) return;
      var preferred = root.querySelector('input[type="search"], input[placeholder*="Buscar"], input[placeholder*="buscar"], [data-extui-autofocus]');
      var closeBtn = root.querySelector(".extuiNavPanelCloseBtn");
      var target = preferred || closeBtn;
      if (target && typeof target.focus === "function") {
        try { target.focus({ preventScroll: true }); } catch (_) { target.focus(); }
      }
    }

    function restoreFocusAfterClose(panelId) {
      var trigger = getNavTrigger(panelId);
      if (trigger && document.body.contains(trigger) && typeof trigger.focus === "function") trigger.focus();
    }

    function build(configPanel) {
      configPanel = configPanel || {};
      var id = configPanel.id, title = configPanel.title || "", iconInner = configPanel.icon || "", eyebrow = configPanel.eyebrow || "", hint = configPanel.hint || "", footer = configPanel.footer === true, sizeKey = configPanel.size || "md";
      var existing = document.getElementById(id);
      var root = existing || document.createElement("section");
      if (existing) resetBuilderLifecycle(root);
      root.id = id;
      root.className = "extuiNavPanel extuiPanelShell";
      root.setAttribute("role", "dialog");
      root.setAttribute("aria-modal", "false");
      root.setAttribute("aria-label", title);
      setVisibility(root, false);
      root.style.setProperty("--extuiPanelAccent", "var(--extui-primary,#00c85a)");
      root.replaceChildren();

      var header = document.createElement("header");
      header.className = "extuiNavPanelHeader extuiPanelHeader";
      header.setAttribute("data-extui-drag-handle", "");
      var lead = document.createElement("div");
      lead.className = "extuiPanelHeaderLead";
      var back = document.createElement("button");
      back.type = "button";
      back.className = "extuiPanelIconButton extuiPanelBackButton extuiNavPanelBackBtn";
      back.setAttribute("data-back", "");
      back.setAttribute("aria-label", "Voltar");
      back.hidden = true;
      back.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>';
      lead.appendChild(back);
      if (iconInner) {
        var glyph = document.createElement("span");
        glyph.className = "extuiPanelHeaderGlyph";
        glyph.setAttribute("aria-hidden", "true");
        glyph.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + iconInner + '</svg>';
        lead.appendChild(glyph);
      }
      var copy = document.createElement("div");
      copy.className = "extuiPanelHeaderCopy";
      if (eyebrow) {
        var eyebrowEl = document.createElement("span");
        eyebrowEl.className = "extuiPanelEyebrow";
        eyebrowEl.setAttribute("data-extui-panel-eyebrow", "");
        eyebrowEl.textContent = eyebrow;
        copy.appendChild(eyebrowEl);
      }
      var heading = document.createElement("h2");
      heading.setAttribute("data-extui-panel-title", "");
      heading.textContent = title;
      copy.appendChild(heading);
      if (hint) {
        var hintEl = document.createElement("div");
        hintEl.className = "extuiPanelHeaderHint extuiNavPanelHint";
        hintEl.setAttribute("data-extui-panel-hint", "");
        hintEl.textContent = hint;
        copy.appendChild(hintEl);
      }
      lead.appendChild(copy);
      header.appendChild(lead);

      var actions = document.createElement("div");
      actions.className = "extuiPanelHeaderActions extuiNavPanelHeaderActions";
      var availability = window.ExtensionCore && window.ExtensionCore.FeatureAvailability;
      var tutorialVisible = false;
      try { tutorialVisible = !!(availability && typeof availability.isSurfaceVisible === "function" && availability.isSurfaceVisible("tutorials", "panelTutorialButton", { requireRegistered: true }) === true); } catch (_) { tutorialVisible = false; }
      var tutorial = null;
      if (tutorialVisible) {
        tutorial = document.createElement("button");
        tutorial.type = "button";
        tutorial.className = "extuiPanelIconButton extuiPanelTutorialButton extuiNavPanelTutorialBtn";
        tutorial.setAttribute("data-tutorial", "");
        tutorial.setAttribute("aria-label", "Abrir tutorial");
        tutorial.title = "Tutorial";
        tutorial.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (navIcons.tutorial || "") + '</svg>';
      }
      var close = document.createElement("button");
      close.type = "button";
      close.className = "extuiPanelIconButton extuiPanelCloseButton extuiNavPanelCloseBtn";
      close.setAttribute("data-close", "");
      close.setAttribute("aria-label", "Fechar painel");
      close.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (navIcons.close || "") + '</svg>';
      if (tutorial) actions.appendChild(tutorial);
      actions.appendChild(close);
      header.appendChild(actions);
      root.appendChild(header);

      var body = document.createElement("main");
      body.className = "extuiNavPanelBody extuiPanelBody";
      body.setAttribute("data-extui-panel-body", "");
      root.appendChild(body);
      if (footer) {
        var footerEl = document.createElement("footer");
        footerEl.className = "extuiNavPanelFooter extuiPanelFooter";
        footerEl.setAttribute("data-extui-panel-footer", "");
        footerEl.hidden = true;
        root.appendChild(footerEl);
      }
      resizeDirs.forEach(function (dir) {
        var handle = document.createElement("div");
        handle.className = "extuiWorkspaceResizeHandle";
        handle.setAttribute("data-resize-dir", dir);
        handle.setAttribute("aria-hidden", "true");
        root.appendChild(handle);
      });
      if (!existing) document.body.appendChild(root);

      close.addEventListener("click", function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        var workspace = getWorkspace();
        if (workspace) workspace.close();
        syncNav();
      });
      back.addEventListener("click", function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        if (hasSubviews(root)) { popSubview(root); return; }
        var origin = panelState ? panelState.origin(root) : "direct";
        if (panelState) panelState.clearOrigin(root);
        if (origin === "tools") {
          Promise.resolve(openTools()).catch(function () { var workspace = getWorkspace(); if (workspace) workspace.close(); });
          return;
        }
        var workspace = getWorkspace();
        if (workspace) workspace.close();
        syncNav();
      });
      if (tutorial) tutorial.addEventListener("click", async function () {
        var feature = String(configPanel.tutorialKey || id || "").replace(/^extuiNav|Panel$/g, "").toLowerCase();
        try {
          var result = await bridgeCall("tutorialLookup", feature);
          var url = trustedTutorialUrl(result && (result.url || result.videoUrl || result.href));
          if (!url) throw new Error("Tutorial indisponível");
          window.open(url, "_blank", "noopener,noreferrer");
        } catch (_) { await alertFn("O tutorial deste recurso ainda não está disponível. A extensão consultará o servidor somente quando este botão for clicado."); }
      });
      var baseState=shellState(root);
      baseState.subviews.length=0;
      baseState.baseTitle=title;
      baseState.baseEyebrow=eyebrow;
      baseState.baseHint=hint;
      baseState.sizeKey=sizeKey;
      baseState.panelMeta={ title: title, eyebrow: eyebrow, hint: hint, size: sizeKey };
      root.setAttribute("data-panel-size-key",sizeKey);
      root.setAttribute("data-extui-panel-shell", "canonical");
      registerRoot(id, root);
      attachResize(root);
      attachDrag(root);
      installScrollContract(root);
      if (!existing) centerWorkspace(root, sizeKey);
      return root;
    }

    return Object.freeze({
      build: build,
      applySubviewHeader: applySubviewHeader,
      pushSubview: pushSubview,
      popSubview: popSubview,
      focusOnOpen: focusOnOpen,
      restoreFocusAfterClose: restoreFocusAfterClose,
      trustedTutorialUrl: trustedTutorialUrl,
      hasSubviews: hasSubviews,
      peekSubview: peekSubview,
      sizeKey: sizeKeyFor
    });
  };
})();
