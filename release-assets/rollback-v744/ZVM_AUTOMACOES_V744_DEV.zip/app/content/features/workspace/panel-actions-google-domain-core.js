;(function () {
  "use strict";
  if (window.__extCreateActionsGoogleDomainCore) return;
  window.__extCreateActionsGoogleDomainCore = function (deps) {
    deps = deps || {};
    var panelBrand = deps.panelBrand || {};
    var buildPanelShell = deps.buildPanelShell;
    var panelBody = deps.panelBody;
    var escHtml = deps.escHtml;
    if (typeof buildPanelShell !== "function" || typeof panelBody !== "function" || typeof escHtml !== "function") throw new TypeError("Dependências do domínio Google inválidas.");


    function googleShortcutIcon(kind) {
      var logos = {
        gmail:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#EA4335" d="M3 6.75 12 13.5l9-6.75V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path fill="#34A853" d="M3 6.75V18a2 2 0 0 0 2 2h1.55V9.88z"/><path fill="#4285F4" d="M21 6.75V18a2 2 0 0 1-2 2h-1.55V9.88z"/><path fill="#FBBC04" d="M21 6.75V8.1L12 14.85 3 8.1V6.75l9 6.75z"/></svg>',
        contacts:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3.5" width="14" height="17" rx="3" fill="#1A73E8"/><circle cx="12" cy="10" r="2.9" fill="#fff"/><path d="M7.9 17.2c.8-2.1 2.34-3.2 4.1-3.2s3.3 1.1 4.1 3.2" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/><rect x="7.5" y="4.8" width="1.7" height="14.4" rx=".8" fill="#8AB4F8"/></svg>',
        calendar:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4.5" width="16" height="15.5" rx="2.7" fill="#1A73E8"/><rect x="4" y="4.5" width="16" height="4.2" rx="2.7" fill="#8AB4F8"/><path d="M8 3v3M16 3v3" stroke="#1A73E8" stroke-width="1.8" stroke-linecap="round"/><text x="12" y="17" text-anchor="middle" font-size="7.8" font-family="Arial,Helvetica,sans-serif" font-weight="800" fill="#fff">31</text></svg>',
        video:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="6" width="11.8" height="12" rx="3" fill="#34A853"/><path d="M15.4 10.1 20.5 7.9a1 1 0 0 1 1.4.92v6.36a1 1 0 0 1-1.4.92l-5.1-2.2z" fill="#0F9D58"/></svg>',
        chat:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#34A853" d="M6 4h12a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3H10l-4 3v-3H6a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z"/><path fill="#fff" d="M8 9.25h8v1.5H8zm0 3.5h5.5v1.5H8z"/></svg>',
        translate:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="4" width="17" height="16" rx="3" fill="#4285F4"/><path d="M7 9h7M10.5 7.5V9m-2.7 0c.8 2.4 2.2 4.2 4.5 5.5m1.2-5.5c-.7 2.4-2.1 4.3-4.6 5.8" stroke="#fff" stroke-width="1.35" stroke-linecap="round"/><path d="m14.3 16 2-4 2 4m-3.2-1.5h2.4" stroke="#fff" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        drive:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#0F9D58" d="M9.1 3.8h5.7l5.2 9H14.3z"/><path fill="#4285F4" d="M6.2 17.7 3.4 12.9l5.7-9 2.8 4.8z"/><path fill="#F4B400" d="M20 12.8 17.2 17.7H6.2l2.8-4.9z"/></svg>',
        document:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#1A73E8" d="M8 3.5h6.7L19 7.8v12.1A2.1 2.1 0 0 1 16.9 22H8A2 2 0 0 1 6 20V5.5A2 2 0 0 1 8 3.5z"/><path fill="#8AB4F8" d="M14.7 3.5v3a1.3 1.3 0 0 0 1.3 1.3h3z"/><path stroke="#fff" stroke-width="1.7" stroke-linecap="round" d="M9.5 11.5h5M9.5 14.8h5M9.5 18h3.5"/></svg>',
        sheet:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#0F9D58" d="M8 3.5h6.7L19 7.8v12.1A2.1 2.1 0 0 1 16.9 22H8A2 2 0 0 1 6 20V5.5A2 2 0 0 1 8 3.5z"/><path fill="#81C995" d="M14.7 3.5v3a1.3 1.3 0 0 0 1.3 1.3h3z"/><path stroke="#fff" stroke-width="1.5" d="M9.2 11.2h5.8M9.2 14.4h5.8M11.1 9.3v8.5"/></svg>',
        form:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#9334E6" d="M8 3.5h6.7L19 7.8v12.1A2.1 2.1 0 0 1 16.9 22H8A2 2 0 0 1 6 20V5.5A2 2 0 0 1 8 3.5z"/><path fill="#C58AF9" d="M14.7 3.5v3a1.3 1.3 0 0 0 1.3 1.3h3z"/><path fill="#fff" d="M9.3 8.5h1.9v1.9H9.3zm0 4h1.9v1.9H9.3zm0 4h1.9v1.9H9.3z"/><path stroke="#fff" stroke-width="1.5" stroke-linecap="round" d="M12.4 9.4h3.4M12.4 13.4h3.4M12.4 17.4h3.4"/></svg>',
        note:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#FABB05" d="M6 4h12a2.5 2.5 0 0 1 2.5 2.5v11L15 23l-1.6-4H6A2.5 2.5 0 0 1 3.5 16.5v-10A2.5 2.5 0 0 1 6 4z"/><path fill="#fff" d="M12 8.2a2.2 2.2 0 0 0-1.67 3.64l-.68 2.07h4.7l-.68-2.07A2.2 2.2 0 0 0 12 8.2z"/></svg>',
        tasks:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="4" width="14" height="16" rx="2.8" fill="#4285F4"/><path fill="#fff" d="m9.25 10.8 1.5 1.5 3.5-3.7 1.15 1.08-4.62 4.85-2.68-2.67zM9.25 16.3h6v1.5h-6z"/></svg>',
        business:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#EA4335" d="M6.2 5h11.6l1.7 3.5H4.5z"/><path fill="#4285F4" d="M5 8h14v9.2A2.8 2.8 0 0 1 16.2 20H7.8A2.8 2.8 0 0 1 5 17.2z"/><path fill="#34A853" d="M10 11h4a2 2 0 0 1 2 2v7H8v-7a2 2 0 0 1 2-2z"/><path fill="#FBBC04" d="M9.2 4h5.6v2H9.2z"/></svg>',
        ads:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="16.7" cy="17.5" r="2.2" fill="#34A853"/><path fill="#4285F4" d="M8.3 5.4A4.3 4.3 0 0 1 15.8 9l-4.6 8A4.3 4.3 0 1 1 3.8 13z"/><path fill="#FBBC04" d="M15.7 6.3a4.2 4.2 0 0 1 1.8 5.7l-2.1 3.7-3.8-2.2 2.1-3.7a4.2 4.2 0 0 1 2-1.8z"/></svg>',
        analytics:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="12" width="3.4" height="7" rx="1.2" fill="#F9AB00"/><rect x="10.3" y="8.3" width="3.4" height="10.7" rx="1.2" fill="#FBBC04"/><circle cx="17.8" cy="6.7" r="2.2" fill="#E8710A"/><rect x="15.9" y="10" width="3.8" height="9" rx="1.4" fill="#E8710A"/></svg>',
        map:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#34A853" d="M12 3.8c3.2 0 5.8 2.52 5.8 5.63 0 3.96-5.8 10.77-5.8 10.77S6.2 13.39 6.2 9.43C6.2 6.32 8.8 3.8 12 3.8z"/><circle cx="12" cy="9.5" r="2.25" fill="#fff"/><path fill="#4285F4" d="M12 3.8c-3.2 0-5.8 2.52-5.8 5.63 0 .69.12 1.43.34 2.2l5.46-7.83z"/><path fill="#EA4335" d="M17.45 11.63c.23-.77.35-1.5.35-2.2 0-3.1-2.6-5.63-5.8-5.63v5.7z"/><path fill="#FBBC04" d="M9.08 15.8A58.5 58.5 0 0 0 12 20.23s1.23-1.45 2.6-3.39z"/></svg>'
      };
      return logos[kind] || logos.document;
    }

    function buildGooglePanel() {
      var root = buildPanelShell({ id: "extuiNavGooglePanel", title: "Google", accent: panelBrand.google.accent, icon: panelBrand.google.icon, eyebrow: "Produtividade", hint: "Atalhos Google selecionados para atendimento, organização, dados e aquisição comercial.", size: "md" });
      var body = panelBody(root); body.innerHTML = ""; body.classList.add("extuiGoogleScrollableBody");
      var groups = [
        { title: "Comunicação e atendimento", apps: [{ name: "Gmail", icon: "gmail", url: "https://mail.google.com/" }, { name: "Contatos", icon: "contacts", url: "https://contacts.google.com/" }, { name: "Agenda", icon: "calendar", url: "https://calendar.google.com/" }, { name: "Meet", icon: "video", url: "https://meet.google.com/" }, { name: "Chat", icon: "chat", url: "https://chat.google.com/" }, { name: "Tradutor", icon: "translate", url: "https://translate.google.com/" }] },
        { title: "Arquivos e produtividade", apps: [{ name: "Drive", icon: "drive", url: "https://drive.google.com/" }, { name: "Documentos", icon: "document", url: "https://docs.google.com/" }, { name: "Planilhas", icon: "sheet", url: "https://sheets.google.com/" }, { name: "Formulários", icon: "form", url: "https://forms.google.com/" }, { name: "Keep", icon: "note", url: "https://keep.google.com/" }, { name: "Tarefas", icon: "tasks", url: "https://tasks.google.com/" }] },
        { title: "Negócios e insights", apps: [{ name: "Perfil da Empresa", icon: "business", url: "https://business.google.com/" }, { name: "Google Ads", icon: "ads", url: "https://ads.google.com/" }, { name: "Analytics", icon: "analytics", url: "https://analytics.google.com/" }, { name: "Maps", icon: "map", url: "https://maps.google.com/" }] }
      ];
      groups.forEach(function (group) {
        var section = document.createElement("section"); section.className = "extuiGoogleRailGroup";
        var head = document.createElement("div"); head.className = "extuiGoogleRailGroupHead"; head.innerHTML = '<strong>' + escHtml(group.title) + '</strong><small>' + group.apps.length + ' atalhos</small>'; section.appendChild(head);
        var grid = document.createElement("div"); grid.className = "extuiGoogleRailGrid";
        group.apps.forEach(function (app) { var link = document.createElement("a"); link.className = "extuiGoogleRailCard extuiGoogleRailCard--brand"; link.href = app.url; link.target = "_blank"; link.rel = "noopener noreferrer"; link.setAttribute("aria-label", "Abrir " + app.name + " em nova aba"); link.innerHTML = '<span class="extuiGoogleRailMark extuiGoogleRailMark--brand">' + googleShortcutIcon(app.icon) + '</span><span class="extuiGoogleRailCopy"><strong>' + escHtml(app.name) + '</strong></span>'; grid.appendChild(link); });
        section.appendChild(grid); body.appendChild(section);
      });
      return root;
    }
    return Object.freeze({ buildGooglePanel: buildGooglePanel });
  };
})();
