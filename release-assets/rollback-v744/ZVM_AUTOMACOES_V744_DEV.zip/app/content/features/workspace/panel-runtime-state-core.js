;(function(){
  "use strict";
  if(window.__extCreatePanelRuntimeStateCore)return;
  window.__extCreatePanelRuntimeStateCore=function(){
    var states=new WeakMap();
    function state(root){var s=states.get(root);if(!s){s={backEnabled:false,openOrigin:"direct",refresh:null,storeDirty:false};states.set(root,s);}return s;}
    function setOrigin(root,payload){if(!root)return "direct";payload=payload||{};var s=state(root);s.backEnabled=true;s.openOrigin=payload.source==="chat-tools"?"tools":"direct";return s.openOrigin;}
    function origin(root){return root?state(root).openOrigin:"direct";}
    function clearOrigin(root){if(root)state(root).openOrigin="direct";}
    function backEnabled(root){return !!(root&&state(root).backEnabled);}
    function setRefresh(root,fn){if(!root)throw new TypeError("Painel inválido.");state(root).refresh=typeof fn==="function"?fn:null;return fn;}
    function markDirty(root,value){if(root)state(root).storeDirty=value!==false;}
    function isDirty(root){return !!(root&&state(root).storeDirty);}
    async function refresh(root){if(!root)return false;var s=state(root);if(typeof s.refresh!=="function")return false;await s.refresh();s.storeDirty=false;return true;}
    function clear(root){if(root)states.delete(root);}
    return Object.freeze({setOrigin:setOrigin,origin:origin,clearOrigin:clearOrigin,backEnabled:backEnabled,setRefresh:setRefresh,markDirty:markDirty,isDirty:isDirty,refresh:refresh,clear:clear});
  };
})();
