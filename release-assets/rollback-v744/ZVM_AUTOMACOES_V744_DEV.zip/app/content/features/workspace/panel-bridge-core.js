;(function(){
  "use strict";
  if(window.__extCreatePanelBridgeCore)return;
  window.__extCreatePanelBridgeCore=function(deps){
    deps=deps||{};
    var getOptionsKey=typeof deps.getOptionsKey==="function"?deps.getOptionsKey:function(){return "EXTUI:extappOptionsStore";};
    function extBridgeCall(action, key, value) {
      if (action === "get") return window.ExtensionStorage ? window.ExtensionStorage.get(key) : Promise.reject(new Error("O armazenamento da extensão não está disponível."));
      if (action === "set") return window.ExtensionStorage ? window.ExtensionStorage.set(key, value) : Promise.reject(new Error("O armazenamento da extensão não está disponível."));
      if (action === "remove") return window.ExtensionStorage ? window.ExtensionStorage.remove(key) : Promise.reject(new Error("O armazenamento da extensão não está disponível."));
      if (action === "resourceUrl") {
        var allowed = { "logo-dark": "assets/brand/logo-icon-dark.png", "logo-light": "assets/brand/logo-icon-light.png" };
        return allowed[key] ? Promise.resolve(chrome.runtime.getURL(allowed[key])) : Promise.reject(new Error("Recurso não permitido: " + key));
      }
      if (action === "notificationFeed" || action === "tutorialLookup") {
        if (action === "tutorialLookup") {
          var availability = window.ExtensionCore && window.ExtensionCore.FeatureAvailability;
          var allowed = false;
          try { allowed = !!(availability && typeof availability.isSurfaceVisible === "function" && availability.isSurfaceVisible("tutorials", "tutorialLookup", { requireRegistered: true }) === true); } catch (_) { allowed = false; }
          if (!allowed) { var unavailable = new Error("Recurso temporariamente indisponível."); unavailable.code = "FEATURE_UNAVAILABLE"; return Promise.reject(unavailable); }
        }
        return new Promise(function (resolve, reject) {
          var feature = action === "tutorialLookup" ? String(key || "").replace(/[^a-z0-9_-]/gi, "").slice(0, 80) : "";
          try {
            chrome.runtime.sendMessage({ type: "EXTUI_FIXED_JSON_FETCH", kind: action, feature: feature }, function (response) {
              var last = chrome.runtime.lastError;
              if (last) { reject(new Error(last.message)); return; }
              if (!response || response.ok !== true) { var e = new Error(response && response.error || "Falha ao consultar o serviço da extensão."); if (response && response.code) e.code = response.code; reject(e); return; }
              resolve(response.data);
            });
          } catch (err) { reject(err); }
        });
      }
      if (action === "openShell" || action === "crmProfessionalOperation") {
        return new Promise(function (resolve, reject) {
          var msg;
          if (action === "openShell") {
            var req = value && typeof value === "object" ? value : {};
            msg = { __extOpenShell: true, section: req.section || null, focus: req.focus || null, crmContactId: req.crmContactId || null, crmId: req.crmId || null, crmView: req.crmView || null, crmProfileTab: req.crmProfileTab || null, flowId: req.flowId || null, funnelId: req.funnelId || null, crmCreate: req.crmCreate === true, crmCopilot: req.crmCopilot === true, reuseExisting: req.reuseExisting === true, newTab: req.newTab === true };
          } else {
            msg = { __extCrmProfessionalOperation: true, operation: value && typeof value === "object" ? value : null };
          }
          try { chrome.runtime.sendMessage(msg, function (response) {
            var last = chrome.runtime.lastError;
            if (last) { reject(new Error(last.message)); return; }
            if (!response || response.ok !== true) { reject(new Error(response && response.error || "A operação não pôde ser concluída.")); return; }
            resolve(action === "crmProfessionalOperation" ? (response.result || true) : response);
          }); } catch (err) { reject(err); }
        });
      }
      return Promise.reject(new Error("Esta ação não está disponível neste contexto: " + action));
    }
    function extGet(key) { return extBridgeCall("get", key); }
    function extSet(key, value) {
      if(key===getOptionsKey()&&typeof chrome!=="undefined"&&chrome.runtime&&chrome.runtime.sendMessage){return new Promise(function(resolve,reject){chrome.runtime.sendMessage({type:"EXTUI_OPTIONS_COMMIT",scope:"operational",patch:value||{}},function(r){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message));return;}if(!r||r.ok!==true){reject(new Error(r&&r.error||"Falha ao salvar as opções."));return;}resolve(r.value);});});}
      return extBridgeCall("set", key, value);
    }
    function extCrmProfessionalOperation(operation) { return extBridgeCall("crmProfessionalOperation", null, operation); }
    function openShellHtml(section, options) {
      return extBridgeCall("openShell", null, { section: typeof section === "string" ? section : null, focus: options && options.focus || null, crmContactId: options && options.crmContactId || null, crmId: options && options.crmId || null, crmView: options && options.crmView || null, crmProfileTab: options && options.crmProfileTab || null, flowId: options && options.flowId || null, funnelId: options && options.funnelId || null, crmCreate: !!(options && options.crmCreate), crmCopilot: !!(options && options.crmCopilot), reuseExisting: !!(options && options.reuseExisting), newTab: !!(options && options.newTab) });
    }
    return Object.freeze({ bridgeCall:extBridgeCall, get:extGet, set:extSet, crmProfessionalOperation:extCrmProfessionalOperation, openShellHtml:openShellHtml });
  };
})();
