;

;
try{
(function () {
  "use strict";
var flowRuntime = { listenerAttached: false };


  if (window.__extFluxosEngineBooted) return;
  window.__extFluxosEngineBooted = true;

  flowRuntime.instanceId = Math.random().toString(36).slice(2, 10);

  var FLOW_STORE_KEY = "EXTUI:extappFlowStore";
  var RUNNING_STORE_KEY = "EXTUI:extappFlowRunningStore";
  var AI_ASSISTANTS_STORE_KEY = "EXTUI:aiAssistantsStore";
  var AI_AGENTS_STORE_KEY = "EXTUI:aiAgentsStore";
  var INTEGRATIONS_STORE_KEY = "EXTUI:integrationsStore";
  var KNOWLEDGE_STORE_KEY = "EXTUI:knowledgeBasesStore";
  flowRuntime.activeAiRequests = new Map();
  flowRuntime.cancelledExecutionIds = new Set();
  flowRuntime.domainTriggerCooldowns = new Map();
  var EXTUI_DOMAIN_TRIGGER_COOLDOWN_MS = 120000;


  flowRuntime.pendingTriggerMedia = new Map();
  function takeTriggerMedia(instanceId) {
    var ref = flowRuntime.pendingTriggerMedia.get(instanceId);
    flowRuntime.pendingTriggerMedia.delete(instanceId);
    return ref || null;
  }

  var CRM_STORE_KEY = "EXTUI:CrmStore";

  async function loadCrmList() {
    var raw = await extfStorageGet(CRM_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.crmList) || [];
  }

  var ITEM_STORAGE_BY_TYPE = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList" },
    audio: { key: "EXTUI:audioStore", listField: "audioList" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList" },
    sticker: { key: "EXTUI:stickerStore", listField: "stickerList" },
    document: { key: "EXTUI:documentStore", listField: "documentList" }
  };


  async function loadItemContent(kind, itemId) {
    var config = ITEM_STORAGE_BY_TYPE[kind];
    if (!config) return null;
    var raw = await extfStorageGet(config.key);
    var state = parsePersisted(raw);
    var list = (state && state[config.listField]) || [];
    var meta = list.find(function (it) { return it.id === itemId; });
    if (!meta) return null;
    var contentRaw = await extfStorageGet(itemId);
    var content = null;
    if (contentRaw) {
      try { content = typeof contentRaw === "string" ? JSON.parse(contentRaw) : contentRaw; }
      catch (err) { err.code = err.code || "FLOW_ITEM_CONTENT_CORRUPT"; throw err; }
      if (!content || typeof content !== "object" || Array.isArray(content)) { var invalidContent = new Error("O conteúdo do item usado pelo Fluxo está corrompido e o envio foi bloqueado."); invalidContent.code = "FLOW_ITEM_CONTENT_CORRUPT"; throw invalidContent; }
    }
    return Object.assign({}, meta, content || {});
  }


  function chatIdToPhoneDigits(chatId) {
    var at = chatId.indexOf("@");
    var head = at >= 0 ? chatId.slice(0, at) : chatId;
    return head.replace(/\D/g, "");
  }


  async function resolveChatPhoneDigits(chatId) {
    var str = String(chatId || "");
    if (str.indexOf("@lid") !== -1) {
      var engine = getSendEngine();
      if (engine) {
        try {
          var lidEntry = await engine.contact.getPnLidEntry(str);
          var pn = lidEntry && lidEntry.phoneNumber && (lidEntry.phoneNumber._serialized || lidEntry.phoneNumber.user);
          if (pn) return String(pn).replace(/\D/g, "");
        } catch (lidErr) {                                                                 }
      }
      return null;
    }
    return chatIdToPhoneDigits(str) || null;
  }

  async function isChatInColumn(crmList, crmId, columnId, chatId) {
    var crm = crmList.find(function (c) { return c.id === crmId; });
    if (!crm) return false;
    var col = crm.columns.find(function (c) { return c.id === columnId; });
    if (!col) return false;
    var phone = await resolveChatPhoneDigits(chatId);
    if (!phone) return false;
    return col.items.some(function (it) { return it.contact && String(it.contact.phoneNumber || "").replace(/\D/g, "") === phone; });
  }

  var SEEN_CHATS_STORE_KEY = "EXTUI:extappSeenChatsStore";

  async function loadSeenChatIds() {
    var raw = await extfStorageGet(SEEN_CHATS_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.seenChatIds) || [];
  }
  async function markChatSeen(chatId, seenChatIds) {
    seenChatIds.push(chatId);
    await extfStorageSet(SEEN_CHATS_STORE_KEY, JSON.stringify({ state: { seenChatIds: seenChatIds }, version: 0 }));
  }


  var LAST_SEEN_DATE_STORE_KEY = "EXTUI:extappLastSeenDateStore";
  function todayDateStr(now) {
    return now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0") + "-" + String(now.getDate()).padStart(2, "0");
  }
  async function loadLastSeenDates() {
    var raw = await extfStorageGet(LAST_SEEN_DATE_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.lastSeenDate) || {};
  }
  async function saveLastSeenDates(map) {
    await extfStorageSet(LAST_SEEN_DATE_STORE_KEY, JSON.stringify({ state: { lastSeenDate: map }, version: 0 }));
  }
  function columnEventQueueRequest(action, payload) {
    function request() {
      return new Promise(function (resolve, reject) {
        var settled = false, timer = setTimeout(function () { if (settled) return; settled = true; var timeout = new Error("A fila de eventos do CRM demorou demais para responder."); timeout.code = "CRM_COLUMN_EVENT_QUEUE_TIMEOUT"; reject(timeout); }, 7000);
        try {
          chrome.runtime.sendMessage(Object.assign({ type: "EXTUI_COLUMN_EVENT_QUEUE", action: action }, payload || {}), function (response) {
            if (settled) return; settled = true; clearTimeout(timer);
            if (chrome.runtime.lastError) { var transport = new Error(chrome.runtime.lastError.message || "A fila de eventos do CRM foi interrompida."); transport.code = "CRM_COLUMN_EVENT_QUEUE_TRANSPORT"; reject(transport); return; }
            if (!response || response.ok !== true) { var error = new Error(response && response.userMessage || "A fila de eventos do CRM não pôde ser consultada."); error.code = response && response.errorCode || "CRM_COLUMN_EVENT_QUEUE_FAILED"; reject(error); return; }
            resolve(response.result);
          });
        } catch (error) { if (!settled) { settled = true; clearTimeout(timer); reject(error); } }
      });
    }
    return request().catch(async function (error) {
      if (!error || ["CRM_COLUMN_EVENT_QUEUE_TIMEOUT", "CRM_COLUMN_EVENT_QUEUE_TRANSPORT"].indexOf(error.code) < 0) throw error;
      await new Promise(function (resolve) { setTimeout(resolve, 120); });
      return request();
    });
  }
  async function loadColumnEventQueue() {
    var result = await columnEventQueueRequest("list");
    if (!Array.isArray(result)) { var invalid = new Error("A autoridade da fila de eventos do CRM retornou um estado inválido."); invalid.code = "CRM_COLUMN_EVENT_QUEUE_INVALID_RESPONSE"; throw invalid; }
    return result;
  }
  async function ackColumnEventQueue(ids) {
    if (!ids || !ids.length) return { removed: 0 };
    return columnEventQueueRequest("ack", { ids: ids });
  }
  function resolveColumnEventChatId(crmList, event) {
    if (!event || !event.contactId || !event.crmId) return null;
    var crm = Array.isArray(crmList) ? crmList.find(function (item) { return item && String(item.id || "") === String(event.crmId); }) : null;
    if (!crm || !Array.isArray(crm.columns)) return null;
    var contactId = String(event.contactId), match = null;
    for (var i = 0; i < crm.columns.length; i++) {
      var items = Array.isArray(crm.columns[i] && crm.columns[i].items) ? crm.columns[i].items : [];
      for (var j = 0; j < items.length; j++) {
        if (items[j] && String(items[j].id || "") === contactId) { match = items[j]; break; }
      }
      if (match) break;
    }
    var phone = String(match && match.contact && match.contact.phoneNumber || "").replace(/\D/g, "");
    return phone ? phone + "@c.us" : null;
  }


  function extfStorageGet(key) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.get(key);
  }
  function extfStorageSet(key, value) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.set(key, value);
  }

  function parsePersisted(raw) {
    if (raw == null || raw === "") return null;
    var parsed;
    try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (err) { err.code = err.code || "FLOW_STORE_CORRUPT"; throw err; }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state)) {
      var invalid = new Error("Os dados de Fluxos estão inválidos e não serão sobrescritos.");
      invalid.code = "FLOW_STORE_CORRUPT";
      throw invalid;
    }
    return parsed.state;
  }
  async function loadFlows() {
    var raw = await extfStorageGet(FLOW_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.flowList) || [];
  }
  async function loadRunning() {
    var raw = await extfStorageGet(RUNNING_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.runningList) || [];
  }
  async function saveRunning(runningList) {
    await extfStorageSet(RUNNING_STORE_KEY, JSON.stringify({ state: { runningList: runningList }, version: 0 }));
    scheduleRunningDeadline(runningList);
  }

  flowRuntime.deadlineTimer = null;
  function nextFlowDeadlineAt(runningList, nowMs) {
    var next = null, now = Number(nowMs == null ? Date.now() : nowMs);
    (Array.isArray(runningList) ? runningList : []).forEach(function (instance) {
      if (!instance) return;
      var deadline = instance.status === "waitingForInput" ? Number(instance.expiresAtMs) : instance.status === "waitingDelay" ? Number(instance.resumeAtMs) : 0;
      if (!Number.isFinite(deadline) || deadline <= 0) return;
      if (next === null || deadline < next) next = deadline;
    });
    return next;
  }
  function scheduleRunningDeadline(runningList) {
    if (flowRuntime.deadlineTimer) { clearTimeout(flowRuntime.deadlineTimer); flowRuntime.deadlineTimer = null; }
    var next = nextFlowDeadlineAt(runningList, Date.now());
    if (next === null) return;
    var delay = Math.max(0, next - Date.now());
    flowRuntime.deadlineTimer = setTimeout(function () {
      flowRuntime.deadlineTimer = null;
      processDueFlowDeadlines().catch(function (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("FLOW_DEADLINE_WAKE_FAILED", err); });
    }, Math.min(2147483647, delay));
  }


  flowRuntime.runningMutex = Promise.resolve();
  function withRunningLock(fn) {
    var result = flowRuntime.runningMutex.then(fn);
    flowRuntime.runningMutex = result.catch(function () {});
    return result;
  }

  var STALE_RUNNING_MS = 300000;
  var PRUNE_AFTER_MS = 86400000;


  function matchesKeywordRule(rule, text) {
    var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
    if (formHelpers && typeof formHelpers.matchesTextRule === "function") return formHelpers.matchesTextRule(rule, text, true);
    var keywords = rule.keywords || [];
    if (rule.type === "startsWith") return keywords.some(function (k) { return text.indexOf(k) === 0; });
    if (rule.type === "endsWith") return keywords.some(function (k) { return text.slice(-k.length) === k; });
    if (rule.type === "contains") return keywords.some(function (k) { return text.indexOf(k) >= 0; });
    if (rule.type === "equals") return keywords.some(function (k) { return text === k; });
    if (rule.type === "notContains") return keywords.length > 0 && keywords.every(function (k) { return text.indexOf(k) < 0; });
    return false;
  }
  function triggerType(trigger) {
    return (trigger && trigger.type) || "keyword";
  }
  function triggerModes(trigger) {
    var modes = trigger && Array.isArray(trigger.activationTypes) ? trigger.activationTypes.map(String).filter(Boolean) : [];
    return modes.length ? modes : [triggerType(trigger)];
  }
  function hasTriggerMode(trigger, mode) {
    return triggerModes(trigger).indexOf(mode) >= 0;
  }
  function matchesTrigger(trigger, messageText) {
    if (!hasTriggerMode(trigger, "keyword")) return false;
    if (!trigger || !trigger.keywordRules || trigger.keywordRules.length === 0) return false;
    var text = trigger.isCaseSensitive ? messageText : messageText.toLowerCase();
    var rules = trigger.keywordRules.map(function (r) {
      return trigger.isCaseSensitive ? r : Object.assign({}, r, { keywords: (r.keywords || []).map(function (k) { return k.toLowerCase(); }) });
    });


    var positiveRules = rules.filter(function (r) { return r.type !== "notContains"; });
    var negativeRules = rules.filter(function (r) { return r.type === "notContains"; });
    var positiveMatch = positiveRules.length === 0 || positiveRules.some(function (r) { return matchesKeywordRule(r, text); });
    if (!positiveMatch) return false;
    return negativeRules.every(function (r) { return matchesKeywordRule(r, text); });
  }


  function fireTriggerWebhook(url, payload) {


    if (!url) return;
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        chrome.runtime.sendMessage({ type:"EXTUI_FLOW_WEBHOOK_SEND", url:String(url), payload:payload||{}, timeoutMs:8000 }, function(res){
          var last=chrome.runtime.lastError;
          if(last||!res||res.ok!==true){var failure=last||new Error(res&&res.error||"Falha ao executar webhook de Fluxo");if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_WEBHOOK_SEND_FAILED",failure);}
        });
      } catch(err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_WEBHOOK_SEND_FAILED",err); }
      return;
    }


    if (window.__extWebhookService && typeof window.__extWebhookService.fire === "function") {
      window.__extWebhookService.fire("fluxo", payload && payload.chatId || "", Object.assign({}, payload || {})).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_WEBHOOK_SERVICE_FAILED",err);});
    }
  }

  function isWithinTriggerWindow(trigger, now) {
    if (!trigger) return true;


    if (trigger.weeklyHours && trigger.weeklyHours[now.getDay()]) {
      var dayCfg = trigger.weeklyHours[now.getDay()];
      if (!dayCfg.active) return false;
      if (dayCfg.from && dayCfg.to && dayCfg.from !== dayCfg.to) {
        var padW = function (n) { return (n < 10 ? "0" : "") + n; };
        var nowStrW = padW(now.getHours()) + ":" + padW(now.getMinutes());
        if (dayCfg.from <= dayCfg.to) {
          if (nowStrW < dayCfg.from || nowStrW > dayCfg.to) return false;
        } else {
          if (nowStrW < dayCfg.from && nowStrW > dayCfg.to) return false;
        }
      }
      return true;
    }
    var days = trigger.activeDays;
    if (Array.isArray(days) && days.length > 0 && days.indexOf(now.getDay()) === -1) {
      return false;
    }
    var hours = trigger.activeHours;
    if (hours && hours.from && hours.to && hours.from !== hours.to) {
      var pad = function (n) { return (n < 10 ? "0" : "") + n; };
      var nowStr = pad(now.getHours()) + ":" + pad(now.getMinutes());
      if (hours.from <= hours.to) {
        if (nowStr < hours.from || nowStr > hours.to) return false;
      } else {

        if (nowStr < hours.from && nowStr > hours.to) return false;
      }
    }
    return true;
  }


  async function passesCrmGate(trigger, chatId, crmList) {
    if (!trigger || !trigger.crmGate || !trigger.crmGate.crmId || !trigger.crmGate.columnId) return true;
    return isChatInColumn(crmList, trigger.crmGate.crmId, trigger.crmGate.columnId, chatId);
  }


  async function evaluateTriggerEligibility(flow, context) {
    var trigger = flow && flow.trigger || {};
    var ctx = context || {};
    var isGroupChat = typeof ctx.isGroupChat === "boolean" ? ctx.isGroupChat : null;
    if (isGroupChat === true && trigger.sendToGroups === false) return { eligible:false, reason:"AUDIENCE_GROUP_DISABLED" };
    if (isGroupChat === false && trigger.sendToContacts === false) return { eligible:false, reason:"AUDIENCE_CONTACT_DISABLED" };
    if (!isWithinTriggerWindow(trigger, ctx.now || new Date())) return { eligible:false, reason:"SCHEDULE_BLOCKED" };
    if (!(await passesCrmGate(trigger, ctx.chatId || "", ctx.crmList || []))) return { eligible:false, reason:"CRM_GATE_BLOCKED" };
    return { eligible:true, reason:null };
  }

  function notifyAcceptedFlowTrigger(flow, chatId, eventType, details) {
    if (!flow) return;
    var extra = details && typeof details === "object" ? details : {};
    var payload = Object.assign({ chatId:chatId, flowId:flow.id, flowName:flow.name, eventType:eventType }, extra);
    if (flow.trigger && flow.trigger.webhook) fireTriggerWebhook(flow.trigger.webhook, payload);
    if (typeof window.__extFireWebhook === "function") window.__extFireWebhook("fluxo", chatId, { flowId:flow.id, flowName:flow.name, triggerEvent:eventType });
  }


  function formatPhoneNumberForVariable(raw) {
    var d = String(raw || "").replace(/\D/g, "");
    if (!d) return "";
    if (d.length >= 12 && d.slice(0, 2) === "55") {
      var rest = d.slice(2), ddd = rest.slice(0, 2), num = rest.slice(2);
      if (num.length === 9) return "+55 (" + ddd + ") " + num.slice(0, 5) + "-" + num.slice(5);
      if (num.length === 8) return "+55 (" + ddd + ") " + num.slice(0, 4) + "-" + num.slice(4);
    }
    return "+" + d;
  }

  function getSendEngine() {
    return (window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null;
  }

  async function applyMessageVariables(text, chatId) {
    if (text == null) return text;
    var source = String(text);
    if (window.__extVariableResolver && typeof window.__extVariableResolver.resolveForChat === "function") return window.__extVariableResolver.resolveForChat(source, chatId);
    if (!/(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|first_name|fn|nome|nome_completo|full_name|nome_extapp|nome_whatsapp|numero|telefone|phone|email|empresa|company|origem_lead|leadSource|cidade|city|estado|state|endereco|address|cep|postalCode|idioma|language|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i.test(source)) return source;
    try {
      var engine = getSendEngine ? getSendEngine() : ((window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null);
      var rawId = String(chatId && chatId._serialized || chatId || "");
      var active = null, contact = null, meta = null;
      if (engine && engine.chat && typeof engine.chat.getActiveChat === "function") {
        try { active = await engine.chat.getActiveChat(); } catch (_) {}
      }
      if (engine && engine.contact && typeof engine.contact.get === "function" && rawId) {
        try { contact = await engine.contact.get(rawId); } catch (_) {}
      }
      if (window.__extContactMetadataService && typeof window.__extContactMetadataService.get === "function" && rawId) {
        try { meta = await window.__extContactMetadataService.get(rawId); } catch (_) {}
      }
      var activeId = String(active && active.id && (active.id._serialized || active.id) || "");
      var activeContact = active && active.contact || null;
      var activeMatches = !!active && (!rawId || !activeId || activeId === rawId);
      var localName = String(meta && meta.localAlias || "").trim();
      var whatsappName = String(
        contact && (contact.name || contact.pushname || contact.formattedName || contact.notifyName || contact.shortName) ||
        (activeMatches && activeContact && (activeContact.name || activeContact.pushname || activeContact.formattedName || activeContact.notifyName || activeContact.shortName)) ||
        (activeMatches && (active.formattedTitle || active.name || active.title)) || ""
      ).trim();
      var fullName = localName || whatsappName;
      var firstName = fullName ? fullName.split(/\s+/)[0] : "";
      var rawNum = rawId.replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
      if (/@lid$/i.test(rawId) && engine && engine.contact && typeof engine.contact.getPnLidEntry === "function") {
        try {
          var lidEntry = await engine.contact.getPnLidEntry(rawId);
          var pn = lidEntry && lidEntry.phoneNumber && (lidEntry.phoneNumber._serialized || lidEntry.phoneNumber.user);
          if (pn) rawNum = String(pn).replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
        } catch (_) {}
      }
      var num = formatPhoneNumberForVariable(rawNum);
      var now = new Date(), hour = now.getHours();
      var greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
      var period = hour < 12 ? "manhã" : hour < 18 ? "tarde" : "noite";
      var dateStr = String(now.getDate()).padStart(2, "0") + "/" + String(now.getMonth() + 1).padStart(2, "0") + "/" + now.getFullYear();
      var timeStr = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
      var weekday = now.toLocaleDateString("pt-BR", { weekday: "long" });
      var vars = {
        primeiro_nome:firstName, primeiroNome:firstName, first_name:firstName, fn:firstName,
        nome:fullName, nome_completo:fullName, full_name:fullName,
        nome_extapp:localName || fullName, nome_ext:localName || fullName, nome_whatsapp:whatsappName || fullName,
        numero:num || "", telefone:num || "", phone:num || "",
        email:String(meta && meta.email || ""), empresa:String(meta && meta.company || ""), company:String(meta && meta.company || ""),
        origem_lead:String(meta && meta.leadSource || ""), leadSource:String(meta && meta.leadSource || ""),
        cidade:String(meta && meta.city || ""), city:String(meta && meta.city || ""), estado:String(meta && meta.state || ""), state:String(meta && meta.state || ""),
        endereco:String(meta && meta.address || ""), address:String(meta && meta.address || ""), cep:String(meta && meta.postalCode || ""), postalCode:String(meta && meta.postalCode || ""),
        idioma:String(meta && meta.language || ""), language:String(meta && meta.language || ""),
        saudacao:greeting, "saudação":greeting, periodo_dia:period, "periodo-dia":period, dia_semana:weekday, data:dateStr, hora:timeStr
      };
      function valueFor(expr) {
        var raw=String(expr||"").trim(), match=raw.match(/^([^|]+?)(?:\|\s*(?:fallback|padrao|padrão)\s*:\s*["']([^"']*)["'])?$/i);
        var key=String(match && match[1] || raw).trim(), fallback=match && match[2];
        var val=Object.prototype.hasOwnProperty.call(vars,key)?vars[key]:"";
        return val != null && String(val) !== "" ? String(val) : (fallback != null ? fallback : "");
      }
      var output=source.replace(/\{\{\s*([^{}]+?)\s*\}\}/g,function(_,expr){return valueFor(expr);});
      output=output.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(_,prefix,key){return prefix+valueFor(key);});
      var aliases=Object.keys(vars).sort(function(a,b){return b.length-a.length;});
      aliases.forEach(function(key){output=output.split("#"+key).join(String(vars[key]||""));});
      return output;
    } catch (_) { return source; }
  }


  async function resolveSendTarget(chatId) {
    if (chatId.indexOf("@lid") !== -1 || chatId.indexOf("@g.us") !== -1) return chatId;
    if (chatId.indexOf("@c.us") === -1) return chatId;
    try {
      var engine = getSendEngine();
      if (!engine) return chatId;
      var entry = await engine.contact.getPnLidEntry(chatId);
      if (entry && entry.lid && entry.lid._serialized) return entry.lid._serialized;
    } catch (err) {
    }
    return chatId;
  }


  function extDjb2Hash(str) {
    var hash = 5381;
    for (var i = 0; i < str.length; i++) hash = (((hash << 5) + hash) + str.charCodeAt(i)) | 0;
    return hash >>> 0;
  }


  function pickRandomNextNodeId(node, chatId) {
    var weights = (node.data && node.data.weights) || [];
    var total = weights.reduce(function (sum, w) { return sum + Math.max(0, Number(w && w.weight) || 0); }, 0);
    if (total <= 0) return { nextNodeId: null, chosenIndex: -1 };
    var sticky = node.data && node.data.mode === "sticky";
    var roll = sticky
      ? (extDjb2Hash(String(chatId) + ":" + node.id) % 100000) / 100000 * total
      : Math.random() * total;
    var acc = 0;
    for (var i = 0; i < weights.length; i++) {
      acc += Math.max(0, Number(weights[i] && weights[i].weight) || 0);
      if (roll < acc) return { nextNodeId: weights[i].nextNodeId, chosenIndex: i };
    }
    return { nextNodeId: weights[weights.length - 1].nextNodeId, chosenIndex: weights.length - 1 };
  }

  function createAiRequestId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return flowRuntime.instanceId + ":ai:" + Date.now() + ":" + Math.random().toString(36).slice(2, 10);
  }

  async function executeSharedActions(actions, chatId, instance, source, lease, effectScope) {
    var executor = window.__extActionExecutor;
    if (!executor || typeof executor.execute !== "function") {
      var unavailable = new Error("O mecanismo de automações ainda não está pronto para executar Fluxos");
      unavailable.code = "ACTION_EXECUTOR_UNAVAILABLE";
      throw unavailable;
    }
    if(lease)lease.assertActive();
    var result = await executor.execute(actions || [], {
      contactId: chatId,
      remetente: chatId,
      source: source || "flow-runtime",
      flowId: instance && instance.flowId || null,
      flowExecutionId: instance && instance.id || null,
      executionId:instance&&instance.id?("flow:"+String(instance.id)+":visit:"+String(Math.max(0,Number(instance.effectOrdinal)||0))+":"+String(effectScope||source||"actions")):undefined,
      cancellationSignal:lease&&lease.signal||null
    });
    if (!result || result.status !== "success") {
      var failed = new Error(result && result.error && result.error.message || "ActionExecutor falhou durante o Fluxo");
      failed.code = result && result.error && result.error.code || "FLOW_ACTION_EXECUTION_FAILED";
      failed.effectDigest = result && result.error && result.error.effectDigest || null;
      failed.remoteEffectSucceeded = result && result.error && result.error.remoteEffectSucceeded === true;
      failed.actionResult = result || null;
      throw failed;
    }
    return result;
  }

  async function sendTextThroughFlowPipeline(chatId, text, resolvedTarget, instance, lease, effectScope) {
    var target = resolvedTarget || await resolveSendTarget(chatId);
    return executeSharedActions([{ type:"txt", properties:{ mensagem:text, aguarde:0, composing:0 } }], target, instance, "flow-text", lease, effectScope||"flow-text");
  }

  function isExecutionCancelled(executionId) {
    return flowRuntime.cancelledExecutionIds.has(executionId);
  }

  function createAiContactBindings(instance) {
    var contactRuntime = window.__extAiAutomationContact;
    if (!contactRuntime || typeof contactRuntime.create !== "function") {
      var unavailable = new Error("O contexto do contato não está disponível para a execução de IA.");
      unavailable.code = "AI_CONTACT_RUNTIME_UNAVAILABLE";
      throw unavailable;
    }
    return contactRuntime.create({
      chatId: instance.chatId,
      crmStoreKey: CRM_STORE_KEY,
      storageGet: extfStorageGet,
      getSendEngine: getSendEngine,
      isCancelled: function () { return isExecutionCancelled(instance.id); },
      getMessages: function (chatId, options) {
        if (typeof window.__extGetChatMessages === "function") return window.__extGetChatMessages(chatId, options);
        var engine = getSendEngine();
        if (!engine || !engine.chat || typeof engine.chat.getMessages !== "function") return Promise.reject(new Error("O WhatsApp ainda não está pronto"));
        return engine.chat.getMessages(chatId, options);
      }
    });
  }

  async function executeAiNode(node, instance) {
    var aiCore = window.__extAiAutomationRuntime;
    var aiClient = window.__extAiRuntime;
    var assistantsCore = window.__extAiAssistantsCore;
    var toolsRegistry = window.__extAiToolsRegistry;
    if (!aiCore || typeof aiCore.execute !== "function" || !aiClient || typeof aiClient.generate !== "function" || typeof aiClient.retrieveKnowledge !== "function" || !assistantsCore) {
      var unavailable = new Error("O recurso de IA ainda não está pronto. Recarregue o WhatsApp Web.");
      unavailable.code = "ai_runtime_unavailable";
      throw unavailable;
    }
    var executionNode = node;
    if (assistantsCore.nodeMode(node && node.data) === "assistant") {
      var stores = await Promise.all([extfStorageGet(AI_ASSISTANTS_STORE_KEY), extfStorageGet(INTEGRATIONS_STORE_KEY), extfStorageGet(KNOWLEDGE_STORE_KEY)]);
      var integrations = stores[1];
      try { if (typeof integrations === "string") integrations = JSON.parse(integrations); } catch (error) { integrations = null; }
      integrations = integrations && integrations.state || integrations || { providers: {} };
      var assistant = assistantsCore.resolveForExecution(stores[0], integrations, node.data.assistantId, null, stores[2]);
      executionNode = Object.assign({}, node, { data: {
        mode: "assistant",
        assistantId: assistant.assistantId,
        providerId: assistant.providerId,
        model: assistant.model,
        instructions: assistant.instructions,
        context: assistant.context,
        memory: assistant.memory,
        knowledge: assistant.knowledge,
        tools: assistant.tools,
        multimodal: assistant.multimodal,
        prompt: node.data.prompt || "",
        outputMode: "sendText"
      } });
    }
    var contextMessageCount = 0;
    var memoryUsedCount = 0;
    var memoryUnavailable = false;
    var knowledgeUsedCount = 0;
    var knowledgeBaseName = "";
    var mediaLabel = "";
    var contactBindings = createAiContactBindings(instance);
    return aiCore.execute(executionNode, instance, {
      createRequestId: createAiRequestId,
      resolveTemplate: function (text) { return applyMessageVariables(text, instance.chatId); },
      loadMemory: contactBindings.loadMemory,
      loadConversation: contactBindings.loadConversation,
      resolveToolContext: async function () {
        if (!toolsRegistry) { var unavailable = new Error("Ferramentas de IA indisponíveis."); unavailable.code = "AI_TOOL_CONTEXT_UNAVAILABLE"; throw unavailable; }
        return contactBindings.resolveToolContext();
      },


      prepareMedia: function () {
        var ref = takeTriggerMedia(instance.id);
        if (!ref || !window.__extAiMediaInput) return Promise.resolve(null);


        return window.__extAiMediaInput.prepareMedia(ref, {
          isCancelled: function () { return isExecutionCancelled(instance.id); },
          downloadMedia: function (msgId) { return window.ExtensionChatBridge.chat.downloadMedia(msgId); }
        });
      },
      generate: function (request) { return aiClient.generate(request); },
      retrieveKnowledge: function (request) { return aiClient.retrieveKnowledge(request); },
      sendText: function (text) { return sendTextThroughFlowPipeline(instance.chatId, text, null, instance, null, "node:"+String(node.id||"ai")+":ai-generate"); },
      isCancelled: function () { return isExecutionCancelled(instance.id); },
      onRequestStart: function (requestId) { flowRuntime.activeAiRequests.set(instance.id, { requestId: requestId, chatId: instance.chatId }); },
      onRequestEnd: function (requestId) {
        var active = flowRuntime.activeAiRequests.get(instance.id);
        if (active && active.requestId === requestId) flowRuntime.activeAiRequests.delete(instance.id);
      },
      onMemoryLoaded: function (count, unavailable) {
        memoryUsedCount = Number(count) || 0; memoryUnavailable = unavailable === true;
        if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", memoryUsedCount: memoryUsedCount, memoryUnavailable: memoryUnavailable });
      },
      onKnowledgeLoaded: function (count, baseName) {
        knowledgeUsedCount = Number(count) || 0; knowledgeBaseName = String(baseName || "").slice(0, 100);
        if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", knowledgeUsedCount: knowledgeUsedCount, knowledgeBaseName: knowledgeBaseName });
      },


      onMediaLoaded: function (kind) {
        mediaLabel = kind === "audio" ? "Áudio processado" : "Imagem processada";
        if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", progressLabel: mediaLabel });
      },
      onContextLoaded: function (count) { contextMessageCount = Number(count) || 0; },
      onToolsUsed: function (toolMetadata) {
        var events = toolMetadata && Array.isArray(toolMetadata.events) ? toolMetadata.events.slice(0, 5).map(function (event) { return { toolId: event.toolId, label: event.label, risk: event.risk, success: event.success === true }; }) : [];
        if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", aiToolCount: Number(toolMetadata && toolMetadata.count) || 0, aiToolEvents: events, progressLabel: events.length ? events[events.length - 1].label : null });
      },
      onWaiting: function (waiting) {
        var details = [];
        if (mediaLabel) details.push(mediaLabel);
        if (memoryUsedCount) details.push(memoryUsedCount + " memória" + (memoryUsedCount === 1 ? "" : "s"));
        if (knowledgeUsedCount) details.push("Knowledge · " + knowledgeUsedCount + " trecho" + (knowledgeUsedCount === 1 ? "" : "s"));
        if (contextMessageCount) details.push(contextMessageCount + " mensagem" + (contextMessageCount === 1 ? "" : "s") + " de contexto");
        if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", memoryUsedCount: memoryUsedCount, memoryUnavailable: memoryUnavailable, knowledgeUsedCount: knowledgeUsedCount, knowledgeBaseName: knowledgeBaseName, progressLabel: waiting ? "Gerando resposta com IA…" + (details.length ? " · " + details.join(" · ") : "") : null });
      }
    });
  }

  async function executeAgentNode(node, instance, options) {
    options = options || {};
    var agentRuntime = window.__extAiAgentRuntime;
    var agentsCore = window.__extAiAgentsCore;
    var assistantsCore = window.__extAiAssistantsCore;
    var aiClient = window.__extAiRuntime;
    var toolsRegistry = window.__extAiToolsRegistry;
    if (!agentRuntime || typeof agentRuntime.execute !== "function" || !agentsCore || !assistantsCore || !aiClient || !toolsRegistry) {
      var unavailable = new Error("Os Agentes IA ainda não estão prontos. Recarregue o WhatsApp Web.");
      unavailable.code = "AI_AGENT_RUNTIME_FAILED";
      throw unavailable;
    }
    var stores = await Promise.all([
      extfStorageGet(AI_AGENTS_STORE_KEY),
      extfStorageGet(AI_ASSISTANTS_STORE_KEY),
      extfStorageGet(INTEGRATIONS_STORE_KEY),
      extfStorageGet(KNOWLEDGE_STORE_KEY)
    ]);
    var integrations = stores[2];
    try { if (typeof integrations === "string") integrations = JSON.parse(integrations); } catch (error) { integrations = null; }
    integrations = integrations && integrations.state || integrations || { providers: {} };
    var snapshot = agentsCore.resolveForExecution(stores[0], stores[1], integrations, node.data && node.data.agentId, null, stores[3]);
    var agentToolCount = 0;
    var memoryUsedCount = 0;
    var knowledgeUsedCount = 0;
    var contextMessageCount = 0;
    var contactBindings = createAiContactBindings(instance);
    var outcome = await agentRuntime.execute(node, instance, snapshot, {
      now: Date.now,
      createRunId: function () {
        if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
        return instance.id + ":agent:" + Date.now() + ":" + Math.random().toString(36).slice(2, 10);
      },
      createRequestId: createAiRequestId,
      resolveTemplate: function (value) { return applyMessageVariables(value, instance.chatId); },
      loadMemory: contactBindings.loadMemory,
      loadConversation: contactBindings.loadConversation,
      resolveToolContext: contactBindings.resolveToolContext,
      prepareMedia: function () {
        var ref = takeTriggerMedia(instance.id);
        if (!ref || !window.__extAiMediaInput) return Promise.resolve(null);


        return window.__extAiMediaInput.prepareMedia(ref, {
          isCancelled: function () { return isExecutionCancelled(instance.id); },
          downloadMedia: function (msgId) { return window.ExtensionChatBridge.chat.downloadMedia(msgId); }
        });
      },
      generate: function (request) { return aiClient.generate(request); },
      retrieveKnowledge: function (request) { return aiClient.retrieveKnowledge(request); },
      endAgentRun: function (agentRunId, executionId) { if (typeof aiClient.endAgentRun === "function") aiClient.endAgentRun(agentRunId, executionId); },
      isCancelled: function () { return isExecutionCancelled(instance.id); },
      onRequestStart: function (requestId) { flowRuntime.activeAiRequests.set(instance.id, { requestId: requestId, chatId: instance.chatId }); },
      onRequestEnd: function (requestId) {
        var active = flowRuntime.activeAiRequests.get(instance.id);
        if (active && active.requestId === requestId) flowRuntime.activeAiRequests.delete(instance.id);
      },
      onRunStart: function () {
        if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", agentName: snapshot.agentName, agentStep: 1, agentMaxSteps: snapshot.maxSteps, agentToolCount: 0, progressLabel: "Agente IA em execução…" });
      },
      onStep: function (state) {
        if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", agentName: snapshot.agentName, agentStep: state.step, agentMaxSteps: state.maxSteps, agentToolCount: state.toolCallCount, agentTrace: (state.events || []).map(function (event) { return { step: state.step, label: event.label, success: event.success === true }; }), progressLabel: "Agente IA · etapa " + state.step + "/" + state.maxSteps });
      },
      onToolsUsed: function (toolMetadata) {
        agentToolCount += Number(toolMetadata && toolMetadata.calls) || 0;
        var events = toolMetadata && Array.isArray(toolMetadata.events) ? toolMetadata.events.slice(0, 5).map(function (event) { return { toolId: event.toolId, label: event.label, risk: event.risk, success: event.success === true }; }) : [];
        if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", agentToolCount: agentToolCount, aiToolEvents: events, progressLabel: events.length ? events[events.length - 1].label : "Agente IA em execução…" });
      },
      onMemoryLoaded: function (count, unavailable) {
        memoryUsedCount = Number(count) || 0;
        if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", memoryUsedCount: memoryUsedCount, memoryUnavailable: unavailable === true });
      },
      onKnowledgeLoaded: function (count, baseName) {
        knowledgeUsedCount = Number(count) || 0;
        if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", knowledgeUsedCount: knowledgeUsedCount, knowledgeBaseName: String(baseName || "").slice(0, 100) });
      },
      onMediaLoaded: function (kind) {
        if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", progressLabel: kind === "audio" ? "Áudio processado" : "Imagem processada" });
      },
      onContextLoaded: function (count) { contextMessageCount = Number(count) || 0; }
    });
    if (isExecutionCancelled(instance.id)) { var cancelled = new Error("A execução do agente foi cancelada."); cancelled.code = "AI_AGENT_CANCELLED"; throw cancelled; }
    var text = outcome && typeof outcome.text === "string" ? outcome.text.trim() : "";
    if (!text) { var empty = new Error("O agente concluiu sem produzir uma resposta."); empty.code = "AI_AGENT_EMPTY_RESPONSE"; throw empty; }
    if (options.trackActivity !== false && typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", agentName: snapshot.agentName, agentStep: outcome.metadata.steps, agentMaxSteps: snapshot.maxSteps, agentToolCount: outcome.metadata.toolCallCount, agentTrace: outcome.metadata.trace, progressLabel: "Agente IA concluído" });
    if (options.returnResult === true) return { text: text, metadata: outcome && outcome.metadata || null, snapshot: snapshot };
    await sendTextThroughFlowPipeline(instance.chatId, text, null, instance, null, "node:"+String(node.id||"agent")+":ai-agent");
    return (node.nextNodeIds && node.nextNodeIds[0]) || null;
  }

  function createManualAgentExecutionId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return "agent-chat:" + window.crypto.randomUUID();
    return "agent-chat:" + Date.now() + ":" + Math.random().toString(36).slice(2, 10);
  }

  async function listCanonicalAgents() {
    var agentsCore = window.__extAiAgentsCore;
    if (!agentsCore) return [];
    var raw = await extfStorageGet(AI_AGENTS_STORE_KEY);
    return agentsCore.normalizeStore(raw).agents.filter(function (agent) { return agent && agent.enabled !== false; }).map(function (agent) { return { id: agent.id, name: agent.name || agent.id, description: agent.description || "" }; });
  }

  async function runCanonicalAgentForChat(request) {
    request = request || {};
    var chatId = String(request.chatId || "").trim();
    var task = String(request.text || request.prompt || request.task || "").trim();
    if (!chatId) { var noChat = new Error("Abra uma conversa antes de executar o Agente IA."); noChat.code = "AI_CONTACT_REQUIRED"; throw noChat; }
    if (!task) { var noTask = new Error("Informe o que o Agente IA deve fazer."); noTask.code = "AI_AGENT_INVALID"; throw noTask; }
    var agents = await listCanonicalAgents();
    if (!agents.length) { var noAgents = new Error("Crie e ative um Agente em Assistentes IA antes de usar este recurso."); noAgents.code = "AI_AGENT_NOT_FOUND"; throw noAgents; }
    var requested = String(request.agentId || request.agent || "random").trim();
    var selected = null;
    if (!requested || requested.toLowerCase() === "random") selected = agents[Math.floor(Math.random() * agents.length)];
    else {
      var lowered = requested.toLowerCase();
      selected = agents.find(function (agent) { return agent.id === requested || String(agent.name || "").toLowerCase() === lowered; }) || null;
    }
    if (!selected) { var missingAgent = new Error("O Agente selecionado não foi encontrado ou está desativado."); missingAgent.code = "AI_AGENT_NOT_FOUND"; throw missingAgent; }
    var instance = { id: createManualAgentExecutionId(), chatId: chatId, variables: {}, status: "running" };
    var result = await executeAgentNode({ type: "aiAgent", nextNodeIds: [], data: { agentId: selected.id, task: task, outputMode: "returnText" } }, instance, { returnResult: true, trackActivity: false });
    return result && result.text || "";
  }

  window.__extAiAgentChatRunner = Object.freeze({ list: listCanonicalAgents, run: runCanonicalAgentForChat });

  var FLOW_LIBRARY_NODE_KIND = Object.freeze({
    sendAudio: "audio",
    sendImage: "image",
    sendVideo: "video",
    sendSticker: "sticker",
    sendDocument: "document",
    sendContact: "contact"
  });

  async function executeFlowLibraryItem(node, target, instance, lease) {
    var itemId = node && node.data && node.data.itemId;
    if (!itemId) { var required = new Error("Selecione um item salvo para esta etapa do Fluxo."); required.code = "FLOW_SAVED_ITEM_REQUIRED"; throw required; }
    if (node.type === "sendSignature") {
      var signatureStore = window.ExtensionSignatureStore;
      if (!signatureStore || typeof signatureStore.get !== "function") { var noSignatureStore = new Error("O armazenamento de Assinaturas ainda não está disponível."); noSignatureStore.code = "SIGNATURE_STORE_UNAVAILABLE"; throw noSignatureStore; }
      var signature = await signatureStore.get(itemId);
      if (!signature) { var missingSignature = new Error("A assinatura salva desta etapa não foi encontrada."); missingSignature.code = "FLOW_SAVED_ITEM_NOT_FOUND"; throw missingSignature; }
      await executeSharedActions([{ type:"txt", properties:{ mensagem:String(signature.text || signature.texto || signature.value || ""), aguarde:0, composing:0 } }], target, instance, "flow-library-item", lease, "node:"+String(node.id)+":sendSignature");
      return;
    }
    var kind = FLOW_LIBRARY_NODE_KIND[node.type];
    var quick = window.__extQuickResponseService;
    if (!kind || !quick || typeof quick.nativeToActions !== "function") { var unavailable = new Error("QuickResponseService indisponível para o item da Biblioteca"); unavailable.code = "FLOW_QUICK_RESPONSE_UNAVAILABLE"; throw unavailable; }
    var actions = await quick.nativeToActions(kind, itemId);
    if (!actions || !actions.length) { var missing = new Error("O item salvo desta etapa não foi encontrado ou não pode ser executado."); missing.code = "FLOW_SAVED_ITEM_NOT_FOUND"; throw missing; }
    if ((node.type === "sendImage" || node.type === "sendVideo") && node.data && node.data.caption && actions[0] && actions[0].properties) actions[0].properties.mensagem = node.data.caption;
    await executeSharedActions(actions, target, instance, "flow-library-item", lease, "node:"+String(node.id)+":"+node.type);
  }


  var FLOW_OPT_IN_TERMINAL_TYPES = ["sendText","sendAudio","sendImage","sendVideo","sendSticker","sendDocument","sendPix","sendList","sendContact","sendSignature","sendQuickResponse","sendMedia","moveToColumn","condition"];
  function isFlowTerminalNode(node) {
    if (!node) return false;
    if (node.type === "end" || node.type === "endHuman") return true;
    return FLOW_OPT_IN_TERMINAL_TYPES.indexOf(node.type) >= 0 && !!(node.data && node.data.isTerminal === true);
  }

  async function executeNode(flow, node, instance, lease) {
    if(lease)lease.assertActive();var chatId = instance.chatId;


    if (node.type === "start") return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    if (node.type === "sendText") {
      var target = await resolveSendTarget(chatId);
      var text = node.data.text;
      if (node.data.itemId) {
        var messageItem = await loadItemContent("message", node.data.itemId);
        if (messageItem) text = messageItem.data;
      }
      await sendTextThroughFlowPipeline(chatId, await applyMessageVariables(text, target), target, instance, lease, "node:"+String(node.id)+":sendText");
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if (node.type === "aiGenerate") return executeAiNode(node, instance);
    if (node.type === "aiAgent") return executeAgentNode(node, instance);
    if (node.type === "sendQuickResponse" || node.type === "sendPix" || node.type === "sendList") {
      var savedTarget = await resolveSendTarget(chatId);
      var savedQuick = window.__extQuickResponseService;
      if (!savedQuick) { var noQuick = new Error("QuickResponseService indisponível para o Fluxo"); noQuick.code = "FLOW_QUICK_RESPONSE_UNAVAILABLE"; throw noQuick; }
      var savedItemId = node.data && node.data.itemId;
      if (!savedItemId) { var noItem = new Error("Selecione um item salvo para esta etapa do Fluxo."); noItem.code = "FLOW_SAVED_ITEM_REQUIRED"; throw noItem; }
      var savedActions = node.type === "sendQuickResponse"
        ? (typeof savedQuick.resolve === "function" ? await savedQuick.resolve(savedItemId) : null)
        : (typeof savedQuick.nativeToActions === "function" ? await savedQuick.nativeToActions(node.type === "sendPix" ? "pix" : "interactive-list", savedItemId) : null);
      if (!savedActions || !savedActions.length) { var missingSaved = new Error("O item salvo desta etapa não foi encontrado ou não pode ser executado."); missingSaved.code = "FLOW_SAVED_ITEM_NOT_FOUND"; throw missingSaved; }
      await executeSharedActions(savedActions, savedTarget, instance, "flow-saved-item", lease, "node:"+String(node.id)+":"+node.type);
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if ((FLOW_LIBRARY_NODE_KIND[node.type] && !(node.type === "sendContact" && node.data && !node.data.itemId && (node.data.contactPhone || node.data.contactName))) || node.type === "sendSignature") {
      var libraryTarget = await resolveSendTarget(chatId);
      await executeFlowLibraryItem(node, libraryTarget, instance, lease);
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if (node.type === "sendMedia") {
      var target = await resolveSendTarget(chatId);
      if (node.data.itemId && node.data.itemKind) {
        var quick = window.__extQuickResponseService;
        var mediaActions = quick && typeof quick.nativeToActions === "function"
          ? await quick.nativeToActions(node.data.itemKind, node.data.itemId)
          : null;
        if (!mediaActions || !mediaActions.length) {
          return (node.nextNodeIds && node.nextNodeIds[0]) || null;
        }
        if (node.data.caption && mediaActions[0] && mediaActions[0].properties && (mediaActions[0].type === "image" || mediaActions[0].type === "video")) {
          mediaActions[0].properties.mensagem = node.data.caption;
        }
        await executeSharedActions(mediaActions, target, instance, "flow-media-item", lease, "node:"+String(node.id)+":media-item");
        return (node.nextNodeIds && node.nextNodeIds[0]) || null;
      }
      if (!node.data || !node.data.mediaData) {
        return (node.nextNodeIds && node.nextNodeIds[0]) || null;
      }
      var rawMedia = String(node.data.mediaData || "");
      var mediaHint = String(node.data.mimeType || node.data.mediaType || "").toLowerCase();
      var actionType = mediaHint.indexOf("video") >= 0 || rawMedia.indexOf("data:video/") === 0 ? "video" : "image";
      await executeSharedActions([{ type:actionType, properties:{ base64:node.data.mediaData, mensagem:node.data.caption || "", isViewOnce:!!node.data.isViewOnce, microVideo:!!node.data.isPtv, aguarde:0, composing:0 } }], target, instance, "flow-media-inline", lease, "node:"+String(node.id)+":media-inline");
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if (node.type === "randomizer") {
      var randomizerPick = pickRandomNextNodeId(node, chatId);


      if (typeof window.__extActivityTrack === "function" && randomizerPick.chosenIndex >= 0) {
        window.__extActivityTrack({
          action: "update", id: "fluxo:" + instance.id, status: "running",
          progressLabel: "Aleatorizar · nó " + node.id + " · caminho " + String.fromCharCode(65 + randomizerPick.chosenIndex) + (node.data && node.data.mode === "sticky" ? " (fixo)" : "")
        });
      }
      return randomizerPick.nextNodeId;
    }
    if (node.type === "sendContact") {
      var contactTarget = await resolveSendTarget(chatId);
      var digits = String(node.data.contactPhone || "").replace(/\D/g, "");
      await executeSharedActions([{ type:"contact", properties:{ phone:digits, name:node.data.contactName || "" } }], contactTarget, instance, "flow-contact", lease, "node:"+String(node.id)+":contact");
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if (node.type === "actions" || node.type === "actionList") {
      var declarativeActions = (node.data && node.data.actions) || node.actions || [];
      await executeSharedActions(declarativeActions, await resolveSendTarget(chatId), instance, "flow-action-list", lease, "node:"+String(node.id)+":actions");
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if (node.type === "userInput") {
      return null;
    }
    if (node.type === "moveToColumn") {
      var crmService = window.__extCrmLabelService && window.__extCrmLabelService.crm;
      if (!crmService || typeof crmService.add !== "function") throw new Error("CrmActionAdapter indisponível para moveToColumn");
      try {
        await crmService.add(chatId, { crmID:node.data.crmId, abaID:node.data.columnId }, { source:"flow-moveToColumn", flowId:flow.id, flowExecutionId:instance.id });
      } catch (crmErr) {
        if (!(crmErr && crmErr.code === "CRM_TARGET_NOT_FOUND")) throw crmErr;
      }
      return (node.nextNodeIds && node.nextNodeIds[0]) || null;
    }
    if (node.type === "condition") {
      var crmListForCondition = await loadCrmList();
      var matches = node.data.conditionType === "inColumn"
        ? await isChatInColumn(crmListForCondition, node.data.crmId, node.data.columnId, chatId)
        : false;
      return matches
        ? ((node.nextNodeIds && node.nextNodeIds[0]) || null)
        : (node.nextNodeIdOnConditionFalse || null);
    }
    if ((node.type === "intervalo" || node.type === "delay")) {
      return null;
    }
    if (node.type === "endHuman" || node.type === "end") {
      return null;
    }
    if (node.type === "unsupported") {
      var unsupported = new Error("Tipo de nó não suportado: " + ((node.data && node.data.type) || "unknown"));
      unsupported.code = "FLOW_NODE_UNSUPPORTED";
      throw unsupported;
    }
    var unknown = new Error("Tipo de nó desconhecido no Fluxo: " + node.type);
    unknown.code = "FLOW_NODE_UNKNOWN";
    throw unknown;
  }

  function findNode(flow, nodeId) {
    return flow.nodes.find(function (n) { return n.id === nodeId; }) || null;
  }


  function extActivityPhoneLabel(chatId) {
    var digits = String(chatId || "").replace(/@.*/, "").replace(/\D/g, "");
    return digits ? "+" + digits : "";
  }


  function extTrackFlowInstance(instance) {
    if (typeof window.__extActivityTrack !== "function") return;
    var id = "fluxo:" + instance.id;
    if (instance.status === "finished") window.__extActivityTrack({ action: "success", id: id });
    else if (instance.status === "cancelled") window.__extActivityTrack({ action: "cancel", id: id });
    else {


      var nextActionAt = instance.status === "waitingDelay" ? (instance.resumeAtMs || null) : null;
      window.__extActivityTrack({ action: "update", id: id, status: "waiting", nextActionAt: nextActionAt });
    }
  }
  function extTrackFlowError(instance, err) {
    if (typeof window.__extActivityTrack !== "function") return;
    window.__extActivityTrack({ action: "error", id: "fluxo:" + instance.id, errorMessage: err && err.message ? err.message : String(err), errorCode: err && err.code, provider: err && err.provider });
  }


  function createRunningInstance(flow, chatId) {
    return {
      id: flow.id + ":" + chatId + ":" + Date.now(),
      flowId: flow.id,
      chatId: chatId,
      currentNodeId: flow.startNodeId,
      effectOrdinal: 0,
      status: "running",
      waitingSinceMs: null,
      expiresAtMs: null,
      lastTouchedAtMs: Date.now()
    };
  }


  async function runInstanceForward(flow, instance, lease) {


    if (typeof window.__extActivityTrack === "function") {


      window.__extActivityTrack({ action: "start", id: "fluxo:" + instance.id, type: "fluxo", source: instance.__extTestRun === true ? "test" : "", title: flow.name, targetLabel: extActivityPhoneLabel(instance.chatId), status: "running", chatId: instance.chatId, executionId: instance.id });
      window.__extActivityTrack({ action: "update", id: "fluxo:" + instance.id, status: "running", nextActionAt: null });
    }
    if(!Number.isFinite(Number(instance.effectOrdinal))||Number(instance.effectOrdinal)<0)instance.effectOrdinal=0;
    var node = findNode(flow, instance.currentNodeId);
    while (node) {
      if(lease)lease.assertActive();var nextId;
      try {
        nextId = await executeNode(flow, node, instance, lease);
      } catch (nodeError) {
        if ((window.__extAiAutomationRuntime && window.__extAiAutomationRuntime.isCancellationError(nodeError)) || isExecutionCancelled(instance.id)) {
          instance.status = "cancelled";
          instance.lastTouchedAtMs = Date.now();
          extTrackFlowInstance(instance);
          return instance;
        }
        var durableTerminal=window.__extSendSafetyManager&&typeof window.__extSendSafetyManager.isDurableTerminalError==="function"&&window.__extSendSafetyManager.isDurableTerminalError(nodeError);
        if(durableTerminal){
          instance.status="error";
          instance.lastErrorCode=nodeError&&nodeError.code||null;
          instance.lastEffectDigest=nodeError&&nodeError.effectDigest||null;
          instance.lastErrorMessage=nodeError&&nodeError.message||String(nodeError);
          instance.lastTouchedAtMs=Date.now();
          extTrackFlowError(instance,nodeError);
          return instance;
        }
        throw nodeError;
      }
      instance.effectOrdinal=Math.max(0,Number(instance.effectOrdinal)||0)+1;
      instance.lastTouchedAtMs = Date.now();
      if (isExecutionCancelled(instance.id)) {
        instance.status = "cancelled";
        extTrackFlowInstance(instance);
        return instance;
      }
      if (node.type === "end") {
        instance.status = "finished";
        extTrackFlowInstance(instance);
        return instance;
      }
      if (isFlowTerminalNode(node) && node.type !== "endHuman") {
        instance.status = "finished";
        extTrackFlowInstance(instance);
        return instance;
      }
      if (node.type === "userInput") {
        instance.status = "waitingForInput";
        instance.waitingSinceMs = Date.now();
        instance.expiresAtMs = node.expirationTimeoutInMs ? Date.now() + node.expirationTimeoutInMs : null;
        extTrackFlowInstance(instance);
        return instance;
      }
      if ((node.type === "intervalo" || node.type === "delay")) {
        var delayMs;
        if (node.data && typeof node.data.delayMs === "number") {
          delayMs = node.data.delayMs;
        } else {
          var amount = (node.data && node.data.amount) || 0;


          var unitMs = { seconds: 1000, minutes: 60000, hours: 3600000, days: 86400000 }[(node.data && node.data.unit) || "minutes"] || 60000;
          delayMs = amount * unitMs;
        }
        instance.status = "waitingDelay";
        instance.resumeAtMs = Date.now() + delayMs;
        extTrackFlowInstance(instance);
        return instance;
      }
      if (node.type === "endHuman") {
        instance.status = "needsHuman";
        extTrackFlowInstance(instance);
        return instance;
      }
      if (!nextId) {
        instance.status = "finished";
        extTrackFlowInstance(instance);
        return instance;
      }
      instance.currentNodeId = nextId;
      if(lease&&!lease.isActive())return instance;
      node = findNode(flow, nextId);
    }
    instance.status = "finished";
    instance.lastTouchedAtMs = Date.now();
    extTrackFlowInstance(instance);
    return instance;
  }


  function normalizeDomainEventChatId(payload) {
    var data = payload && payload.data || payload || {};
    var value = data.targetChatId || data.chatId || data.contactId || data.phoneNumber || data.contactKey || data.from || data.author || "";
    if (value && typeof value === "object") value = value._serialized || value.user || value.id || "";
    value = String(value || "").trim();
    if (!value) return "";
    if (value.indexOf("@") >= 0) return value;
    var digits = value.replace(/\D/g, "");
    return digits.length >= 8 ? digits + "@c.us" : "";
  }
  function domainTriggerMatches(trigger, eventType, payload) {
    if (triggerType(trigger) !== eventType) return false;
    if (eventType !== "funnelCompleted") return true;
    var sourceId = trigger && trigger.data && String(trigger.data.sourceId || "");
    var funnelId = payload && String(payload.funnelId || "");
    return !sourceId || sourceId === funnelId;
  }
  function acceptDomainTrigger(flow, chatId, eventType, payload) {
    var sourceId = eventType === "funnelCompleted" && payload ? String(payload.funnelId || "") : "";
    var key = [flow.id, chatId, eventType, sourceId].join("|");
    var now = Date.now(), last = Number(flowRuntime.domainTriggerCooldowns.get(key) || 0);
    if (now - last < EXTUI_DOMAIN_TRIGGER_COOLDOWN_MS) return false;
    flowRuntime.domainTriggerCooldowns.set(key, now);
    if (flowRuntime.domainTriggerCooldowns.size > 300) {
      flowRuntime.domainTriggerCooldowns.forEach(function (ts, k) { if (now - ts > EXTUI_DOMAIN_TRIGGER_COOLDOWN_MS * 3) flowRuntime.domainTriggerCooldowns.delete(k); });
    }
    return true;
  }
  async function handleDomainTriggerEvent(eventType, payload, envelope) {
    if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return false;
    var chatId = normalizeDomainEventChatId(payload);
    if (!chatId) return false;
    try {
      var flows = await loadFlows();
      var crmList = await loadCrmList().catch(function () { return []; });
      var now = new Date();
      var isGroupChat = chatId.indexOf("@g.us") !== -1;
      var matched = null;
      for (var i = 0; i < flows.length; i++) {
        var candidate = flows[i], trigger = candidate && candidate.trigger || {};
        if (!candidate || !candidate.isActive || !domainTriggerMatches(trigger, eventType, payload)) continue;
        var domainEligibility = await evaluateTriggerEligibility(candidate, { chatId:chatId, isGroupChat:isGroupChat, now:now, crmList:crmList });
        if (!domainEligibility.eligible) continue;
        matched = candidate;
        break;
      }
      if (!matched || !acceptDomainTrigger(matched, chatId, eventType, payload)) return false;
      return await withRunningLock(async function () {
        var running = await loadRunning();
        var busy = running.some(function (item) { return item.chatId === chatId && (item.status === "running" || item.status === "waitingForInput" || item.status === "waitingDelay"); });
        if (busy) return false;
        if (typeof window.__extFunnelsGetRunningForChat === "function") {
          var activeFunnel = await window.__extFunnelsGetRunningForChat(chatId).catch(function () { return null; });
          if (activeFunnel) return false;
        }
        var instance = createRunningInstance(matched, chatId);
        instance.triggerEvent = eventType;
        instance.triggerEventId = envelope && envelope.id || null;
        running.push(instance);
        await saveRunning(running);
        notifyAcceptedFlowTrigger(matched, chatId, eventType, { eventId:instance.triggerEventId, eventDetails:payload || {} });
        try {
          var updated = await runInstanceForward(matched, instance);
          var idx = running.findIndex(function (item) { return item.id === updated.id; });
          if (idx >= 0) running[idx] = updated;
          await saveRunning(running);
          return true;
        } catch (err) {
          instance.status = "finished";
          instance.lastTouchedAtMs = Date.now();
          extTrackFlowError(instance, err);
          await saveRunning(running);
          return false;
        }
      });
    } catch (_) { return false; }
  }

  function startListening() {
    if (flowRuntime.listenerAttached) return;
    flowRuntime.listenerAttached = true;
    var _extuiListenEngine = getSendEngine();
    var _extuiBootMs = Date.now();

    function handleLabelChanged(payload) {
      if (typeof window.__extFireWebhook !== "function") return;
      var e = payload && payload.data ? payload.data : payload;
      var chatId = (e && e.id && e.id._serialized) || (e && e.chatId) || null;
      if (chatId) window.__extFireWebhook("labels", chatId, {});
    }

    var handleIncomingMessage = async function (payload, fromEventBus) {
      if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return;
      var e = payload && payload.data ? payload.data : payload;

      try {


        if (!e || e.fromMe || (e.type !== "chat" && e.type !== "image" && e.type !== "ptt")) return;
        if (!fromEventBus && typeof e.t === "number" && e.t * 1000 < _extuiBootMs) return;
        var text = (e.body || e.caption || "").trim();
        var _extuiTriggerMediaRef = window.__extAiMediaInput ? window.__extAiMediaInput.extractTriggerMedia(e) : null;
        if (!text && !_extuiTriggerMediaRef) return;
        var flows = await loadFlows();
        var chatId = e.from && e.from._serialized ? e.from._serialized : String(e.from);
        var isGroupChat = chatId.indexOf("@g.us") !== -1;


        if (typeof window.__extFireWebhook === "function") window.__extFireWebhook("messages", chatId, { body: text });


        var crmListForGate = await loadCrmList().catch(function () { return []; });


        await withRunningLock(async function () {
          var running = await loadRunning();
          var waitingInstance = running.find(function (r) { return r.chatId === chatId && r.status === "waitingForInput"; });
          if (waitingInstance) {
            var flowForInstance = flows.find(function (f) { return f.id === waitingInstance.flowId; });
            if (!flowForInstance) return;
            var currentNode = findNode(flowForInstance, waitingInstance.currentNodeId);
            if (!currentNode) return;


            var expectedMessages = currentNode.data && currentNode.data.expectedMessages;
            var resumeNodeId;
            if (Array.isArray(expectedMessages) && expectedMessages.length > 0) {


              var lowerText = text.toLowerCase();
              var matchIdx = expectedMessages.findIndex(function (m) { return String(m).toLowerCase() === lowerText; });
              resumeNodeId = matchIdx >= 0 ? (currentNode.nextNodeIds && currentNode.nextNodeIds[matchIdx]) || null : (currentNode.nextNodeIdOnDifferentAnswer || null);
            } else {
              var expectedKeyword = currentNode.data && currentNode.data.expectedAnswer;
              var matchesExpected = expectedKeyword ? text.toLowerCase().indexOf(String(expectedKeyword).toLowerCase()) >= 0 : true;
              var safeFirstNext = (currentNode.nextNodeIds && currentNode.nextNodeIds[0]) || null;
              resumeNodeId = matchesExpected ? safeFirstNext : (currentNode.nextNodeIdOnDifferentAnswer || null);
            }
            waitingInstance.waitingSinceMs = null;
            waitingInstance.expiresAtMs = null;
            waitingInstance.lastTouchedAtMs = Date.now();
            var updatedInstance;
            if (!resumeNodeId) {
              waitingInstance.status = "finished";
              updatedInstance = waitingInstance;
            } else {
              waitingInstance.status = "running";
              waitingInstance.currentNodeId = resumeNodeId;
              if (_extuiTriggerMediaRef) flowRuntime.pendingTriggerMedia.set(waitingInstance.id, _extuiTriggerMediaRef);
              updatedInstance = await runInstanceForward(flowForInstance, waitingInstance);
            }
            var idx = running.findIndex(function (r) { return r.id === updatedInstance.id; });
            if (idx >= 0) running[idx] = updatedInstance;
            await saveRunning(running);
            return;
          }
          var seenChatIds = await loadSeenChatIds();
          if (seenChatIds.indexOf(chatId) === -1) {
            await markChatSeen(chatId, seenChatIds);
            var newChatFlow = null;
            for (var ncf = 0; ncf < flows.length; ncf++) {
              var newChatCandidate = flows[ncf];
              if (!newChatCandidate.isActive || !hasTriggerMode(newChatCandidate.trigger, "newChat")) continue;
              var newChatEligibility = await evaluateTriggerEligibility(newChatCandidate, { chatId:chatId, isGroupChat:isGroupChat, now:new Date(), crmList:crmListForGate });
              if (!newChatEligibility.eligible) continue;
              newChatFlow = newChatCandidate; break;
            }
            if (newChatFlow) {
              var alreadyRunningForNewChat = running.some(function (r) { return r.chatId === chatId && r.status === "running"; });
              if (!alreadyRunningForNewChat) {
                var newChatInstance = createRunningInstance(newChatFlow, chatId);
                running.push(newChatInstance);
                await saveRunning(running);
                if (typeof window.__extFireWebhook === "function") window.__extFireWebhook("newChat", chatId, {});
                notifyAcceptedFlowTrigger(newChatFlow, chatId, "newChat", {});
                if (_extuiTriggerMediaRef) flowRuntime.pendingTriggerMedia.set(newChatInstance.id, _extuiTriggerMediaRef);
                var updatedNewChatInstance = await runInstanceForward(newChatFlow, newChatInstance);
                var newChatIdx = running.findIndex(function (r) { return r.id === updatedNewChatInstance.id; });
                if (newChatIdx >= 0) running[newChatIdx] = updatedNewChatInstance;
                await saveRunning(running);
                return;
              }
            }
          }


          var todayStr = todayDateStr(new Date());
          var lastSeenDates = await loadLastSeenDates();
          if (lastSeenDates[chatId] !== todayStr) {
            lastSeenDates[chatId] = todayStr;
            await saveLastSeenDates(lastSeenDates);
            var newDayFlow = null;
            for (var ndf = 0; ndf < flows.length; ndf++) {
              var newDayCandidate = flows[ndf];
              if (!newDayCandidate.isActive || !hasTriggerMode(newDayCandidate.trigger, "newDay")) continue;
              var newDayEligibility = await evaluateTriggerEligibility(newDayCandidate, { chatId:chatId, isGroupChat:isGroupChat, now:new Date(), crmList:crmListForGate });
              if (!newDayEligibility.eligible) continue;
              newDayFlow = newDayCandidate; break;
            }
            if (newDayFlow) {
              var alreadyRunningForNewDay = running.some(function (r) { return r.chatId === chatId && r.status === "running"; });
              if (!alreadyRunningForNewDay) {
                var newDayInstance = createRunningInstance(newDayFlow, chatId);
                running.push(newDayInstance);
                await saveRunning(running);
                notifyAcceptedFlowTrigger(newDayFlow, chatId, "newDay", {});
                if (_extuiTriggerMediaRef) flowRuntime.pendingTriggerMedia.set(newDayInstance.id, _extuiTriggerMediaRef);
                var updatedNewDayInstance = await runInstanceForward(newDayFlow, newDayInstance);
                var newDayIdx = running.findIndex(function (r) { return r.id === updatedNewDayInstance.id; });
                if (newDayIdx >= 0) running[newDayIdx] = updatedNewDayInstance;
                await saveRunning(running);
                return;
              }
            }
          }
          var alreadyRunning = running.some(function (r) { return r.chatId === chatId && r.status === "running"; });
          if (alreadyRunning) return;
          var messageFlow = null;
          for (var amf = 0; amf < flows.length; amf++) {
            var anyMessageCandidate = flows[amf];
            if (!anyMessageCandidate.isActive || !hasTriggerMode(anyMessageCandidate.trigger, "messageReceived")) continue;
            var messageEligibility = await evaluateTriggerEligibility(anyMessageCandidate, { chatId:chatId, isGroupChat:isGroupChat, now:new Date(), crmList:crmListForGate });
            if (!messageEligibility.eligible) continue;
            messageFlow = anyMessageCandidate;
            break;
          }
          if (messageFlow) {
            var messageInstance = createRunningInstance(messageFlow, chatId);
            running.push(messageInstance);
            await saveRunning(running);
            notifyAcceptedFlowTrigger(messageFlow, chatId, "messageReceived", { message:text });
            if (_extuiTriggerMediaRef) flowRuntime.pendingTriggerMedia.set(messageInstance.id, _extuiTriggerMediaRef);
            var updatedMessageInstance = await runInstanceForward(messageFlow, messageInstance);
            var messageIdx = running.findIndex(function (r) { return r.id === updatedMessageInstance.id; });
            if (messageIdx >= 0) running[messageIdx] = updatedMessageInstance;
            await saveRunning(running);
            return;
          }
          var matched = null;
          for (var mfi = 0; mfi < flows.length; mfi++) {
            var f = flows[mfi];
            if (!f.isActive || !hasTriggerMode(f.trigger, "keyword")) continue;
            if (!matchesTrigger(f.trigger, text)) continue;
            var keywordEligibility = await evaluateTriggerEligibility(f, { chatId:chatId, isGroupChat:isGroupChat, now:new Date(), crmList:crmListForGate });
            if (!keywordEligibility.eligible) continue;
            matched = f;
            break;
          }
          if (!matched) return;
          var instance = createRunningInstance(matched, chatId);
          running.push(instance);
          await saveRunning(running);
          notifyAcceptedFlowTrigger(matched, chatId, "keyword", { message:text });
          if (_extuiTriggerMediaRef) flowRuntime.pendingTriggerMedia.set(instance.id, _extuiTriggerMediaRef);
          try {
            await runInstanceForward(matched, instance);
          } catch (runErr) {
            instance.status = "finished";
            instance.lastTouchedAtMs = Date.now();
            extTrackFlowError(instance, runErr);
            await saveRunning(running);
            throw runErr;
          }
          await saveRunning(running);
        });
      } catch (err) {
      }
    };

    var bus = window.__extEventBus || window.__extDomainEventBus;
    if (bus && typeof bus.on === "function") {
      bus.on("MessageReceived", function (payload) { handleIncomingMessage(payload, true); });
      bus.on("LabelChanged", handleLabelChanged);
      bus.on("FunnelCompleted", function (payload, env) { handleDomainTriggerEvent("funnelCompleted", payload, env); });
      bus.on("FollowUpSent", function (payload, env) { handleDomainTriggerEvent("followUpSent", payload, env); });
      bus.on("ScheduleSent", function (payload, env) { handleDomainTriggerEvent("scheduleSent", payload, env); });
      bus.on("OrderCreated", function (payload, env) { handleDomainTriggerEvent("orderChanged", payload, env); });
      bus.on("OrderUpdated", function (payload, env) { handleDomainTriggerEvent("orderChanged", payload, env); });
      bus.on("OrderTrackingSent", function (payload, env) { handleDomainTriggerEvent("orderChanged", payload, env); });
      return;
    }


    if (!_extuiListenEngine || !_extuiListenEngine.ev || typeof _extuiListenEngine.ev.addListener !== "function") {
      flowRuntime.listenerAttached = false;
      return;
    }
    try { _extuiListenEngine.ev.addListener("chat.update_label", handleLabelChanged); } catch (labelErr) { }
    _extuiListenEngine.ev.addListener("chat.new_message", function (e) { handleIncomingMessage(e, false); });
  }


  window.__extFluxosStartFlowManually = async function (flowId, chatId, options) {
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Fluxos");
    return withRunningLock(async function () {
      var flows = await loadFlows();
      var flow = flows.find(function (f) { return f.id === flowId; });
      if (!flow) throw new Error("flow not found: " + flowId);
      if (!flow.startNodeId) throw new Error("flow has no start node: " + flowId);


      var t = flow.trigger || {};
      var isGroupChat = chatId.indexOf("@g.us") !== -1;
      if (isGroupChat && t.sendToGroups === false) throw new Error("flow does not allow group chats: " + flowId);
      if (!isGroupChat && t.sendToContacts === false) throw new Error("flow does not allow direct contacts: " + flowId);
      var running = await loadRunning();
      var alreadyRunning = running.some(function (r) { return r.chatId === chatId && r.status === "running"; });
      if (alreadyRunning) throw new Error("a flow is already running for chat " + chatId);
      var instance = createRunningInstance(flow, chatId);
      if (options && options.isTest) Object.defineProperty(instance, "__extTestRun", { value: true, enumerable: false });
      running.push(instance);
      await saveRunning(running);
      try {
        var updated = await runInstanceForward(flow, instance);
        var idx = running.findIndex(function (r) { return r.id === updated.id; });
        if (idx >= 0) running[idx] = updated;
        await saveRunning(running);
      } catch (runErr) {
        instance.status = "finished";
        instance.lastTouchedAtMs = Date.now();
        extTrackFlowError(instance, runErr);
        await saveRunning(running);
        throw runErr;
      }
    });
  };


  function cancelAiImmediately(chatId, executionId) {
    var cancelledIds = [];
    if (executionId) {
      flowRuntime.cancelledExecutionIds.add(executionId);
      cancelledIds.push(executionId);
    }
    flowRuntime.activeAiRequests.forEach(function (active, activeExecutionId) {
      if ((executionId && activeExecutionId !== executionId) || (!executionId && active.chatId !== chatId)) return;
      flowRuntime.cancelledExecutionIds.add(activeExecutionId);
      if (cancelledIds.indexOf(activeExecutionId) < 0) cancelledIds.push(activeExecutionId);
      if (window.__extAiRuntime && typeof window.__extAiRuntime.cancel === "function") window.__extAiRuntime.cancel(active.requestId, activeExecutionId);
    });
    return cancelledIds;
  }

  window.__extFluxosCancelFlow = function (chatId, executionId) {
    var immediateIds = cancelAiImmediately(chatId, executionId);
    return withRunningLock(async function () {
      var running = await loadRunning();
      var idx = executionId
        ? running.findIndex(function (r) {
            return r.id === executionId && (r.status === "running" || r.status === "waitingForInput" || r.status === "waitingDelay" || r.status === "cancelled");
          })
        : running.findIndex(function (r) {
            return r.chatId === chatId && (r.status === "running" || r.status === "waitingForInput" || r.status === "waitingDelay" || r.status === "cancelled");
          });
      if (idx < 0) return immediateIds.length > 0;
      running[idx].status = "cancelled";
      running[idx].lastTouchedAtMs = Date.now();
      extTrackFlowInstance(running[idx]);
      await saveRunning(running);
      return true;
    }).finally(function () {
      immediateIds.forEach(function (id) { flowRuntime.cancelledExecutionIds.delete(id); });
    });
  };

  window.__extFluxosCancelAll = function () {
    var immediateIds = [];
    flowRuntime.activeAiRequests.forEach(function (active, executionId) {
      flowRuntime.cancelledExecutionIds.add(executionId);
      immediateIds.push(executionId);
      if (window.__extAiRuntime && typeof window.__extAiRuntime.cancel === "function") window.__extAiRuntime.cancel(active.requestId, executionId);
    });
    return withRunningLock(async function () {
      var running = await loadRunning();
      var counted = Object.create(null);
      immediateIds.forEach(function (id) { counted[id] = true; });
      var count = immediateIds.length;
      running.forEach(function (r) {
        if (r.status === "running" || r.status === "waitingForInput" || r.status === "waitingDelay") {
          r.status = "cancelled";
          r.lastTouchedAtMs = Date.now();
          extTrackFlowInstance(r);
          if (!counted[r.id]) { counted[r.id] = true; count++; }
        }
      });
      if (count) await saveRunning(running);
      return count;
    }).finally(function () {
      immediateIds.forEach(function (id) { flowRuntime.cancelledExecutionIds.delete(id); });
    });
  };


  window.__extFluxosCountRunningByFlowId = function (flowId) {
    return loadRunning().then(function (running) {
      return running.filter(function (r) {
        return r.flowId === flowId && (r.status === "running" || r.status === "waitingForInput" || r.status === "waitingDelay");
      }).length;
    });
  };




  window.__extFluxosCommandDirect = async function(command) {
    command = command || {};
    if (command.action !== "startManual") throw new Error("Comando de Fluxos inválido.");
    var manualTarget = String(command.phoneNumber || "");
    if (manualTarget.indexOf("@") === -1) manualTarget += "@c.us";
    var chatId = await resolveSendTarget(manualTarget);
    await window.__extFluxosStartFlowManually(command.flowId, chatId, { isTest: command.isTest === true });
    return true;
  };


  async function processDueFlowTimers(running, flows, now, lease) {
    var changed = false;
    for (var i = 0; i < running.length; i++) {
      if (lease && !lease.isActive()) break;
      var inst = running[i];
      if (inst.status !== "waitingForInput" || !inst.expiresAtMs || inst.expiresAtMs > now) continue;
      var flow = flows.find(function (f) { return f.id === inst.flowId; });
      if (!flow) { inst.status = "finished"; inst.lastTouchedAtMs = now; extTrackFlowInstance(inst); changed = true; continue; }
      var node = findNode(flow, inst.currentNodeId);
      if (!node || !node.nextNodeIdOnExpiration) { inst.status = "finished"; inst.lastTouchedAtMs = now; extTrackFlowInstance(inst); changed = true; continue; }
      inst.currentNodeId = node.nextNodeIdOnExpiration;
      inst.status = "running";
      inst.waitingSinceMs = null;
      inst.expiresAtMs = null;
      running[i] = await runInstanceForward(flow, inst, lease);
      changed = true;
    }
    for (var d = 0; d < running.length; d++) {
      if (lease && !lease.isActive()) break;
      var delayed = running[d];
      if (delayed.status !== "waitingDelay" || !delayed.resumeAtMs || delayed.resumeAtMs > now) continue;
      var delayFlow = flows.find(function (f) { return f.id === delayed.flowId; });
      if (!delayFlow) { delayed.status = "finished"; delayed.lastTouchedAtMs = now; extTrackFlowInstance(delayed); changed = true; continue; }
      var delayNode = findNode(delayFlow, delayed.currentNodeId);
      var delayNextId = (delayNode && delayNode.nextNodeIds && delayNode.nextNodeIds[0]) || null;
      delayed.resumeAtMs = null;
      if (!delayNextId) { delayed.status = "finished"; delayed.lastTouchedAtMs = now; extTrackFlowInstance(delayed); changed = true; continue; }
      delayed.status = "running";
      delayed.currentNodeId = delayNextId;
      running[d] = await runInstanceForward(delayFlow, delayed, lease);
      changed = true;
    }
    return { running: running, changed: changed };
  }

  async function processDueFlowDeadlines() {
    return withRunningLock(async function () {
      if (typeof window.__extWithAutomationLease !== "function") { var coordErr = new Error("Coordenação segura entre abas indisponível."); coordErr.code = "AUTOMATION_COORDINATOR_UNAVAILABLE"; throw coordErr; }
      return window.__extWithAutomationLease("flow-tick", async function (lease) {
        var running = await loadRunning(); lease.assertActive();
        if (window.__extPlanGate && await window.__extPlanGate.isRestricted()) {
          var freeChanged = false, freeNow = Date.now();
          running.forEach(function (inst) { if (inst && ["running","waitingForInput","waitingDelay"].indexOf(inst.status) >= 0) { inst.status = "cancelled"; inst.lastTouchedAtMs = freeNow; extTrackFlowInstance(inst); freeChanged = true; } });
          if (freeChanged) await saveRunning(running); else scheduleRunningDeadline(running);
          return { changed: freeChanged };
        }
        var flows = await loadFlows(), now = Date.now();
        var due = await processDueFlowTimers(running, flows, now, lease);
        running = due.running;
        if (due.changed) await saveRunning(running); else scheduleRunningDeadline(running);
        lease.assertActive();
        return { changed: due.changed };
      });
    });
  }

  setTimeout(function () {
    loadRunning().then(scheduleRunningDeadline).catch(function (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("FLOW_DEADLINE_BOOT_FAILED", err); });
  }, 1000);


  setTimeout(function () {
    if (getSendEngine()) {
      startListening();
      return;
    }
    var onReady = function () {
      if (!getSendEngine()) return;
      document.removeEventListener("wppconnect_ready", onReady);
      startListening();
    };
    document.addEventListener("wppconnect_ready", onReady);
    setTimeout(function () {
      if (getSendEngine()) startListening();
      document.removeEventListener("wppconnect_ready", onReady);
    }, 20000);
  }, 800);


  setInterval(function () {
    withRunningLock(async function () {
      if (typeof window.__extWithAutomationLease !== "function") { var coordErr = new Error("Coordenação segura entre abas indisponível."); coordErr.code = "AUTOMATION_COORDINATOR_UNAVAILABLE"; throw coordErr; }
      return window.__extWithAutomationLease("flow-tick", async function (lease) {
      var running = await loadRunning();lease.assertActive();
      if(window.__extPlanGate&&await window.__extPlanGate.isRestricted()){
        var freeChanged=false,freeNow=Date.now();running.forEach(function(inst){if(inst&&["running","waitingForInput","waitingDelay"].indexOf(inst.status)>=0){inst.status="cancelled";inst.lastTouchedAtMs=freeNow;extTrackFlowInstance(inst);freeChanged=true;}});if(freeChanged)await saveRunning(running);return;
      }
      var flows = await loadFlows();
      var now = Date.now();
      var dueResult = await processDueFlowTimers(running, flows, now, lease);
      running = dueResult.running;
      var changed = dueResult.changed;


      function traceColumnEvent(detail){try{if(window.__extTraceRuntime)window.__extTraceRuntime("FLOW_CRM_EVENT",detail);}catch(_){}}
      var pendingEvents = await loadColumnEventQueue();
      var acknowledgedColumnEventIds = [];
      var columnEventCrmList = pendingEvents.length ? await loadCrmList() : [];
      if (pendingEvents.length > 0) {
        for (var ev = 0; ev < pendingEvents.length; ev++) {
          if(!lease.isActive())break;var evt = pendingEvents[ev];
          if (!evt || !evt.id || !evt.contactId) { var evtInvalid = new Error("A fila de eventos do CRM retornou um item incompleto."); evtInvalid.code = "CRM_COLUMN_EVENT_QUEUE_INVALID_RESPONSE"; throw evtInvalid; }
          var evtAlreadyProcessed = running.some(function (r) { return r && r.sourceColumnEventId === evt.id; });
          if (evtAlreadyProcessed) { traceColumnEvent({sourceColumnEventId:evt.id,status:"duplicate",ack:true}); acknowledgedColumnEventIds.push(evt.id); continue; }
          var evtChatId = resolveColumnEventChatId(columnEventCrmList, evt);
          if (!evtChatId) { if (window.__extReportRuntimeError) { var unresolved = new Error("O contato associado a uma movimentação do CRM não está mais disponível para automação."); unresolved.code = "FLOW_COLUMN_EVENT_CONTACT_UNRESOLVED"; window.__extReportRuntimeError("FLOW_COLUMN_EVENT_CONTACT_UNRESOLVED", unresolved); } traceColumnEvent({sourceColumnEventId:evt.id,status:"contact_unresolved",ack:true,errorCode:"FLOW_COLUMN_EVENT_CONTACT_UNRESOLVED"}); acknowledgedColumnEventIds.push(evt.id); continue; }
          var evtAlreadyRunning = running.some(function (r) { return r.chatId === evtChatId && r.status === "running"; });
          if (!evtAlreadyRunning) {
            var colFlow = flows.find(function (f) {
              return f.isActive && triggerType(f.trigger) === "columnMoved" &&
                f.trigger.data && f.trigger.data.crmId === evt.crmId && f.trigger.data.columnId === evt.columnId;
            });
            if (colFlow) {
              var colInstance = createRunningInstance(colFlow, evtChatId);
              colInstance.sourceColumnEventId = evt.id;
              traceColumnEvent({sourceColumnEventId:evt.id,executionId:colInstance.id,trigger:"columnMoved",status:"launched",ack:false});
              running.push(colInstance);
              var updatedColInstance = await runInstanceForward(colFlow, colInstance, lease);
              updatedColInstance.sourceColumnEventId = evt.id;
              var colIdx = running.findIndex(function (r) { return r.id === updatedColInstance.id; });
              if (colIdx >= 0) running[colIdx] = updatedColInstance;
              changed = true;
            }
          }
          acknowledgedColumnEventIds.push(evt.id);
        }
      }


      for (var j = 0; j < running.length; j++) {
        if(!lease.isActive())break;var stale = running[j];
        if (stale.status !== "running") continue;
        var touched = stale.lastTouchedAtMs || 0;
        if (now - touched <= STALE_RUNNING_MS) continue;
        stale.status = "finished";
        stale.lastTouchedAtMs = now;
        extTrackFlowInstance(stale);
        changed = true;
      }

      var pruned = running.filter(function (r) {
        if (["finished","expired","error"].indexOf(r.status) < 0) return true;
        return now - (r.lastTouchedAtMs || now) <= PRUNE_AFTER_MS;
      });
      if (pruned.length !== running.length) { running = pruned; changed = true; }
      if (changed) await saveRunning(running);
      if (acknowledgedColumnEventIds.length) { await ackColumnEventQueue(acknowledgedColumnEventIds); acknowledgedColumnEventIds.forEach(function(id){traceColumnEvent({sourceColumnEventId:id,status:"acknowledged",ack:true});}); }
      lease.assertActive();return { changed: changed, acknowledgedColumnEvents: acknowledgedColumnEventIds.length };
      });
    }).catch(function (err) {
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("FLOW_TICK_FAILED",err);
    });
  }, 30000);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
