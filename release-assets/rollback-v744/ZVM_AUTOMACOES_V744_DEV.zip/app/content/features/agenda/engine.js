;
try{


(function () {
  "use strict";
  if (window.__extAgendaEngineBooted) return;
  window.__extAgendaEngineBooted = true;

  var STORE_KEY="EXTUI:extappScheduleStore";
  var locks=new Set();
  var cancelledAgendaIds=new Set();
  var started=false;
  var fallbackTimer=null;

  function storage(){if(!window.ExtensionStorage){var e=new Error("Os dados da extensão não estão disponíveis no momento");e.code="STORAGE_UNAVAILABLE";throw e;}return window.ExtensionStorage;}
  function actionExecutor(){if(!window.__extActionExecutor){var e=new Error("ActionExecutor indisponível");e.code="ACTION_EXECUTOR_UNAVAILABLE";throw e;}return window.__extActionExecutor;}
  function eventBus(){return window.__extEventBus||null;}
  function parse(raw){if(raw==null||raw==="")return {list:[],missedHistory:[],sendAfterWhatsAppOpens:false,schemaVersion:3};var p;try{p=typeof raw==="string"?JSON.parse(raw):raw;}catch(err){err.code=err.code||"AGENDA_STORE_CORRUPT";throw err;}if(!p||typeof p!=="object"||Array.isArray(p)){var invalid=new Error("Os dados da Agenda estão inválidos e não serão sobrescritos.");invalid.code="AGENDA_STORE_CORRUPT";throw invalid;}return p;}
  async function load(){var p=parse(await storage().get(STORE_KEY));p.list=Array.isArray(p.list)?p.list:[];p.missedHistory=Array.isArray(p.missedHistory)?p.missedHistory:[];p.sendAfterWhatsAppOpens=p.sendAfterWhatsAppOpens===true;return p;}
  async function save(store){store.schemaVersion=Math.max(3,Number(store.schemaVersion)||0);store.missedHistory=(Array.isArray(store.missedHistory)?store.missedHistory:[]).slice(-30);await storage().set(STORE_KEY,JSON.stringify(store));}
  function now(){return Date.now();}
  function normTarget(raw){raw=String(raw||"").trim();if(!raw)return "";if(raw.indexOf("@")>=0)return raw;return raw.replace(/\D/g,"")+"@c.us";}
  async function resolveTarget(raw){
    var target=normTarget(raw); if(!target)throw new Error("Destino vazio");
    if(String(raw).indexOf("@")>=0)return target;
    if(!window.__extWppBridge)throw new Error("O WhatsApp ainda não está pronto");
    var exists=await window.__extWppBridge.invoke("Contact","queryExists",target);
    return exists&&exists.lid&&exists.lid._serialized||exists&&exists.wid&&exists.wid._serialized||target;
  }
  function retryPolicy(item){
    var p=item.retryPolicy&&typeof item.retryPolicy==="object"?item.retryPolicy:{};
    var max=Number(p.maxAttempts!=null?p.maxAttempts:item.maxAttempts);
    if(!Number.isFinite(max)||max<1)max=1;
    var delay=Number(p.delayMs!=null?p.delayMs:item.retryDelayMs);
    if(!Number.isFinite(delay)||delay<0)delay=60000;
    var factor=Number(p.backoffFactor);if(!Number.isFinite(factor)||factor<1)factor=1;
    return {maxAttempts:Math.floor(max),delayMs:delay,backoffFactor:factor};
  }
  function due(item,t){
    if(item.status==="scheduled")return Number(item.scheduleAtMs||0)<=t;
    if(item.status==="retrying")return Number(item.nextAttemptAtMs||0)<=t;
    return false;
  }
  function hasRecurrence(item){var r=item&&item.recurrence;if(r&&typeof r==="object"&&r.type&&r.type!=="none")return true;var legacy=item&&item.recorrencia;return item&&item.recorrenciaManual===true||Array.isArray(legacy)&&legacy.length>0||typeof legacy==="string"&&legacy.trim()!=="";}
  function weekdayNumber(v){var x=String(v||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");var map={domingo:0,sunday:0,segunda:1,"segunda-feira":1,monday:1,terca:2,"terca-feira":2,tuesday:2,quarta:3,"quarta-feira":3,wednesday:3,quinta:4,"quinta-feira":4,thursday:4,sexta:5,"sexta-feira":5,friday:5,sabado:6,saturday:6};if(Object.prototype.hasOwnProperty.call(map,x))return map[x];var n=Number(v);return Number.isInteger(n)&&n>=0&&n<=6?n:null;}
  function addDays(ms,n){var d=new Date(ms);d.setDate(d.getDate()+n);return d.getTime();}
  function addMonthsClamped(ms,n){var src=new Date(ms),day=src.getDate(),d=new Date(ms);d.setDate(1);d.setMonth(d.getMonth()+n);var last=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(day,last));return d.getTime();}
  function recurrenceSpec(item){
    var r=item&&item.recurrence&&typeof item.recurrence==="object"?item.recurrence:null;if(r){var type=String(r.type||"none");if(type==="daily")return{kind:"days",interval:Math.max(1,Number(r.interval)||1)};if(type==="weekly")return{kind:"days",interval:7*Math.max(1,Number(r.interval)||1)};if(type==="monthly")return{kind:"months",interval:Math.max(1,Number(r.interval)||1)};if(type==="days"||type==="interval-days")return{kind:"days",interval:Math.max(1,Number(r.intervalDays)||Number(r.days)||Number(r.interval)||1)};if(type==="weekdays"&&Array.isArray(r.days)){var allowed=r.days.map(weekdayNumber).filter(function(x){return x!==null;});return allowed.length?{kind:"weekdays",allowed:allowed}:null;}return null;}
    if(item&&item.recorrenciaManual===true){var raw=Array.isArray(item.recorrencia)?item.recorrencia[0]:item.recorrencia;return{kind:"days",interval:Math.max(1,Number(raw)||1)};}
    var vals=Array.isArray(item&&item.recorrencia)?item.recorrencia:[item&&item.recorrencia],days=vals.map(weekdayNumber).filter(function(x){return x!==null;});if(days.length)return{kind:"weekdays",allowed:days};var tag=String(vals[0]||"").toLowerCase();if(/mens|month/.test(tag))return{kind:"months",interval:1};if(/seman|week/.test(tag))return{kind:"days",interval:7};if(/diar|daily|dia/.test(tag))return{kind:"days",interval:1};return null;
  }
  function nextRecurrenceAt(item,afterMs){
    if(!hasRecurrence(item))return null;var base=Number(item.recurrenceAnchorAtMs)||Number(item.scheduleAtMs)||Date.now(),after=Number(afterMs)||0,spec=recurrenceSpec(item);if(!spec)return null;
    if(spec.kind==="weekdays"){var approx=Math.max(1,Math.floor((after-base)/86400000)-2);for(var dayOffset=approx;dayOffset<approx+32;dayOffset++){var weekdayCandidate=addDays(base,dayOffset);if(weekdayCandidate>after&&spec.allowed.indexOf(new Date(weekdayCandidate).getDay())>=0)return weekdayCandidate;}return null;}
    var occurrence=1;if(after>base){if(spec.kind==="months"){var bd=new Date(base),ad=new Date(after),monthDiff=(ad.getFullYear()-bd.getFullYear())*12+(ad.getMonth()-bd.getMonth());occurrence=Math.max(1,Math.floor(monthDiff/spec.interval)-1);}else occurrence=Math.max(1,Math.floor((after-base)/(spec.interval*86400000))-2);}
    for(var i=0;i<12;i++,occurrence++){var candidate=spec.kind==="months"?addMonthsClamped(base,spec.interval*occurrence):addDays(base,spec.interval*occurrence);if(candidate>after)return candidate;}return null;
  }
  function cloneNextOccurrence(item,t){var anchor=Number(item.recurrenceAnchorAtMs)||Number(item.scheduleAtMs)||Date.now(),source=Object.assign({},item,{recurrenceAnchorAtMs:anchor}),next=nextRecurrenceAt(source,t);if(!next)return null;var clone=Object.assign({},item,{id:"schedule-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8),scheduleAtMs:next,recurrenceAnchorAtMs:anchor,status:"scheduled",createdAt:Date.now(),sentAt:null,cancelledAt:null,errorMessage:null,lastError:null,attempts:0,nextAttemptAtMs:null,recurrenceParentId:item.id,recurrenceNextId:null});delete clone.lastAttemptAt;return clone;}
  async function itemActions(item){
    if(Array.isArray(item.actions)&&item.actions.length)return item.actions;
    if(item.quickResponseId&&window.__extQuickResponseService)return [{type:"respostaRapida",properties:{respostaRapidaID:item.quickResponseId}}];
    if(window.__extQuickResponseService&&item.type&&item.itemId){
      var a=await window.__extQuickResponseService.nativeToActions(item.type,item.itemId);if(a&&a.length)return a;
    }
    return null;
  }
  async function dispatch(item,target,lease){
    if(lease)lease.assertActive();
    if(window.__extPlanGate)await window.__extPlanGate.requireActive();
    var freePlan=window.__extPlanGate&&await window.__extPlanGate.isFree();
    if(freePlan&&(!window.__extPlanGate.itemAllowed(item.type)||(Array.isArray(item.actions)&&item.actions.length)||item.quickResponseId||hasRecurrence(item)||item.crmTaskRef)){await window.__extPlanGate.requirePaid("Automação avançada da Agenda");}
    if(freePlan)await window.__extPlanGate.requireFreeQuota(item.type);
    if(item.type==="funnel"&&!item.actions&&!item.quickResponseId){
      if(typeof window.__extFunnelsStartManually!=="function")throw new Error("O mecanismo de Funis ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");
      return window.__extFunnelsStartManually(item.itemId,target);
    }
    if(item.type==="flow"&&!item.actions&&!item.quickResponseId){
      if(typeof window.__extFluxosStartFlowManually!=="function")throw new Error("O mecanismo de Fluxos ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");
      return window.__extFluxosStartFlowManually(item.itemId,target);
    }
    var actions=await itemActions(item);if(!actions){var e=new Error("Item/ações do agendamento não encontrados");e.code="AGENDA_ACTIONS_NOT_FOUND";throw e;}
    var result=await actionExecutor().execute(actions,{source:"agenda",contactId:target,remetente:target,scheduleId:item.id,executionId:"agenda:"+item.id,variables:item.variables||{},cancellationSignal:lease&&lease.signal||null});
    if(result.status!=="success"){var er=new Error(result.error&&result.error.message||"ActionExecutor falhou");er.code=result.error&&result.error.code||"AGENDA_ACTION_ERROR";er.effectDigest=result.error&&result.error.effectDigest||null;er.remoteEffectSucceeded=result.error&&result.error.remoteEffectSucceeded===true;throw er;}
    return result;
  }
  function emit(name,payload){try{var b=eventBus();if(b)b.emit(name,payload,{source:"agenda"});}catch(_){}}
  async function syncLinkedCrmTask(item, patch) {
    var ref=item&&item.crmTaskRef;if(!ref||!ref.crmContactId||!ref.taskId||!globalThis.chrome||!chrome.runtime||typeof chrome.runtime.sendMessage!=="function")return false;
    try{
      var response=await new Promise(function(resolve,reject){chrome.runtime.sendMessage({__extCrmProfessionalOperation:true,operation:{type:"task.update",crmContactId:String(ref.crmContactId),taskId:String(ref.taskId),patch:patch||{},recordEvent:false}},function(reply){if(chrome.runtime.lastError){var runtimeErr=new Error(chrome.runtime.lastError.message||"Falha ao sincronizar tarefa do CRM");void chrome.runtime.lastError;reject(runtimeErr);return;}resolve(reply);});});
      if(!response||response.ok!==true){var e=new Error(response&&response.error||"Não foi possível sincronizar a tarefa do CRM");e.code=response&&response.errorCode||"AGENDA_CRM_TASK_SYNC_FAILED";throw e;}
      return true;
    }catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("AGENDA_CRM_TASK_SYNC_FAILED",err);return false;}
  }
  async function processItem(item,t,lease){
    var id=String(item.id||"");if(!id||locks.has(id))return false;locks.add(id);
    var activity=typeof window.__extActivityTrack==="function"?"agenda:"+id:null;
    try{
      item.attempts=(Number(item.attempts)||0)+1;item.lastAttemptAt=t;item.status="sending";item.errorMessage=null;
      if(activity)window.__extActivityTrack({action:"start",id:activity,type:"agenda",title:item.itemName||"Agendamento",targetLabel:item.targetChatName||item.targetChatId||"",status:"running",chatId:item.targetChatId||"",executionId:"agenda:"+id});
      if(lease)lease.assertActive();var target=await resolveTarget(item.targetChatId);if(cancelledAgendaIds.has(id))throw Object.assign(new Error("Agendamento cancelado manualmente"),{code:"AGENDA_CANCELLED_MANUAL"});if(lease)lease.assertActive();await dispatch(item,target,lease);if(cancelledAgendaIds.has(id))throw Object.assign(new Error("Agendamento cancelado manualmente"),{code:"AGENDA_CANCELLED_MANUAL"});
      if(window.__extPlanGate&&await window.__extPlanGate.isFree()){try{await window.__extPlanGate.usageCommit(item.type);}catch(_quotaErr){item.quotaSyncPending=true;}}
      item.status="sent";item.sentAt=now();item.nextAttemptAtMs=null;item.lastError=null;
      await syncLinkedCrmTask(item,{status:"completed",actionStatus:"executed",actionExecutedAtMs:item.sentAt});
      if(activity)window.__extActivityTrack({action:"success",id:activity});
      emit("ScheduleSent",{scheduleId:id,targetChatId:item.targetChatId,itemId:item.itemId,type:item.type,attempts:item.attempts});
      if(typeof window.__extFireWebhook==="function")window.__extFireWebhook("agendamento",item.targetChatId,{itemId:item.itemId,itemName:item.itemName,type:item.type,scheduleId:id,attempt:item.attempts});
    }catch(err){
      if(cancelledAgendaIds.has(id)||(err&&err.code==="AGENDA_CANCELLED_MANUAL")){item.status="cancelled";item.cancelledAt=now();item.nextAttemptAtMs=null;item.errorMessage=null;item.lastError=null;if(activity)window.__extActivityTrack({action:"cancel",id:activity});emit("ScheduleCancelled",{scheduleId:id,manual:true});return true;}
      var p=retryPolicy(item);item.lastError=err&&err.message?err.message:String(err);item.errorMessage=item.lastError;item.lastErrorCode=err&&err.code||null;item.lastEffectDigest=err&&err.effectDigest||null;
      var durableTerminal=window.__extSendSafetyManager&&typeof window.__extSendSafetyManager.isDurableTerminalError==="function"&&window.__extSendSafetyManager.isDurableTerminalError(err);
      if(!durableTerminal&&item.attempts<p.maxAttempts){
        item.status="retrying";item.nextAttemptAtMs=now()+Math.round(p.delayMs*Math.pow(p.backoffFactor,Math.max(0,item.attempts-1)));
        emit("ScheduleRetrying",{scheduleId:id,attempt:item.attempts,maxAttempts:p.maxAttempts,nextAttemptAtMs:item.nextAttemptAtMs,error:item.lastError});
      }else{
        item.status="error";item.nextAttemptAtMs=null;await syncLinkedCrmTask(item,{actionStatus:"error"});emit("ScheduleFailed",{scheduleId:id,attempts:item.attempts,error:item.lastError,errorCode:item.lastErrorCode,durableReviewRequired:durableTerminal===true});
      }
      if(activity)window.__extActivityTrack({action:"error",id:activity,errorMessage:item.lastError});
    }finally{locks.delete(id);cancelledAgendaIds.delete(id);}
    return true;
  }
  var tickMutex=Promise.resolve();
  function queueStateMutation(work){var op=tickMutex.then(work,work);tickMutex=op.catch(function(){});return op;}
  function runTick(reason){
    var op=queueStateMutation(async function(){
      if(typeof window.__extWithAutomationLease!=="function"){var coordErr=new Error("Coordenação segura entre abas indisponível.");coordErr.code="AUTOMATION_COORDINATOR_UNAVAILABLE";throw coordErr;}
      return window.__extWithAutomationLease("agenda-tick",async function(lease){
      var store=await load(),t=now(),changed=false,initialLength=store.list.length;lease.assertActive();
      for(var i=0;i<initialLength;i++){if(!lease.isActive())break;var item=store.list[i];if(!due(item,t))continue;
        if(item.status==="scheduled"&&store.sendAfterWhatsAppOpens===true&&t-Number(item.scheduleAtMs||0)>300000){
          item.status="missed";item.missedAt=t;item.errorMessage="Fora da janela de 5 minutos após a abertura do WhatsApp";store.missedHistory.push(Object.assign({},item,{notsend:true}));await syncLinkedCrmTask(item,{actionStatus:"error"});changed=true;emit("ScheduleMissed",{scheduleId:item.id,targetChatId:item.targetChatId,scheduleAtMs:item.scheduleAtMs});
        }else changed=await processItem(item,t,lease)||changed;
        if(!lease.isActive())break;
        if((item.status==="sent"||item.status==="missed")&&hasRecurrence(item)&&!item.recurrenceNextId){var next=cloneNextOccurrence(item,t);if(next){item.recurrenceNextId=next.id;store.list.push(next);changed=true;emit("ScheduleRecurrenceCreated",{scheduleId:item.id,nextScheduleId:next.id,nextAtMs:next.scheduleAtMs});}}
      }
      if(changed)await save(store);
      lease.assertActive();emit("AgendaTickCompleted",{reason:reason||"fallback",changed:changed,at:t});
      });
    });
    return op.catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("AGENDA_TICK_FAILED",err);emit("AgendaTickFailed",{reason:reason||"fallback",error:err&&err.message||String(err)});});
  }
  async function cancel(id){id=String(id||"");if(!id)return false;cancelledAgendaIds.add(id);try{if(window.__extActionExecutor&&typeof window.__extActionExecutor.cancel==="function")window.__extActionExecutor.cancel("agenda:"+id);}catch(_){}var result=await queueStateMutation(async function(){var s=await load(),x=s.list.find(function(i){return i.id===id;});if(!x)return false;if(["sent","cancelled"].indexOf(x.status)>=0)return false;x.status="cancelled";x.cancelledAt=now();x.nextAttemptAtMs=null;x.errorMessage=null;await save(s);if(typeof window.__extActivityTrack==="function")window.__extActivityTrack({action:"cancel",id:"agenda:"+id});emit("ScheduleCancelled",{scheduleId:id,manual:true});return true;});if(!result)cancelledAgendaIds.delete(id);else setTimeout(function(){cancelledAgendaIds.delete(id);},300000);return result;}
  async function retry(id){id=String(id||"");var result=await queueStateMutation(async function(){var s=await load(),x=s.list.find(function(i){return i.id===id;});if(!x)return false;x.status="retrying";x.nextAttemptAtMs=now();x.errorMessage=null;await save(s);emit("ScheduleRetryRequested",{scheduleId:id});return true;});if(result)runTick("manual-retry");return result;}
  function start(){if(started)return;started=true;var b=eventBus();fallbackTimer=setInterval(function(){runTick(b?"120s-fallback":"30s-fallback");},b?120000:30000);if(b)b.on("AgendaTick",function(){runTick("eventbus-1m");});runTick("startup");}
  async function configure(options){return queueStateMutation(async function(){var s=await load();if(options&&Object.prototype.hasOwnProperty.call(options,"sendAfterWhatsAppOpens"))s.sendAfterWhatsAppOpens=options.sendAfterWhatsAppOpens===true;await save(s);return s;});}
  async function schedule(input){input=input&&typeof input==="object"?input:{};if(window.__extPlanGate)await window.__extPlanGate.requireActive();var when=Number(input.scheduleAtMs||input.at||input.triggerAt);if(!Number.isFinite(when)||when<=0)throw Object.assign(new Error("Data/hora do agendamento inválida"),{code:"AGENDA_TIME_INVALID"});var target=String(input.targetChatId||input.chatId||input.contactId||"").trim();if(!target)throw Object.assign(new Error("Destino do agendamento obrigatório"),{code:"AGENDA_TARGET_REQUIRED"});var freePlan=window.__extPlanGate&&await window.__extPlanGate.isFree();if(freePlan&&(!window.__extPlanGate.itemAllowed(input.type)||(Array.isArray(input.actions)&&input.actions.length)||input.quickResponseId||hasRecurrence(input)||input.crmTaskRef))await window.__extPlanGate.requirePaid("Automação avançada da Agenda");return queueStateMutation(async function(){var store=await load();if(freePlan){var activeCount=store.list.filter(function(x){return x&&["scheduled","retrying","sending"].indexOf(x.status)>=0;}).length;await window.__extPlanGate.requireScheduleCapacity(activeCount);}var item=Object.assign({},input,{id:String(input.id||("schedule-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8))),targetChatId:target,scheduleAtMs:when,status:"scheduled",createdAt:Number(input.createdAt)||Date.now(),attempts:0});store.list.push(item);await save(store);if(freePlan){var nextCount=store.list.filter(function(x){return x&&["scheduled","retrying","sending"].indexOf(x.status)>=0;}).length;try{await window.__extPlanGate.usageCommit("scheduleItem",nextCount);}catch(err){store.list=store.list.filter(function(x){return x&&x.id!==item.id;});await save(store);throw err;}}emit("ScheduleCreated",{scheduleId:item.id,targetChatId:target,scheduleAtMs:when});return item;});}
  var api=Object.freeze({version:"3.1.0",storeKey:STORE_KEY,runTick:runTick,cancel:cancel,retry:retry,load:load,configure:configure,schedule:schedule,retryPolicy:retryPolicy,hasRecurrence:hasRecurrence,nextRecurrenceAt:nextRecurrenceAt,start:start});
  window.__extAgendaService=api;window.ExtensionCore=window.ExtensionCore||{};
  setTimeout(start,1200);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
