;
try{


(function () {
  "use strict";

  if (window.__extWebhooksEngineBooted) return;
  window.__extWebhooksEngineBooted = true;

  var STORE_KEY = "EXTUI:extappWebhookStore";
  var MAX_HISTORY = 50;
  var MAX_ATTEMPTS = 5;
  var DEFAULT_ATTEMPTS = 3;
  var DEFAULT_RETRY_DELAY_MS = 1000;
  var EVENT_IDS = [
    "messages", "labels", "newChat", "agendamento", "fluxo",
    "metaAds", "respostaRapida", "crm", "autoAtendimento",
    "followup", "orders", "scheduleFailed", "funnelCompleted"
  ];
  var recent = new Map();

  function callBridge(fields) {
    if (!fields || fields.action !== "webhook") return Promise.reject(new Error("Operação de Webhook inválida."));
    return new Promise(function(resolve,reject){
      try {
        chrome.runtime.sendMessage({type:"EXTUI_WEBHOOK_SEND",eventId:String(fields.eventId||""),payload:fields.payload||{},timeoutMs:fields.timeoutMs},function(response){
          var last=chrome.runtime.lastError;
          if(last){reject(new Error(last.message));return;}
          if(!response||response.ok!==true){reject(new Error(response&&((response.error&&response.error.message)||response.userMessage)||"WEBHOOK_SEND_FAILED"));return;}
          resolve(response.result||{ok:true});
        });
      } catch(err) { reject(err); }
    });
  }
  function get(key) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.get(key);
  }
  function set(key, value) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.set(key, value);
  }
  function sleep(ms) { return new Promise(function (resolve) { setTimeout(resolve, Math.max(0, Number(ms) || 0)); }); }
  function clone(value) { try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; } }
  function parse(raw) {
    if (raw == null || raw === "") return null;
    var parsed = raw;
    if (typeof raw === "string") { try { parsed = JSON.parse(raw); } catch (_) { var malformed = new Error("A configuração dos avisos automáticos está corrompida."); malformed.code="WEBHOOK_STORE_CORRUPT"; throw malformed; } }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state) || !Array.isArray(parsed.state.webhookList)) { var invalid = new Error("A configuração dos avisos automáticos está corrompida."); invalid.code="WEBHOOK_STORE_CORRUPT"; throw invalid; }
    return parsed.state;
  }
  async function loadList() {
    var state = parse(await get(STORE_KEY));
    return state ? state.webhookList : [];
  }
  async function saveList() { throw new Error("WEBHOOK_CONFIG_REQUIRES_DASHBOARD"); }

  var UNSAFE_PATH_KEYS = { "__proto__": true, "prototype": true, "constructor": true };
  function pathParts(path) {
    var parts = String(path || "").split(".").filter(Boolean);
    if (!parts.length || parts.length > 16) return null;
    for (var i = 0; i < parts.length; i++) if (UNSAFE_PATH_KEYS[parts[i]] || !/^[A-Za-z0-9_:@-]{1,120}$/.test(parts[i])) return null;
    return parts;
  }
  function getPath(obj, path) {
    var parts = pathParts(path), cur = obj;
    if (!parts) return undefined;
    parts.forEach(function (key) { cur = cur == null ? undefined : cur[key]; });
    return cur;
  }
  function putPath(obj, path, value) {
    var parts = pathParts(path), cur = obj;
    if (!parts) return;
    for (var i = 0; i < parts.length - 1; i++) {
      var next = cur[parts[i]];
      if (!next || typeof next !== "object" || Array.isArray(next)) next = cur[parts[i]] = Object.create(null);
      cur = next;
    }
    cur[parts[parts.length - 1]] = value;
  }
  function selectedFields(cfg) {
    var raw = Array.isArray(cfg && cfg.param) ? cfg.param : (Array.isArray(cfg && cfg.fields) ? cfg.fields : []);
    return raw.map(function (item) {
      if (typeof item === "string") return item;
      if (!item || typeof item !== "object") return null;
      if (item.active === false || item.enabled === false || item.include === false) return null;
      return item.key || item.id || item.name || item.field || null;
    }).filter(Boolean);
  }
  function applyFilter(payload, cfg) {
    var fields = selectedFields(cfg);
    if (!fields.length) return payload;
    var out = {};
    fields.forEach(function (field) {
      var value = getPath(payload, field);
      if (value === undefined && payload.eventDetails) value = getPath(payload.eventDetails, field);
      if (value !== undefined) putPath(out, field, clone(value));
    });


    out.eventId = payload.eventId;
    out.chatId = payload.chatId;
    out.atMs = payload.atMs;
    return out;
  }

  function attemptsFor(cfg) {
    var n = Number(cfg && (cfg.maxAttempts != null ? cfg.maxAttempts : cfg.retryAttempts));
    if (!isFinite(n) || n < 1) n = DEFAULT_ATTEMPTS;
    return Math.max(1, Math.min(MAX_ATTEMPTS, Math.floor(n)));
  }
  function retryDelayFor(cfg) {
    var n = Number(cfg && cfg.retryDelayMs);
    return isFinite(n) && n >= 0 ? Math.min(n, 60000) : DEFAULT_RETRY_DELAY_MS;
  }
  function shouldRetry(result, err, attempt, maxAttempts) {
    if (attempt >= maxAttempts) return false;
    if (err) return true;
    var status = Number(result && result.status);
    return status === 408 || status === 425 || status === 429 || status >= 500 || !status;
  }

  function dedupeKey(eventId, chatId, details) {
    var corr = details && (details.msgID || details.messageId || details.id || details.executionId || details.scheduleId || details.automationId || details.flowId);
    return eventId + "|" + String(chatId || "") + "|" + String(corr || "");
  }
  function acceptOnce(key) {
    var now = Date.now(), prior = recent.get(key);
    recent.set(key, now);
    recent.forEach(function (ts, k) { if (now - ts > 5000) recent.delete(k); });
    return !prior || now - prior > 1000;
  }

  async function sendConfigured(cfg, payload) {
    var maxAttempts = cfg.retry === false ? 1 : attemptsFor(cfg);
    var baseDelay = retryDelayFor(cfg), last = null, error = null, started = Date.now();
    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      error = null;
      try {
        last = await callBridge({ action: "webhook", eventId: cfg.id, payload: payload, timeoutMs: cfg.timeoutMs || 8000 }, Math.max(12000, Number(cfg.timeoutMs || 8000) + 3000));
      } catch (err) { error = err; last = null; }
      if (!shouldRetry(last, error, attempt, maxAttempts)) {
        return { ok: !!(last && last.ok), status: last && last.status || null, attempts: attempt, durationMs: Date.now() - started, error: error && error.message || (last && last.error) || null };
      }
      await sleep(baseDelay * Math.pow(2, attempt - 1));
    }
    return { ok: false, status: last && last.status || null, attempts: maxAttempts, durationMs: Date.now() - started, error: error && error.message || "webhook failed" };
  }

  async function appendHistory() { return true; }

  async function fire(eventId, chatId, eventDetails, meta) {
    if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return {status:"ignored",reason:"plan_restricted"};
    eventId = String(eventId || "");
    if (!eventId) return { status: "ignored", reason: "event_missing" };
    var key = dedupeKey(eventId, chatId, eventDetails || {});
    if (!acceptOnce(key)) return { status: "ignored", reason: "duplicate" };
    try {
      var list = await loadList();
      var cfg = list.find(function (item) { return item.id === eventId; });
      if (!cfg || !cfg.active || !cfg.url) return { status: "ignored", reason: "not_configured" };
      var fullPayload = {
        eventId: eventId,
        chatId: String(chatId || "").replace(/@c\.us|@lid|@g\.us/g, ""),
        eventDetails: clone(eventDetails || {}),
        atMs: Date.now()
      };
      if (meta && meta.correlationId) fullPayload.correlationId = meta.correlationId;
      var payload = applyFilter(fullPayload, cfg);
      var result = await sendConfigured(cfg, payload);
      var history = {
        id: (typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : "wh-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7)),
        atMs: Date.now(),
        chatId: fullPayload.chatId,
        status: !!result.ok,
        code: result.status,
        attempts: result.attempts,
        durationMs: result.durationMs
      };
      if (result.error) history.errorMessage = result.error;
      await appendHistory(eventId, history);
      return { status: result.ok ? "success" : "error", eventId: eventId, result: result };
    } catch (err) {
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("WEBHOOK_RUNTIME_FAILED",err);
      return { status: "error", eventId: eventId, error: err && err.message || String(err) };
    }
  }

  function jidFrom(value) {
    var data = value && value.data || value || {};
    var id = data.chatId || data.jid || data.contactId || data.phoneNumber || data.from || data.author || data.id;
    if (id && typeof id === "object") id = id._serialized || id.user || id.id;
    return id || "";
  }
  function bindEventBus() {
    var bus = window.__extEventBus || window.__extDomainEventBus;
    if (!bus || typeof bus.on !== "function" || bindEventBus.bound) return false;
    bindEventBus.bound = true;


    bus.on("LabelChanged", function (p, env) { fire("labels", jidFrom(p), p || {}, env); });
    bus.on("ScheduleSent", function (p, env) { fire("agendamento", jidFrom(p), p || {}, env); });
    bus.on("AutoServiceTriggered", function (p, env) { fire("autoAtendimento", jidFrom(p), p || {}, env); });
    bus.on("CrmContactMoved", function (p, env) { fire("crm", jidFrom(p), p || {}, env); });
    bus.on("QuickReplySent", function (p, env) { fire("respostaRapida", jidFrom(p), p || {}, env); });
    bus.on("FollowUpSent", function (p, env) { fire("followup", jidFrom(p), Object.assign({status:"sent"},p||{}), env); });
    bus.on("FollowUpFailed", function (p, env) { fire("followup", jidFrom(p), Object.assign({status:"error"},p||{}), env); });
    bus.on("OrderCreated", function (p, env) { fire("orders", jidFrom(p), Object.assign({action:"created"},p||{}), env); });
    bus.on("OrderUpdated", function (p, env) { fire("orders", jidFrom(p), Object.assign({action:"updated"},p||{}), env); });
    bus.on("OrderTrackingSent", function (p, env) { fire("orders", jidFrom(p), Object.assign({action:"tracking_sent"},p||{}), env); });
    bus.on("ScheduleFailed", function (p, env) { fire("scheduleFailed", jidFrom(p), p||{}, env); });
    bus.on("FunnelCompleted", function (p, env) { fire("funnelCompleted", jidFrom(p), p||{}, env); });
    bus.on("MessageReceived", function (p, env) {
      var data=p&&p.data||p||{}, context=data.ctwaContext||data.referral||data.contextInfo&&data.contextInfo.externalAdReply||data.externalAdReply;
      if(context) fire("metaAds", jidFrom(data), {ctwaContext:clone(context),messageId:data.id&&data.id._serialized||data.id||null,body:data.body||data.caption||""}, env);
    });
    return true;
  }

  var api = Object.freeze({
    version: "1.0.0",
    eventIds: EVENT_IDS.slice(),
    fire: fire,
    load: loadList,
    save: saveList,
    applyFilter: applyFilter,
    bindEventBus: bindEventBus,
    constants: { maxHistory: MAX_HISTORY, maxAttempts: MAX_ATTEMPTS }
  });
  window.__extFireWebhook = fire;
  window.__extWebhookService = api;
  window.ExtensionCore = window.ExtensionCore || {};
  

  if (!bindEventBus()) window.addEventListener("ext:eventbus-ready", function () { bindEventBus(); }, { once:true });
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
