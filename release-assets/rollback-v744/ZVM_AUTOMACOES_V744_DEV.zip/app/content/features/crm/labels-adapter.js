try{


(function(){
  "use strict";
  if(window.__extCrmLabelServiceBooted)return;window.__extCrmLabelServiceBooted=true;
  async function paid(feature){if(window.__extPlanGate)await window.__extPlanGate.requirePaid(feature||"CRM e Etiquetas");return true;}
  var CRM_KEY="EXTUI:CrmStore";
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function crmStoreError(cause){var e=new Error("Os dados do CRM estão corrompidos. O último estado válido foi preservado e nenhuma alteração foi gravada.");e.code="CRM_STORE_CORRUPT";if(cause)e.cause=cause;return e;}function parse(raw){if(raw==null||raw==="")return {state:{crmList:[],selectedCrmId:""},version:0};var p=raw;if(typeof raw==="string"){try{p=JSON.parse(raw);}catch(err){throw crmStoreError(err);}}if(!p||typeof p!=="object"||Array.isArray(p))throw crmStoreError();var state=p.state;if(!state||typeof state!=="object"||Array.isArray(state))throw crmStoreError();if(state.crmList!==undefined&&!Array.isArray(state.crmList))throw crmStoreError();return p;}
  function normalizePhone(v){return String(v||"").replace(/@.*/,"").replace(/\D/g,"");}
  function uid(){return globalThis.crypto&&crypto.randomUUID?crypto.randomUUID():("crm-"+Date.now()+"-"+Math.random().toString(36).slice(2,9));}
  function emit(name,payload){try{if(window.__extEventBus)window.__extEventBus.emit(name,payload,{source:"crm-label-service"});}catch(_){}}
  async function loadCrm(){await paid("CRM");var p=parse(await repo().get(CRM_KEY));p.state.crmList=Array.isArray(p.state.crmList)?p.state.crmList:[];p.state.selectedCrmId=String(p.state.selectedCrmId||"");return p;}
  async function saveCrm(p){p.version=typeof p.version==="number"?p.version:0;p.state.revision=Math.max(0,Number(p.state.revision)||0)+1;delete p.state.dummyTrigger;await repo().set(CRM_KEY,JSON.stringify(p));return p;}
  function findTarget(state,p){
    p=p||{};var crmId=String(p.crmID||p.crmId||"");var colId=String(p.abaID||p.columnId||p.stageId||"");var crms=state.crmList||[];
    var crm=null,col=null;
    if(crmId&&crmId!=="abas")crm=crms.find(function(x){return String(x.id)===crmId;})||null;
    if(crm){col=(crm.columns||[]).find(function(x){return String(x.id)===colId;})||null;}
    if(!col&&colId){for(var i=0;i<crms.length&&!col;i++){var c=(crms[i].columns||[]).find(function(x){return String(x.id)===colId;});if(c){crm=crms[i];col=c;}}}
    if(!crm&&state.selectedCrmId)crm=crms.find(function(x){return String(x.id)===state.selectedCrmId;})||null;
    if(crm&&!col&&colId)col=(crm.columns||[]).find(function(x){return String(x.id)===colId;})||null;
    if(crm&&!col&&!colId)col=(crm.columns||[])[0]||null;
    return crm&&col?{crm:crm,column:col}:null;
  }
  function membershipsByPhone(state,phone){var out=[];(state.crmList||[]).forEach(function(crm){(crm.columns||[]).forEach(function(col){(col.items||[]).forEach(function(item,index){var p=normalizePhone(item&&item.contact&&(item.contact.phoneNumber||item.contact.chatId)||"");if(phone&&p===phone)out.push({crm:crm,column:col,item:item,index:index});});});});return out;}
  async function resolvePhoneNumber(contactId){var raw=String(contactId||"");if(/@(g\.us|broadcast|newsletter)$/i.test(raw))return "";if(/@lid$/i.test(raw)){if(!window.__extWppBridge)return "";try{var entry=await window.__extWppBridge.invoke("Contact","getPnLidEntry",raw);var pn=entry&&entry.phoneNumber;var resolved=pn&&(pn._serialized||pn.id||pn.user)||"";return normalizePhone(resolved);}catch(_){return "";}}return normalizePhone(raw);}
  async function resolveContact(contactId,phone){var name=phone;if(window.__extWppBridge){try{var c=await window.__extWppBridge.invoke("Utils","get-card",contactId);if(c)name=c.name||c.pushname||c.verifiedName||name;}catch(_){try{var cc=await window.__extWppBridge.invoke("Contact","get",contactId);if(cc)name=cc.name||cc.pushname||cc.verifiedName||name;}catch(__){}}}return {phoneNumber:phone,name:name||phone,chatId:String(contactId||"")};}
  function unresolvedPhoneError(){var e=new Error("Não foi possível identificar o telefone deste contato no WhatsApp");e.code="CRM_CONTACT_PHONE_UNRESOLVED";return e;}
  async function add(contactId,p,ctx){await paid("CRM");
    var store=await loadCrm(),target=findTarget(store.state,p);if(!target){var e=new Error("CRM/aba de destino não encontrada");e.code="CRM_TARGET_NOT_FOUND";throw e;}
    var phone=await resolvePhoneNumber(contactId);if(!phone)throw unresolvedPhoneError();
    var ms=membershipsByPhone(store.state,phone),same=ms.find(function(m){return m.crm===target.crm&&m.column===target.column;});if(same)return {changed:false,state:"already_present",crmId:target.crm.id,columnId:target.column.id,crmContactId:same.item.id};
    var moving=ms.find(function(m){return m.crm===target.crm;});var item;
    if(moving){moving.column.items.splice(moving.index,1);item=moving.item;}
    else{var contact=await resolveContact(contactId,phone);item={id:uid(),contact:{name:contact.name,phoneNumber:contact.phoneNumber,chatId:contact.chatId},createdBy:"automation",createdAtInMs:Date.now()};}
    target.column.items=Array.isArray(target.column.items)?target.column.items:[];target.column.items.push(item);await saveCrm(store);
    emit("CrmContactMoved",{crmId:target.crm.id,columnId:target.column.id,crmContactId:item.id,phoneNumber:item.contact&&item.contact.phoneNumber,source:ctx&&ctx.source||"action-engine"});
    return {changed:true,crmId:target.crm.id,columnId:target.column.id,crmContactId:item.id};
  }
  async function remove(contactId,p,ctx){await paid("CRM");var store=await loadCrm(),target=findTarget(store.state,p),changed=false,removed=[],phone=await resolvePhoneNumber(contactId);if(!phone)throw unresolvedPhoneError();if(target){target.column.items=(target.column.items||[]).filter(function(item){var match=normalizePhone(item&&item.contact&&item.contact.phoneNumber)===phone;if(match){changed=true;removed.push(item.id);}return !match;});}else{var crmId=String(p&&(p.crmID||p.crmId)||""),colId=String(p&&(p.abaID||p.columnId)||"");(store.state.crmList||[]).forEach(function(crm){if(crmId&&crmId!=="abas"&&String(crm.id)!==crmId)return;(crm.columns||[]).forEach(function(col){if(colId&&String(col.id)!==colId)return;col.items=(col.items||[]).filter(function(item){var match=normalizePhone(item&&item.contact&&item.contact.phoneNumber)===phone;if(match){changed=true;removed.push(item.id);}return !match;});});});}if(changed){await saveCrm(store);emit("CrmContactRemoved",{contactId:contactId,removedIds:removed,source:ctx&&ctx.source||"action-engine"});}return {changed:changed,removedIds:removed};}
  async function removeAll(contactId,p,ctx){await paid("CRM");var store=await loadCrm(),phone=await resolvePhoneNumber(contactId),removed=[];if(!phone)throw unresolvedPhoneError();(store.state.crmList||[]).forEach(function(crm){(crm.columns||[]).forEach(function(col){col.items=(col.items||[]).filter(function(item){var match=normalizePhone(item&&item.contact&&item.contact.phoneNumber)===phone;if(match)removed.push({crmId:crm.id,columnId:col.id,crmContactId:item.id});return !match;});});});if(removed.length){await saveCrm(store);emit("CrmContactRemovedAll",{contactId:contactId,removed:removed,source:ctx&&ctx.source||"action-engine"});}return {changed:!!removed.length,removed:removed};}
  async function listMemberships(contactId){await paid("CRM");var store=await loadCrm(),phone=await resolvePhoneNumber(contactId);if(!phone)return [];return membershipsByPhone(store.state,phone).map(function(m){return {crmId:m.crm.id,columnId:m.column.id,crmContactId:m.item.id,contact:m.item.contact};});}

  async function chatLabelIds(contactId){await paid("Etiquetas avançadas");var chat=null;try{chat=await window.__extWppBridge.invoke("Chat","get",contactId);}catch(_){}var raw=chat&&(chat.labels||chat.labelIds||chat.__x_labels)||[];if(raw&&raw._models)raw=raw._models;return (Array.isArray(raw)?raw:[]).map(function(x){return String(x&&(x.id&&x.id._serialized||x.id||x.labelId)||x);}).filter(Boolean);}
  async function changeLabel(contactId,labelId,type){await paid("Etiquetas avançadas");if(!labelId){var e=new Error("Não foi possível identificar a etiqueta");e.code="LABEL_ID_REQUIRED";throw e;}var payload=[{labelId:String(labelId),type:type}];var result=await window.__extWppBridge.invoke("Labels","addOrRemoveLabels",{id:contactId,label:payload});emit("LabelActionApplied",{contactId:contactId,labelId:String(labelId),type:type});return result;}
  async function addLabel(contactId,labelId){return changeLabel(contactId,labelId,"add");}
  async function removeLabel(contactId,labelId){return changeLabel(contactId,labelId,"remove");}
  async function removeAllLabels(contactId){var ids=await chatLabelIds(contactId);if(!ids.length)return {changed:false,removed:[]};await window.__extWppBridge.invoke("Labels","addOrRemoveLabels",{id:contactId,label:ids.map(function(id){return {labelId:id,type:"remove"};})});emit("LabelActionApplied",{contactId:contactId,type:"removeAll",labelIds:ids});return {changed:true,removed:ids};}
  async function getAllLabels(){await paid("Etiquetas avançadas");return window.__extWppBridge.invoke("Labels","getAllLabels",null);}

  var api=Object.freeze({version:"1.0.0",crm:{add:add,remove:remove,removeAll:removeAll,listMemberships:listMemberships,load:loadCrm},labels:{add:addLabel,remove:removeLabel,removeAll:removeAllLabels,getAll:getAllLabels,getChatLabelIds:chatLabelIds}});
  window.__extCrmLabelService=api;window.ExtensionCore=window.ExtensionCore||{};
  function register(){if(!window.__extActionExecutor)return false;window.__extActionExecutor.registerAdapter("CrmActionAdapter",{add:add,remove:remove,removeAll:removeAll});window.__extActionExecutor.registerAdapter("LabelActionAdapter",{add:addLabel,remove:removeLabel,removeAll:removeAllLabels});return true;}if(!register())window.addEventListener("ext:action-executor-ready",function(){register();},{once:true});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
