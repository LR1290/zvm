;
try{
(function () {
  "use strict";


  if (window.__extDisparosPanelBooted) return;
  window.__extDisparosPanelBooted = true;


  function toast(message, isError) { return window.__extNotify(message, !!isError); }
  function reportRuntime(code, err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError(code, err); }


  function escHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }


  function extStorageGet(key) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.get(key);
  }
  function extStorageSet(key, value) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.set(key, value);
  }

var PANEL_ID = "ext-broadcast-panel-root";
  var state = {
    selectedType: "message",
    selectedItemId: null,
    phoneNumbers: [],
    minDelay: 1,
    maxDelay: 30,
    invalidIgnored: 0,
    manualDuplicates: 0,
    labelDuplicates: 0
  };

  function hardenLegacyLabels(container) {
    container.querySelectorAll("label").forEach(function (l) {
      l.style.display = "block";
      l.style.fontSize = "var(--extui-text-label-size, 13px)";
      l.style.fontWeight = "700";
      l.style.color = "var(--extui-primary-bright, #00e676)";
      l.style.margin = "16px 0 8px";
      l.style.letterSpacing = "0.05em";
      l.style.textTransform = "uppercase";
    });
  }

  function buildPanel() {
    var existing = document.getElementById(PANEL_ID);
    if (existing) return existing;


    var root = window.__extBuildPanelShell({
      id: PANEL_ID,
      title: "Disparo em massa",
      eyebrow: "COMUNICAÇÃO",
      hint: "Envie itens para vários contatos com intervalo.",
      accent: "#a855f7",
      icon: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
      size: "lg"
    });
    root.classList.add("extuiDisparosPanel");
    root.querySelector("[data-extui-panel-body]").innerHTML = '<div class="extuiDisparosBody"><div id="extuiDisparosStep"></div></div>';


    root.querySelector("[data-close]").addEventListener("click", closePanel);

    return root;
  }

  function openPanel() {
    var root = buildPanel();
    if (window.__extWorkspace) window.__extWorkspace.open(root);
    else { root.hidden = false; root.setAttribute("aria-hidden", "false"); root.classList.add("extuiOpen"); }


    var step = root.querySelector("#extuiDisparosStep");
    if (step && step.querySelector("#extuiDisparosProgressSummary")) renderStatusStep(step);
    else if (step && !step.firstElementChild) renderConfigStep(step);
    else loadItemOptions(state.selectedType);
  }

  function closePanel() {
    var root = document.getElementById(PANEL_ID);
    if (root && window.__extWorkspace && window.__extWorkspace.activePanel === root) window.__extWorkspace.close();
    else if (root) { root.classList.remove("extuiOpen"); root.hidden = true; root.setAttribute("aria-hidden", "true"); }


    if (window.__extSyncNavActive) window.__extSyncNavActive();
  }

  function togglePanel() {
    var root = document.getElementById(PANEL_ID);
    var isOpen = root && root.classList.contains("extuiOpen");
    if (isOpen) closePanel();
    else openPanel();
  }


  var pickerOutsidePointerBound = false;
  function handlePickerOutsidePointer(ev) {
    var target = ev.target;
    document.querySelectorAll(".extuiItemPickerDropdown.extuiOpen").forEach(function (dropdown) {
      var picker = dropdown.closest(".extuiItemPicker");
      if (picker && target.closest && target.closest("#" + picker.id)) return;
      dropdown.classList.remove("extuiOpen");
    });
  }
  function bindPickerOutsidePointer() {
    if (pickerOutsidePointerBound) return;
    pickerOutsidePointerBound = true;
    document.addEventListener("mousedown", handlePickerOutsidePointer);
  }
  function unbindPickerOutsidePointer() {
    if (!pickerOutsidePointerBound) return;
    pickerOutsidePointerBound = false;
    document.removeEventListener("mousedown", handlePickerOutsidePointer);
  }


  function extTypeIconChip(accent, svgInner) {
    return '<span class="extTypeIconChip" style="--c:' + accent + ';">' +
      '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + svgInner + '</svg>' +
      '</span>';
  }
  var TYPE_ICONS = [
    { type: "message", icon: extTypeIconChip("#a855f7", '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>'), title: "Mensagem" },
    { type: "audio", icon: extTypeIconChip("#14b8a6", '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2"/><path d="M12 19v3"/>'), title: "Áudio" },
    { type: "image", icon: extTypeIconChip("#84cc16", '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="m21 16-4.5-4.5a2 2 0 0 0-2.8 0L5 20"/>'), title: "Imagem" },
    { type: "video", icon: extTypeIconChip("#3b82f6", '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-2v8l-4-2z"/>'), title: "Vídeo" },
    { type: "sticker", icon: extTypeIconChip("#f59e0b", '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>'), title: "Figurinha" },
    { type: "document", icon: extTypeIconChip("#f59e0b", '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>'), title: "Documento" },
    { type: "flow", icon: extTypeIconChip("#fb923c", '<circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M9 6h5a4 4 0 0 1 4 4v6"/>'), title: "Fluxo" },
    { type: "funnel", icon: extTypeIconChip("#f43f5e", '<path d="M22 3H2l8 9.46V19l4 2v-8.54z"/>'), title: "Funil" }
  ];


  var broadcastRuntime = { loadedItemList: [] };
  var QUICK_ITEMS_RECENTS_KEY = "EXTUI:quickItemsRecents";
  async function rankLoadedItems(type, items) {
    var recents = [];
    try { recents = await extStorageGet(QUICK_ITEMS_RECENTS_KEY); } catch (err) { recents = []; }
    var recentRank = {};
    (Array.isArray(recents) ? recents : []).forEach(function (recent, index) { if (recent && recent.type === type) recentRank[recent.id] = index; });
    return items.map(function (item, index) {
      item.quickTier = item.favorite ? "Favoritos" : Object.prototype.hasOwnProperty.call(recentRank, item.id) ? "Recentes" : "Todos";
      item.recentRank = Object.prototype.hasOwnProperty.call(recentRank, item.id) ? recentRank[item.id] : Infinity;
      item.originalIndex = index;
      return item;
    }).sort(function (a, b) {
      var tierRank = { Favoritos: 0, Recentes: 1, Todos: 2 };
      if (tierRank[a.quickTier] !== tierRank[b.quickTier]) return tierRank[a.quickTier] - tierRank[b.quickTier];
      if (a.recentRank !== b.recentRank) return a.recentRank - b.recentRank;
      return a.originalIndex - b.originalIndex;
    });
  }
  function renderItemListRows(filterText) {
    var listEl = document.getElementById("extuiDisparosItemList");
    if (!listEl) return;
    var filter = (filterText || "").toLowerCase();
    var items = broadcastRuntime.loadedItemList.filter(function (it) {
      return !filter || (it.displayName || "").toLowerCase().indexOf(filter) !== -1;
    });
    if (items.length === 0) {
      listEl.innerHTML = '<div class="extuiItemPickerEmpty">Nenhum item encontrado</div>';
      return;
    }
    var lastTier = null;
    listEl.innerHTML = items.map(function (it) {
      var selected = state.selectedItemId === it.id ? " extuiSelected" : "";
      var group = it.quickTier !== lastTier ? '<div class="extuiItemPickerGroup">' + escHtml(it.quickTier) + '</div>' : '';
      lastTier = it.quickTier;
      return group + '<div class="extuiItemPickerRow' + selected + '" role="option" aria-selected="' + (selected ? 'true' : 'false') + '" tabindex="-1" data-id="' + escHtml(it.id) + '">' + escHtml(it.displayName) + '</div>';
    }).join("");
  }

  function renderConfigStep(stepEl) {
    var minMinutes = Math.floor((state.minDelay || 0) / 60), minSeconds = (state.minDelay || 0) % 60;
    var maxMinutes = Math.floor((state.maxDelay || 0) / 60), maxSeconds = (state.maxDelay || 0) % 60;


    if (!state.contactEntries) {
      state.contactEntries = (state.phoneNumbers || []).map(function (v) { return { value: v, label: v }; });
    }
    var contactsCount = state.contactEntries.length;

    stepEl.innerHTML = [
      '<section class="extuiDisparosBlock extuiDisparosBlock--content">',
      '  <div class="extuiDisparosBlockHead"><div><strong>Conteúdo</strong><span>Escolha o que será enviado e o item salvo.</span></div><span class="extuiDisparosStepBadge">1</span></div>',
      '  <span class="extuiDisparosFieldLabel" id="extuiDisparosTypeLabel">Tipo de conteúdo</span>',
      '  <div class="extuiTypeRow" id="extuiDisparosTypeRow" role="group" aria-labelledby="extuiDisparosTypeLabel">',
      TYPE_ICONS.map(function (t) {
        return '<button type="button" class="extuiTypeBtn" data-type="' + t.type + '" title="' + t.title + '" aria-pressed="false"><span class="extuiTypeCard"><span class="extTypeIconChip">' + t.icon + '</span><span class="extuiTypeLabel">' + escHtml(t.title) + '</span></span></button>';
      }).join("\n"),
      '  </div>',
      '  <span class="extuiDisparosFieldLabel" id="extuiDisparosItemLabel">Item salvo</span>',
      '  <div class="extuiItemPicker" id="extuiDisparosItemPicker">',
      '    <div class="extuiItemPickerBox" id="extuiDisparosItemBox" tabindex="0" role="combobox" aria-labelledby="extuiDisparosItemLabel extuiDisparosItemText" aria-haspopup="listbox" aria-expanded="false" aria-controls="extuiDisparosItemList">',
      '      <span class="extuiItemPickerText" id="extuiDisparosItemText">Selecione um item</span>',
      '      <span class="extuiItemPickerChevron">&#9662;</span>',
      '    </div>',
      '    <div class="extuiItemPickerDropdown" id="extuiDisparosItemDropdown">',
      '      <input type="text" class="extuiItemPickerSearch" id="extuiDisparosItemSearch" placeholder="Pesquisar item" aria-label="Pesquisar item salvo" aria-controls="extuiDisparosItemList">',
      '      <div class="extuiItemPickerList" id="extuiDisparosItemList" role="listbox" aria-label="Itens salvos"></div>',
      '    </div>',
      '  </div>',
      '  <p class="extuiDisparosError" id="extuiDisparosItemError"></p>',
      '</section>',
      '<section class="extuiDisparosBlock extuiDisparosBlock--recipients">',
      '  <div class="extuiDisparosBlockHead"><div><strong>Destinatários</strong><span>Monte a lista por etiquetas, busca ou números manuais.</span></div><span class="extuiDisparosStepBadge">2</span></div>',
      '  <span class="extuiDisparosFieldLabel" id="extuiDisparosLabelsLabel">Etiquetas do WhatsApp</span>',
      '  <div class="extuiItemPicker" id="extuiDisparosLabelsPicker">',
      '    <div class="extuiItemPickerBox" id="extuiDisparosLabelsBox" tabindex="0" role="button" aria-labelledby="extuiDisparosLabelsLabel extuiDisparosLabelsText" aria-haspopup="listbox" aria-expanded="false" aria-controls="extuiDisparosLabelsList">',
      '      <span class="extuiItemPickerText" id="extuiDisparosLabelsText">Selecionar etiquetas</span>',
      '      <span class="extuiItemPickerChevron">&#9662;</span>',
      '    </div>',
      '    <div class="extuiItemPickerDropdown" id="extuiDisparosLabelsDropdown">',
      '      <div class="extuiItemPickerList" id="extuiDisparosLabelsList" role="listbox" aria-multiselectable="true" aria-label="Etiquetas do WhatsApp"></div>',
      '    </div>',
      '  </div>',
      '  <label for="extuiDisparosContactSearch">Buscar contato pelo nome</label>',
      '  <div class="extuiItemPicker" id="extuiDisparosContactSearchPicker">',
      '    <input type="text" class="extuiItemPickerSearch" id="extuiDisparosContactSearch" placeholder="Digite um nome..." role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="extuiDisparosContactSuggestList">',
      '    <div class="extuiItemPickerDropdown" id="extuiDisparosContactSuggestDropdown">',
      '      <div class="extuiItemPickerList" id="extuiDisparosContactSuggestList" role="listbox" aria-label="Sugestões de contatos"></div>',
      '    </div>',
      '  </div>',
      '  <div class="extuiDisparosRecipientCount"><span id="extuiDisparosContactsLabel">Números para o disparo (' + contactsCount + '):</span></div>',
      '  <div class="extuiChipsBox" id="extuiDisparosContactsChips"></div>',
      '  <input type="text" id="extuiDisparosContactsManualInput" inputmode="numeric" placeholder="Digite um número e pressione Enter" aria-labelledby="extuiDisparosContactsLabel" aria-describedby="extuiDisparosContactsHint">',
      '  <p class="extuiDisparosHint" id="extuiDisparosContactsHint">DDD + número, sem espaços, traços ou +55.</p>',
      '  <p class="extuiDisparosError" id="extuiDisparosContactsError"></p>',
      '</section>',
      '<section class="extuiDisparosBlock extuiDisparosBlock--import">',
      '  <div class="extuiDisparosBlockHead"><div><strong>Planilha</strong><span>Importe CSV/XLSX ou use o modelo pronto.</span></div><span class="extuiDisparosStepBadge">3</span></div>',
      '  <div class="extuiSpreadsheetImportRow"><input type="file" id="extuiDisparosSpreadsheetInput" accept=".xlsx,.csv" aria-label="Importar planilha XLSX ou CSV"><button type="button" class="secondary" id="extuiDisparosSpreadsheetTemplate">Modelo CSV</button></div>',
      '  <div class="extuiSpreadsheetOptions">',
      '    <label><input type="checkbox" id="extuiDisparosSheetHasDdi"> Planilha já contém DDI</label>',
      '    <label><input type="checkbox" id="extuiDisparosSheetNinthDigit"> Ajustar 9º dígito BR</label>',
      '    <label><input type="checkbox" id="extuiDisparosSheetValidate"> Validar números no WhatsApp</label>',
      '  </div>',
      '</section>',
      '<section class="extuiDisparosBlock extuiDisparosBlock--timing">',
      '  <div class="extuiDisparosBlockHead"><div><strong>Intervalo entre envios</strong><span>Use uma variação realista para reduzir comportamento repetitivo.</span></div><span class="extuiDisparosStepBadge">4</span></div>',
      '  <div class="extuiDisparosDelayGrid">',
      '    <div class="extuiDisparosDelayGroup"><span class="extuiDisparosFieldLabel">Mínimo</span><div class="delayPairRow"><div class="delayPairField"><input type="number" id="extuiDisparosMinDelayMin" min="0" value="' + minMinutes + '" aria-label="Intervalo mínimo em minutos"><span>min</span></div><div class="delayPairField"><input type="number" id="extuiDisparosMinDelaySec" min="0" max="59" value="' + minSeconds + '" aria-label="Intervalo mínimo em segundos"><span>seg</span></div></div></div>',
      '    <div class="extuiDisparosDelayGroup"><span class="extuiDisparosFieldLabel">Máximo</span><div class="delayPairRow"><div class="delayPairField"><input type="number" id="extuiDisparosMaxDelayMin" min="0" value="' + maxMinutes + '" aria-label="Intervalo máximo em minutos"><span>min</span></div><div class="delayPairField"><input type="number" id="extuiDisparosMaxDelaySec" min="0" max="59" value="' + maxSeconds + '" aria-label="Intervalo máximo em segundos"><span>seg</span></div></div></div>',
      '  </div>',
      '  <p class="extuiDisparosError" id="extuiDisparosDelayError"></p>',
      '  <div class="extuiInfoBox" id="extuiDisparosInfoBox">',
      '    <button type="button" class="extuiInfoBoxHeader" id="extuiDisparosInfoBoxHeader" aria-expanded="false" aria-controls="extuiDisparosInfoBoxBody"><span class="extuiInfoIcon">&#8505;</span><span>Boas práticas de envio</span><span class="extuiInfoChevron">&#9662;</span></button>',
      '    <div class="extuiInfoBoxBody" id="extuiDisparosInfoBoxBody">Envios em massa têm risco de bloqueio da conta. Use intervalos realistas e evite listas muito grandes.</div>',
      '  </div>',
      '</section>',
      '<div class="extuiDisparosActionBar"><div><strong>Preparação do disparo</strong><span>Revise os dados antes de avançar para a confirmação.</span></div><button class="primary" id="extuiDisparosNextBtn">Continuar</button></div>'
    ].join("\n");
    hardenLegacyLabels(stepEl);


    var typeRow = stepEl.querySelector("#extuiDisparosTypeRow");
    function setActiveTypeBtn(type) {
      typeRow.querySelectorAll(".extuiTypeBtn").forEach(function (btn) {
        var active=btn.getAttribute("data-type") === type;
        btn.classList.toggle("extuiActive", active);
        btn.setAttribute("aria-pressed",String(active));
      });
    }
    setActiveTypeBtn(state.selectedType);
    typeRow.addEventListener("click", function (ev) {
      var btn = ev.target.closest(".extuiTypeBtn");
      if (!btn) return;
      var type = btn.getAttribute("data-type");
      state.selectedType = type;
      setActiveTypeBtn(type);
      loadItemOptions(type);
      extStorageSet("EXTUI:disparosLastType", type).catch(function (err) {
      });
    });


    (async function () {
      try {
        var savedType = await extStorageGet("EXTUI:disparosLastType");
        if (savedType && ITEM_STORAGE_BY_TYPE.hasOwnProperty(savedType)) {
          state.selectedType = savedType;
          setActiveTypeBtn(savedType);
        }
      } catch (err) {
      }
      loadItemOptions(state.selectedType);
    })();


    var itemBox = stepEl.querySelector("#extuiDisparosItemBox");
    var itemDropdown = stepEl.querySelector("#extuiDisparosItemDropdown");
    var itemSearch = stepEl.querySelector("#extuiDisparosItemSearch");
    var itemList = stepEl.querySelector("#extuiDisparosItemList");
    var itemText = stepEl.querySelector("#extuiDisparosItemText");
    var itemError = stepEl.querySelector("#extuiDisparosItemError");
    var nextBtn = stepEl.querySelector("#extuiDisparosNextBtn");
    function updateNextBtnState() {
      nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
    }
    updateNextBtnState();

    function setItemPickerOpen(open){itemDropdown.classList.toggle("extuiOpen",!!open);itemBox.setAttribute("aria-expanded",String(!!open));if(open)itemSearch.focus();}
    itemBox.addEventListener("click", function (ev) {ev.stopPropagation();setItemPickerOpen(!itemDropdown.classList.contains("extuiOpen"));});
    itemBox.addEventListener("keydown",function(ev){if(ev.key==="Enter"||ev.key===" "){ev.preventDefault();setItemPickerOpen(!itemDropdown.classList.contains("extuiOpen"));}else if(ev.key==="Escape"){setItemPickerOpen(false);}});
    itemSearch.addEventListener("click", function (ev) { ev.stopPropagation(); });
    itemSearch.addEventListener("input", function () { renderItemListRows(itemSearch.value); });
    itemSearch.addEventListener("keydown", function (ev) { if (ev.key === "ArrowDown") { var first = itemList.querySelector('.extuiItemPickerRow'); if (first) { ev.preventDefault(); first.focus(); } } else if (ev.key === "Escape") { setItemPickerOpen(false); itemBox.focus(); } });
    function selectItemRow(row) {
      if (!row) return;
      state.selectedItemId = row.getAttribute("data-id");
      itemText.textContent = row.textContent;
      itemList.querySelectorAll('.extuiItemPickerRow').forEach(function (option) { option.classList.toggle('extuiSelected', option === row); option.setAttribute('aria-selected', String(option === row)); });
      setItemPickerOpen(false);
      itemError.style.display = "none";
      updateNextBtnState();
      itemBox.focus();
    }
    itemList.addEventListener("click", function (ev) { selectItemRow(ev.target.closest(".extuiItemPickerRow")); });
    itemList.addEventListener("keydown", function (ev) { var row = ev.target.closest('.extuiItemPickerRow'); if (!row) return; var options = Array.from(itemList.querySelectorAll('.extuiItemPickerRow')), index = options.indexOf(row); if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); var next = options[Math.max(0, Math.min(options.length - 1, index + (ev.key === 'ArrowDown' ? 1 : -1)))]; if (next) next.focus(); } else if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); selectItemRow(row); } else if (ev.key === 'Escape') { ev.preventDefault(); setItemPickerOpen(false); itemBox.focus(); } });


    var labelsBox = stepEl.querySelector("#extuiDisparosLabelsBox");
    var labelsText = stepEl.querySelector("#extuiDisparosLabelsText");
    var labelsDropdown = stepEl.querySelector("#extuiDisparosLabelsDropdown");
    var labelsList = stepEl.querySelector("#extuiDisparosLabelsList");
    if (!state.selectedLabelIds) state.selectedLabelIds = [];

    var pickerRuntime = { allLabelsCache: null, labelRecomputeSeq: 0, contactSearchDebounce: null, allContactsCache: null };
    async function getAllLabels() {
      if (!pickerRuntime.allLabelsCache) pickerRuntime.allLabelsCache = await window.ExtensionChatBridge.labels.getAllLabels();
      return pickerRuntime.allLabelsCache;
    }

    function updateLabelsBoxText() {
      if (state.selectedLabelIds.length === 0) {
        labelsText.textContent = "Selecionar etiquetas";
        return;
      }
      var names = (pickerRuntime.allLabelsCache || [])
        .filter(function (l) { return state.selectedLabelIds.indexOf(l.id) !== -1; })
        .map(function (l) { return l.name; });
      if (names.length === state.selectedLabelIds.length) {
        labelsText.textContent = names.join(", ");
      } else {


        labelsText.textContent = state.selectedLabelIds.length + " etiqueta(s) selecionada(s)";
      }
    }

    async function renderLabelsList() {
      try {
        var labels = await getAllLabels();
        if (labels.length === 0) {
          labelsList.innerHTML = '<div class="extuiItemPickerEmpty">Nenhuma etiqueta cadastrada no WhatsApp</div>';
          return;
        }
        labelsList.innerHTML = labels.map(function (l) {
          var selected = state.selectedLabelIds.indexOf(l.id) !== -1 ? " extuiSelected" : "";
          return '<div class="extuiItemPickerRow' + selected + '" role="option" aria-selected="' + (selected?"true":"false") + '" tabindex="-1" data-id="' + escHtml(l.id) + '">' + escHtml(l.name) + '</div>';
        }).join("");
      } catch (err) {
        labelsList.innerHTML = '<div class="extuiItemPickerEmpty">Erro ao carregar etiquetas</div>';
      }
    }



    async function recomputeLabelContacts() {
      var seq = ++pickerRuntime.labelRecomputeSeq;
      var chats = [];
      if (state.selectedLabelIds.length > 0) {
        try {
          chats = await window.ExtensionChatBridge.chat.list({ withLabels: state.selectedLabelIds });
        } catch (err) {
          return;
        }
        if (seq !== pickerRuntime.labelRecomputeSeq) return;
      }
      var labelValues = {};
      chats.forEach(function (c) {
        if (c.id && c.id._serialized) labelValues[c.id._serialized] = c;
      });
      state.contactEntries = state.contactEntries.filter(function (e) {
        return e.source !== "label" || labelValues.hasOwnProperty(e.value);
      });
      state.labelDuplicates = 0;
      Object.keys(labelValues).forEach(function (value) {
        var existing = state.contactEntries.find(function (e) { return e.value === value; });
        if (existing) { if (existing.source !== "label") state.labelDuplicates++; return; }
        var c = labelValues[value];
        var display = c.name || c.formattedName || c.pushname || (c.id && c.id.user) || value;
        state.contactEntries.push({ value: value, label: display, source: "label" });
      });
      renderContactChips();
    }

    function setLabelsPickerOpen(open){labelsDropdown.classList.toggle("extuiOpen",!!open);labelsBox.setAttribute("aria-expanded",String(!!open));if(open)renderLabelsList();}
    labelsBox.addEventListener("click", function (ev) {ev.stopPropagation();setLabelsPickerOpen(!labelsDropdown.classList.contains("extuiOpen"));});
    labelsBox.addEventListener("keydown",function(ev){if(ev.key==="Enter"||ev.key===" "){ev.preventDefault();setLabelsPickerOpen(!labelsDropdown.classList.contains("extuiOpen"));}else if(ev.key==="Escape"){setLabelsPickerOpen(false);}});
    function toggleLabelRow(row) {
      if (!row) return;
      var id = row.getAttribute("data-id");
      var idx = state.selectedLabelIds.indexOf(id);
      if (idx === -1) state.selectedLabelIds.push(id); else state.selectedLabelIds.splice(idx, 1);
      row.classList.toggle("extuiSelected");
      row.setAttribute("aria-selected",String(row.classList.contains("extuiSelected")));
      updateLabelsBoxText();
      recomputeLabelContacts();
    }
    labelsList.addEventListener("click", function (ev) { toggleLabelRow(ev.target.closest(".extuiItemPickerRow")); });
    labelsList.addEventListener("keydown", function (ev) { var row = ev.target.closest('.extuiItemPickerRow'); if (!row) return; var options = Array.from(labelsList.querySelectorAll('.extuiItemPickerRow')), index = options.indexOf(row); if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); var next = options[Math.max(0, Math.min(options.length - 1, index + (ev.key === 'ArrowDown' ? 1 : -1)))]; if (next) next.focus(); } else if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); toggleLabelRow(row); } else if (ev.key === 'Escape') { ev.preventDefault(); setLabelsPickerOpen(false); labelsBox.focus(); } });
    updateLabelsBoxText();


    var infoBox = stepEl.querySelector("#extuiDisparosInfoBox");
    var infoBoxHeader=stepEl.querySelector("#extuiDisparosInfoBoxHeader");
    infoBoxHeader.addEventListener("click", function () {var open=infoBox.classList.toggle("extuiOpen");infoBoxHeader.setAttribute("aria-expanded",String(open));});


    var contactSearchInput = stepEl.querySelector("#extuiDisparosContactSearch");
    var contactSuggestDropdown = stepEl.querySelector("#extuiDisparosContactSuggestDropdown");
    var contactSuggestList = stepEl.querySelector("#extuiDisparosContactSuggestList");



    async function getAllContacts() {
      if (!pickerRuntime.allContactsCache) pickerRuntime.allContactsCache = await window.ExtensionChatBridge.contact.list();
      return pickerRuntime.allContactsCache;
    }

    function dedupeContacts(list) {


      var byName = {};
      var order = [];
      list.forEach(function (c) {
        var name = (c.name || c.pushname || c.formattedName || "").trim();
        var key = name || (c.id && c.id._serialized) || "";
        if (!key) return;
        var isCus = c.id && c.id.server === "c.us";
        if (!(key in byName)) {
          byName[key] = c;
          order.push(key);
        } else if (isCus && byName[key].id && byName[key].id.server !== "c.us") {
          byName[key] = c;
        }
      });
      return order.map(function (key) { return byName[key]; });
    }

    async function runContactSearch(query) {
      var term = (query || "").trim().toLowerCase();
      try {
        var allContacts = await getAllContacts();
        var filtered = term.length === 0
          ? allContacts
          : allContacts.filter(function (c) {
              var name = (c.name || c.pushname || c.formattedName || "").toLowerCase();
              return name.indexOf(term) !== -1;
            });
        var pool = dedupeContacts(filtered);
        if (pool.length === 0) {
          contactSuggestList.innerHTML = '<div class="extuiItemPickerEmpty">Nenhum contato encontrado</div>';
        } else {
          contactSuggestList.innerHTML = pool.map(function (c) {
            var display = c.name || c.pushname || c.formattedName || (c.id && c.id.user) || "";


            var serialized = c.id && c.id._serialized ? c.id._serialized : "";
            var displayNumber = c.id && c.id.server === "c.us" ? c.id.user : (display || serialized);
            if (!serialized) return "";
            return '<div class="extuiItemPickerRow" role="option" aria-selected="false" tabindex="-1" data-id="' + escHtml(serialized) + '" data-label="' + escHtml(display) + '">' + escHtml(display) + ' <span style="color:var(--extui-text-dim,#a0a0a0);font-size:var(--extui-text-caption-size,13.5px);">(' + escHtml(displayNumber) + ')</span></div>';
          }).join("");
        }
        contactSuggestDropdown.classList.add("extuiOpen");
        contactSearchInput.setAttribute("aria-expanded","true");
      } catch (err) {
        contactSuggestList.innerHTML = '<div class="extuiItemPickerEmpty">Erro ao buscar contatos</div>';
        contactSuggestDropdown.classList.add("extuiOpen");
        contactSearchInput.setAttribute("aria-expanded","true");
      }
    }

    stepEl.addEventListener("click",function(ev){if(!ev.target.closest("#extuiDisparosItemPicker"))setItemPickerOpen(false);if(!ev.target.closest("#extuiDisparosLabelsPicker"))setLabelsPickerOpen(false);if(!ev.target.closest("#extuiDisparosContactSearchPicker")){contactSuggestDropdown.classList.remove("extuiOpen");contactSearchInput.setAttribute("aria-expanded","false");}});

    contactSearchInput.addEventListener("focus", function () {
      runContactSearch(contactSearchInput.value);
    });
    contactSearchInput.addEventListener("click", function (ev) {
      ev.stopPropagation();
      runContactSearch(contactSearchInput.value);
    });
    contactSearchInput.addEventListener("input", function () {
      clearTimeout(pickerRuntime.contactSearchDebounce);
      var query = contactSearchInput.value;
      pickerRuntime.contactSearchDebounce = setTimeout(function () { runContactSearch(query); }, 300);
    });
    contactSearchInput.addEventListener("keydown", function (ev) { if (ev.key === 'ArrowDown') { var first = contactSuggestList.querySelector('.extuiItemPickerRow'); if (first) { ev.preventDefault(); first.focus(); } } else if (ev.key === 'Escape') { contactSuggestDropdown.classList.remove('extuiOpen'); contactSearchInput.setAttribute('aria-expanded','false'); } });
    contactSuggestList.addEventListener("keydown", function (ev) { var row = ev.target.closest('.extuiItemPickerRow'); if (!row) return; var options = Array.from(contactSuggestList.querySelectorAll('.extuiItemPickerRow')), index = options.indexOf(row); if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); var next = options[Math.max(0, Math.min(options.length - 1, index + (ev.key === 'ArrowDown' ? 1 : -1)))]; if (next) next.focus(); } else if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); row.click(); } else if (ev.key === 'Escape') { ev.preventDefault(); contactSuggestDropdown.classList.remove('extuiOpen'); contactSearchInput.setAttribute('aria-expanded','false'); contactSearchInput.focus(); } });


    var contactsChipsBox = stepEl.querySelector("#extuiDisparosContactsChips");
    var contactsManualInput = stepEl.querySelector("#extuiDisparosContactsManualInput");
    var contactsLabel = stepEl.querySelector("#extuiDisparosContactsLabel");
    var contactsError = stepEl.querySelector("#extuiDisparosContactsError");

    function updateChipsBoxVisibility() {
      var shouldShow = state.contactEntries.length > 0 || contactsManualInput.value.trim().length > 0 || document.activeElement === contactsManualInput;
      contactsChipsBox.classList.toggle("extuiHidden", !shouldShow);
    }
    function renderContactChips() {
      contactsLabel.textContent = "Números para o disparo (" + state.contactEntries.length + "):";
      if (state.contactEntries.length === 0) {
        contactsChipsBox.innerHTML = '<span class="extuiChipsEmpty">Nenhum contato adicionado ainda</span>';
      } else {
        contactsChipsBox.innerHTML = state.contactEntries.map(function (e, i) {
          return '<span class="extuiChip">' + escHtml(e.label) + '<button type="button" class="extuiChipRemove" data-idx="' + i + '" aria-label="Remover ' + escHtml(e.label) + '">&times;</button></span>';
        }).join("");
        contactsError.style.display = "none";
      }
      updateChipsBoxVisibility();
      updateNextBtnState();
    }
    function addContactEntry(value, label, source) {
      var v = (value || "").trim();
      if (!v) return;
      if (state.contactEntries.some(function (e) { return e.value === v; })) { state.manualDuplicates++; return; }
      state.contactEntries.push({ value: v, label: label || v, source: source || "manual" });
      renderContactChips();
    }
    function addManualContact() {
      var digits = contactsManualInput.value.replace(/\D/g, "");
      contactsManualInput.value = "";
      if (!digits) return;
      if (digits.length < 10 || digits.length > 11) {
        state.invalidIgnored++;
        contactsError.textContent = "Número inválido. Use DDD + número (ex: 11987654321).";
        contactsError.style.display = "block";
        return;
      }
      addContactEntry(digits, digits, "manual");
    }
    contactsManualInput.addEventListener("input", function () {
      var digits = contactsManualInput.value.replace(/\D/g, "");
      if (contactsManualInput.value !== digits) contactsManualInput.value = digits;
      updateChipsBoxVisibility();
    });
    contactsManualInput.addEventListener("focus", updateChipsBoxVisibility);
    contactsChipsBox.addEventListener("click", function (ev) {
      var btn = ev.target.closest(".extuiChipRemove");
      if (!btn) return;
      var idx = parseInt(btn.getAttribute("data-idx"), 10);
      state.contactEntries.splice(idx, 1);
      renderContactChips();
    });
    contactsManualInput.addEventListener("keydown", function (ev) {
      if (ev.key !== "Enter") return;
      ev.preventDefault();
      addManualContact();
    });
    contactsManualInput.addEventListener("blur", function () {
      if (contactsManualInput.value.trim()) addManualContact();
      updateChipsBoxVisibility();
    });
    renderContactChips();
    var spreadsheetInput=stepEl.querySelector("#extuiDisparosSpreadsheetInput"),spreadsheetTemplate=stepEl.querySelector("#extuiDisparosSpreadsheetTemplate");
    var spreadsheetHasDdi=stepEl.querySelector("#extuiDisparosSheetHasDdi"),spreadsheetNinthDigit=stepEl.querySelector("#extuiDisparosSheetNinthDigit"),spreadsheetValidate=stepEl.querySelector("#extuiDisparosSheetValidate");
    if(spreadsheetTemplate)spreadsheetTemplate.addEventListener("click",function(){var svc=window.__extSpreadsheetImport;if(!svc)return;var a=document.createElement("a"),downloadUrl=URL.createObjectURL(new Blob([svc.templateCsv()],{type:"text/csv;charset=utf-8"}));a.href=downloadUrl;a.download="extapp-modelo-disparos.csv";document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(downloadUrl);},1500);});
    if(spreadsheetInput)spreadsheetInput.addEventListener("change",async function(){var file=spreadsheetInput.files&&spreadsheetInput.files[0];if(!file)return;try{var svc=window.__extSpreadsheetImport;if(!svc)throw new Error("Importador de planilhas indisponível.");var opts={international:!!(spreadsheetHasDdi&&spreadsheetHasDdi.checked),ninthDigit:!!(spreadsheetNinthDigit&&spreadsheetNinthDigit.checked)};if(spreadsheetValidate&&spreadsheetValidate.checked){if(!getSendEngine())throw new Error("Aguarde o WhatsApp ficar pronto antes de validar os números.");opts.validator=async function(number){try{return !!(await verifyNumberExists(String(number)+"@c.us"));}catch(_){return false;}};}var result=await svc.parseFile(file,opts);result.contacts.forEach(function(c){addContactEntry(c.value,c.label,"spreadsheet");});state.invalidIgnored+=result.invalidCount||0;state.manualDuplicates+=result.duplicateCount||0;renderContactChips();}catch(err){contactsError.textContent=err&&err.message?err.message:"Falha ao importar planilha.";contactsError.style.display="block";}finally{spreadsheetInput.value="";}});

    contactSuggestList.addEventListener("click", function (ev) {
      var row = ev.target.closest(".extuiItemPickerRow");
      if (!row) return;
      var id = row.getAttribute("data-id");
      if (!id) return;
      addContactEntry(id, row.getAttribute("data-label") || id, "search");
      contactSearchInput.value = "";
      contactSuggestDropdown.classList.remove("extuiOpen");
      contactSearchInput.setAttribute("aria-expanded","false");
    });

    nextBtn.addEventListener("click", async function () {
      var isStillLoading = itemText.textContent === "Carregando itens...";
      var hasError = false;

      if (!state.selectedItemId) {
        itemError.textContent = isStillLoading
          ? "Aguarde o carregamento dos itens antes de continuar."
          : "Campo obrigatório";
        itemError.style.display = "block";
        hasError = true;
      } else {
        itemError.style.display = "none";
      }

      if (state.contactEntries.length === 0) {
        contactsError.textContent = "Campo obrigatório";
        contactsError.style.display = "block";
        hasError = true;
      } else {
        contactsError.style.display = "none";
      }

      var minMin = parseInt(stepEl.querySelector("#extuiDisparosMinDelayMin").value, 10) || 0;
      var minSec = parseInt(stepEl.querySelector("#extuiDisparosMinDelaySec").value, 10) || 0;
      var maxMin = parseInt(stepEl.querySelector("#extuiDisparosMaxDelayMin").value, 10) || 0;
      var maxSec = parseInt(stepEl.querySelector("#extuiDisparosMaxDelaySec").value, 10) || 0;
      var minDelayCandidate = (minMin * 60 + minSec) || 1;
      var maxDelayCandidate = (maxMin * 60 + maxSec) || 30;
      var delayError = stepEl.querySelector("#extuiDisparosDelayError");
      if (minDelayCandidate > maxDelayCandidate) {
        delayError.textContent = "O tempo mínimo não pode ser maior que o máximo.";
        delayError.style.display = "block";
        hasError = true;
      } else {
        delayError.style.display = "none";
      }

      if (hasError) return;

      state.phoneNumbers = state.contactEntries.map(function (e) { return e.value; });
      state.minDelay = minDelayCandidate;
      state.maxDelay = maxDelayCandidate;


      state.selectedItemName = itemText.textContent || "";
      state.selectedTagNames = (pickerRuntime.allLabelsCache || [])
        .filter(function (l) { return state.selectedLabelIds.indexOf(l.id) !== -1; })
        .map(function (l) { return l.name; });
      try { await renderPreflightStep(stepEl); } catch (err) { toast(err&&err.message||"Não foi possível revisar este disparo com a Proteção de Envio.",true); }
    });
  }

  function formatPreflightDuration(totalSeconds) {
    if (totalSeconds < 60) return "~" + Math.max(1, Math.ceil(totalSeconds)) + " segundo(s)";
    if (totalSeconds < 3600) return "~" + Math.ceil(totalSeconds / 60) + " minuto(s)";
    var hours = totalSeconds / 3600;
    return "~" + (hours < 10 ? hours.toFixed(1).replace(".", ",") : Math.ceil(hours)) + " hora(s)";
  }

  async function renderPreflightStep(stepEl) {
    var typeDef=TYPE_ICONS.find(function(type){return type.type===state.selectedType;}),tags=state.selectedTagNames||[],recipientCount=(state.contactEntries||[]).length,duplicateCount=(state.manualDuplicates||0)+(state.labelDuplicates||0),totalReceived=recipientCount+duplicateCount+(state.invalidIgnored||0);
    var safety=window.__extSendSafetyManager;if(!safety||typeof safety.preflightRecipients!=="function")throw Object.assign(new Error("Proteção de Envio indisponível; campanha bloqueada."),{code:"SEND_SAFETY_UNAVAILABLE"});
    var batchId=state.preflightCampaignId||(state.preflightCampaignId="bulk-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10));
    var preflight=await safety.preflightRecipients((state.contactEntries||[]).map(function(entry){return entry.value;}),{source:"bulk",campaignId:batchId,enforceRecipientCooldown:true});state.safetyPreflight=preflight;
    var allowedSet=new Set((preflight.allowedRecipients||[]).map(function(v){return String(v).replace(/\D/g,"");})),eligible=(state.contactEntries||[]).filter(function(entry){return allowedSet.has(String(entry.value).replace(/\D/g,""));}),risk=preflight.risk||{label:"Atenção baixa",reasons:[]};state.preflightEligibleEntries=eligible;
    stepEl.innerHTML=[
      '<section class="extuiDisparosPreflight" aria-labelledby="extuiDisparosPreflightTitle">',
      '  <div class="extuiDisparosPreflightEyebrow">Revisão final</div>',
      '  <h3 id="extuiDisparosPreflightTitle">Confirme antes de enviar</h3>',
      '  <p class="extuiDisparosPreflightHint">A Proteção de Envio filtra duplicados, opt-outs, cooldown e limites globais antes de criar a fila.</p>',
      '  <div class="extuiDisparosPreflightIdentity"><span>'+escHtml(typeDef?typeDef.title:state.selectedType)+'</span><strong>'+escHtml(state.selectedItemName||state.selectedItemId)+'</strong></div>',
      '  <div class="extuiDisparosPreflightMetrics">',
      '    <div><strong>'+totalReceived+'</strong><span>contatos recebidos</span></div>',
      '    <div><strong>'+eligible.length+'</strong><span>elegíveis para envio</span></div>',
      '    <div><strong>'+duplicateCount+'</strong><span>duplicados removidos</span></div>',
      '    <div><strong>'+((preflight.suppressionSkippedCount||0)+(preflight.cooldownSkippedCount||0)+(state.invalidIgnored||0))+'</strong><span>bloqueados/ignorados</span></div>',
      '  </div>',
      '  <dl class="extuiDisparosPreflightDetails">',
      '    <div><dt>Etiquetas</dt><dd>'+escHtml(tags.length?tags.join(", "):"Nenhuma")+'</dd></div>',
      '    <div><dt>Intervalo</dt><dd>'+state.minDelay+'–'+state.maxDelay+' segundos</dd></div>',
      '    <div><dt>Duração estimada</dt><dd>'+formatPreflightDuration(eligible.length*Math.max(state.minDelay,Number(preflight.settingsMinGap)||0))+' a '+formatPreflightDuration(eligible.length*Math.max(state.maxDelay,Number(preflight.settingsMinGap)||0))+'</dd></div>',
      '    <div><dt>Janela 24h</dt><dd>'+String(preflight.dayCount||0)+' usados · '+String(preflight.dayRemaining||0)+' restantes</dd></div>',
      '    <div><dt>Avaliação local</dt><dd>'+escHtml(risk.label||"Atenção baixa")+'</dd></div>',
      '  </dl>',
      '  <div class="extuiDisparosPolicyNotice"><strong>Consentimento e opt-out</strong><span>Estes guardrails não são limites oficiais do WhatsApp. Confirme que os destinatários esperam esta mensagem e respeite qualquer pedido para não receber comunicações.</span></div>',
      '  <div class="extuiDisparosConsentChecks">',
      '    <label><input type="checkbox" id="extuiDisparosConsentCheck"><span>Confirmo que os destinatários forneceram seus números e esperam receber este tipo de mensagem.</span></label>',
      '    <label><input type="checkbox" id="extuiDisparosOptoutCheck"><span>Revisei a lista e removi ou marquei como Não contatar quem pediu para não receber comunicações.</span></label>',
      '  </div>',
      ((preflight.suppressionSkippedCount||0)||(preflight.cooldownSkippedCount||0)?'  <small class="extuiDisparosFilteredNote">'+String(preflight.suppressionSkippedCount||0)+' em Não contatar · '+String(preflight.cooldownSkippedCount||0)+' protegidos contra reenvio recente</small>':''),
      (preflight.ok!==true?'  <div class="extuiDisparosBlockedNote">'+escHtml(preflight.message||"A Proteção de Envio bloqueou esta campanha.")+'</div>':''),
      '  <div class="extuiDisparosPreflightActions"><button type="button" class="secondary" id="extuiDisparosPreflightBack">Voltar</button><button type="button" class="primary" id="extuiDisparosPreflightConfirm" disabled>Confirmar disparo</button></div>',
      '</section>'
    ].join("\n");
    stepEl.querySelector("#extuiDisparosPreflightBack").addEventListener("click",function(){renderConfigStep(stepEl);});
    var consent=stepEl.querySelector("#extuiDisparosConsentCheck"),optout=stepEl.querySelector("#extuiDisparosOptoutCheck"),confirmBtn=stepEl.querySelector("#extuiDisparosPreflightConfirm");function sync(){confirmBtn.disabled=!(consent.checked&&optout.checked&&preflight.ok===true&&eligible.length>0);}consent.addEventListener("change",sync);optout.addEventListener("change",sync);sync();
    confirmBtn.addEventListener("click",async function(){confirmBtn.disabled=true;state.consentConfirmed=consent.checked===true;state.optOutReviewed=optout.checked===true;try{await enqueueAndStart(state);renderStatusStep(stepEl);}catch(err){var code=String(err&&err.code||"");toast(code.indexOf("SEND_SAFETY_")===0?(err.message||"O disparo foi bloqueado pela Proteção de Envio."):"Não foi possível iniciar o disparo. Recarregue a página (F5) e tente de novo.",true);sync();}});
  }

  var ITEM_STORAGE_BY_TYPE = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList" },
    audio: { key: "EXTUI:audioStore", listField: "audioList" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList" },
    image: { key: "EXTUI:mediaStore", listField: "mediaList", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", listField: "mediaList", virtualMediaKind: "video" },
    sticker: { key: "EXTUI:stickerStore", listField: "stickerList" },
    document: { key: "EXTUI:documentStore", listField: "documentList" },
    flow: { key: "EXTUI:extappFlowStore", listField: "flowList" },
    funnel: { key: "EXTUI:extappFunnelStore", listField: "funnelList" }
  };

  broadcastRuntime.itemLoadRequestId = 0;

  async function resolveFunnelIdForStart(itemId) { return String(itemId || ""); }

async function loadFunnelItemOptions(requestId) {
    var itemText = document.getElementById("extuiDisparosItemText");
    var itemList = document.getElementById("extuiDisparosItemList");
    var nextBtn = document.getElementById("extuiDisparosNextBtn");
    var config = ITEM_STORAGE_BY_TYPE.funnel;
    var MAX_RETRY_ATTEMPTS = 2;
    var RETRY_DELAY_MS = 500;
    try {
      for (var attempt = 0; attempt <= MAX_RETRY_ATTEMPTS; attempt++) {
        var raw = await extStorageGet(config.key);
        if (requestId !== broadcastRuntime.itemLoadRequestId) return;
        var parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
        var list = (parsed && parsed.state && parsed.state[config.listField]) || [];
        if (requestId !== broadcastRuntime.itemLoadRequestId) return;
        if (list.length > 0) {
          broadcastRuntime.loadedItemList = await rankLoadedItems("funnel", list.map(function (item) {
            return { id: item.id, displayName: item.name || item.id, favorite: !!item.favorite };
          }));
          if (itemText) itemText.textContent = "Selecione um item";
          renderItemListRows("");
          if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
          return;
        }


        if (attempt < MAX_RETRY_ATTEMPTS) {
          await new Promise(function (resolve) { setTimeout(resolve, RETRY_DELAY_MS); });
          if (requestId !== broadcastRuntime.itemLoadRequestId) return;
          continue;
        }

        if (itemText) itemText.textContent = "Selecione um item";
        if (itemList) itemList.innerHTML = '<div class="extuiItemPickerEmpty">Nenhum item salvo deste tipo</div>';
        if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
        return;
      }
    } catch (err) {
      if (requestId !== broadcastRuntime.itemLoadRequestId) return;
      if (itemText) itemText.textContent = "Erro ao carregar itens";
      if (itemList) itemList.innerHTML = '<div class="extuiItemPickerEmpty">Erro ao carregar itens</div>';
      if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
    }
  }

  async function classifyBroadcastMediaItem(item) {
    if (item && (item.mediaKind === "image" || item.mediaKind === "video")) return item.mediaKind;
    if (!item || !item.id) return "unknown";
    try {
      var raw = await extStorageGet(String(item.id));
      var content = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
      if (!content) return "unknown";
      if (content.mediaKind === "image" || content.mediaKind === "video") return content.mediaKind;
      var mime = String(content.mimeType || content.type || "").toLowerCase();
      var name = String(content.fileName || content.name || item.name || "").toLowerCase();
      var data = String(content.data || content.base64 || "");
      if (/^data:video\//i.test(data) || mime.indexOf("video/") === 0 || /\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name)) return "video";
      if (/^data:image\//i.test(data) || mime.indexOf("image/") === 0 || /\.(png|jpe?g|gif|webp|bmp|avif)$/.test(name)) return "image";
    } catch (_) {}
    return "unknown";
  }

  async function loadItemOptions(type) {
    var requestId = ++broadcastRuntime.itemLoadRequestId;
    var config = ITEM_STORAGE_BY_TYPE[type];
    var itemText = document.getElementById("extuiDisparosItemText");
    var itemList = document.getElementById("extuiDisparosItemList");
    var nextBtn = document.getElementById("extuiDisparosNextBtn");
    if (nextBtn) nextBtn.disabled = true;

    state.selectedItemId = null;
    broadcastRuntime.loadedItemList = [];
    if (itemText) itemText.textContent = "Carregando itens...";
    if (itemList) itemList.innerHTML = "";
    if (!config) {
      if (requestId !== broadcastRuntime.itemLoadRequestId) return;
      if (itemText) itemText.textContent = "Tipo não suportado ainda";
      if (itemList) itemList.innerHTML = '<div class="extuiItemPickerEmpty">Tipo não suportado ainda</div>';
      if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
      return;
    }
    if (type === "funnel") {
      return await loadFunnelItemOptions(requestId);
    }


    var MAX_RETRY_ATTEMPTS = 2;
    var RETRY_DELAY_MS = 500;
    try {
      for (var attempt = 0; attempt <= MAX_RETRY_ATTEMPTS; attempt++) {
        var raw = await extStorageGet(config.key);


        if (requestId !== broadcastRuntime.itemLoadRequestId) return;


        var parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
        var list = (parsed && parsed.state && parsed.state[config.listField]) || [];
        if (config.virtualMediaKind && list.length) {
          var filteredMedia = [];
          for (var mediaIndex = 0; mediaIndex < list.length; mediaIndex++) if (await classifyBroadcastMediaItem(list[mediaIndex]) === config.virtualMediaKind) filteredMedia.push(list[mediaIndex]);
          list = filteredMedia;
        }
        if (list.length > 0) {
          broadcastRuntime.loadedItemList = await rankLoadedItems(type, list.map(function (item) {
            var displayName = item.name || item.fileName || item.id;
            return { id: item.id, displayName: displayName, favorite: !!item.favorite };
          }));
          if (itemText) itemText.textContent = "Selecione um item";
          renderItemListRows("");
          if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
          return;
        }


        if (attempt < MAX_RETRY_ATTEMPTS) {
          await new Promise(function (resolve) { setTimeout(resolve, RETRY_DELAY_MS); });
          if (requestId !== broadcastRuntime.itemLoadRequestId) return;
          continue;
        }

        if (itemText) itemText.textContent = "Selecione um item";
        if (itemList) itemList.innerHTML = '<div class="extuiItemPickerEmpty">Nenhum item salvo deste tipo</div>';
        if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
        return;
      }
    } catch (err) {
      if (requestId !== broadcastRuntime.itemLoadRequestId) return;
      if (itemText) itemText.textContent = "Erro ao carregar itens";
      if (itemList) itemList.innerHTML = '<div class="extuiItemPickerEmpty">Erro ao carregar itens</div>';
      if (nextBtn) nextBtn.disabled = !(state.selectedItemId && state.contactEntries.length > 0);
    }
  }


  window.ExtensionCore = window.ExtensionCore || {};
  var panelControllers = window.ExtensionCore.PanelControllers;
  if (!panelControllers) {
    panelControllers = Object.create(null);
    Object.defineProperty(window.ExtensionCore, "PanelControllers", { value: panelControllers, writable: false, configurable: false, enumerable: true });
  }
  Object.defineProperty(panelControllers, "broadcast", { value: Object.freeze({ open: openPanel, close: closePanel, toggle: togglePanel }), writable: false, configurable: false, enumerable: true });


  window.addEventListener("ext:panel-state", function (ev) {
    if (!ev.detail || ev.detail.panelId !== PANEL_ID) return;
    if (ev.detail.open) { bindPickerOutsidePointer(); return; }
    unbindPickerOutsidePointer();
    if (statusPollTimer) { clearInterval(statusPollTimer); statusPollTimer = null; }
  });

  var QUEUE_STORAGE_KEY = "ext:bulkQueue";
  var processing = false;
  var cancelled = false;
  var paused = false;
  var processGeneration = 0;
  var activeActionExecutionId = null;
  var BULK_START_CONFIRM_TIMEOUT_MS = 6000;
  var BULK_PLAN_CHECK_TIMEOUT_MS = 10000;
  broadcastRuntime.bulkProcessorLastError = null;

  function bulkError(code,message,cause){
    var err=new Error(message||"Falha no processador de Disparos.");
    err.code=code||"BULK_PROCESSOR_ERROR";
    if(cause)err.cause=cause;
    return err;
  }
  function bulkWithTimeout(promise,ms,code,message){
    return new Promise(function(resolve,reject){
      var done=false,timer=setTimeout(function(){if(done)return;done=true;reject(bulkError(code,message));},Math.max(250,Number(ms)||1000));
      Promise.resolve(promise).then(function(value){if(done)return;done=true;clearTimeout(timer);resolve(value);},function(err){if(done)return;done=true;clearTimeout(timer);reject(err);});
    });
  }
  async function ensureBulkProcessorReady(){
    if(!window.ExtensionStorage||typeof window.ExtensionStorage.get!=="function"||typeof window.ExtensionStorage.set!=="function")throw bulkError("BULK_STORAGE_UNAVAILABLE","O armazenamento necessário para iniciar o disparo não está disponível.");
    if(!window.__extActionExecutor||typeof window.__extActionExecutor.execute!=="function")throw bulkError("BULK_ACTION_EXECUTOR_UNAVAILABLE","O executor de ações ainda não está pronto. Recarregue o WhatsApp Web e tente novamente.");
    if(!window.__extSendSafetyManager||typeof window.__extSendSafetyManager.enqueue!=="function")throw bulkError("SEND_SAFETY_UNAVAILABLE","A Proteção de Envio ainda não está pronta. Recarregue o WhatsApp Web e tente novamente.");
    if(!window.ExtensionChatBridge||!window.__extWppBridge)throw bulkError("WPP_BRIDGE_UNAVAILABLE","A conexão com o WhatsApp Web ainda não está pronta.");
    if(!window.__extPlanGate||typeof window.__extPlanGate.requireActive!=="function")throw bulkError("LICENSE_REQUIRED","Sua sessão precisa ser validada novamente.");
    var plan=await bulkWithTimeout(window.__extPlanGate.requireActive(),BULK_PLAN_CHECK_TIMEOUT_MS,"BULK_PLAN_CHECK_TIMEOUT","A validação do plano demorou demais. Recarregue o WhatsApp Web e tente novamente.");
    if(!plan||plan.isPaid!==true)throw bulkError(plan&&plan.isFree?"EXTAPP_PLAN_UPGRADE_REQUIRED":"LICENSE_REQUIRED",plan&&plan.isFree?"O plano atual não permite iniciar Disparos em massa.":"Sua sessão precisa ser validada novamente.");
    return true;
  }
  async function persistBulkFailure(err){
    var queue=[];
    try{queue=await readQueue();}catch(err){reportRuntime(err&&err.code||"BULK_QUEUE_READ_FAILED",err);return queue;}
    var message=err&&err.message?String(err.message):"Falha interna ao iniciar o processador de Disparos.";
    var code=err&&err.code||"BULK_PROCESSOR_START_FAILED";
    var changed=false;
    queue.forEach(function(item){
      if(!item)return;
      if(item.state==="queued"||item.state==="retrying"||item.state==="sending"){
        item.state="error";
        item.lastErrorCode=code;
        item.lastErrorMessage=message;
        item.lastStatusAt=Date.now();
        changed=true;
      }
    });
    if(changed){try{await writeQueue(queue);}catch(err){reportRuntime(err&&err.code||"BULK_QUEUE_WRITE_FAILED",err);}}
    return queue;
  }
  async function waitForBulkProcessorStart(campaignId){
    var startedAt=Date.now(),lastQueue=[];
    while(Date.now()-startedAt<BULK_START_CONFIRM_TIMEOUT_MS){
      if(broadcastRuntime.bulkProcessorLastError)throw broadcastRuntime.bulkProcessorLastError;
      try{lastQueue=await readQueue();}catch(err){throw bulkError("BULK_QUEUE_READ_FAILED","Não foi possível confirmar o estado inicial da fila de Disparos.",err);}
      var rows=(Array.isArray(lastQueue)?lastQueue:[]).filter(function(item){return !campaignId||!item||!item.campaignId||String(item.campaignId)===String(campaignId);});
      var failed=rows.find(function(item){return item&&item.state==="error";});
      if(failed)throw bulkError(failed.lastErrorCode||"BULK_PROCESSOR_START_FAILED",failed.lastErrorMessage||"O processador de Disparos falhou ao iniciar.");
      if(rows.some(function(item){return item&&(item.state==="sending"||item.state==="sent");}))return{started:true,queue:rows};
      await reliableDispatchWait(100);
    }
    throw bulkError("BULK_PROCESSOR_START_TIMEOUT","O processador de Disparos não saiu do estado de espera. O envio foi interrompido para evitar uma fila travada.");
  }


  broadcastRuntime.bulkActivityId = null;


  broadcastRuntime.bulkHistoryId = null;
  var statusPollTimer = null;
  var statusPollRunning = false;
  var REMOTE_PAUSE_KEY = "ext:bulkQueuePauseRequested";


  var HISTORY_KEY = "EXTUI:disparosHistory";
  var MAX_HISTORY_ENTRIES = 100;
  var CRITICAL_LIST_STORES = {};
  CRITICAL_LIST_STORES[QUEUE_STORAGE_KEY] = { code: "BULK_QUEUE_CORRUPT", legacy: "queue" };
  CRITICAL_LIST_STORES[HISTORY_KEY] = { code: "DISPAROS_HISTORY_CORRUPT", legacy: "history" };
  var criticalListSnapshots = Object.create(null);
  function criticalListError(key, cause) {
    var cfg = CRITICAL_LIST_STORES[key] || {}, err = new Error("Os dados persistidos de Disparos estão corrompidos. O último estado válido foi preservado e a sobrescrita foi bloqueada.");
    err.code = cfg.code || "DISPAROS_STORAGE_CORRUPT";
    if (cause) err.cause = cause;
    return err;
  }
  function decodeCriticalList(raw, key, remember) {
    var cfg = CRITICAL_LIST_STORES[key], value = raw;
    if (value == null || value === "") value = [];
    else if (typeof value === "string") { try { value = JSON.parse(value); } catch (err) { throw criticalListError(key, err); } }
    if (value && !Array.isArray(value) && typeof value === "object") {
      var state = value.state;
      if (Array.isArray(state)) value = state;
      else if (Array.isArray(value[cfg.legacy])) value = value[cfg.legacy];
      else if (state && typeof state === "object" && Array.isArray(state[cfg.legacy])) value = state[cfg.legacy];
    }
    if (!Array.isArray(value)) throw criticalListError(key);
    for (var i = 0; i < value.length; i++) if (!value[i] || typeof value[i] !== "object" || Array.isArray(value[i])) throw criticalListError(key);
    var out = JSON.parse(JSON.stringify(value));
    if (remember !== false) criticalListSnapshots[key] = JSON.parse(JSON.stringify(out));
    return out;
  }
  async function writeCriticalList(key, list) {
    var next = decodeCriticalList(list, key, false);
    decodeCriticalList(await extStorageGet(key), key, true);
    await extStorageSet(key, next);
    criticalListSnapshots[key] = JSON.parse(JSON.stringify(next));
    return next;
  }
  async function loadHistory() { return decodeCriticalList(await extStorageGet(HISTORY_KEY), HISTORY_KEY, true); }
  async function saveHistory(list) {
    if (!Array.isArray(list)) throw criticalListError(HISTORY_KEY);
    await writeCriticalList(HISTORY_KEY, list.slice(0, MAX_HISTORY_ENTRIES));
  }
  async function recordHistoryStart(queue, batchId) {
    if (!queue.length) return;
    var first = queue[0];
    var rec = {
      id: batchId,
      startedAt: Date.now(),
      finishedAt: null,
      status: "running",
      itemType: first.type,
      itemId: first.itemId,
      itemName: first.itemName || "",
      journeyId: first.journeyId || null,
      journeyName: first.journeyName || first.itemName || "",
      actionCount: Number(first.actionCount) || (Array.isArray(first.actions) ? first.actions.length : 0),
      tags: first.tagNames || [],
      recipients: queue.map(function (q) { return { phone: q.phoneNumber, status: q.state }; }),
      sentCount: 0, failedCount: 0, cancelledCount: 0
    };
    var list = await loadHistory();
    list.unshift(rec);
    await saveHistory(list);
  }
  async function finalizeHistory(batchId, finalQueue, wasCancelled) {
    if (!batchId) return;
    var list = await loadHistory();
    var idx = list.findIndex(function (r) { return r.id === batchId; });
    if (idx < 0) return;
    var sent = 0, failed = 0, notSent = 0;
    var recipients = finalQueue.map(function (q) {
      var st = q.state === "sent" ? "sent" : q.state === "error" ? "failed" : (wasCancelled ? "cancelled" : "pending");
      if (st === "sent") sent++; else if (st === "failed") failed++; else notSent++;
      return { phone: q.phoneNumber, status: st };
    });
    list[idx].finishedAt = Date.now();
    list[idx].recipients = recipients;
    list[idx].sentCount = sent;
    list[idx].failedCount = failed;
    list[idx].cancelledCount = notSent;
    list[idx].status = wasCancelled ? "cancelled" : (failed === 0 && notSent === 0 ? "success" : (sent === 0 ? "failed" : "partial"));
    await saveHistory(list);
  }




  async function startBulkTracking(queue, batchId) {
    batchId = batchId || ("disparo:" + Date.now());
    await recordHistoryStart(queue, batchId);
    broadcastRuntime.bulkHistoryId = batchId;
    if (typeof window.__extActivityTrack === "function") {
      broadcastRuntime.bulkActivityId = batchId;
      window.__extActivityTrack({ action: "start", id: batchId, type: "disparo", title: "Disparo em massa", targetLabel: queue.length + " contato(s)", current: 0, total: queue.length, status: "running" });
    }
    return batchId;
  }


  function pacedDelayMs(minSec, maxSec, index) {
    var minMs = Math.max(0, Number(minSec) || 0) * 1000, maxMs = Math.max(minMs, (Number(maxSec) || 0) * 1000);
    if (maxMs <= minMs) return Math.round(minMs);
    var slot = Math.abs(Number(index) || 0) % 5;
    return Math.round(minMs + (maxMs - minMs) * (slot / 4));
  }

  async function readQueue() { return decodeCriticalList(await extStorageGet(QUEUE_STORAGE_KEY), QUEUE_STORAGE_KEY, true); }

  async function writeQueue(queue) {
    if (!Array.isArray(queue)) throw criticalListError(QUEUE_STORAGE_KEY);
    var written = await writeCriticalList(QUEUE_STORAGE_KEY, queue);
    scheduleBulkWatchdog(written);
  }


  async function pauseCurrentDispatch() {
    if (cancelled) return "cancelled";
    paused = true;
    try { await extStorageSet(REMOTE_PAUSE_KEY, true); } catch (err) { reportRuntime("BULK_PAUSE_STATE_WRITE_FAILED", err); }
    if (activeActionExecutionId && window.__extActionExecutor) window.__extActionExecutor.pause(activeActionExecutionId);
    return "paused";
  }

  async function resumeCurrentDispatch() {
    if (cancelled) return "cancelled";
    paused = false;
    try { await extStorageSet(REMOTE_PAUSE_KEY, false); } catch (err) { reportRuntime("BULK_RESUME_STATE_WRITE_FAILED", err); }
    if (activeActionExecutionId && window.__extActionExecutor) window.__extActionExecutor.resume(activeActionExecutionId);
    if (!processing) processQueue();
    return "success";
  }

  async function cancelCurrentDispatch() {
    var snapshot = await readQueue();
    cancelled = true;
    paused = false;
    processGeneration++;
    if (activeActionExecutionId && window.__extActionExecutor) window.__extActionExecutor.cancel(activeActionExecutionId);
    activeActionExecutionId = null;


    processing = false;
    clearInterval(statusPollTimer);
    statusPollTimer = null;
    try {
      await Promise.all([writeQueue([]), extStorageSet(REMOTE_PAUSE_KEY, false)]);
    } catch (err) {
      reportRuntime(err && err.code || "BULK_CANCEL_STORAGE_FAILED", err);
      throw err;
    }
    if (broadcastRuntime.bulkActivityId && typeof window.__extActivityTrack === "function") {
      window.__extActivityTrack({ action: "cancel", id: broadcastRuntime.bulkActivityId });
      broadcastRuntime.bulkActivityId = null;
    }
    if (broadcastRuntime.bulkHistoryId) {
      await finalizeHistory(broadcastRuntime.bulkHistoryId, snapshot, true);
      broadcastRuntime.bulkHistoryId = null;
    }
    return "cancelled";
  }
  window.__extDisparosCancelCurrent = cancelCurrentDispatch;



  async function enqueueAndStart(currentState) {
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Disparos em massa");
    if(!currentState||currentState.consentConfirmed!==true||currentState.optOutReviewed!==true){
      throw Object.assign(new Error("Confirme consentimento e revisão de opt-out antes de iniciar o disparo."),{code:"SEND_SAFETY_CONSENT_REQUIRED"});
    }
    var safety = window.__extSendSafetyManager;
    if (!safety || typeof safety.preflightRecipients !== "function") {
      throw Object.assign(new Error("Proteção de Envio indisponível; campanha bloqueada."),{code:"SEND_SAFETY_UNAVAILABLE"});
    }
    var entries = (currentState.preflightEligibleEntries && currentState.preflightEligibleEntries.length ? currentState.preflightEligibleEntries : currentState.contactEntries) || currentState.phoneNumbers.map(function (v) { return { value: v, label: v }; });
    var batchId = currentState.preflightCampaignId || (currentState.preflightCampaignId = "bulk:" + Date.now());
    var preflight = await safety.preflightRecipients(entries.map(function (entry) { return entry.value; }), { source:"bulk", campaignId:batchId, enforceRecipientCooldown:true });
    if (!preflight || preflight.ok !== true) {
      var safetyError = new Error(preflight && preflight.message || "O disparo foi bloqueado pela Proteção de Envio.");
      safetyError.code = preflight && preflight.code || "SEND_SAFETY_PREFLIGHT_FAILED";
      throw safetyError;
    }
    var allowedSet = new Set((preflight.allowedRecipients || []).map(function (v) { return String(v).replace(/\D/g, ""); }));
    var beforeCount = entries.length;
    entries = entries.filter(function (entry) { return allowedSet.has(String(entry.value).replace(/\D/g, "")); });
    var newlyFiltered = beforeCount - entries.length;
    if (newlyFiltered > 0) toast(newlyFiltered + " contato(s) removido(s) pela Proteção de Envio na revisão final.");
    if (!entries.length) throw Object.assign(new Error("Nenhum destinatário permaneceu elegível após a revisão final."),{code:"SEND_SAFETY_NO_ELIGIBLE_RECIPIENTS"});
    var queue = entries.map(function (entry,index) {
      return {
        phoneNumber: entry.value,
        displayLabel: entry.label || entry.value,
        state: "queued",
        delayMs: pacedDelayMs(currentState.minDelay, currentState.maxDelay, index),
        itemId: currentState.selectedItemId,
        type: currentState.selectedType,
        itemName: currentState.selectedItemName || "",
        tagNames: currentState.selectedTagNames || [],
        campaignId: batchId,
        effectExecutionId: "bulk:"+batchId+":"+String(index),
        safetyAttestation:{policyRevision:Number(preflight.policyRevision)||2,consentConfirmed:true,optOutReviewed:true,confirmedAt:Date.now()},
        attempts: 0,
        retryCount: 0,
        retryLimit: Math.max(1, Math.floor(Number(currentState.retryLimit) || 1))
      };
    });
    await writeQueue(queue);
    cancelled = false;
    paused = false;
    try { await extStorageSet(REMOTE_PAUSE_KEY, false); } catch (err) { reportRuntime("BULK_RESUME_STATE_WRITE_FAILED", err); }
    await startBulkTracking(queue, batchId);
    processQueue();
  }


  function formatPhoneNumberForVariable(raw) {
    var d = String(raw || "").replace(/\D/g, "");
    if (!d) return "";
    if (d.length >= 12 && d.slice(0, 2) === "55") {
      var rest = d.slice(2), ddd = rest.slice(0, 2), num = rest.slice(2);
      if (num.length === 9) return "+55 (" + ddd + ") " + num.slice(0, 5) + "-" + num.slice(5);
      if (num.length === 8) return "+55 (" + ddd + ") " + num.slice(0, 4) + "-" + num.slice(4);
    }
    return "+" + d;
  }
  async function applyMessageVariables(text, chatId) {
    if (text == null) return text;
    var source = String(text);
    if (window.__extVariableResolver && typeof window.__extVariableResolver.resolveForChat === "function") return window.__extVariableResolver.resolveForChat(source, chatId);
    if (!/(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|first_name|fn|nome|nome_completo|full_name|nome_extapp|nome_whatsapp|numero|telefone|phone|email|empresa|company|origem_lead|leadSource|cidade|city|estado|state|endereco|address|cep|postalCode|idioma|language|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i.test(source)) return source;
    try {
      var engine = getSendEngine ? getSendEngine() : ((window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null);
      var rawId = String(chatId && chatId._serialized || chatId || "");
      var active = null, contact = null, meta = null;
      if (engine && engine.chat && typeof engine.chat.getActiveChat === "function") {
        try { active = await engine.chat.getActiveChat(); } catch (_) {}
      }
      if (engine && engine.contact && typeof engine.contact.get === "function" && rawId) {
        try { contact = await engine.contact.get(rawId); } catch (_) {}
      }
      if (window.__extContactMetadataService && typeof window.__extContactMetadataService.get === "function" && rawId) {
        try { meta = await window.__extContactMetadataService.get(rawId); } catch (_) {}
      }
      var activeId = String(active && active.id && (active.id._serialized || active.id) || "");
      var activeContact = active && active.contact || null;
      var activeMatches = !!active && (!rawId || !activeId || activeId === rawId);
      var localName = String(meta && meta.localAlias || "").trim();
      var whatsappName = String(
        contact && (contact.name || contact.pushname || contact.formattedName || contact.notifyName || contact.shortName) ||
        (activeMatches && activeContact && (activeContact.name || activeContact.pushname || activeContact.formattedName || activeContact.notifyName || activeContact.shortName)) ||
        (activeMatches && (active.formattedTitle || active.name || active.title)) || ""
      ).trim();
      var fullName = localName || whatsappName;
      var firstName = fullName ? fullName.split(/\s+/)[0] : "";
      var rawNum = rawId.replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
      if (/@lid$/i.test(rawId) && engine && engine.contact && typeof engine.contact.getPnLidEntry === "function") {
        try {
          var lidEntry = await engine.contact.getPnLidEntry(rawId);
          var pn = lidEntry && lidEntry.phoneNumber && (lidEntry.phoneNumber._serialized || lidEntry.phoneNumber.user);
          if (pn) rawNum = String(pn).replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
        } catch (_) {}
      }
      var num = formatPhoneNumberForVariable(rawNum);
      var now = new Date(), hour = now.getHours();
      var greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
      var period = hour < 12 ? "manhã" : hour < 18 ? "tarde" : "noite";
      var dateStr = String(now.getDate()).padStart(2, "0") + "/" + String(now.getMonth() + 1).padStart(2, "0") + "/" + now.getFullYear();
      var timeStr = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
      var weekday = now.toLocaleDateString("pt-BR", { weekday: "long" });
      var vars = {
        primeiro_nome:firstName, primeiroNome:firstName, first_name:firstName, fn:firstName,
        nome:fullName, nome_completo:fullName, full_name:fullName,
        nome_extapp:localName || fullName, nome_ext:localName || fullName, nome_whatsapp:whatsappName || fullName,
        numero:num || "", telefone:num || "", phone:num || "",
        email:String(meta && meta.email || ""), empresa:String(meta && meta.company || ""), company:String(meta && meta.company || ""),
        origem_lead:String(meta && meta.leadSource || ""), leadSource:String(meta && meta.leadSource || ""),
        cidade:String(meta && meta.city || ""), city:String(meta && meta.city || ""), estado:String(meta && meta.state || ""), state:String(meta && meta.state || ""),
        endereco:String(meta && meta.address || ""), address:String(meta && meta.address || ""), cep:String(meta && meta.postalCode || ""), postalCode:String(meta && meta.postalCode || ""),
        idioma:String(meta && meta.language || ""), language:String(meta && meta.language || ""),
        saudacao:greeting, "saudação":greeting, periodo_dia:period, "periodo-dia":period, dia_semana:weekday, data:dateStr, hora:timeStr
      };
      function valueFor(expr) {
        var raw=String(expr||"").trim(), match=raw.match(/^([^|]+?)(?:\|\s*(?:fallback|padrao|padrão)\s*:\s*["']([^"']*)["'])?$/i);
        var key=String(match && match[1] || raw).trim(), fallback=match && match[2];
        var val=Object.prototype.hasOwnProperty.call(vars,key)?vars[key]:"";
        return val != null && String(val) !== "" ? String(val) : (fallback != null ? fallback : "");
      }
      var output=source.replace(/\{\{\s*([^{}]+?)\s*\}\}/g,function(_,expr){return valueFor(expr);});
      output=output.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(_,prefix,key){return prefix+valueFor(key);});
      var aliases=Object.keys(vars).sort(function(a,b){return b.length-a.length;});
      aliases.forEach(function(key){output=output.split("#"+key).join(String(vars[key]||""));});
      return output;
    } catch (_) { return source; }
  }


  function getSendEngine() {
    return (window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null;
  }

  var bulkOwnIdentityPromise=null;
  function bulkSerializedIdentity(value){
    if(!value)return "";
    if(typeof value==="string")return value;
    if(value._serialized)return String(value._serialized);
    if(value.id&&value.id._serialized)return String(value.id._serialized);
    if(value.user&&value.server)return String(value.user)+"@"+String(value.server);
    try{var text=value.toString&&value.toString();return text&&text!=="[object Object]"?String(text):"";}catch(_){return "";}
  }
  function bulkCanonicalIdentity(value){
    var raw=bulkSerializedIdentity(value).trim().toLowerCase();
    if(!raw)return "";
    var at=raw.lastIndexOf("@");
    if(at>0)raw=raw.slice(0,at).replace(/:\d+$/,"")+raw.slice(at);
    return raw;
  }
  async function bulkOwnIdentities(){
    if(bulkOwnIdentityPromise)return bulkOwnIdentityPromise;
    bulkOwnIdentityPromise=(async function(){
      var ids=new Set(),engine=getSendEngine();
      if(!engine||!engine.conn)return ids;
      var tasks=[];
      if(typeof engine.conn.getMyUserId==="function")tasks.push(engine.conn.getMyUserId().catch(function(){return null;}));
      if(typeof engine.conn.getMyUserLid==="function")tasks.push(engine.conn.getMyUserLid().catch(function(){return null;}));
      var values=await Promise.all(tasks);
      values.forEach(function(value){var raw=bulkCanonicalIdentity(value);if(!raw)return;ids.add(raw);var user=raw.split("@")[0].replace(/\D/g,"");if(user)ids.add("phone:"+user);});
      return ids;
    })();
    var resolved=await bulkOwnIdentityPromise;if(!resolved.size)bulkOwnIdentityPromise=null;return resolved;
  }
  async function bulkIsSelfRecipient(chatId,phoneNumber){
    var own=await bulkOwnIdentities();
    if(!own.size)return false;
    var chat=bulkCanonicalIdentity(chatId);
    if(chat&&own.has(chat))return true;
    var phone=String(phoneNumber||"").replace(/\D/g,"");
    return !!(phone&&own.has("phone:"+phone));
  }

  function serializedContactId(value){
    if(!value)return null;
    if(typeof value==="string")return /@(?:c|g)\.us$|@lid$/i.test(value)?value:null;
    if(value._serialized)return String(value._serialized);
    if(value.id&&value.id._serialized)return String(value.id._serialized);
    return null;
  }
  async function verifyNumberExists(chatId) {
    var engine = getSendEngine();
    if (!engine) throw new Error("O WhatsApp ainda está carregando. Aguarde alguns segundos e tente novamente.");
    var result = await bulkWithTimeout(engine.contact.queryExists(chatId),35000,"BULK_NUMBER_LOOKUP_TIMEOUT","O WhatsApp demorou demais para validar o número do destinatário.");
    if (!result) return null;
    var resolved=serializedContactId(result.lid)||serializedContactId(result.wid)||serializedContactId(result.id)||serializedContactId(result);
    if(resolved)return resolved;
    if(result===true||result.exists===true||result.valid===true)return chatId;
    return null;
  }

  async function resolveChatId(phoneNumber,chatIdHint) {
    var expected=String(phoneNumber||"").replace(/\D/g,"");
    var hint=String(chatIdHint||"").trim();
    if(hint){
      if(/@c\.us$/i.test(hint)&&String(hint.split("@")[0]||"").replace(/\D/g,"")===expected)return hint;
      if(/@lid$/i.test(hint)){
        try{
          var engineHint=getSendEngine(),entry=engineHint&&engineHint.contact&&typeof engineHint.contact.getPnLidEntry==="function"?await engineHint.contact.getPnLidEntry(hint):null,pn=entry&&entry.phoneNumber,pnRaw=typeof pn==="string"?pn:(pn&&(pn._serialized||pn.id||pn.user)||""),hintPhone=String(pnRaw||"").replace(/@(?:c|g)\.us$/i,"").replace(/\D/g,"");
          if(hintPhone&&hintPhone===expected)return hint;
        }catch(_){}
      }
    }
    if (String(phoneNumber||"").indexOf("@") !== -1) return phoneNumber;


    var _extuiId = expected + "@c.us";
    try {
      var _extuiResolvedId = await verifyNumberExists(_extuiId);
      if (_extuiResolvedId === null) {
        throw new Error("Número não encontrado no WhatsApp: " + phoneNumber);
      }
      _extuiId = _extuiResolvedId;
    } catch (err) {
      throw new Error(err && err.message && err.message.indexOf("Número não encontrado") === 0 ? err.message : "Número inválido ou não encontrado no WhatsApp: " + phoneNumber);
    }
    return _extuiId;
  }

  async function loadItemContent(type, itemId) {
    var config = ITEM_STORAGE_BY_TYPE[type];
    if (!config) return null;
    var raw = await extStorageGet(config.key);
    var parsed = null;
    if (raw != null && raw !== "") {
      try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
      catch (err) { err.code = err.code || "BULK_ITEM_STORE_CORRUPT"; throw err; }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state)) { var invalidStore = new Error("A Biblioteca usada pelo disparo está corrompida e o envio foi bloqueado."); invalidStore.code = "BULK_ITEM_STORE_CORRUPT"; throw invalidStore; }
    }
    var list = (parsed && parsed.state && parsed.state[config.listField]) || [];
    var meta = null;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === itemId) { meta = list[i]; break; }
    }
    if (!meta) return null;


    var contentRaw = await extStorageGet(itemId);
    var content = null;
    if (contentRaw) {
      try {
        content = typeof contentRaw === "string" ? JSON.parse(contentRaw) : contentRaw;
      } catch (err) {
        err.code = err.code || "BULK_ITEM_CONTENT_CORRUPT"; throw err;
      }
      if (!content || typeof content !== "object" || Array.isArray(content)) { var invalidContent = new Error("O conteúdo do item usado no disparo está corrompido e o envio foi bloqueado."); invalidContent.code = "BULK_ITEM_CONTENT_CORRUPT"; throw invalidContent; }
    }
    return Object.assign({}, meta, content || {});
  }

  async function reliableDispatchWait(ms) {
    var bridge = window.__extReliableDelay;
    if (!bridge || typeof bridge.wait !== "function") throw bulkError("BULK_RELIABLE_DELAY_UNAVAILABLE", "O temporizador de envio não está disponível. Recarregue o WhatsApp Web antes de disparar.");
    await bridge.wait(Math.max(0, Number(ms) || 0));
  }

  async function waitForDispatch(ms, generation) {
    var remaining = Math.max(0, Number(ms) || 0);
    while (remaining > 0) {
      if (cancelled || generation !== processGeneration) return "cancelled";
      while (paused && !cancelled && generation === processGeneration) await reliableDispatchWait(500);
      if (cancelled || generation !== processGeneration) return "cancelled";
      var slice = Math.min(1000, remaining);
      await reliableDispatchWait(slice);
      remaining -= slice;
    }
    return cancelled || generation !== processGeneration ? "cancelled" : "success";
  }

  async function waitWhilePaused(generation) {
    while (paused && !cancelled && generation === processGeneration) await reliableDispatchWait(500);
    return cancelled || generation !== processGeneration ? "cancelled" : "success";
  }

  function requireBulkSafetyAttestation(item){var a=item&&item.safetyAttestation;if(!a||a.consentConfirmed!==true||a.optOutReviewed!==true||Number(a.policyRevision)<2)throw Object.assign(new Error("Esta fila não possui a revisão de consentimento exigida pela Proteção de Envio. Recrie o disparo."),{code:"SEND_SAFETY_CONSENT_REQUIRED"});}
  function bulkItemExecutionTimeoutMs(item){
    var actions=Array.isArray(item&&item.actions)?item.actions:[],declaredSeconds=0;
    actions.forEach(function(action){
      if(!action)return;
      var p=action.properties||{},type=String(action.type||"");
      if(type==="timer"||type==="composing"||type==="recording")declaredSeconds+=Math.max(0,Number(p.segundos)||0);
      declaredSeconds+=Math.max(0,Number(p.aguarde)||0)+Math.max(0,Number(p.composing)||0);
    });
    var budget=declaredSeconds*1000+Math.max(1,actions.length||1)*90000+30000;
    return Math.min(1800000,Math.max(120000,budget));
  }

  async function compileBulkSequenceActions(actions) {
    var compiled=[];
    for(var i=0;i<(Array.isArray(actions)?actions:[]).length;i++){
      var action=actions[i];
      if(!action||action.enabled===false)continue;
      var quickId=action&&action.type==="respostaRapida"&&action.properties&&action.properties.respostaRapidaID;
      var isNative=/^extapp-item:(?:message|audio|image|video|media|document|sticker|pix|interactive-list|contact):/.test(String(quickId||""));
      if(isNative&&window.__extQuickResponseService&&typeof window.__extQuickResponseService.resolve==="function"){
        var nested=await window.__extQuickResponseService.resolve(quickId);
        if(!Array.isArray(nested)||!nested.length){var nativeErr=new Error("O item salvo da Biblioteca não pôde ser resolvido para o disparo: "+String(quickId));nativeErr.code="BULK_NATIVE_ITEM_UNAVAILABLE";throw nativeErr;}
        for(var j=0;j<nested.length;j++){
          var child=nested[j]&&typeof nested[j]==="object"?Object.assign({},nested[j]):nested[j];
          if(child&&typeof child==="object"){
            child.properties=child.properties&&typeof child.properties==="object"?Object.assign({},child.properties):{};
            child.id=String(action.id||("step-"+i))+":native:"+String(j);
          }
          compiled.push(child);
        }
      }else compiled.push(action);
    }
    return compiled;
  }

  async function sendQueueItem(item,onQueueProgress) {
    requireBulkSafetyAttestation(item);
    var chatId = await resolveChatId(item.phoneNumber,item.chatIdHint);
    var isSelfRecipient = await bulkIsSelfRecipient(chatId,item.phoneNumber);

    if (Array.isArray(item.actions) && item.actions.length) {
      var sequenceExecutor = window.__extActionExecutor;
      if (!sequenceExecutor || typeof sequenceExecutor.execute !== "function") throw new Error("ActionExecutor indisponível para Disparo em massa");
      activeActionExecutionId = String(item.effectExecutionId || ("bulk:" + String(item.campaignId || "journey") + ":" + String(item.phoneNumber || "contact")));
      var compiledActions = await compileBulkSequenceActions(item.actions);
      if(!compiledActions.length){var emptyErr=new Error("Nenhuma ação ativa foi encontrada para este disparo.");emptyErr.code="BULK_SEQUENCE_EMPTY";throw emptyErr;}
      var totalActions=compiledActions.length,startIndex=Math.max(0,Math.min(totalActions,Math.floor(Number(item.actionNextIndex)||0)));
      item.actionCount=totalActions;
      item.actionSucceeded=Math.max(0,Math.min(totalActions,Math.floor(Number(item.actionSucceeded)||0)));
      item.actionFailed=Math.max(0,Math.floor(Number(item.actionFailed)||0));
      if(startIndex>=totalActions){item.actionSucceeded=totalActions;item.actionFailed=0;return{status:"success",results:[]};}
      var remainingActions=compiledActions.slice(startIndex),sequenceResult;
      try {
        sequenceResult = await sequenceExecutor.execute(remainingActions, { executionId: activeActionExecutionId, source: "bulk", contactId: chatId, remetente: chatId, isSelfRecipient:isSelfRecipient, variables: {}, campaignId: item.campaignId || broadcastRuntime.bulkHistoryId || null, onActionProgress:async function(evt){
          var localIndex=Math.max(0,Math.floor(Number(evt&&evt.index)||0)),globalIndex=Math.min(totalActions-1,startIndex+localIndex);
          if(evt&&evt.status==="success"){item.actionSucceeded=Math.max(item.actionSucceeded,globalIndex+1);item.actionFailed=0;item.actionNextIndex=globalIndex+1;item.lastActionId=evt.actionId||null;item.lastActionType=evt.type||null;}
          else if(evt&&evt.status==="error"){item.actionSucceeded=Math.max(item.actionSucceeded,globalIndex);item.actionFailed=1;item.actionNextIndex=globalIndex;item.lastActionId=evt.actionId||null;item.lastActionType=evt.type||null;}
          if(typeof onQueueProgress==="function")await onQueueProgress(item,evt);
        } });
      } finally {
        activeActionExecutionId = null;
      }
      if (!sequenceResult || sequenceResult.status !== "success") {
        var failedLocal=sequenceResult&&sequenceResult.monitor?Math.max(0,Number(sequenceResult.monitor.actionIndice)||0):Math.max(0,Number(sequenceResult&&sequenceResult.results&&sequenceResult.results.length)||0),failedGlobal=Math.min(totalActions-1,startIndex+failedLocal);
        item.actionSucceeded=Math.max(item.actionSucceeded,failedGlobal);item.actionFailed=1;item.actionNextIndex=failedGlobal;
        var sequenceDetail = sequenceResult && sequenceResult.error && sequenceResult.error.message ? sequenceResult.error.message : (sequenceResult && sequenceResult.status) || "erro desconhecido";
        var sequenceErr = new Error("ActionExecutor: " + sequenceDetail);
        sequenceErr.code = sequenceResult && sequenceResult.error && sequenceResult.error.code || "BULK_ACTION_ERROR";
        sequenceErr.effectDigest = sequenceResult && sequenceResult.error && sequenceResult.error.effectDigest || null;
        sequenceErr.remoteEffectSucceeded = sequenceResult && sequenceResult.error && sequenceResult.error.remoteEffectSucceeded === true;
        sequenceErr.actionSucceeded=item.actionSucceeded;sequenceErr.actionFailed=item.actionFailed;sequenceErr.actionNextIndex=item.actionNextIndex;
        throw sequenceErr;
      }
      item.actionSucceeded=totalActions;item.actionFailed=0;item.actionNextIndex=totalActions;
      return sequenceResult;
    }

    if (item.type === "flow") {
      if (typeof window.__extFluxosStartFlowManually !== "function") {
        throw new Error("O mecanismo de Fluxos ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");
      }
      return await window.__extFluxosStartFlowManually(item.itemId, chatId);
    }

    if (item.type === "funnel") {
      if (typeof window.__extFunnelsStartManually !== "function") {
        throw new Error("O mecanismo de Funis ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");
      }
      var funnelIdToStart = await resolveFunnelIdForStart(item.itemId);
      return await window.__extFunnelsStartManually(funnelIdToStart, chatId);
    }

    var e = await loadItemContent(item.type, item.itemId);
    if (!e) throw new Error("item not found in storage: " + item.itemId);

    var executor = window.__extActionExecutor;
    if (!executor || typeof executor.execute !== "function") throw new Error("ActionExecutor indisponível para Disparo em massa");
    var action;
    if (item.type === "message") {
      action = { type: "txt", properties: { mensagem: await applyMessageVariables(e.data, chatId), aguarde: 0, composing: 0 } };
    } else if (item.type === "audio") {
      action = { type: "audio", properties: { base64: e.data, composing: 0, isPtt: e.isPtt !== false, isViewOnce: !!e.asViewOnce } };
    } else if (item.type === "document") {
      action = { type: "doc", properties: { base64: e.data, base64Name: e.fileName || e.name || "documento" } };
    } else if (item.type === "sticker") {
      action = { type: "sticker", properties: { base64: e.data, mediaId: item.itemId } };
    } else if (item.type === "media" || item.type === "image" || item.type === "video") {
      var detectedMediaKind = e.sendAsDocument ? "document" : window.ExtensionChatBridge.mediaKind(e.data,{type:"auto-detect",mimeType:e.mimeType||e.type,filename:e.fileName||e.name});
      var mediaKind = (item.type === "image" || item.type === "video") && detectedMediaKind !== "document" ? item.type : detectedMediaKind;
      action = mediaKind === "document" ? { type: "doc", properties: { base64: e.data, base64Name: e.fileName || e.name || "arquivo" } } : { type: mediaKind, properties: { base64: e.data, mensagem: e.caption || "", aguarde: 0, composing: 0, isViewOnce: !!e.isViewOnce, microVideo: mediaKind === "video" && !!e.isPtv } };
    } else {
      throw new Error("unsupported type: " + item.type);
    }
    activeActionExecutionId = String(item.effectExecutionId || ("bulk:"+String(item.campaignId||"legacy")+":"+String(item.phoneNumber||item.itemId||"item")));
    var resultPromise = executor.execute([action], { executionId: activeActionExecutionId, source: "bulk", contactId: chatId, remetente: chatId, isSelfRecipient:isSelfRecipient, variables: {}, campaignId: item.campaignId || broadcastRuntime.bulkHistoryId || null });
    var result = await resultPromise;
    if (!result || result.status !== "success") {
      var detail = result && result.error && result.error.message ? result.error.message : (result && result.status) || "erro desconhecido";
      var actionErr=new Error("ActionExecutor: " + detail);
      actionErr.code=result&&result.error&&result.error.code||"BULK_ACTION_ERROR";
      actionErr.effectDigest=result&&result.error&&result.error.effectDigest||null;
      actionErr.remoteEffectSucceeded=result&&result.error&&result.error.remoteEffectSucceeded===true;
      throw actionErr;
    }
    activeActionExecutionId = null;
    return result;
  }

  function bulkRetryLimit(item) {
    return Math.max(1, Math.floor(Number(item && item.retryLimit) || 1));
  }

  function bulkRetryCount(item) {
    return Math.max(0, Math.floor(Number(item && item.retryCount) || 0));
  }

  function bulkPendingPass(item) {
    if (!item) return Infinity;
    if (item.state === "queued") return 0;
    if (item.state !== "retrying") return Infinity;
    var count = bulkRetryCount(item), limit = bulkRetryLimit(item);
    return count < limit ? count + 1 : Infinity;
  }

  function bulkNextPendingPass(queue) {
    var next = Infinity;
    (Array.isArray(queue) ? queue : []).forEach(function (item) {
      var pass = bulkPendingPass(item);
      if (pass < next) next = pass;
    });
    return next;
  }

  function bulkFailureRequiresReview(err) {
    if (err && err.remoteEffectSucceeded === true) return true;
    var code = String(err && err.code || "");
    if (/^SEND_EFFECT_(?:AMBIGUOUS|COMMIT_UNCERTAIN|ID_CONFLICT)$/.test(code) || code === "BULK_ITEM_EXEC_TIMEOUT") return true;
    return !!(window.__extSendSafetyManager && typeof window.__extSendSafetyManager.isDurableTerminalError === "function" && window.__extSendSafetyManager.isDurableTerminalError(err));
  }

  async function processQueue() {
    if (processing || paused || cancelled) return paused ? "paused" : (cancelled ? "cancelled" : "success");
    processing = true;
    broadcastRuntime.bulkProcessorLastError = null;
    var generation = ++processGeneration;
    var queue = [], bulkReadinessPassed = false;
    try {
      await ensureBulkProcessorReady();
      bulkReadinessPassed = true;
      queue = await readQueue();
      if(!Array.isArray(queue)||!queue.length)throw bulkError("BULK_QUEUE_EMPTY","Nenhum item pendente foi encontrado na fila de disparos.");
      while (!cancelled && generation === processGeneration) {
        if (await waitWhilePaused(generation) === "cancelled") break;
        var currentPass = bulkNextPendingPass(queue);
        if (!Number.isFinite(currentPass)) break;
        var progressed = false;
        for (var i = 0; i < queue.length; i++) {
          if (cancelled || generation !== processGeneration) break;
          if (await waitWhilePaused(generation) === "cancelled") break;
          var item = queue[i];
          if (!item || bulkPendingPass(item) !== currentPass) continue;
          progressed = true;
          var retryAttempt = currentPass > 0;
          item.state = "sending";
          item.delayStartedAt = Date.now();
          item.lastStatusAt = Date.now();
          item.lastErrorCode = null;
          item.lastErrorMessage = null;
          item.remoteEffectSucceeded = false;
          item.processorStage = retryAttempt ? "retry-executing" : "executing";
          await writeQueue(queue);
          if (await waitForDispatch(item.delayMs, generation) === "cancelled") break;
          try {
            if (await waitWhilePaused(generation) === "cancelled") break;
            item.lastStatusAt=Date.now();
            await writeQueue(queue);
            var actionAttemptToken=String(Date.now())+":"+String(i)+":"+String(currentPass);item.actionAttemptToken=actionAttemptToken;
            await bulkWithTimeout(sendQueueItem(item,async function(){if(item.actionAttemptToken!==actionAttemptToken||item.state!=="sending")return;item.lastStatusAt=Date.now();await writeQueue(queue);}),bulkItemExecutionTimeoutMs(item),"BULK_ITEM_EXEC_TIMEOUT","O envio ficou sem resposta por tempo demais e foi interrompido para evitar uma fila travada.");
            if (cancelled || generation !== processGeneration) break;
            item.state = "sent";
            item.processorStage="done";
            item.lastStatusAt=Date.now();
            try { if (window.__extSendSafetyManager && typeof window.__extSendSafetyManager.markRecipientTouched === "function") window.__extSendSafetyManager.markRecipientTouched(item.phoneNumber); } catch (_) {}
          } catch (err) {
            if (cancelled || generation !== processGeneration) break;
            item.attempts = (item.attempts || 0) + 1;
            item.lastErrorCode=err&&err.code||"BULK_ACTION_ERROR";
            item.lastErrorMessage=err&&err.message?String(err.message):"Falha ao executar a sequência.";
            item.lastEffectDigest=err&&err.effectDigest||null;
            item.remoteEffectSucceeded=err&&err.remoteEffectSucceeded===true;
            item.processorStage="failed";
            item.lastStatusAt=Date.now();
            var durableTerminal=bulkFailureRequiresReview(err);
            if (durableTerminal) {
              item.state = "error";
              item.durableReviewRequired = true;
            } else if (retryAttempt) {
              item.retryCount = bulkRetryCount(item) + 1;
              if (item.retryCount < bulkRetryLimit(item)) {
                item.state = "retrying";
                item.processorStage = "retry-deferred";
                item.durableReviewRequired = false;
              } else {
                item.state = "error";
                item.durableReviewRequired = false;
              }
            } else {
              item.retryCount = bulkRetryCount(item);
              item.state = bulkRetryLimit(item) > 0 ? "retrying" : "error";
              item.processorStage = item.state === "retrying" ? "retry-deferred" : "failed";
              item.durableReviewRequired = false;
            }
          }
          if (generation !== processGeneration) break;
          await writeQueue(queue);
          if (typeof window.__extActivityTrack === "function" && broadcastRuntime.bulkActivityId) {
            var _extuiCounts = computeSendStates(queue);
            window.__extActivityTrack({ action: "update", id: broadcastRuntime.bulkActivityId, current: _extuiCounts.sent + _extuiCounts.error, total: queue.length, status: paused ? "paused" : "running" });
          }
        }
        if (!progressed) break;
      }
      return paused ? "paused" : (cancelled ? "cancelled" : "success");
    } catch (err) {
      broadcastRuntime.bulkProcessorLastError=err&&err.code?err:bulkError("BULK_PROCESS_QUEUE_FAILED",err&&err.message||"Falha interna ao processar a fila.",err);
      reportRuntime("BULK_PROCESS_QUEUE_FAILED",broadcastRuntime.bulkProcessorLastError);
      if(bulkReadinessPassed){
        try{
          if(!queue.length)queue=await readQueue();
          var catastrophicMessage=broadcastRuntime.bulkProcessorLastError.message;
          queue.forEach(function(item){if(item&&(item.state==="queued"||item.state==="retrying"||item.state==="sending")){item.state="error";item.lastErrorCode=broadcastRuntime.bulkProcessorLastError.code||"BULK_PROCESS_QUEUE_FAILED";item.lastErrorMessage=catastrophicMessage;item.lastStatusAt=Date.now();}});
          if(queue.length)await writeQueue(queue);
        }catch(_){}
      }
      toast(broadcastRuntime.bulkProcessorLastError.message||"O processamento do disparo falhou.",true);
      return "error";
    } finally {
      if (generation !== processGeneration) return;
      processing = false;
      if (paused) return;
      var _extuiStillPending = queue.some(function (it) { return it && (it.state === "queued" || it.state === "retrying" || it.state === "sending"); });
      if (typeof window.__extActivityTrack === "function" && broadcastRuntime.bulkActivityId && !_extuiStillPending) {
        window.__extActivityTrack({ action: "success", id: broadcastRuntime.bulkActivityId });
        broadcastRuntime.bulkActivityId = null;
      }
      if (broadcastRuntime.bulkHistoryId && !_extuiStillPending) {
        await finalizeHistory(broadcastRuntime.bulkHistoryId, queue, false);
        broadcastRuntime.bulkHistoryId = null;
      }
    }
  }

  function computeSendStates(queue) {
    var result = { sent: 0, pending: 0, error: 0 };
    queue.forEach(function (item) {
      if (item.state === "sent") result.sent++;
      else if (item.state === "error") result.error++;
      else result.pending++;
    });
    return result;
  }

  function renderStatusStep(stepEl) {
    stepEl.innerHTML = [
      '<div class="extuiStatusCard">',
      '  <div class="extuiStatusCardTop">',
      '    <p id="extuiDisparosProgressSummary" class="extuiStatusMain">Iniciando envio...</p>',
      '    <div class="extuiClockBadge" id="extuiDisparosClockBadge" style="display:none"><span id="extuiDisparosClockValue">00:00</span></div>',
      '  </div>',
      '  <div class="extuiProgressBarTrack"><div class="extuiProgressBarFill" id="extuiDisparosProgressBar" style="width:0%"></div></div>',
      '</div>',
      '<div class="statusGrid">',
      '  <div class="cell"><div class="num" id="extuiStatSent">0</div><div class="label">Enviado</div></div>',
      '  <div class="cell"><div class="num" id="extuiStatPending">0</div><div class="label">Pendente</div></div>',
      '  <div class="cell"><div class="num" id="extuiStatError">0</div><div class="label">Erro</div></div>',
      '</div>',
      '<button class="secondary" id="extuiDisparosPauseBtn">Pausar envio</button>',
      '<button class="secondary" id="extuiDisparosCancelBtn">Cancelar envio</button>',
      '<button class="secondary" id="extuiDisparosNewDispatchBtn">Novo disparo</button>'
    ].join("\n");


    stepEl.querySelector("#extuiDisparosNewDispatchBtn").addEventListener("click", function () {
      clearInterval(statusPollTimer);
      statusPollTimer = null;
      state.invalidIgnored = 0; state.manualDuplicates = 0; state.labelDuplicates = 0;
      renderConfigStep(stepEl);
    });

    stepEl.querySelector("#extuiDisparosPauseBtn").addEventListener("click", async function () {
      var btn = this;
      if (paused) {
        await resumeCurrentDispatch();
        btn.textContent = "Pausar envio";
      } else {
        await pauseCurrentDispatch();
        btn.textContent = "Retomar envio";
      }
    });

    stepEl.querySelector("#extuiDisparosCancelBtn").addEventListener("click", async function () {
      await cancelCurrentDispatch();
      state.invalidIgnored = 0; state.manualDuplicates = 0; state.labelDuplicates = 0;


      renderConfigStep(stepEl);
    });

    async function pollStatus() {
      if (!document.getElementById("extuiDisparosProgressSummary")) { if(statusPollTimer){clearInterval(statusPollTimer);statusPollTimer=null;} return; }
      if (document.hidden && !processing && !paused) return;
      if (statusPollRunning) return;
      statusPollRunning = true;
      try {
        var queue = await readQueue();
        var counts = computeSendStates(queue);
        document.getElementById("extuiStatSent").textContent = counts.sent;
        document.getElementById("extuiStatPending").textContent = counts.pending;
        document.getElementById("extuiStatError").textContent = counts.error;
        var total = queue.length;
        var done = counts.sent + counts.error;
        var summaryEl = document.getElementById("extuiDisparosProgressSummary");
        var sendingItem = queue.find(function (item) { return item.state === "sending"; });
        var barEl = document.getElementById("extuiDisparosProgressBar");
        if (barEl) barEl.style.width = (total === 0 ? 0 : Math.round((done / total) * 100)) + "%";
        var clockBadge = document.getElementById("extuiDisparosClockBadge");
        var clockValue = document.getElementById("extuiDisparosClockValue");
        var _extuiRemainSec = 0;
        if (sendingItem && sendingItem.delayStartedAt) {
          var _extuiRemainMs = sendingItem.delayStartedAt + sendingItem.delayMs - Date.now();
          _extuiRemainSec = Math.max(0, Math.ceil(_extuiRemainMs / 1000));
        }
        if (clockBadge) clockBadge.style.display = (sendingItem && _extuiRemainSec > 0) ? "flex" : "none";
        if (clockValue && sendingItem && _extuiRemainSec > 0) {
          var _extuiMin = Math.floor(_extuiRemainSec / 60);
          var _extuiSec = _extuiRemainSec % 60;
          clockValue.textContent = (_extuiMin < 10 ? "0" : "") + _extuiMin + ":" + (_extuiSec < 10 ? "0" : "") + _extuiSec;
        }
        var pauseBtn = document.getElementById("extuiDisparosPauseBtn");
        if (pauseBtn) pauseBtn.textContent = paused ? "Retomar envio" : "Pausar envio";
        if (summaryEl) {
          if (paused) {
            summaryEl.textContent = "Disparo pausado — " + done + " de " + total + " processados.";
          } else if (total === 0) {
            summaryEl.textContent = "Nenhum envio em andamento.";
          } else if (sendingItem) {
            var _extuiWho = sendingItem.displayLabel || sendingItem.phoneNumber;
            if (_extuiRemainSec > 0) {
              summaryEl.textContent = "Próximo envio para " + _extuiWho + " (" + done + " de " + total + " processados)";
            } else {
              summaryEl.textContent = "Enviando agora para " + _extuiWho + "... (" + done + " de " + total + " processados)";
            }
          } else if (done >= total) {
            summaryEl.textContent = "Concluído: " + done + " de " + total + " processados.";
          } else {
            summaryEl.textContent = done + " de " + total + " processados — aguardando o próximo (intervalo configurado)...";
          }
        }
      } catch (err) {
        reportRuntime("BULK_STATUS_POLL_FAILED", err);
      } finally {
        statusPollRunning = false;
      }
    }

    pollStatus();
    if (statusPollTimer) clearInterval(statusPollTimer);
    statusPollTimer = setInterval(pollStatus, 1000);
  }



  


  broadcastRuntime.bulkWatchdogRunning = false;
  broadcastRuntime.bulkWatchdogTimer = null;
  function scheduleBulkWatchdog(queue){
    if(broadcastRuntime.bulkWatchdogTimer){clearTimeout(broadcastRuntime.bulkWatchdogTimer);broadcastRuntime.bulkWatchdogTimer=null;}
    if(!Array.isArray(queue))return;
    var now=Date.now(),nextAt=Infinity;
    queue.forEach(function(item){if(!item||item.state!=="sending"||!item.delayStartedAt)return;var due=Number(item.delayStartedAt)+(Math.max(0,Number(item.delayMs)||0))+60000;if(Number.isFinite(due))nextAt=Math.min(nextAt,due);});
    if(!Number.isFinite(nextAt))return;
    var delay=Math.max(1000,Math.min(2147483000,nextAt-now));
    broadcastRuntime.bulkWatchdogTimer=setTimeout(runBulkWatchdog,delay);
  }
  async function runBulkWatchdog(){
    if(broadcastRuntime.bulkWatchdogRunning)return;
    broadcastRuntime.bulkWatchdogRunning=true;
    broadcastRuntime.bulkWatchdogTimer=null;
    try {
      var queue = await readQueue();
      var changed = false;
      var now = Date.now();
      queue.forEach(function (item) {
        if (item.state === "sending" && item.delayStartedAt && (now - (Number(item.delayStartedAt) + Math.max(0,Number(item.delayMs)||0))) > 60000) {
          item.state = "queued";
          changed = true;
        }
      });
      if (changed) {
        await writeQueue(queue);
        if (!cancelled) processQueue();
      } else scheduleBulkWatchdog(queue);
    } catch (err) {
      reportRuntime("BULK_WATCHDOG_FAILED", err);
    } finally {
      broadcastRuntime.bulkWatchdogRunning=false;
    }
  }


  var REMOTE_CANCEL_KEY = "ext:bulkQueueCancelRequested";

  function bulkQueueHasActiveItems(queue) {
    return (Array.isArray(queue) ? queue : []).some(function (item) { return item && (item.state === "queued" || item.state === "retrying" || item.state === "sending"); });
  }

  function bulkRetryBlocked(item) {
    var code = String(item && item.lastErrorCode || "");
    return !!(item && (item.durableReviewRequired === true || item.remoteEffectSucceeded === true || code === "SEND_EFFECT_AMBIGUOUS" || code === "SEND_EFFECT_COMMIT_UNCERTAIN" || code === "SEND_EFFECT_ID_CONFLICT"));
  }

  async function reopenBulkTrackingForRetry(queue, batchId) {
    batchId = batchId || (queue[0] && queue[0].campaignId) || ("disparo-retry:" + Date.now());
    var list = await loadHistory();
    var idx = list.findIndex(function (row) { return row && String(row.id || "") === String(batchId); });
    if (idx < 0) {
      await recordHistoryStart(queue, batchId);
    } else {
      var sent = 0, failed = 0;
      var recipients = queue.map(function (item) {
        var status = item.state === "sent" ? "sent" : item.state === "error" ? "failed" : "pending";
        if (status === "sent") sent++; else if (status === "failed") failed++;
        return { phone: item.phoneNumber, status: status };
      });
      list[idx].finishedAt = null;
      list[idx].status = "running";
      list[idx].recipients = recipients;
      list[idx].sentCount = sent;
      list[idx].failedCount = failed;
      list[idx].cancelledCount = 0;
      await saveHistory(list);
    }
    broadcastRuntime.bulkHistoryId = batchId;
    if (typeof window.__extActivityTrack === "function") {
      broadcastRuntime.bulkActivityId = batchId;
      window.__extActivityTrack({ action: "start", id: batchId, type: "disparo", title: "Disparo em massa", targetLabel: queue.length + " contato(s)", current: 0, total: queue.length, status: "running" });
    }
    return batchId;
  }

  async function retryFailedDispatchItems(phoneNumbers) {
    var queue = await readQueue();
    if (!queue.length) return { accepted: false, retried: 0, blocked: 0, message: "A fila deste disparo não está mais disponível." };
    if (processing || bulkQueueHasActiveItems(queue)) throw bulkError("BULK_RETRY_WHILE_ACTIVE", "Aguarde o disparo atual terminar antes de reenviar as falhas.");
    var requested = new Set((Array.isArray(phoneNumbers) ? phoneNumbers : []).map(function (value) { return String(value || "").replace(/\D/g, ""); }).filter(Boolean));
    var candidates = queue.filter(function (item) {
      if (!item || item.state !== "error") return false;
      if (!requested.size) return true;
      return requested.has(String(item.phoneNumber || "").replace(/\D/g, ""));
    });
    var blocked = candidates.filter(bulkRetryBlocked);
    var eligible = candidates.filter(function (item) { return !bulkRetryBlocked(item); });
    if (!eligible.length) {
      return { accepted: false, retried: 0, blocked: blocked.length, message: blocked.length ? "O reenvio foi bloqueado por segurança porque a entrega anterior pode ter sido concluída. Revise o destinatário antes de tentar novamente." : "Não há falhas disponíveis para reenviar." };
    }
    var first = true;
    eligible.forEach(function (item) {
      item.state = "queued";
      item.attempts = 0;
      item.retryCount = 0;
      item.processorStage = "retry-requested";
      item.lastErrorCode = null;
      item.lastErrorMessage = null;
      item.lastEffectDigest = null;
      item.durableReviewRequired = false;
      item.remoteEffectSucceeded = false;
      item.delayStartedAt = null;
      if (first) { item.delayMs = 0; first = false; }
      item.lastStatusAt = Date.now();
    });
    cancelled = false;
    paused = false;
    broadcastRuntime.bulkProcessorLastError = null;
    await Promise.all([writeQueue(queue), extStorageSet(REMOTE_CANCEL_KEY, false), extStorageSet(REMOTE_PAUSE_KEY, false)]);
    var batchId = eligible[0] && eligible[0].campaignId || queue[0] && queue[0].campaignId || null;
    await reopenBulkTrackingForRetry(queue, batchId);
    processQueue().catch(function (err) { broadcastRuntime.bulkProcessorLastError = err; reportRuntime("BULK_RETRY_PROCESS_FAILED", err); });
    return { accepted: true, retried: eligible.length, blocked: blocked.length, campaignId: batchId, message: eligible.length === 1 ? "Reenvio iniciado." : eligible.length + " reenvios iniciados." };
  }

  function handleDashboardQueueControl(message, _sender, sendResponse) {
    if (!_sender || _sender.id !== chrome.runtime.id) return false;
    if (!message || message.type !== "EXTUI_DISPAROS_QUEUE_CONTROL") return false;
    var requestId = message.requestId, action = String(message.action || "");
    Promise.resolve().then(async function () {
      var queue = await readQueue();
      var active = bulkQueueHasActiveItems(queue);
      if (action === "pause") {
        if (!active) return { accepted: false, state: "idle", message: "Não há disparo em execução para pausar." };
        await pauseCurrentDispatch();
        return { accepted: true, state: "paused", message: "Disparo pausado." };
      }
      if (action === "resume") {
        if (!active) return { accepted: false, state: "idle", message: "Não há disparo pausado para retomar." };
        await resumeCurrentDispatch();
        return { accepted: true, state: "running", message: "Disparo retomado." };
      }
      if (action === "cancel") {
        if (!active) return { accepted: false, state: "idle", message: "O disparo já foi finalizado." };
        await extStorageSet(REMOTE_CANCEL_KEY, false);
        await cancelCurrentDispatch();
        return { accepted: true, state: "cancelled", message: "Disparo cancelado." };
      }
      if (action === "retry") return await retryFailedDispatchItems(message.phoneNumbers);
      throw bulkError("BULK_CONTROL_ACTION_INVALID", "Comando de controle do disparo inválido.");
    }).then(function (data) { sendResponse({ requestId: requestId, data: data }); }, function (err) {
      sendResponse({ requestId: requestId, error: { code: err && err.code || "BULK_CONTROL_FAILED", message: err && err.message || "Não foi possível controlar o disparo." } });
    });
    return true;
  }
  try { chrome.runtime.onMessage.addListener(handleDashboardQueueControl); } catch (err) { reportRuntime("BULK_QUEUE_CONTROL_LISTENER_FAILED", err); }

  function handleDashboardQueueStart(message,_sender,sendResponse){
    if(!_sender||_sender.id!==chrome.runtime.id)return false;
    if(!message||message.type!=="EXTUI_DISPAROS_QUEUE_START")return false;
    var requestId=message.requestId,campaignId=message.campaignId||null;
    Promise.resolve().then(async function(){
      cancelled=false;
      paused=false;
      broadcastRuntime.bulkProcessorLastError=null;
      await extStorageSet(REMOTE_PAUSE_KEY,false);
      var queue=await readQueue();
      if(!Array.isArray(queue)||!queue.length)throw bulkError("BULK_QUEUE_EMPTY","Nenhum item foi encontrado na fila de disparos.");
      campaignId=campaignId||queue[0]&&queue[0].campaignId||null;
      var rows=queue.filter(function(item){return item&&(!campaignId||String(item.campaignId||"")===String(campaignId));});
      if(!rows.length)throw bulkError("BULK_CAMPAIGN_QUEUE_MISSING","A fila desta campanha não foi encontrada no WhatsApp Web.");
      var failed=rows.find(function(item){return item.state==="error";});
      if(failed)throw bulkError(failed.lastErrorCode||"BULK_PROCESSOR_START_FAILED",failed.lastErrorMessage||"O processador de Disparos falhou ao iniciar.");
      var alreadyStarted=rows.some(function(item){return item.state==="sending"||item.state==="sent";});
      var pending=rows.filter(function(item){return item.state==="queued"||item.state==="retrying";});
      scheduleBulkWatchdog(queue);
      if(!broadcastRuntime.bulkActivityId&&!broadcastRuntime.bulkHistoryId)await startBulkTracking(rows,campaignId||undefined);
      if(!alreadyStarted&&pending.length)processQueue().catch(function(err){broadcastRuntime.bulkProcessorLastError=err;reportRuntime("BULK_PROCESS_QUEUE_START_FAILED",err);});
      var confirmed=alreadyStarted?{started:true,queue:rows}:await waitForBulkProcessorStart(campaignId);
      return{accepted:true,started:true,queued:pending.length,campaignId:campaignId,state:confirmed.queue.some(function(item){return item&&item.state==="sending";})?"sending":"sent"};
    }).then(function(data){sendResponse({requestId:requestId,data:data});},function(err){
      broadcastRuntime.bulkProcessorLastError=err;
      sendResponse({requestId:requestId,error:{code:err&&err.code||"BULK_QUEUE_START_FAILED",message:err&&err.message||"Não foi possível iniciar a fila de disparos."}});
    });
    return true;
  }
  try{chrome.runtime.onMessage.addListener(handleDashboardQueueStart);}catch(err){reportRuntime("BULK_QUEUE_START_LISTENER_FAILED",err);}


  broadcastRuntime.remoteQueueFailStreak = 0;
  broadcastRuntime.remoteQueueCheckRunning = false;
  async function checkRemoteQueueTick() {
    if (broadcastRuntime.remoteQueueCheckRunning) return;
    broadcastRuntime.remoteQueueCheckRunning = true;
    try {
      var controls = await Promise.all([extStorageGet(REMOTE_CANCEL_KEY), extStorageGet(REMOTE_PAUSE_KEY)]);
      var cancelReq = controls[0], pauseReq = !!controls[1];
      broadcastRuntime.remoteQueueFailStreak = 0;
      if (cancelReq) {
        await extStorageSet(REMOTE_CANCEL_KEY, false);
        await cancelCurrentDispatch();
        return;
      }
      if (pauseReq && !paused) await pauseCurrentDispatch();
      else if (!pauseReq && paused) await resumeCurrentDispatch();
      if (processing || paused) return;
      var queue = await readQueue();
      scheduleBulkWatchdog(queue);
      var hasPending = queue.some(function (it) { return it.state === "queued" || it.state === "retrying"; });
      if (hasPending) {
        cancelled = false;


        if (!broadcastRuntime.bulkActivityId && !broadcastRuntime.bulkHistoryId) await startBulkTracking(queue, queue[0] && queue[0].campaignId || undefined);
        processQueue();
      }
    } catch (err) {
      reportRuntime("BULK_REMOTE_QUEUE_CHECK_FAILED", err);
      broadcastRuntime.remoteQueueFailStreak++;
      if (broadcastRuntime.remoteQueueFailStreak < 3) {
      } else if (broadcastRuntime.remoteQueueFailStreak === 3) {
        toast("Conexão da extensão perdida nesta aba. Recarregue a página (F5) para corrigir.", true);
      }
    } finally {
      broadcastRuntime.remoteQueueCheckRunning = false;
    }
  }
  broadcastRuntime.remoteQueueCheckScheduled = false;
  function scheduleRemoteQueueCheck(){
    if(broadcastRuntime.remoteQueueCheckScheduled)return;
    broadcastRuntime.remoteQueueCheckScheduled=true;
    Promise.resolve().then(function(){broadcastRuntime.remoteQueueCheckScheduled=false;return checkRemoteQueueTick();}).catch(function(err){reportRuntime("BULK_REMOTE_QUEUE_CHECK_FAILED",err);});
  }
  if(window.ExtensionStorage&&typeof window.ExtensionStorage.subscribe==="function"){
    window.ExtensionStorage.subscribe(REMOTE_CANCEL_KEY,scheduleRemoteQueueCheck);
    window.ExtensionStorage.subscribe(REMOTE_PAUSE_KEY,scheduleRemoteQueueCheck);
    window.ExtensionStorage.subscribe(QUEUE_STORAGE_KEY,scheduleRemoteQueueCheck);
  }
  setInterval(checkRemoteQueueTick,30000);
  document.addEventListener("visibilitychange",scheduleRemoteQueueCheck);
  window.addEventListener("focus",scheduleRemoteQueueCheck);
  scheduleRemoteQueueCheck();

})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
