;(function(){
  "use strict";
  if (window.__extBroadcastShellEmbed) return;
  var ROOT_ID = "extapp-broadcast-shell-embed-root";
  var active = null;
  var previousFocus = null;
  var instance = "";
  var extensionOrigin = "chrome-extension://" + String(chrome.runtime && chrome.runtime.id || "");

  function uid(){ return "broadcast-embed-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2,10); }
  function state(){ return { active: !!(active && active.isConnected), instance: instance || null }; }
  function restoreFocus(){ var target=previousFocus; previousFocus=null; if(target&&target.isConnected&&typeof target.focus==="function") requestAnimationFrame(function(){try{target.focus({preventScroll:true});}catch(_){try{target.focus();}catch(__){}}}); }
  function close(){
    if (!active) return { ok:true, active:false };
    var root=active; active=null; instance="";
    window.removeEventListener("message", onMessage, true);
    document.removeEventListener("keydown", onKeydown, true);
    window.removeEventListener("pagehide", onPageHide, true);
    document.documentElement.classList.remove("extuiBroadcastShellEmbedOpen");
    try { if(root.tagName==="DIALOG"&&root.open&&typeof root.close==="function")root.close(); } catch (_) {}
    try { root.remove(); } catch (_) { if(root.parentNode) root.parentNode.removeChild(root); }
    restoreFocus();
    return { ok:true, active:false };
  }
  function onPageHide(){ close(); }
  function onKeydown(event){ if(event.key!=="Escape"||!active)return; event.preventDefault(); event.stopPropagation(); close(); }
  function onMessage(event){
    if(!active||!event||event.source!==active._extuiFrameWindow||event.origin!==extensionOrigin)return;
    var data=event.data;
    if(!data||data.__extBroadcastEmbed!==true||data.action!=="close"||String(data.instance||"")!==instance)return;
    close();
  }
  function makeButton(){
    var button=document.createElement("button"); button.type="button"; button.className="extuiBroadcastShellEmbedClose"; button.setAttribute("aria-label","Fechar Disparos e voltar ao WhatsApp"); button.setAttribute("title","Fechar Disparos"); button.textContent="×"; button.setAttribute("aria-hidden","false");
    button.addEventListener("click",close); return button;
  }
  function open(){
    if(active&&active.isConnected){ var existingClose=active.querySelector(".extuiBroadcastShellEmbedClose"); if(existingClose)existingClose.focus(); return Promise.resolve({ok:true,active:true,reused:true}); }
    previousFocus=document.activeElement&&document.activeElement!==document.body?document.activeElement:null;
    instance=uid();
    var root=document.createElement("dialog"); root.id=ROOT_ID; root.className="extuiBroadcastShellEmbed"; root.setAttribute("aria-label","Disparos");
    var frame=document.createElement("iframe"); frame.className="extuiBroadcastShellEmbedFrame"; frame.title="Disparos"; frame.setAttribute("referrerpolicy","no-referrer");
    var url=chrome.runtime.getURL("pages/dashboard/disparos-embed.html");
    var params=new URLSearchParams({embed:"whatsapp",expanded:"1",embedInstance:instance});
    frame.src=url+"?"+params.toString();
    root.appendChild(frame); root.appendChild(makeButton());
    root.addEventListener("cancel",function(event){event.preventDefault();close();});
    active=root; root._extuiFrameWindow=null;
    frame.addEventListener("load",function(){ if(active===root)root._extuiFrameWindow=frame.contentWindow; },{once:true});
    document.documentElement.classList.add("extuiBroadcastShellEmbedOpen");
    document.body.appendChild(root);
    if(typeof root.showModal==="function")root.showModal();else root.setAttribute("open","");
    root._extuiFrameWindow=frame.contentWindow;
    window.addEventListener("message",onMessage,true);
    document.addEventListener("keydown",onKeydown,true);
    window.addEventListener("pagehide",onPageHide,true);
    return Promise.resolve({ok:true,active:true,instance:instance});
  }
  window.__extBroadcastShellEmbed=Object.freeze({open:open,close:close,state:state});
})();
