;
try{


(function(){
  "use strict";
  if(window.__extAutoServiceBooted)return;window.__extAutoServiceBooted=true;
  var STORE_KEY="EXTUI:extappAutoServiceStore",CRM_KEY="EXTUI:CrmStore";
  var updateMutex=Promise.resolve();
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function parse(raw,code,message){if(raw==null||raw==="")return null;var parsed=raw;if(typeof raw==="string"){try{parsed=JSON.parse(raw);}catch(err){err.code=code||"AUTO_SERVICE_STORE_CORRUPT";throw err;}}if(!parsed||typeof parsed!=="object"||Array.isArray(parsed)){var invalid=new Error(message||"Os dados da automação estão inválidos e não serão sobrescritos.");invalid.code=code||"AUTO_SERVICE_STORE_CORRUPT";throw invalid;}return parsed;}
  function extractRules(parsed){if(!parsed)return[];var s=parsed.state&&typeof parsed.state==="object"&&!Array.isArray(parsed.state)?parsed.state:parsed;var rules=s.rules||s.triggerList||s.triggers||s.autoAtendimentoList||s.list||[];if(!Array.isArray(rules)){var invalid=new Error("As regras de atendimento automático estão inválidas e não serão sobrescritas.");invalid.code="AUTO_SERVICE_STORE_CORRUPT";throw invalid;}return rules;}
  async function loadRules(){var c=parse(await repo().get(STORE_KEY),"AUTO_SERVICE_STORE_CORRUPT","As regras de atendimento automático estão inválidas e não serão sobrescritas.")||{schemaVersion:1,rules:[]},rules=extractRules(c);return {key:STORE_KEY,parsed:c,rules:rules,canonical:true};}
  function isActive(r){return r&&r.active!==false&&!(r.propriedades&&r.propriedades.active===false)&&r.enabled!==false;}
  function actionList(r){return Array.isArray(r.acao)?r.acao:Array.isArray(r.actions)?r.actions:Array.isArray(r.action)?r.action:[];}
  function acc(r){return r&&r.acionamento||r&&r.trigger||{};}
  function triggerType(r){var a=acc(r);return String(a.type||a.tipo||r.triggerType||"");}
  function triggerValues(r){var a=acc(r),p=a.propriedades||a.properties||{};var v=p.values||p.keywords||p.palavras||p.messages||p.mensagens||p.value||p.valor||p.message||p.mensagem||a.values||a.value||a.valor||r.keywords||r.keyword||r.message||[];if(Array.isArray(v))return v.map(String).filter(Boolean);if(v&&typeof v==="object")return Object.values(v).flat().map(String).filter(Boolean);return String(v||"").split(/\r?\n|,/).map(function(x){return x.trim();}).filter(Boolean);}
  function bodyOf(data){return String(data&&((data.body!=null&&data.body)||(data.caption!=null&&data.caption)||(data.text!=null&&data.text))||"");}
  function jidOf(data){var x=data&&data.from||data&&data.author||data&&data.chatId||"";return x&&x._serialized||String(x||"");}
  async function messageIdentity(data,jid){var id=data&&data.id,raw=id&&(id._serialized||id.id)||data&&data.msgID||data&&data.messageId||"";if(raw)return String(raw);var stamp=Number(data&&(data.t||data.timestamp||data.messageTimestamp)||0),body=bodyOf(data),cryptoApi=window.crypto;if(!cryptoApi||!cryptoApi.subtle)throw Object.assign(new Error("Não foi possível gerar a identidade segura da mensagem recebida."),{code:"AUTO_MESSAGE_IDENTITY_UNAVAILABLE"});var bytes=new TextEncoder().encode(String(jid||"")+"|"+String(stamp||0)+"|"+String(body||"")),hash=await cryptoApi.subtle.digest("SHA-256",bytes);return "fallback:"+Array.from(new Uint8Array(hash)).map(function(b){return b.toString(16).padStart(2,"0");}).join("");}
  function isGroup(jid){return String(jid).indexOf("@g.us")>=0;}
  function ruleObj(rule,name){var r=rule&&rule.regras||rule&&rule.rules||{};return r[name]||{};}
  function boolRule(rule,names,defaultValue){for(var i=0;i<names.length;i++){var o=ruleObj(rule,names[i]);if(typeof o==="boolean")return o;if(o&&typeof o==="object"){if(o.active!=null)return !!o.active;if(o.propriedades&&o.propriedades.active!=null)return !!o.propriedades.active;if(o.properties&&o.properties.active!=null)return !!o.properties.active;}}return defaultValue;}
  function listRule(rule,names,fields){for(var i=0;i<names.length;i++){var o=ruleObj(rule,names[i]);if(!o)continue;for(var j=0;j<fields.length;j++){var v=o[fields[j]]||(o.propriedades&&o.propriedades[fields[j]])||(o.properties&&o.properties[fields[j]]);if(Array.isArray(v))return v.map(String);}}return[];}
  function timeToMinutes(v){if(typeof v==="number")return v;var m=String(v||"").match(/^(\d{1,2}):(\d{2})$/);return m?(+m[1])*60+(+m[2]):null;}
  function scheduleAllows(rule,at){var o=ruleObj(rule,"horario")||ruleObj(rule,"schedule")||ruleObj(rule,"horarios");if(!o||(!o.active&&!o.propriedades&&!o.properties))return true;var p=o.propriedades||o.properties||o;if(o.active===false||p.active===false)return true;var days=p.days||p.weekDays||p.diasSemana||p.dias;if(Array.isArray(days)&&days.length){var d=at.getDay();if(!days.map(Number).includes(d)&&!days.map(String).includes(String(d)))return false;}var start=timeToMinutes(p.start||p.inicio||p.from),end=timeToMinutes(p.end||p.fim||p.to);if(start==null||end==null)return true;var cur=at.getHours()*60+at.getMinutes();return start<=end?(cur>=start&&cur<=end):(cur>=start||cur<=end);}
  async function getChat(jid){if(!window.__extWppBridge)throw Object.assign(new Error("O WhatsApp ainda não está pronto para validar as regras do atendimento automático."),{code:"AUTO_SERVICE_WPP_UNAVAILABLE"});return await window.__extWppBridge.invoke("Chat","get",jid);}
  async function activeChatId(){if(!window.__extWppBridge)throw Object.assign(new Error("O WhatsApp ainda não está pronto para validar a conversa ativa."),{code:"AUTO_SERVICE_WPP_UNAVAILABLE"});var x=await window.__extWppBridge.invoke("Chat","getActiveChat","@");return x&&x._serialized||String(x||"");}
  function chatLabels(chat){var raw=chat&&(chat.labels||chat.labelIds||chat.__x_labels)||[];if(raw&&raw._models)raw=raw._models;return(Array.isArray(raw)?raw:[]).map(function(x){return String(x&& (x.id&&x.id._serialized||x.id||x.labelId)||x);});}
  async function crmMembership(jid){if(window.__extCrmLabelService&&window.__extCrmLabelService.crm&&typeof window.__extCrmLabelService.crm.listMemberships==="function")return await window.__extCrmLabelService.crm.listMemberships(jid);var raw=String(jid||"");if(/@lid$/i.test(raw))throw Object.assign(new Error("Não foi possível validar o vínculo do contato com o CRM."),{code:"AUTO_SERVICE_CRM_LOOKUP_UNAVAILABLE"});var p=parse(await repo().get(CRM_KEY),"AUTO_SERVICE_CRM_STORE_CORRUPT","Os dados do CRM estão inválidos e não serão usados pela automação."),s=p&&p.state;if(p&&!s){var stateErr=new Error("Os dados do CRM não possuem um estado válido.");stateErr.code="AUTO_SERVICE_CRM_STORE_CORRUPT";throw stateErr;}var crms=Array.isArray(s&&s.crmList)?s.crmList:[],d=raw.replace(/@.*/,"").replace(/\D/g,""),hits=[];crms.forEach(function(crm){(crm.columns||[]).forEach(function(col){(col.items||[]).forEach(function(it){var c=it.contact||it,cd=String(c.phoneNumber||c.chatId||c.id||"").replace(/@.*/,"").replace(/\D/g,"");if(cd&&d&&cd===d)hits.push({crmId:crm.id,columnId:col.id});});});});return hits;}
  async function rulesAllow(rule,data,jid){
    if(isGroup(jid)&&!boolRule(rule,["responderGrupos","replyGroups"],false))return {ok:false,reason:"groups_disabled"};
    if(!scheduleAllows(rule,new Date()))return {ok:false,reason:"outside_schedule"};
    var ignoreOpen=boolRule(rule,["ignorarChatAberto","ignoreOpenChat","naoResponderChatAberto"],false);if(ignoreOpen&&await activeChatId()===jid)return {ok:false,reason:"active_chat"};
    var ignoreArchived=boolRule(rule,["ignorarArquivados","ignoreArchived"],false),black=listRule(rule,["labelsBlacklist","blacklistLabels","etiquetasBlacklist"],["ids","labels","labelIds"]),white=listRule(rule,["labelsWhitelist","whitelistLabels","etiquetasWhitelist"],["ids","labels","labelIds"]),chat=null,labels=[];
    if(ignoreArchived||black.length||white.length){chat=await getChat(jid);if(!chat)throw Object.assign(new Error("Não foi possível validar o estado da conversa para aplicar as regras."),{code:"AUTO_SERVICE_CHAT_LOOKUP_FAILED"});labels=chatLabels(chat);}
    if(ignoreArchived&&(chat.archive===true||chat.archived===true||chat.isArchived===true))return {ok:false,reason:"archived"};
    if(black.some(function(x){return labels.indexOf(x)>=0;}))return {ok:false,reason:"label_blacklist"};if(white.length&&!white.some(function(x){return labels.indexOf(x)>=0;}))return {ok:false,reason:"label_whitelist"};
    var ignoreAnyCrm=boolRule(rule,["ignorarQualquerCRM","excludeAnyCrm"],false),ex=listRule(rule,["crmExclusao","excludeCrm","crmsExclusao"],["ids","crmIds"]),req=listRule(rule,["crmObrigatorio","requireCrm","crmsObrigatorios"],["ids","crmIds"]),membership=[],crmIds=[];
    if(ignoreAnyCrm||ex.length||req.length){membership=await crmMembership(jid);crmIds=membership.map(function(x){return String(x.crmId);});}
    if(ignoreAnyCrm&&membership.length)return {ok:false,reason:"in_any_crm"};
    if(ex.some(function(x){return crmIds.indexOf(x)>=0;}))return {ok:false,reason:"excluded_crm"};
    if(req.length&&!req.some(function(x){return crmIds.indexOf(x)>=0;}))return {ok:false,reason:"required_crm_missing"};
    return {ok:true,chat:chat,labels:labels,crm:membership};
  }
  async function history(jid,count){if(!window.__extWppBridge)throw Object.assign(new Error("O histórico do WhatsApp ainda não está disponível."),{code:"AUTO_SERVICE_HISTORY_UNAVAILABLE"});var x=await window.__extWppBridge.invoke("Chat","getMessages",{id:jid,quant:count||20,disabledAwaitHydrate:false}),list=Array.isArray(x)?x:(x&&x.messages||x&&x.msgs);if(!Array.isArray(list))throw Object.assign(new Error("O WhatsApp não retornou um histórico válido para a automação."),{code:"AUTO_SERVICE_HISTORY_INVALID"});return list;}
  function msgTs(m){var n=Number(m&&(m.t||m.timestamp||m.messageTimestamp)||0);return n<1e11?n*1000:n;}
  function relevant(m){var type=String(m&&m.type||"chat");return ["notification_template","e2e_notification","gp2","protocol"].indexOf(type)<0;}
  async function matches(rule,data,jid){var type=triggerType(rule),body=bodyOf(data),vals=triggerValues(rule);
    if(type==="message_Received")return vals.length?vals.some(function(v){return body===v;}):false;
    if(type==="keyword")return vals.length?vals.some(function(v){return body.toLowerCase().indexOf(v.toLowerCase())>=0;}):false;
    if(type==="day_Message"){var h=(await history(jid,30)).filter(relevant).filter(function(m){return !(m.fromMe||m.id&&m.id.fromMe);});var today=new Date();today.setHours(0,0,0,0);var currentId=data.id&& (data.id._serialized||data.id.id)||data.msgID;var previous=h.filter(function(m){var id=m.id&&(m.id._serialized||m.id.id)||m.msgID;return !currentId||String(id)!==String(currentId);}).sort(function(a,b){return msgTs(b)-msgTs(a);})[0];return !previous||msgTs(previous)<today.getTime();}
    if(type==="customer_Message"){var hh=(await history(jid,50)).filter(relevant).filter(function(m){return !(m.fromMe||m.id&&m.id.fromMe);});return hh.length<=1;}
    return false;
  }
  async function _e0(rule){var feature=rule.requiredFeature||rule.entitlement;if(!feature)return true;var service=window.__extS0;if(!service||typeof service._n!=="function")return false;try{return await service._n(feature);}catch(_){return false;}}
  function applySignature(rule,actions){var s=rule.assinatura||rule.signature;if(!s||s.active===false)return actions;var text=String(s.texto||s.text||s.value||"");if(!text)return actions;return actions.map(function(a){if(String(a.type)!=="txt")return a;var x=JSON.parse(JSON.stringify(a)),p=x.properties||x;p.mensagem=String(p.mensagem||p.msg||p.text||"")+"\n"+text;return x;});}
  function incrementUsage(source,rule){updateMutex=updateMutex.then(async function(){var raw=await repo().get(STORE_KEY),current=parse(raw,"AUTO_SERVICE_STORE_CORRUPT","As regras de atendimento automático estão inválidas e não serão sobrescritas.")||{schemaVersion:1,rules:[]},rules=extractRules(current),target=rules.find(function(x){return x&&x.id===rule.id;});if(!target)return;target.usedLenght=(Number(target.usedLenght)||0)+1;await repo().set(STORE_KEY,typeof raw==="string"?JSON.stringify(current):current);}).catch(function(e){if(window.__extReportRuntimeError)window.__extReportRuntimeError("AUTO_SERVICE_USAGE_PERSIST_FAILED",e);});return updateMutex;}
  function emit(name,payload){try{if(window.__extEventBus)window.__extEventBus.emit(name,payload,{source:"auto-service"});}catch(_){}}
  async function handleMessage(payload){if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return;var data=payload&&payload.data||payload||{},jid=jidOf(data);if(!jid)return;var source=await loadRules();for(var i=0;i<source.rules.length;i++){var rule=source.rules[i];if(!isActive(rule))continue;try{var allowed=await rulesAllow(rule,data,jid);if(!allowed.ok){emit("AutoServiceRuleSkipped",{automationId:rule.id,reason:allowed.reason});continue;}if(!await matches(rule,data,jid))continue;if(!await _e0(rule)){emit("AutoServiceRuleSkipped",{automationId:rule.id,reason:"entitlement"});continue;}var actions=applySignature(rule,actionList(rule));if(!actions.length){emit("AutoServiceRuleBlocked",{automationId:rule.id,reason:"actions_missing"});continue;}var result=await window.__extActionExecutor.execute(actions,{source:"auto-service",contactId:jid,remetente:jid,automationId:rule.id,executionId:"auto:"+String(rule.id)+":"+await messageIdentity(data,jid),variables:{message:bodyOf(data)}});if(result.status!=="success"){emit("AutoServiceFailed",{automationId:rule.id,error:result.error});continue;}await incrementUsage(source,rule);emit("AutoServiceTriggered",{automationId:rule.id,name:rule.nome||rule.name||"",jid:jid,trigger:triggerType(rule)});if(typeof window.__extFireWebhook==="function")window.__extFireWebhook("autoAtendimento",jid,{automationId:rule.id,name:rule.nome||rule.name||"",trigger:triggerType(rule)});}catch(err){emit("AutoServiceFailed",{automationId:rule&&rule.id,error:err&&err.message||String(err)});}}}
  var autoServiceRuntime = { started: false, waitingForBus: false };

  function start(){
    if(autoServiceRuntime.started)return true;
    if(!window.__extEventBus){
      if(!autoServiceRuntime.waitingForBus){
        autoServiceRuntime.waitingForBus=true;
        window.addEventListener("ext:eventbus-ready",function(){autoServiceRuntime.waitingForBus=false;start();},{once:true});
      }
      return false;
    }
    autoServiceRuntime.started=true;
    window.__extEventBus.on("MessageReceived",handleMessage);
    return true;
  }
  var api=Object.freeze({version:"1.1.0",storeKey:STORE_KEY,loadRules:loadRules,handleMessage:handleMessage,matches:matches,scheduleAllows:scheduleAllows,rulesAllow:rulesAllow,start:start});window.__extAutoService=api;window.ExtensionCore=window.ExtensionCore||{};start();
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
