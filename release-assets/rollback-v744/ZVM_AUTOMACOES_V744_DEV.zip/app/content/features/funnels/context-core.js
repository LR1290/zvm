;
try{


(function(){
  "use strict";
  if(window.__extWppIsolatedContextBooted)return;
  window.__extWppIsolatedContextBooted=true;

  var bridge=window.__extWppBridge;
  var lastPublished=Object.create(null);
  var allContactsCache=null;
  var allContactsCacheAt=0;
  var CONTACT_CACHE_TTL_MS=30000;
  var contextRefreshPromise=null;
  function storageGet(key){if(window.ExtensionStorage)return window.ExtensionStorage.get(key);return chrome.storage.local.get(key).then(function(o){return o&&o[key];});}
  function storageSet(key,value){if(window.ExtensionStorage)return window.ExtensionStorage.set(key,value);var o={};o[key]=value;return chrome.storage.local.set(o);}
  function publish(key,value){if(lastPublished[key]===value)return Promise.resolve();lastPublished[key]=value;return storageSet(key,value).catch(function(){});}
  function idSerialized(id){if(!id)return"";if(typeof id==="string")return id;return String(id._serialized||id.id||"");}
  function idUser(id){if(!id)return"";if(typeof id==="object"&&id.user!=null)return String(id.user);var s=idSerialized(id);return s.indexOf("@")>0?s.split("@")[0]:s.replace(/\D/g,"");}
  function idServer(id){if(id&&typeof id==="object"&&id.server)return String(id.server);var s=idSerialized(id);return s.indexOf("@")>0?s.split("@")[1]:"";}
  function isGroupId(id){var server=idServer(id),s=idSerialized(id);return server==="g.us"||/@g\.us$/i.test(s);}
  function ensureReady(){if(!bridge)return Promise.reject(new Error("A conexão com o WhatsApp não está disponível"));if(bridge.isReady&&bridge.isReady())return Promise.resolve(true);return bridge.waitUntilReady(45000);}

  function refreshContext(){
    if(!bridge)return Promise.resolve();
    if(contextRefreshPromise)return contextRefreshPromise;
    contextRefreshPromise=(async function(){
      try{
        await ensureReady();
        var me=await bridge.invoke("Conn","getMyUserId",null).catch(function(){return null;});
        var phone=idUser(me)||null;
        await Promise.all([publish("EXTUI:wppStatus","ready"),publish("EXTUI:wppPhoneNumber",phone)]);
        try{document.dispatchEvent(new CustomEvent("wppconnect_ready",{detail:{source:"extapp-isolated"}}));}catch(_){}
      }catch(_){
        await publish("EXTUI:wppStatus","initializing");
      }
    })();
    return contextRefreshPromise.finally(function(){contextRefreshPromise=null;});
  }
  publish("EXTUI:wppStatus","initializing");
  function invalidateContactCache(){allContactsCache=null;allContactsCacheAt=0;}
  if(bridge&&bridge.on){
    bridge.on("webpack.full_ready",refreshContext);
    bridge.on("conn.stream_info_changed",function(){invalidateContactCache();refreshContext();});
  }
  function onWppReadiness(event){
    var detail=event&&event.detail||{};
    if(detail.ready===false&&detail.fullReady===false){publish("EXTUI:wppStatus","initializing");return;}
    refreshContext();
  }
  function startContextReadiness(){
    refreshContext();
    window.addEventListener("ext:wpp-readiness",onWppReadiness);
  }
  if(window.__extBootPhases&&typeof window.__extBootPhases.when==="function")window.__extBootPhases.when(2,startContextReadiness);else startContextReadiness();

  function findCrmPhone(raw,crmContactId){
    var parsed=raw;try{if(typeof parsed==="string")parsed=JSON.parse(parsed);}catch(_){parsed=null;}
    var state=parsed&&parsed.state||parsed||{},crmList=Array.isArray(state.crmList)?state.crmList:[];
    for(var i=0;i<crmList.length;i++){var columns=Array.isArray(crmList[i].columns)?crmList[i].columns:[];for(var j=0;j<columns.length;j++){var items=Array.isArray(columns[j].items)?columns[j].items:[];for(var k=0;k<items.length;k++){var item=items[k];if(item&&item.id===crmContactId)return String(item.contact&&item.contact.phoneNumber||"").replace(/\D/g,"")||null;}}}
    return null;
  }

  async function resolveChatIdByPhone(phoneNumber){
    var expected=String(phoneNumber||"").replace(/\D/g,"");if(!expected)return null;
    var chats=await bridge.invoke("Chat","List",{});chats=Array.isArray(chats)?chats:[];
    for(var i=0;i<chats.length;i++){
      var chat=chats[i],id=chat&&chat.id;if(!id||isGroupId(id))continue;
      var serialized=idSerialized(id),candidate=idServer(id)==="c.us"?idUser(id):null;
      if(!candidate&&/@lid$/i.test(serialized)){
        try{var entry=await bridge.invoke("Contact","getPnLidEntry",serialized);candidate=entry&&entry.phoneNumber&&(entry.phoneNumber.id||entry.phoneNumber.user)||idUser(entry&&entry.phoneNumber);}catch(_){candidate=null;}
      }
      if(String(candidate||"").replace(/\D/g,"")===expected)return serialized;
    }
    return null;
  }

  async function crmCopilotContext(msg){
    var raw=await storageGet("EXTUI:CrmStore"),phone=findCrmPhone(raw,String(msg.crmContactId||"").slice(0,160));
    if(!phone)throw new Error("Contato atual sem telefone resolvido.");
    var chatId=await resolveChatIdByPhone(phone);if(!chatId)throw new Error("A conversa deste contato não foi encontrada no WhatsApp.");
    var contextCore=window.__extAiConversationContext;
    if(contextCore&&typeof contextCore.fetchRecent==="function"){
      return contextCore.fetchRecent({chatId:chatId,messageCount:Number(msg.messageCount)||5,getMessages:function(resolvedChatId,options){return bridge.invoke("Chat","getMessages",{id:resolvedChatId,quant:options&&options.count||50,disabledAwaitHydrate:false});}});
    }
    var messages=await bridge.invoke("Chat","getMessages",{id:chatId,quant:Number(msg.messageCount)||5,disabledAwaitHydrate:false});
    return Array.isArray(messages)?messages:[];
  }

  async function mapLimit(list,limit,worker){
    var out=new Array(list.length),cursor=0;
    async function run(){while(true){var index=cursor++;if(index>=list.length)return;out[index]=await worker(list[index],index);}}
    var workers=[];for(var i=0;i<Math.min(limit,list.length);i++)workers.push(run());
    await Promise.all(workers);return out;
  }
  async function crmFetchContacts(){
    await ensureReady();
    var base=await bridge.invoke("Contact","ListForCrm",{});
    base=Array.isArray(base)?base:[];
    return mapLimit(base,6,async function(b){
      b=b||{};var avatar=null;
      try{if(b.idStr)avatar=await bridge.invoke("Contact","getProfilePictureUrl",b.idStr);}catch(_){}
      return {name:String(b.name||""),phoneNumber:b.phoneNumber==null?null:String(b.phoneNumber),avatar:avatar||null};
    });
  }

  async function fetchLabels(){await ensureReady();var labels=await bridge.invoke("Labels","getAllLabels",null);return (labels||[]).map(function(l){return{id:l.id,name:l.name};});}
  async function searchContacts(query){await ensureReady();if(!allContactsCache||Date.now()-allContactsCacheAt>CONTACT_CACHE_TTL_MS){allContactsCache=await bridge.invoke("Contact","ListPlain",{});allContactsCache=Array.isArray(allContactsCache)?allContactsCache:[];allContactsCacheAt=Date.now();}var me=null,mySerialized="",myPhone="";try{me=await bridge.invoke("Conn","getMyUserId",null);mySerialized=idSerialized(me);myPhone=idUser(me).replace(/\D/g,"");if(/@lid$/i.test(mySerialized)){try{var ownEntry=await bridge.invoke("Contact","getPnLidEntry",mySerialized),ownPn=ownEntry&&ownEntry.phoneNumber;myPhone=idUser(ownPn).replace(/\D/g,"")||myPhone;}catch(_){}}}catch(_){}var term=String(query||"").trim().toLowerCase(),seen=Object.create(null),out=[],selfRow=null;function matches(c,phone,label){if(!term)return true;return String(label||c&&c.name||"").toLowerCase().indexOf(term)!==-1||String(phone||c&&c.phoneNumber||"").indexOf(term)!==-1;}for(var i=0;i<allContactsCache.length;i++){var c=allContactsCache[i]||{},serialized=String(c.idStr||""),phone=String(c.phoneNumber||"").replace(/\D/g,"");if(!serialized||/@g\.us$/i.test(serialized))continue;var isSelf=!!((myPhone&&phone===myPhone)||(mySerialized&&serialized===mySerialized));var label=isSelf?"Eu mesmo":String(c.name||phone||serialized);if(!matches(c,phone,label))continue;var key=phone||serialized;if(seen[key])continue;seen[key]=true;var row={value:serialized,chatId:serialized,phoneNumber:phone||null,label:label,displayNumber:phone||serialized,isSelf:isSelf};if(isSelf)selfRow=row;else out.push(row);}if(!selfRow&&mySerialized&&matches(null,myPhone,"Eu mesmo")){var selfKey=myPhone||mySerialized;if(!seen[selfKey])selfRow={value:mySerialized,chatId:mySerialized,phoneNumber:myPhone||null,label:"Eu mesmo",displayNumber:myPhone||mySerialized,isSelf:true};}if(selfRow)out.unshift(selfRow);return out;}
  async function validateNumber(number){await ensureReady();var digits=String(number||"").replace(/\D/g,"");if(digits.length<8||digits.length>17)return{valid:false,resolvedId:null};var found=await bridge.invoke("Contact","queryExists",digits+"@c.us"),resolved=found&&((found.lid&&idSerialized(found.lid))||(found.wid&&idSerialized(found.wid)))||null;return{valid:!!resolved,resolvedId:resolved};}
  async function resolveRecipientIdentity(raw){await ensureReady();var value=String(raw||"").trim(),serialized=/@(?:c|g)\.us$|@lid$/i.test(value)?value:"",digits=serialized&&!/@lid$/i.test(serialized)?idUser(serialized):value.replace(/\D/g,"");if(/@lid$/i.test(serialized)){try{var lidEntry=await bridge.invoke("Contact","getPnLidEntry",serialized),pn=lidEntry&&lidEntry.phoneNumber;digits=idUser(pn).replace(/\D/g,"");}catch(_){digits="";}}else if(!serialized&&digits){try{var found=await bridge.invoke("Contact","queryExists",digits+"@c.us"),resolved=(found&&found.lid&&idSerialized(found.lid))||(found&&found.wid&&idSerialized(found.wid))||"";if(resolved)serialized=resolved;}catch(_){}if(!serialized&&digits.length>=14){try{var candidate=digits+"@lid",entry=await bridge.invoke("Contact","getPnLidEntry",candidate),pn2=entry&&entry.phoneNumber,resolvedPhone=idUser(pn2).replace(/\D/g,"");if(resolvedPhone){serialized=candidate;digits=resolvedPhone;}}catch(_){}}}if(!digits)return null;return{value:serialized||digits,chatId:serialized||null,phoneNumber:digits,displayNumber:digits};}
  async function labelContacts(labelIds){await ensureReady();var chats=labelIds&&labelIds.length?await bridge.invoke("Chat","List",{withLabels:labelIds}):[],out=[];for(var i=0;i<(chats||[]).length;i++){var c=chats[i];if(!c||!idSerialized(c.id))continue;var id=idSerialized(c.id),identity=await resolveRecipientIdentity(id);if(!identity)continue;var display=c.name||c.formattedName||c.pushname||identity.phoneNumber||id;out.push({value:id,chatId:id,phoneNumber:identity.phoneNumber,displayNumber:identity.phoneNumber,label:display});}return out;}
  async function fetchGroups(){await ensureReady();var groups=await bridge.invoke("Group","getAllGroups",null);return (groups||[]).filter(function(g){return g&&idSerialized(g.id);}).map(function(g){var id=idSerialized(g.id),display=g.name||g.formattedName||g.pushname||idUser(g.id)||id;return{value:id,label:display};});}
  async function groupContacts(groupIds){await ensureReady();var ids=Array.from(new Set((Array.isArray(groupIds)?groupIds:[]).map(function(id){return String(id||"").trim();}).filter(function(id){return /@g\.us$/i.test(id);})));if(!ids.length)return[];var me=null,myPhone="";try{me=await bridge.invoke("Conn","getMyUserId",null);myPhone=idUser(me).replace(/\D/g,"");}catch(_){}var seen=Object.create(null),out=[];for(var gi=0;gi<ids.length;gi++){var participants=[];try{participants=await bridge.invoke("Group","getParticipants",ids[gi]);}catch(_){participants=[];}var rows=await mapLimit(Array.isArray(participants)?participants:[],6,async function(p){var pid=p&&p.id!=null?p.id:p,serialized=idSerialized(pid)||String(pid||"");if(!serialized)return null;var identity=await resolveRecipientIdentity(serialized);if(!identity||!identity.phoneNumber||identity.phoneNumber===myPhone)return null;var label=identity.phoneNumber;try{var contact=await bridge.invoke("Contact","get",serialized);label=String(contact&&(contact.name||contact.pushname||contact.formattedName)||label);}catch(_){}return{value:serialized,chatId:serialized,phoneNumber:identity.phoneNumber,displayNumber:identity.phoneNumber,label:label};});rows.forEach(function(row){if(!row||seen[row.phoneNumber])return;seen[row.phoneNumber]=true;out.push(row);});}return out;}

  chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){
    if(!msg||!sender||sender.id!==chrome.runtime.id)return;
    var work=null;
    if(msg.type==="EXTUI_CRM_COPILOT_CONTEXT")work=crmCopilotContext(msg);
    else if(msg.type==="EXTUI_CRM_FETCH_CONTACTS_V2")work=crmFetchContacts();
    else if(msg.type==="EXTUI_DISPAROS_FETCH_LABELS")work=fetchLabels();
    else if(msg.type==="EXTUI_DISPAROS_SEARCH_CONTACTS")work=searchContacts(msg.query);
    else if(msg.type==="EXTUI_DISPAROS_LABEL_CONTACTS")work=labelContacts(Array.isArray(msg.labelIds)?msg.labelIds:[]);
    else if(msg.type==="EXTUI_DISPAROS_GROUP_CONTACTS")work=groupContacts(Array.isArray(msg.groupIds)?msg.groupIds:[]);
    else if(msg.type==="EXTUI_DISPAROS_VALIDATE_NUMBER")work=validateNumber(msg.number);
    else if(msg.type==="EXTUI_DISPAROS_RESOLVE_RECIPIENT")work=resolveRecipientIdentity(msg.value);
    else if(msg.type==="EXTUI_SALVAR_FETCH_GROUPS")work=fetchGroups();
    else return;
    Promise.resolve(work).then(function(data){sendResponse({requestId:msg.requestId||null,data:data,error:null});}).catch(function(err){sendResponse({requestId:msg.requestId||null,data:null,error:err&&err.message||String(err)});});
    return true;
  });
})();
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
try{


(function(){
  "use strict";
  if(window.__extWppRpcRelayBooted)return;
  window.__extWppRpcRelayBooted=true;
  var CHANNEL="WPP",RESPONSE_MODEL="WPP-RESPONSE";
  function makeId(){return"extapp-rpc:"+Date.now()+":"+Math.random().toString(36).slice(2,12);}
  function validate(req){if(!req||typeof req!=="object")return"request ausente";if(!req.type||typeof req.type!=="string")return"type ausente";if(!req.action||typeof req.action!=="string")return"action ausente";if(req.id!=null&&typeof req.id!=="string")return"id inválido";return null;}
  chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){
    if(!msg||msg.type!=="EXTUI_WPP_RPC")return;
    if(!sender||sender.id!==chrome.runtime.id)return;
    var req=msg.request||{},id=req.id||makeId(),err=validate(req);
    if(err){sendResponse({requestId:id,response:null,error:err,code:"WPP_RPC_INVALID_REQUEST"});return;}
    var bridge=window.__extWppBridge;
    if(!bridge||typeof bridge.invoke!=="function"){sendResponse({requestId:id,response:null,error:"A conexão com o WhatsApp não está disponível",code:"WPP_RPC_UNAVAILABLE"});return;}
    Promise.resolve(bridge.invoke(req.type,req.action,req.payload)).then(function(result){
      sendResponse({requestId:id,response:{channel:CHANNEL,model:RESPONSE_MODEL,id:id,sender:req.sender||"extension-page",ok:true,result:result,error:null},error:null});
    }).catch(function(e){
      sendResponse({requestId:id,response:{channel:CHANNEL,model:RESPONSE_MODEL,id:id,sender:req.sender||"extension-page",ok:false,result:null,error:e&&e.message||String(e),code:e&&e.code||"WPP_RPC_ERROR"},error:null});
    });
    return true;
  });
})();
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;

;
