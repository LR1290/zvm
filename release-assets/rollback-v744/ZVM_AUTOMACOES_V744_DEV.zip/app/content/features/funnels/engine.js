;
try{
(function () {
  "use strict";
if (window.__extFunnelsEngineBooted) return;
  window.__extFunnelsEngineBooted = true;

  var funnelRuntime = { instanceId: Math.random().toString(36).slice(2, 10) };

  var FUNNEL_STORE_KEY = "EXTUI:extappFunnelStore";
  var RUNNING_STORE_KEY = "EXTUI:extappFunnelRunningStore";
  var AI_ASSISTANTS_STORE_KEY = "EXTUI:aiAssistantsStore";
  var AI_AGENTS_STORE_KEY = "EXTUI:aiAgentsStore";
  var INTEGRATIONS_STORE_KEY = "EXTUI:integrationsStore";
  var KNOWLEDGE_STORE_KEY = "EXTUI:knowledgeBasesStore";
  var CRM_STORE_KEY = "EXTUI:CrmStore";
  funnelRuntime.activeAiRequests = new Map();
  funnelRuntime.cancelledExecutionIds = new Set();
  funnelRuntime.processingInstances = new Map();
  funnelRuntime.cancelAllRequested = false;


  function extnStorageGet(key) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.get(key);
  }
  function extnStorageSet(key, value) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.set(key, value);
  }

  function parsePersisted(raw) {
    if (raw == null || raw === "") return null;
    var parsed;
    try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (err) { err.code = err.code || "FUNNEL_STORE_CORRUPT"; throw err; }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state)) {
      var invalid = new Error("Os dados de Funis estão inválidos e não serão sobrescritos.");
      invalid.code = "FUNNEL_STORE_CORRUPT";
      throw invalid;
    }
    return parsed.state;
  }
  async function loadFunnels() {
    var state = parsePersisted(await extnStorageGet(FUNNEL_STORE_KEY));
    return ((state && state.funnelList) || []).filter(function (f) { return !!(f && f.id); });
  }
  async function loadRunning() {
    var raw = await extnStorageGet(RUNNING_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.runningList) || [];
  }
  async function saveRunning(runningList) {
    await extnStorageSet(RUNNING_STORE_KEY, JSON.stringify({ state: { runningList: runningList }, version: 0 }));
  }


  funnelRuntime.runningMutex = Promise.resolve();
  function withRunningLock(fn) {
    var result = funnelRuntime.runningMutex.then(fn);
    funnelRuntime.runningMutex = result.catch(function () {});
    return result;
  }




  function formatPhoneNumberForVariable(raw) {
    var d = String(raw || "").replace(/\D/g, "");
    if (!d) return "";
    if (d.length >= 12 && d.slice(0, 2) === "55") {
      var rest = d.slice(2), ddd = rest.slice(0, 2), num = rest.slice(2);
      if (num.length === 9) return "+55 (" + ddd + ") " + num.slice(0, 5) + "-" + num.slice(5);
      if (num.length === 8) return "+55 (" + ddd + ") " + num.slice(0, 4) + "-" + num.slice(4);
    }
    return "+" + d;
  }

  function getSendEngine() {
    return (window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null;
  }

  async function applyMessageVariables(text, chatId) {
    if (text == null) return text;
    var source = String(text);
    if (window.__extVariableResolver && typeof window.__extVariableResolver.resolveForChat === "function") return window.__extVariableResolver.resolveForChat(source, chatId);
    if (!/(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|first_name|fn|nome|nome_completo|full_name|nome_extapp|nome_whatsapp|numero|telefone|phone|email|empresa|company|origem_lead|leadSource|cidade|city|estado|state|endereco|address|cep|postalCode|idioma|language|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i.test(source)) return source;
    try {
      var engine = getSendEngine ? getSendEngine() : ((window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null);
      var rawId = String(chatId && chatId._serialized || chatId || "");
      var active = null, contact = null, meta = null;
      if (engine && engine.chat && typeof engine.chat.getActiveChat === "function") {
        try { active = await engine.chat.getActiveChat(); } catch (_) {}
      }
      if (engine && engine.contact && typeof engine.contact.get === "function" && rawId) {
        try { contact = await engine.contact.get(rawId); } catch (_) {}
      }
      if (window.__extContactMetadataService && typeof window.__extContactMetadataService.get === "function" && rawId) {
        try { meta = await window.__extContactMetadataService.get(rawId); } catch (_) {}
      }
      var activeId = String(active && active.id && (active.id._serialized || active.id) || "");
      var activeContact = active && active.contact || null;
      var activeMatches = !!active && (!rawId || !activeId || activeId === rawId);
      var localName = String(meta && meta.localAlias || "").trim();
      var whatsappName = String(
        contact && (contact.name || contact.pushname || contact.formattedName || contact.notifyName || contact.shortName) ||
        (activeMatches && activeContact && (activeContact.name || activeContact.pushname || activeContact.formattedName || activeContact.notifyName || activeContact.shortName)) ||
        (activeMatches && (active.formattedTitle || active.name || active.title)) || ""
      ).trim();
      var fullName = localName || whatsappName;
      var firstName = fullName ? fullName.split(/\s+/)[0] : "";
      var rawNum = rawId.replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
      if (/@lid$/i.test(rawId) && engine && engine.contact && typeof engine.contact.getPnLidEntry === "function") {
        try {
          var lidEntry = await engine.contact.getPnLidEntry(rawId);
          var pn = lidEntry && lidEntry.phoneNumber && (lidEntry.phoneNumber._serialized || lidEntry.phoneNumber.user);
          if (pn) rawNum = String(pn).replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
        } catch (_) {}
      }
      var num = formatPhoneNumberForVariable(rawNum);
      var now = new Date(), hour = now.getHours();
      var greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
      var period = hour < 12 ? "manhã" : hour < 18 ? "tarde" : "noite";
      var dateStr = String(now.getDate()).padStart(2, "0") + "/" + String(now.getMonth() + 1).padStart(2, "0") + "/" + now.getFullYear();
      var timeStr = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
      var weekday = now.toLocaleDateString("pt-BR", { weekday: "long" });
      var vars = {
        primeiro_nome:firstName, primeiroNome:firstName, first_name:firstName, fn:firstName,
        nome:fullName, nome_completo:fullName, full_name:fullName,
        nome_extapp:localName || fullName, nome_ext:localName || fullName, nome_whatsapp:whatsappName || fullName,
        numero:num || "", telefone:num || "", phone:num || "",
        email:String(meta && meta.email || ""), empresa:String(meta && meta.company || ""), company:String(meta && meta.company || ""),
        origem_lead:String(meta && meta.leadSource || ""), leadSource:String(meta && meta.leadSource || ""),
        cidade:String(meta && meta.city || ""), city:String(meta && meta.city || ""), estado:String(meta && meta.state || ""), state:String(meta && meta.state || ""),
        endereco:String(meta && meta.address || ""), address:String(meta && meta.address || ""), cep:String(meta && meta.postalCode || ""), postalCode:String(meta && meta.postalCode || ""),
        idioma:String(meta && meta.language || ""), language:String(meta && meta.language || ""),
        saudacao:greeting, "saudação":greeting, periodo_dia:period, "periodo-dia":period, dia_semana:weekday, data:dateStr, hora:timeStr
      };
      function valueFor(expr) {
        var raw=String(expr||"").trim(), match=raw.match(/^([^|]+?)(?:\|\s*(?:fallback|padrao|padrão)\s*:\s*["']([^"']*)["'])?$/i);
        var key=String(match && match[1] || raw).trim(), fallback=match && match[2];
        var val=Object.prototype.hasOwnProperty.call(vars,key)?vars[key]:"";
        return val != null && String(val) !== "" ? String(val) : (fallback != null ? fallback : "");
      }
      var output=source.replace(/\{\{\s*([^{}]+?)\s*\}\}/g,function(_,expr){return valueFor(expr);});
      output=output.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(_,prefix,key){return prefix+valueFor(key);});
      var aliases=Object.keys(vars).sort(function(a,b){return b.length-a.length;});
      aliases.forEach(function(key){output=output.split("#"+key).join(String(vars[key]||""));});
      return output;
    } catch (_) { return source; }
  }


  async function resolveSendTarget(chatId) {
    if (chatId.indexOf("@lid") !== -1 || chatId.indexOf("@g.us") !== -1) return chatId;
    if (chatId.indexOf("@c.us") === -1) return chatId;
    try {
      var engine = getSendEngine();
      if (!engine) return chatId;
      var entry = await engine.contact.getPnLidEntry(chatId);
      if (entry && entry.lid && entry.lid._serialized) return entry.lid._serialized;
    } catch (err) {
    }
    return chatId;
  }

  async function sendTextThroughFunnelPipeline(chatId, text, resolvedTarget, lease, effectId) {
    var target = resolvedTarget || await resolveSendTarget(chatId);
    var safety = window.__extSendSafetyManager;
    if (safety && typeof safety.sendChat === "function") {
      return safety.sendChat("sendTxt", { id:target, msg:text }, { source:"funnel-ai", contactId:target, cancellationSignal:lease&&lease.signal||null }, { source:"funnel-ai", signal:lease&&lease.signal||null, effectId:effectId||null });
    }
    var safetyErr = new Error("Proteção de Envio indisponível; envio do Funil bloqueado por segurança.");
    safetyErr.code = "SEND_SAFETY_UNAVAILABLE";
    throw safetyErr;
  }


  async function sendFunnelItem(item, chatId, lease, instance) {
    var quick = window.__extQuickResponseService;
    var executor = window.__extActionExecutor;
    if (!quick || !executor) throw new Error("ActionExecutor/QuickResponseService indisponível");
    var actions = await quick.nativeToActions(item.type, item.itemId);
    if (!actions || !actions.length) throw new Error("funnel item not found/unsupported: " + item.itemId);

    if (actions[0].type === "txt" && actions[0].properties) {
      actions[0].properties.mensagem = await applyMessageVariables(actions[0].properties.mensagem || "", chatId);
    }
    if(lease)lease.assertActive();
    var stableExecutionId=instance&&instance.id?("funnel:"+String(instance.id)+":item:"+String(instance.currentItemIndex)):undefined;
    var result = await executor.execute(actions, { source:"funnel", contactId:chatId, remetente:chatId, funnelItemId:item.itemId, executionId:stableExecutionId, cancellationSignal:lease&&lease.signal||null });
    if (!result || result.status !== "success") {
      var err = new Error(result && result.error && result.error.message || "Falha no ActionExecutor do Funil");
      err.code = result && result.error && result.error.code || "FUNNEL_ACTION_FAILED";
      err.effectDigest = result && result.error && result.error.effectDigest || null;
      err.remoteEffectSucceeded = result && result.error && result.error.remoteEffectSucceeded === true;
      throw err;
    }
    return result;
  }


  var DELAY_UNIT_MS = { seconds: 1000, minutes: 60000, hours: 3600000, days: 86400000 };
  function delayToMs(amount, unit) {
    var mult = DELAY_UNIT_MS[unit];
    if (!mult) {
      mult = DELAY_UNIT_MS.minutes;
    }
    return Math.max(0, amount || 0) * mult;
  }


  function createAiRequestId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return funnelRuntime.instanceId + ":ai:" + Date.now() + ":" + Math.random().toString(36).slice(2, 10);
  }

  function parseState(raw) {
    if (!raw) return null;
    try {
      var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
      return parsed && parsed.state || parsed;
    } catch (error) {
      return null;
    }
  }

  function isExecutionCancelled(executionId) {
    return funnelRuntime.cancelAllRequested || funnelRuntime.cancelledExecutionIds.has(executionId);
  }

  function cancellationError() {
    var error = new Error("A execução do Funil foi cancelada.");
    error.code = "FUNNEL_AI_CANCELLED";
    return error;
  }

  async function ensureExecutionActive(instance) {
    if (!instance || isExecutionCancelled(instance.id)) throw cancellationError();
    var running = await loadRunning();
    var current = running.find(function (entry) { return entry.id === instance.id; });
    if (!current || current.status !== "running" || current.currentItemIndex !== instance.currentItemIndex) throw cancellationError();
    if (isExecutionCancelled(instance.id)) throw cancellationError();
  }

  function activityUpdate(instance, fields) {
    if (typeof window.__extActivityTrack !== "function") return;
    window.__extActivityTrack(Object.assign({ action: "update", id: "funil:" + instance.id, status: "running" }, fields || {}));
  }

  function createAiDependencies(instance, handlers) {
    var aiClient = window.__extAiRuntime;
    var contactRuntime = window.__extAiAutomationContact;
    if (!aiClient || typeof aiClient.generate !== "function" || typeof aiClient.retrieveKnowledge !== "function" || !contactRuntime || typeof contactRuntime.create !== "function") {
      var unavailable = new Error("O recurso de IA ainda não está pronto. Recarregue o WhatsApp Web.");
      unavailable.code = "ai_runtime_unavailable";
      throw unavailable;
    }
    var contact = contactRuntime.create({
      chatId: instance.chatId,
      crmStoreKey: CRM_STORE_KEY,
      storageGet: extnStorageGet,
      getSendEngine: getSendEngine,
      isCancelled: function () { return isExecutionCancelled(instance.id); },
      getMessages: function (chatId, options) {
        if (typeof window.__extGetChatMessages === "function") return window.__extGetChatMessages(chatId, options);
        var engine = getSendEngine();
        if (!engine || !engine.chat || typeof engine.chat.getMessages !== "function") return Promise.reject(new Error("O WhatsApp ainda não está pronto"));
        return engine.chat.getMessages(chatId, options);
      }
    });
    return Object.assign({
      now: Date.now,
      createRequestId: createAiRequestId,
      createRunId: function () {
        if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
        return instance.id + ":agent:" + Date.now() + ":" + Math.random().toString(36).slice(2, 10);
      },
      resolveTemplate: function (value) { return applyMessageVariables(value, instance.chatId); },
      loadMemory: contact.loadMemory,
      loadConversation: contact.loadConversation,
      resolveToolContext: function () {
        if (!window.__extAiToolsRegistry) {
          var unavailable = new Error("Ferramentas de IA indisponíveis.");
          unavailable.code = "AI_TOOL_CONTEXT_UNAVAILABLE";
          throw unavailable;
        }
        return contact.resolveToolContext();
      },
      generate: function (request) { return aiClient.generate(request); },
      retrieveKnowledge: function (request) { return aiClient.retrieveKnowledge(request); },
      endAgentRun: function (agentRunId, executionId) {
        if (typeof aiClient.endAgentRun === "function") aiClient.endAgentRun(agentRunId, executionId);
      },
      isCancelled: function () { return isExecutionCancelled(instance.id); },
      onRequestStart: function (requestId) { funnelRuntime.activeAiRequests.set(instance.id, { requestId: requestId, chatId: instance.chatId }); },
      onRequestEnd: function (requestId) {
        var active = funnelRuntime.activeAiRequests.get(instance.id);
        if (active && active.requestId === requestId) funnelRuntime.activeAiRequests.delete(instance.id);
      }
    }, handlers || {});
  }

  async function loadAiStores(includeAgents) {
    var keys = [
      extnStorageGet(AI_ASSISTANTS_STORE_KEY),
      extnStorageGet(INTEGRATIONS_STORE_KEY),
      extnStorageGet(KNOWLEDGE_STORE_KEY)
    ];
    if (includeAgents) keys.unshift(extnStorageGet(AI_AGENTS_STORE_KEY));
    return Promise.all(keys);
  }

  async function executeAiGenerateStep(item, instance, lease) {
    if(lease)lease.assertActive();await ensureExecutionActive(instance);
    var runtime = window.__extAiAutomationRuntime;
    var assistantsCore = window.__extAiAssistantsCore;
    if (!runtime || typeof runtime.execute !== "function" || !assistantsCore) {
      var unavailable = new Error("O recurso de IA ainda não está pronto. Recarregue o WhatsApp Web.");
      unavailable.code = "ai_runtime_unavailable";
      throw unavailable;
    }
    var stores = await loadAiStores(false);
    await ensureExecutionActive(instance);
    var assistant = assistantsCore.resolveForExecution(stores[0], parseState(stores[1]) || { providers: {} }, item.assistantId, null, stores[2]);
    var executionNode = {
      type: "aiGenerate",
      nextNodeIds: [],
      data: {
        mode: "assistant",
        assistantId: assistant.assistantId,
        providerId: assistant.providerId,
        model: assistant.model,
        instructions: assistant.instructions,
        context: assistant.context,
        memory: assistant.memory,
        knowledge: assistant.knowledge,
        tools: assistant.tools,


        multimodal: assistant.multimodal,
        prompt: item.prompt || "",
        outputMode: "sendText"
      }
    };
    var toolCount = 0;
    activityUpdate(instance, { progressLabel: "Funil · Gerando resposta com IA…", assistantName: assistant.assistantName, funnelStep: instance.currentItemIndex + 1, aiToolCount: 0 });
    return runtime.execute(executionNode, instance, createAiDependencies(instance, {
      sendText: async function (text) {
        await ensureExecutionActive(instance);
        if(lease)lease.assertActive();return sendTextThroughFunnelPipeline(instance.chatId, text, null, lease, "funnel:"+String(instance.id)+":item:"+String(instance.currentItemIndex)+":ai-generate");
      },
      onWaiting: function (waiting) {
        activityUpdate(instance, { progressLabel: waiting ? "Funil · Gerando resposta com IA…" : null, assistantName: assistant.assistantName, funnelStep: instance.currentItemIndex + 1, aiToolCount: toolCount });
      },
      onToolsUsed: function (metadata) {
        toolCount = Number(metadata && (metadata.count != null ? metadata.count : metadata.calls)) || 0;
        activityUpdate(instance, { progressLabel: "Funil · Gerando resposta com IA…", assistantName: assistant.assistantName, funnelStep: instance.currentItemIndex + 1, aiToolCount: toolCount });
      },
      onMemoryLoaded: function () {},
      onKnowledgeLoaded: function () {},
      onContextLoaded: function () {}
    }));
  }

  async function executeAiAgentStep(item, instance, lease) {
    if(lease)lease.assertActive();await ensureExecutionActive(instance);
    var agentRuntime = window.__extAiAgentRuntime;
    var agentsCore = window.__extAiAgentsCore;
    if (!agentRuntime || typeof agentRuntime.execute !== "function" || !agentsCore || !window.__extAiAssistantsCore) {
      var unavailable = new Error("Os Agentes IA ainda não estão prontos. Recarregue o WhatsApp Web.");
      unavailable.code = "AI_AGENT_RUNTIME_FAILED";
      throw unavailable;
    }
    var stores = await loadAiStores(true);
    await ensureExecutionActive(instance);
    var snapshot = agentsCore.resolveForExecution(stores[0], stores[1], parseState(stores[2]) || { providers: {} }, item.agentId, null, stores[3]);
    var toolCount = 0;
    activityUpdate(instance, { progressLabel: "Funil · Executando agente…", agentName: snapshot.agentName, funnelStep: instance.currentItemIndex + 1, agentStep: 1, agentMaxSteps: snapshot.maxSteps, agentToolCount: 0 });
    var outcome = await agentRuntime.execute({ type: "aiAgent", data: { agentId: item.agentId, task: item.task || "", outputMode: "sendText" } }, instance, snapshot, createAiDependencies(instance, {
      onRunStart: function () {
        activityUpdate(instance, { progressLabel: "Funil · Executando agente…", agentName: snapshot.agentName, funnelStep: instance.currentItemIndex + 1, agentStep: 1, agentMaxSteps: snapshot.maxSteps, agentToolCount: 0 });
      },
      onStep: function (state) {
        activityUpdate(instance, { progressLabel: "Funil · Executando agente…", agentName: snapshot.agentName, funnelStep: instance.currentItemIndex + 1, agentStep: state.step, agentMaxSteps: state.maxSteps, agentToolCount: state.toolCallCount });
      },
      onToolsUsed: function (metadata) {
        toolCount += Number(metadata && metadata.calls) || 0;
        activityUpdate(instance, { progressLabel: "Funil · Executando agente…", agentName: snapshot.agentName, funnelStep: instance.currentItemIndex + 1, agentMaxSteps: snapshot.maxSteps, agentToolCount: toolCount });
      },
      onMemoryLoaded: function () {},
      onKnowledgeLoaded: function () {},
      onContextLoaded: function () {}
    }));
    await ensureExecutionActive(instance);
    var output = outcome && typeof outcome.text === "string" ? outcome.text.trim() : "";
    if (!output) {
      var empty = new Error("O agente concluiu sem produzir uma resposta.");
      empty.code = "AI_AGENT_EMPTY_RESPONSE";
      throw empty;
    }
    if(lease)lease.assertActive();await sendTextThroughFunnelPipeline(instance.chatId, output, null, lease, "funnel:"+String(instance.id)+":item:"+String(instance.currentItemIndex)+":ai-agent");
    return null;
  }

  function isAiStep(item) {
    return !!(item && (item.type === "aiGenerate" || item.type === "aiAgent"));
  }

  async function executeFunnelStep(item, instance, lease) {
    if(lease)lease.assertActive();
    if (item.type === "aiGenerate") return executeAiGenerateStep(item, instance, lease);
    if (item.type === "aiAgent") return executeAiAgentStep(item, instance, lease);
    return sendFunnelItem(item, instance.chatId, lease, instance);
  }

  function isAiCancellationError(error, instance) {
    var generationRuntime = window.__extAiAutomationRuntime;
    var agentRuntime = window.__extAiAgentRuntime;
    return isExecutionCancelled(instance.id)
      || !!(error && error.code === "FUNNEL_AI_CANCELLED")
      || !!(generationRuntime && generationRuntime.isCancellationError && generationRuntime.isCancellationError(error))
      || !!(agentRuntime && agentRuntime.isCancellationError && agentRuntime.isCancellationError(error));
  }

  function safeAiError(error) {
    var messages = {
      AI_ASSISTANT_NOT_FOUND: "O Assistente desta etapa não foi encontrado.",
      AI_ASSISTANT_DISABLED: "O Assistente desta etapa está desativado.",
      AI_ASSISTANT_PROVIDER_UNAVAILABLE: "O serviço de IA do Assistente não está disponível.",
      AI_ASSISTANT_MODEL_UNAVAILABLE: "O modelo do Assistente não está disponível.",
      AI_ASSISTANT_INVALID: "A configuração do Assistente está incompleta.",
      AI_AGENT_NOT_FOUND: "O Agente desta etapa não foi encontrado.",
      AI_AGENT_DISABLED: "O Agente desta etapa está desativado.",
      AI_AGENT_ASSISTANT_INVALID: "O Assistente associado ao Agente requer atenção.",
      AI_AGENT_STEP_LIMIT_EXCEEDED: "O Agente atingiu o limite seguro de etapas.",
      AI_AGENT_TOOL_LIMIT_EXCEEDED: "O Agente atingiu o limite seguro de ferramentas.",
      AI_AGENT_MODEL_TOOL_UNSUPPORTED: "O modelo escolhido não é compatível com as ferramentas obrigatórias do Agente. Selecione outro modelo em Assistentes IA.",
      AI_AGENT_CONTROL_REQUIRED: "O modelo não acionou o controle obrigatório do Agente. Selecione outro modelo compatível com uso de ferramentas.",
      AI_AGENT_RUNTIME_FAILED: "Não foi possível concluir a execução do Agente.",
      AI_AGENT_EMPTY_RESPONSE: "O Agente concluiu sem produzir uma resposta.",
      auth_failed: "A chave de acesso do serviço de IA foi recusada.",
      access_denied: "A conta conectada não possui acesso ao modelo solicitado.",
      credential_missing: "A chave de acesso do serviço de IA não está disponível.",
      integration_not_configured: "Conecte o serviço de IA antes de executar o Agente.",
      integration_not_ready: "A conexão de IA precisa ser revalidada.",
      model_required: "Escolha um modelo para o Assistente.",
      model_invalid: "O modelo configurado não está disponível para esta conta.",
      rate_limited: "A cota ou o limite temporário do serviço de IA foi atingido.",
      timeout: "A operação de IA excedeu o tempo limite.",
      network_error: "Não foi possível alcançar o serviço de IA.",
      provider_unavailable: "O serviço de IA está temporariamente indisponível.",
      invalid_response: "O serviço de IA retornou uma resposta inesperada.",
      ai_prompt_required: "Informe as instruções desta etapa de IA.",
      ai_empty_response: "O serviço de IA retornou uma resposta vazia.",
      ai_response_too_long: "A resposta de IA excedeu o limite seguro para envio.",
      ai_runtime_unavailable: "O recurso de IA não está disponível.",
      timeout: "A operação de IA excedeu o tempo limite.",
      KNOWLEDGE_RETRIEVAL_FAILED: "Não foi possível consultar a Base de Conhecimento.",
      KNOWLEDGE_BASE_NOT_READY: "A Base de Conhecimento desta etapa requer atenção.",
      AI_TOOL_EXECUTION_FAILED: "Uma ferramenta permitida não pôde ser executada."
    };
    return messages[error && error.code] || "Não foi possível concluir a etapa de IA.";
  }

  async function preflightFunnel(funnel) {
    var core = window.__extFunnelsCore;
    if (!core || !core.hasAiSteps(funnel)) return { ok: true, issues: [] };
    var stores = await Promise.all([extnStorageGet(AI_ASSISTANTS_STORE_KEY), extnStorageGet(AI_AGENTS_STORE_KEY)]);
    var result = core.preflight(funnel, stores[0], stores[1]);
    if (!result.ok) {
      var error = new Error(result.issues[0].message);
      error.code = result.issues[0].code;
      error.preflight = true;
      throw error;
    }
    return result;
  }


  function extActivityPhoneLabel(chatId) {
    var digits = String(chatId || "").replace(/@.*/, "").replace(/\D/g, "");
    return digits ? "+" + digits : "";
  }
  function extTrackFunnelInstance(instance, funnel) {
    if (typeof window.__extActivityTrack !== "function") return;
    var id = "funil:" + instance.id;
    var total = funnel && funnel.items ? funnel.items.length : undefined;
    if (instance.status === "finished") window.__extActivityTrack({ action: "success", id: id });
    else if (instance.status === "cancelled") window.__extActivityTrack({ action: "cancel", id: id });


    else window.__extActivityTrack({ action: "update", id: id, current: instance.currentItemIndex + 1, total: total, status: (instance.attempts || 0) > 0 ? "waiting" : "running", nextActionAt: instance.nextSendAtMs || null, progressLabel: null });
  }
  function markFunnelCompleted(instance, funnel) {
    if (!instance || !funnel || instance.completedEventAtMs) return null;
    instance.completedEventAtMs = Date.now();
    return { funnelId:funnel.id, funnelName:funnel.name || "Funil", executionId:instance.id, chatId:instance.chatId, completedAtMs:instance.completedEventAtMs };
  }
  function emitFunnelCompleted(payload) {
    if (!payload) return false;
    var bus = window.__extEventBus || window.__extDomainEventBus;
    if (!bus || typeof bus.emit !== "function") return false;
    bus.emit("FunnelCompleted", payload, { source:"funnels-engine", correlationId:payload.executionId });
    return true;
  }


  window.__extFunnelsStartManually = async function (funnelId, chatId, options) {
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Funis");
    return withRunningLock(async function () {
      var funnels = await loadFunnels();
      var funnel = funnels.find(function (f) { return f.id === funnelId; });
      if (!funnel) throw new Error("funnel not found: " + funnelId);
      if (!funnel.items || funnel.items.length === 0) throw new Error("funnel has no items: " + funnelId);
      await preflightFunnel(funnel);
      var running = await loadRunning();
      var alreadyRunning = running.some(function (r) { return r.chatId === chatId && r.funnelId === funnelId && r.status === "running"; });
      if (alreadyRunning) throw new Error("this funnel is already running for chat " + chatId);
      var newInstance = {
        id: funnelId + ":" + chatId + ":" + Date.now(),
        funnelId: funnelId,
        chatId: chatId,
        currentItemIndex: 0,
        nextSendAtMs: Date.now(),
        status: "running",
        startedAtMs: Date.now(),
        lastTouchedAtMs: Date.now(),
        attempts: 0
      };
      running.push(newInstance);
      if (typeof window.__extActivityTrack === "function") {


        window.__extActivityTrack({ action: "start", id: "funil:" + newInstance.id, type: "funil", source: options && options.isTest ? "test" : "", title: funnel.name, targetLabel: extActivityPhoneLabel(chatId), current: 1, total: funnel.items.length, status: "running", chatId: chatId, executionId: newInstance.id });
      }
      await saveRunning(running);
      return newInstance;
    }).then(function (instance) { wakeFunnelScheduler(); return instance; });
  };

  window.__extFunnelsCommandDirect = function(command) {
    command = command || {};
    if (command.action === "startManual") {
      var manualTarget = String(command.phoneNumber || "");
      if (manualTarget.indexOf("@") === -1) manualTarget += "@c.us";
      return resolveSendTarget(manualTarget).then(function (chatId) { return window.__extFunnelsStartManually(command.funnelId, chatId, { isTest: command.isTest === true }); });
    }
    if (command.action === "cancel") return window.__extFunnelsCancelFunnel(String(command.chatId || ""), String(command.executionId || "") || null);
    return Promise.reject(new Error("Comando de Funis inválido."));
  };


  function cancelAiImmediately(chatId, executionId) {
    var cancelledIds = [];
    if (executionId) {
      funnelRuntime.cancelledExecutionIds.add(executionId);
      cancelledIds.push(executionId);
    }
    funnelRuntime.processingInstances.forEach(function (processingChatId, processingExecutionId) {
      if ((executionId && processingExecutionId !== executionId) || (!executionId && processingChatId !== chatId)) return;
      funnelRuntime.cancelledExecutionIds.add(processingExecutionId);
      if (cancelledIds.indexOf(processingExecutionId) < 0) cancelledIds.push(processingExecutionId);
    });
    funnelRuntime.activeAiRequests.forEach(function (active, activeExecutionId) {
      if ((executionId && activeExecutionId !== executionId) || (!executionId && active.chatId !== chatId)) return;
      funnelRuntime.cancelledExecutionIds.add(activeExecutionId);
      if (cancelledIds.indexOf(activeExecutionId) < 0) cancelledIds.push(activeExecutionId);
    });
    if (window.__extAiRuntime && typeof window.__extAiRuntime.cancelExecution === "function") {
      cancelledIds.forEach(function (id) { window.__extAiRuntime.cancelExecution(id); });
    }
    return cancelledIds;
  }

  window.__extFunnelsCancelFunnel = function (chatId, executionId) {
    var immediateIds = cancelAiImmediately(chatId, executionId);
    return withRunningLock(async function () {
      var running = await loadRunning();
      var idx = executionId
        ? running.findIndex(function (r) { return r.id === executionId && (r.status === "running" || r.status === "cancelled"); })
        : running.findIndex(function (r) { return r.chatId === chatId && r.status === "running"; });
      if (idx < 0) return immediateIds.length > 0;
      running[idx].status = "cancelled";
      running[idx].lastTouchedAtMs = Date.now();
      extTrackFunnelInstance(running[idx], null);
      await saveRunning(running);
      return true;
    }).finally(function () {
      immediateIds.forEach(function (id) { funnelRuntime.cancelledExecutionIds.delete(id); });
    });
  };

  window.__extFunnelsCancelAll = function () {
    funnelRuntime.cancelAllRequested = true;
    var immediateIds = [];
    funnelRuntime.processingInstances.forEach(function (_chatId, executionId) {
      funnelRuntime.cancelledExecutionIds.add(executionId);
      immediateIds.push(executionId);
    });
    funnelRuntime.activeAiRequests.forEach(function (_active, executionId) {
      funnelRuntime.cancelledExecutionIds.add(executionId);
      if (immediateIds.indexOf(executionId) < 0) immediateIds.push(executionId);
    });
    if (window.__extAiRuntime && typeof window.__extAiRuntime.cancelExecution === "function") immediateIds.forEach(function (id) { window.__extAiRuntime.cancelExecution(id); });
    return withRunningLock(async function () {
      var running = await loadRunning();
      var count = 0;
      running.forEach(function (r) {
        if (r.status === "running") { r.status = "cancelled"; r.lastTouchedAtMs = Date.now(); extTrackFunnelInstance(r, null); count++; }
      });
      if (count) await saveRunning(running);
      return count;
    }).finally(function () {
      funnelRuntime.cancelAllRequested = false;
      immediateIds.forEach(function (id) { funnelRuntime.cancelledExecutionIds.delete(id); });
    });
  };

  window.__extFunnelsCountRunningByFunnelId = function (funnelId) {
    return loadRunning().then(function (running) {
      return running.filter(function (r) { return r.funnelId === funnelId && r.status === "running"; }).length;
    });
  };

  window.__extFunnelsGetRunningForChat = function (chatId) {
    return loadRunning().then(function (running) {
      return running.find(function (r) { return r.chatId === chatId && r.status === "running"; }) || null;
    });
  };


  function runTick() {
    return withRunningLock(async function () {
      if(typeof window.__extWithAutomationLease!=="function"){var coordErr=new Error("Coordenação segura entre abas indisponível.");coordErr.code="AUTOMATION_COORDINATOR_UNAVAILABLE";throw coordErr;}
      return window.__extWithAutomationLease("funnel-tick",async function(lease){
      var running = await loadRunning();lease.assertActive();
      if(window.__extPlanGate&&await window.__extPlanGate.isRestricted()){
        var freeChanged=false,freeNow=Date.now();running.forEach(function(instance){if(instance&&instance.status==="running"){instance.status="cancelled";instance.lastTouchedAtMs=freeNow;extTrackFunnelInstance(instance,null);freeChanged=true;}});if(freeChanged)await saveRunning(running);return;
      }
      var funnels = await loadFunnels();
      var now = Date.now();
      var changed = false;
      var touchedIds = [];
      var completionPayloads = [];
      for (var i = 0; i < running.length; i++) {
        if(!lease.isActive())break;var instance = running[i];
        if (instance.status !== "running" || instance.nextSendAtMs > now) continue;
        var funnel = funnels.find(function (f) { return f.id === instance.funnelId; });
        if (!funnel) {
          instance.status = "finished";
          instance.lastTouchedAtMs = now;
          extTrackFunnelInstance(instance, null);
          changed = true;
          touchedIds.push(instance.id);
          continue;
        }
        var item = funnel.items[instance.currentItemIndex];
        if (!item) {
          instance.status = "finished";
          instance.lastTouchedAtMs = now;
          var completionPayload = markFunnelCompleted(instance, funnel);
          if (completionPayload) completionPayloads.push(completionPayload);
          extTrackFunnelInstance(instance, funnel);
          changed = true;
          touchedIds.push(instance.id);
          continue;
        }
        funnelRuntime.processingInstances.set(instance.id, instance.chatId);
        try {
          await ensureExecutionActive(instance);
          lease.assertActive();await executeFunnelStep(item, instance, lease);
          await ensureExecutionActive(instance);
          instance.attempts = 0;
        } catch (err) {
          if (isAiCancellationError(err, instance)) {
            instance.status = "cancelled";
            instance.lastTouchedAtMs = Date.now();
            extTrackFunnelInstance(instance, funnel);
            changed = true;
            touchedIds.push(instance.id);
            continue;
          }
          if (isAiStep(item)) {
            instance.status = "error";
            instance.attempts = 0;
            instance.lastTouchedAtMs = Date.now();
            changed = true;
            touchedIds.push(instance.id);
            if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "error", id: "funil:" + instance.id, errorMessage: safeAiError(err), errorCode: err && err.code, funnelStep: instance.currentItemIndex + 1 });
            continue;
          }
          instance.attempts = (instance.attempts || 0) + 1;
          instance.lastTouchedAtMs = now;
          changed = true;
          touchedIds.push(instance.id);
          var durableTerminal=window.__extSendSafetyManager&&typeof window.__extSendSafetyManager.isDurableTerminalError==="function"&&window.__extSendSafetyManager.isDurableTerminalError(err);
          if (!durableTerminal && instance.attempts < 3) {
            instance.nextSendAtMs = now + 60000;
            extTrackFunnelInstance(instance, funnel);
          } else {
            instance.status = "error";
            instance.nextSendAtMs = null;
            instance.lastErrorCode = err && err.code || null;
            instance.lastEffectDigest = err && err.effectDigest || null;
            if (typeof window.__extActivityTrack === "function") window.__extActivityTrack({ action: "error", id: "funil:" + instance.id, errorMessage: err && err.message ? err.message : String(err), errorCode:instance.lastErrorCode, durableReviewRequired:durableTerminal===true });
          }
          continue;
        } finally {
          funnelRuntime.processingInstances.delete(instance.id);
        }
        var nextIndex = instance.currentItemIndex + 1;
        var nextItem = funnel.items[nextIndex];
        instance.lastTouchedAtMs = Date.now();
        if (nextItem) {
          instance.currentItemIndex = nextIndex;
          instance.nextSendAtMs = Date.now() + delayToMs(nextItem.delayAmount, nextItem.delayUnit);
        } else {
          instance.status = "finished";
          var completionPayloadAfterStep = markFunnelCompleted(instance, funnel);
          if (completionPayloadAfterStep) completionPayloads.push(completionPayloadAfterStep);
        }
        extTrackFunnelInstance(instance, funnel);
        changed = true;
        touchedIds.push(instance.id);
        if(!lease.isActive())break;
      }
      if (touchedIds.length > 0) {
        var freshRunning = await loadRunning();
        var committedCompletionIds = Object.create(null);
        touchedIds.forEach(function (id) {
          var mutated = running.find(function (r) { return r.id === id; });
          var freshIdx = freshRunning.findIndex(function (r) { return r.id === id; });
          if (!mutated || freshIdx === -1) return;
          if (freshRunning[freshIdx].status !== "running") return;
          freshRunning[freshIdx] = mutated;
          if (mutated.status === "finished" && mutated.completedEventAtMs) committedCompletionIds[id] = true;
        });
        await saveRunning(freshRunning);
        if(lease.isActive())completionPayloads.forEach(function (payload) { if (payload && committedCompletionIds[payload.executionId]) emitFunnelCompleted(payload); });
      }
      lease.assertActive();
      });
    }).catch(function (err) {
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("FUNNEL_TICK_FAILED",err);
    });
  }


  var FUNNEL_SCHEDULER_MAX_ACTIVE_WAIT_MS = 20000;
  var FUNNEL_SCHEDULER_IDLE_WAIT_MS = 60000;
  function computeFunnelSchedulerDelay(running, now) {
    now = Number(now) || Date.now();
    var active = (Array.isArray(running) ? running : []).filter(function (instance) { return instance && instance.status === "running"; });
    if (!active.length) return FUNNEL_SCHEDULER_IDLE_WAIT_MS;
    var earliest = active.reduce(function (min, instance) { var due = Number(instance.nextSendAtMs); if (!Number.isFinite(due)) due = now; return Math.min(min, due); }, Infinity);
    return Math.max(0, Math.min(FUNNEL_SCHEDULER_MAX_ACTIVE_WAIT_MS, earliest - now));
  }
  function hasRunningFunnels(running) { return (Array.isArray(running) ? running : []).some(function (instance) { return instance && instance.status === "running"; }); }
  function abortableLocalWait(ms, signal) {
    return new Promise(function (resolve, reject) {
      if (signal && signal.aborted) { var pre = new Error("Espera cancelada."); pre.name = "AbortError"; reject(pre); return; }
      var timer = setTimeout(function () { cleanup(); resolve(); }, Math.max(0, Number(ms) || 0));
      function onAbort() { clearTimeout(timer); cleanup(); var err = new Error("Espera cancelada."); err.name = "AbortError"; reject(err); }
      function cleanup() { if (signal && signal.removeEventListener) signal.removeEventListener("abort", onAbort); }
      if (signal && signal.addEventListener) signal.addEventListener("abort", onAbort, { once: true });
    });
  }
  async function waitForNextFunnelTick(ms, active) {
    var controller = typeof AbortController === "function" ? new AbortController() : null;
    funnelRuntime.schedulerAbort = controller;
    try {
      if (active && window.__extReliableDelay && typeof window.__extReliableDelay.wait === "function") {
        try { await window.__extReliableDelay.wait(ms, controller && controller.signal); }
        catch (err) {
          if (err && err.name === "AbortError") throw err;
          if (window.__extReportRuntimeError) window.__extReportRuntimeError("FUNNEL_RELIABLE_DELAY_FALLBACK", err);
          await abortableLocalWait(ms, controller && controller.signal);
        }
      } else await abortableLocalWait(ms, controller && controller.signal);
    } catch (err) { if (!(err && err.name === "AbortError")) throw err; }
    finally { if (funnelRuntime.schedulerAbort === controller) funnelRuntime.schedulerAbort = null; }
  }
  function wakeFunnelScheduler() {
    if (!funnelRuntime.tickStarted) { startTicking(); return; }
    if (funnelRuntime.schedulerAbort) { try { funnelRuntime.schedulerAbort.abort(); } catch (_) {} }
  }
  async function funnelSchedulerLoop() {
    while (funnelRuntime.tickStarted) {
      await runTick();
      var running = [];
      try { running = await loadRunning(); } catch (err) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("FUNNEL_SCHEDULER_STATE_FAILED", err); }
      var active = hasRunningFunnels(running), delay = computeFunnelSchedulerDelay(running, Date.now());
      if (active && delay < 250) delay = 250;
      await waitForNextFunnelTick(delay, active);
    }
  }
  funnelRuntime.tickStarted = false;
  function startTicking() {
    if (funnelRuntime.tickStarted) return;
    funnelRuntime.tickStarted = true;
    funnelRuntime.schedulerLoopPromise = funnelSchedulerLoop().catch(function (err) { funnelRuntime.tickStarted = false; if (window.__extReportRuntimeError) window.__extReportRuntimeError("FUNNEL_SCHEDULER_FAILED", err); });
  }

  setTimeout(function () {
    if (getSendEngine()) {
      startTicking();
      return;
    }
    var onReady = function () {
      if (!getSendEngine()) return;
      document.removeEventListener("wppconnect_ready", onReady);
      startTicking();
    };
    document.addEventListener("wppconnect_ready", onReady);
    setTimeout(function () {
      if (getSendEngine()) startTicking();
      document.removeEventListener("wppconnect_ready", onReady);
    }, 20000);
  }, 1000);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
