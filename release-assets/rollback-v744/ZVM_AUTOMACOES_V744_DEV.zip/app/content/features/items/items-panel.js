;
try{


(function () {
  "use strict";

  if (window.__extSidebarItensPanelBooted) return;
  window.__extSidebarItensPanelBooted = true;
  var itemsRuntime = { instanceId: Math.random().toString(36).slice(2, 10) };

  var PANEL_ID = "ext-items-panel-root";


  function extStorageGet(key) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.get(key);
  }
  function extStorageSet(key, value) {
    if (!window.ExtensionStorage) return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.set(key, value);
  }
  function extStorageRemove(key) {
    if (!window.ExtensionStorage || typeof window.ExtensionStorage.remove !== "function") return Promise.reject(new Error("O armazenamento da extensão não está disponível."));
    return window.ExtensionStorage.remove(key);
  }

  function extOnItensKeyChange(key, fn) {
    if (!window.ExtensionStorage || typeof window.ExtensionStorage.subscribe !== "function") throw new Error("Serviço de armazenamento indisponível");
    return window.ExtensionStorage.subscribe(key, function (newValue) { try { fn(newValue); } catch (err) { } });
  }


  function toast(message, isError) { return window.__extNotify(message, !!isError); }


  function extTypeIconChip(accent, svgInner) {
    return '<span class="extuiSideItensTypeChip" style="--c:' + accent + ';">' +
      '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + svgInner + '</svg>' +
      '</span>';
  }


  var AGENDA_SCHEDULABLE_TYPES = { message: true, audio: true, image: true, video: true, media: true, sticker: true, document: true, funnel: true };


  var DUPLICATE_SUPPORTED_TYPES = { message: true, audio: true, image: true, video: true, media: true, sticker: true, document: true, pix: true, "interactive-list": true, contact: true };


  var EDIT_IN_DASHBOARD_SECTION_BY_TYPE = {
    message: "itens-message", audio: "itens-audio", image: "itens-image", video: "itens-video", media: "itens-image", sticker: "itens-sticker", document: "itens-document",
    pix: "itens-pix", "interactive-list": "itens-interactive-list", contact: "itens-contact", flow: "fluxos", funnel: "funis"
  };
  var TYPE_ICONS = [
    { type: "message", icon: extTypeIconChip("#a855f7", '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>'), title: "Mensagem" },
    { type: "audio", icon: extTypeIconChip("#14b8a6", '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2"/><path d="M12 19v3"/>'), title: "Áudio" },
    { type: "image", icon: extTypeIconChip("#84cc16", '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="m21 16-4.5-4.5a2 2 0 0 0-2.8 0L5 20"/>'), title: "Imagem" },
    { type: "video", icon: extTypeIconChip("#3b82f6", '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 10 4-2v8l-4-2z"/>'), title: "Vídeo" },
    { type: "sticker", icon: extTypeIconChip("#f59e0b", '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>'), title: "Figurinha" },
    { type: "document", icon: extTypeIconChip("#f59e0b", '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>'), title: "Documento" },
    { type: "flow", icon: extTypeIconChip("#fb923c", '<circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M9 6h5a4 4 0 0 1 4 4v6"/>'), title: "Fluxo" },
    { type: "funnel", icon: extTypeIconChip("#f43f5e", '<path d="M22 3H2l8 9.46V19l4 2v-8.54z"/>'), title: "Funil" },


    { type: "pix", icon: extTypeIconChip("#32bcad", '<path d="m12 3 3 3-3 3-3-3z"/><path d="m12 15 3 3-3 3-3-3z"/><path d="m3 12 3-3 3 3-3 3z"/><path d="m15 12 3-3 3 3-3 3z"/>'), title: "PIX" },
    { type: "interactive-list", icon: extTypeIconChip("#06b6d4", '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3" cy="6" r="1"/><circle cx="3" cy="12" r="1"/><circle cx="3" cy="18" r="1"/>'), title: "Lista" },
    { type: "contact", icon: extTypeIconChip("#6366f1", '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>'), title: "Contato" }
  ];
  var ITEM_STORAGE_BY_TYPE = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList" },
    audio: { key: "EXTUI:audioStore", listField: "audioList" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList" },
    sticker: { key: "EXTUI:stickerStore", listField: "stickerList" },
    document: { key: "EXTUI:documentStore", listField: "documentList" },
    flow: { key: "EXTUI:extappFlowStore", listField: "flowList" },
    funnel: { key: "EXTUI:extappFunnelStore", listField: "funnelList" },
    pix: { key: "EXTUI:pixStore", listField: "pixList" },
    "interactive-list": { key: "EXTUI:interactiveListStore", listField: "interactiveListList" },
    contact: { key: "EXTUI:contactCardStore", listField: "contactList" }
  };

  function storageItemType(type) { return type === "image" || type === "video" ? "media" : type; }
  function entitlementItemType(type) { return storageItemType(type); }
  function classifyMediaItem(item, content) {
    var kind = String(item && item.mediaKind || content && content.mediaKind || "").toLowerCase();
    if (kind === "image" || kind === "video") return kind;
    var mime = String(content && content.mimeType || "").toLowerCase();
    var name = String(content && content.fileName || item && item.name || "").toLowerCase();
    if (mime.indexOf("video/") === 0 || /\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name)) return "video";
    return "image";
  }

  var state = {
    query: "",
    onlyFavorites: false,
    hiddenTypes: {}
  };
  itemsRuntime.itemsFreePlan = false;


  var CONFIRM_LABELS = { message: "esta mensagem", audio: "este áudio", document: "este documento", image: "esta imagem", video: "este vídeo", media: "esta mídia", sticker: "esta figurinha", flow: "este fluxo", funnel: "este funil", pix: "este PIX", "interactive-list": "esta lista interativa", contact: "este contato", "quick-response": "esta resposta rápida" };
  var extOptions = { hideItemsBar: false, showOnlyFavoritesOnItemsBar: false, askToSendSingleItem: true, askToSendFlows: true, askToSendFunnels: true, shouldAvoidWhatsappAutoScroll: false };
  async function loadItemPanelOptions() {
    try {
      var raw = await extStorageGet("EXTUI:extappOptionsStore");
      if (raw) extOptions = Object.assign({}, extOptions, typeof raw === "string" ? JSON.parse(raw) : raw);
    } catch (err) {
    }
  }
  function extChatListScrollNodes() {
    var selectors = ["#pane-side", '[aria-label="Lista de conversas"]', '[aria-label="Chat list"]'];
    var nodes = [];
    function add(node) { if (node && nodes.indexOf(node) < 0) nodes.push(node); }
    selectors.forEach(function (selector) {
      try { document.querySelectorAll(selector).forEach(add); } catch (_) {}
    });
    var scrollable = nodes.filter(function (node) { return node && node.isConnected && node.scrollHeight > node.clientHeight + 2; });
    if (!scrollable.length) {
      try {
        document.querySelectorAll('[role="grid"], [role="list"]').forEach(function (node) {
          var rect = node.getBoundingClientRect();
          if (rect.width > 180 && rect.height > 240 && rect.left < Math.max(520, window.innerWidth * 0.45) && node.scrollHeight > node.clientHeight + 8) add(node);
        });
      } catch (_) {}
      scrollable = nodes.filter(function (node) { return node && node.isConnected && node.scrollHeight > node.clientHeight + 2; });
    }
    return scrollable;
  }
  function extRestoreChatListScroll(snapshot) {
    snapshot.forEach(function (entry) {
      if (!entry.node || !entry.node.isConnected) return;
      if (Math.abs(entry.node.scrollTop - entry.top) > 1) entry.node.scrollTop = entry.top;
      if (Math.abs(entry.node.scrollLeft - entry.left) > 1) entry.node.scrollLeft = entry.left;
    });
  }
  async function extPreserveChatListScroll(task) {
    if (!extOptions.shouldAvoidWhatsappAutoScroll) return task();
    var snapshot = extChatListScrollNodes().map(function (node) { return { node: node, top: node.scrollTop, left: node.scrollLeft }; });
    if (!snapshot.length) return task();
    try { return await task(); }
    finally {
      extRestoreChatListScroll(snapshot);
      requestAnimationFrame(function () { extRestoreChatListScroll(snapshot); });
      setTimeout(function () { extRestoreChatListScroll(snapshot); }, 80);
      setTimeout(function () { extRestoreChatListScroll(snapshot); }, 220);
    }
  }
  window.__extPreserveChatListScroll = extPreserveChatListScroll;
  extOnItensKeyChange("EXTUI:extappOptionsStore", function () { loadItemPanelOptions(); });

  itemsRuntime.allItems = [];




  Object.keys(ITEM_STORAGE_BY_TYPE).map(function (t) { return ITEM_STORAGE_BY_TYPE[t].key; }).forEach(function (key) {
    extOnItensKeyChange(key, function () {
      var root = document.getElementById(PANEL_ID);
      if (!root || !root.classList.contains("extuiOpen")) return;
      loadAllItems().then(function (items) { itemsRuntime.allItems = items; renderList(); }).catch(function () {});
    });
  });

  async function loadAllItems() {
    var results = [];
    var types = Object.keys(ITEM_STORAGE_BY_TYPE);
    itemsRuntime.rawItemsByTypeId = {};
    for (var i = 0; i < types.length; i++) {
      var type = types[i];
      var config = ITEM_STORAGE_BY_TYPE[type];
      itemsRuntime.rawItemsByTypeId[type] = {};
      try {
        var raw = await extStorageGet(config.key);
        var parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
        var list = (parsed && parsed.state && parsed.state[config.listField]) || [];
        for (var li = 0; li < list.length; li++) {
          var item = list[li];
          if (!item || !item.id) continue;
          itemsRuntime.rawItemsByTypeId[type][item.id] = item;
          var displayType = type;
          if (type === "media") {
            var mediaContent = null;
            if (item.mediaKind !== "image" && item.mediaKind !== "video") { try { mediaContent = await loadItemContent(type, item.id); } catch (_) {} }
            displayType = classifyMediaItem(item, mediaContent);
          }
          results.push({ type: displayType, id: item.id, name: (item.name && String(item.name).trim()) || "(sem nome)", favorite: !!item.favorite });
        }
      } catch (err) {
      }
    }


    return results;
  }


  itemsRuntime.rawItemsByTypeId = {};
  itemsRuntime.contentCache = {};
  itemsRuntime.expandedRowKey = null;

  function fmtDelay(amount, unit) {
    var labels = { seconds: "s", minutes: "min", hours: "h", days: "d" };
    return (amount || 0) + (labels[unit] || unit || "");
  }

  function describeTrigger(trigger) {
    trigger = trigger || {};
    var t = trigger.type || "keyword";
    if (t === "keyword") {
      var kws = (trigger.keywordRules && trigger.keywordRules[0] && trigger.keywordRules[0].keywords) || [];
      return kws.length ? "Palavra-chave: " + kws.slice(0, 3).map(escHtml).join(", ") + (kws.length > 3 ? "…" : "") : "Palavra-chave (nenhuma configurada)";
    }
    if (t === "newChat") return "Nova conversa (primeira mensagem)";
    if (t === "newDay") return "Primeira mensagem do dia";
    if (t === "columnMoved") return "Contato movido de coluna no CRM";
    if (t === "funnelCompleted") return "Funil finalizado";
    if (t === "followUpSent") return "FollowUp enviado";
    if (t === "scheduleSent") return "Agendamento enviado";
    if (t === "orderChanged") return "Encomenda criada ou alterada";
    if (t === "manual") return "Manual (só via botão)";
    return t;
  }

  function renderFlowPreview(item) {
    var nodeCount = (item.nodes || []).length;
    return '<div class="extuiSideItensPreview">' +
      '<div class="extuiSideItensPreviewLine"><strong>' + (item.isActive ? "&#128994; Ativo" : "&#9898; Inativo") + '</strong></div>' +
      '<div class="extuiSideItensPreviewLine">' + describeTrigger(item.trigger) + '</div>' +
      '<div class="extuiSideItensPreviewLine">' + nodeCount + ' etapa' + (nodeCount === 1 ? "" : "s") + ' no fluxo</div>' +
      '</div>';
  }

  function renderFunnelPreview(item) {


    var steps = Array.isArray(item.items) ? item.items : [];
    if (!steps.length) return '<div class="extuiSideItensPreview"><div class="extuiSideItensPreviewLine">Nenhuma etapa configurada</div></div>';
    return '<div class="extuiSideItensPreview">' +
      steps.map(function (step, idx) {
        var raw = (itemsRuntime.rawItemsByTypeId[step.type] || {})[step.itemId];
        var stepName = raw ? (step.type === "document" ? (raw.fileName || raw.name) : raw.name) || step.itemId : "(item removido)";
        return '<div class="extuiSideItensPreviewStep">' +
          '<span class="extuiSideItensPreviewStepNum">' + (idx + 1) + '</span>' +
          '<span class="extuiSideItensRowIcon" title="' + escHtml(typeTitle(step.type)) + '">' + typeIcon(step.type) + '</span>' +
          '<span class="extuiSideItensPreviewStepName">' + escHtml(stepName) + '</span>' +
          '<span class="extuiSideItensPreviewStepDelay">' + fmtDelay(step.delayAmount, step.delayUnit) + '</span>' +
          '</div>';
      }).join("") +
      '</div>';
  }

  async function renderContentPreview(type, id, container) {
    var cacheKey = type + ":" + id;
    container.innerHTML = '<div class="extuiSideItensPreview extuiSideItensPreviewLoading">Carregando prévia...</div>';
    try {
      var content = itemsRuntime.contentCache[cacheKey];
      if (!content) {
        content = await loadItemContent(type, id);
        itemsRuntime.contentCache[cacheKey] = content;
      }
      if (!content) { container.innerHTML = '<div class="extuiSideItensPreview">Conteúdo não encontrado</div>'; return; }
      if (type === "message") {
        container.innerHTML = '<div class="extuiSideItensPreview extuiSideItensPreviewText">' + escHtml(content.data || "") + '</div>';
      } else if (type === "audio") {


        container.innerHTML = '<div class="extuiSideItensPreview"><audio controls preload="metadata" src="' + escHtml(content.data || "") + '" style="width:100%"></audio></div>';
      } else if (type === "media" || type === "image" || type === "video") {
        var mediaKind = window.ExtensionChatBridge.mediaKind(content.data || "", { type: "auto-detect", mimeType: content.mimeType || "", filename: content.fileName || "" });
        var mediaTag = mediaKind === "video"
          ? '<video controls preload="metadata" src="' + escHtml(content.data || "") + '" style="max-width:100%;border-radius:8px"></video>'
          : '<img src="' + escHtml(content.data || "") + '" style="max-width:100%;border-radius:8px" alt="">';
        container.innerHTML = '<div class="extuiSideItensPreview">' + mediaTag + (content.isPtv ? '<div class="extuiSideItensPreviewCaption">&#127909; Vídeo recado</div>' : '') + (content.caption ? '<div class="extuiSideItensPreviewCaption">' + escHtml(content.caption) + '</div>' : '') + '</div>';
      } else if (type === "sticker") {
        container.innerHTML = '<div class="extuiSideItensPreview"><img src="' + escHtml(content.data || "") + '" style="max-width:100%;max-height:220px;object-fit:contain;border-radius:8px" alt="Figurinha"></div>';
      } else if (type === "interactive-list") {
        var listApi = window.__extInteractiveList;
        var listValue = listApi ? listApi.normalize(content) : content;
        var totalRows = listApi ? listApi.countRows(listValue) : (listValue.sections || []).reduce(function (n, section) { return n + ((section && section.rows || []).length); }, 0);
        container.innerHTML = '<div class="extuiSideItensPreview extuiSideItensPreviewText"><strong>' + escHtml(listValue.title || "Lista interativa") + '</strong><div style="margin-top:6px">' + escHtml(listValue.description || "") + '</div><div class="extuiSideItensPreviewCaption">' + totalRows + (totalRows === 1 ? ' opção' : ' opções') + ' · ' + escHtml(listValue.buttonText || "Ver opções") + '</div></div>';
      }
    } catch (err) {
      container.innerHTML = '<div class="extuiSideItensPreview">Erro ao carregar prévia</div>';
    }
  }

  function typeHasPreview(type) {
    return type === "message" || type === "audio" || type === "image" || type === "video" || type === "media" || type === "sticker" || type === "interactive-list" || type === "flow" || type === "funnel";
  }

  function typeIcon(type) {
    var found = TYPE_ICONS.filter(function (t) { return t.type === type; })[0];
    return found ? found.icon : "&#128196;";
  }
  function typeTitle(type) {
    var found = TYPE_ICONS.filter(function (t) { return t.type === type; })[0];
    return found ? found.title : type;
  }


  function findByAttr(scope, attrName, value) {
    var all = (scope || document).querySelectorAll("[" + attrName + "]");
    for (var i = 0; i < all.length; i++) {
      if (all[i].getAttribute(attrName) === value) return all[i];
    }
    return null;
  }

  function extSideItemActionIcon(name, active) {
    var icons = {
      expandDown: '<path d="m7 10 5 5 5-5"/>',
      expandUp: '<path d="m7 14 5-5 5 5"/>',
      schedule: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
      favorite: active ? '<path d="m12 3 2.75 5.57 6.15.9-4.45 4.33 1.05 6.12L12 17.02l-5.5 2.9 1.05-6.12L3.1 9.47l6.15-.9Z" fill="currentColor" stroke="currentColor"/>' : '<path d="m12 3 2.75 5.57 6.15.9-4.45 4.33 1.05 6.12L12 17.02l-5.5 2.9 1.05-6.12L3.1 9.47l6.15-.9Z"/>',
      duplicate: '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
      edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
      more: '<circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
      play: '<path d="m9 7 8 5-8 5Z" fill="currentColor" stroke="currentColor"/>'
    };
    return '<svg class="extuiSideItensActionIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (icons[name] || '') + '</svg>';
  }

  function extItemsListState(kind, title, detail) {
    var safeKind = kind === "loading" || kind === "error" ? kind : "empty";
    var role = safeKind === "error" ? "alert" : "status";
    var glyph = safeKind === "loading"
      ? '<span class="extuiSideItensStateSpinner" aria-hidden="true"></span>'
      : safeKind === "error"
        ? '<svg class="extuiSideItensStateIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/></svg>'
        : '<svg class="extuiSideItensStateIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 10h8M8 14h5"/></svg>';
    return '<div class="extuiSideItensEmpty extuiSideItensState is-' + safeKind + '" role="' + role + '">' +
      glyph + '<strong>' + escHtml(title || "") + '</strong>' + (detail ? '<span>' + escHtml(detail) + '</span>' : '') + '</div>';
  }

  function renderList() {
    var listEl = document.getElementById("extuiSideItensList");
    if (!listEl) return;
    var q = (state.query || "").toLowerCase();
    var items = itemsRuntime.allItems.filter(function (it) {
      if (itemsRuntime.itemsFreePlan&&window.__extPlanGate&&!window.__extPlanGate.itemAllowed(it.type)) return false;
      if (state.hiddenTypes[it.type]) return false;
      if (state.onlyFavorites && !it.favorite) return false;
      if (q && String(it && it.name || "").toLowerCase().indexOf(q) === -1) return false;
      return true;
    });

    items.sort(function (a, b) { return (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0); });

    if (items.length === 0) {
      listEl.innerHTML = extItemsListState("empty", "Nenhum item encontrado", "Altere os filtros ou cadastre um novo item no Painel de Controle.");
      return;
    }
    listEl.innerHTML = items.map(function (it) {
      var rowKey = it.type + ":" + it.id;
      var hasPreview = typeHasPreview(it.type);
      var isExpanded = itemsRuntime.expandedRowKey === rowKey;
      var chevronBtn = hasPreview
        ? '<button type="button" class="extuiSideItensActionBtn extuiActionGlyph extuiSideItensExpand' + (isExpanded ? " extuiActive" : "") + '" title="Ver prévia" aria-label="Ver prévia" data-action="expand">' + extSideItemActionIcon(isExpanded ? "expandUp" : "expandDown") + '</button>'
        : "";
      var previewWrap = (hasPreview && isExpanded) ? '<div class="extuiSideItensPreviewWrap" data-preview-for="' + escHtml(rowKey) + '"></div>' : "";
      var runningBadge = (it.type === "flow" || it.type === "funnel") ? '<span class="extuiSideItensRunningBadge" data-running-for="' + escHtml(rowKey) + '" style="display:none;"></span>' : "";


      var scheduleMenuBtn = AGENDA_SCHEDULABLE_TYPES[it.type]
        ? '<button type="button" class="extuiSideItensMenuAction extuiSideItensActionBtn" data-action="schedule" role="menuitem">' + extSideItemActionIcon("schedule") + '<span>Agendar</span></button>'
        : "";
      var favBtn = '<button type="button" class="extuiSideItensActionBtn extuiActionGlyph extuiSideItensFav' + (it.favorite ? " extuiActive" : "") + '" title="' + (it.favorite ? "Remover dos favoritos" : "Favoritar") + '" aria-label="' + (it.favorite ? "Remover dos favoritos" : "Favoritar") + '" data-action="favorite">' + extSideItemActionIcon("favorite", it.favorite) + '</button>';
      var duplicateMenuBtn = DUPLICATE_SUPPORTED_TYPES[it.type]
        ? '<button type="button" class="extuiSideItensMenuAction extuiSideItensActionBtn" data-action="duplicate" role="menuitem">' + extSideItemActionIcon("duplicate") + '<span>Duplicar</span></button>'
        : "";
      var editMenuBtn = '<button type="button" class="extuiSideItensMenuAction extuiSideItensActionBtn" data-action="editDashboard" role="menuitem">' + extSideItemActionIcon("edit") + '<span>Editar no Painel</span></button>';
      var moreMenu = '<span class="extuiSideItensMoreWrap">' +
        '<button type="button" class="extuiSideItensActionBtn extuiActionGlyph extuiSideItensMore" title="Mais ações" aria-label="Mais ações" aria-haspopup="menu" aria-expanded="false" data-action="more">' + extSideItemActionIcon("more") + '</button>' +
        '<span class="extuiSideItensActionMenu" role="menu">' + scheduleMenuBtn + duplicateMenuBtn + editMenuBtn + '</span>' +
        '</span>';
      return '<div class="extuiSideItensRowWrap">' +
        '<div class="extuiSideItensRow" data-type="' + escHtml(it.type) + '" data-id="' + escHtml(it.id) + '">' +
        '<span class="extuiSideItensRowIcon" title="' + escHtml(typeTitle(it.type)) + '">' + typeIcon(it.type) + '</span>' +
        '<span class="extuiSideItensRowName">' + escHtml(it.name) + '</span>' +
        runningBadge +
        chevronBtn +
        favBtn +
        moreMenu +
        '<button type="button" class="extuiSideItensActionBtn extuiActionGlyph extuiSideItensPlay" title="Enviar agora na conversa aberta" aria-label="Enviar agora na conversa aberta" data-action="play">' + extSideItemActionIcon("play") + '</button>' +
        '</div>' +
        previewWrap +
        '</div>';
    }).join("");


    if (itemsRuntime.expandedRowKey) {
      var expandedType = itemsRuntime.expandedRowKey.split(":")[0];
      var expandedId = itemsRuntime.expandedRowKey.slice(expandedType.length + 1);


      var wrap = findByAttr(listEl, "data-preview-for", itemsRuntime.expandedRowKey);
      if (wrap) {
        if (expandedType === "flow") {
          var flowRaw = (itemsRuntime.rawItemsByTypeId.flow || {})[expandedId];
          wrap.innerHTML = flowRaw ? renderFlowPreview(flowRaw) : '<div class="extuiSideItensPreview">Fluxo não encontrado</div>';
        } else if (expandedType === "funnel") {
          var funnelRaw = (itemsRuntime.rawItemsByTypeId.funnel || {})[expandedId];
          wrap.innerHTML = funnelRaw ? renderFunnelPreview(funnelRaw) : '<div class="extuiSideItensPreview">Funil não encontrado</div>';
        } else {
          renderContentPreview(expandedType, expandedId, wrap);
        }
      }
    }

    refreshRunningBadges(items);
  }


  function refreshRunningBadges(items) {
    items.forEach(function (it) {
      if (it.type !== "flow" && it.type !== "funnel") return;
      var fn = it.type === "flow" ? window.__extFluxosCountRunningByFlowId : window.__extFunnelsCountRunningByFunnelId;
      if (typeof fn !== "function") return;
      fn(it.id).then(function (count) {
        var badge = findByAttr(document, "data-running-for", it.type + ":" + it.id);
        if (!badge) return;
        if (count > 0) {
          badge.style.display = "";
          badge.textContent = "▶ " + count;
          badge.title = count === 1 ? "Rodando em 1 conversa" : "Rodando em " + count + " conversas";
        } else {
          badge.style.display = "none";
        }
      }).catch(function () {});
    });
  }


  function escHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }


  function getSendEngine() {
    return (window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null;
  }

  function safeInteractiveSend(method, chatId, task) {
    var safety = window.__extSendSafetyManager;
    if (!safety || typeof safety.enqueue !== "function") {
      return Promise.reject(Object.assign(new Error("Proteção de Envio indisponível; envio bloqueado."), { code: "SEND_SAFETY_UNAVAILABLE" }));
    }
    return safety.enqueue({ method: method, source: "quick-items", recipient: chatId, interactive: true }, task);
  }



  async function getMessageById(messageId) {
    var engine = getSendEngine();
    if (!engine) throw new Error("O WhatsApp ainda está carregando. Aguarde alguns segundos e tente novamente.");
    return await engine.chat.getMessageById(messageId);
  }
  window.__extGetMessageById = getMessageById;

  async function getChatMessages(chatId, options) {
    var engine = getSendEngine();
    if (!engine) throw new Error("O WhatsApp ainda está carregando. Aguarde alguns segundos e tente novamente.");
    return await engine.chat.getMessages(chatId, options || { count: 20, direction: "before", id: null });
  }
  window.__extGetChatMessages = getChatMessages;


  async function getMyUserId() {
    var engine = getSendEngine();
    if (!engine) throw new Error("O WhatsApp ainda está carregando. Aguarde alguns segundos e tente novamente.");
    return await engine.conn.getMyUserId();
  }


  async function ensureGroup(groupId) {
    var engine = getSendEngine();
    if (!engine) throw new Error("O WhatsApp ainda está carregando. Aguarde alguns segundos e tente novamente.");
    return await engine.group.ensureGroup(groupId);
  }



  function dedupeContactsByName(list) {
    var byName = {};
    list.forEach(function (c) {
      var name = (c.name || c.pushname || c.formattedName || "").trim();
      if (!name) return;
      var id = (c.id && c.id._serialized) || "";
      if (id.indexOf("@c.us") === -1 && id.indexOf("@lid") === -1) return;
      var key = name.toLowerCase();
      var existing = byName[key];


      if (!existing || (existing.id.indexOf("@c.us") === -1 && id.indexOf("@c.us") !== -1)) {
        byName[key] = { name: name, id: id, user: (c.id && c.id.user) || id.split("@")[0] };
      }
    });
    return Object.keys(byName).map(function (k) { return byName[k]; });
  }


  async function resolveWidToExportEntry(wid, nameHint) {
    if (!wid) return null;
    var serialized = (wid._serialized || String(wid) || "");
    if (serialized.indexOf("@g.us") !== -1) return null;
    var user = null;
    if (wid.server === "c.us" || serialized.indexOf("@c.us") !== -1) {
      user = wid.user || serialized.split("@")[0];
    } else if (wid.server === "lid" || serialized.indexOf("@lid") !== -1) {
      try {
        var lidEntry = await window.ExtensionChatBridge.contact.getPnLidEntry(serialized);
        var pn = lidEntry && lidEntry.phoneNumber && (lidEntry.phoneNumber._serialized || lidEntry.phoneNumber.user);
        if (pn) user = String(pn).replace("@c.us", "").replace("@lid", "");
      } catch (err) {                                                                    }
    }
    if (!user) return null;
    var name = nameHint || user;
    return { name: name, user: user };
  }

  function dedupeExportEntries(list) {
    var byUser = {};
    var order = [];
    list.forEach(function (c) {
      if (!c || !c.user) return;
      if (!(c.user in byUser)) { byUser[c.user] = c; order.push(c.user); }
    });
    return order.map(function (u) { return byUser[u]; });
  }


  async function resolveExportSet(opts) {
    if (!window.ExtensionChatBridge || !window.ExtensionChatBridge.isReady) {
      throw new Error("O WhatsApp ainda não está pronto para exportar contatos. Aguarde o carregamento e tente novamente.");
    }
    var contacts, unresolvedCount = 0;
    if (opts.source === "labels") {
      var labelIds = opts.labelIds || [];
      if (labelIds.length === 0) throw new Error("Selecione ao menos uma etiqueta");
      var chats = await window.ExtensionChatBridge.chat.list({ withLabels: labelIds });
      var resolved = await Promise.all(chats.map(async function (c) {
        var nameHint = (c.name || c.formattedName || c.pushname || "").trim() || null;
        return resolveWidToExportEntry(c.id, nameHint);
      }));
      resolved.forEach(function (r, i) { if (!r && chats[i] && chats[i].id && String(chats[i].id._serialized || "").indexOf("@g.us") === -1) unresolvedCount++; });
      contacts = dedupeExportEntries(resolved.filter(Boolean));
    } else if (opts.source === "group") {
      if (!opts.groupId) throw new Error("Selecione um grupo");
      var participants = await window.ExtensionChatBridge.group.getParticipants(opts.groupId);
      var resolvedP = await Promise.all((participants || []).map(async function (p) {
        var nameHint = null;
        try {
          var contact = await window.ExtensionChatBridge.contact.get(p.id);
          nameHint = (contact && (contact.name || contact.pushname || contact.formattedName)) || null;
        } catch (err) {                                                                            }
        return resolveWidToExportEntry(p.id, nameHint);
      }));
      resolvedP.forEach(function (r) { if (!r) unresolvedCount++; });
      contacts = dedupeExportEntries(resolvedP.filter(Boolean));
    } else {
      var raw = await window.ExtensionChatBridge.contact.list({ onlyMyContacts: true });
      contacts = dedupeContactsByName(raw);
      if (opts.prefix) {
        var prefixLower = opts.prefix.toLowerCase();
        contacts = contacts.filter(function (c) { return c.name.toLowerCase().indexOf(prefixLower) === 0; });
      }
      if (opts.limit && opts.limit > 0) contacts = contacts.slice(0, opts.limit);
    }
    return { contacts: contacts, unresolvedCount: unresolvedCount };
  }


  function extSpreadsheetSafeText(value) {
    var text = value == null ? "" : String(value);
    var probe = text.replace(/^[ \t\r\n]+/, "");
    if (/^[=+\-@]/.test(probe)) text = "'" + text;
    return text;
  }
  function extCsvCell(value) {
    var text = extSpreadsheetSafeText(value).replace(/\u0000/g, "");
    return '"' + text.replace(/"/g, '""') + '"';
  }
  function extVcardText(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/\r\n|\r|\n/g, "\\n")
      .replace(/;/g, "\\;")
      .replace(/,/g, "\\,");
  }

  async function exportContacts(opts) {
    var resolvedSet = await resolveExportSet(opts);
    var contacts = resolvedSet.contacts;
    if (opts.previewOnly) return { count: contacts.length, unresolvedCount: resolvedSet.unresolvedCount, contacts: contacts.slice(0, 200).map(function (contact) { return { name: String(contact && contact.name || "Contato sem nome"), user: String(contact && contact.user || "") }; }), truncated: contacts.length > 200 };
    if (contacts.length === 0) throw new Error("Nenhum contato encontrado com esses filtros");

    var dateStr = new Date().toLocaleDateString("pt-BR").split("/").join("-");
    var blob, filename;
    if (opts.format === "vcf") {
      var vcf = contacts.map(function (c) {
        var safeName = extVcardText(c.name);
        var safePhone = String(c.user == null ? "" : c.user).replace(/[^0-9+]/g, "");
        return "BEGIN:VCARD\r\nVERSION:3.0\r\nN:" + safeName + "\r\nFN:" + safeName + "\r\nTEL;TYPE=VOICE:" + safePhone + "\r\nEND:VCARD";
      }).join("\r\n");
      blob = new Blob([vcf], { type: "text/vcard" });
      filename = contacts.length + "_contatos_(" + dateStr + ").vcf";
    } else {
      var csvRows = [["First Name", "Mobile Phone"]].concat(contacts.map(function (c) { return [c.name, c.user]; }));
      var csv = csvRows.map(function (row) { return row.map(extCsvCell).join(","); }).join("\r\n") + "\r\n";
      blob = new Blob(["﻿" + csv], { type: "text/csv" });
      filename = contacts.length + "_contatos_(" + dateStr + ").csv";
    }
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function(){URL.revokeObjectURL(url);},1500);
    return { count: contacts.length, unresolvedCount: resolvedSet.unresolvedCount };
  }



  function openExportContactsModal() {
    if (!window.__extWorkspace) { toast("Painel indisponível nesta aba. Recarregue a página (F5).", true); return; }
    var active = window.__extWorkspace.activePanel;
    while (active && window.__extWorkspace && window.__extWorkspace.hasSubviews(active)) window.__extWorkspace.popSubview();
    window.__extWorkspace.pushSubview("Exportar contatos", renderExportSubview, { eyebrow: "Dados", hint: "Exporte os contatos disponíveis para CSV ou vCard." });
  }

  function renderExportSubview(body) {
    body.innerHTML = [
      '<div class="extuiSubviewIntro"><span class="extuiSubviewIntroIcon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg></span><div><strong>Exportar contatos</strong><span>Prepare um arquivo CSV ou vCard com os contatos disponíveis no WhatsApp.</span></div></div>',
      '<div class="extuiNavAgendaForm extuiSubviewFormCard">',
      '  <div class="extuiFieldGroup"><label class="extuiFieldLabel" for="extuiExportPrefix">Prefixo do nome (opcional)</label><input type="text" class="extuiNavFormInput" id="extuiExportPrefix" placeholder="Ex: Cliente -"></div>',
      '  <label class="extuiPanelToggleCard extuiSubviewToggle"><span><strong>Usar data como prefixo</strong><small>Adiciona a data atual ao nome exportado.</small></span><input type="checkbox" id="extuiExportDatePrefix"></label>',
      '  <div class="extuiFieldGroup"><label class="extuiFieldLabel" for="extuiExportLimit">Limite de contatos</label><input type="number" class="extuiNavFormInput" id="extuiExportLimit" value="0" min="0"><div class="extuiFieldHelper">Use 0 para exportar todos os contatos disponíveis.</div></div>',
      '  <div class="extuiFieldGroup"><label class="extuiFieldLabel" for="extuiExportFormat">Formato do arquivo</label><select class="extuiNavFormInput" id="extuiExportFormat"><option value="csv">CSV</option><option value="vcf">VCF (vCard)</option></select></div>',
      '</div>',
      '<button type="button" class="extuiNavPrimaryBtn extuiSubviewPrimary" id="extuiExportConfirmBtn">Exportar contatos</button>'
    ].join("\n");
    var prefixInput = body.querySelector("#extuiExportPrefix");
    body.querySelector("#extuiExportDatePrefix").addEventListener("change", function (ev) {
      prefixInput.disabled = ev.target.checked;
      if (ev.target.checked) {
        var d = new Date();
        prefixInput.value = String(d.getDate()).padStart(2, "0") + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + d.getFullYear();
      }
    });
    body.querySelector("#extuiExportConfirmBtn").addEventListener("click", async function () {
      var btn = body.querySelector("#extuiExportConfirmBtn");
      btn.disabled = true;
      btn.textContent = "Exportando...";
      try {
        var result = await exportContacts({
          prefix: prefixInput.value,
          limit: parseInt(body.querySelector("#extuiExportLimit").value, 10) || 0,
          format: body.querySelector("#extuiExportFormat").value
        });
        toast(result.count + " contato(s) exportado(s)!");
        if (window.__extWorkspace) window.__extWorkspace.popSubview();
      } catch (err) {
        toast("Falha ao exportar: " + (err && err.message ? err.message : String(err)), true);
        btn.disabled = false;
        btn.textContent = "Exportar contatos";
      }
    });
  }


  async function loadItemContent(type, itemId) {
    var raw = await extStorageGet(itemId);
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (_) { return null; }
  }


  function formatPhoneNumberForVariable(raw) {
    var d = String(raw || "").replace(/\D/g, "");
    if (!d) return "";
    if (d.length >= 12 && d.slice(0, 2) === "55") {
      var rest = d.slice(2), ddd = rest.slice(0, 2), num = rest.slice(2);
      if (num.length === 9) return "+55 (" + ddd + ") " + num.slice(0, 5) + "-" + num.slice(5);
      if (num.length === 8) return "+55 (" + ddd + ") " + num.slice(0, 4) + "-" + num.slice(4);
    }
    return "+" + d;
  }
  async function applyMessageVariables(text, chatId) {
    if (text == null) return text;
    var source = String(text);
    if (window.__extVariableResolver && typeof window.__extVariableResolver.resolveForChat === "function") return window.__extVariableResolver.resolveForChat(source, chatId);
    if (!/(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|first_name|fn|nome|nome_completo|full_name|nome_extapp|nome_whatsapp|numero|telefone|phone|email|empresa|company|origem_lead|leadSource|cidade|city|estado|state|endereco|address|cep|postalCode|idioma|language|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i.test(source)) return source;
    try {
      var engine = getSendEngine ? getSendEngine() : ((window.ExtensionChatBridge && window.ExtensionChatBridge.isReady) ? window.ExtensionChatBridge : null);
      var rawId = String(chatId && chatId._serialized || chatId || "");
      var active = null, contact = null, meta = null;
      if (engine && engine.chat && typeof engine.chat.getActiveChat === "function") {
        try { active = await engine.chat.getActiveChat(); } catch (_) {}
      }
      if (engine && engine.contact && typeof engine.contact.get === "function" && rawId) {
        try { contact = await engine.contact.get(rawId); } catch (_) {}
      }
      if (window.__extContactMetadataService && typeof window.__extContactMetadataService.get === "function" && rawId) {
        try { meta = await window.__extContactMetadataService.get(rawId); } catch (_) {}
      }
      var activeId = String(active && active.id && (active.id._serialized || active.id) || "");
      var activeContact = active && active.contact || null;
      var activeMatches = !!active && (!rawId || !activeId || activeId === rawId);
      var localName = String(meta && meta.localAlias || "").trim();
      var whatsappName = String(
        contact && (contact.name || contact.pushname || contact.formattedName || contact.notifyName || contact.shortName) ||
        (activeMatches && activeContact && (activeContact.name || activeContact.pushname || activeContact.formattedName || activeContact.notifyName || activeContact.shortName)) ||
        (activeMatches && (active.formattedTitle || active.name || active.title)) || ""
      ).trim();
      var fullName = localName || whatsappName;
      var firstName = fullName ? fullName.split(/\s+/)[0] : "";
      var rawNum = rawId.replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
      if (/@lid$/i.test(rawId) && engine && engine.contact && typeof engine.contact.getPnLidEntry === "function") {
        try {
          var lidEntry = await engine.contact.getPnLidEntry(rawId);
          var pn = lidEntry && lidEntry.phoneNumber && (lidEntry.phoneNumber._serialized || lidEntry.phoneNumber.user);
          if (pn) rawNum = String(pn).replace(/@(c|g)\.us$/i, "").replace(/@lid$/i, "");
        } catch (_) {}
      }
      var num = formatPhoneNumberForVariable(rawNum);
      var now = new Date(), hour = now.getHours();
      var greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
      var period = hour < 12 ? "manhã" : hour < 18 ? "tarde" : "noite";
      var dateStr = String(now.getDate()).padStart(2, "0") + "/" + String(now.getMonth() + 1).padStart(2, "0") + "/" + now.getFullYear();
      var timeStr = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
      var weekday = now.toLocaleDateString("pt-BR", { weekday: "long" });
      var vars = {
        primeiro_nome:firstName, primeiroNome:firstName, first_name:firstName, fn:firstName,
        nome:fullName, nome_completo:fullName, full_name:fullName,
        nome_extapp:localName || fullName, nome_ext:localName || fullName, nome_whatsapp:whatsappName || fullName,
        numero:num || "", telefone:num || "", phone:num || "",
        email:String(meta && meta.email || ""), empresa:String(meta && meta.company || ""), company:String(meta && meta.company || ""),
        origem_lead:String(meta && meta.leadSource || ""), leadSource:String(meta && meta.leadSource || ""),
        cidade:String(meta && meta.city || ""), city:String(meta && meta.city || ""), estado:String(meta && meta.state || ""), state:String(meta && meta.state || ""),
        endereco:String(meta && meta.address || ""), address:String(meta && meta.address || ""), cep:String(meta && meta.postalCode || ""), postalCode:String(meta && meta.postalCode || ""),
        idioma:String(meta && meta.language || ""), language:String(meta && meta.language || ""),
        saudacao:greeting, "saudação":greeting, periodo_dia:period, "periodo-dia":period, dia_semana:weekday, data:dateStr, hora:timeStr
      };
      function valueFor(expr) {
        var raw=String(expr||"").trim(), match=raw.match(/^([^|]+?)(?:\|\s*(?:fallback|padrao|padrão)\s*:\s*["']([^"']*)["'])?$/i);
        var key=String(match && match[1] || raw).trim(), fallback=match && match[2];
        var val=Object.prototype.hasOwnProperty.call(vars,key)?vars[key]:"";
        return val != null && String(val) !== "" ? String(val) : (fallback != null ? fallback : "");
      }
      var output=source.replace(/\{\{\s*([^{}]+?)\s*\}\}/g,function(_,expr){return valueFor(expr);});
      output=output.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(_,prefix,key){return prefix+valueFor(key);});
      var aliases=Object.keys(vars).sort(function(a,b){return b.length-a.length;});
      aliases.forEach(function(key){output=output.split("#"+key).join(String(vars[key]||""));});
      return output;
    } catch (_) { return source; }
  }


  async function sendNow(type, itemId, opts) {
    if(window.__extPlanGate)await window.__extPlanGate.requireActive();
    var _extuiFreeSend=!!(window.__extPlanGate&&await window.__extPlanGate.isFree());
    if(_extuiFreeSend&&!window.__extPlanGate.itemAllowed(entitlementItemType(type))){await window.__extPlanGate.requirePaid("Este item da Biblioteca");}
    var silent = !!(opts && opts.silent);
    var engine = getSendEngine();
    if (!engine) {
      var notReady = { ok: false, code: "WPP_NOT_READY", message: "O WhatsApp ainda está carregando. Aguarde alguns segundos e tente enviar novamente." };
      if (!silent) toast("Falha ao enviar [" + notReady.code + "]: " + notReady.message, true);
      return notReady;
    }
    var chat = null;
    if (opts && opts.targetChatId) {
      chat = { id: opts.targetChatId };
    } else {
      chat = await engine.chat.getActiveChat();
    }
    if (!chat || !chat.id) {
      var noChat = { ok: false, code: "ACTIVE_CHAT_NOT_FOUND", message: "Abra uma conversa primeiro." };
      if (!silent) toast("Falha ao enviar [" + noChat.code + "]: " + noChat.message, true);
      return noChat;
    }


    var chatId = (chat.id && chat.id._serialized) || String(chat.id);


    var _extuiAskFlag = !(opts && opts.skipConfirm) && (type === "flow" ? extOptions.askToSendFlows : type === "funnel" ? extOptions.askToSendFunnels : extOptions.askToSendSingleItem);


    if (_extuiAskFlag && !await window.extConfirm("Enviar " + (CONFIRM_LABELS[type] || "este item") + " agora?")) return "cancelled";
    if(_extuiFreeSend)await window.__extPlanGate.requireFreeQuota(type);


    var _extuiActivityId = null;
    if (type !== "flow" && type !== "funnel" && typeof window.__extActivityTrack === "function") {
      _extuiActivityId = "send:" + Date.now() + ":" + Math.random().toString(36).slice(2, 8);
      var _extuiItemMeta = itemsRuntime.allItems.find(function (it) { return it.type === type && it.id === itemId; });
      var _extuiTargetLabel = (opts && opts.targetLabel) || (chat.contact && (chat.contact.name || chat.contact.verifiedName || chat.contact.pushname)) || chat.formattedTitle || "";
      window.__extActivityTrack({ action: "start", id: _extuiActivityId, type: type, title: (_extuiItemMeta && _extuiItemMeta.name) || undefined, targetLabel: _extuiTargetLabel, status: "running", chatId: chatId });
    }
    try {
      if (type === "flow") {
        if (typeof window.__extFluxosStartFlowManually !== "function") throw new Error("fluxos-engine.js não carregado");
        await window.__extFluxosStartFlowManually(itemId, chatId);
      } else if (type === "funnel") {
        if (typeof window.__extFunnelsStartManually !== "function") throw new Error("funnels-engine.js não carregado");
        var resolvedFunnelId = itemId;
        await window.__extFunnelsStartManually(resolvedFunnelId, chatId);
      } else if (type === "quick-response") {
        if (!window.__extQuickResponseService) throw new Error("Serviço de Respostas Rápidas indisponível.");
        var qrMeta = window.__extContactMetadataService ? await window.__extContactMetadataService.get(chatId).catch(function () { return null; }) : null;
        var qrResult = await window.__extQuickResponseService.send(itemId, { contactId: chatId, chatId: chatId, remetente: chatId, contactName: qrMeta && qrMeta.localAlias || (opts && opts.targetLabel) || "", language: qrMeta && qrMeta.language || "", interactive: true });
        if (!qrResult || qrResult.status !== "success") throw new Error(qrResult && qrResult.error && qrResult.error.message || "A sequência não foi concluída.");
      } else {
        var content = await loadItemContent(type, itemId);
        if (!content) throw new Error("conteúdo do item não encontrado");
        if (type === "message") {
          await safeInteractiveSend("sendTxt", chatId, async function () { return engine.chat.sendTextMessage(chatId, await applyMessageVariables(content.data, chatId), { linkPreview: false }); });
        } else if (type === "audio") {
          var isPttAudio = content.isPtt !== false;
          var audioData = content.data, audioRelease = null;
          if (isPttAudio && !content.normalizedForWhatsApp) {
            if (typeof window.__extNormalizeAudioReference !== "function") throw new Error("O recurso que prepara notas de voz não está disponível. Recarregue o WhatsApp Web e tente novamente.");
            var normalizedAudio = await window.__extNormalizeAudioReference(audioData,{fileName:content.fileName||((_extuiItemMeta&&_extuiItemMeta.name)||"audio"),mimeType:content.mimeType||"",bitrate:32000});
            audioData = normalizedAudio.ref;
            content.data = normalizedAudio.ref;
            content.isPtt = true;
            content.mimeType = "audio/ogg";
            content.fileName = normalizedAudio.fileName || "audio.ogg";
            content.sizeBytes = normalizedAudio.sizeBytes || content.sizeBytes || 0;
            content.durationMs = normalizedAudio.durationMs || content.durationMs || 0;
            content.normalizedForWhatsApp = true;
            content.audioCodec = "opus";
            content.audioContainer = "ogg";
            content.codecVersion = 2;
            content.sourceMimeType = normalizedAudio.sourceMimeType || content.sourceMimeType || "";
            try { await extStorageSet(itemId, JSON.stringify(content)); } catch (persistErr) {}
          }
          if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(audioData)) { audioData = await window.ExtensionMediaStore.portable(audioData); }
          try { await safeInteractiveSend("sendAudio", chatId, function () { return engine.chat.sendFileMessage(chatId, audioData, { isPtt: isPttAudio, isViewOnce: content.asViewOnce, type: "audio", mimetype: isPttAudio ? "audio/ogg" : (content.mimeType || undefined), filename: content.fileName || undefined }); }); }
          finally { if (audioRelease && window.ExtensionMediaStore) window.ExtensionMediaStore.releaseOwnedUrl(audioRelease); }
        } else if (type === "sticker") {
          var stickerData = content.data, stickerRelease = null, stickerPrepared = null;
          if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(stickerData)) { stickerData = await window.ExtensionMediaStore.portable(stickerData); }
          try { await safeInteractiveSend("sticker", chatId, function () { return engine.chat.sendFileMessage(chatId, stickerData, { type: "sticker", mimetype: "image/webp", filename: content.fileName || (stickerPrepared && stickerPrepared.name) || "sticker.webp" }); }); }
          finally { if (stickerRelease && window.ExtensionMediaStore) window.ExtensionMediaStore.releaseOwnedUrl(stickerRelease); }
        } else if (type === "document") {
          var documentData = content.data, documentRelease = null, documentPrepared = null;
          if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(documentData)) { documentData = await window.ExtensionMediaStore.portable(documentData); }
          var documentMime = content.mimeType || (documentPrepared && documentPrepared.mime) || "application/octet-stream";
          var documentName = content.fileName || (documentPrepared && documentPrepared.name) || ((_extuiItemMeta && _extuiItemMeta.name) || "documento");
          try { await safeInteractiveSend("sendDoc", chatId, function () { return engine.chat.sendFileMessage(chatId, documentData, { filename: documentName, mimetype: documentMime, type: "document" }); }); }
          finally { if (documentRelease && window.ExtensionMediaStore) window.ExtensionMediaStore.releaseOwnedUrl(documentRelease); }
        } else if (type === "media" || type === "image" || type === "video") {
          var mediaData = content.data, mediaRelease = null, mediaPrepared = null;
          if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(mediaData)) { mediaData = await window.ExtensionMediaStore.portable(mediaData); }
          var mediaMime = String(content.mimeType || (mediaPrepared && mediaPrepared.mime) || "").toLowerCase();
          var mediaName = content.fileName || (mediaPrepared && mediaPrepared.name) || undefined;
          var mediaKind = content.sendAsDocument ? "document" : window.ExtensionChatBridge.mediaKind(mediaData,{type:"auto-detect",mimeType:mediaMime,filename:mediaName});
          try { await safeInteractiveSend(mediaKind === "video" ? "sendVideo" : mediaKind === "image" ? "sendImage" : "sendDoc", chatId, function () { return engine.chat.sendFileMessage(chatId, mediaData, mediaKind === "document" ? { type: "document", mimetype: mediaMime || "application/octet-stream", filename: mediaName || "arquivo" } : { type: mediaKind, mimetype: mediaMime || undefined, filename: mediaName, caption: content.caption, isViewOnce: content.asViewOnce, isPtv: mediaKind === "video" && !!content.isPtv }); }); }
          finally { if (mediaRelease && window.ExtensionMediaStore) window.ExtensionMediaStore.releaseOwnedUrl(mediaRelease); }
        } else if (type === "interactive-list") {
          var interactiveListApi = window.__extInteractiveList;
          if (!interactiveListApi) throw new Error("O recurso de listas interativas não está disponível. Recarregue o WhatsApp Web e tente novamente.");
          var listOptions = interactiveListApi.toSendOptions(content);
          await safeInteractiveSend("sendListMessage", chatId, function () { return engine.chat.sendListMessage(chatId, listOptions); });
        } else if (type === "pix") {


          await safeInteractiveSend("sendPixKeyMessage", chatId, function () { return engine.chat.sendPixKeyMessage(chatId, { keyType: content.keyType, name: content.merchantName || content.name || "PIX", key: content.key }); });
        } else if (type === "contact") {


          await safeInteractiveSend("sendContact", chatId, function () { return engine.chat.sendVCardContactMessage(chatId, { id: content.contactPhone.replace(/\D/g, "") + "@c.us", name: content.contactName }); });
        }
      }
      if(_extuiFreeSend){try{await window.__extPlanGate.usageCommit(type);}catch(_quotaErr){if(!silent)toast("Enviado, mas o limite gratuito não pôde ser sincronizado. Novos envios ficam pausados até recarregar o WhatsApp Web.",true);}}
      if (_extuiActivityId) window.__extActivityTrack({ action: "success", id: _extuiActivityId });
      if (!silent) toast("Enviado!");
      return true;
    } catch (err) {
      var sendErrorMessage = err && err.message ? err.message : String(err);
      var sendErrorCode = err && err.code ? String(err.code) : "SEND_FAILED";
      if (_extuiActivityId) window.__extActivityTrack({ action: "error", id: _extuiActivityId, errorMessage: sendErrorMessage });
      if (!silent) toast("Falha ao enviar [" + sendErrorCode + "]: " + sendErrorMessage, true);
      return { ok: false, code: sendErrorCode, message: sendErrorMessage };
    }
  }


  window.__extItemsSendNow = sendNow;


  async function scheduleViaAgenda(type, itemId) {
    if(window.__extPlanGate&&await window.__extPlanGate.isFree()&&!window.__extPlanGate.itemAllowed(entitlementItemType(type))){await window.__extPlanGate.requirePaid("Este tipo de agendamento").catch(function(){});return;}
    if (typeof window.__extScheduleViaAgenda !== "function") {
      toast("Agenda ainda não carregou - tente novamente em instantes", true);
      return;
    }
    closePanel();
    window.__extScheduleViaAgenda(storageItemType(type), itemId);
  }


  async function toggleItemFavorite(type, id) {
    var cfg = ITEM_STORAGE_BY_TYPE[storageItemType(type)];
    if (!cfg) return;
    try {
      var raw = await extStorageGet(cfg.key);
      var parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
      var list = (parsed && parsed.state && parsed.state[cfg.listField]) || [];
      var item = list.filter(function (r) { return r && r.id === id; })[0];
      if (!item) { toast("Item não está mais disponível.", true); return; }
      item.favorite = !item.favorite;
      var payload = {}; payload[cfg.listField] = list;
      await extStorageSet(cfg.key, JSON.stringify({ state: payload, version: 0 }));
    } catch (err) {
      toast("Não foi possível atualizar o favorito.", true);
    }
  }

  async function duplicateItem(type, id) {
    var cfg = ITEM_STORAGE_BY_TYPE[storageItemType(type)];
    if (!cfg || !DUPLICATE_SUPPORTED_TYPES[type]) return;
    try {
      var raw = await extStorageGet(cfg.key);
      var parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
      var list = (parsed && parsed.state && parsed.state[cfg.listField]) || [];
      var item = list.filter(function (r) { return r && r.id === id; })[0];
      if (!item) { toast("Item não está mais disponível.", true); return; }
      var content = await loadItemContent(type, id);
      var newId = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : ("id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10));
      list.push(Object.assign({ id: newId, name: ((item.name && String(item.name).trim()) || "(sem nome)") + " (cópia)", favorite: false }, (type === "image" || type === "video") ? { mediaKind: type } : {}));
      var payload = {}; payload[cfg.listField] = list;


      await extStorageSet(newId, JSON.stringify(content || {}));
      try {
        await extStorageSet(cfg.key, JSON.stringify({ state: payload, version: 0 }));
      } catch (writeErr) {
        try { await extStorageRemove(newId); } catch (_) {}
        throw writeErr;
      }
      toast("Item duplicado.");
    } catch (err) {
      toast("Não foi possível duplicar o item.", true);
    }
  }

  function editInDashboard(type) {
    var section = EDIT_IN_DASHBOARD_SECTION_BY_TYPE[type];
    if (!section || typeof window.__extOpenShellHtml !== "function") {
      toast("Não foi possível abrir o Painel de Controle.", true);
      return;
    }
    window.__extOpenShellHtml(section);
  }

  function buildPanel() {
    var existing = document.getElementById(PANEL_ID);
    if (existing) return existing;


    var root = window.__extBuildPanelShell({
      id: PANEL_ID,
      title: "Itens",
      eyebrow: "BIBLIOTECA",
      hint: "Acesse e envie rapidamente seus itens salvos.",
      accent: "#f5a623",
      icon: '<path d="M4 6h16M4 12h16M4 18h10"/>',
      size: "md"
    });
    root.classList.add("extuiSideItensPanel");

    var body = root.querySelector("[data-extui-panel-body]");
    body.innerHTML = [
      '<div class="extuiSideItensToolbar">',
      '  <input type="text" id="extuiSideItensSearch" placeholder="Buscar..." aria-label="Buscar itens salvos">',
      '  <label class="extuiSideItensFavToggle"><input type="checkbox" id="extuiSideItensFavCheck"> Apenas favoritos</label>',
      '</div>',
      '<div class="extuiSideItensTypeRow" id="extuiSideItensTypeRow" role="group" aria-label="Tipos de itens">',
      TYPE_ICONS.map(function (t) {
        var locked=itemsRuntime.itemsFreePlan&&window.__extPlanGate&&!window.__extPlanGate.itemAllowed(t.type);
        return '<button type="button" class="extuiSideItensTypeBtn extuiActive'+(locked?' extuiPlanLocked':'')+'" data-type="' + t.type + '" '+(locked?'data-plan-locked="true" ':'')+'title="' + t.title + (locked?' · Pro':'') + '" aria-pressed="true"><span class="extuiSideItensTypeCard"><span class="extuiSideItensTypeChip">' + t.icon + '</span><span class="extuiSideItensTypeLabel">' + escHtml(t.title) + '</span>'+(locked?'<small class="extuiSideItensProBadge">PRO</small>':'')+'</span></button>';
      }).join("\n"),
      '</div>',
      '<div class="extuiSideItensList" id="extuiSideItensList"></div>'
    ].join("\n");

    function applyItemsPlanUi(){
      root.querySelectorAll(".extuiSideItensTypeBtn[data-type]").forEach(function(btn){var locked=itemsRuntime.itemsFreePlan&&window.__extPlanGate&&!window.__extPlanGate.itemAllowed(entitlementItemType(btn.getAttribute("data-type")));btn.toggleAttribute("data-plan-locked",locked);btn.classList.toggle("extuiPlanLocked",locked);var card=btn.querySelector(".extuiSideItensTypeCard"),badge=btn.querySelector(".extuiSideItensProBadge");if(locked&&!badge&&card){badge=document.createElement("small");badge.className="extuiSideItensProBadge";badge.textContent="PRO";card.appendChild(badge);}else if(!locked&&badge)badge.remove();});
    }
    root.__extApplyItemsPlanUi=applyItemsPlanUi;applyItemsPlanUi();

    root.querySelector("[data-close]").addEventListener("click", closePanel);
    root.querySelector("#extuiSideItensSearch").addEventListener("input", function (ev) {
      state.query = ev.target.value;
      renderList();
    });
    root.querySelector("#extuiSideItensFavCheck").addEventListener("change", function (ev) {
      state.onlyFavorites = ev.target.checked;
      renderList();
    });
    root.querySelector("#extuiSideItensTypeRow").addEventListener("click", async function (ev) {
      var btn = ev.target.closest(".extuiSideItensTypeBtn");
      if (!btn) return;
      var type = btn.getAttribute("data-type");
      if(itemsRuntime.itemsFreePlan&&window.__extPlanGate&&!window.__extPlanGate.itemAllowed(entitlementItemType(type))){await window.__extPlanGate.requirePaid(typeTitle(type)).catch(function(){});return;}
      btn.classList.toggle("extuiActive");
      btn.setAttribute("aria-pressed",btn.classList.contains("extuiActive")?"true":"false");
      state.hiddenTypes[type] = !btn.classList.contains("extuiActive");
      renderList();
    });
    root.querySelector("#extuiSideItensList").addEventListener("click", function (ev) {
      var actionBtn = ev.target.closest(".extuiSideItensActionBtn");
      var clickedWrap = ev.target.closest(".extuiSideItensMoreWrap");
      root.querySelectorAll(".extuiSideItensMoreWrap.extuiOpen").forEach(function (wrap) {
        if (wrap !== clickedWrap) {
          wrap.classList.remove("extuiOpen");
          var trigger = wrap.querySelector('[data-action="more"]');
          if (trigger) trigger.setAttribute("aria-expanded", "false");
        }
      });
      if (!actionBtn) return;
      var row = actionBtn.closest(".extuiSideItensRow");
      if (!row) return;
      var type = row.getAttribute("data-type");
      var id = row.getAttribute("data-id");
      var action = actionBtn.getAttribute("data-action");
      if (action === "more") {
        var wrap = actionBtn.closest(".extuiSideItensMoreWrap");
        var open = !wrap.classList.contains("extuiOpen");
        wrap.classList.toggle("extuiOpen", open);
        actionBtn.setAttribute("aria-expanded", open ? "true" : "false");
        return;
      }
      var actionWrap = actionBtn.closest(".extuiSideItensMoreWrap");
      if (actionWrap) {
        actionWrap.classList.remove("extuiOpen");
        var actionTrigger = actionWrap.querySelector('[data-action="more"]');
        if (actionTrigger) actionTrigger.setAttribute("aria-expanded", "false");
      }
      if (action === "play") sendNow(type, id);
      else if (action === "schedule") scheduleViaAgenda(type, id);
      else if (action === "favorite") toggleItemFavorite(type, id);
      else if (action === "duplicate") duplicateItem(type, id);
      else if (action === "editDashboard") editInDashboard(type);
      else if (action === "expand") {
        var rowKey = type + ":" + id;
        itemsRuntime.expandedRowKey = (itemsRuntime.expandedRowKey === rowKey) ? null : rowKey;
        renderList();
      }
    });
    root.querySelector("#extuiSideItensList").addEventListener("keydown", function (ev) {
      if (ev.key !== "Escape") return;
      root.querySelectorAll(".extuiSideItensMoreWrap.extuiOpen").forEach(function (wrap) {
        wrap.classList.remove("extuiOpen");
        var trigger = wrap.querySelector('[data-action="more"]');
        if (trigger) { trigger.setAttribute("aria-expanded", "false"); trigger.focus(); }
      });
    });


    return root;
  }

  async function openPanel() {
    itemsRuntime.itemsFreePlan=!!(window.__extPlanGate&&await window.__extPlanGate.isFree());
    var root = buildPanel();
    if(root.__extApplyItemsPlanUi)root.__extApplyItemsPlanUi();


    root.style.display = "";
    if (window.__extWorkspace) window.__extWorkspace.open(root);
    else { root.hidden = false; root.setAttribute("aria-hidden", "false"); root.classList.add("extuiOpen"); }
    var listEl = document.getElementById("extuiSideItensList");
    if (listEl) listEl.innerHTML = extItemsListState("loading", "Carregando itens", "Sincronizando sua biblioteca com a extensão.");
    try {
      itemsRuntime.allItems = await loadAllItems();
      renderList();
    } catch (err) {
      if (listEl) listEl.innerHTML = extItemsListState("error", "Não foi possível carregar os itens", "Tente novamente ao reabrir este painel.");
    }
  }

  function closePanel() {
    var root = document.getElementById(PANEL_ID);
    if (root && window.__extWorkspace && window.__extWorkspace.activePanel === root) window.__extWorkspace.close();
    else if (root) { root.classList.remove("extuiOpen"); root.hidden = true; root.setAttribute("aria-hidden", "true"); }
    if (window.__extSyncNavActive) window.__extSyncNavActive();
  }

  function togglePanel() {
    var root = document.getElementById(PANEL_ID);
    var isOpen = root && root.classList.contains("extuiOpen");
    if (isOpen) closePanel();
    else openPanel();
  }

  window.ExtensionCore = window.ExtensionCore || {};
  var panelControllers = window.ExtensionCore.PanelControllers;
  if (!panelControllers) {
    panelControllers = Object.create(null);
    Object.defineProperty(window.ExtensionCore, "PanelControllers", { value: panelControllers, writable: false, configurable: false, enumerable: true });
  }
  Object.defineProperty(panelControllers, "items", { value: Object.freeze({ open: openPanel, close: closePanel, toggle: togglePanel, exportContacts: openExportContactsModal }), writable: false, configurable: false, enumerable: true });


  chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){
    if(!msg||!sender||sender.id!==chrome.runtime.id)return;
    var work=null;
    if(msg.type==="EXTUI_EXPORT_CONTACTS"){
      var payload=msg.payload||{};
      work=(window.__extPlanGate?window.__extPlanGate.requirePaid("Exportar Contatos"):Promise.resolve(true)).then(function(){return exportContacts({source:payload.source,prefix:payload.prefix,limit:payload.limit,format:payload.format,labelIds:payload.labelIds,groupId:payload.groupId,previewOnly:payload.previewOnly});});
    }else if(msg.type==="EXTUI_ITEMS_SEND_NOW"){
      var sendPayload=msg.payload||{};
      work=Promise.resolve(sendNow(sendPayload.type,sendPayload.itemId,{targetChatId:sendPayload.targetChatId,targetLabel:sendPayload.targetLabel,silent:true,skipConfirm:!!sendPayload.skipConfirm})).then(function(result){
        if(result==="cancelled")return{cancelled:true};
        if(result===true)return{ok:true};
        if(result&&result.ok===false){var err=new Error(result.message||"Falha ao enviar");err.code=result.code||"SEND_FAILED";throw err;}
        if(result)return{ok:true};
        throw new Error("Não foi possível enviar. Confira se o WhatsApp Web está aberto e conectado.");
      });
    }else return;
    Promise.resolve(work).then(function(data){sendResponse({requestId:msg.requestId||null,data:data,error:null});}).catch(function(err){sendResponse({requestId:msg.requestId||null,data:null,error:err&&err.message||String(err),code:err&&err.code||null});});
    return true;
  });


  setTimeout(function () { loadItemPanelOptions().catch(function () {}); }, 1400);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
