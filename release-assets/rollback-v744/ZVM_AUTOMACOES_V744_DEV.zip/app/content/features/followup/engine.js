;
try{


(function(){
  "use strict";
  if(window.__extFollowUpEngineBooted)return;
  window.__extFollowUpEngineBooted=true;

  var RULES_KEY="EXTUI:extappFollowUpStore",QUEUE_KEY="EXTUI:extappFollowUpQueueStore",CRM_KEY="EXTUI:CrmStore",MEMBERSHIP_KEY="EXTUI:extappFollowUpMembershipStore";
  var tickMutex=Promise.resolve(),started=false,cancelledFollowupIds=new Set();
  function queueStateMutation(work){var op=tickMutex.then(work,work);tickMutex=op.catch(function(){});return op;}
  function repo(){if(!window.ExtensionStorage){var e=new Error("Os dados da extensão não estão disponíveis no momento");e.code="STORAGE_UNAVAILABLE";throw e;}return window.ExtensionStorage;}
  function parse(raw){if(raw==null||raw==="")return null;try{return typeof raw==="string"?JSON.parse(raw):raw;}catch(err){err.code=err.code||"FOLLOWUP_STORE_CORRUPT";throw err;}}
  function state(raw){var p=parse(raw);if(p==null)return{};if(!p||typeof p!=="object"||Array.isArray(p)||!p.state||typeof p.state!=="object"||Array.isArray(p.state)){var invalid=new Error("Os dados de Follow-up estão inválidos e não serão sobrescritos.");invalid.code="FOLLOWUP_STORE_CORRUPT";throw invalid;}return p.state;}
  async function loadRules(){var s=state(await repo().get(RULES_KEY));return Array.isArray(s.followUpList)?s.followUpList:[];}
  async function loadQueue(){var s=state(await repo().get(QUEUE_KEY));return Array.isArray(s.queue)?s.queue:[];}
  async function saveQueue(q){return repo().set(QUEUE_KEY,JSON.stringify({state:{queue:q},version:1}));}
  async function loadCrm(){var s=state(await repo().get(CRM_KEY));return Array.isArray(s.crmList)?s.crmList:[];}
  async function loadMembership(){var p=parse(await repo().get(MEMBERSHIP_KEY));if(p==null)return{schemaVersion:1,rules:{}};if(!p||typeof p!=="object"||Array.isArray(p)||!p.rules||typeof p.rules!=="object"||Array.isArray(p.rules)){var invalid=new Error("Os dados internos do Follow-up estão inválidos e não serão sobrescritos.");invalid.code="FOLLOWUP_STORE_CORRUPT";throw invalid;}return p;}
  async function saveMembership(m){m.schemaVersion=1;m.updatedAt=Date.now();return repo().set(MEMBERSHIP_KEY,JSON.stringify(m));}
  function uid(){return (globalThis.crypto&&crypto.randomUUID)?crypto.randomUUID():("fu-"+Date.now()+"-"+Math.random().toString(36).slice(2,9));}
  function digits(v){return String(v||"").replace(/@.*/,"").replace(/\D/g,"");}
  function contactKey(item){var c=item&&item.contact||item||{};return String(c.chatId||c.id||c.phoneNumber||"").trim();}
  function contactPhone(item){var c=item&&item.contact||item||{};return c.phoneNumber||c.chatId||c.id||"";}
  function contactName(item){var c=item&&item.contact||item||{};return c.name||c.pushname||c.phoneNumber||c.chatId||"";}
  function currentColumn(crms,source){
    var crm=crms.find(function(c){return c&&c.id===source.crmId;});if(!crm)return {exists:false,items:[]};
    var col=(crm.columns||[]).find(function(c){return c&&c.id===source.columnId;});if(!col)return {exists:false,items:[]};
    return {exists:true,items:Array.isArray(col.items)?col.items:[]};
  }
  function triggerKind(rule){var t=String(rule&&rule.acionamento&&rule.acionamento.type||rule.trigger||"");if(t==="onEnter"||t==="dispararAoEntrar")return "enter";if(t==="onExit"||t==="dispararAoSair")return "exit";return "timing";}
  function timingMs(rule){var t=rule&&rule.acionamento&&rule.acionamento.timing||rule&&rule.timing||{};return (Number(t.days)||0)*86400000+(Number(t.hours)||0)*3600000+(Number(t.minutes)||0)*60000+(Number(t.seconds)||0)*1000;}
  function allowsGroup(rule,chat){if(String(chat||"").indexOf("@g.us")<0)return true;var r=rule&&rule.regras&&rule.regras.responderGrupos;return !!(r&&(r.active===true||r.propriedades&&r.propriedades.active===true));}
  function emit(name,payload){try{if(window.__extEventBus)window.__extEventBus.emit(name,payload,{source:"followup"});}catch(_){}}

  async function resolveTarget(raw){
    var value=String(raw||"");if(value.indexOf("@")>=0){
      if(value.indexOf("@lid")>=0&&window.__extWppBridge){try{var resolved=await window.__extWppBridge.invoke("Whatsapp","getUserContact",value);if(resolved)return resolved._serialized||resolved;}catch(_){}}
      return value;
    }
    var d=digits(value);if(!d)throw new Error("Não foi possível identificar o telefone do contato");var c=d+"@c.us";
    if(window.__extWppBridge){try{var q=await window.__extWppBridge.invoke("Contact","queryExists",c);return q&&q.lid&&q.lid._serialized||q&&q.wid&&q.wid._serialized||c;}catch(_){}}
    return c;
  }
  async function actionsForRule(rule){
    if(Array.isArray(rule.actions)&&rule.actions.length)return rule.actions;
    if(rule.quickResponseId)return [{type:"respostaRapida",properties:{respostaRapidaID:rule.quickResponseId}}];
    if(window.__extQuickResponseService&&rule.sendType&&rule.itemId){var a=await window.__extQuickResponseService.nativeToActions(rule.sendType,rule.itemId);if(a&&a.length)return a;}
    return null;
  }
  async function dispatch(rule,entry,lease){
    var target=await resolveTarget(entry.chatId||entry.phoneNumber);if(!allowsGroup(rule,target)){var e=new Error("Regra não permite grupos");e.code="FOLLOWUP_GROUP_BLOCKED";throw e;}
    if(rule.sendType==="funnel"&&!rule.actions&&!rule.quickResponseId){if(typeof window.__extFunnelsStartManually!=="function")throw new Error("funnels-engine.js não carregado");return window.__extFunnelsStartManually(rule.itemId,target);}
    if(rule.sendType==="flow"&&!rule.actions&&!rule.quickResponseId){if(typeof window.__extFluxosStartFlowManually!=="function")throw new Error("fluxos-engine.js não carregado");return window.__extFluxosStartFlowManually(rule.itemId,target);}
    var actions=await actionsForRule(rule);if(!actions){var er=new Error("Ações do Follow-up não encontradas");er.code="FOLLOWUP_ACTIONS_NOT_FOUND";throw er;}
    var ex=await window.__extActionExecutor.execute(actions,{source:"followup",contactId:target,remetente:target,followUpId:rule.id,executionId:"followup:"+entry.id,variables:rule.variables||{},cancellationSignal:lease&&lease.signal||null});
    if(ex.status!=="success"){var ee=new Error(ex.error&&ex.error.message||"ActionExecutor falhou");ee.code=ex.error&&ex.error.code||"FOLLOWUP_ACTION_ERROR";throw ee;}return ex;
  }
  function pendingFor(q,ruleId,key,cycle){return q.some(function(x){return x.followUpId===ruleId&&x.contactKey===key&&x.status==="pending"&&(!cycle||x.cycle===cycle);});}
  function enqueue(queue,rule,item,kind,at){
    var key=contactKey(item);if(!key)return null;var cycle=kind+":"+at;
    if(pendingFor(queue,rule.id,key,cycle))return null;
    var e={id:uid(),followUpId:rule.id,contactKey:key,phoneNumber:contactPhone(item),chatId:(item.contact&&item.contact.chatId)||null,chatName:contactName(item),trigger:kind,cycle:cycle,enqueuedAtMs:at,status:"pending",firedAtMs:null,errorMessage:null};queue.push(e);return e;
  }
  async function syncMembership(rules,crms,queue,membership,t){
    var changed=false,memChanged=false,activeIds=new Set();
    for(var ri=0;ri<rules.length;ri++){
      var rule=rules[ri];if(!rule.active||!rule.source||!rule.source.crmId||!rule.source.columnId)continue;activeIds.add(rule.id);
      var col=currentColumn(crms,rule.source);if(!col.exists)continue;
      var prev=membership.rules[rule.id]||{members:{},initialized:false};var nextMembers={};
      col.items.forEach(function(item){var k=contactKey(item);if(k)nextMembers[k]={phoneNumber:contactPhone(item),chatId:item.contact&&item.contact.chatId||null,chatName:contactName(item)};});
      if(!prev.initialized){


        if(triggerKind(rule)!=="exit")col.items.forEach(function(item){if(enqueue(queue,rule,item,triggerKind(rule),t))changed=true;});
      }else{
        var added=Object.keys(nextMembers).filter(function(k){return !prev.members[k];});
        var removed=Object.keys(prev.members||{}).filter(function(k){return !nextMembers[k];});
        added.forEach(function(k){var item=col.items.find(function(x){return contactKey(x)===k;});if(item&&triggerKind(rule)!=="exit"&&enqueue(queue,rule,item,triggerKind(rule),t))changed=true;});
        removed.forEach(function(k){

          queue.forEach(function(q){if(q.followUpId===rule.id&&q.contactKey===k&&q.status==="pending"&&q.trigger==="timing"){q.status="cancelled";q.errorMessage="contato saiu da tab antes do disparo";q.cancelledAtMs=t;changed=true;}});
          if(triggerKind(rule)==="exit"){var p=prev.members[k]||{};if(enqueue(queue,rule,{contact:{phoneNumber:p.phoneNumber,chatId:p.chatId,name:p.chatName}},"exit",t))changed=true;}
        });
        if(added.length||removed.length)emit("FollowUpMembershipChanged",{followUpId:rule.id,chatsAdded:added,chatsRemoved:removed});
      }
      membership.rules[rule.id]={members:nextMembers,initialized:true,updatedAt:t};memChanged=true;
    }

    Object.keys(membership.rules).forEach(function(id){if(!activeIds.has(id)){delete membership.rules[id];memChanged=true;}});
    return {queueChanged:changed,membershipChanged:memChanged};
  }
  function isDue(entry,rule,t){if(entry.status!=="pending")return false;if(entry.trigger==="enter"||entry.trigger==="exit")return true;return t>=Number(entry.enqueuedAtMs||0)+timingMs(rule);}
  async function fireDue(rules,queue,t,lease){var changed=false;
    for(var i=0;i<queue.length;i++){if(lease&&!lease.isActive())break;var e=queue[i],rule=rules.find(function(r){return r.id===e.followUpId;});if(!rule){if(e.status==="pending"){e.status="cancelled";e.errorMessage="regra removida";changed=true;}continue;}if(!rule.active||!isDue(e,rule,t))continue;
      var aid=typeof window.__extActivityTrack==="function"?"followup:"+e.id:null;if(aid)window.__extActivityTrack({action:"start",id:aid,type:"followup",title:rule.nome||"Follow-up",targetLabel:e.chatName||e.phoneNumber||"",status:"running",chatId:e.chatId||e.phoneNumber||"",executionId:"followup:"+e.id});
      e.status="sending";e.attemptedAtMs=t;changed=true;
      try{if(cancelledFollowupIds.has(e.id))throw Object.assign(new Error("Follow-up cancelado manualmente"),{code:"FOLLOWUP_CANCELLED_MANUAL"});if(lease)lease.assertActive();await dispatch(rule,e,lease);if(cancelledFollowupIds.has(e.id))throw Object.assign(new Error("Follow-up cancelado manualmente"),{code:"FOLLOWUP_CANCELLED_MANUAL"});e.status="sent";e.firedAtMs=Date.now();e.errorMessage=null;if(aid)window.__extActivityTrack({action:"success",id:aid});emit("FollowUpSent",{followUpId:rule.id,queueId:e.id,trigger:e.trigger,contactKey:e.contactKey,chatId:e.chatId||null,phoneNumber:e.phoneNumber||null});}
      catch(err){if(cancelledFollowupIds.has(e.id)||(err&&err.code==="FOLLOWUP_CANCELLED_MANUAL")){e.status="cancelled";e.cancelledAtMs=Date.now();e.errorMessage="cancelado manualmente";if(aid)window.__extActivityTrack({action:"cancel",id:aid});emit("FollowUpCancelled",{followUpId:rule.id,queueId:e.id,manual:true});}else{e.status="error";e.errorMessage=err&&err.message?err.message:String(err);if(aid)window.__extActivityTrack({action:"error",id:aid,errorMessage:e.errorMessage});emit("FollowUpFailed",{followUpId:rule.id,queueId:e.id,error:e.errorMessage,contactKey:e.contactKey,chatId:e.chatId||null,phoneNumber:e.phoneNumber||null});} }finally{cancelledFollowupIds.delete(e.id);}
    }return changed;
  }
  function runTick(reason){var op=queueStateMutation(async function(){if(typeof window.__extWithAutomationLease!=="function"){var coordErr=new Error("Coordenação segura entre abas indisponível.");coordErr.code="AUTOMATION_COORDINATOR_UNAVAILABLE";throw coordErr;}return window.__extWithAutomationLease("followup-tick",async function(lease){if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return;var rules=await loadRules(),queue=await loadQueue(),crms=await loadCrm(),m=await loadMembership(),t=Date.now();lease.assertActive();var sync=await syncMembership(rules,crms,queue,m,t);var fired=lease.isActive()?await fireDue(rules,queue,t,lease):false;if(sync.queueChanged||fired)await saveQueue(queue);if(sync.membershipChanged)await saveMembership(m);lease.assertActive();emit("FollowUpTickCompleted",{reason:reason||"fallback",queueChanged:sync.queueChanged||fired});});});return op.catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("FOLLOWUP_TICK_FAILED",err);emit("FollowUpTickFailed",{error:err&&err.message||String(err)});});}
  async function cancelOnReply(payload){
    var data=payload&&payload.data||payload||{};var from=data.from&&data.from._serialized||data.author&&data.author._serialized||data.from||payload&&payload.author||"";if(!from)return;
    var resolved=String(from);if(resolved.indexOf("@lid")>=0&&window.__extWppBridge){try{var r=await window.__extWppBridge.invoke("Whatsapp","getUserContact",resolved);resolved=r&&r._serialized||r||resolved;}catch(_){}}
    var d=digits(resolved);if(!d)return;
    queueStateMutation(async function(){var rules=(await loadRules()).filter(function(r){return r.active&&r.cancelOnReply;});if(!rules.length)return;var ids=new Set(rules.map(function(r){return r.id;})),q=await loadQueue(),changed=false;q.forEach(function(e){if(e.status!=="pending"||!ids.has(e.followUpId))return;if(digits(e.phoneNumber||e.chatId||e.contactKey)!==d)return;e.status="cancelled";e.cancelledAtMs=Date.now();e.errorMessage="contato respondeu antes do disparo";changed=true;emit("FollowUpCancelledOnReply",{followUpId:e.followUpId,queueId:e.id,contactKey:e.contactKey});});if(changed)await saveQueue(q);}).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("FOLLOWUP_REPLY_CANCEL_FAILED",err);});
  }
  async function cancelQueue(id){id=String(id||"");if(!id)return false;cancelledFollowupIds.add(id);try{if(window.__extActionExecutor&&typeof window.__extActionExecutor.cancel==="function")window.__extActionExecutor.cancel("followup:"+id);}catch(_){}var result=await queueStateMutation(async function(){var q=await loadQueue(),entry=q.find(function(x){return x&&String(x.id)===id;});if(!entry)return false;if(["sent","cancelled","error"].indexOf(entry.status)>=0)return false;entry.status="cancelled";entry.cancelledAtMs=Date.now();entry.errorMessage="cancelado manualmente";await saveQueue(q);if(typeof window.__extActivityTrack==="function")window.__extActivityTrack({action:"cancel",id:"followup:"+id});emit("FollowUpCancelled",{followUpId:entry.followUpId,queueId:id,manual:true});return true;});if(!result)cancelledFollowupIds.delete(id);else setTimeout(function(){cancelledFollowupIds.delete(id);},300000);return result;}
  function start(){if(started)return;started=true;var b=window.__extEventBus;if(b){b.on("FollowUpTimingTick",function(){runTick("eventbus-5m");});b.on("MessageReceived",cancelOnReply);}repo().subscribe(CRM_KEY,function(){runTick("crm-changed");});repo().subscribe(RULES_KEY,function(){runTick("rules-changed");});setInterval(function(){runTick(b?"120s-fallback":"30s-fallback");},b?120000:30000);runTick("startup");}
  var api=Object.freeze({version:"2.1.0",runTick:runTick,loadRules:loadRules,loadQueue:loadQueue,loadMembership:loadMembership,cancelQueue:cancelQueue,triggerKind:triggerKind,timingMs:timingMs,start:start});window.__extFollowUpService=api;window.ExtensionCore=window.ExtensionCore||{};setTimeout(start,1400);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
