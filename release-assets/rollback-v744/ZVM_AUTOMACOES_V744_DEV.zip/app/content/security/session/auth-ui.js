try{
(function () {
  "use strict";


  if (window.__extLoginOverlayBooted) return;
  window.__extLoginOverlayBooted = true;


  function getLicenseService() {
    if (!window.__extS0) {
      return null;
    }
    return window.__extS0;
  }

  function sendSecurityRequest(message) {
    return new Promise(function(resolve,reject){
      var settled=false;
      var timer=setTimeout(function(){if(settled)return;settled=true;reject(Object.assign(new Error("A validação demorou demais. Tente novamente."),{code:"LICENSE_WORKER_TIMEOUT"}));},45000);
      try{
        chrome.runtime.sendMessage(message,function(response){
          if(settled)return;settled=true;clearTimeout(timer);
          if(chrome.runtime.lastError){reject(chrome.runtime.lastError);return;}
          if(!response||response.ok!==true){var err=new Error(response&&response.userMessage||"Falha ao validar acesso.");err.code=response&&response.errorCode||"LICENSE_ERROR";reject(err);return;}
          resolve(response.result||{});
        });
      }catch(err){if(settled)return;settled=true;clearTimeout(timer);reject(err);}
    });
  }

  function hasLocalCredential() {
    return sendSecurityRequest({type:"EXTUI_S0_LOCAL_CREDENTIAL"}).then(function(result){return result&&result.credentialPresent===true;});
  }

  function normalizeKey(raw) { return (raw || "").trim(); }
  function isValidKeyFormat(raw) {
    var key = normalizeKey(raw);
    return !!key && key.length >= 8 && !/\s/.test(key);
  }

  var OVERLAY_ID = "extapp-login-overlay-root";
  var OFFLINE_ID = "extapp-login-offline-root";
  var _offlineRetryTimer = 0;
  var _offlineRetryInFlight = null;
  var _offlineRetryStep = 0;

  function scheduleOfflineRetry(delayMs) {
    if (_offlineRetryTimer || !document.getElementById(OFFLINE_ID)) return;
    var delays = [5000, 10000, 20000, 30000];
    var delay = Number(delayMs) || delays[Math.min(_offlineRetryStep, delays.length - 1)];
    _offlineRetryTimer = setTimeout(function () {
      _offlineRetryTimer = 0;
      if (!document.getElementById(OFFLINE_ID)) return;
      if (document.visibilityState === "hidden") { scheduleOfflineRetry(15000); return; }
      _offlineRetryStep = Math.min(_offlineRetryStep + 1, delays.length - 1);
      tryOfflineRestore(false);
    }, delay);
  }

  function tryOfflineRestore(manual) {
    if (_offlineRetryInFlight) return _offlineRetryInFlight;
    var license = getLicenseService();
    if (!license) { scheduleOfflineRetry(5000); return Promise.resolve(false); }
    var btn = document.getElementById("extappOfflineRetryBtn");
    if (manual && btn) { btn.disabled = true; btn.textContent = "Validando..."; }
    _offlineRetryInFlight = Promise.resolve(license._o()).then(function (result) {
      if (result && result.active === true) { setAuthGateState("none"); return true; }
      scheduleOfflineRetry();
      return false;
    }).catch(function () { scheduleOfflineRetry(); return false; }).finally(function () {
      _offlineRetryInFlight = null;
      var current = document.getElementById("extappOfflineRetryBtn");
      if (current) { current.disabled = false; current.textContent = "Tentar novamente"; }
    });
    return _offlineRetryInFlight;
  }


  var _activeModalGuard=null;
  function focusableWithin(root){return Array.from(root.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')).filter(function(el){return !el.hidden&&el.getAttribute("aria-hidden")!=="true"&&!!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);});}
  function deactivateModalGuard(root){var guard=_activeModalGuard;if(!guard||root&&guard.root!==root)return;document.removeEventListener("keydown",guard.keydown,true);document.removeEventListener("focusin",guard.focusin,true);_activeModalGuard=null;if(guard.previous&&guard.previous.isConnected&&typeof guard.previous.focus==="function")try{guard.previous.focus({preventScroll:true});}catch(_){}}
  function activateModalGuard(root,labelledBy,initialSelector){
    if(!root)return;deactivateModalGuard();var previous=document.activeElement;root.setAttribute("role","dialog");root.setAttribute("aria-modal","true");if(labelledBy)root.setAttribute("aria-labelledby",labelledBy);root.tabIndex=-1;
    function focusFirst(){if(!root.isConnected)return;var preferred=initialSelector&&root.querySelector(initialSelector),list=focusableWithin(root),target=preferred&&!preferred.disabled&&!preferred.hidden?preferred:(list[0]||root);try{target.focus({preventScroll:true});}catch(_){try{target.focus();}catch(__){}}}
    function onKeydown(ev){if(!root.isConnected)return;if(ev.key!=="Tab")return;var list=focusableWithin(root);if(!list.length){ev.preventDefault();root.focus();return;}var first=list[0],last=list[list.length-1],active=document.activeElement;if(!root.contains(active)){ev.preventDefault();(ev.shiftKey?last:first).focus();return;}if(ev.shiftKey&&active===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&active===last){ev.preventDefault();first.focus();}}
    function onFocusin(ev){if(!root.isConnected)return;if(!root.contains(ev.target)){setTimeout(focusFirst,0);}}
    _activeModalGuard={root:root,previous:previous,keydown:onKeydown,focusin:onFocusin};document.addEventListener("keydown",onKeydown,true);document.addEventListener("focusin",onFocusin,true);setTimeout(focusFirst,0);
  }

  function buildOfflineOverlay() {
    var existing = document.getElementById(OFFLINE_ID);
    if (existing) { activateModalGuard(existing,"extappOfflineHeading","#extappOfflineRetryBtn"); scheduleOfflineRetry(); return existing; }
    var root = document.createElement("div");
    root.id = OFFLINE_ID;
    root.className = "extuiLoginOverlay";
    root.innerHTML = [
      '<div class="extuiLoginShell extuiLoginShell--offline">',
      '  <div class="extuiLoginBrandRow">',
      '    <img class="extuiLoginLogo" src="' + chrome.runtime.getURL("assets/brand/logo-icon-light.png") + '" alt="" aria-hidden="true">',
      '    <div class="extuiLoginBrandName">ZVM - Automações</div>',
      '  </div>',
      '  <div class="extuiLoginCard">',
      '    <div class="extuiLoginHero">',
      '      <span class="extuiLoginBadge extuiLoginBadge--warning"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2.5 20h19z"/><path d="M12 9v4M12 16h.01"/></svg>Conexão indisponível</span>',
      '      <h1 class="extuiLoginTitle" id="extappOfflineHeading">Não foi possível validar sua licença</h1>',
      '      <p class="extuiLoginDesc">Sua sessão continua salva. Assim que a conexão voltar, a extensão tenta restaurar o acesso automaticamente.</p>',
      '      <div class="extuiLoginHeroMeta"><span class="extuiLoginMetaPill">Tentativa automática</span><span class="extuiLoginMetaPill">Sessão preservada</span></div>',
      '    </div>',
      '    <div class="extuiLoginAssistBox"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg><span>Se preferir, você também pode tentar novamente manualmente agora.</span></div>',
      '    <div class="extuiLoginRecoveryActions">',
      '      <button type="button" class="extuiNavPrimaryBtn extuiLoginSubmitBtn" id="extappOfflineRetryBtn">Tentar novamente</button>',
      '      <button type="button" class="extuiLoginRecoveryBtn" id="extappOfflineResetBtn">Voltar ao acesso</button>',
      '    </div>',
      '    <p class="extuiLoginRecoveryHint">Voltar ao acesso encerra somente a sessão local desta instalação para permitir uma nova ativação.</p>',
      '  </div>',
      '</div>'
    ].join("\n");
    document.body.appendChild(root);
    activateModalGuard(root,"extappOfflineHeading","#extappOfflineRetryBtn");
    root.querySelector("#extappOfflineRetryBtn").addEventListener("click", function () { tryOfflineRestore(true); });
    var resetBtn=root.querySelector("#extappOfflineResetBtn");
    if(resetBtn)resetBtn.addEventListener("click",async function(){
      resetBtn.disabled=true;
      try{
        var service=getLicenseService();
        if(!service||typeof service._i!=="function")throw Object.assign(new Error("O serviço seguro de sessão não está disponível."),{code:"SESSION_SERVICE_UNAVAILABLE"});
        await service._i();
        setAuthGateState("login");
      }catch(err){
        if(window.__extReportRuntimeError)window.__extReportRuntimeError("SESSION_LOCAL_RESET_FAILED",err);
        var assist=root.querySelector(".extuiLoginAssistBox span");
        if(assist)assist.textContent="Não foi possível encerrar a sessão local com segurança. Tente novamente.";
        if(window.__extNotify)window.__extNotify("Não foi possível encerrar a sessão local com segurança. Tente novamente.",true);
        resetBtn.disabled=false;
      }
    });
    _offlineRetryStep = 0;
    scheduleOfflineRetry();
    return root;
  }
  function removeOfflineOverlay() {
    if (_offlineRetryTimer) { clearTimeout(_offlineRetryTimer); _offlineRetryTimer = 0; }
    _offlineRetryStep = 0;
    var root = document.getElementById(OFFLINE_ID);
    if (root) deactivateModalGuard(root);
    if (root && root.parentNode) root.parentNode.removeChild(root);
  }

  function buildOverlay() {
    var existing = document.getElementById(OVERLAY_ID);
    if (existing) { activateModalGuard(existing,"extappLoginHeading","#extappAccountEmail"); return existing; }
    var root = document.createElement("div");
    root.id = OVERLAY_ID;
    root.className = "extuiLoginOverlay";
    root.innerHTML = [
      '<div class="extuiLoginShell">',
      '  <aside class="extuiLoginIntro" aria-label="Acesso da extensão no WhatsApp Web">',
      '    <div class="extuiLoginIntroInner">',
      '      <span class="extuiLoginBadge">extensão - AUTOMAÇÕES NO WHATSAPP WEB</span>',
      '      <h1 class="extuiLoginIntroTitle">Sua extensão, <span>pronta para trabalhar.</span></h1>',
      '      <p class="extuiLoginIntroDesc">Use a mesma conta do Portal do Cliente para acessar sua licença e trabalhar com a extensão sem sair do WhatsApp Web.</p>',
      '      <div class="extuiLoginBenefits" aria-label="Benefícios do acesso">',
      '        <div class="extuiLoginBenefit"><span class="extuiLoginBenefitIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 14a5 5 0 1 1 3.8 4.85L8 21.5V19H5.5v-2.5H3l3.15-3.15A5 5 0 0 1 7 14Z"/><circle cx="12" cy="9" r="1"/></svg></span><span>Conta e licença no mesmo acesso</span></div>',
      '        <div class="extuiLoginBenefit"><span class="extuiLoginBenefitIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="M9 17h6"/></svg></span><span>Sessão vinculada a este dispositivo</span></div>',
      '        <div class="extuiLoginBenefit"><span class="extuiLoginBenefitIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h10"/></svg></span><span>Seus recursos e dados sempre sincronizados</span></div>',
      '        <div class="extuiLoginBenefit"><span class="extuiLoginBenefitIcon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 7 3v5c0 4.2-2.6 8-7 10-4.4-2-7-5.8-7-10V6l7-3Z"/><path d="m9 12 2 2 4-4"/></svg></span><span>Chave extensão disponível como alternativa segura</span></div>',
      '      </div>',
      '    </div>',
      '  </aside>',
      '  <main class="extuiLoginAuth" aria-labelledby="extappLoginHeading">',
      '    <div class="extuiLoginAuthInner">',
      '      <div class="extuiLoginBrandRow">',
      '        <img class="extuiLoginLogo" src="' + chrome.runtime.getURL("assets/brand/logo-icon-light.png") + '" alt="" aria-hidden="true">',
      '        <div class="extuiLoginBrandName">ZVM - Automações</div>',
      '      </div>',
      '      <div class="extuiLoginAuthHead">',
      '        <h2 class="extuiLoginTitle" id="extappLoginHeading">Entrar na sua conta</h2>',
      '        <p class="extuiLoginDesc" id="extappLoginSubtitle">Acesse sua conta para validar sua licença e continuar no WhatsApp Web.</p>',
      '      </div>',
      '      <div class="extuiLoginContextPill"><i class="extuiLoginStatusDot"></i><span>Acesso seguro dentro do WhatsApp Web</span></div>',
      '      <div class="extuiLoginMsgBox extError" id="extappOverlayErrorBox" hidden role="alert" aria-live="assertive"></div>',
      '      <section class="extuiLoginModePanel" id="extappAccountPanel">',
      '        <form id="extappAccountForm" novalidate>',
      '          <div class="extuiFieldGroup">',
      '            <label class="extuiFieldLabel" for="extappAccountEmail">E-mail</label>',
      '            <input class="extuiNavFormInput extuiLoginAccountInput" type="email" id="extappAccountEmail" autocomplete="email" inputmode="email" autocapitalize="off" spellcheck="false" placeholder="seu@email.com">',
      '          </div>',
      '          <div class="extuiFieldGroup">',
      '            <div class="extuiLoginFieldHead"><label class="extuiFieldLabel" for="extappAccountPassword">Senha</label><button type="button" class="extuiLoginInlineLink" id="extappForgotPassword">Esqueci minha senha</button></div>',
      '            <div class="extuiLoginKeyRow">',
      '              <input class="extuiNavFormInput extuiLoginAccountInput" type="password" id="extappAccountPassword" autocomplete="current-password" placeholder="Sua senha">',
      '              <button type="button" class="extuiLoginTogglePwBtn" id="extappAccountTogglePw" aria-label="Mostrar senha" aria-pressed="false"><svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg></button>',
      '            </div>',
      '          </div>',
      '          <div class="extuiFieldGroup extuiLoginMfaGroup" id="extappAccountTotpGroup" hidden>',
      '            <label class="extuiFieldLabel" for="extappAccountTotp">Código de verificação</label>',
      '            <input class="extuiNavFormInput extuiLoginAccountInput extuiLoginTotpInput" type="text" id="extappAccountTotp" autocomplete="one-time-code" inputmode="numeric" pattern="[0-9]{6}" aria-describedby="extappAccountTotpHint" placeholder="000000">',
      '            <div class="extuiLoginFmtHint" id="extappAccountTotpHint">Digite o código de 6 dígitos do seu aplicativo autenticador.</div>',
      '          </div>',
      '          <button type="submit" class="extuiLoginSubmitBtn" id="extappAccountSubmitBtn"><span id="extappAccountSubmitLabel">Entrar</span><span id="extappAccountSpinnerRow" class="extuiLoginSpinnerRow" hidden><span class="extuiLoginSpinner"></span><span id="extappAccountSpinnerText">Entrando...</span></span></button>',
      '        </form>',
      '        <div class="extuiLoginDivider"><span>ou</span></div>',
      '        <button type="button" class="extuiLoginAltBtn" id="extappUseKeyBtn"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 14a5 5 0 1 1 3.8 4.85L8 21.5V19H5.5v-2.5H3l3.15-3.15A5 5 0 0 1 7 14Z"/></svg><span>Entrar com chave extensão</span></button>',
      '      </section>',
      '      <section class="extuiLoginModePanel" id="extappKeyPanel" hidden>',
      '        <form id="extappOverlayForm" novalidate>',
      '          <div class="extuiFieldGroup">',
      '            <label class="extuiFieldLabel" for="extappOverlayKeyInput">Chave extensão</label>',
      '            <div class="extuiLoginKeyRow">',
      '              <input class="extuiNavFormInput" type="password" id="extappOverlayKeyInput" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Cole sua chave aqui">',
      '              <button type="button" class="extuiLoginTogglePwBtn" id="extappOverlayTogglePw" aria-label="Mostrar chave" aria-pressed="false"><svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg></button>',
      '            </div>',
      '            <div class="extuiLoginFmtHint" id="extappOverlayFmtHint" aria-live="polite"></div>',
      '          </div>',
      '          <button type="submit" class="extuiLoginSubmitBtn" id="extappOverlaySubmitBtn"><span id="extappOverlaySubmitLabel">Entrar com minha chave</span><span id="extappOverlaySpinnerRow" class="extuiLoginSpinnerRow" hidden><span class="extuiLoginSpinner"></span><span id="extappOverlaySpinnerText">Validando...</span></span></button>',
      '        </form>',
      '        <button type="button" class="extuiLoginAltBtn extuiLoginAltBtn--back" id="extappUseAccountBtn"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg><span>Usar e-mail e senha</span></button>',
      '      </section>',
      '      <p class="extuiLoginAccountFooter">Ainda não tem conta? <button type="button" id="extappOverlayRegisterBtn">Criar conta</button></p>',
      '      <p class="extuiLoginPrivacyNote">Sua senha não é armazenada pela extensão.</p>',
      '    </div>',
      '  </main>',
      '</div>'
    ].join("\n");
    document.body.appendChild(root);
    activateModalGuard(root,"extappLoginHeading","#extappAccountEmail");
    return root;
  }

  function removeOverlay() {
    var root = document.getElementById(OVERLAY_ID);
    if (root) deactivateModalGuard(root);
    if (root && root.parentNode) root.parentNode.removeChild(root);
  }

  var _authGate = null;
  function getAuthGate() {
    if (_authGate) return _authGate;
    var readiness = window[Symbol.for("extui.whatsapp-readiness")];
    if (!readiness || typeof readiness.createGate !== "function") {
      if (window.__extReportRuntimeError) window.__extReportRuntimeError("WHATSAPP_READINESS_UNAVAILABLE", new Error("WHATSAPP_READINESS_UNAVAILABLE"));
      _authGate = Object.freeze({
        setDesired: function(){ removeOverlay(); removeOfflineOverlay(); return { connected:false, desired:"none", visible:"none" }; },
        reconcile: function(){ removeOverlay(); removeOfflineOverlay(); return { connected:false, desired:"none", visible:"none" }; },
        stop: function(){ removeOverlay(); removeOfflineOverlay(); }
      });
      return _authGate;
    }
    _authGate = readiness.createGate({
      document: document,
      pollMs: 750,
      showLogin: function(){ var root = buildOverlay(); wireOverlay(root); },
      showOffline: function(){ buildOfflineOverlay(); },
      hideLogin: removeOverlay,
      hideOffline: removeOfflineOverlay
    });
    return _authGate;
  }

  function setAuthGateState(state) {
    return getAuthGate().setDesired(state);
  }

  function wireOverlay(root) {
    if (!root || root.dataset.extuiLoginWired === "1") return;
    root.dataset.extuiLoginWired = "1";
    var accountForm=root.querySelector("#extappAccountForm"),accountPanel=root.querySelector("#extappAccountPanel"),keyPanel=root.querySelector("#extappKeyPanel"),emailInput=root.querySelector("#extappAccountEmail"),passwordInput=root.querySelector("#extappAccountPassword"),totpGroup=root.querySelector("#extappAccountTotpGroup"),totpInput=root.querySelector("#extappAccountTotp"),accountToggle=root.querySelector("#extappAccountTogglePw"),forgotPassword=root.querySelector("#extappForgotPassword"),accountSubmit=root.querySelector("#extappAccountSubmitBtn"),accountLabel=root.querySelector("#extappAccountSubmitLabel"),accountSpinner=root.querySelector("#extappAccountSpinnerRow"),accountSpinnerText=root.querySelector("#extappAccountSpinnerText"),useKeyBtn=root.querySelector("#extappUseKeyBtn"),useAccountBtn=root.querySelector("#extappUseAccountBtn"),heading=root.querySelector("#extappLoginHeading"),subtitle=root.querySelector("#extappLoginSubtitle"),accountPendingMfa=false;
    var form=root.querySelector("#extappOverlayForm"),keyInput=root.querySelector("#extappOverlayKeyInput"),togglePwBtn=root.querySelector("#extappOverlayTogglePw"),fmtHint=root.querySelector("#extappOverlayFmtHint"),submitBtn=root.querySelector("#extappOverlaySubmitBtn"),submitLabel=root.querySelector("#extappOverlaySubmitLabel"),spinnerRow=root.querySelector("#extappOverlaySpinnerRow"),spinnerText=root.querySelector("#extappOverlaySpinnerText"),errorBox=root.querySelector("#extappOverlayErrorBox"),registerBtn=root.querySelector("#extappOverlayRegisterBtn");
    function friendlyError(value,code){
      var text=String(value||""); var c=String(code||"");
      if(/^EXTENSION_INTEGRITY_/.test(c)||/manifesto de integridade|fingerprint da build|assinatura de integridade/i.test(text))return "Não foi possível validar esta instalação da extensão. Recarregue a extensão e tente novamente; se persistir, reinstale a versão oficial.";
      if(c==="BUILD_NOT_ALLOWED")return "Esta versão da extensão precisa ser atualizada antes de continuar.";
      if(c==="ACCOUNT_MFA_REQUIRED"||c==="mfa_required")return "Digite o código de verificação para concluir o acesso.";
      if(c==="ACCOUNT_INVALID_TOTP"||c==="invalid_totp")return "Código de verificação inválido. Confira o aplicativo autenticador e tente novamente.";
      if(c==="ACCOUNT_INVALID_CREDENTIALS")return "E-mail ou senha inválidos.";
      if(c==="ACCOUNT_RATE_LIMITED")return "Muitas tentativas seguidas. Aguarde alguns minutos e tente novamente.";
      if(c==="ACCOUNT_LOGIN_TIMEOUT"||c==="ACCOUNT_LOGIN_UNAVAILABLE")return "Não foi possível acessar sua conta agora. Verifique sua conexão e tente novamente.";
      return text||"Não foi possível concluir o acesso agora.";
    }
    function setError(text,code){text=text?friendlyError(text,code):"";errorBox.hidden=!text;errorBox.style.display=text?"block":"none";errorBox.textContent=text;}
    function resetMfa(){accountPendingMfa=false;if(totpGroup)totpGroup.hidden=true;if(totpInput)totpInput.value="";if(accountLabel)accountLabel.textContent="Entrar";}function setMode(mode){var account=mode!=="key";if(!account){passwordInput.value="";resetMfa();}accountPanel.hidden=!account;keyPanel.hidden=account;heading.textContent=account?"Entrar na sua conta":"Entrar com sua chave";subtitle.textContent=account?"Acesse sua conta para validar sua licença e continuar no WhatsApp Web.":"Use a chave vinculada à sua licença.";setError("");root.dataset.extuiLoginMode=account?"account":"key";setTimeout(function(){var target=account?(accountPendingMfa&&totpInput?totpInput:emailInput):keyInput;if(target)target.focus();},0);}
    if(useKeyBtn)useKeyBtn.addEventListener("click",function(){setMode("key");});
    if(useAccountBtn)useAccountBtn.addEventListener("click",function(){setMode("account");});
    function eyeToggle(button,input,noun){if(!button||!input)return;button.addEventListener("click",function(){var showing=input.type==="text";input.type=showing?"password":"text";button.setAttribute("aria-pressed",String(!showing));button.setAttribute("aria-label",(showing?"Mostrar ":"Ocultar ")+noun);button.innerHTML=showing?'<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg>':'<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/></svg>';});}
    eyeToggle(accountToggle,passwordInput,"senha");eyeToggle(togglePwBtn,keyInput,"chave");
    function lockOtherControls(busy){if(useKeyBtn)useKeyBtn.disabled=busy;if(useAccountBtn)useAccountBtn.disabled=busy;if(registerBtn)registerBtn.disabled=busy;}
    function setAccountBusy(busy,label){accountSubmit.disabled=busy;accountLabel.hidden=busy;accountSpinner.hidden=!busy;if(label)accountSpinnerText.textContent=label;lockOtherControls(busy);}
    function setKeyBusy(busy,label){submitBtn.disabled=busy;submitLabel.hidden=busy;spinnerRow.hidden=!busy;if(label)spinnerText.textContent=label;lockOtherControls(busy);}
    if(forgotPassword)forgotPassword.addEventListener("click",function(){window.open(window.__extRuntimeConfig.backendUrl("/cliente/recuperar"),"_blank","noopener,noreferrer");});
    accountForm.addEventListener("submit",async function(e){e.preventDefault();var email=String(emailInput.value||"").trim().toLowerCase(),password=String(passwordInput.value||""),totpCode=String(totpInput&&totpInput.value||"").replace(/\D/g,"").slice(0,6);if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){setError("Informe um e-mail válido.");emailInput.focus();return;}if(!password){setError("Informe sua senha.");passwordInput.focus();return;}if(accountPendingMfa&&totpCode.length!==6){setError("Digite os 6 dígitos do seu código de verificação.");if(totpInput)totpInput.focus();return;}setError("");setAccountBusy(true,accountPendingMfa?"Verificando...":"Entrando...");try{var result=await sendSecurityRequest({type:"EXTUI_S0_F",email:email,password:password,totpCode:totpCode});if(result&&result.authorized===true){passwordInput.value="";resetMfa();window.location.reload();return;}throw Object.assign(new Error("Não foi possível concluir o login."),{code:"ACCOUNT_LOGIN_INCOMPLETE"});}catch(err){var code=String(err&&err.code||"");if(code==="ACCOUNT_MFA_REQUIRED"||code==="mfa_required"){accountPendingMfa=true;if(totpGroup)totpGroup.hidden=false;if(accountLabel)accountLabel.textContent="Confirmar e entrar";heading.textContent="Confirme seu acesso";subtitle.textContent="Sua conta usa verificação em duas etapas. Digite o código do aplicativo autenticador.";setError("");setTimeout(function(){if(totpInput)totpInput.focus();},0);}else{if(code==="ACCOUNT_INVALID_TOTP"||code==="invalid_totp"){accountPendingMfa=true;if(totpGroup)totpGroup.hidden=false;if(accountLabel)accountLabel.textContent="Confirmar e entrar";if(totpInput){totpInput.value="";setTimeout(function(){totpInput.focus();},0);}}else{passwordInput.value="";resetMfa();}setError(err&&err.message,code);}}finally{setAccountBusy(false);}});if(totpInput)totpInput.addEventListener("input",function(){var clean=String(totpInput.value||"").replace(/\D/g,"").slice(0,6);if(totpInput.value!==clean)totpInput.value=clean;});emailInput.addEventListener("input",function(){if(accountPendingMfa)resetMfa();});
    keyInput.addEventListener("input",function(){var raw=keyInput.value;if(!raw){fmtHint.textContent="";fmtHint.classList.remove("extError");return;}if(isValidKeyFormat(raw)){fmtHint.textContent="";fmtHint.classList.remove("extError");}else{fmtHint.textContent="A chave parece incompleta. Cole a chave inteira, sem espaços.";fmtHint.classList.add("extError");}});
    form.addEventListener("submit",async function(e){e.preventDefault();var key=normalizeKey(keyInput.value);if(!isValidKeyFormat(key)){setError("Confira se a chave foi copiada por completo, sem espaços.");keyInput.focus();return;}var license=getLicenseService();if(!license){setError("A extensão ainda está terminando de carregar. Recarregue a página e tente novamente.");return;}setError("");setKeyBusy(true,"Validando...");function waiting(ev){if(ev.detail&&ev.detail.state==="waitingForPhone")setKeyBusy(true,"Conectando ao WhatsApp...");}window.addEventListener("extui-s0-state",waiting);try{var result=await license._h(key);if(result&&result.ok){window.location.reload();return;}setError(result&&result.message||"Não foi possível validar esta chave.",result&&result.authError);}catch(err){setError(err&&err.message||"Erro de conexão. Verifique sua internet e tente novamente.",err&&err.code);}finally{window.removeEventListener("extui-s0-state",waiting);setKeyBusy(false);}});
    if(registerBtn)registerBtn.addEventListener("click",function(){window.open(window.__extRuntimeConfig.backendUrl("/cliente/registro"),"_blank","noopener,noreferrer");});
    setMode("account");
  }


  window.addEventListener("extui-s0-state", function (ev) {
    var detail = ev.detail || {};
    if (detail.state === "forceLogout") {
      setAuthGateState("login");
    } else if (detail.state === "validationUnavailable") {
      hasLocalCredential().then(function(hasCredential){
        setAuthGateState(hasCredential ? "offline" : "login");
      }).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("LOCAL_CREDENTIAL_QUERY_FAILED",err);setAuthGateState("offline");});
    } else if (detail.state === "restored" || detail.state === "offlineGrace") {
      setAuthGateState("none");
    }
  });

  (async function bootstrap() {
    try {
      var license = getLicenseService();
      if (!license) {
        setAuthGateState("login");
        return;
      }

      var access = await license._p();
      if (access && access.authorized === true) {
        setAuthGateState("none");
        return;
      }
      if (access && access.reason === "validationUnavailable") {
        try{
          setAuthGateState(await hasLocalCredential() ? "offline" : "login");
        }catch(localErr){if(window.__extReportRuntimeError)window.__extReportRuntimeError("LOCAL_CREDENTIAL_QUERY_FAILED",localErr);setAuthGateState("offline");}
        return;
      }
      setAuthGateState("login");
    } catch (err) {
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("AUTH_BOOTSTRAP_FAILED",err);
      setAuthGateState("offline");
    }
  })();
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;


;try{
(function(){
  "use strict";
  if(window.__extDashboardCommandBridgeBound)return;
  window.__extDashboardCommandBridgeBound=true;
  if(!globalThis.chrome||!chrome.runtime||!chrome.runtime.onMessage)return;
  chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){
    if(!msg||!sender||sender.id!==chrome.runtime.id)return;
    var work=null;
    if(msg.type==="EXTUI_FLUXOS_START_MANUAL"){
      if(typeof window.__extFluxosCommandDirect!=="function")work=Promise.reject(Object.assign(new Error("O motor de Fluxos ainda não está pronto."),{code:"FLOW_ENGINE_UNAVAILABLE"}));
      else work=window.__extFluxosCommandDirect({action:"startManual",flowId:msg.flowId,phoneNumber:msg.phoneNumber,isTest:msg.isTest===true});
    }else if(msg.type==="EXTUI_FUNNELS_START_MANUAL"){
      if(typeof window.__extFunnelsCommandDirect!=="function")work=Promise.reject(Object.assign(new Error("O motor de Funis ainda não está pronto."),{code:"FUNNEL_ENGINE_UNAVAILABLE"}));
      else work=window.__extFunnelsCommandDirect({action:"startManual",funnelId:msg.funnelId,phoneNumber:msg.phoneNumber,isTest:msg.isTest===true});
    }else if(msg.type==="EXTUI_FUNNELS_CANCEL"){
      if(typeof window.__extFunnelsCommandDirect!=="function")work=Promise.reject(Object.assign(new Error("O motor de Funis ainda não está pronto."),{code:"FUNNEL_ENGINE_UNAVAILABLE"}));
      else work=window.__extFunnelsCommandDirect({action:"cancel",chatId:msg.chatId,executionId:msg.executionId});
    }else if(msg.type==="EXTUI_CHAT_CAPABILITY_INVOKE"){
      if(typeof window.__extInvokeChatCapability!=="function")work=Promise.reject(Object.assign(new Error("A ação da conversa ainda não está pronta."),{code:"CHAT_CAPABILITY_UNAVAILABLE"}));
      else work=window.__extInvokeChatCapability(String(msg.capability||""),msg.context&&typeof msg.context==="object"?msg.context:{});
    }else return;
    Promise.resolve(work).then(function(data){
      sendResponse({requestId:msg.requestId||null,ok:true,data:data,error:null});
    }).catch(function(err){
      sendResponse({requestId:msg.requestId||null,ok:false,data:null,error:err&&err.message||String(err),code:err&&err.code||null});
    });
    return true;
  });
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
