try{
(function(){
  "use strict";

  var KEY = Symbol.for("extui.whatsapp-readiness");
  if (window[KEY]) return;

  var CONNECTED_SELECTORS = [
    "#pane-side",
    "#side",
    '[aria-label="Lista de conversas"]',
    '[aria-label="Chat list"]'
  ];

  function isConnected(doc) {
    var root = doc || document;
    if (!root || typeof root.querySelector !== "function") return false;
    for (var i = 0; i < CONNECTED_SELECTORS.length; i += 1) {
      try {
        if (root.querySelector(CONNECTED_SELECTORS[i])) return true;
      } catch (_) {}
    }
    return false;
  }

  var mainBridgeState = "idle";
  var mainBridgePromise = null;
  var mainBridgeTimer = 0;

  function ensureMainBridge(options) {
    var opts = options || {};
    var doc = opts.document || document;
    var setTimer = typeof opts.setInterval === "function" ? opts.setInterval : setInterval;
    var clearTimer = typeof opts.clearInterval === "function" ? opts.clearInterval : clearInterval;
    var pollMs = Math.max(250, Number(opts.pollMs) || 750);
    if (mainBridgeState === "ready") return Promise.resolve(true);
    if (mainBridgePromise) return mainBridgePromise;

    mainBridgePromise = new Promise(function(resolve){
      var requesting = false;

      function stopTimer() {
        if (!mainBridgeTimer) return;
        clearTimer(mainBridgeTimer);
        mainBridgeTimer = 0;
      }

      function finishReady() {
        if (mainBridgeState === "ready") return;
        mainBridgeState = "ready";
        requesting = false;
        stopTimer();
        try { window.dispatchEvent(new CustomEvent("extui:wpp-main-bridge-ready", { detail: { at: Date.now() } })); } catch (_) {}
        resolve(true);
      }

      function ensureTimer() {
        if (mainBridgeTimer || mainBridgeState === "ready") return;
        mainBridgeTimer = setTimer(probe, pollMs);
      }

      function probe() {
        if (mainBridgeState === "ready") { finishReady(); return; }
        if (!isConnected(doc)) { ensureTimer(); return; }
        if (requesting) return;
        if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") { ensureTimer(); return; }
        requesting = true;
        try {
          chrome.runtime.sendMessage({ type: "EXTUI_WPP_MAIN_BRIDGE_ENSURE" }, function(response){
            requesting = false;
            var lastError = chrome.runtime.lastError;
            if (!lastError && response && response.ok === true) { finishReady(); return; }
            mainBridgeState = "idle";
            ensureTimer();
          });
        } catch (_) {
          requesting = false;
          mainBridgeState = "idle";
          ensureTimer();
        }
      }

      probe();
      ensureTimer();
    });
    return mainBridgePromise;
  }

  function createGate(options) {
    var opts = options || {};
    var doc = opts.document || document;
    var showLogin = typeof opts.showLogin === "function" ? opts.showLogin : function(){};
    var showOffline = typeof opts.showOffline === "function" ? opts.showOffline : function(){};
    var hideLogin = typeof opts.hideLogin === "function" ? opts.hideLogin : function(){};
    var hideOffline = typeof opts.hideOffline === "function" ? opts.hideOffline : function(){};
    var setTimer = typeof opts.setInterval === "function" ? opts.setInterval : setInterval;
    var clearTimer = typeof opts.clearInterval === "function" ? opts.clearInterval : clearInterval;
    var pollMs = Math.max(250, Number(opts.pollMs) || 750);
    var desired = "none";
    var visible = "unknown";
    var timer = 0;

    function hideAll(force) {
      if (force || visible !== "none") {
        hideLogin();
        hideOffline();
      }
      visible = "none";
    }

    function reconcile() {
      var connected = isConnected(doc);
      if (!connected || desired === "none") {
        hideAll(visible === "unknown");
        return { connected: connected, desired: desired, visible: visible };
      }
      if (desired === "login") {
        if (visible !== "login") {
          hideOffline();
          showLogin();
          visible = "login";
        }
      } else if (desired === "offline") {
        if (visible !== "offline") {
          hideLogin();
          showOffline();
          visible = "offline";
        }
      }
      return { connected: connected, desired: desired, visible: visible };
    }

    function ensureTimer() {
      if (timer || desired === "none") return;
      timer = setTimer(function(){ reconcile(); }, pollMs);
    }

    function stopTimer() {
      if (!timer) return;
      clearTimer(timer);
      timer = 0;
    }

    function setDesired(next) {
      if (next !== "login" && next !== "offline" && next !== "none") throw new Error("WHATSAPP_GATE_STATE_INVALID");
      desired = next;
      var result = reconcile();
      if (desired === "none") stopTimer();
      else ensureTimer();
      return result;
    }

    function stop() {
      desired = "none";
      stopTimer();
      hideAll(true);
    }

    return Object.freeze({
      setDesired: setDesired,
      reconcile: reconcile,
      stop: stop,
      getDesired: function(){ return desired; }
    });
  }

  Object.defineProperty(window, KEY, {
    value: Object.freeze({ isConnected: isConnected, ensureMainBridge: ensureMainBridge, createGate: createGate }),
    enumerable: false,
    configurable: false,
    writable: false
  });
})();
}catch(_extuiBundleError){if(window.__extRecordBootError)window.__extRecordBootError(_extuiBundleError);}
