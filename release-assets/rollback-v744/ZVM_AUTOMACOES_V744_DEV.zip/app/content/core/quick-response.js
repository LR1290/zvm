;
try{


(function () {
  "use strict";

  if (window.__extQuickResponseServiceBooted) return;
  window.__extQuickResponseServiceBooted = true;

  var STORE_KEY = "EXTUI:extappQuickResponseStore";
  var CURRENT_VERSION = 2;
  var NATIVE = {
    message:  { key: "EXTUI:textMessageStore", listField: "textMessageList" },
    audio:    { key: "EXTUI:audioStore", listField: "audioList" },
    media:    { key: "EXTUI:mediaStore", listField: "mediaList" },
    image:    { key: "EXTUI:mediaStore", listField: "mediaList" },
    video:    { key: "EXTUI:mediaStore", listField: "mediaList" },
    sticker:  { key: "EXTUI:stickerStore", listField: "stickerList" },
    document: { key: "EXTUI:documentStore", listField: "documentList" },
    pix:      { key: "EXTUI:pixStore", listField: "pixList" },
    "interactive-list": { key: "EXTUI:interactiveListStore", listField: "interactiveListList" },
    contact:  { key: "EXTUI:contactCardStore", listField: "contactList" }
  };

  function repo() {
    if (!window.ExtensionStorage) { var e = new Error("Os dados da extensão não estão disponíveis no momento"); e.code="STORAGE_UNAVAILABLE"; throw e; }
    return window.ExtensionStorage;
  }
  function executor() {
    if (!window.__extActionExecutor) { var e = new Error("ActionExecutor indisponível"); e.code="ACTION_EXECUTOR_UNAVAILABLE"; throw e; }
    return window.__extActionExecutor;
  }
  async function paid(){if(!window.__extPlanGate)throw Object.assign(new Error("Sua sessão precisa ser validada novamente."),{code:"LICENSE_REQUIRED"});await window.__extPlanGate.requirePaid("Respostas Rápidas");return true;}
  function uid(prefix) { return (prefix || "qr") + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2,9); }
  function nowIso() { return new Date().toISOString(); }
  function parse(raw, fallback) {
    if (raw == null || raw === "") return fallback;
    if (typeof raw !== "string") return raw;
    try { return JSON.parse(raw); } catch (_) { return fallback; }
  }
  function parsePersisted(raw) {
    var p = parse(raw, null);
    return p && p.state && typeof p.state === "object" ? p.state : {};
  }
  var CANONICAL_ACTION_TYPES = new Set(["txt","respostaRapida","sticker","groupInvite","linkPreview","list","timer","composing","recording","addCRM","removeCRM","removeAllCRM","arquivar","desarquivar","fixarChat","desfixarChat","marcarLido","marcarNaoLido","bloquear","desbloquear"]);
  function canonicalActions(actions) { return Array.isArray(actions) ? actions.filter(function(action){ return action && CANONICAL_ACTION_TYPES.has(String(action.type||"")); }) : []; }
  function emptyState() { return { schemaVersion:CURRENT_VERSION, categories:[], items:[] }; }
  function normalizeState(value) {
    value = value && typeof value === "object" ? value : {};
    if (value.state && typeof value.state === "object" && !Array.isArray(value.state)) value = value.state;
    return {
      schemaVersion: CURRENT_VERSION,
      categories: Array.isArray(value.categories) ? value.categories.filter(Boolean) : [],
      items: Array.isArray(value.items) ? value.items.filter(Boolean).map(function(item){var next=Object.assign({},item);next.actions=canonicalActions(item.actions);return next;}) : []
    };
  }
  async function loadState() { await paid(); return normalizeState(parse(await repo().get(STORE_KEY), emptyState())); }
  async function saveState(state) { state=normalizeState(state); await repo().set(STORE_KEY, JSON.stringify(state)); return state; }

  function normalizeCategory(input, existing) {
    input=input||{}; existing=existing||{};
    return {
      id: String(input.id || existing.id || uid("qrcat")),
      name: String(input.name != null ? input.name : (existing.name || "Categoria")).trim() || "Categoria",
      position: Number.isFinite(Number(input.position)) ? Number(input.position) : (Number(existing.position)||0),
      hidden: input.hidden != null ? !!input.hidden : !!existing.hidden,
      createdAt: existing.createdAt || input.createdAt || nowIso(),
      updatedAt: nowIso()
    };
  }
  function normalizeItem(input, existing) {
    input=input||{}; existing=existing||{};
    var actions = input.actions != null ? input.actions : existing.actions;
    return {
      id: String(input.id || existing.id || uid("qr")),
      name: String(input.name != null ? input.name : (existing.name || "Resposta rápida")).trim() || "Resposta rápida",
      categoryId: input.categoryId != null ? String(input.categoryId || "") : String(existing.categoryId || ""),
      shortcut: input.shortcut != null ? String(input.shortcut || "") : String(existing.shortcut || ""),
      actions: canonicalActions(actions),
      favorite: input.favorite != null ? !!input.favorite : !!existing.favorite,
      createdAt: existing.createdAt || input.createdAt || nowIso(),
      updatedAt: nowIso()
    };
  }

  async function listCategories(options) { options=options||{}; var s=await loadState(); var rows=s.categories.slice().sort(function(a,b){return (a.position||0)-(b.position||0);}); return options.includeHidden?rows:rows.filter(function(c){return !c.hidden;}); }
  async function upsertCategory(input) {
    input=input||{}; var s=await loadState(); var i=s.categories.findIndex(function(x){return x.id===input.id;});
    var next=normalizeCategory(input, i>=0?s.categories[i]:null), nameKey=String(next.name||"").trim().toLocaleLowerCase("pt-BR");
    if(s.categories.some(function(c,idx){return idx!==i&&String(c&&c.name||"").trim().toLocaleLowerCase("pt-BR")===nameKey;})){var duplicate=new Error("Já existe uma categoria com esse nome.");duplicate.code="QUICK_REPLY_CATEGORY_DUPLICATE";throw duplicate;}
    if(i>=0)s.categories[i]=next; else s.categories.push(next); await saveState(s); emit("QuickReplyCategoryChanged",{category:next}); return next;
  }
  async function removeCategory(id, options) {
    options=options||{}; var s=await loadState();
    s.categories=s.categories.filter(function(x){return x.id!==id;});
    if(options.deleteItems===true)s.items=s.items.filter(function(x){return x.categoryId!==id;});
    else s.items=s.items.map(function(x){ if(x.categoryId!==id)return x; var y=Object.assign({},x); y.categoryId=options.moveToCategoryId||""; y.updatedAt=nowIso(); return y; });
    await saveState(s); emit("QuickReplyCategoryRemoved",{categoryId:id,deleteItems:options.deleteItems===true}); return true;
  }
  async function list(options) {
    options=options||{}; var s=await loadState(); var items=s.items.slice();
    if(options.categoryId!=null)items=items.filter(function(x){return x.categoryId===options.categoryId;});
    if(options.query){var q=String(options.query).toLowerCase();items=items.filter(function(x){return String(x.name).toLowerCase().indexOf(q)>=0||String(x.shortcut||"").toLowerCase().indexOf(q)>=0;});}
    return items;
  }
  async function get(id) { var s=await loadState(); return s.items.find(function(x){return x.id===id;})||null; }
  async function upsert(input) {
    var s=await loadState(); var i=s.items.findIndex(function(x){return x.id===input.id;});
    var next=normalizeItem(input,i>=0?s.items[i]:null);
    if(i>=0)s.items[i]=next; else s.items.push(next); await saveState(s); emit("QuickReplyChanged",{item:next}); return next;
  }
  async function remove(id) { var s=await loadState(); var n=s.items.length; s.items=s.items.filter(function(x){return x.id!==id;}); if(s.items.length!==n)await saveState(s); emit("QuickReplyRemoved",{itemId:id}); return s.items.length!==n; }

  async function findNativeMeta(type,id) {
    var cfg=NATIVE[type]; if(!cfg)return null;
    var state=parsePersisted(await repo().get(cfg.key)); var list=Array.isArray(state[cfg.listField])?state[cfg.listField]:[];
    return list.find(function(x){return x&&String(x.id)===String(id);})||null;
  }
  async function readNativeContent(id) { return parse(await repo().get(id), null); }
  async function portableMediaValue(value) {
    if(window.ExtensionMediaStore&&typeof window.ExtensionMediaStore.isRef==="function"&&window.ExtensionMediaStore.isRef(value))value=await window.ExtensionMediaStore.portable(value);
    if(typeof Blob!=="undefined"&&value instanceof Blob)value=await new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(String(r.result||""));};r.onerror=function(){reject(r.error||new Error("Falha ao preparar mídia."));};r.readAsDataURL(value);});
    if(typeof value==="string"&&value.indexOf("blob:")===0){var response=await fetch(value);if(!response.ok)throw new Error("Falha ao ler mídia temporária.");var blob=await response.blob();value=await new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(String(r.result||""));};r.onerror=function(){reject(r.error||new Error("Falha ao preparar mídia."));};r.readAsDataURL(blob);});}
    return value;
  }
  async function nativeToActions(type,id) {
    if(type==="signature"){
      var signatureStore=window.ExtensionSignatureStore;
      var signature=signatureStore&&typeof signatureStore.get==="function"?await signatureStore.get(id):null;
      if(!signature||!signature.text)return null;
      return [{type:"txt",properties:{mensagem:String(signature.text),aguarde:0,composing:0}}];
    }
    var meta=await findNativeMeta(type,id); if(!meta)return null;
    var c=await readNativeContent(id); if(!c)return null;
    if(type==="message") return [{type:"txt",properties:{mensagem:c.data||c.text||"",aguarde:0,composing:0}}];
    if(type==="audio") return [{type:"audio",properties:{base64:await portableMediaValue(c.data||c.base64||""),composing:0,isPtt:c.isPtt!==false,isViewOnce:!!(c.isViewOnce||c.asViewOnce),mimeType:c.mimeType||"",fileName:c.fileName||meta.name||"audio"}}];
    if(type==="document") return [{type:"doc",properties:{base64:await portableMediaValue(c.data||c.base64||""),base64Name:c.fileName||c.name||meta.name||"documento"}}];
    if(type==="media"||type==="image"||type==="video") {
      var detected=window.ExtensionChatBridge.mediaKind(c.data||c.base64||"",{type:"auto-detect",mimeType:c.mimeType||c.type||c.fileType,filename:c.fileName||c.name}),t=(type==="image"||type==="video")?type:detected;
      if(c.sendAsDocument||detected==="document") return [{type:"doc",properties:{base64:await portableMediaValue(c.data||c.base64||""),base64Name:c.fileName||c.name||meta.name||"arquivo"}}];
      return [{type:t,properties:{base64:await portableMediaValue(c.data||c.base64||""),mensagem:c.caption||"",isViewOnce:!!c.asViewOnce,microVideo:t==="video"&&!!c.isPtv,aguarde:0,composing:0}}];
    }
    if(type==="sticker") return [{type:"sticker",properties:{base64:await portableMediaValue(c.data||c.base64||""),mediaId:id}}];
    if(type==="pix") return [{type:"pix",properties:{keyType:c.keyType,name:c.merchantName||c.name||"PIX",key:c.key}}];
    if(type==="interactive-list") {
      var listApi=window.__extInteractiveList;
      if(!listApi){var unavailable=new Error("O recurso de listas interativas não está disponível.");unavailable.code="INTERACTIVE_LIST_UNAVAILABLE";throw unavailable;}
      var options=listApi.toSendOptions(c);
      return [{type:"list",properties:{title:options.title||"",description:options.description||"",footer:options.footer||"",buttonText:options.buttonText||"",sections:options.sections}}];
    }
    if(type==="contact") return [{type:"contact",properties:{phone:c.contactPhone,name:c.contactName||meta.name||""}}];
    return null;
  }


  function splitVirtualId(id) {
    var m=/^extapp-item:([^:]+):(.+)$/.exec(String(id||"")); return m?{type:m[1],id:m[2]}:null;
  }
  async function resolve(id) {
    var v=splitVirtualId(id); if(v)return await nativeToActions(v.type,v.id);
    var item=await get(id); if(item)return item.actions.slice();


    var found=null;
    for(var type of Object.keys(NATIVE)){ if(await findNativeMeta(type,id)){ if(found)return null; found=type; } }
    return found?await nativeToActions(found,id):null;
  }

  async function send(id, context) {
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Respostas Rápidas");
    var actions=await resolve(id); if(!actions){var e=new Error("Resposta rápida não encontrada: "+id);e.code="QUICK_REPLY_NOT_FOUND";throw e;}
    var ctx=Object.assign({source:"quick-reply"},context||{}),result=await executor().execute(actions,ctx);
    if(result&&result.status==="success")emit("QuickReplySent",{quickReplyId:id,chatId:ctx.contactId||ctx.chatId||ctx.remetente||"",executionId:result.executionId||null});
    return result;
  }
  function findAsset(value,id,depth){
    if(depth>5||value==null)return null;
    if(typeof value==="string"){try{value=JSON.parse(value);}catch(_){return null;}}
    if(Array.isArray(value)){for(var i=0;i<value.length;i++){var hit=findAsset(value[i],id,depth+1);if(hit)return hit;}return null;}
    if(typeof value!=="object")return null;
    if(String(value.id||value.itemId||value.mediaId||"")===String(id))return value;
    var keys=["media","medias","messages","files","items","assets","state"];for(var k=0;k<keys.length;k++){if(value[keys[k]]!=null){var nested=findAsset(value[keys[k]],id,depth+1);if(nested)return nested;}}return null;
  }
  async function resolveBase64(mediaRef) {
    await paid();
    var content=await readNativeContent(mediaRef);
    if(content){var direct=content.base64||content.data||content.content;if(direct)return portableMediaValue(direct);}
    var imported=await repo().getMany(["EXTUI:quickAssetsStore","EXTUI:flowFilesStore"]);
    var hit=findAsset(imported&&imported["EXTUI:quickAssetsStore"],mediaRef,0)||findAsset(imported&&imported["EXTUI:flowFilesStore"],mediaRef,0);
    var value=hit&&(hit.base64||hit.data||hit.content)||null;
    return value?portableMediaValue(value):null;
  }
  async function insert(id, context) {
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Respostas Rápidas");
    var actions=await resolve(id); context=context||{};
    if(!actions || actions.length!==1 || String(actions[0].type)!=="txt") { var e=new Error("Resposta rápida não pode ser inserida como texto");e.code="QUICK_REPLY_NOT_INSERTABLE";throw e; }
    var p=actions[0].properties||actions[0]; var text=p.mensagem!=null?p.mensagem:(p.text||"");
    var chatId=context.contactId||context.chatId||context.remetente;
    if(!chatId && window.__extWppBridge)chatId=await window.__extWppBridge.invoke("Chat","getActiveChat","@");
    if(chatId && chatId._serialized)chatId=chatId._serialized;
    if(!chatId){var no=new Error("Nenhum chat ativo para inserir a resposta");no.code="NO_ACTIVE_CHAT";throw no;}
    var exec=executor();
    if(exec&&typeof exec.buildVariables==="function"&&typeof exec.resolvePlaceholders==="function"){
      var varContext=Object.assign({},context,{contactId:chatId,chatId:chatId});
      var vars=await exec.buildVariables(varContext,true);
      text=exec.resolvePlaceholders(text,vars);
    } else if(window.__extVariableResolver&&typeof window.__extVariableResolver.resolveForChat==="function") text=await window.__extVariableResolver.resolveForChat(text,chatId,context);
    return window.__extWppBridge.invoke("Chat","setInputText",{id:chatId,txt:text});
  }

  function emit(name,payload){try{if(window.__extEventBus)window.__extEventBus.emit(name,payload,{source:"quick-response"});}catch(_){}}

  var api=Object.freeze({
    version:"1.0.0", storeKey:STORE_KEY,
    listCategories:listCategories, upsertCategory:upsertCategory, removeCategory:removeCategory,
    list:list, get:get, upsert:upsert, remove:remove, resolve:resolve, send:send, insert:insert, resolveBase64:resolveBase64,
    nativeVirtualId:function(type,id){return "extapp-item:"+type+":"+id;}, nativeToActions:nativeToActions
  });
  window.__extQuickResponseService=api;
  window.ExtensionCore=window.ExtensionCore||{}; 

  function register(){
    if(!window.__extActionExecutor || typeof window.__extActionExecutor.registerAdapter!=="function")return false;
    window.__extActionExecutor.registerAdapter("QuickReplyResolver",{resolve:resolve});
    window.__extActionExecutor.registerAdapter("MediaResolver",{resolveBase64:resolveBase64});
    return true;
  }
  if(!register())window.addEventListener("ext:action-executor-ready",function(){register();},{once:true});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
