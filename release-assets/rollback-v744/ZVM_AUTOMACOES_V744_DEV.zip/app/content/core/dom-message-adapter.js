;
try{
(function(){
  "use strict";
  if(window.__extDomMessageAdapter)return;
  function bridge(){if(!window.__extWppBridge)throw Object.assign(new Error("O WhatsApp ainda não está pronto"),{code:"WPP_UNAVAILABLE"});return window.__extWppBridge;}
  var api=Object.freeze({
    version:"1.0.0",
    sendTextChat:async function(p){
      p=p||{};
      var id=p.chatID||p.id,method=(p.quotedMsg||p.replayID)?"sendTextReplay":"sendTxt",payload={id:id,msg:p.formattedMessage||p.msg||""};
      if(method==="sendTextReplay")payload.replayID=p.replayID||p.quotedMsg;
      var safety=window.__extSendSafetyManager;
      if(!safety||typeof safety.sendChat!=="function")throw Object.assign(new Error("Proteção de Envio indisponível; envio bloqueado."),{code:"SEND_SAFETY_UNAVAILABLE"});
      return safety.sendChat(method,payload,{source:"manual-composer",contactId:id,interactive:true},{source:"manual-composer",interactive:true});
    },
    downloadMediaByActiveChat:function(id){return bridge().invoke("Chat","downloadMedia",id);},
    getMessageByDomId:function(id){return bridge().invoke("Chat","getMessageById",id);}
  });
  window.__extDomMessageAdapter=api;
  if(window.__extWppBridge)window.__extWppBridge.registerAdapter("DomMessageAdapter",api);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
