;
try{


(function(){
  "use strict";
  if(window.__extDomAdapterBooted)return;
  window.__extDomAdapterBooted=true;

  var defaults={
    app:{model:"querySelector",selector:["#app"]},
    afiliadoMain:{model:"querySelector",selector:["body > div"]},
    paneSide:{model:"Element",selector:"#pane-side"},
    waPage:{model:"querySelector",selector:["div.two"]},
    two:{model:"Element",selector:"two"},
    menuLateral:{model:"querySelector",selector:["div.two > div:nth-child(5)"]},
    closeChat:{model:"Element",selector:"x10l6tqk"},
    chatListInput:{model:"querySelector",selector:[".lexical-rich-text-input > div"]},
    searchInput:{model:"querySelector",selector:["[data-icon='search']"]},
    downAba:{model:"querySelector",selector:["header > div > div > div > div > span > div > div:nth-child(1)","header > div._ak0w"]},
    chatListHeader:{model:"querySelector",selector:["header > header > div > span > div"]},
    searchCamp:{model:"querySelector",selector:["#side div[data-testid='chat-list-search-container']"]},
    chatName:{model:"querySelector",selector:["#main > header > div.x78zum5 > div > div > div > div"]},
    menuVertical:{model:"querySelector",selector:["#main ._amm9","#main .x1n2onr6.x1vjfegm.x1cqoux5.x14yy4lh"]},
    menuHorizontal:{model:"querySelector",selector:["#main > header > div.x1c4vz4f > div"]},
    menuFooter:{model:"querySelector",selector:["footer ._ak1m"]},
    respostaRapida:{model:"querySelector",selector:["footer > div"]},
    footerTextArea:{model:"querySelector",selector:["footer div[contenteditable=true]"]},
    mainAudio:{model:"querySelector",selector:["footer > div.copyable-area > div"]},
    assChat:{model:"querySelector",selector:["#main > div.x1n2onr6.x1vjfegm.x1cqoux5.x14yy4lh"]},
    assInput:{model:"querySelector",selector:["#main > footer > div.copyable-area > div > span > div > div > div"]},
    assBtn:{model:"querySelector",selector:["#main > footer > div.copyable-area > div > span > div > div > div > div:nth-child(6)"]},
    assEmoji:{model:"querySelector",selector:["#main > footer > div.copyable-area > div > span > div > div._ak1m > div > button[tabindex='-1']"]},
    assCitacao:{model:"querySelector",selector:["footer div.x9f619.x1okw0bk > button > div > div > div:nth-child(1)"]},
    listMensages:{model:"querySelector",selector:["div[data-scrolltracepolicy='wa.web.conversation.messages']"]},
    allMensages:{model:"querySelectorAll",selector:["#main div > div[data-id]"]},
    assistenteChat:{model:"querySelector",selector:["#main > footer"]},
    trasferidos:{model:"querySelector",selector:["#side div[tabindex='-1']"]},
    notification:{model:"querySelector",selector:["#side > div:nth-child(2)"]},
    quotedMsg:{model:"querySelector",selector:["#main > footer > div.x10l6tqk.x13vifvy.x1o0tod.xh8yej3 > div > div > div > span > div"]},
    listChats:{model:"querySelector",selector:["#pane-side > div > div > div"]},
    listChatsUsers:{model:"querySelectorAll",selector:["#pane-side > div > div > div > div  div[aria-selected]","#pane-side > div > div > div div[role='button'] > div"]},
    listChatAtendimento:{model:"Element",selector:"div div[data-testid='cell-frame-secondary'] div[role='gridcell']"},
    insertAtendente:{model:"Element",selector:"x10l6tqk xh8yej3 x1g42fcv"},
    updateChatList:{model:"querySelector",selector:["#side div._ai04 > button"]},
    chatList:{model:"querySelector",selector:["div.two > div._aigw"]},
    observerFooter:{model:"querySelector",selector:["#main > span:nth-child(8)","#main > :last-child"]},
    observerFooterNewModel:{model:"querySelector",selector:["#main > span:nth-child(7)","#main > span:nth-child(8)","#main > span:nth-child(9)"]},
    whatsModal:{model:"querySelector",selector:["#app > div > div > span:nth-child(3)"]},
    whats:{model:"querySelector",selector:["#app > div > div.x78zum5.xdt5ytf.x5yr21d > div > header > div > div:nth-child(2) > div","header > div > div:nth-child(2) > div"]},
    actionMonitor:{model:"querySelector",selector:["#main header"]},
    footerIconsLeft:{model:"querySelector",selector:["#main > footer > div.copyable-area > div > span > div > div > div"]},
    side:{model:"querySelector",selector:["#side"]},
    chatFilters:{model:"querySelectorAll",selector:["#side > div[aria-label='chat-list-filters'] button"]},
    theme:{model:"querySelector",selector:[".os-win"]}
  };
  var current=JSON.parse(JSON.stringify(defaults));
  var revision=0;
  var allowedModels=new Set(["querySelector","querySelectorAll","Element"]);

  function selectorsOf(def){var s=def&&def.selector;return Array.isArray(s)?s.slice():typeof s==="string"?[s]:[];}
  function validDefinition(def){if(!def||typeof def!=="object"||!allowedModels.has(def.model))return false;var s=selectorsOf(def);return s.length>0&&s.length<=12&&s.every(function(v){return typeof v==="string"&&v.length>0&&v.length<=1000;});}
  function elementQuery(selector,all){
    try{
      if(selector[0]==="#"||selector[0]==="."||/[>\[\]:]/.test(selector))return all?Array.from(document.querySelectorAll(selector)):document.querySelector(selector);
      var classes=selector.trim().split(/\s+/).filter(Boolean);
      if(classes.length){var css="."+classes.join(".");var byCss=all?Array.from(document.querySelectorAll(css)):document.querySelector(css);if(all?byCss.length:byCss)return byCss;}
      var byClass=document.getElementsByClassName(selector);return all?Array.from(byClass):(byClass[0]||null);
    }catch(e){return all?[]:null;}
  }
  function queryByDef(def,all){
    if(!def)return all?[]:null;
    var sels=selectorsOf(def);
    for(var i=0;i<sels.length;i++){
      try{
        var result;
        if(def.model==="Element")result=elementQuery(sels[i],all);
        else if(all||def.model==="querySelectorAll")result=Array.from(document.querySelectorAll(sels[i]));
        else result=document.querySelector(sels[i]);
        if(all){if(result&&result.length)return result;}else if(result)return result;
      }catch(e){}
    }
    return all?[]:null;
  }
  function query(name){return queryByDef(current[name],false);}
  function queryAll(name){return queryByDef(current[name],true);}
  function describe(name){var d=current[name];return d?JSON.parse(JSON.stringify(d)):null;}
  function snapshot(){return JSON.parse(JSON.stringify(current));}
  function set(next,options){
    options=options||{};
    if(!next||typeof next!=="object")throw new TypeError("DomAdapter.set exige objeto de seletores");
    var candidate=options.replace?{}:JSON.parse(JSON.stringify(current));
    Object.keys(next).forEach(function(name){if(validDefinition(next[name]))candidate[name]=JSON.parse(JSON.stringify(next[name]));});


    Object.keys(defaults).forEach(function(name){if(!candidate[name])candidate[name]=JSON.parse(JSON.stringify(defaults[name]));});
    current=candidate; revision++;
    if(window.ExtensionCore&&window.ExtensionCore.EventBus)window.ExtensionCore.EventBus.emit("DomSelectorsChanged",{revision:revision,source:options.source||"runtime",names:Object.keys(next)},{source:"dom-adapter"});
    return {revision:revision,count:Object.keys(current).length};
  }
  function reset(){current=JSON.parse(JSON.stringify(defaults));revision++;return {revision:revision,count:Object.keys(current).length};}

  var api=Object.freeze({version:"1.0.0",query:query,queryAll:queryAll,describe:describe,snapshot:snapshot,set:set,reset:reset,defaults:function(){return JSON.parse(JSON.stringify(defaults));},get revision(){return revision;}});
  window.__extDomAdapter=api;window.ExtensionCore=window.ExtensionCore||{};


  if(window.__extWppBridge&&typeof window.__extWppBridge.registerAdapter==="function"){
    window.__extWppBridge.registerAdapter("DomSelector",{version:api.version,set:function(payload){return api.set(payload||{},{source:"wpp-rpc"});}});
  }
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{


(function(){
  "use strict";
  if(window.__extRemoteConfigBooted)return;
  window.__extRemoteConfigBooted=true;
  var STORE_KEY="EXTUI:remoteConfigStore";
  var provider=null,state={status:"fallback",lastRefreshAt:null,lastSuccessAt:null,lastError:null,source:"defaults"};

  function normalizeConfig(raw){
    if(!raw||typeof raw!=="object")return null;
    var selectors=raw.dom_selector||raw.domSelector||raw.selectors||null;
    return {schemaVersion:1,dom_selector:selectors&&typeof selectors==="object"?selectors:null,pt:raw.pt===true||raw.data&&raw.data.pt===true,update_path_active:raw.update_path_active||null,update_path_new:raw.update_path_new||null,fetchedAt:raw.fetchedAt||Date.now(),source:raw.source||"remote"};
  }
  async function persist(config){if(window.ExtensionStorage)await window.ExtensionStorage.set(STORE_KEY,JSON.stringify(config));}
  function apply(config,source){
    if(!config)return false;
    if(config.dom_selector&&window.__extDomAdapter)window.__extDomAdapter.set(config.dom_selector,{source:source||config.source||"remote"});
    if(window.__extEntitlementSecurity)window.__extEntitlementSecurity.evaluate({pt:config.pt,update_path_active:config.update_path_active,update_path_new:config.update_path_new}).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("REMOTE_CONFIG_ENTITLEMENT_EVALUATION_FAILED",err);});
    return true;
  }
  async function loadCached(){
    if(!window.ExtensionStorage)return null;
    var raw=await window.ExtensionStorage.get(STORE_KEY).catch(function(){return null;});
    if(!raw)return null;
    var parsed;try{parsed=typeof raw==="string"?JSON.parse(raw):raw;}catch(e){return null;}
    var cfg=normalizeConfig(parsed);if(cfg){apply(cfg,"cache");state.status="cached";state.source="cache";state.lastSuccessAt=cfg.fetchedAt||null;}return cfg;
  }
  async function refresh(reason){
    state.lastRefreshAt=Date.now();state.lastError=null;
    if(!provider){state.status="BLOQUEADO_CONTRATO_EXTERNO";state.source="defaults/cache";var blocked={status:state.status,reason:reason||"manual",dependency:"RemoteConfigProvider atual da extensão"};if(window.ExtensionCore&&window.ExtensionCore.EventBus)window.ExtensionCore.EventBus.emit("RemoteConfigBlocked",blocked,{source:"remote-config"});return blocked;}
    try{
      var raw=await provider.fetchConfig({reason:reason||"manual",current:status()});var cfg=normalizeConfig(raw);if(!cfg)throw new Error("Config remota inválida");
      cfg.source=provider.name||cfg.source||"provider";cfg.fetchedAt=Date.now();apply(cfg,cfg.source);await persist(cfg);state.status="ready";state.source=cfg.source;state.lastSuccessAt=cfg.fetchedAt;
      if(window.ExtensionCore&&window.ExtensionCore.EventBus)window.ExtensionCore.EventBus.emit("RemoteConfigUpdated",{source:cfg.source,fetchedAt:cfg.fetchedAt},{source:"remote-config"});return {status:"ready",config:cfg};
    }catch(err){state.status="error";state.lastError=err&&err.message?err.message:String(err);if(window.ExtensionCore&&window.ExtensionCore.EventBus)window.ExtensionCore.EventBus.emit("RemoteConfigFailed",{error:state.lastError},{source:"remote-config"});return {status:"error",error:state.lastError};}
  }
  function status(){return Object.assign({hasProvider:!!provider},state);}


  loadCached().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("REMOTE_CONFIG_CACHE_LOAD_FAILED",err);});
  if(window.ExtensionCore.EventBus&&typeof window.ExtensionCore.EventBus.on==="function")window.ExtensionCore.EventBus.on("ConfigRefresh",function(){refresh("scheduled-10m");});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
