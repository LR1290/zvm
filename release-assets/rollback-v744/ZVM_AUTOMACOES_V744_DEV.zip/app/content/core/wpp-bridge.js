;
try{


(function () {
  "use strict";

  if (window.__extWppIsolatedClientBooted) return;
  window.__extWppIsolatedClientBooted = true;

  var RPC_CHANNEL = "WPP";


  var RPC_REQUEST_MODEL = "WPP";
  var RPC_RESPONSE_MODEL = "WPP-RESPONSE";
  var RPC_CHUNK_SIZE = 524288;
  var RPC_MAX_CHUNKS = 256;
  var RPC_TIMEOUT_MS = 30000;
  var RPC_ID_MAX = 160;
  var RPC_TYPE_MAX = 32;
  var RPC_ACTION_MAX = 64;
  var SECURE_RPC_VERIFY_QUEUE_MAX = 1024;
  var EVENT_MARKER = "__extSecureWppEvent";
  var MAX_EVENT_BYTES = 1024 * 1024;
  var SECURE_EVENT_VERIFY_QUEUE_MAX = 128;
  var SECURE_EVENT_NAMES = Object.freeze({"chat.new_message":true,"chat.active_chat":true,"webpack.full_ready":true,"chat.presence_change":true,"chat.update_label":true,"conn.stream_info_changed":true});

  var seq = 0;
  var subscribers = Object.create(null);
  var localAdapters = Object.create(null);
  var readyState = { ready: false, fullReady: false, updatedAt: 0 };
  var eventSecurity = { channelId: null, key: null, active: false, lastError: null };
  var eventSeen = new Set();
  var eventSeenQueue = [];
  var eventVerifyQueue = Promise.resolve();
  var rpcVerifyQueue = Promise.resolve();
  var secureEventVerifyQueued = 0;
  var secureRpcSeq = 0;
  var secureRpcPending = new Map();
  var secureRpcVerifyQueued = 0;
  var secureEventInitPromise = null;
  var SECURE_RPC_MARKER = "__extSecureWppRpc";

  function makeId() {
    seq += 1;
    return "extapp-iso-rpc:" + Date.now().toString(36) + ":" + seq.toString(36) + ":" + Math.random().toString(36).slice(2, 10);
  }

  function chunksOf(text) {
    if (!text.length) return [""];
    var chunks = [];
    for (var i = 0; i < text.length; i += RPC_CHUNK_SIZE) chunks.push(text.slice(i, i + RPC_CHUNK_SIZE));
    return chunks;
  }

  function rpcError(message, code) {
    var err = new Error(message || "Falha na comunicação com o WhatsApp");
    if (code) err.code = code;
    return err;
  }

  function validSignature(value) { return typeof value === "string" && value.length === 44 && /^[A-Za-z0-9+/]{43}=$/.test(value); }
  function validRpcToken(value, max) { return typeof value === "string" && value.length > 0 && value.length <= max && /^[A-Za-z0-9:_-]+$/.test(value); }
  function validChannelId(value) { return typeof value === "string" && /^extapp-wpp-event:[a-f0-9]{32}$/.test(value); }
  function validKeyB64(value) { return validSignature(value); }

  function bytesToB64(buffer) {
    var bytes = new Uint8Array(buffer), raw = "";
    for (var i = 0; i < bytes.length; i++) raw += String.fromCharCode(bytes[i]);
    return btoa(raw);
  }

  function secureRpcRequestCanonical(channelId, seqValue, id, type, action, index, total, chunk) {
    return ["EXTAPP-WPP-RPC-REQ-CHUNK-V1", channelId, String(seqValue), id, type, action, String(index), String(total), chunk].join("\n");
  }
  function secureRpcResponseCanonical(channelId, seqValue, id, index, total, chunk) {
    return ["EXTAPP-WPP-RPC-RESP-CHUNK-V1", channelId, String(seqValue), id, String(index), String(total), chunk].join("\n");
  }
  async function signSecureText(text) {
    var sig = await crypto.subtle.sign("HMAC", eventSecurity.key, new TextEncoder().encode(text));
    return bytesToB64(sig);
  }
  async function verifySecureText(text, signature) {
    var sig; try { sig = b64ToBytes(signature); } catch (_) { return false; }
    return crypto.subtle.verify("HMAC", eventSecurity.key, sig, new TextEncoder().encode(text));
  }
  async function secureRequestMain(type, action, payload, meta) {
    if (!eventSecurity.active || !eventSecurity.key || !eventSecurity.channelId) throw rpcError("A conexão segura com o WhatsApp ainda não ficou pronta", "WPP_SECURE_CHANNEL_NOT_READY");
    type = String(type == null ? "" : type); action = String(action == null ? "" : action);
    if (!validRpcToken(type, RPC_TYPE_MAX) || !validRpcToken(action, RPC_ACTION_MAX)) throw rpcError("A operação solicitada ao WhatsApp possui um formato inválido", "WPP_RPC_SCHEMA_INVALID");
    var id = meta && meta.id || makeId(), payloadText;
    if (!validRpcToken(id, RPC_ID_MAX)) throw rpcError("A identificação da operação é inválida", "WPP_RPC_SCHEMA_INVALID");
    if (secureRpcPending.size >= 32) throw rpcError("Há operações demais aguardando resposta do WhatsApp", "WPP_RPC_BUSY");
    try { payloadText = JSON.stringify(payload === undefined ? null : payload); }
    catch (_) { throw rpcError("Os dados enviados ao WhatsApp estão em um formato inválido", "WPP_RPC_PAYLOAD_NOT_SERIALIZABLE"); }
    if (payloadText === undefined) payloadText = "null";
    var chunks = chunksOf(payloadText);
    if (chunks.length > RPC_MAX_CHUNKS) throw rpcError("Os dados enviados ao WhatsApp são grandes demais", "WPP_RPC_TOO_LARGE");
    var seqValue = ++secureRpcSeq;
    return new Promise(function(resolve, reject){
      var timeoutId = setTimeout(function(){ var rec=secureRpcPending.get(id); if(!rec)return; secureRpcPending.delete(id); reject(rpcError("O WhatsApp demorou demais para responder", "WPP_RPC_TIMEOUT")); }, RPC_TIMEOUT_MS);
      secureRpcPending.set(id,{resolve:resolve,reject:reject,timeoutId:timeoutId,seq:seqValue,total:null,chunks:null,received:0,verified:new Set()});
      (async function(){
        for(var i=0;i<chunks.length;i++){
          var canonical=secureRpcRequestCanonical(eventSecurity.channelId,seqValue,id,String(type||""),String(action||""),i,chunks.length,chunks[i]);
          var signature=await signSecureText(canonical);
          window.postMessage({__extSecureWppRpc:true,direction:"ISOLATED_TO_MAIN",channelId:eventSecurity.channelId,seq:seqValue,id:id,type:String(type||""),action:String(action||""),index:i,total:chunks.length,chunk:chunks[i],signature:signature},"*");
        }
      })().catch(function(err){var rec=secureRpcPending.get(id);if(!rec)return;secureRpcPending.delete(id);clearTimeout(rec.timeoutId);reject(rpcError(err&&err.message||String(err),"WPP_RPC_SIGN_FAILED"));});
    });
  }
  function requestMain(type, action, payload, meta) {


    if (!(window.chrome && chrome.runtime)) return Promise.reject(rpcError("A extensão não conseguiu iniciar este recurso", "WPP_SECURE_CHANNEL_UNAVAILABLE"));
    var readiness = window[Symbol.for("extui.whatsapp-readiness")];
    if (!readiness || typeof readiness.isConnected !== "function" || readiness.isConnected(document) !== true) return Promise.reject(rpcError("O WhatsApp Web ainda não está conectado", "WPP_WHATSAPP_NOT_CONNECTED"));
    var ready = eventSecurity.active ? Promise.resolve(true) : ensureSecureEventChannel();
    return Promise.resolve(ready).then(function(ok){
      if(!ok) throw rpcError("Não foi possível estabelecer uma conexão segura com o WhatsApp", "WPP_SECURE_CHANNEL_FAILED");
      return secureRequestMain(type,action,payload,meta);
    });
  }

  window.addEventListener("message", function(ev){
    if(ev.source!==window)return;
    var d=ev.data;
    if(!d||d[SECURE_RPC_MARKER]!==true||d.direction!=="MAIN_TO_ISOLATED"||d.channelId!==eventSecurity.channelId)return;
    if(!validRpcToken(d.id,RPC_ID_MAX)||typeof d.chunk!=="string"||d.chunk.length>RPC_CHUNK_SIZE+16||!validSignature(d.signature)||!Number.isSafeInteger(d.seq))return;
    var rec=secureRpcPending.get(d.id);if(!rec||rec.seq!==d.seq)return;
    var total=d.total,index=d.index;
    if(!Number.isInteger(total)||total<1||total>RPC_MAX_CHUNKS||!Number.isInteger(index)||index<0||index>=total)return;
    if(rec.total===null){rec.total=total;rec.chunks=new Array(total);}if(rec.total!==total||rec.verified.has(index))return;
    if(secureRpcVerifyQueued>=SECURE_RPC_VERIFY_QUEUE_MAX)return;
    var chunk=d.chunk;secureRpcVerifyQueued++;
    rpcVerifyQueue=rpcVerifyQueue.then(async function(){
      var canonical=secureRpcResponseCanonical(d.channelId,d.seq,d.id,index,total,chunk);
      var ok=await verifySecureText(canonical,d.signature);if(!ok)return;
      var current=secureRpcPending.get(d.id);if(!current||current!==rec||current.verified.has(index))return;
      current.verified.add(index);current.chunks[index]=chunk;current.received++;
      if(current.received!==current.total)return;
      secureRpcPending.delete(d.id);clearTimeout(current.timeoutId);
      var response;try{response=JSON.parse(current.chunks.join(""));}catch(_){current.reject(rpcError("O WhatsApp retornou uma resposta inválida","WPP_RPC_INVALID_RESPONSE"));return;}
      if(!response||response.ok!==true){current.reject(rpcError(response&&response.error||"A operação no WhatsApp falhou",response&&response.code||"WPP_RPC_ERROR"));return;}
      current.resolve(response.result);
    }).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("WPP_RPC_VERIFY_FAILED",err);}).finally(function(){secureRpcVerifyQueued=Math.max(0,secureRpcVerifyQueued-1);});
  });

  function localAdapterFor(type, action) {
    var direct = localAdapters[type];
    if (direct && typeof direct[action] === "function") return { adapter: direct, method: action };
    if (type === "Msg") {
    }
    if (type === "Functions") {
      if ((action === "downloadMediaByActiveChat" || action === "getMessageByDomId" || action === "sendTextChat") && localAdapters.DomMessageAdapter) return { adapter: localAdapters.DomMessageAdapter, method: action };
    }
    return null;
  }

  async function invoke(type, action, payload) {
    var local = localAdapterFor(String(type || ""), String(action || ""));
    if (local && local.adapter && typeof local.adapter[local.method] === "function") return local.adapter[local.method](payload);
    return requestMain(type, action, payload);
  }

  function request(req) {
    req = req || {};
    return invoke(req.type, req.action, req.payload).then(function (result) {
      return { channel: RPC_CHANNEL, model: RPC_RESPONSE_MODEL, id: req.id || null, sender: req.sender || "extapp-isolated", ok: true, result: result, error: null };
    }).catch(function (err) {
      return { channel: RPC_CHANNEL, model: RPC_RESPONSE_MODEL, id: req.id || null, sender: req.sender || "extapp-isolated", ok: false, result: null, error: err && err.message || String(err), code: err && err.code || null };
    });
  }

  function registerAdapter(name, adapter) {
    if (!name || !adapter) throw new TypeError("registerAdapter(name, adapter)");
    localAdapters[name] = adapter;
    return function () { if (localAdapters[name] === adapter) delete localAdapters[name]; };
  }

  function on(name, fn) {
    if (typeof fn !== "function") throw new TypeError("A conexão com o WhatsApp recebeu uma configuração inválida");
    if (!subscribers[name]) subscribers[name] = new Set();
    subscribers[name].add(fn);
    return function () { var set = subscribers[name]; if (set) set.delete(fn); };
  }

  function emitSecureEvent(name, payload) {
    var set = subscribers[name];
    if (!set) return;
    set.forEach(function (fn) { try { fn(payload); } catch (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("WPP_EVENT_LISTENER_FAILED",err); } });
  }

  function b64ToBytes(text) {
    var raw = atob(String(text || "")), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }


  async function importHmacKey(keyB64) {
    return crypto.subtle.importKey("raw", b64ToBytes(keyB64), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
  }

  function eventCanonical(channelId, seqValue, ts, name, payloadText) {
    return ["EXTAPP-WPP-EVENT-V1", channelId, String(seqValue), String(ts), String(name), String(payloadText)].join("\n");
  }

  async function verifyEventEnvelope(d) {
    if (!eventSecurity.active || !eventSecurity.key || d.channelId !== eventSecurity.channelId) return false;
    if (!Number.isSafeInteger(d.seq) || d.seq < 1 || !Number.isSafeInteger(d.ts) || !SECURE_EVENT_NAMES[d.name] || typeof d.payloadText !== "string" || !validSignature(d.signature)) return false;
    if (Math.abs(Date.now() - d.ts) > 5 * 60 * 1000) return false;
    var seenKey = d.channelId + ":" + d.seq;
    if (eventSeen.has(seenKey)) return false;
    var payloadText = d.payloadText;
    if (new TextEncoder().encode(payloadText).byteLength > MAX_EVENT_BYTES) return false;
    var signature;
    try { signature = b64ToBytes(d.signature); } catch (_) { return false; }
    var bytes = new TextEncoder().encode(eventCanonical(d.channelId, d.seq, d.ts, d.name, payloadText));
    var ok = await crypto.subtle.verify("HMAC", eventSecurity.key, signature, bytes);
    if (!ok) return false;
    eventSeen.add(seenKey); eventSeenQueue.push(seenKey);
    while (eventSeenQueue.length > 500) eventSeen.delete(eventSeenQueue.shift());
    var payload;
    try { payload = JSON.parse(payloadText); } catch (_) { return false; }
    var eventName = String(d.name || "");
    emitSecureEvent(eventName, payload);
    if (eventName === "webpack.full_ready" || eventName === "conn.stream_info_changed") refreshReadyState().catch(function () {});
    return true;
  }

  window.addEventListener("message", function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (!d || d[EVENT_MARKER] !== true || d.direction !== "MAIN_TO_ISOLATED" || d.channelId !== eventSecurity.channelId) return;
    if (!Number.isSafeInteger(d.seq) || d.seq < 1 || !Number.isSafeInteger(d.ts) || !SECURE_EVENT_NAMES[d.name] || typeof d.payloadText !== "string" || d.payloadText.length > MAX_EVENT_BYTES || !validSignature(d.signature)) return;
    if (secureEventVerifyQueued >= SECURE_EVENT_VERIFY_QUEUE_MAX) return;
    secureEventVerifyQueued++;
    eventVerifyQueue = eventVerifyQueue.then(function () { return verifyEventEnvelope(d); }).catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("WPP_EVENT_VERIFY_FAILED",err); return false; }).finally(function () { secureEventVerifyQueued = Math.max(0, secureEventVerifyQueued - 1); });
  });

  function extResetSecureEventChannel(reason) {
    eventSecurity.channelId = null;
    eventSecurity.key = null;
    eventSecurity.active = false;
    if (reason) eventSecurity.lastError = String(reason);
  }

  function initSecureEventChannel() {
    if (eventSecurity.active && eventSecurity.channelId && eventSecurity.key) return Promise.resolve(true);
    try{if(window.__extBootPhases&&window.__extBootPhases.mark)window.__extBootPhases.mark("wpp:secure-channel-request");}catch(_){}
    if (secureEventInitPromise) return secureEventInitPromise;
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) return Promise.resolve(false);
    secureEventInitPromise = new Promise(function (resolve) {
      var finished = false;
      var timer = setTimeout(function () {
        if (finished) return;
        finished = true;
        extResetSecureEventChannel("event_channel_init_timeout");
        secureEventInitPromise = null;
        resolve(false);
      }, 5000);
      function finish(ok, reason) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        if (!ok) {
          extResetSecureEventChannel(reason || "event_channel_init_failed");
          secureEventInitPromise = null;
        }
        resolve(!!ok);
      }
      try {
        chrome.runtime.sendMessage({ type: "EXTUI_WPP_EVENT_CHANNEL_INIT" }, function (res) {
          if (finished) return;
          var lastError = chrome.runtime.lastError;
          if (lastError || !res || res.ok !== true || !validChannelId(res.channelId) || !validKeyB64(res.keyB64)) {
            finish(false, lastError && lastError.message || res && res.error || "event_channel_init_failed");
            return;
          }
          importHmacKey(res.keyB64).then(function (key) {
            if (finished) return;
            eventSecurity.channelId = res.channelId;
            eventSecurity.key = key;
            eventSecurity.active = true;
            eventSecurity.lastError = null;
            try{if(window.__extBootPhases&&window.__extBootPhases.mark)window.__extBootPhases.mark("wpp:secure-channel-ready");}catch(_){}
            finish(true);
          }).catch(function (err) { finish(false, err && err.message || String(err)); });
        });
      } catch (err) { finish(false, err && err.message || String(err)); }
    });
    return secureEventInitPromise;
  }

  function ensureSecureEventChannel() {
    if (eventSecurity.active && eventSecurity.channelId && eventSecurity.key) return Promise.resolve(true);
    var delays = [0, 250, 800];
    function attempt(index) {
      if (index >= delays.length) return Promise.resolve(false);
      return new Promise(function (resolve) { setTimeout(resolve, delays[index]); }).then(function () {
        return initSecureEventChannel();
      }).then(function (ok) {
        if (ok) return true;
        secureEventInitPromise = null;
        return attempt(index + 1);
      });
    }
    return attempt(0);
  }

  var readyRefreshPromise = null;
  function extPublishWppReadiness(previousReady, previousFullReady) {
    var changed = previousReady !== readyState.ready || previousFullReady !== readyState.fullReady;
    document.documentElement.setAttribute("data-extui-wpp-ready", readyState.ready ? "true" : "false");
    document.documentElement.setAttribute("data-extui-wpp-full-ready", readyState.fullReady ? "true" : "false");
    if (!changed) return;
    try { window.dispatchEvent(new CustomEvent("ext:wpp-readiness", { detail: { ready: readyState.ready, fullReady: readyState.fullReady, at: readyState.updatedAt } })); } catch (_) {}
  }
  function refreshReadyState() {
    if (readyRefreshPromise) return readyRefreshPromise;
    readyRefreshPromise = (async function () {
    var previousReady = readyState.ready, previousFullReady = readyState.fullReady;
    try {
      var pair = await Promise.all([
        requestMain("Webpack", "isReady", null),
        requestMain("Webpack", "isFullReady", null)
      ]);
      readyState.ready = pair[0] === true;
      readyState.fullReady = pair[1] === true;
      readyState.updatedAt = Date.now();
      extPublishWppReadiness(previousReady, previousFullReady);
      return readyState;
    } catch (_) {
      readyState.ready = false; readyState.fullReady = false; readyState.updatedAt = Date.now();
      extPublishWppReadiness(previousReady, previousFullReady);
      return readyState;
    }
    })();
    return readyRefreshPromise.finally(function () { readyRefreshPromise = null; });
  }

  function waitState(field, timeoutMs) {
    timeoutMs = Math.max(500, Number(timeoutMs) || 45000);
    var started = Date.now();
    return new Promise(function (resolve, reject) {
      var settled=false,probeTimer=0,deadlineTimer=0;
      function cleanup(){if(probeTimer)clearTimeout(probeTimer);if(deadlineTimer)clearTimeout(deadlineTimer);window.removeEventListener("ext:wpp-readiness",onReadiness);}
      function finish(ok){if(settled)return;settled=true;cleanup();if(ok)resolve(true);else reject(rpcError("Tempo esgotado ao aguardar o WhatsApp " + field, "WPP_READY_TIMEOUT"));}
      function onReadiness(ev){var d=ev&&ev.detail||{};if(field==="fullReady"?d.fullReady===true:d.ready===true)finish(true);}
      function probe(){if(settled)return;if(readyState[field]){finish(true);return;}refreshReadyState().then(function(){if(settled)return;if(readyState[field]){finish(true);return;}var age=Date.now()-started;if(age>=timeoutMs){finish(false);return;}probeTimer=setTimeout(probe,Math.min(1200,Math.max(500,timeoutMs-age)));}).catch(function(){if(!settled)probeTimer=setTimeout(probe,900);});}
      window.addEventListener("ext:wpp-readiness",onReadiness);
      deadlineTimer=setTimeout(function(){finish(false);},timeoutMs+40);
      probe();
    });
  }

  var bridge = {
    version: "2.0.0-isolated",
    isReady: function () { return readyState.ready; },
    isFullReady: function () { return readyState.fullReady; },
    waitUntilReady: function (timeoutMs) { return waitState("ready", timeoutMs); },
    waitUntilFullReady: function (timeoutMs) { return waitState("fullReady", timeoutMs); },
    invoke: invoke,
    request: request,
    registerAdapter: registerAdapter,
    on: on,
    emit: emitSecureEvent,
    capabilities: function () { return { isolated: true, secureEvents: eventSecurity.active, ready: readyState.ready, fullReady: readyState.fullReady }; },
    normalize: {
      phone: function (value) { return String(value == null ? "" : value).replace(/\D/g, ""); },
      jid: function (value) { var v = String(value == null ? "" : value); return /@(?:c|g)\.us$|@lid$/.test(v) ? v : v.replace(/\D/g, "") + "@c.us"; }
    },
    constants: { channel: RPC_CHANNEL, requestModel: RPC_REQUEST_MODEL, responseModel: RPC_RESPONSE_MODEL, chunkSize: RPC_CHUNK_SIZE }
  };


  function extDataUrlToBlob(value) {
    if (typeof value !== "string" || value.indexOf("data:") !== 0) return value;
    var comma = value.indexOf(",");
    if (comma < 0) return value;
    var head = value.slice(5, comma), mime = (head.split(";")[0] || "application/octet-stream"), body = value.slice(comma + 1);
    var bytes;
    try {
      if (/;base64/i.test(head)) {
        var raw = atob(body), out = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
        bytes = out;
      } else {
        bytes = new TextEncoder().encode(decodeURIComponent(body));
      }
      return new Blob([bytes], { type: mime });
    } catch (_) { return value; }
  }
  function extBlobToDataUrl(blob) {
    return new Promise(function(resolve,reject){
      try {
        var reader=new FileReader();
        reader.onload=function(){resolve(String(reader.result||""));};
        reader.onerror=function(){reject(reader.error||new Error("Não foi possível preparar a mídia para envio."));};
        reader.readAsDataURL(blob);
      } catch (err) { reject(err); }
    });
  }
  async function extPortableMediaContent(value) {
    if (window.ExtensionMediaStore && typeof window.ExtensionMediaStore.isRef === "function" && window.ExtensionMediaStore.isRef(value)) value=await window.ExtensionMediaStore.portable(value);
    if (typeof Blob !== "undefined" && value instanceof Blob) value=await extBlobToDataUrl(value);
    if (typeof value === "string" && value.indexOf("blob:") === 0) {
      var response=await fetch(value);
      if(!response.ok)throw new Error("Não foi possível ler a mídia temporária para envio.");
      value=await extBlobToDataUrl(await response.blob());
    }
    return value;
  }
  function extMediaKind(content, options) {
    options = options || {};
    var type = String(options.type || "auto-detect").toLowerCase();
    if (type !== "auto-detect") return type;
    var hints = [options.mimetype, options.mimeType, options.filename, options.fileName].filter(Boolean).join(" ");
    if (typeof content === "string" && content.indexOf("data:") === 0) hints += " " + content.slice(5, content.indexOf(",") >= 0 ? content.indexOf(",") : 128);
    var hint = String(hints || "").toLowerCase();
    if (hint.indexOf("video/") >= 0 || /\.(mp4|webm|mov|m4v|mkv|avi|3gp|flv)(?:$|[?#\s])/i.test(hint)) return "video";
    if (hint.indexOf("audio/") >= 0 || /\.(ogg|opus|mp3|m4a|wav|aac|amr|flac|weba)(?:$|[?#\s])/i.test(hint)) return "audio";
    if (hint.indexOf("image/") >= 0 || /\.(png|jpe?g|gif|webp|bmp)(?:$|[?#\s])/i.test(hint)) return "image";
    return "document";
  }
  var compat = { chat: {}, contact: {}, group: {}, labels: {}, conn: {} };
  compat.mediaKind = extMediaKind;
  Object.defineProperty(compat, "isReady", { enumerable: true, get: function () { return readyState.ready; } });
  compat.chat.getActiveChat = function () { return invoke("Chat", "getActiveChat", null); };
  compat.chat.list = function (options) { return invoke("Chat", "List", options || {}); };
  compat.chat.sendTextMessage = function (id, text, options) {
    options = options || {};
    if (options.quotedMsg) return invoke("Chat", "sendTextReplay", { id: id, msg: text, replayID: options.quotedMsg });
    return invoke("Chat", "sendTxt", { id: id, msg: text, mentionedList: options.mentionedList || undefined });
  };
  compat.chat.sendFileMessage = async function (id, content, options) {
    options = options || {};
    content=await extPortableMediaContent(content);
    var kind = extMediaKind(content, options);
    if (kind === "image") return invoke("Chat", "sendImage", { id: id, base64: content, msg: options.caption || "", mentionedList: options.mentionedList || undefined, isViewOnce: !!options.isViewOnce, mimeType: options.mimetype || options.mimeType, name: options.filename });
    if (kind === "video") return invoke("Chat", "sendVideo", { id: id, base64: content, msg: options.caption || "", mentionedList: options.mentionedList || undefined, microVideo: !!options.isPtv, isViewOnce: !!options.isViewOnce, mimeType: options.mimetype || options.mimeType, name: options.filename });
    if (kind === "audio") return invoke("Chat", "sendAudio", { id: id, base64: content, isPtt: options.isPtt !== false, isViewOnce: !!options.isViewOnce, mimeType: options.mimetype || options.mimeType, name: options.filename });
    if (kind === "sticker") return invoke("Chat", "sticker", { id: id, base64: content });
    return invoke("Chat", "sendDoc", { id: id, base64: content, name: options.filename || "documento", mimeType: options.mimetype || options.mimeType });
  };
  compat.chat.sendListMessage = function (id, options) { return invoke("Chat", "sendListMessage", { id: id, options: options || {} }); };
  compat.chat.sendPixKeyMessage = function (id, payload) { payload = payload || {}; return invoke("Chat", "sendPixKeyMessage", { id: id, keyType: payload.keyType, name: payload.name, key: payload.key }); };
  compat.chat.sendVCardContactMessage = function (id, contact) {
    var phone = contact && typeof contact === "object" ? (contact.id || contact.phone || contact.contactId || "") : contact;
    var name = contact && typeof contact === "object" ? (contact.name || contact.formattedName || "") : "";
    return invoke("Chat", "sendContact", { id: id, phone: phone, name: name });
  };
  compat.chat.downloadMedia = function (id) { return invoke("Chat", "downloadMedia", id).then(extDataUrlToBlob); };
  compat.chat.downloadMediaResolved = function (payload) { return invoke("Chat", "downloadMediaResolved", payload || {}).then(extDataUrlToBlob); };
  compat.chat.getMessages = function (id, options) { options = options || {}; return invoke("Chat", "getMessages", { id: id, quant: options.count == null ? 50 : options.count, disabledAwaitHydrate: !!options.disabledAwaitHydrate }); };
  compat.chat.getMessageById = function (id) { return invoke("Chat", "getMessageById", id); };
  compat.chat.setInputText = function (id, text) { return invoke("Chat", "setInputText", { id: id, txt: text }); };
  compat.chat.markIsComposing = function (id, timer) { return invoke("Chat", "markIsComposing", { id: id, timer: timer }); };
  compat.chat.markIsRecording = function (id, timer) { return invoke("Chat", "markIsRecording", { id: id, timer: timer }); };
  compat.chat.markIsPaused = function (id) { return invoke("Chat", "markIsPaused", { id: id }); };
  compat.chat.markIsRead = function (id) { return invoke("Chat", "markIsRead", { id: id }); };
  compat.chat.markIsUnread = function (id) { return invoke("Chat", "markIsUnread", { id: id }); };
  compat.chat.openChatFromUnread = function () { return invoke("Chat", "openChatFromUnread", null); };
  compat.chat.getAllChatsByLabels = function (labelIds) { return invoke("Chat", "List", { withLabels: Array.isArray(labelIds) ? labelIds : [] }); };
  compat.chat.getHasUnread = function (id) { return invoke("Chat", "get", id).then(function (chat) { return !!(chat && Number(chat.unreadCount) > 0); }); };
  compat.contact.list = function (options) { return invoke("Contact", "List", options || {}); };
  compat.contact.get = function (id) { return invoke("Contact", "get", id); };
  compat.contact.getPnLidEntry = function (id) { return invoke("Contact", "getPnLidEntry", id); };
  compat.contact.getProfilePictureUrl = function (id) { return invoke("Contact", "getProfilePictureUrl", id); };
  compat.contact.queryExists = function (id) { return invoke("Contact", "queryExists", id); };
  compat.group.getParticipants = function (id) { return invoke("Group", "getParticipants", id); };
  compat.group.getAllGroups = function () { return invoke("Group", "getAllGroups", null); };
  compat.group.ensureGroup = function (id) { return invoke("Group", "getParticipants", id).then(function () { return true; }); };
  compat.conn.getMyUserId = function () { return invoke("Conn", "getMyUserId", null); };
  compat.conn.getMyUserLid = function () { return invoke("Conn", "getMyUserLid", null); };
  compat.labels.getAllLabels = function () { return invoke("Labels", "getAllLabels", null); };
  compat.labels.editLabel = function (id, options) { return invoke("Labels", "editLabel", { id: id, options: options || {} }); };
  compat.labels.deleteLabel = function (id) { return invoke("Labels", "deleteLabel", id); };
  compat.labels.addOrRemoveLabels = function (id, labels) { return invoke("Labels", "addOrRemoveLabels", { id: id, labels: labels }); };

  window.__extWppBridge = bridge;
  window.ExtensionChatBridge = compat;
  window.ExtensionCore = window.ExtensionCore || {};
  window.ExtensionCore.WppBridge = bridge;

  function extStartWppBridgeHealth(){
    try{if(window.__extBootPhases&&window.__extBootPhases.mark)window.__extBootPhases.mark("wpp:health-start");}catch(_){}
    var readiness=window[Symbol.for("extui.whatsapp-readiness")];
    if(readiness&&typeof readiness.ensureMainBridge==="function")readiness.ensureMainBridge({document:document}).then(function(ok){if(ok!==true)return false;return initSecureEventChannel();}).then(function(ok){if(ok===true)return refreshReadyState();return false;}).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("WPP_SECURE_CHANNEL_INIT_FAILED",err);});
    setInterval(function () { if (!document.hidden) refreshReadyState(); }, 90000);
  }
  if(window.__extBootPhases&&typeof window.__extBootPhases.when==="function")window.__extBootPhases.when(2,extStartWppBridgeHealth);else extStartWppBridgeHealth();
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
