;
try{
(function(){
  "use strict";
  if(window.__extAiAgentChatService)return;
  async function paid(){if(!window.__extPlanGate)throw Object.assign(new Error("Sua sessão precisa ser validada novamente."),{code:"LICENSE_REQUIRED"});await window.__extPlanGate.requirePaid("Assistentes IA");return true;}
  function runner(){var value=window.__extAiAgentChatRunner;if(!value||typeof value.run!=="function")throw Object.assign(new Error("Os Agentes IA ainda não estão prontos. Recarregue o WhatsApp Web."),{code:"AI_AGENT_RUNTIME_FAILED"});return value;}
  async function list(){await paid();var value=window.__extAiAgentChatRunner;if(!value||typeof value.list!=="function")return [];return value.list();}
  async function text(request){await paid();request=request||{};return runner().run({chatId:request.chatId||request.contactId||"",agentId:request.agentId||"",agent:request.agent||"random",text:request.text||request.prompt||request.task||""});}
  var api=Object.freeze({version:"3.0.0",list:list,text:text});
  window.__extAiAgentChatService=api;window.ExtensionCore=window.ExtensionCore||{};
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
