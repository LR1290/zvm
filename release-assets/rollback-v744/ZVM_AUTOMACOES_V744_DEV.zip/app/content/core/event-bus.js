;
try{


(function () {
  "use strict";

  if (window.__extDomainEventBusBooted) return;
  window.__extDomainEventBusBooted = true;

  var PROTOCOL = "EXTAPP_DOMAIN_EVENT";
  var VERSION = 1;
  var listeners = new Map();
  var history = [];
  var seenEnvelopes = new Map();
  var seenMessages = [];
  var seenMessageSet = new Set();
  var seq = 0;
  var synchronized = null;
  var wppBound = false;
  var wppBridge = null;
  var wppUnsubs = [];
  var messageAutomationQueue = Promise.resolve();
  var MAX_HISTORY = 200;
  var MAX_MESSAGE_DEDUPE = 100;
  var MAX_MESSAGE_AGE_MS = 5 * 60 * 1000;

  var acceptedMessageTypes = new Set(["chat","image","document","video","ptt","vcard","sticker","poll_creation","location","list_response","call_log"]);
  var relayAllowlist = new Set(["LicenseRefresh","ConfigRefresh","RemoteNotificationTick","FollowUpTimingTick","AgendaTick","StatusTick","BackupTick","MeetLiveTick","NotificationTick"]);

  function uid() { return "extui-evt-" + Date.now().toString(36) + "-" + (++seq).toString(36); }
  function cloneSafe(value) { try { return JSON.parse(JSON.stringify(value)); } catch (e) { return null; } }

  function makeEnvelope(name, payload, meta) {
    meta = meta || {};
    return {
      protocol: PROTOCOL,
      version: VERSION,
      id: meta.id || uid(),
      name: name,
      source: meta.source || "main",
      timestamp: meta.timestamp || Date.now(),
      correlationId: meta.correlationId || null,
      payload: payload === undefined ? null : payload
    };
  }

  function rememberEnvelope(id) {
    if (!id) return true;
    if (seenEnvelopes.has(id)) return false;
    seenEnvelopes.set(id, Date.now());
    if (seenEnvelopes.size > 500) {
      var cutoff = Date.now() - 10 * 60 * 1000;
      seenEnvelopes.forEach(function (ts, key) { if (ts < cutoff || seenEnvelopes.size > 400) seenEnvelopes.delete(key); });
    }
    return true;
  }

  function dispatchEnvelope(envelope) {
    if (!envelope || envelope.protocol !== PROTOCOL || envelope.version !== VERSION || !envelope.name) return false;
    if (!rememberEnvelope(envelope.id)) return false;
    history.push(cloneSafe(envelope) || { id: envelope.id, name: envelope.name, timestamp: envelope.timestamp });
    if (history.length > MAX_HISTORY) history.splice(0, history.length - MAX_HISTORY);
    [listeners.get(envelope.name), listeners.get("*")].forEach(function (set) {
      if (!set) return;
      set.forEach(function (fn) {
        try { fn(envelope.payload, envelope); } catch (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("EVENT_BUS_LISTENER_FAILED",err); }
      });
    });
    return true;
  }

  function emit(name, payload, meta) { var env = makeEnvelope(name, payload, meta); dispatchEnvelope(env); return env; }
  function on(name, fn) { if(typeof fn!=="function") throw new TypeError("EventBus.on exige função"); var set=listeners.get(name); if(!set){set=new Set();listeners.set(name,set);} set.add(fn); return function(){set.delete(fn);if(!set.size)listeners.delete(name);}; }
  function once(name, fn) { var off=on(name,function(payload,env){off();fn(payload,env);}); return off; }
  function clear(name) { if(name) listeners.delete(name); else listeners.clear(); }

  function messageTimestampMs(msg) {
    var value = msg && (msg.timestamp != null ? msg.timestamp : (msg.t != null ? msg.t : msg.messageTimestamp));
    var n = Number(value);
    if (!isFinite(n) || n <= 0) return Date.now();
    return n < 100000000000 ? n * 1000 : n;
  }
  function messageId(payload) {
    var data=payload&&payload.data||payload||{};
    var id=payload&&payload.msgID || data.id || data.msgID || data.key && data.key.id;
    if (id && typeof id === "object") return id._serialized || id.id || id.user || JSON.stringify(id);
    return id == null ? "" : String(id);
  }
  function rememberMessage(id) {
    if (!id) return true;
    if (seenMessageSet.has(id)) return false;
    seenMessageSet.add(id); seenMessages.push(id);
    while(seenMessages.length>MAX_MESSAGE_DEDUPE){seenMessageSet.delete(seenMessages.shift());}
    return true;
  }
  function normalizeAuthor(payload) {
    var data=payload&&payload.data||payload||{};
    return payload&&payload.author || data.author && (data.author._serialized||data.author) || data.from && (data.from._serialized||data.from) || null;
  }

  function handleNewMessage(payload) {
    emit("WppMessageReceived", payload, { source:"wpp" });
    var data = payload && payload.data || payload || {};
    var type = String(data.type || data.typeName || data.msgType || "chat");
    var id = messageId(payload);
    var ts = messageTimestampMs(data);
    var fromMe = !!(data.fromMe || data.id && data.id.fromMe || data.key && data.key.fromMe);
    var reason = null;
    if (synchronized === false) reason = "not_synchronized";
    else if (!acceptedMessageTypes.has(type)) reason = "unsupported_type";
    else if (fromMe) reason = "from_me";
    else if (Date.now() - ts > MAX_MESSAGE_AGE_MS) reason = "too_old";
    else if (!id) reason = "missing_id";
    else if (!rememberMessage(id)) reason = "duplicate";
    if (reason) { emit("MessageIgnored", { reason:reason, msgID:id, type:type, timestamp:ts }, { source:"event-gateway", correlationId:id||null }); return; }
    if(typeof window.__extClaimAutomationEvent!=="function"){var coordErr=new Error("Coordenador seguro entre abas indisponível.");coordErr.code="AUTOMATION_COORDINATOR_UNAVAILABLE";if(window.__extReportRuntimeError)window.__extReportRuntimeError("MESSAGE_CROSS_TAB_COORDINATOR_UNAVAILABLE",coordErr);emit("MessageIgnored",{reason:"coordinator_unavailable",msgID:id,type:type,timestamp:ts},{source:"event-gateway",correlationId:id||null});return;}
    messageAutomationQueue=messageAutomationQueue.then(async function(){
      var claimed=await window.__extClaimAutomationEvent("message-received",id,15*60*1000);
      if(!claimed){emit("MessageIgnored",{reason:"duplicate_cross_tab",msgID:id,type:type,timestamp:ts},{source:"event-gateway",correlationId:id||null});return;}
      emit("MessageReceived", { data:data, msgID:id, author:normalizeAuthor(payload), type:type, timestamp:ts }, { source:"event-gateway", correlationId:id||null });
    }).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("MESSAGE_CROSS_TAB_COORDINATION_FAILED",err);emit("MessageIgnored",{reason:"coordinator_failed",msgID:id,type:type,timestamp:ts},{source:"event-gateway",correlationId:id||null});});
  }

  function unbindWpp() {
    for(var i=wppUnsubs.length-1;i>=0;i--){try{if(typeof wppUnsubs[i]==="function")wppUnsubs[i]();}catch(_){} }
    wppUnsubs=[];wppBridge=null;wppBound=false;
  }
  function bindWpp() {
    var bridge = window.__extWppBridge;
    if (!bridge || typeof bridge.on !== "function") return false;
    if (wppBound && wppBridge === bridge) return true;
    if (wppBound || wppUnsubs.length) unbindWpp();
    var unsubs=[];
    try {
      unsubs.push(bridge.on("chat.new_message", handleNewMessage));
      unsubs.push(bridge.on("chat.active_chat", function(p){emit("ActiveChatChanged",p,{source:"wpp"});}));
      unsubs.push(bridge.on("webpack.full_ready", function(p){synchronized=true;emit("WppFullReady",p,{source:"wpp"});}));
      unsubs.push(bridge.on("chat.presence_change", function(p){emit("PresenceChanged",p,{source:"wpp"});}));
      unsubs.push(bridge.on("chat.update_label", function(p){emit("LabelChanged",p,{source:"wpp"});}));
      unsubs.push(bridge.on("conn.stream_info_changed", function(p){
        if(p && typeof p.isSynchronized === "boolean") synchronized=p.isSynchronized;
        emit("ConnectionStateChanged",p,{source:"wpp"});
      }));
      wppUnsubs=unsubs;wppBridge=bridge;wppBound = true;
      return true;
    } catch (err) {
      for(var i=unsubs.length-1;i>=0;i--){try{if(typeof unsubs[i]==="function")unsubs[i]();}catch(_){} }
      wppUnsubs=[];wppBridge=null;wppBound = false;
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("EVENT_BUS_WPP_BIND_FAILED",err);
      return false;
    }
  }

  function relay(name, payload, meta) {
    if (!relayAllowlist.has(name)) { var e=new Error("Evento não autorizado para relay: "+name); e.code="EVENT_RELAY_NOT_ALLOWED"; throw e; }


    var env=makeEnvelope(name,payload,Object.assign({source:"main-local"},meta||{}));
    dispatchEnvelope(env);
    return env;
  }


  var api=Object.freeze({
    version:"1.0.0", protocol:PROTOCOL, protocolVersion:VERSION,
    emit:emit,on:on,once:once,clear:clear,relay:relay,bindWpp:bindWpp,
    dispatchEnvelope:dispatchEnvelope, makeEnvelope:makeEnvelope,
    history:function(){return history.slice();},
    isSynchronized:function(){return synchronized;},
    acceptedMessageTypes:Array.from(acceptedMessageTypes),
    constants:{MESSAGE_MAX_AGE_MS:MAX_MESSAGE_AGE_MS,MESSAGE_DEDUPE_MAX:MAX_MESSAGE_DEDUPE}
  });
  window.__extDomainEventBus=api;


  window.__extEventBus=api;
  window.ExtensionCore=window.ExtensionCore||{};
  window.ExtensionCore.EventBus=api;
  try { window.dispatchEvent(new CustomEvent("ext:eventbus-ready")); } catch (_) {}

  window.addEventListener("pagehide",function(){unbindWpp();});
  window.addEventListener("pageshow",function(){if(!bindWpp())setTimeout(function(){bindWpp();},250);});
  if(!bindWpp()){
    document.addEventListener("wppconnect_ready", function(){ bindWpp(); }, { once:true });
    setTimeout(function(){ bindWpp(); }, 4000);
  }
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{


(function(){
  "use strict";
  if(window.__extDomainEventRelayBooted)return;
  window.__extDomainEventRelayBooted=true;
  var PROTOCOL="EXTAPP_DOMAIN_EVENT", VERSION=1;
  var allowed=new Set(["LicenseRefresh","ConfigRefresh","RemoteNotificationTick","FollowUpTimingTick","AgendaTick","StatusTick","BackupTick","MeetLiveTick","NotificationTick"]);
  function valid(env){return !!env&&env.protocol===PROTOCOL&&env.version===VERSION&&typeof env.id==="string"&&allowed.has(env.name);}
  chrome.runtime.onMessage.addListener(function(msg,sender){
    if(!sender||sender.id!==chrome.runtime.id)return;
    if(!msg||msg.__extDomainEventRelay!==true||!valid(msg.envelope))return;
    var bus=window.__extDomainEventBus||window.__extEventBus;
    if(!bus||typeof bus.dispatchEnvelope!=="function")return;
    bus.dispatchEnvelope(msg.envelope);
  });


})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
