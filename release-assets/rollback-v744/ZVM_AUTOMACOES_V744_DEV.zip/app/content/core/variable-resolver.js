(function(root){
  "use strict";
  function str(v){return v==null?"":String(v).trim();}
  function serialized(v){if(v&&v._serialized)return String(v._serialized);return String(v||"");}
  function hasOwn(o,k){return Object.prototype.hasOwnProperty.call(o,k);}
  function formatPhone(raw){
    var d=String(raw||"").replace(/\D/g,""); if(!d)return "";
    if(d.length>=12&&d.slice(0,2)==="55"){
      var rest=d.slice(2),ddd=rest.slice(0,2),num=rest.slice(2);
      if(num.length===9)return "+55 ("+ddd+") "+num.slice(0,5)+"-"+num.slice(5);
      if(num.length===8)return "+55 ("+ddd+") "+num.slice(0,4)+"-"+num.slice(4);
    }
    return "+"+d;
  }
  function languageCode(context,meta){
    var raw=str(context&&context.language||meta&&meta.language).toLowerCase();
    if(raw.indexOf("en")===0)return "en"; if(raw.indexOf("es")===0)return "es"; return "pt";
  }
  function temporal(lang,now){
    now=now||new Date();var h=now.getHours(),greeting,period;
    if(lang==="en"){greeting=h<12?"Good morning":h<18?"Good afternoon":"Good evening";period=h<12?"morning":h<18?"afternoon":"evening";}
    else if(lang==="es"){greeting=h<12?"Buenos días":h<19?"Buenas tardes":"Buenas noches";period=h<12?"mañana":h<19?"tarde":"noche";}
    else{greeting=h<12?"Bom dia":h<18?"Boa tarde":"Boa noite";period=h<12?"manhã":h<18?"tarde":"noite";}
    var locale=lang==="en"?"en-US":lang==="es"?"es-ES":"pt-BR";
    return {saudacao:greeting,periodo:period,diaSemana:now.toLocaleDateString(locale,{weekday:"long"}),data:String(now.getDate()).padStart(2,"0")+"/"+String(now.getMonth()+1).padStart(2,"0")+"/"+now.getFullYear(),hora:String(now.getHours()).padStart(2,"0")+":"+String(now.getMinutes()).padStart(2,"0")};
  }
  function scalar(source,target){
    if(!source||typeof source!=="object")return;
    Object.keys(source).forEach(function(k){var v=source[k];if(v==null||!(typeof v==="string"||typeof v==="number"||typeof v==="boolean"))return;if(!hasOwn(target,k))target[k]=v;});
  }
  async function contactFromBridge(rawId,context){
    if(context&&context.contact&&typeof context.contact==="object")return context.contact;
    if(!rawId)return null;
    try{if(root.__extWppBridge&&typeof root.__extWppBridge.invoke==="function")return await root.__extWppBridge.invoke("Contact","get",{id:rawId});}catch(_){}
    try{var engine=root.ExtensionChatBridge;if(engine&&engine.isReady&&engine.contact&&typeof engine.contact.get==="function")return await engine.contact.get(rawId);}catch(_){}
    return null;
  }
  async function activeChat(){
    try{if(root.__extWppBridge&&typeof root.__extWppBridge.invoke==="function")return await root.__extWppBridge.invoke("Chat","getActiveChat","@");}catch(_){}
    try{var engine=root.ExtensionChatBridge;if(engine&&engine.isReady&&engine.chat&&typeof engine.chat.getActiveChat==="function")return await engine.chat.getActiveChat();}catch(_){}
    return null;
  }
  async function phoneFromId(rawId){
    var plain=String(rawId||"").replace(/@(c|g)\.us$/i,"").replace(/@lid$/i,"");
    if(!/@lid$/i.test(rawId))return plain;
    try{
      if(root.__extWppBridge&&typeof root.__extWppBridge.invoke==="function"){
        var entry=await root.__extWppBridge.invoke("Contact","getPnLidEntry",{id:rawId});
        var pn=entry&&entry.phoneNumber&&(entry.phoneNumber._serialized||entry.phoneNumber.user);if(pn)return String(pn).replace(/@(c|g)\.us$/i,"").replace(/@lid$/i,"");
      }
    }catch(_){}
    try{var engine=root.ExtensionChatBridge;if(engine&&engine.isReady&&engine.contact&&typeof engine.contact.getPnLidEntry==="function"){var e=await engine.contact.getPnLidEntry(rawId);var p=e&&e.phoneNumber&&(e.phoneNumber._serialized||e.phoneNumber.user);if(p)return String(p).replace(/@(c|g)\.us$/i,"").replace(/@lid$/i,"");}}catch(_){}
    return plain;
  }
  async function buildForChat(chatId,context){
    context=context||{};var vars=Object.assign({},context.variables||{}),rawId=serialized(chatId||context.contactId||context.chatId||context.remetente||"");
    var contact=await contactFromBridge(rawId,context),active=await activeChat(),meta=null;
    try{if(rawId&&root.__extContactMetadataService&&typeof root.__extContactMetadataService.get==="function")meta=await root.__extContactMetadataService.get(rawId);}catch(_){}
    scalar(contact,vars);scalar(meta,vars);
    var activeId=serialized(active&&active.id),activeContact=active&&active.contact||null,activeMatches=!!active&&(!rawId||!activeId||activeId===rawId);
    var localName=str(meta&&meta.localAlias||context.localAlias);
    var whatsappName=str(contact&&(contact.name||contact.pushname||contact.formattedName||contact.notifyName||contact.shortName)||activeMatches&&activeContact&&(activeContact.name||activeContact.pushname||activeContact.formattedName||activeContact.notifyName||activeContact.shortName)||activeMatches&&(active.formattedTitle||active.name||active.title));
    var suppliedName=str(context.contactName||context.name),fullName=localName||whatsappName||suppliedName,firstName=fullName?fullName.split(/\s+/)[0]:"";
    var rawNumber=await phoneFromId(rawId),number=formatPhone(rawNumber);var lang=languageCode(context,meta),clock=temporal(lang,new Date());
    var aliases={
      primeiro_nome:firstName,primeiroNome:firstName,first_name:firstName,fn:firstName,
      nome:fullName,nome_completo:fullName,full_name:fullName,
      nome_extapp:localName||fullName,nome_ext:localName||fullName,nome_whatsapp:whatsappName||fullName,
      numero:number,telefone:number,phone:number,
      email:str(meta&&meta.email||vars.email),empresa:str(meta&&meta.company||vars.company||vars.empresa),company:str(meta&&meta.company||vars.company||vars.empresa),
      origem_lead:str(meta&&meta.leadSource||vars.leadSource||vars.origem_lead),leadSource:str(meta&&meta.leadSource||vars.leadSource||vars.origem_lead),
      cidade:str(meta&&meta.city||vars.city||vars.cidade),city:str(meta&&meta.city||vars.city||vars.cidade),estado:str(meta&&meta.state||vars.state||vars.estado),state:str(meta&&meta.state||vars.state||vars.estado),
      endereco:str(meta&&meta.address||vars.address||vars.endereco),address:str(meta&&meta.address||vars.address||vars.endereco),cep:str(meta&&meta.postalCode||vars.postalCode||vars.cep),postalCode:str(meta&&meta.postalCode||vars.postalCode||vars.cep),
      idioma:str(meta&&meta.language||vars.language||vars.idioma),language:str(meta&&meta.language||vars.language||vars.idioma),
      saudacao:clock.saudacao,"saudação":clock.saudacao,periodo_dia:clock.periodo,"periodo-dia":clock.periodo,dia_semana:clock.diaSemana,data:clock.data,hora:clock.hora
    };
    Object.keys(aliases).forEach(function(k){if(aliases[k]!==""||!hasOwn(vars,k))vars[k]=aliases[k];});return vars;
  }
  function expression(expr,vars,original){
    var raw=String(expr||"").trim(),m=raw.match(/^([^|]+?)(?:\|\s*(?:fallback|default|padrao|padrão)\s*:\s*["']([^"']*)["'])?$/i),key=String(m&&m[1]||raw).trim(),fallback=m&&m[2];
    if(hasOwn(vars,key)){var v=vars[key];if(v!=null&&String(v)!=="")return String(v);if(fallback!=null)return fallback;return "";}
    return fallback!=null?fallback:original;
  }
  function resolveString(value,vars){
    vars=vars||{};var out=String(value==null?"":value);
    out=out.replace(/\{\{\s*([^{}]+?)\s*\}\}/g,function(all,expr){return expression(expr,vars,all);});
    out=out.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(all,prefix,key){return prefix+expression(key,vars,"{"+key+"}");});
    Object.keys(vars).sort(function(a,b){return b.length-a.length;}).forEach(function(key){if(!key||/[{}\s]/.test(key))return;var token="#"+key;if(out.indexOf(token)>=0)out=out.split(token).join(String(vars[key]==null?"":vars[key]));});
    return out;
  }
  var SYSTEM_TOKEN=/(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|first_name|fn|nome|nome_completo|full_name|nome_extapp|nome_ext|nome_whatsapp|numero|telefone|phone|email|empresa|company|origem_lead|leadSource|cidade|city|estado|state|endereco|address|cep|postalCode|idioma|language|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i;
  function needsResolution(value){return SYSTEM_TOKEN.test(String(value==null?"":value));}
  async function resolveForChat(value,chatId,context){if(value==null)return value;if(!needsResolution(value))return String(value);var vars=await buildForChat(chatId,context);return resolveString(value,vars);}
  root.__extVariableResolver=Object.freeze({version:"2.0.0",formatPhone:formatPhone,buildForChat:buildForChat,resolveString:resolveString,resolveForChat:resolveForChat,needsResolution:needsResolution});
})(window);
