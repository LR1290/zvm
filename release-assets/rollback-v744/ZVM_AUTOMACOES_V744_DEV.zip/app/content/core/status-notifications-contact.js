;
try{

(function(){
  "use strict";
  if(window.__extStatusService)return;

  var KEY="EXTUI:statusScheduleStore";
  async function paid(){if(!window.__extPlanGate)throw Object.assign(new Error("Sua sessão precisa ser validada novamente."),{code:"LICENSE_REQUIRED"});await window.__extPlanGate.requirePaid("Status");return true;}

  function storage(){
    if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");
    return window.ExtensionStorage;
  }
  function parse(value){
    if(value==null||value==="")return[];
    var parsed=value;if(typeof value==="string"){try{parsed=JSON.parse(value);}catch(err){err.code="STATUS_STORE_CORRUPT";throw err;}}
    if(!Array.isArray(parsed)||parsed.some(function(item){return !item||typeof item!=="object"||Array.isArray(item);}))throw Object.assign(new Error("Os agendamentos de Status estão inválidos e não serão sobrescritos."),{code:"STATUS_STORE_CORRUPT"});
    return parsed;
  }
  function uniqueIds(list){
    var seen=Object.create(null),out=[];
    (Array.isArray(list)?list:[]).forEach(function(id){
      id=String(id||"").trim();
      if(!/@(?:c\.us|lid)$/i.test(id)||seen[id])return;
      seen[id]=true;out.push(id);
    });
    return out;
  }
  async function list(){await paid();return parse(await storage().get(KEY));}
  async function persist(items){await storage().set(KEY,JSON.stringify(items));return items;}

  async function resolvePrivacyRecipients(job,wpp){
    var mode=String(job&&job.privacyMode||"").trim();
    if(!mode)return null;
    if(mode==="contacts")return [];

    var selected=uniqueIds(job&&job.privacyContactIds);
    if(mode==="only"){
      if(!selected.length){var onlyErr=new Error("Selecione pelo menos um contato para 'Apenas compartilhar com...'.");onlyErr.code="STATUS_PRIVACY_EMPTY_ALLOW_LIST";throw onlyErr;}
      return selected;
    }
    if(mode==="except"){
      if(!selected.length)return [];
      var roster=await wpp.invoke("Contact","ListPlain",{});
      roster=Array.isArray(roster)?roster:[];
      if(!roster.length){var rosterErr=new Error("Não foi possível carregar os contatos para aplicar as exceções de privacidade.");rosterErr.code="STATUS_PRIVACY_CONTACTS_UNAVAILABLE";throw rosterErr;}
      var denied=Object.create(null);selected.forEach(function(id){denied[id]=true;});
      var allowed=uniqueIds(roster.map(function(c){return c&&c.idStr;}).filter(function(id){return id&&!denied[id];}));


      if(!allowed.length){var allErr=new Error("A configuração excluiria todos os contatos do Status.");allErr.code="STATUS_PRIVACY_ALL_EXCLUDED";throw allErr;}
      return allowed;
    }
    var invalid=new Error("Privacidade do Status inválida");invalid.code="STATUS_PRIVACY_INVALID";throw invalid;
  }

  async function applyPrivacy(job,wpp){
    await paid();
    var recipients=await resolvePrivacyRecipients(job,wpp);
    if(recipients===null)return null;
    await wpp.invoke("Status","updateParticipants",{ids:recipients});
    return recipients;
  }
  function statusSafetyMethod(job){
    if(job&&job.type==="text")return "sendTextStatus";
    if(job&&job.type==="image")return "sendImageStatus";
    if(job&&job.type==="video")return "sendVideoStatus";
    return "status";
  }
  async function sendUnlocked(job){
    job=job||{};
    var wpp=window.__extWppBridge;
    if(!wpp)throw new Error("O WhatsApp ainda não está pronto");
    await applyPrivacy(job,wpp);
    if(job.type==="text")return wpp.invoke("Status","sendTextStatus",{texto:job.text,color:job.color});
    if(job.type==="image")return wpp.invoke("Status","sendImageStatus",{base64:job.base64});
    if(job.type==="video")return wpp.invoke("Status","sendVideoStatus",{base64:job.base64});
    throw Object.assign(new Error("Tipo de status inválido"),{code:"STATUS_TYPE_INVALID"});
  }
  async function send(job,options){
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Publicação de Status");
    options=options||{};
    var safety=window.__extSendSafetyManager;
    var meta={
      method:statusSafetyMethod(job),
      source:options.source||"status-manual",
      interactive:options.interactive!==false,
      exempt:options.exempt===true,
      effectId:options.effectId||null,
      effectPayload:{type:job&&job.type||"",text:job&&job.text||"",color:job&&job.color||"",base64:job&&job.base64||"",privacyMode:job&&job.privacyMode||"",privacyContactIds:Array.isArray(job&&job.privacyContactIds)?job.privacyContactIds:[]},
      signal:options.signal||null
    };
    if(!safety||typeof safety.enqueue!=="function")return Promise.reject(Object.assign(new Error("Proteção de Envio indisponível; publicação bloqueada."),{code:"SEND_SAFETY_UNAVAILABLE"}));
    return safety.enqueue(meta,function(){return sendUnlocked(job);});
  }

  async function schedule(job){
    if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Agendamento de Status");
    var items=await list();
    var item=Object.assign({id:"extuis-"+Date.now().toString(36),status:"pending",runAt:Date.now()},job||{});
    item.privacyContactIds=uniqueIds(item.privacyContactIds);
    items.push(item);await persist(items);return item;
  }

  async function tickUnlocked(lease){
    var items=await list(),now=Date.now(),changed=false;if(lease)lease.assertActive();
    for(var i=0;i<items.length;i++){
      if(lease&&!lease.isActive())break;var job=items[i];
      if(job.status!=="pending"||Number(job.runAt)>now)continue;
      try{if(lease)lease.assertActive();await send(job,{source:"status-scheduled",interactive:false,effectId:"status:"+String(job.id),signal:lease&&lease.signal||null});job.status="sent";job.sentAt=Date.now();delete job.error;}
      catch(e){job.status="error";job.error=e&&e.code||e&&e.message||String(e);}
      changed=true;
    }
    if(changed)await persist(items);
    return items;
  }
  async function tick(){
    if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return[];
    if(typeof window.__extWithAutomationLease!=="function")throw Object.assign(new Error("Coordenação segura entre abas indisponível."),{code:"AUTOMATION_COORDINATOR_UNAVAILABLE"});
    var coordinated=await window.__extWithAutomationLease("status-tick",tickUnlocked);return coordinated.executed?coordinated.value:await list();
  }

  var api=Object.freeze({version:"1.2.0",send:send,schedule:schedule,list:list,tick:tick,applyPrivacy:applyPrivacy});
  window.__extStatusService=api;
  window.ExtensionCore=window.ExtensionCore||{};
  
  var bus=window.__extEventBus;
  if(bus&&bus.on)bus.on("StatusTick",function(){tick().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("STATUS_TICK_FAILED",err);});});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){"use strict";if(window.__extNotificationService)return;var KEY="EXTUI:notificationStore",MAX=100;
 function r(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}function parse(v){if(v==null||v==="")return[];var parsed=v;if(typeof v==="string"){try{parsed=JSON.parse(v);}catch(err){err.code="NOTIFICATION_STORE_CORRUPT";throw err;}}if(!Array.isArray(parsed)||parsed.some(function(item){return !item||typeof item!=="object"||Array.isArray(item);}))throw Object.assign(new Error("As notificações salvas estão inválidas e não serão sobrescritas."),{code:"NOTIFICATION_STORE_CORRUPT"});return parsed;}async function list(){return parse(await r().get(KEY));}async function save(a){if(!Array.isArray(a))throw Object.assign(new Error("As notificações não puderam ser salvas."),{code:"NOTIFICATION_STORE_INVALID"});a=a.slice(-MAX);await r().set(KEY,JSON.stringify(a));return a;}async function push(n){var a=await list(),x=Object.assign({id:"extuin-"+Date.now().toString(36),createdAt:Date.now(),read:false,expiresAt:null},n||{});a.push(x);await save(a);return x;}async function markRead(id){var a=await list();a.forEach(function(x){if(x.id===id){x.read=true;x.readAt=Date.now();}});return save(a);}async function tickUnlocked(lease){var a=await list(),now=Date.now(),changed=false;if(lease)lease.assertActive();for(var i=0;i<a.length;i++){if(lease&&!lease.isActive())break;var x=a[i];if(!x.delivered&&x.triggerAt&&Number(x.triggerAt)<=now){x.delivered=true;x.deliveredAt=now;changed=true;if(window.__extEventBus)window.__extEventBus.emit("NotificationDue",x,{source:"notifications"});}}var next=a.filter(function(x){return !x.expiresAt||Number(x.expiresAt)>now;});if(changed||next.length!==a.length)await save(next);if(lease)lease.assertActive();return next;}async function tick(){if(typeof window.__extWithAutomationLease!=="function")throw Object.assign(new Error("Coordenação segura entre abas indisponível."),{code:"AUTOMATION_COORDINATOR_UNAVAILABLE"});var coordinated=await window.__extWithAutomationLease("notification-tick",tickUnlocked);return coordinated.executed?coordinated.value:await list();}
 var api=Object.freeze({version:"1.1.0",list:list,push:push,markRead:markRead,tick:tick});window.__extNotificationService=api;window.ExtensionCore=window.ExtensionCore||{};var b=window.__extEventBus;if(b&&b.on){b.on("NotificationTick",function(){tick().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("NOTIFICATION_TICK_FAILED",err);});});b.on("RemoteNotificationTick",function(){tick().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("NOTIFICATION_TICK_FAILED",err);});});}})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){"use strict";if(window.__extContactMetadataService)return;var KEY="EXTUI:contactMetadataStore",lastValid=null;async function paid(){if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Perfil e notas do cliente");return true;}function r(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}function metadataError(cause){var err=new Error("Os dados locais deste contato estão corrompidos. O último estado válido foi preservado e a sobrescrita foi bloqueada.");err.code="CONTACT_METADATA_CORRUPT";if(cause)err.cause=cause;return err;}function clone(v){return v==null?v:JSON.parse(JSON.stringify(v));}function parse(v){var parsed=v;if(v==null||v==="")parsed={};else if(typeof v==="string"){try{parsed=JSON.parse(v);}catch(e){throw metadataError(e);}}if(!parsed||typeof parsed!=="object"||Array.isArray(parsed))throw metadataError();Object.keys(parsed).forEach(function(k){var row=parsed[k];if(!row||typeof row!=="object"||Array.isArray(row))throw metadataError();if(row.notes!==undefined&&(!Array.isArray(row.notes)||row.notes.some(function(n){return !n||typeof n!=="object"||Array.isArray(n);})))throw metadataError();});return clone(parsed);}function jid(x){return String(x&&x._serialized||x||"").trim();}async function all(){await paid();try{var value=parse(await r().get(KEY));lastValid=clone(value);return value;}catch(e){throw e;}}async function get(id){var a=await all();return a[jid(id)]||null;}async function set(id,data){await paid();var a;try{a=await all();}catch(e){if(lastValid)void 0;throw e;}var k=jid(id);if(!k)throw new Error("Não foi possível identificar o contato");data=data&&typeof data==="object"&&!Array.isArray(data)?Object.assign({},data):{};var stamp=Date.now();if(Object.prototype.hasOwnProperty.call(data,"notes")&&!Number(data.notesUpdatedAt))data.notesUpdatedAt=stamp;a[k]=Object.assign({},a[k]||{},data,{updatedAt:stamp});await r().set(KEY,JSON.stringify(a));lastValid=clone(a);return clone(a[k]);}async function addNote(id,text){await paid();var cur=await get(id)||{},notes=Array.isArray(cur.notes)?cur.notes.slice():[],stamp=Date.now();notes.push({id:"note-"+stamp.toString(36),text:String(text||""),createdAt:stamp,updatedAt:stamp});return set(id,{notes:notes,notesUpdatedAt:stamp});}var api=Object.freeze({version:"1.1.0",all:all,get:get,set:set,addNote:addNote});window.__extContactMetadataService=api;window.ExtensionCore=window.ExtensionCore||{};})();
(function(){
  "use strict";
  if(window.__extLocalAliasOverlay)return;
  var KEY="EXTUI:contactMetadataStore",aliases=[],timer=0,rootObserver=null,targetObservers=[],started=false;
  function parse(v){try{if(typeof v==="string")v=JSON.parse(v);return v&&typeof v==="object"&&!Array.isArray(v)?v:{};}catch(_){return {};}}
  function build(store){aliases=[];Object.keys(store||{}).forEach(function(id){var x=store[id]||{},alias=String(x.localAlias||"").trim(),source=String(x.whatsappName||x.sourceName||"").trim();if(alias&&source&&alias!==source)aliases.push({source:source,alias:alias});});}
  function aliasFor(source){source=String(source||"").trim();for(var i=0;i<aliases.length;i++)if(aliases[i].source===source)return aliases[i].alias;return "";}
  function scan(){timer=0;if(!aliases.length)return;var nodes=document.querySelectorAll('#pane-side span[title],#pane-side span[dir="auto"],#pane-side span[dir="ltr"],#main header span[title],#main header span[dir="auto"],#main header span[dir="ltr"],[data-extui-alias-original]');nodes.forEach(function(node){if(!node||node.closest&&node.closest('[id^="extapp-"],.extuiPanelShell,.extuiNavPanel'))return;var current=String(node.textContent||"").trim(),stored=node.getAttribute('data-extui-alias-original')||"",storedAlias=stored?aliasFor(stored):"";if(stored&&current!==stored&&current!==storedAlias){node.removeAttribute('data-extui-alias-original');stored="";}var original=stored||current,alias=aliasFor(original);if(alias){if(!stored)node.setAttribute('data-extui-alias-original',original);if(current!==alias)node.textContent=alias;if(node.hasAttribute('title'))node.setAttribute('title',alias);}else if(stored){node.textContent=original;if(node.hasAttribute('title'))node.setAttribute('title',original);node.removeAttribute('data-extui-alias-original');}});}
  function queue(){if(timer)return;timer=setTimeout(scan,80);}
  async function refresh(){if(!window.ExtensionStorage)return;try{build(parse(await window.ExtensionStorage.get(KEY)));queue();}catch(_){}}
  function pruneTargetObservers(){
    targetObservers=targetObservers.filter(function(entry){
      var node=entry&&entry.node;
      if(node&&node.isConnected)return true;
      try{if(entry&&entry.observer)entry.observer.disconnect();}catch(_){}
      try{if(node)delete node.__extAliasObserved;}catch(_){}
      return false;
    });
  }
  function observeTarget(node){
    if(!node||node.__extAliasObserved)return;
    try{
      node.__extAliasObserved=true;
      var ob=new MutationObserver(queue);
      ob.observe(node,{childList:true,subtree:true,characterData:true});
      targetObservers.push({node:node,observer:ob});
    }catch(_){try{delete node.__extAliasObserved;}catch(__){}}
  }
  function attachTargets(){pruneTargetObservers();observeTarget(document.getElementById('pane-side'));var main=document.getElementById('main');observeTarget(main&&main.querySelector('header'));queue();}
  function start(){
    if(started)return;
    started=true;
    attachTargets();
    if(window.MutationObserver){
      var app=document.getElementById('app')||document.body;
      rootObserver=new MutationObserver(function(mutations){
        pruneTargetObservers();
        var pane=document.getElementById('pane-side'),main=document.getElementById('main'),header=main&&main.querySelector('header'),need=!pane||!pane.__extAliasObserved||!header||!header.__extAliasObserved;
        if(!need){for(var i=0;i<mutations.length&&!need;i++){var m=mutations[i];for(var j=0;j<m.addedNodes.length;j++){var n=m.addedNodes[j];if(n&&n.nodeType===1&&(n.id==='pane-side'||n.id==='main'||(n.querySelector&&(n.querySelector('#pane-side')||n.querySelector('#main header'))))){need=true;break;}}}}
        if(need)attachTargets();
      });
      rootObserver.observe(app,{childList:true,subtree:true});
    }
    setTimeout(refresh,160);
  }
  window.__extLocalAliasOverlay={refresh:refresh,scan:scan};
  if(window.ExtensionStorage&&typeof window.ExtensionStorage.subscribe==="function")window.ExtensionStorage.subscribe(KEY,function(raw){build(parse(raw));if(started)queue();});
  if(window.__extEventBus&&typeof window.__extEventBus.on==="function")window.__extEventBus.on("ActiveChatChanged",function(){if(started)queue();});
  if(window.__extBootPhases&&typeof window.__extBootPhases.when==="function")window.__extBootPhases.when(3,start);else setTimeout(start,1200);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
