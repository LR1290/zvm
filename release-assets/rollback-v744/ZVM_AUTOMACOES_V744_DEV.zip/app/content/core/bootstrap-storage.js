;try{if(window.__extBootPhases&&window.__extBootPhases.mark)window.__extBootPhases.mark("content:start");}catch(_){}

try{(function(root){
  "use strict";
  if(root.__extNotify)return;
  function ensureStatusRegion(){
    var region=document.getElementById("extui-global-status-region");
    if(region)return region;
    region=document.createElement("div"); region.id="extui-global-status-region"; region.setAttribute("role","status");
    region.setAttribute("aria-live","polite"); region.setAttribute("aria-atomic","true");
    region.style.cssText="position:fixed;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;";
    document.body.appendChild(region); return region;
  }
  function shouldShowSuccess(message){return /(?:enviad[oa]|conclu[ií]d|importad[oa]|exportad[oa]|backup|c[oó]pia|restaurad[oa]|agendad[oa]|conectad[oa]|campanha|teste.{0,24}sucesso|processamento.{0,24}finaliz)/i.test(String(message||""));}
  root.__extNotify=function(message,isError){
    message=String(message==null?"":message);
    var status=ensureStatusRegion(); status.textContent=""; setTimeout(function(){status.textContent=message;},0);
    if(!isError&&!shouldShowSuccess(message))return status;
    var host=document.getElementById("extui-global-toast-host");
    if(!host){ host=document.createElement("div"); host.id="extui-global-toast-host"; host.className="extuiToastWrap"; document.body.appendChild(host); }
    var item=document.createElement("div"); item.className="extuiToast "+(isError?"extuiToast--error":"extuiToast--success");
    item.setAttribute("role",isError?"alert":"status"); item.textContent=message; host.appendChild(item);
    while(host.children.length>3)host.firstElementChild.remove();
    setTimeout(function(){if(item&&item.parentNode)item.remove();},isError?4200:2600);
    return item;
  };
})(window)}catch(_extuiNotifyBootstrapError){if(window.__extRecordBootError)window.__extRecordBootError(_extuiNotifyBootstrapError);else throw _extuiNotifyBootstrapError;};
try{(function(root){"use strict";if(root.__extNormalizeAudioReference)return;root.__extNormalizeAudioReference=async function(value,meta){meta=meta||{};if(!root.ExtensionMediaStore)throw new Error("Cofre de mídia indisponível");var ref=value;if(!root.ExtensionMediaStore.isRef(ref)){if(typeof ref!=="string"||ref.indexOf("data:")!==0)throw new Error("Áudio inválido para conversão");ref=await root.ExtensionMediaStore.putDataUrl(ref,{mimeType:meta.mimeType||"application/octet-stream",fileName:meta.fileName||"audio"})}return new Promise(function(resolve,reject){chrome.runtime.sendMessage({type:"EXTUI_AUDIO_NORMALIZE_REF",ref:ref,fileName:meta.fileName||"audio",bitrate:Number(meta.bitrate)||32000},function(r){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message));return}if(!r||r.ok!==true){var e=new Error(r&&r.error||"Falha ao preparar áudio");e.code=r&&r.code||"AUDIO_NORMALIZE_FAILED";reject(e);return}resolve(r.data)})})}})(window)}catch(_extuiAudioBridgeError){if(window.__extRecordBootError)window.__extRecordBootError(_extuiAudioBridgeError);else throw _extuiAudioBridgeError;};

try{(function(root){
  "use strict";
  if(root.__extWithAutomationLease&&root.__extClaimAutomationEvent)return;
  function coordinatorRequest(payload){
    return new Promise(function(resolve,reject){
      var settled=false,timer=setTimeout(function(){if(settled)return;settled=true;var e=new Error("A coordenação entre abas demorou demais.");e.code="AUTOMATION_COORDINATOR_TIMEOUT";reject(e);},7000);
      try{
        chrome.runtime.sendMessage(Object.assign({type:"EXTUI_AUTOMATION_COORDINATOR"},payload||{}),function(response){
          if(settled)return;settled=true;clearTimeout(timer);
          var runtimeErr=chrome.runtime.lastError;if(runtimeErr){var transportErr=new Error(runtimeErr.message||"A coordenação entre abas foi interrompida.");transportErr.code="AUTOMATION_COORDINATOR_TRANSPORT";reject(transportErr);return;}
          if(!response||response.ok!==true){var err=new Error(response&&response.userMessage||"A coordenação entre abas falhou.");err.code=response&&response.errorCode||"AUTOMATION_COORDINATOR_FAILED";reject(err);return;}
          resolve(response.result||{});
        });
      }catch(err){if(settled)return;settled=true;clearTimeout(timer);reject(err);}
    });
  }
  function report(code,err){if(root.__extReportRuntimeError)root.__extReportRuntimeError(code,err);}
  function coordinatorClaimToken(){var c=root.crypto;if(c&&typeof c.randomUUID==="function")return c.randomUUID();return "claim-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2)+"-"+Math.random().toString(36).slice(2);}
  async function hashToken(scope,token){
    if(!root.crypto||!root.crypto.subtle)throw Object.assign(new Error("SHA-256 indisponível para deduplicação segura."),{code:"AUTOMATION_COORDINATOR_HASH_UNAVAILABLE"});
    var bytes=new TextEncoder().encode(String(scope||"")+"|"+String(token||"")),digest=await root.crypto.subtle.digest("SHA-256",bytes);
    return Array.from(new Uint8Array(digest)).map(function(b){return b.toString(16).padStart(2,"0");}).join("");
  }
  root.__extWithAutomationLease=async function(scope,fn){
    if(typeof fn!=="function")throw new TypeError("A coordenação automática exige uma função.");
    var claimant=coordinatorClaimToken(),acquirePayload={action:"acquire",scope:String(scope||""),claimant:claimant,ttlMs:300000},acquired;
    try{acquired=await coordinatorRequest(acquirePayload);}catch(acquireErr){if(!acquireErr||["AUTOMATION_COORDINATOR_TIMEOUT","AUTOMATION_COORDINATOR_TRANSPORT"].indexOf(acquireErr.code)<0)throw acquireErr;await new Promise(function(resolve){setTimeout(resolve,120);});acquired=await coordinatorRequest(acquirePayload);}
    if(acquired.acquired!==true)return{executed:false,reason:"lease_busy",retryAfterMs:Number(acquired.retryAfterMs)||0};
    var leaseToken=String(acquired.token||""),closed=false,leaseLostError=null,leaseAbort=new AbortController(),leaseExpiresAt=Math.max(0,Number(acquired.expiresAt)||0);
    function markLeaseLost(){if(leaseLostError)return;leaseLostError=Object.assign(new Error("A posse da execução entre abas foi perdida."),{code:"AUTOMATION_COORDINATOR_LEASE_LOST"});try{leaseAbort.abort();}catch(_){}report("AUTOMATION_COORDINATOR_LEASE_LOST",leaseLostError);}
    function leaseStillActive(){if(!leaseLostError&&leaseExpiresAt&&Date.now()>=leaseExpiresAt)markLeaseLost();return !leaseLostError;}
    var leaseContext=Object.freeze({signal:leaseAbort.signal,assertActive:function(){if(!leaseStillActive())throw leaseLostError;},isActive:leaseStillActive});
    var renewTimer=setInterval(function(){
      if(closed||!leaseStillActive())return;
      coordinatorRequest({action:"renew",scope:String(scope||""),token:leaseToken,ttlMs:300000}).then(function(result){if(result.renewed!==true){markLeaseLost();return;}leaseExpiresAt=Math.max(0,Number(result.expiresAt)||0);if(!leaseExpiresAt)markLeaseLost();}).catch(function(err){report("AUTOMATION_COORDINATOR_RENEW_FAILED",err);leaseStillActive();});
    },30000);
    try{var value=await fn(leaseContext);leaseContext.assertActive();return{executed:true,value:value};}
    finally{
      closed=true;clearInterval(renewTimer);
      try{await coordinatorRequest({action:"release",scope:String(scope||""),token:leaseToken});}catch(err){report("AUTOMATION_COORDINATOR_RELEASE_FAILED",err);}
    }
  };
  root.__extClaimAutomationEvent=async function(scope,token,ttlMs){
    token=String(token||"");if(!token)throw Object.assign(new Error("A mensagem não possui identificador seguro para deduplicação."),{code:"AUTOMATION_EVENT_ID_REQUIRED"});
    var digest=await hashToken(scope,token),claimant=coordinatorClaimToken(),payload={action:"claim_once",scope:String(scope||""),digest:digest,claimant:claimant,ttlMs:Number(ttlMs)||900000},result;
    try{result=await coordinatorRequest(payload);}catch(err){if(!err||["AUTOMATION_COORDINATOR_TIMEOUT","AUTOMATION_COORDINATOR_TRANSPORT"].indexOf(err.code)<0)throw err;await new Promise(function(resolve){setTimeout(resolve,120);});result=await coordinatorRequest(payload);}
    return result.claimed===true;
  };
})(window)}catch(_extuiAutomationCoordinatorBootError){if(window.__extRecordBootError)window.__extRecordBootError(_extuiAutomationCoordinatorBootError);else throw _extuiAutomationCoordinatorBootError;};
