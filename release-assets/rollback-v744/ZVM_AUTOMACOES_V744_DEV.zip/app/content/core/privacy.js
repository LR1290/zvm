;
try{

(function(){
 "use strict";
 if(window.__extPrivacyService)return;
 var KEY="privacityOptions", STORAGE_KEY="EXTUI:privacyOptions";
 var FLAGS=Object.freeze(["photoHidden","nameHidden","midiaHidden","galeryHidden","lastMessageHidden","messageHidden"]);
 var DEFAULTS=Object.freeze({photoHidden:false,nameHidden:false,midiaHidden:false,galeryHidden:false,lastMessageHidden:false,messageHidden:false});
 function normalize(value){var out=Object.assign({},DEFAULTS),src=value&&typeof value==="object"&&!Array.isArray(value)?value:{};FLAGS.forEach(function(k){out[k]=src[k]===true||src[k]===1||src[k]==="1"||src[k]==="true";});return out;}
 function read(){var raw=null;try{raw=localStorage.getItem(KEY);}catch(_){}if(!raw)return normalize();try{return normalize(JSON.parse(raw));}catch(_){return normalize();}}
 function activeKeys(v){v=normalize(v);return FLAGS.filter(function(k){return v[k]===true;});}
 function apply(v){v=normalize(v||read());var keys=activeKeys(v);if(document.body){if(keys.length)document.body.setAttribute("hide",keys.join(" "));else document.body.removeAttribute("hide");}return keys;}
 function persist(v){if(!window.ExtensionStorage||typeof window.ExtensionStorage.set!=="function")return;Promise.resolve(window.ExtensionStorage.set(STORAGE_KEY,JSON.stringify(normalize(v)))).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("PRIVACY_STORAGE_PERSIST_FAILED",err);});}
 function save(v){var out=normalize(v);try{localStorage.setItem(KEY,JSON.stringify(out));}catch(_){}persist(out);apply(out);return out;}
 function setFlag(name,value){name=String(name||"");if(FLAGS.indexOf(name)<0)throw Object.assign(new Error("Opção de privacidade desconhecida"),{code:"PRIVACY_FLAG_UNKNOWN"});var v=read();v[name]=!!value;return save(v);}
 function reset(){return save(DEFAULTS);}
 function importDecoded(value){return save(normalize(value));}
 function applyStored(raw){if(raw==null||raw==="")return false;var value=raw;try{if(typeof raw==="string")value=JSON.parse(raw);}catch(_){value=null;}if(!value||typeof value!=="object"||Array.isArray(value))return false;var out=normalize(value);try{localStorage.setItem(KEY,JSON.stringify(out));}catch(_){}apply(out);return true;}
 function purgeDeprecatedSensitiveData(){var keys=["EXTUI:deletedMessagesStore"];try{keys.forEach(function(k){localStorage.removeItem(k);});}catch(_){}if(window.ExtensionStorage&&typeof window.ExtensionStorage.remove==="function")keys.forEach(function(k){Promise.resolve(window.ExtensionStorage.remove(k)).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("PRIVACY_DEPRECATED_DATA_PURGE_FAILED",err);});});}
 function hydrate(){if(!window.ExtensionStorage||typeof window.ExtensionStorage.get!=="function"){persist(read());return;}Promise.resolve(window.ExtensionStorage.get(STORAGE_KEY)).then(function(raw){if(!applyStored(raw))persist(read());}).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("PRIVACY_STORAGE_HYDRATE_FAILED",err);});}
 var api=Object.freeze({version:"2.2.0",key:KEY,storageKey:STORAGE_KEY,maxFlags:FLAGS.length,flags:FLAGS.slice(),defaults:Object.assign({},DEFAULTS),read:read,save:save,setFlag:setFlag,reset:reset,importDecoded:importDecoded,apply:apply,active:activeKeys,hydrate:hydrate});
 window.__extPrivacyService=api;window.ExtensionCore=window.ExtensionCore||{};
 if(window.ExtensionStorage&&typeof window.ExtensionStorage.subscribe==="function")window.ExtensionStorage.subscribe(STORAGE_KEY,function(next){if(next!=null)applyStored(next);});
 purgeDeprecatedSensitiveData();
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",function(){apply();hydrate();},{once:true});else{apply();hydrate();}
 window.addEventListener("storage",function(e){if(e.key===KEY)apply();});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){
  "use strict";
  if(window.__extLocalPreferencesMigration)return;
  var TARGET_KEY="EXTUI:compatUiPreferences", MARKER_KEY="EXTUI:localPreferenceMigration";
  var SAFE_KEYS=Object.freeze(["activeLanguage","active-view-menu","NavBarViewer","menu","menuLateral","menuVerticalOpen","openCat","zoom","wpp-status-participants"]);
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function parseMaybe(raw){if(raw==null)return null;try{return JSON.parse(raw);}catch(_){return String(raw);}}
  function readLocal(){var out={};SAFE_KEYS.forEach(function(k){try{var v=localStorage.getItem(k);if(v!=null)out[k]=parseMaybe(v);}catch(_){}});return out;}
  function parseObject(raw){try{if(typeof raw==="string")raw=JSON.parse(raw);return raw&&typeof raw==="object"&&!Array.isArray(raw)?raw:{};}catch(_){return {};}}
  async function run(){
    var r=repo(),marker=parseObject(await r.get(MARKER_KEY));
    if(marker.version>=1)return Object.assign({state:"ALREADY_APPLIED"},marker);
    var local=readLocal(),current=parseObject(await r.get(TARGET_KEY)),merged=Object.assign({},local,current);
    if(Object.keys(merged).length)await r.set(TARGET_KEY,JSON.stringify(merged));
    var privacyState="ABSENT";
    try{
      var raw=localStorage.getItem("privacityOptions");
      if(raw!=null){
        try{
          var decoded=JSON.parse(raw);
          if(decoded&&typeof decoded==="object"&&!Array.isArray(decoded)&&window.__extPrivacyService){window.__extPrivacyService.importDecoded(decoded);privacyState="IMPORTED_DECODED";}
          else privacyState="UNSUPPORTED_FORMAT";
        }catch(_){privacyState="ENCRYPTED_OR_UNSUPPORTED";}
      }
    }catch(_){privacyState="UNAVAILABLE";}
    var result={version:1,state:"MIGRATED",at:Date.now(),sourcePreserved:true,credentialsImported:false,keys:Object.keys(local),privacyState:privacyState};
    await r.set(MARKER_KEY,JSON.stringify(result));
    return result;
  }
  var api=Object.freeze({version:"1.0.0",targetKey:TARGET_KEY,markerKey:MARKER_KEY,safeKeys:SAFE_KEYS.slice(),readLocal:readLocal,run:run});
  window.__extLocalPreferencesMigration=api;window.ExtensionCore=window.ExtensionCore||{};
  Promise.resolve().then(run).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("LOCAL_PREFERENCES_MIGRATION_FAILED",err);});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
