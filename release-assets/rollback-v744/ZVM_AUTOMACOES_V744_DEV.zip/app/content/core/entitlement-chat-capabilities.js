;

try{

(function(){"use strict";if(window.__extEntitlementSecurity)return;var OVERLAY="extuiEntitlementBlockOverlay";function remove(){var e=document.getElementById(OVERLAY);if(e)e.remove();document.documentElement.removeAttribute("data-extui-entitlement-blocked");}function block(reason){document.documentElement.setAttribute("data-extui-entitlement-blocked","true");var e=document.getElementById(OVERLAY);if(!e){e=document.createElement("div");e.id=OVERLAY;e.setAttribute("role","alert");e.style.cssText="position:fixed;inset:0;z-index:2147483647;background:#0b0f0d;color:#fff;display:grid;place-items:center;font:600 16px system-ui;padding:32px;text-align:center";e.textContent="Extensão indisponível nesta sessão. Verifique sua licença e tente novamente.";document.body&&document.body.appendChild(e);}return {blocked:true,reason:reason||"entitlement"};}
 async function evaluate(signal){signal=signal||{};                                                                   if(signal.pt===true||signal.blocked===true||signal.entitled===false)return block("remote_entitlement");remove();return {blocked:false};}
 var api=Object.freeze({version:"1.0.0",evaluate:evaluate,block:block,clear:remove});window.__extEntitlementSecurity=api;window.ExtensionCore=window.ExtensionCore||{};})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){
  "use strict";
  if(window.__extPinnedChatService)return;
  var KEY="EXTUI:pinnedChatsStore", restoring=false;
  async function paid(){if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Fixar conversas pela extensão");return true;}
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function parse(v){try{if(typeof v==="string")v=JSON.parse(v);}catch(_){v=null;}return v;}
  function jid(v){v=String(v&&v._serialized||v||"").trim();if(!v)return"";if(v.indexOf("@")>=0)return v;var n=v.replace(/\D/g,"");return n?n+"@c.us":"";}
  function normalize(v){v=parse(v);var list=[];if(Array.isArray(v))list=v;else if(v&&Array.isArray(v.items))list=v.items;else if(v&&Array.isArray(v.pinned))list=v.pinned;else if(v&&typeof v==="object")Object.keys(v).forEach(function(k){if(v[k])list.push(k);});var seen=new Set();return {schemaVersion:1,items:list.map(function(x){return jid(x&&typeof x==="object"?(x.chatId||x.id||x.userID||x.phoneNumber):x);}).filter(function(x){if(!x||seen.has(x))return false;seen.add(x);return true;})};}
  async function state(){return normalize(await repo().get(KEY));}
  async function save(s){await paid();s=normalize(s);await repo().set(KEY,JSON.stringify(s));return s;}
  async function set(chatId,on){await paid();chatId=jid(chatId);if(!chatId)throw new Error("Não foi possível identificar a conversa");var s=await state(),idx=s.items.indexOf(chatId);if(on&&idx<0)s.items.push(chatId);if(!on&&idx>=0)s.items.splice(idx,1);return save(s);}
  async function pin(chatId){await paid();chatId=jid(chatId);var result=await window.__extWppBridge.invoke("Functions","FixChats",{action:"pin",pin:chatId});var s=await state(),idx=s.items.indexOf(chatId);if(idx<0)s.items.push(chatId);await repo().set(KEY,JSON.stringify(normalize(s)));return result;}
  async function unpin(chatId){await paid();chatId=jid(chatId);var result=await window.__extWppBridge.invoke("Functions","FixChats",{action:"unpin",pin:chatId});var s=await state(),idx=s.items.indexOf(chatId);if(idx>=0)s.items.splice(idx,1);await repo().set(KEY,JSON.stringify(normalize(s)));return result;}
  async function restore(){if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return {state:"PLAN_RESTRICTED"};if(restoring)return {state:"BUSY"};if(!window.__extWppBridge)return {state:"WPP_UNAVAILABLE"};restoring=true;try{var s=await state(),done=[],failed=[];for(var i=0;i<s.items.length;i++){try{await window.__extWppBridge.invoke("Functions","FixChats",{action:"pin",pin:s.items[i]});done.push(s.items[i]);}catch(e){failed.push({chatId:s.items[i],error:e&&e.message||String(e)});}}return {state:"RESTORED",done:done,failed:failed};}finally{restoring=false;}}
  var api=Object.freeze({version:"1.0.0",storeKey:KEY,state:state,save:save,set:set,pin:pin,unpin:unpin,restore:restore});
  window.__extPinnedChatService=api;window.ExtensionCore=window.ExtensionCore||{};
  function reportRestore(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("PINNED_CHAT_RESTORE_FAILED",err);}
  var bus=window.__extEventBus;if(bus&&bus.on){bus.on("WppFullReady",function(){restore().catch(reportRestore);});bus.on("WppWebpackFullReady",function(){restore().catch(reportRestore);});}
  setTimeout(function(){restore().catch(reportRestore);},2500);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){"use strict";if(window.__extChatUtils)return;function w(){if(!window.__extWppBridge)throw new Error("O WhatsApp ainda não está pronto");return window.__extWppBridge;}async function paid(label){if(window.__extPlanGate)await window.__extPlanGate.requirePaid(label||"Ferramentas avançadas do chat");return true;}var api=Object.freeze({version:"1.1.0",pin:async function(id){await paid("Fixar conversas pela extensão");return window.__extPinnedChatService?window.__extPinnedChatService.pin(id):w().invoke("Functions","FixChats",{action:"pin",pin:id});},unpin:async function(id){await paid("Fixar conversas pela extensão");return window.__extPinnedChatService?window.__extPinnedChatService.unpin(id):w().invoke("Functions","FixChats",{action:"unpin",pin:id});},profile:function(id){return w().invoke("Utils","get-card",id);},contact:function(id){return w().invoke("Utils","getContato",id);},theme:function(theme){return w().invoke("Whatsapp","theme",theme);},block:async function(id){await paid("Bloqueio avançado de contatos");return w().invoke("BlockList","blockContact",id);},unblock:async function(id){await paid("Bloqueio avançado de contatos");return w().invoke("BlockList","unblockContact",id);},remind:async function(contactId,text,at){await paid("Lembretes do atendimento");if(!window.__extNotificationService)throw new Error("NotificationService indisponível");return window.__extNotificationService.push({type:"reminder",contactId:contactId,text:String(text||""),expiresAt:null,triggerAt:Number(at)||Date.now()});}});window.__extChatUtils=api;window.ExtensionCore=window.ExtensionCore||{};window.ExtensionCore.ChatUtils=api;})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){
  "use strict";
  if(window.__extChatCapabilities)return;
  var KEY="EXTUI:chatCapabilities";
  var DEFAULTS=Object.freeze({
    vertical:Object.freeze({agente_ia:true,encomendas:true,contact_profile:true,agendamento:true,google_calendario:true,notes:true,lembrete:true}),
    horizontal:Object.freeze({init_fluxo:true,traducao_com_IA:true,user_tabs:true,labels:true}),
    footer:Object.freeze({signature:true,chat_assistant:true,insert_name:false,replace_text:true,agendamento_footer:true})
  });
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function clone(v){return JSON.parse(JSON.stringify(v));}
  function normalize(v){try{if(typeof v==="string")v=JSON.parse(v);}catch(_){v={};}v=v&&typeof v==="object"?v:{};var out=clone(DEFAULTS);["vertical","horizontal","footer"].forEach(function(group){var src=v[group]&&typeof v[group]==="object"?v[group]:{};Object.keys(out[group]).forEach(function(k){if(Object.prototype.hasOwnProperty.call(src,k))out[group][k]=src[k]!==false;});});return {schemaVersion:3,vertical:out.vertical,horizontal:out.horizontal,footer:out.footer};}
  async function state(){return normalize(await repo().get(KEY));}
  async function save(v){v=normalize(v);await repo().set(KEY,JSON.stringify(v));return v;}
  async function setEnabled(group,name,on){var s=await state();if(!s[group]||!Object.prototype.hasOwnProperty.call(s[group],name))throw new Error("Recurso não reconhecido");s[group][name]=!!on;return save(s);}
  async function isEnabled(group,name){var s=await state();return !!(s[group]&&s[group][name]);}
  function activeChatId(){if(!window.__extWppBridge)return Promise.resolve(null);return window.__extWppBridge.invoke("Chat","getActiveChat","@").then(function(c){return String(c&&c.id&&c.id._serialized||c&&c._serialized||c&&c.id||c||"");});}
  async function getStore(key,fallback){var raw=await repo().get(key);try{if(typeof raw==="string")raw=JSON.parse(raw);}catch(_){raw=fallback;}return raw==null?fallback:raw;}
  async function setStore(key,value){await repo().set(key,JSON.stringify(value));return value;}
  function textOfSignature(v){if(v==null)return"";if(typeof v==="string")return v;return String(v.text||v.texto||v.value||v.signature||"");}
  async function invoke(name,ctx){ctx=ctx||{};if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Ferramentas avançadas do chat");var id=ctx.contactId||ctx.chatId||await activeChatId();switch(name){
    case "agente_ia":if(!window.__extAiAgentChatService)throw Object.assign(new Error("Agente IA indisponível"),{code:"AI_AGENT_UNAVAILABLE"});return window.__extAiAgentChatService.text({chatId:id,agentId:ctx.agentId||"",agent:ctx.agent||"random",text:ctx.text||ctx.prompt||ctx.task||""});
    case "encomendas":if(!window.__extOrdersService)throw new Error("Encomendas ainda não estão disponíveis. Recarregue o WhatsApp Web e tente novamente.");if(ctx.action==="create")return window.__extOrdersService.create(Object.assign({},ctx.order||ctx,{contactId:id}));if(ctx.action==="update")return window.__extOrdersService.update(ctx.orderId,ctx.patch||ctx.order||{});if(ctx.action==="remove")return window.__extOrdersService.remove(ctx.orderId);if(ctx.action==="tracking")return window.__extOrdersService.sendTracking(ctx.orderId,id);if(ctx.action==="status"&&typeof window.__extOrdersService.sendStatus==="function")return window.__extOrdersService.sendStatus(ctx.orderId,id,{status:ctx.status,message:ctx.message});return window.__extOrdersService.list(id);
    case "contact_profile":return window.__extChatUtils.profile(id);
    case "agendamento":case "agendamento_footer":if(!window.__extAgendaService)throw new Error("A Agenda ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");if(ctx.scheduleAtMs||ctx.at)return window.__extAgendaService.schedule(Object.assign({},ctx,{targetChatId:id}));return window.__extAgendaService.load();
    case "google_calendario":if(!window.__extMeetCalendarService)throw new Error("O Google Calendar ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");return ctx.open===true?window.__extMeetCalendarService.openGoogleCalendar(ctx):window.__extMeetCalendarService.googleCalendarUrl(ctx);
    case "notes":if(!window.__extContactMetadataService)throw new Error("Os dados do contato não estão disponíveis");return ctx.text?window.__extContactMetadataService.addNote(id,ctx.text):window.__extContactMetadataService.get(id);
    case "lembrete":return window.__extChatUtils.remind(id,ctx.text,ctx.at);
    case "init_fluxo":if(!window.__extFluxosStartFlowManually)throw new Error("O mecanismo de Fluxos ainda não está disponível. Recarregue o WhatsApp Web e tente novamente.");return window.__extFluxosStartFlowManually(ctx.flowId,id);
    case "traducao_com_IA":if(!window.__extAiTextTools)throw Object.assign(new Error("Ferramentas de IA indisponíveis"),{code:"AI_TEXT_TOOLS_UNAVAILABLE"});if(ctx.messageId)return window.__extAiTextTools.translateMessage(ctx.messageId,ctx);return window.__extAiTextTools.translate(ctx.text||"",ctx);
    case "user_tabs":var tabs=await getStore("EXTUI:userTabsStore",{tabs:[]});if(ctx.action==="save")return setStore("EXTUI:userTabsStore",ctx.value||ctx.tabs||{tabs:[]});return tabs;
    case "labels":if(!window.__extCrmLabelService)throw new Error("LabelService indisponível");if(ctx.action==="add")return window.__extCrmLabelService.labels.add(id,ctx.labelId||ctx.labelIds);if(ctx.action==="remove")return window.__extCrmLabelService.labels.remove(id,ctx.labelId||ctx.labelIds);if(ctx.action==="removeAll")return window.__extCrmLabelService.labels.removeAll(id);return window.__extCrmLabelService.labels.getAll();
    case "signature":var signatureStore=window.ExtensionSignatureStore;if(!signatureStore)throw Object.assign(new Error("O armazenamento de assinaturas ainda não está disponível."),{code:"SIGNATURE_STORE_UNAVAILABLE"});if(ctx.action==="save"){await signatureStore.save(ctx.value||ctx.signature||ctx);return signatureStore.list();}if(ctx.action==="remove"){await signatureStore.remove(ctx.id||ctx.signatureId);return signatureStore.list();}if(ctx.id||ctx.signatureId){var sig=await signatureStore.get(ctx.id||ctx.signatureId);if(!sig)throw Object.assign(new Error("Assinatura não encontrada"),{code:"SIGNATURE_NOT_FOUND"});var sigText=textOfSignature(sig);if(ctx.insert===true&&window.__extWppBridge)return window.__extWppBridge.invoke("Chat","setInputText",{id:id,txt:sigText});return sigText;}return signatureStore.list();
    case "chat_assistant":if(!window.__extAiTextTools)throw Object.assign(new Error("Assistente de texto indisponível"),{code:"AI_TEXT_TOOLS_UNAVAILABLE"});return window.__extAiTextTools.optimize(ctx.text||ctx.prompt||"",ctx);
    case "insert_name":var profile=await window.__extChatUtils.profile(id),nameText=String(profile&&profile.name||profile&&profile.pushname||profile&&profile.formattedName||profile&&profile.shortName||"");if(!nameText)throw Object.assign(new Error("Nome do contato indisponível"),{code:"CONTACT_NAME_UNAVAILABLE"});if(ctx.insert===true&&window.__extWppBridge)return window.__extWppBridge.invoke("Chat","setInputText",{id:id,txt:nameText});return nameText;
    case "replace_text":if(!window.__extReplacementService)throw new Error("ReplacementService indisponível");return ctx.action==="save"?window.__extReplacementService.save(ctx.value||{items:ctx.rules||[]}):window.__extReplacementService.state();
    default:throw Object.assign(new Error("Recurso não reconhecido: "+name),{code:"CAPABILITY_UNKNOWN"});
  }}
  var api=Object.freeze({version:"2.2.0",storeKey:KEY,defaults:clone(DEFAULTS),state:state,save:save,setEnabled:setEnabled,isEnabled:isEnabled,invoke:invoke});
  window.__extChatCapabilities=api;window.ExtensionCore=window.ExtensionCore||{};
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
