;
try{


(function () {
  "use strict";

  if (window.__extActionEngineBooted) return;
  window.__extActionEngineBooted = true;

  var registry = Object.create(null);
  var adapters = Object.create(null);
  var executions = new Map();
  var seq = 0;
  var SELF_BULK_NOOP_ACTIONS = Object.freeze({ composing:true, recording:true, arquivar:true, desarquivar:true, fixarChat:true, desfixarChat:true, marcarLido:true, marcarNaoLido:true, bloquear:true, desbloquear:true });

  function shouldSkipSelfBulkAction(action, context) {
    return !!(context && context.isSelfRecipient === true && action && SELF_BULK_NOOP_ACTIONS[action.type]);
  }

  function sleep(ms, signal) {
    ms = Math.max(0, Number(ms) || 0);
    if (!ms) return Promise.resolve();
    var reliable = window.__extReliableDelay;
    if (reliable && typeof reliable.wait === "function") return reliable.wait(ms, signal).catch(function (err) { if (err && err.name === "AbortError") { var e = new Error("Execução cancelada"); e.code = "ACTION_CANCELLED"; throw e; } throw err; });
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(done, ms);
      function done() { cleanup(); resolve(); }
      function abort() { cleanup(); var e = new Error("Execução cancelada"); e.code = "ACTION_CANCELLED"; reject(e); }
      function cleanup() { clearTimeout(timer); if (signal && signal.removeEventListener) signal.removeEventListener("abort", abort); }
      if (signal && signal.aborted) return abort();
      if (signal && signal.addEventListener) signal.addEventListener("abort", abort, { once: true });
    });
  }

  function seconds(value, fallback) {
    var n = Number(value);
    return isFinite(n) && n >= 0 ? n : (fallback || 0);
  }

  function register(type, defaults, handler, meta) {
    registry[type] = Object.assign({
      type: type,
      defaults: defaults || {},
      group: meta && meta.group || "generic",
      dependency: meta && meta.dependency || null,
      handler: handler
    }, meta || {});
  }

  function requireBridge() {
    var bridge = window.__extWppBridge;
    if (!bridge || typeof bridge.invoke !== "function") {
      var e = new Error("O WhatsApp ainda não está pronto"); e.code = "WPP_BRIDGE_UNAVAILABLE"; throw e;
    }
    return bridge;
  }

  function idempotentChatState(promise, acceptedCodes) {
    return Promise.resolve(promise).catch(function (err) {
      var code=String(err&&err.code||"");
      if (acceptedCodes && acceptedCodes.indexOf(code)>=0) return { skipped:true, reason:"already-in-target-state", code:code };
      throw err;
    });
  }

  function requireAdapter(name) {
    var a = adapters[name];
    if (!a) {
      var e = new Error("Dependência do ActionEngine indisponível: " + name);
      e.code = "DEPENDENCY_UNAVAILABLE";
      e.dependency = name;
      throw e;
    }
    return a;
  }

  function registerAdapter(name, adapter) {
    if (!name || !adapter) throw new TypeError("registerAdapter(name, adapter)");
    adapters[name] = adapter;
    return function () { if (adapters[name] === adapter) delete adapters[name]; };
  }

  function normalizeAction(action, index) {
    if (typeof action === "string") action = { type: action, properties: {} };
    action = action && typeof action === "object" ? action : {};
    var type = String(action.type || action.action || "");
    var def = registry[type];
    var props = action.properties && typeof action.properties === "object" ? action.properties : action;
    var merged = Object.assign({}, def && def.defaults || {}, props || {});
    delete merged.type; delete merged.action; delete merged.properties;
    return { id: action.id || "action-" + index, type: type, properties: merged };
  }

  function replaceVarsInString(value, vars) {
    if(window.__extVariableResolver&&typeof window.__extVariableResolver.resolveString==="function")return window.__extVariableResolver.resolveString(value,vars||{});
    var output = String(value).replace(/\{\{\s*([^{}]+?)\s*\}\}/g, function (_, key) { key=String(key).trim(); return Object.prototype.hasOwnProperty.call(vars,key)?String(vars[key]==null?"":vars[key]):_; });
    output=output.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(all,prefix,key){return prefix+(Object.prototype.hasOwnProperty.call(vars,key)?String(vars[key]==null?"":vars[key]):"{"+key+"}");});
    Object.keys(vars || {}).sort(function (a,b) { return b.length-a.length; }).forEach(function (key) { if (!key || /[{}\s]/.test(key)) return; var token = "#" + key; if (output.indexOf(token) >= 0) output = output.split(token).join(String(vars[key] == null ? "" : vars[key])); });
    return output;
  }

  function activeLanguage(ctx) {
    var raw = String(ctx && (ctx.language || ctx.lang) || "").trim().toLowerCase();
    if (!raw) {
      try {
        var storage = window && window.localStorage;
        if (storage && typeof storage.getItem === "function") raw=String(storage.getItem("activeLanguage")||"").toLowerCase();
      } catch (_) {}
    }
    if (raw.indexOf("es")===0) return "es";
    if (raw.indexOf("en")===0) return "en";
    return "pt";
  }
  function dayPeriod(language, now) {
    var h=(now||new Date()).getHours();
    if (language==="en") return h<12?"Good morning":(h<18?"Good afternoon":"Good evening");
    if (language==="es") return h<12?"Buenos días":(h<19?"Buenas tardes":"Buenas noches");
    return h<12?"Bom dia":(h<18?"Boa tarde":"Boa noite");
  }
  function greeting(language, now) {
    var period=dayPeriod(language,now);
    if(language==="en") return period+", how are you?";
    if(language==="es") return period+", ¿cómo estás?";
    return period+", tudo bem?";
  }
  function scalarContactFields(contact, vars) {
    if(!contact || typeof contact!=="object") return;
    Object.keys(contact).forEach(function(k){
      var v=contact[k];
      if(v==null || (typeof v!=="string" && typeof v!=="number" && typeof v!=="boolean")) return;
      if(!Object.prototype.hasOwnProperty.call(vars,k)) vars[k]=v;
    });
  }
  async function buildVariables(context, needsSystemFields) {
    context=context||{};
    if(needsSystemFields&&window.__extVariableResolver&&typeof window.__extVariableResolver.buildForChat==="function")return window.__extVariableResolver.buildForChat(context.contactId||context.chatId||context.remetente||"",context);
    var vars=Object.assign({},context.variables||{});
    var rawId=context.contactId||context.chatId||context.remetente||"";
    if(rawId && rawId._serialized) rawId=rawId._serialized;
    rawId=String(rawId||"");
    var contact=context.contact && typeof context.contact==="object" ? context.contact : null;
    if(!contact && needsSystemFields && rawId && window.__extWppBridge && typeof window.__extWppBridge.invoke==="function") {
      try { contact=await window.__extWppBridge.invoke("Contact","get",{id:rawId}); } catch (_) {}
    }
    scalarContactFields(contact,vars);
    var contactMeta=null;
    if(needsSystemFields && rawId && window.__extContactMetadataService && typeof window.__extContactMetadataService.get==="function") {
      try { contactMeta=await window.__extContactMetadataService.get(rawId); } catch (_) {}
    }
    scalarContactFields(contactMeta,vars);
    var name=String(context.contactName||context.name||vars.nome||vars.name||contactMeta && (contactMeta.localAlias||contactMeta.name)||contact && (contact.name||contact.pushname||contact.formattedName||contact.notifyName)||"").trim();
    var language=activeLanguage(Object.assign({},context,{language:context.language||contactMeta&&contactMeta.language||""}));
    if(name){ vars.nome=name; vars.nomes=name; vars.primeiroNome=name.split(/\s+/)[0]||name; vars.primeiro_nome=vars.primeiroNome; vars.first_name=vars.primeiroNome; vars.fn=vars.primeiroNome; vars.nome_completo=name; vars.full_name=name; }
    if(rawId) vars.numero=rawId.replace(/@(c|g)\.us$/i,"").replace(/\D+/g,"") || rawId.replace(/@(c|g)\.us$/i,"");
    if(!Object.prototype.hasOwnProperty.call(vars,"periodo-dia")) vars["periodo-dia"]=dayPeriod(language);
    if(!Object.prototype.hasOwnProperty.call(vars,"saudação")) vars["saudação"]=greeting(language);
    if(!Object.prototype.hasOwnProperty.call(vars,"saudacao")) vars.saudacao=vars["saudação"];
    return vars;
  }

  function resolvePlaceholders(value, vars) {
    vars = vars || {};
    if (typeof value === "string") return replaceVarsInString(value, vars);
    if (Array.isArray(value)) return value.map(function (v) { return resolvePlaceholders(v, vars); });
    if (value && typeof value === "object") {
      var out = {};
      Object.keys(value).forEach(function (k) { out[k] = resolvePlaceholders(value[k], vars); });
      return out;
    }
    return value;
  }

  function contactId(ctx, p) { return p.id || p.chatId || p.contactId || ctx.contactId || ctx.remetente || ""; }
  function messageText(p) { return p.mensagem != null ? p.mensagem : (p.msg != null ? p.msg : (p.text != null ? p.text : "")); }

  async function resolveMediaRaw(p, type, ctx) {
    if (p.base64) return p.base64;
    var mediaRef = p.mediaId || p.itemId || p.contentId;
    if (!mediaRef) return p.base64 || "";
    var a = adapters.MediaResolver;
    if (!a || typeof a.resolveBase64 !== "function") {
      var e = new Error("Arquivo de imagem/vídeo referenciado exige MediaResolver"); e.code = "DEPENDENCY_UNAVAILABLE"; e.dependency = "MediaResolver"; throw e;
    }
    return a.resolveBase64(mediaRef, type, ctx);
  }
  async function prepareMediaRaw(value) {
    if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(value)) value=await window.ExtensionMediaStore.portable(value);
    if (typeof Blob!=="undefined" && value instanceof Blob) value=await new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(String(r.result||""));};r.onerror=function(){reject(r.error||new Error("Falha ao preparar mídia."));};r.readAsDataURL(value);});
    if (typeof value==="string" && value.indexOf("blob:")===0) {var response=await fetch(value);if(!response.ok)throw new Error("Falha ao ler mídia temporária.");var blob=await response.blob();value=await new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(String(r.result||""));};r.onerror=function(){reject(r.error||new Error("Falha ao preparar mídia."));};r.readAsDataURL(blob);});}
    return value;
  }
  async function maybeResolveMedia(p, type, ctx) { return prepareMediaRaw(await resolveMediaRaw(p,type,ctx)); }

  async function preSend(p, ctx) {
    var id = contactId(ctx, p);
    var waitSeconds = seconds(p.aguarde, 0);
    if (waitSeconds) await sleep(waitSeconds * 1000, ctx.cancellationSignal);
    return id;
  }

  function safeChatSend(method, payload, ctx, presenceKind, presenceSeconds) {
    var bridge = requireBridge();
    var safety = window.__extSendSafetyManager;
    var recipient = payload && (payload.id || payload.chatId || payload.contactId) || contactId(ctx || {}, payload || {});
    var task = async function () {
      if (presenceKind && presenceSeconds > 0 && !(ctx && ctx.isSelfRecipient === true)) {
        await bridge.invoke("Chat", presenceKind === "recording" ? "markIsRecording" : "markIsComposing", { id:recipient, timer:Math.round(presenceSeconds*1000) });
      }
      return bridge.invoke("Chat", method, payload);
    };
    if (!safety || typeof safety.enqueue !== "function") {
      var safetyErr = new Error("Proteção de Envio indisponível; envio bloqueado por segurança.");
      safetyErr.code = "SEND_SAFETY_UNAVAILABLE";
      return Promise.reject(safetyErr);
    }
    var interactive=!!(ctx && ctx.interactive);
    if(!interactive&&!(ctx&&ctx.__extExecutionIdStable===true)){
      var identityErr=new Error("Envios automáticos exigem um executionId estável fornecido pela automação.");
      identityErr.code="SEND_EFFECT_ID_REQUIRED";
      return Promise.reject(identityErr);
    }
    var effectId=!interactive&&ctx&&ctx.executionId&&ctx.__extCurrentActionId?("action|"+String(ctx.executionId)+"|"+String(ctx.__extCurrentActionId)):null;
    var queued = safety.enqueue({
      method:method,
      source:ctx && ctx.source || "action-engine",
      context:ctx || {},
      recipient:recipient,
      campaignId:ctx && ctx.campaignId || null,
      enforceRecipientCooldown:!!(ctx && ctx.enforceRecipientCooldown),
      interactive:interactive,
      effectId:effectId,
      effectPayload:payload,
      signal:ctx && ctx.cancellationSignal || null
    }, task);
    return Promise.resolve(queued).finally(function () {
      try { if (window.ExtensionMediaStore && window.ExtensionMediaStore.isOwnedUrl(payload && payload.base64)) window.ExtensionMediaStore.releaseOwnedUrl(payload.base64); } catch (_) {}
    });
  }

  register("txt", { mensagem: "", aguarde: 5, composing: 5 }, async function (p, ctx) {
    var id = await preSend(p, ctx);
    return safeChatSend("sendTxt", { id: id, msg: messageText(p), mentionedList: p.mentionedList }, ctx, "composing", seconds(p.composing, 0));
  }, { group: "message" });

  register("image", { mensagem: "", aguarde: 2, composing: 5 }, async function (p, ctx) {
    var id = await preSend(p, ctx);
    return safeChatSend("sendImage", { id: id, base64: await maybeResolveMedia(p,"image",ctx), msg: messageText(p), mentionedList: p.mentionedList, isViewOnce: !!p.isViewOnce }, ctx, "composing", seconds(p.composing, 0));
  }, { group: "message" });

  register("video", { mensagem: "", aguarde: 2, composing: 5 }, async function (p, ctx) {
    var id = await preSend(p, ctx);
    return safeChatSend("sendVideo", { id: id, base64: await maybeResolveMedia(p,"video",ctx), msg: messageText(p), mentionedList: p.mentionedList, microVideo: !!p.microVideo, isViewOnce: !!p.isViewOnce }, ctx, "composing", seconds(p.composing, 0));
  }, { group: "message" });

  register("audio", { base64: "", composing: 5 }, async function (p, ctx) {
    var id = await preSend(p, ctx);
    var isPtt = p.isPtt !== false;
    var audioRaw = await resolveMediaRaw(p,"audio",ctx);
    if (isPtt) {
      if (typeof window.__extNormalizeAudioReference !== "function") throw new Error("O recurso que prepara notas de voz não está disponível. Recarregue o WhatsApp Web e tente novamente.");
      audioRaw = (await window.__extNormalizeAudioReference(audioRaw,{fileName:p.fileName||p.name||"audio",mimeType:p.mimeType||"",bitrate:32000})).ref;
    }
    var audioBase64 = await prepareMediaRaw(audioRaw);
    return safeChatSend("sendAudio", { id: id, base64: audioBase64, isPtt: isPtt, isViewOnce: !!p.isViewOnce, mimeType:isPtt?"audio/ogg":(p.mimeType||undefined), name:p.fileName||p.name||undefined }, ctx, "recording", seconds(p.composing, 0));
  }, { group: "message" });

  register("doc", {}, async function (p, ctx) {
    var id = contactId(ctx,p);
    return safeChatSend("sendDoc", { id: id, base64: await maybeResolveMedia(p,"document",ctx), name: p.base64Name || p.name || p.fileName || "documento" }, ctx);
  }, { group: "message" });

  register("respostaRapida", { respostaRapidaID: null }, async function (p, ctx) {
    var a = requireAdapter("QuickReplyResolver");
    var nested = await a.resolve(p.respostaRapidaID, ctx);
    var nestedId=String(ctx&&ctx.executionId||"quick")+":quick:"+String(ctx&&ctx.__extCurrentActionId||"action")+":"+String(p.respostaRapidaID||"reply");
    var nestedResult=await execute(nested || [], Object.assign({}, ctx, { source: "quick-reply", parentExecutionId: ctx.executionId, executionId:nestedId }));
    if(!nestedResult||nestedResult.status!=="success"){
      var nestedErr=new Error(nestedResult&&nestedResult.error&&nestedResult.error.message||"A Resposta Rápida aninhada não pôde ser concluída.");
      nestedErr.code=nestedResult&&nestedResult.error&&nestedResult.error.code||"QUICK_REPLY_ACTION_FAILED";
      nestedErr.effectDigest=nestedResult&&nestedResult.error&&nestedResult.error.effectDigest||null;
      nestedErr.remoteEffectSucceeded=nestedResult&&nestedResult.error&&nestedResult.error.remoteEffectSucceeded===true;
      throw nestedErr;
    }
    return nestedResult;
  }, { group: "composition", dependency: null });

  register("pix", {}, async function (p, ctx) {
    return safeChatSend("sendPixKeyMessage", { id: contactId(ctx,p), keyType: p.keyType || p.tipo, name: p.name || p.nome, key: p.key || p.chave }, ctx);
  }, { group: "message" });

  register("groupInvite", {}, async function (p, ctx) {
    return safeChatSend("sendGroupInviteMessage", { id: contactId(ctx,p), groupID: p.groupID || p.groupId }, ctx);
  }, { group: "message" });

  register("contact", {}, async function (p, ctx) {
    return safeChatSend("sendContact", { id: contactId(ctx,p), phone: p.phone || p.contactId || p.telefone, name: p.name || p.nome || "" }, ctx);
  }, { group: "message" });

  register("linkPreview", {}, async function (p, ctx) {
    return safeChatSend("linkPreview", { id: contactId(ctx,p), link: p.link || p.url, title: p.title || p.titulo || "", description: p.description || p.descricao || "" }, ctx);
  }, { group: "message" });

  register("sticker", {}, async function (p, ctx) {
    return safeChatSend("sticker", { id: contactId(ctx,p), base64: await maybeResolveMedia(p,"sticker",ctx) }, ctx);
  }, { group: "message" });

  register("list", { composing: 5, aguarde: 5, title: "", description: "", footer: "", buttonText: "", sections: [] }, async function (p, ctx) {
    var id = await preSend(p, ctx);

    var options = p.options || { title: p.title, description: p.description, footer: p.footer, buttonText: p.buttonText, sections: p.sections || [] };
    return safeChatSend("sendListMessage", { id: id, options: options }, ctx, "composing", seconds(p.composing, 0));
  }, { group: "message" });

  ["addCRM","removeCRM","removeAllCRM"].forEach(function (type) {
    register(type, type === "removeAllCRM" ? {} : { crmID: "abas", abaID: null }, async function (p, ctx) {
      var a = requireAdapter("CrmActionAdapter");
      if (type === "addCRM") return a.add(contactId(ctx,p), p, ctx);
      if (type === "removeCRM") return a.remove(contactId(ctx,p), p, ctx);
      return a.removeAll(contactId(ctx,p), p, ctx);
    }, { group: "crm", dependency: null });
  });

  ["addLabel","removeLabel","removeAllLabel"].forEach(function (type) {
    register(type, type === "removeAllLabel" ? {} : { labelID: null }, async function (p, ctx) {
      var a = requireAdapter("LabelActionAdapter");
      if (type === "addLabel") return a.add(contactId(ctx,p), p.labelID || p.labelId, ctx);
      if (type === "removeLabel") return a.remove(contactId(ctx,p), p.labelID || p.labelId, ctx);
      return a.removeAll(contactId(ctx,p), ctx);
    }, { group: "labels", dependency: null });
  });

  register("timer", { segundos: 10 }, async function (p, ctx) { var waitedMs=Math.round(seconds(p.segundos,10)*1000); await sleep(waitedMs, ctx.cancellationSignal); return { waitedMs:waitedMs }; }, { group: "timing" });
  register("composing", { segundos: 10 }, function (p, ctx) { return requireBridge().invoke("Chat","markIsComposing",{ id: contactId(ctx,p), timer: Math.round(seconds(p.segundos,10)*1000) }); }, { group: "presence" });
  register("recording", { segundos: 10 }, function (p, ctx) { return requireBridge().invoke("Chat","markIsRecording",{ id: contactId(ctx,p), timer: Math.round(seconds(p.segundos,10)*1000) }); }, { group: "presence" });
  register("arquivar", {}, function (p,ctx) { return idempotentChatState(requireBridge().invoke("Chat","arquivar",contactId(ctx,p)),["archive_error"]); }, { group:"utility" });
  register("desarquivar", {}, function (p,ctx) { return idempotentChatState(requireBridge().invoke("Chat","desarquivar",contactId(ctx,p)),["unarchive_error"]); }, { group:"utility" });
  register("fixarChat", {}, function (p,ctx) { var id=contactId(ctx,p),utils=window.ExtensionCore&&window.ExtensionCore.ChatUtils,op=utils&&typeof utils.pin==="function"?utils.pin(id):requireBridge().invoke("Functions","FixChats",{ action:"pin", pin:id });return idempotentChatState(op,["pin_error"]); }, { group:"utility" });
  register("desfixarChat", {}, function (p,ctx) { var id=contactId(ctx,p),utils=window.ExtensionCore&&window.ExtensionCore.ChatUtils,op=utils&&typeof utils.unpin==="function"?utils.unpin(id):requireBridge().invoke("Functions","FixChats",{ action:"unpin", pin:id });return idempotentChatState(op,["unpin_error"]); }, { group:"utility" });
  register("marcarLido", {}, function (p,ctx) { return requireBridge().invoke("Chat","markIsRead",{ id:contactId(ctx,p) }); }, { group:"utility" });
  register("marcarNaoLido", {}, function (p,ctx) { return requireBridge().invoke("Chat","markIsUnread",{ id:contactId(ctx,p) }); }, { group:"utility" });
  register("bloquear", {}, function (p,ctx) { return requireBridge().invoke("BlockList","blockContact",contactId(ctx,p)); }, { group:"utility" });
  register("desbloquear", {}, function (p,ctx) { return requireBridge().invoke("BlockList","unblockContact",contactId(ctx,p)); }, { group:"utility" });

  function createMonitor(id, actions, ctx) {
    return {
      id: id,
      userID: ctx.userID || ctx.contactId || ctx.remetente || null,
      sendAction: "Actived",
      remetente: ctx.remetente || ctx.contactId || null,
      actionsTam: actions.length,
      actionIndice: -1,
      activeAction: null,
      status: "running",
      source: ctx.source || "unknown",
      startedAt: Date.now(),
      updatedAt: Date.now()
    };
  }

  async function waitIfPaused(record) {
    while (record.control.paused && !record.control.cancelled) await sleep(50, record.context.cancellationSignal);
  }

  async function notifyActionProgress(context, event) {
    if (!context || typeof context.onActionProgress !== "function") return;
    try { await context.onActionProgress(event); } catch (_) {}
  }

  async function execute(actions, context) {
    context = Object.assign({ source: "unknown", variables: {} }, context || {});
    actions = Array.isArray(actions) ? actions.map(normalizeAction) : [];
    if(window.__extPlanGate){
      var actionPlan=await window.__extPlanGate.requireActive();
      if(actionPlan.isFree){
        var freeActionTypes={txt:true,audio:true,doc:true,image:true,video:true},freeAgenda=context.source==="agenda"&&actions.length>0&&actions.every(function(action){return !!freeActionTypes[action.type];});
        if(!freeAgenda){var planErr=new Error("Esta automação faz parte do plano Pro da extensão.");planErr.code="EXTAPP_PLAN_UPGRADE_REQUIRED";throw planErr;}
      }
    }
    var needsSystemFields = actions.some(function(action){
      try { var source=JSON.stringify(action.properties||{}); return window.__extVariableResolver&&typeof window.__extVariableResolver.needsResolution==="function"?window.__extVariableResolver.needsResolution(source):/(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|nome|nome_extapp|nome_whatsapp|numero|email|empresa|cidade|estado|endereco|cep|idioma|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i.test(source); } catch (_) { return false; }
    });
    context.variables = await buildVariables(context, needsSystemFields);
    var providedExecutionId = typeof context.executionId === "string" && context.executionId.trim() ? context.executionId.trim() : "";
    var stableExecutionId = context.__extExecutionIdStable === false ? false : !!providedExecutionId;
    var id = providedExecutionId || "extui-act-" + Date.now().toString(36) + "-" + (++seq).toString(36);
    var monitor = createMonitor(id, actions, context);
    var record = { id: id, monitor: monitor, context: Object.assign({}, context, { executionId: id, __extExecutionIdStable: stableExecutionId }), control: { paused:false, cancelled:false }, results: [] };
    executions.set(id, record);

    try {
      for (var i=0; i<actions.length; i++) {
        if (record.control.cancelled || (record.context.cancellationSignal && record.context.cancellationSignal.aborted)) {
          monitor.status = "cancelled"; monitor.sendAction = "Cancelled"; return { status:"cancelled", executionId:id, monitor:monitor, results:record.results };
        }
        await waitIfPaused(record);
        if (record.control.cancelled) { monitor.status="cancelled"; monitor.sendAction="Cancelled"; return { status:"cancelled", executionId:id, monitor:monitor, results:record.results }; }
        var action = actions[i];
        var def = registry[action.type];
        monitor.actionIndice = i;
        monitor.activeAction = action.type;
        monitor.updatedAt = Date.now();
        if (!def || typeof def.handler !== "function") {
          var unknown = new Error("Tipo de ação desconhecido: " + action.type); unknown.code="UNKNOWN_ACTION_TYPE"; throw unknown;
        }
        record.context.__extCurrentActionId=String(action.id||("action-"+i));
        record.context.__extCurrentActionIndex=i;
        var props = resolvePlaceholders(action.properties, record.context.variables || {});
        if (shouldSkipSelfBulkAction(action, record.context)) {
          var skippedResult={ skipped:true, reason:"self-chat-noop", actionType:action.type };
          record.results.push({ id:action.id, type:action.type, result:skippedResult });
          await notifyActionProgress(record.context,{ status:"success", skipped:true, index:i, actionId:String(action.id||("action-"+i)), type:action.type });
          continue;
        }
        var result = await def.handler(props, record.context, action);
        record.results.push({ id: action.id, type: action.type, result: result === undefined ? null : result });
        await notifyActionProgress(record.context,{ status:"success", index:i, actionId:String(action.id||("action-"+i)), type:action.type });
      }
      monitor.status = "success"; monitor.sendAction = "Completed"; monitor.activeAction = null; monitor.updatedAt = Date.now();
      return { status:"success", executionId:id, monitor:monitor, results:record.results };
    } catch (err) {
      if (err && err.code === "ACTION_CANCELLED") {
        monitor.status="cancelled"; monitor.sendAction="Cancelled";
        return { status:"cancelled", executionId:id, monitor:monitor, results:record.results };
      }
      monitor.status="error"; monitor.sendAction="Error"; monitor.error = err && err.message ? err.message : String(err); monitor.errorCode = err && err.code || "ACTION_EXECUTION_ERROR"; monitor.updatedAt=Date.now();
      if(monitor.actionIndice>=0) await notifyActionProgress(record.context,{ status:"error", index:monitor.actionIndice, actionId:actions[monitor.actionIndice]&&String(actions[monitor.actionIndice].id||("action-"+monitor.actionIndice)), type:monitor.activeAction, error:{ code:monitor.errorCode, message:monitor.error } });
      return { status:"error", executionId:id, monitor:monitor, results:record.results, error:{ code:monitor.errorCode, message:monitor.error, dependency:err && err.dependency || null, effectDigest:err && err.effectDigest || null, remoteEffectSucceeded:err && err.remoteEffectSucceeded===true } };
    } finally {
      record.finishedAt = Date.now();
      setTimeout(function () { if(executions.get(id)===record)executions.delete(id); }, 60000);
    }
  }

  function pause(id) { var r=executions.get(id); if(!r) return "execution_not_found"; r.control.paused=true; r.monitor.status="paused"; r.monitor.sendAction="Paused"; return "paused"; }
  function resume(id) { var r=executions.get(id); if(!r) return "execution_not_found"; r.control.paused=false; r.monitor.status="running"; r.monitor.sendAction="Actived"; return "success"; }
  function cancel(id) { var r=executions.get(id); if(!r) return "execution_not_found"; r.control.cancelled=true; r.monitor.status="cancelled"; r.monitor.sendAction="Cancelled"; return "cancelled"; }
  function getExecution(id) { var r=executions.get(id); return r ? { id:r.id, monitor:Object.assign({},r.monitor), control:Object.assign({},r.control) } : null; }

  function capabilities() {
    return Object.keys(registry).map(function (type) {
      var d=registry[type], dependency=d.dependency||null, adapterName=dependency?String(dependency).split(" /")[0].trim():"";
      return { type:type, group:d.group, available:!dependency||!!adapters[adapterName], dependency:dependency, defaults:Object.assign({},d.defaults) };
    });
  }

  var api = Object.freeze({
    version: "1.0.0",
    execute: execute,
    pause: pause,
    resume: resume,
    cancel: cancel,
    getExecution: getExecution,
    capabilities: capabilities,
    registerAdapter: registerAdapter,
    resolvePlaceholders: resolvePlaceholders,
    buildVariables: buildVariables,
    normalizeAction: normalizeAction,
    constants: { SUCCESS:"success", ERROR:"error", CANCELLED:"cancelled", PAUSED:"paused", NOT_FOUND:"execution_not_found" }
  });

  window.__extActionExecutor = api;
  window.ExtensionCore = window.ExtensionCore || {};
  window.ExtensionCore.ActionExecutor = api;
  try { window.dispatchEvent(new CustomEvent("ext:action-executor-ready")); } catch (_) {}
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
