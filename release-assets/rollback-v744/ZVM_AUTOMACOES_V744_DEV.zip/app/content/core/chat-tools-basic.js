;
try{

(function(){
  "use strict";
  if(window.__extReplacementService)return;
  var KEY="EXTUI:replacementStore", guard=false, timer=null;
  async function paid(){if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Substituições automáticas de texto");return true;}
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function parse(v){try{if(typeof v==="string")v=JSON.parse(v);return v&&typeof v==="object"&&!Array.isArray(v)?v:{};}catch(_){return {};}}
  function normalizeItem(x,i){x=x&&typeof x==="object"?x:{};return {id:String(x.id||("replacement-"+i)),shortcut:String(x.shortcut!=null?x.shortcut:(x.key!=null?x.key:(x.from||""))),replacement:String(x.replacement!=null?x.replacement:(x.value!=null?x.value:(x.to||""))),caseSensitive:x.caseSensitive===true,wholeWord:x.wholeWord===true,enabled:x.enabled!==false};}
  function normalize(v){v=parse(v);var items=Array.isArray(v.items)?v.items.map(normalizeItem).filter(function(x){return x.shortcut;}):[];return {schemaVersion:1,isEnabled:v.isEnabled!==false,items:items};}
  async function state(){await paid();return normalize(await repo().get(KEY));}
  async function save(v){await paid();v=normalize(v);await repo().set(KEY,JSON.stringify(v));return v;}
  async function configure(patch){await paid();var s=await state();Object.assign(s,patch||{});return save(s);}
  function escRe(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,"\\$&");}
  function transform(text,s){text=String(text==null?"":text);s=normalize(s);if(!s.isEnabled)return text;s.items.forEach(function(item){if(!item.enabled||!item.shortcut)return;var flags=item.caseSensitive?"g":"gi",pattern=escRe(item.shortcut);if(item.wholeWord)pattern="\\b"+pattern+"\\b";try{text=text.replace(new RegExp(pattern,flags),function(){return item.replacement;});}catch(_){}});return text;}
  function composerFromEventTarget(target){var el=target&&target.nodeType===1?target:target&&target.parentElement;return el&&el.closest?el.closest('#main footer [contenteditable="true"], #main [data-testid="conversation-compose-box-input"], #main [contenteditable="true"][role="textbox"]'):null;}
  async function getActiveChatId(){if(!window.__extWppBridge)return null;try{var c=await window.__extWppBridge.invoke("Chat","getActiveChat","@");return String(c&&c.id&&c.id._serialized||c&&c._serialized||c&&c.id||c||"");}catch(_){return null;}}
  async function replaceComposer(el){if(guard||!el||!el.isConnected)return;if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return;var s=await state();if(!s.isEnabled||!s.items.length)return;var current=String(el.innerText!=null?el.innerText:el.textContent||""),next=transform(current,s);if(next===current)return;var id=await getActiveChatId();if(!id||!window.__extWppBridge)return;guard=true;try{await window.__extWppBridge.invoke("Chat","setInputText",{id:id,txt:next});}finally{setTimeout(function(){guard=false;},0);}}
  document.addEventListener("input",function(ev){var el=composerFromEventTarget(ev.target);if(!el||guard)return;clearTimeout(timer);timer=setTimeout(function(){replaceComposer(el).catch(function(err){});},70);},true);
  var api=Object.freeze({version:"1.0.0",storeKey:KEY,state:state,save:save,configure:configure,transform:transform,replaceComposer:replaceComposer});
  window.__extReplacementService=api;window.ExtensionCore=window.ExtensionCore||{};
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{
(function(root){
  "use strict";
  if(root.__extTrackingService)return;
  var KEY="EXTUI:trackingStore",FLAG="__extTrackingBridge",pending=new Map(),seq=0,history=[];
  var EVENT_MAP=Object.freeze({MessageReceived:"Lead",CrmContactMoved:"Lead",ScheduleSent:"Contact",AutoServiceTriggered:"Contact"});
  function repo(){if(!root.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return root.ExtensionStorage;}
  function parse(v){try{if(typeof v==="string")v=JSON.parse(v);return v&&typeof v==="object"?v:{};}catch(_){return {};}}
  function safeConfig(c){c=c&&typeof c==="object"?c:{};return{enabled:c.enabled===true,pixelId:String(c.pixelId||"").replace(/\D/g,"").slice(0,32),apiVersion:/^v\d+\.\d+$/.test(String(c.apiVersion||""))?String(c.apiVersion):"v23.0",testEventCode:String(c.testEventCode||"").trim().slice(0,100),eventMap:Object.assign({},EVENT_MAP,c.eventMap&&typeof c.eventMap==="object"?c.eventMap:{}),actionSource:String(c.actionSource||"other").slice(0,32)};}
  async function config(){return safeConfig(parse(await repo().get(KEY)));}
  async function configure(){throw Object.assign(new Error("A configuração da Meta deve ser alterada pelo Painel de Controle."),{code:"TRACKING_CONFIG_REQUIRES_DASHBOARD"});}
  function request(type,payload){return new Promise(function(resolve,reject){
    if(!root.chrome||!chrome.runtime||typeof chrome.runtime.sendMessage!=="function"){reject(Object.assign(new Error("A extensão não conseguiu iniciar este recurso."),{code:"TRACKING_RUNTIME_UNAVAILABLE"}));return;}
    var map={send:"EXTUI_TRACKING_SEND",secretStatus:"EXTUI_TRACKING_SECRET_STATUS"},runtimeType=map[type];
    if(!runtimeType){reject(Object.assign(new Error("Operação Meta não permitida neste contexto."),{code:"TRACKING_SECRET_REQUIRES_DASHBOARD"}));return;}
    var msg={type:runtimeType};if(type==="send")msg.event=payload||{};
    try{chrome.runtime.sendMessage(msg,function(res){var last=chrome.runtime.lastError;if(last){reject(Object.assign(new Error(last.message||"A conexão com a Meta falhou."),{code:"TRACKING_RUNTIME_ERROR"}));return;}if(!res||res.ok!==true){var e=new Error(res&&((res.error&&res.error.message)||res.userMessage)||"Falha na integração Meta.");e.code=res&&(res.errorCode||(res.error&&res.error.code))||"TRACKING_ERROR";reject(e);return;}resolve(res.result);});}catch(err){reject(Object.assign(new Error(err&&err.message||String(err)),{code:"TRACKING_RUNTIME_ERROR"}));}
  });}
  async function setAccessToken(){throw Object.assign(new Error("As chaves de acesso da Meta devem ser alteradas pelo Painel de Controle."),{code:"TRACKING_SECRET_REQUIRES_DASHBOARD"});}
  function removeAccessToken(){return Promise.reject(Object.assign(new Error("As chaves de acesso da Meta devem ser alteradas pelo Painel de Controle."),{code:"TRACKING_SECRET_REQUIRES_DASHBOARD"}));}function secretStatus(){return request("secretStatus");}
  async function track(eventName,payload,options){options=options||{};var cfg=await config(),eventPayload=payload&&typeof payload==="object"?payload:{},rec={event:String(eventName||""),timestamp:Date.now(),status:"recorded"};history.push(rec);if(history.length>100)history.shift();if(root.__extPlanGate&&await root.__extPlanGate.isRestricted()){rec.status="ignored";rec.reason="plan_restricted";return rec;}if(cfg.enabled!==true&&!options.force)return rec;if(!cfg.pixelId)throw Object.assign(new Error("Informe o código do Pixel da Meta antes de enviar eventos."),{code:"TRACKING_PIXEL_REQUIRED"});var mapped=cfg.eventMap[rec.event]||rec.event;if(!mapped)return rec;try{rec.result=await request("send",{eventName:mapped,eventId:String(options.eventId||("extapp-"+Date.now()+"-"+Math.random().toString(36).slice(2))),payload:eventPayload});rec.status="sent";}catch(e){rec.status="error";rec.error=e.code||e.message;throw e;}return rec;}
  var api=Object.freeze({version:"2.0.0",config:config,configure:configure,setAccessToken:setAccessToken,removeAccessToken:removeAccessToken,secretStatus:secretStatus,track:track,history:function(){return history.slice();},defaultEventMap:Object.assign({},EVENT_MAP)});root.__extTrackingService=api;root.ExtensionCore=root.ExtensionCore||{};
  var bus=root.__extEventBus;if(bus&&bus.on)Object.keys(EVENT_MAP).forEach(function(ev){bus.on(ev,function(p){track(ev,p).catch(function(err){if(root.__extReportRuntimeError)root.__extReportRuntimeError("TRACKING_EVENT_SEND_FAILED",err);});});});
})(typeof window!=="undefined"?window:self);
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
try{

(function(){
  "use strict";
  if(window.__extMeetCalendarService)return;
  var KEY="EXTUI:meetCalendarStore";
  async function paid(){if(window.__extPlanGate)await window.__extPlanGate.requirePaid("Agenda Google e Meet avançados");return true;}
  function repo(){if(!window.ExtensionStorage)throw new Error("Os dados da extensão não estão disponíveis no momento");return window.ExtensionStorage;}
  function parse(v){if(v==null||v==="")return{schemaVersion:2,events:[]};var parsed=v;if(typeof v==="string"){try{parsed=JSON.parse(v);}catch(err){err.code="MEET_CALENDAR_STORE_CORRUPT";throw err;}}if(!parsed||typeof parsed!=="object"||Array.isArray(parsed))throw Object.assign(new Error("Os eventos de Agenda/Meet estão inválidos e não serão sobrescritos."),{code:"MEET_CALENDAR_STORE_CORRUPT"});var events=parsed.events==null?[]:parsed.events;if(!Array.isArray(events)||events.some(function(item){return !item||typeof item!=="object"||Array.isArray(item);}))throw Object.assign(new Error("Os eventos de Agenda/Meet estão inválidos e não serão sobrescritos."),{code:"MEET_CALENDAR_STORE_CORRUPT"});return {schemaVersion:2,events:events};}
  async function state(){await paid();return parse(await repo().get(KEY));}
  async function save(s){s=parse(s);await repo().set(KEY,JSON.stringify(s));return s;}
  function uid(){return "meet-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8);}
  function asMs(v){if(v==null||v==="")return NaN;var n=Number(v);if(Number.isFinite(n))return n;var d=Date.parse(String(v));return Number.isFinite(d)?d:NaN;}
  function normalizeEvent(input,existing){input=input||{};existing=existing||{};var start=asMs(input.startAt!=null?input.startAt:existing.startAt);var end=asMs(input.endAt!=null?input.endAt:existing.endAt);if(!Number.isFinite(start))start=Date.now()+3600000;if(!Number.isFinite(end)||end<=start)end=start+3600000;return Object.assign({},existing,input,{id:String(input.id||existing.id||uid()),title:String(input.title||input.text||existing.title||"Compromisso Extensão"),startAt:start,endAt:end,status:String(input.status||existing.status||"scheduled"),updatedAt:Date.now(),createdAt:existing.createdAt||input.createdAt||Date.now()});}
  async function schedule(input){await paid();var s=await state(),x=normalizeEvent(input);s.events.push(x);await save(s);emit("CalendarEventScheduled",x);return x;}
  async function update(id,patch){await paid();var s=await state(),i=s.events.findIndex(function(e){return e&&e.id===id;});if(i<0)throw Object.assign(new Error("Evento não encontrado"),{code:"CALENDAR_EVENT_NOT_FOUND"});s.events[i]=normalizeEvent(Object.assign({},patch,{id:id}),s.events[i]);await save(s);emit("CalendarEventUpdated",s.events[i]);return s.events[i];}
  async function remove(id){await paid();var s=await state(),before=s.events.length,removed=s.events.find(function(e){return e&&e.id===id;})||null;s.events=s.events.filter(function(e){return !e||e.id!==id;});if(s.events.length!==before){await save(s);emit("CalendarEventRemoved",removed||{id:id});}return s.events.length!==before;}
  function googleDate(v){var ms=asMs(v);if(!Number.isFinite(ms))return "";return new Date(ms).toISOString().replace(/[-:]/g,"").replace(/\.\d{3}Z$/,"Z");}
  function googleCalendarUrl(input){input=input||{};var start=asMs(input.startAt||input.start||input.date);if(!Number.isFinite(start))start=Date.now()+3600000;var end=asMs(input.endAt||input.end);if(!Number.isFinite(end)||end<=start)end=start+(Number(input.durationMinutes)||60)*60000;var q=new URLSearchParams();q.set("action","TEMPLATE");q.set("text",String(input.title||input.text||"Compromisso Extensão"));q.set("dates",googleDate(start)+"/"+googleDate(end));if(input.details||input.description)q.set("details",String(input.details||input.description));if(input.location)q.set("location",String(input.location));return "https://calendar.google.com/calendar/render?"+q.toString();}
  function meetUrl(){return "https://meet.google.com/";}
  function openGoogleCalendar(input){var url=googleCalendarUrl(input);try{window.open(url,"_blank","noopener,noreferrer");}catch(_){}return url;}
  function openMeet(){var url=meetUrl();try{window.open(url,"_blank","noopener,noreferrer");}catch(_){}return url;}
  async function tickUnlocked(lease){var s=await state(),now=Date.now(),dirty=false;if(lease)lease.assertActive();for(var i=0;i<s.events.length;i++){if(lease&&!lease.isActive())break;var e=s.events[i];if(!e)continue;if(e.status==="scheduled"&&Number(e.startAt)<=now&&Number(e.endAt)>now){e.status="live";e.updatedAt=now;dirty=true;emit("MeetStarted",e);}else if((e.status==="live"||e.status==="scheduled")&&Number(e.endAt)<=now){e.status="ended";e.updatedAt=now;dirty=true;emit("MeetEnded",e);}}if(dirty)await save(s);if(lease)lease.assertActive();return s.events;}
  async function tick(){if(window.__extPlanGate&&await window.__extPlanGate.isRestricted())return[];if(typeof window.__extWithAutomationLease!=="function")throw Object.assign(new Error("Coordenação segura entre abas indisponível."),{code:"AUTOMATION_COORDINATOR_UNAVAILABLE"});var coordinated=await window.__extWithAutomationLease("meet-calendar-tick",tickUnlocked);return coordinated.executed?coordinated.value:await state().then(function(s){return s.events;});}
  function emit(name,payload){try{window.__extEventBus&&window.__extEventBus.emit(name,payload,{source:"meet-calendar"});}catch(_){}}
  var api=Object.freeze({version:"2.0.0",storeKey:KEY,state:state,schedule:schedule,update:update,remove:remove,tick:tick,googleCalendarUrl:googleCalendarUrl,openGoogleCalendar:openGoogleCalendar,meetUrl:meetUrl,openMeet:openMeet});
  window.__extMeetCalendarService=api;window.ExtensionCore=window.ExtensionCore||{};
  var bus=window.__extEventBus;if(bus&&bus.on)bus.on("MeetLiveTick",function(){tick().catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("MEET_CALENDAR_TICK_FAILED",err);});});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
