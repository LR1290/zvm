;
try{
(function () {
  "use strict";

  if (window.__extSendSafetyManagerBooted) return;
  window.__extSendSafetyManagerBooted = true;

  var OPTIONS_KEY = "EXTUI:extappOptionsStore";
  var SUPPRESSION_KEY = "EXTUI:sendSafetySuppressionStore";
  var SUPPRESSION_VERSION = 1;
  var POLICY_REVISION = 2;
  var PROBE_TTL_MS = 120000;
  var SESSION_TTL_MS = 5000;
  var MAX_QUEUE_DEPTH = 2000;
  var REQUIRED_COMPATIBILITY_COMMANDS = Object.freeze(["sendText","sendFile","sendContact","sendList","sendPix","sendGroupInvite","statusImage","statusVideo","statusText"]);
  var DEFAULTS = Object.freeze({
    sendSafetyEnabled: true,
    sendSafetyGlobalPause: false,
    sendSafetyPolicyRevision: POLICY_REVISION,
    sendSafetyMinGapSeconds: 8,
    sendSafetyMaxPerMinute: 6,
    sendSafetyMaxPerHour: 60,
    sendSafetyMaxPerDay: 250,
    sendSafetyMaxCampaignRecipients: 100,
    sendSafetyFailureThreshold: 4,
    sendSafetyCircuitPauseSeconds: 120,
    sendSafetyBackoffBaseSeconds: 4,
    sendSafetyBackoffMaxSeconds: 60,
    sendSafetyQuietHoursEnabled: false,
    sendSafetyQuietStart: "08:00",
    sendSafetyQuietEnd: "20:00",
    sendSafetyAllowedDays: [0,1,2,3,4,5,6],
    sendSafetyRecipientCooldownMinutes: 1440
  });

  var settings = Object.assign({}, DEFAULTS);
  var suppression = { version:SUPPRESSION_VERSION, entries:Object.create(null) };
  var suppressionLoadPromise = null;
  var suppressionSyncError = null;
  var settingsLoadPromise = null;
  var settingsEpoch = 0;
  var settingsSyncError = null;
  function ensureSettingsReady() {
    if (settingsLoadPromise) return settingsLoadPromise;
    var task = Promise.resolve().then(loadSettings);
    settingsLoadPromise = task;
    task.catch(function () { if (settingsLoadPromise === task) settingsLoadPromise = null; });
    return task;
  }
  ensureSettingsReady().catch(function () {});
  var tail = Promise.resolve();
  var queueDepth = 0;
  var sentMinute = [];
  var sentHour = [];
  var lastSuccessAt = 0;
  var consecutiveFailures = 0;
  var circuitOpenUntil = 0;
  var lastError = null;
  var lastProbe = null;
  var lastProbeAt = 0;
  var lastSession = null;
  var lastSessionAt = 0;
  var recentRecipients = new Map();
  var campaignCounts = new Map();
  var metrics = { queued:0, sent:0, failed:0, throttled:0, blocked:0, probes:0, recovered:0, ambiguous:0 };

  function finite(value, fallback, min, max) {
    var n = Number(value);
    if (!isFinite(n)) n = fallback;
    if (typeof min === "number") n = Math.max(min, n);
    if (typeof max === "number") n = Math.min(max, n);
    return n;
  }

  function parseSettingsRaw(raw) {
    if (raw == null || raw === "") return {};
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); }
      catch (err) { throw makeError("SEND_SAFETY_SETTINGS_CORRUPT", "As configurações da Proteção de Envio estão inválidas e não serão substituídas por valores padrão.", { cause:err }); }
    }
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw makeError("SEND_SAFETY_SETTINGS_CORRUPT", "As configurações da Proteção de Envio estão inválidas e não serão substituídas por valores padrão.");
    return raw;
  }

  function normalizeSettings(raw) {
    raw = parseSettingsRaw(raw);
    var out = Object.assign({}, DEFAULTS);
    Object.keys(DEFAULTS).forEach(function (key) { if (Object.prototype.hasOwnProperty.call(raw, key)) out[key] = raw[key]; });
    out.sendSafetyEnabled = out.sendSafetyEnabled !== false;
    out.sendSafetyGlobalPause = out.sendSafetyGlobalPause === true;
    out.sendSafetyPolicyRevision = POLICY_REVISION;
    out.sendSafetyMinGapSeconds = finite(out.sendSafetyMinGapSeconds, DEFAULTS.sendSafetyMinGapSeconds, 1, 300);
    out.sendSafetyMaxPerMinute = Math.round(finite(out.sendSafetyMaxPerMinute, DEFAULTS.sendSafetyMaxPerMinute, 1, 60));
    out.sendSafetyMaxPerHour = Math.round(finite(out.sendSafetyMaxPerHour, DEFAULTS.sendSafetyMaxPerHour, 1, 1000));
    out.sendSafetyMaxPerDay = Math.round(finite(out.sendSafetyMaxPerDay, DEFAULTS.sendSafetyMaxPerDay, 1, 2000));
    out.sendSafetyMaxCampaignRecipients = Math.round(finite(out.sendSafetyMaxCampaignRecipients, DEFAULTS.sendSafetyMaxCampaignRecipients, 1, 1000));
    out.sendSafetyFailureThreshold = Math.round(finite(out.sendSafetyFailureThreshold, DEFAULTS.sendSafetyFailureThreshold, 1, 20));
    out.sendSafetyCircuitPauseSeconds = Math.round(finite(out.sendSafetyCircuitPauseSeconds, DEFAULTS.sendSafetyCircuitPauseSeconds, 10, 3600));
    out.sendSafetyBackoffBaseSeconds = finite(out.sendSafetyBackoffBaseSeconds, DEFAULTS.sendSafetyBackoffBaseSeconds, 0, 120);
    out.sendSafetyBackoffMaxSeconds = finite(out.sendSafetyBackoffMaxSeconds, DEFAULTS.sendSafetyBackoffMaxSeconds, out.sendSafetyBackoffBaseSeconds, 1800);
    out.sendSafetyQuietHoursEnabled = !!out.sendSafetyQuietHoursEnabled;
    out.sendSafetyQuietStart = /^\d{2}:\d{2}$/.test(String(out.sendSafetyQuietStart || "")) ? String(out.sendSafetyQuietStart) : DEFAULTS.sendSafetyQuietStart;
    out.sendSafetyQuietEnd = /^\d{2}:\d{2}$/.test(String(out.sendSafetyQuietEnd || "")) ? String(out.sendSafetyQuietEnd) : DEFAULTS.sendSafetyQuietEnd;
    out.sendSafetyAllowedDays = Array.isArray(out.sendSafetyAllowedDays) ? out.sendSafetyAllowedDays.map(Number).filter(function (v, i, a) { return v >= 0 && v <= 6 && a.indexOf(v) === i; }) : DEFAULTS.sendSafetyAllowedDays.slice();
    if (!out.sendSafetyAllowedDays.length) out.sendSafetyAllowedDays = DEFAULTS.sendSafetyAllowedDays.slice();
    out.sendSafetyRecipientCooldownMinutes = Math.round(finite(out.sendSafetyRecipientCooldownMinutes, DEFAULTS.sendSafetyRecipientCooldownMinutes, 0, 10080));
    return out;
  }

  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(key, function (result) {
          if (chrome.runtime && chrome.runtime.lastError) {
            var err=makeError("SEND_SAFETY_STORAGE_UNAVAILABLE","Não foi possível carregar a Proteção de Envio.");
            err.causeMessage=String(chrome.runtime.lastError.message||"").slice(0,160);
            reject(err); return;
          }
          resolve(result ? result[key] : undefined);
        });
      } catch (err) { reject(makeError("SEND_SAFETY_STORAGE_UNAVAILABLE","Não foi possível carregar a Proteção de Envio.",{cause:err})); }
    });
  }

  function storageSet(key, value) {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value);
    var payload = {}; payload[key] = value;
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.set(payload, function () {
          if (chrome.runtime && chrome.runtime.lastError) { reject(makeError("SEND_SAFETY_STORAGE_UNAVAILABLE", "Não foi possível atualizar a Proteção de Envio.")); return; }
          resolve(true);
        });
      } catch (err) { reject(makeError("SEND_SAFETY_STORAGE_UNAVAILABLE", "Não foi possível atualizar a Proteção de Envio.", { cause:err })); }
    });
  }

  function normalizeRecipientIdentity(value) {
    var raw = value && value._serialized ? value._serialized : String(value || "");
    raw = raw.trim().toLowerCase();
    var jid = raw.replace(/\s+/g, "");
    var cUs = /^(\d+)@c\.us$/.exec(jid);
    if (cUs) return cUs[1];
    if (/^\+?\d{8,20}$/.test(jid)) return jid.replace(/\D/g, "");
    return jid;
  }

  function parseSuppressionRaw(raw) {
    if (raw == null || raw === "") return { version:SUPPRESSION_VERSION, entries:Object.create(null) };
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (err) { throw makeError("SEND_SAFETY_SUPPRESSION_CORRUPT", "A lista Não contatar está inválida e os envios automáticos foram bloqueados por segurança.", { cause:err }); } }
    if (!raw || typeof raw !== "object" || Array.isArray(raw) || Number(raw.version || 0) !== SUPPRESSION_VERSION || !raw.entries || typeof raw.entries !== "object" || Array.isArray(raw.entries)) throw makeError("SEND_SAFETY_SUPPRESSION_CORRUPT", "A lista Não contatar está inválida e os envios automáticos foram bloqueados por segurança.");
    var out = Object.create(null), count = 0;
    Object.keys(raw.entries).forEach(function (digest) {
      if (!/^[a-f0-9]{64}$/.test(digest)) throw makeError("SEND_SAFETY_SUPPRESSION_CORRUPT", "A lista Não contatar contém um identificador inválido.");
      var row = raw.entries[digest];
      if (!row || typeof row !== "object" || Array.isArray(row)) throw makeError("SEND_SAFETY_SUPPRESSION_CORRUPT", "A lista Não contatar contém um registro inválido.");
      var last4 = String(row.last4 || "").replace(/\D/g, "");
      var createdAt = Number(row.createdAt || 0);
      if (last4.length > 4 || !Number.isFinite(createdAt) || createdAt <= 0) throw makeError("SEND_SAFETY_SUPPRESSION_CORRUPT", "A lista Não contatar contém metadados inválidos.");
      out[digest] = { last4:last4, createdAt:createdAt }; count++;
      if (count > 20000) throw makeError("SEND_SAFETY_SUPPRESSION_CAPACITY", "A lista Não contatar atingiu o limite interno seguro.");
    });
    return { version:SUPPRESSION_VERSION, entries:out };
  }

  async function loadSuppression() {
    var raw = await storageGet(SUPPRESSION_KEY);
    suppression = parseSuppressionRaw(raw); suppressionSyncError = null; return suppression;
  }
  function ensureSuppressionReady() {
    if (suppressionLoadPromise) return suppressionLoadPromise;
    var task = Promise.resolve().then(loadSuppression); suppressionLoadPromise = task;
    task.catch(function () { if (suppressionLoadPromise === task) suppressionLoadPromise = null; });
    return task;
  }
  ensureSuppressionReady().catch(function (err) { suppressionSyncError = err; });
  function refreshSuppressionFromValue(value) {
    try { suppression = parseSuppressionRaw(value); suppressionSyncError = null; suppressionLoadPromise = Promise.resolve(suppression); }
    catch (err) { suppressionSyncError = err; suppressionLoadPromise = null; if (window.__extReportRuntimeError) window.__extReportRuntimeError("SEND_SAFETY_SUPPRESSION_SYNC_FAILED", err); }
    emitHealth();
  }

  async function loadSettings() {
    var epoch = settingsEpoch;
    try {
      var raw = await storageGet(OPTIONS_KEY);
      var normalized = normalizeSettings(raw);
      if (epoch !== settingsEpoch) { if (settingsSyncError) throw settingsSyncError; return settings; }
      settings = normalized;
      settingsSyncError = null;
      lastError = null;
      emitHealth();
      return settings;
    } catch(err) {
      if (epoch !== settingsEpoch) { if (settingsSyncError) throw settingsSyncError; return settings; }
      settingsSyncError = err;
      lastError={code:err&&err.code||"SEND_SAFETY_STORAGE_UNAVAILABLE",message:err&&err.message||"Não foi possível carregar a Proteção de Envio.",at:Date.now()};
      emitHealth();
      if(window.__extReportRuntimeError)window.__extReportRuntimeError("SEND_SAFETY_SETTINGS_LOAD_FAILED",err);
      throw err;
    }
  }

  function refreshSettingsFromValue(newValue) {
    settingsEpoch++;
    try {
      settings = normalizeSettings(newValue);
      settingsSyncError = null;
      lastError = null;
      settingsLoadPromise = Promise.resolve(settings);
      emitHealth();
    } catch (err) {
      settingsSyncError = err;
      settingsLoadPromise = null;
      lastError = { code:err&&err.code||"SEND_SAFETY_SETTINGS_CORRUPT", message:err&&err.message||"As configurações da Proteção de Envio estão inválidas.", at:Date.now() };
      emitHealth();
      if (window.__extReportRuntimeError) window.__extReportRuntimeError("SEND_SAFETY_SETTINGS_SYNC_FAILED", err);
    }
  }

  try {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
      window.ExtensionStorage.subscribe(OPTIONS_KEY, refreshSettingsFromValue);
      window.ExtensionStorage.subscribe(SUPPRESSION_KEY, refreshSuppressionFromValue);
    }
  } catch (_) {}

  function makeError(code, message, extra) {
    var err = new Error(message);
    err.code = code;
    if (extra && typeof extra === "object") Object.keys(extra).forEach(function (k) { err[k] = extra[k]; });
    return err;
  }

  function sleep(ms, signal) {
    ms = Math.max(0, Number(ms) || 0);
    if (!ms) return Promise.resolve();
    var reliable = window.__extReliableDelay;
    if (reliable && typeof reliable.wait === "function") return reliable.wait(ms, signal).catch(function(err){if(err&&err.name==="AbortError")throw makeError("SEND_SAFETY_CANCELLED","Envio cancelado.");throw err;});
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(done, ms);
      function cleanup() { clearTimeout(timer); if (signal && signal.removeEventListener) signal.removeEventListener("abort", abort); }
      function done() { cleanup(); resolve(); }
      function abort() { cleanup(); reject(makeError("SEND_SAFETY_CANCELLED", "Envio cancelado.")); }
      if (signal && signal.aborted) return abort();
      if (signal && signal.addEventListener) signal.addEventListener("abort", abort, { once:true });
    });
  }

  function safetyRequestId() {
    var c = window.crypto;
    if (c && typeof c.randomUUID === "function") return c.randomUUID();
    return "send-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2) + "-" + Math.random().toString(36).slice(2);
  }

  async function safetyDigest(scope, value) {
    value = String(value || "");
    if (!value) return "";
    if (!window.crypto || !window.crypto.subtle) throw makeError("SEND_SAFETY_HASH_UNAVAILABLE", "A proteção segura entre abas não está disponível.");
    var bytes = new TextEncoder().encode(String(scope || "") + "|" + value), digest = await window.crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest)).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
  }

  function coordinatorRequest(payload) {
    return new Promise(function (resolve, reject) {
      var settled = false, timer = setTimeout(function () {
        if (settled) return; settled = true;
        reject(makeError("SEND_SAFETY_COORDINATOR_TIMEOUT", "A Proteção de Envio entre abas demorou demais para responder."));
      }, 7000);
      try {
        chrome.runtime.sendMessage(Object.assign({ type:"EXTUI_AUTOMATION_COORDINATOR" }, payload || {}), function (response) {
          if (settled) return; settled = true; clearTimeout(timer);
          var runtimeErr = chrome.runtime.lastError;
          if (runtimeErr) { reject(makeError("SEND_SAFETY_COORDINATOR_TRANSPORT", "A Proteção de Envio entre abas foi interrompida.")); return; }
          if (!response || response.ok !== true) { reject(makeError(response && response.errorCode || "SEND_SAFETY_COORDINATOR_FAILED", response && response.userMessage || "A Proteção de Envio entre abas falhou.")); return; }
          resolve(response.result || {});
        });
      } catch (err) { if (settled) return; settled = true; clearTimeout(timer); reject(err); }
    });
  }

  async function coordinatorRequestRetry(payload) {
    try { return await coordinatorRequest(payload); }
    catch (err) {
      if (!err || ["SEND_SAFETY_COORDINATOR_TIMEOUT", "SEND_SAFETY_COORDINATOR_TRANSPORT"].indexOf(err.code) < 0) throw err;
      await sleep(120);
      return await coordinatorRequest(payload);
    }
  }

  async function reserveGlobalSafety(meta) {
    if (!settings.sendSafetyEnabled || isExempt(meta) || isInteractive(meta)) return null;
    var requestId = safetyRequestId(), recipientDigest = "", campaignDigest = "";
    if (meta && meta.enforceRecipientCooldown && meta.recipient && settings.sendSafetyRecipientCooldownMinutes > 0) recipientDigest = await safetyDigest("recipient", recipientKey(meta.recipient));
    if (meta && meta.enforceCampaignLimit === true && meta.campaignId) campaignDigest = await safetyDigest("campaign", String(meta.campaignId));
    var payload = {
      action:"send_reserve", requestId:requestId,
      minGapMs:settings.sendSafetyMinGapSeconds * 1000,
      maxMinute:settings.sendSafetyMaxPerMinute,
      maxHour:settings.sendSafetyMaxPerHour,
      maxDay:settings.sendSafetyMaxPerDay,
      cooldownMs:settings.sendSafetyRecipientCooldownMinutes * 60000,
      campaignLimit:settings.sendSafetyMaxCampaignRecipients,
      failureThreshold:settings.sendSafetyFailureThreshold,
      circuitPauseMs:settings.sendSafetyCircuitPauseSeconds * 1000,
      recipientDigest:recipientDigest, campaignDigest:campaignDigest
    };
    while (true) {
      var result = await coordinatorRequestRetry(payload);
      if (result.reserved === true && result.token) return String(result.token);
      var code = String(result.code || "SEND_SAFETY_COORDINATOR_FAILED"), wait = Math.max(0, Number(result.retryAfterMs) || 0);
      if (code === "SEND_SAFETY_RATE_WAIT") { metrics.throttled++; emitHealth(); await sleep(Math.max(50, wait), meta && meta.signal); continue; }
      metrics.blocked++; emitHealth();
      if (code === "SEND_SAFETY_RECIPIENT_COOLDOWN") throw makeError(code, "Este contato já recebeu uma automação recentemente e foi protegido contra reenvio duplicado.", { retryAt:Date.now() + wait });
      if (code === "SEND_SAFETY_CAMPAIGN_LIMIT") throw makeError(code, "O limite de destinatários por campanha configurado em Proteção de Envio foi atingido.", { limit:Number(result.limit) || settings.sendSafetyMaxCampaignRecipients });
      if (code === "SEND_SAFETY_DAY_LIMIT") throw makeError(code, "O limite de envios automáticos das últimas 24 horas foi atingido.", { limit:settings.sendSafetyMaxPerDay, retryAt:Date.now()+wait });
      if (code === "SEND_SAFETY_CIRCUIT_OPEN") throw makeError(code, "As automações estão temporariamente pausadas após falhas consecutivas de envio.", { retryAt:Date.now() + wait });
      throw makeError(code, "A Proteção de Envio entre abas não conseguiu reservar o envio com segurança.");
    }
  }

  async function finalizeGlobalSafety(token, success, err) {
    if (!token) return false;
    var payload = { action:"send_finalize", token:String(token), success:success === true, operationalFailure:success !== true && isOperationalFailure(err), failureThreshold:settings.sendSafetyFailureThreshold, circuitPauseMs:settings.sendSafetyCircuitPauseSeconds * 1000 };
    var result = await coordinatorRequestRetry(payload);
    return result && result.finalized === true;
  }

  async function durablePayloadDigest(value, depth) {
    depth=Number(depth)||0;if(depth>16)throw makeError("SEND_EFFECT_PAYLOAD_INVALID","O conteúdo do envio excedeu a profundidade segura para identificação durável.");
    if(value===null)return safetyDigest("effect-node","null");
    var type=typeof value;
    if(type==="string")return safetyDigest("effect-node","s:"+value);
    if(type==="number")return safetyDigest("effect-node","n:"+(Number.isFinite(value)?String(value):"invalid"));
    if(type==="boolean")return safetyDigest("effect-node",value?"b:1":"b:0");
    if(type==="undefined")return safetyDigest("effect-node","u:");
    if(type!=="object")return safetyDigest("effect-node","x:"+String(value));
    if(Array.isArray(value)){var parts=[];for(var i=0;i<value.length;i++)parts.push(await durablePayloadDigest(value[i],depth+1));return safetyDigest("effect-array",String(value.length)+"|"+parts.join("|"));}
    var keys=Object.keys(value).sort(),pairs=[];for(var k=0;k<keys.length;k++){var key=keys[k];if(typeof value[key]==="function")continue;pairs.push(await safetyDigest("effect-key",key)+":"+await durablePayloadDigest(value[key],depth+1));}return safetyDigest("effect-object",pairs.join("|"));
  }

  async function prepareDurableEffect(meta) {
    if (!meta || meta.interactive === true || meta.exempt === true) return null;
    if (!meta.effectId) throw makeError("SEND_EFFECT_ID_REQUIRED", "Envios automáticos exigem uma identidade durável antes de acessar o WhatsApp.");
    var effectId=String(meta.effectId||"");
    if (!effectId || effectId.length>1024) throw makeError("SEND_EFFECT_ID_INVALID", "A automação não possui um identificador durável válido para este envio.");
    var effectDigest=await safetyDigest("effect",effectId);
    var recipientDigest=meta.recipient?await safetyDigest("effect-recipient",recipientKey(meta.recipient)):await safetyDigest("effect-recipient","none");
    var contentDigest=await durablePayloadDigest(meta.effectPayload,0);
    var payloadDigest=await safetyDigest("effect-payload",effectId+"|"+String(meta.method||"")+"|"+recipientDigest+"|"+contentDigest);
    var prepared=await coordinatorRequestRetry({action:"effect_prepare",effectDigest:effectDigest,payloadDigest:payloadDigest});
    if(prepared&&prepared.committed===true){metrics.recovered++;emitHealth();return{recovered:true,committedAt:Number(prepared.committedAt)||0,effectDigest:effectDigest,payloadDigest:payloadDigest};}
    if(prepared&&prepared.ambiguous===true){metrics.ambiguous++;emitHealth();throw makeError("SEND_EFFECT_AMBIGUOUS","Um envio anterior pode ter sido concluído antes de uma interrupção. O reenvio automático foi bloqueado para evitar duplicidade.",{effectDigest:effectDigest});}
    if(!prepared||prepared.prepared!==true||!prepared.token)throw makeError("SEND_EFFECT_PREPARE_FAILED","Não foi possível registrar este envio no journal durável.");
    return{recovered:false,effectDigest:effectDigest,payloadDigest:payloadDigest,token:String(prepared.token),begun:false};
  }

  async function beginDurableEffect(effect) {
    if(!effect||effect.recovered)return effect;
    var result=await coordinatorRequestRetry({action:"effect_begin",effectDigest:effect.effectDigest,payloadDigest:effect.payloadDigest,token:effect.token});
    if(result&&result.committed===true){effect.recovered=true;effect.committedAt=Number(result.committedAt)||0;metrics.recovered++;emitHealth();return effect;}
    if(result&&result.ambiguous===true){metrics.ambiguous++;emitHealth();throw makeError("SEND_EFFECT_AMBIGUOUS","Um envio anterior ficou em estado ambíguo e não será repetido automaticamente.",{effectDigest:effect.effectDigest});}
    if(!result||result.begun!==true)throw makeError("SEND_EFFECT_BEGIN_FAILED","O journal durável não autorizou o início deste envio.");
    effect.begun=true;return effect;
  }

  async function commitDurableEffect(effect) {
    if(!effect||effect.recovered)return true;
    var result=await coordinatorRequestRetry({action:"effect_commit",effectDigest:effect.effectDigest,payloadDigest:effect.payloadDigest,token:effect.token});
    return !!(result&&result.committed===true);
  }

  async function failDurableEffect(effect) {
    if(!effect||effect.recovered||!effect.begun)return false;
    var result=await coordinatorRequestRetry({action:"effect_fail",effectDigest:effect.effectDigest,payloadDigest:effect.payloadDigest,token:effect.token});
    return !!(result&&result.failed===true);
  }

  function trimWindows(now) {
    now = now || Date.now();
    sentMinute = sentMinute.filter(function (t) { return now - t < 60000; });
    sentHour = sentHour.filter(function (t) { return now - t < 3600000; });
    var cooldownWindowMs = settings.sendSafetyRecipientCooldownMinutes * 60000;
    if (!cooldownWindowMs) recentRecipients.clear();
    else recentRecipients.forEach(function (t, key) { if (now - t >= cooldownWindowMs) recentRecipients.delete(key); });
    campaignCounts.forEach(function (v, key) { if (!v || now - v.updatedAt > 24 * 3600000) campaignCounts.delete(key); });
  }

  function hhmmToMinutes(v) {
    var m = /^(\d{2}):(\d{2})$/.exec(String(v || ""));
    if (!m) return 0;
    return Math.max(0, Math.min(1439, Number(m[1]) * 60 + Number(m[2])));
  }

  function isWithinAllowedWindow(now) {
    if (!settings.sendSafetyQuietHoursEnabled) return true;
    now = now || new Date();
    if (settings.sendSafetyAllowedDays.indexOf(now.getDay()) < 0) return false;
    var current = now.getHours() * 60 + now.getMinutes();
    var start = hhmmToMinutes(settings.sendSafetyQuietStart);
    var end = hhmmToMinutes(settings.sendSafetyQuietEnd);
    if (start === end) return true;
    if (start < end) return current >= start && current < end;
    return current >= start || current < end;
  }

  function isInteractive(meta) { return !!(meta && (meta.interactive === true || meta.context && meta.context.interactive === true)); }
  function isExempt(meta) { return !!(meta && meta.exempt === true); }

  function stabilitySnapshot() {
    var now = Date.now();
    if (settings.sendSafetyEnabled === false) return { state:"disabled", label:"Proteção desativada", ok:true, checkedAt:now };
    if (settings.sendSafetyGlobalPause === true) return { state:"paused", label:"Envios pausados", ok:false, reason:"Pausa global ativada.", checkedAt:now };
    if (circuitOpenUntil > now) return { state:"paused", label:"Envios pausados", ok:false, reason:"Pausa automática após falhas consecutivas.", retryAt:circuitOpenUntil, checkedAt:now };
    if (lastError || consecutiveFailures > 0) return { state:"unstable", label:"Operação instável", ok:false, reason:lastError ? String(lastError.message || "Falha operacional recente.") : "Há falhas consecutivas registradas.", checkedAt:now };
    return { state:"stable", label:"Operação normal", ok:true, checkedAt:now };
  }

  function deriveReadiness(compatibility, session, stability) {
    compatibility = compatibility || lastProbe;
    session = session || lastSession;
    stability = stability || stabilitySnapshot();
    var checkedAt = Math.max(
      Number(compatibility && compatibility.checkedAt) || 0,
      Number(session && session.checkedAt) || 0
    ) || null;
    if (!compatibility) return { state:"unknown", label:"Teste necessário", ready:false, detail:"Execute Testar tudo para verificar compatibilidade e sessão.", checkedAt:checkedAt };
    if (compatibility.state === "unavailable") return { state:"whatsapp_unavailable", label:"WhatsApp indisponível", ready:false, detail:"A infraestrutura do WhatsApp Web não está disponível nesta aba.", checkedAt:checkedAt };
    if (compatibility.ok !== true) return { state:"compatibility_reduced", label:"Compatibilidade reduzida", ready:false, detail:compatibility.missingCommands && compatibility.missingCommands.length ? "Recursos ausentes: " + compatibility.missingCommands.join(", ") : "A infraestrutura necessária não foi confirmada.", checkedAt:checkedAt };
    if (!session) return { state:"unknown", label:"Verifique a sessão", ready:false, detail:"A compatibilidade foi confirmada, mas a sessão ainda não foi testada.", checkedAt:checkedAt };
    if (session.state === "waiting_connection") return { state:"waiting_connection", label:"Aguardando conexão", ready:false, detail:"Leia o QR Code para conectar uma conta ao WhatsApp Web.", checkedAt:checkedAt };
    if (session.state === "unavailable") return { state:"whatsapp_unavailable", label:"WhatsApp indisponível", ready:false, detail:"A sessão não conseguiu acessar o runtime do WhatsApp Web.", checkedAt:checkedAt };
    if (session.state !== "ready") return { state:"initializing", label:"Inicializando", ready:false, detail:"A conta foi detectada, mas a superfície de envio ainda está inicializando.", checkedAt:checkedAt };
    if (stability.state === "paused") return { state:"paused", label:"Envios pausados", ready:false, detail:stability.reason || "A Proteção de Envio está pausada.", checkedAt:checkedAt };
    if (stability.state === "unstable") return { state:"unstable", label:"Operação instável", ready:false, detail:stability.reason || "Foram detectadas falhas operacionais recentes.", checkedAt:checkedAt };
    return { state:"ready", label:"Pronto para enviar", ready:true, detail:stability.state === "disabled" ? "Sessão pronta; a Proteção de Envio está desativada." : "Compatibilidade aprovada, sessão pronta e operação estável.", checkedAt:checkedAt };
  }

  function healthState() {
    return deriveReadiness(lastProbe, lastSession, stabilitySnapshot()).state;
  }

  function snapshot() {
    trimWindows();
    var stability = stabilitySnapshot();
    var readiness = deriveReadiness(lastProbe, lastSession, stability);
    return {
      state: readiness.state,
      enabled: !!settings.sendSafetyEnabled,
      queueDepth: queueDepth,
      sentLastMinute: sentMinute.length,
      sentLastHour: sentHour.length,
      consecutiveFailures: consecutiveFailures,
      circuitOpenUntil: circuitOpenUntil || null,
      lastSuccessAt: lastSuccessAt || null,
      lastError: lastError ? { code:lastError.code || "SEND_ERROR", message:String(lastError.message || lastError) } : null,
      compatibility: lastProbe ? Object.assign({}, lastProbe) : null,
      session: lastSession ? Object.assign({}, lastSession) : null,
      stability: stabilitySnapshot(),
      readiness: deriveReadiness(lastProbe, lastSession, stability),
      metrics: Object.assign({}, metrics),
      settings: Object.assign({}, settings)
    };
  }

  function emitHealth() {
    var detail = snapshot();
    try { window.dispatchEvent(new CustomEvent("ext:send-safety-health", { detail:detail })); } catch (_) {}
    try { if (window.__extEventBus && typeof window.__extEventBus.emit === "function") window.__extEventBus.emit("SendSafetyHealth", detail, { source:"send-safety" }); } catch (_) {}
  }

  function bridgeUnavailableResult(code) {
    return { ready:false, rawReady:false, graphReady:false, fullReady:false, authenticated:null, mainReady:null, sendSurface:false, activeChat:false, waVersion:null, commands:{}, code:code || "WPP_BRIDGE_UNAVAILABLE" };
  }

  async function invokeBridgeProbe() {
    var bridge = window.__extWppBridge;
    if (!bridge || typeof bridge.invoke !== "function") return bridgeUnavailableResult("WPP_BRIDGE_UNAVAILABLE");
    try {
      var result = await bridge.invoke("Webpack", "probe", null);
      return result && typeof result === "object" ? result : bridgeUnavailableResult("WPP_PROBE_INVALID");
    } catch (err) {
      try {
        var ready = await bridge.invoke("Webpack", "isReady", null);
        return { ready:ready === true, rawReady:ready === true, graphReady:ready === true, fullReady:false, authenticated:null, mainReady:null, sendSurface:false, activeChat:false, waVersion:null, commands:{}, code:ready === true ? null : "WPP_NOT_READY" };
      } catch (fallbackErr) {
        return bridgeUnavailableResult((fallbackErr && fallbackErr.code) || "WPP_PROBE_FAILED");
      }
    }
  }

  function compatibilityFromResult(result, checkedAt) {
    result = result && typeof result === "object" ? result : {};
    var commands = result.commands && typeof result.commands === "object" ? result.commands : {};
    var compatibilityGraphReady = result.graphReady === true || result.fullReady === true || result.rawReady === true || result.ready === true;
    var missingCommands = REQUIRED_COMPATIBILITY_COMMANDS.filter(function (name) { return commands[name] !== true; });
    return {
      ok: compatibilityGraphReady && missingCommands.length === 0,
      state: compatibilityGraphReady ? (missingCommands.length ? "reduced" : "compatible") : "unavailable",
      graphReady: result.graphReady === true,
      rawReady: result.rawReady === true,
      fullReady: result.fullReady === true,
      waVersion: result.waVersion || null,
      commands: Object.assign({}, commands),
      missingCommands: missingCommands,
      checkedAt: checkedAt || Date.now(),
      code: result.code || (compatibilityGraphReady ? (missingCommands.length ? "WPP_CAPABILITIES_REDUCED" : null) : "WPP_NOT_READY")
    };
  }

  function sessionFromResult(result, checkedAt) {
    result = result && typeof result === "object" ? result : {};
    var graphReady = result.graphReady === true || result.fullReady === true || result.rawReady === true || result.ready === true;
    var authenticated = result.authenticated === true;
    var mainReady = result.mainReady === true;
    var connected = authenticated || mainReady;
    var sendSurface = result.sendSurface === true;
    var unknownAuth = result.authenticated == null && result.mainReady == null;
    var state = !graphReady ? "unavailable" : (!connected ? (unknownAuth ? "initializing" : "waiting_connection") : (sendSurface ? "ready" : "initializing"));
    return {
      ok: state === "ready",
      ready: state === "ready",
      state: state,
      authenticated: result.authenticated === true ? true : (result.authenticated === false ? false : null),
      mainReady: result.mainReady === true ? true : (result.mainReady === false ? false : null),
      sendSurface: sendSurface,
      activeChat: result.activeChat === true,
      checkedAt: checkedAt || Date.now(),
      code: state === "ready" ? null : (state === "waiting_connection" ? "WPP_SESSION_NOT_AUTHENTICATED" : (state === "initializing" ? "WPP_SESSION_INITIALIZING" : "WPP_NOT_READY"))
    };
  }

  async function probeCompatibility(force) {
    await ensureSettingsReady();
    var now = Date.now();
    var probeTtl = lastProbe && lastProbe.ok === true ? PROBE_TTL_MS : 1200;
    if (!force && lastProbe && now - lastProbeAt < probeTtl) return lastProbe;
    metrics.probes++;
    var result = await invokeBridgeProbe();
    lastProbe = compatibilityFromResult(result, Date.now());
    lastProbeAt = lastProbe.checkedAt;
    emitHealth();
    return lastProbe;
  }

  async function probeSession(force) {
    await ensureSettingsReady();
    var now = Date.now();
    if (!force && lastSession && now - lastSessionAt < SESSION_TTL_MS) return lastSession;
    metrics.probes++;
    var result = await invokeBridgeProbe();
    lastSession = sessionFromResult(result, Date.now());
    lastSessionAt = lastSession.checkedAt;
    emitHealth();
    return lastSession;
  }

  async function probeAll(force) {
    await probeCompatibility(force === true);
    await probeSession(force === true);
    emitHealth();
    return snapshot();
  }

  function commandForMethod(method) {
    var map = {
      sendTxt:"sendText", sendTextReplay:"sendText", linkPreview:"sendText",
      sendImage:"sendFile", sendVideo:"sendFile", sendAudio:"sendFile", sendDoc:"sendFile", sticker:"sendFile",
      sendContact:"sendContact", sendListMessage:"sendList", sendPixKeyMessage:"sendPix", sendGroupInviteMessage:"sendGroupInvite",
      sendTextStatus:"statusText", sendImageStatus:"statusImage", sendVideoStatus:"statusVideo"
    };
    return map[method] || null;
  }

  async function ensureCompatible(method, signal) {
    var probe = await probeCompatibility(false);
    if (!probe || probe.state === "unavailable") {
      var bridge = window.__extWppBridge;
      if (bridge && typeof bridge.waitUntilReady === "function") {
        try { await bridge.waitUntilReady(6000); } catch (_) {}
      } else {
        try { await sleep(350, signal); } catch (_) {}
      }
      probe = await probeCompatibility(true);
    }
    if (!probe || probe.state === "unavailable") throw makeError("SEND_SAFETY_WPP_NOT_READY", "A infraestrutura interna do WhatsApp Web ainda não está disponível.", { health:probe });
    var cap = commandForMethod(method);
    if (cap && (!probe.commands || probe.commands[cap] !== true)) {
      throw makeError("SEND_SAFETY_CAPABILITY_UNAVAILABLE", "O WhatsApp Web atual não oferece temporariamente a capacidade necessária para este envio.", { capability:cap, health:probe });
    }
    if (signal && signal.aborted) throw makeError("SEND_SAFETY_CANCELLED", "Envio cancelado.");
  }

  async function ensureSessionReady(signal) {
    var session = await probeSession(false);
    if (!session || session.ready !== true) {
      var bridge = window.__extWppBridge;
      if (bridge && typeof bridge.waitUntilReady === "function") {
        try { await bridge.waitUntilReady(1200); } catch (_) {}
      } else {
        try { await sleep(250, signal); } catch (_) {}
      }
      session = await probeSession(true);
    }
    if (session && session.ready === true) return session;
    if (session && session.state === "waiting_connection") throw makeError("SEND_SAFETY_SESSION_NOT_AUTHENTICATED", "Conecte uma conta ao WhatsApp Web lendo o QR Code antes de enviar.", { session:session });
    if (session && session.state === "initializing") throw makeError("SEND_SAFETY_SESSION_INITIALIZING", "A sessão do WhatsApp foi detectada, mas ainda está inicializando. Aguarde alguns instantes e tente novamente.", { session:session });
    throw makeError("SEND_SAFETY_WPP_NOT_READY", "A sessão do WhatsApp Web não está disponível para envio.", { session:session });
  }

  async function waitRateLimits(meta) {
    if (!settings.sendSafetyEnabled || isExempt(meta) || isInteractive(meta)) return;
    var signal = meta && meta.signal;
    while (true) {
      trimWindows();
      var now = Date.now();
      var waits = [];
      var gapMs = Math.max(0, settings.sendSafetyMinGapSeconds * 1000 - (now - lastSuccessAt));
      if (gapMs > 0) waits.push(gapMs);
      if (sentMinute.length >= settings.sendSafetyMaxPerMinute) waits.push(Math.max(50, 60000 - (now - sentMinute[0]) + 20));
      if (sentHour.length >= settings.sendSafetyMaxPerHour) waits.push(Math.max(50, 3600000 - (now - sentHour[0]) + 20));
      var backoff = consecutiveFailures > 0 ? Math.min(settings.sendSafetyBackoffMaxSeconds * 1000, settings.sendSafetyBackoffBaseSeconds * 1000 * Math.pow(2, Math.max(0, consecutiveFailures - 1))) : 0;
      if (backoff > 0 && lastError && lastError.at) waits.push(Math.max(0, backoff - (now - lastError.at)));
      var wait = waits.length ? Math.max.apply(Math, waits) : 0;
      if (!wait) return;
      metrics.throttled++;
      emitHealth();
      await sleep(wait, signal);
    }
  }

  function ensureQuietHours(meta) {
    if (!settings.sendSafetyEnabled || isExempt(meta) || isInteractive(meta)) return;
    if (!isWithinAllowedWindow(new Date())) {
      metrics.blocked++;
      throw makeError("SEND_SAFETY_OUTSIDE_WINDOW", "Envio automático bloqueado pela janela de horário configurada em Proteção de Envio.");
    }
  }

  async function ensureCircuit(meta) {
    if (!settings.sendSafetyEnabled || isExempt(meta) || isInteractive(meta)) return;
    var now = Date.now();
    if (circuitOpenUntil && circuitOpenUntil <= now) {
      circuitOpenUntil = 0;
      consecutiveFailures = 0;
      lastError = null;
      emitHealth();
      return;
    }
    if (circuitOpenUntil > now) {
      metrics.blocked++;
      throw makeError("SEND_SAFETY_CIRCUIT_OPEN", "As automações estão temporariamente pausadas após falhas consecutivas de envio.", { retryAt:circuitOpenUntil });
    }
  }

  function recipientKey(value) { return normalizeRecipientIdentity(value); }

  async function suppressionDigestFor(value) { var key = recipientKey(value); return key ? await safetyDigest("optout", key) : ""; }
  async function isRecipientSuppressed(value) {
    await ensureSuppressionReady(); if (suppressionSyncError) throw suppressionSyncError;
    var digest = await suppressionDigestFor(value); return !!(digest && suppression.entries[digest]);
  }
  async function addSuppressedRecipient(value) {
    await ensureSuppressionReady(); if (suppressionSyncError) throw suppressionSyncError;
    var key = recipientKey(value), digest = await suppressionDigestFor(value);
    if (!key || !digest) throw makeError("SEND_SAFETY_SUPPRESSION_INVALID", "Informe um destinatário válido para a lista Não contatar.");
    var next = { version:SUPPRESSION_VERSION, entries:Object.assign(Object.create(null), suppression.entries) };
    var digits = key.replace(/\D/g, ""); next.entries[digest] = { last4:digits.slice(-4), createdAt:Date.now() };
    await storageSet(SUPPRESSION_KEY, next);
    suppression = parseSuppressionRaw(next); suppressionLoadPromise = Promise.resolve(suppression); emitHealth(); return { digest:digest, last4:next.entries[digest].last4 };
  }
  async function removeSuppressedRecipient(digest) {
    await ensureSuppressionReady(); digest=String(digest||"").toLowerCase(); if(!/^[a-f0-9]{64}$/.test(digest))throw makeError("SEND_SAFETY_SUPPRESSION_INVALID","Identificador inválido da lista Não contatar.");
    var next={version:SUPPRESSION_VERSION,entries:Object.assign(Object.create(null),suppression.entries)};delete next.entries[digest];await storageSet(SUPPRESSION_KEY,next);suppression=parseSuppressionRaw(next);suppressionLoadPromise=Promise.resolve(suppression);emitHealth();return true;
  }
  function listSuppressedRecipients() {
    if (suppressionSyncError) return [];
    return Object.keys(suppression.entries||{}).map(function(digest){var row=suppression.entries[digest];return{digest:digest,last4:row.last4||"",createdAt:Number(row.createdAt)||0};}).sort(function(a,b){return b.createdAt-a.createdAt;});
  }
  function ensureGlobalPause(meta) {
    if (isExempt(meta) || isInteractive(meta)) return;
    if (settings.sendSafetyGlobalPause === true) { metrics.blocked++; throw makeError("SEND_SAFETY_GLOBAL_PAUSED", "Os novos envios automáticos estão pausados pelo Kill Switch em Ajustes > Segurança."); }
  }
  async function ensureNotSuppressed(meta) {
    if (isExempt(meta) || isInteractive(meta) || !(meta && meta.recipient)) return;
    if (await isRecipientSuppressed(meta.recipient)) { metrics.blocked++; throw makeError("SEND_SAFETY_DO_NOT_CONTACT", "Este destinatário está na lista Não contatar e não receberá automações."); }
  }

  function recipientCooldownInfo(value) {
    var key = recipientKey(value), previous = key ? recentRecipients.get(key) : null;
    var windowMs = settings.sendSafetyRecipientCooldownMinutes * 60000;
    if (!windowMs || !previous || Date.now() - previous >= windowMs) return { blocked:false, key:key, retryAt:null };
    return { blocked:true, key:key, retryAt:previous + windowMs };
  }

  function markRecipientTouched(value, at) {
    if (!settings.sendSafetyEnabled || settings.sendSafetyRecipientCooldownMinutes <= 0) return false;
    var key = recipientKey(value); if (!key) return false;
    recentRecipients.set(key, Number(at) || Date.now()); trimWindows(); return true;
  }

  function ensureRecipientCooldown(meta) {
    if (!settings.sendSafetyEnabled || isExempt(meta) || isInteractive(meta)) return;
    if (!settings.sendSafetyRecipientCooldownMinutes || !(meta && meta.enforceRecipientCooldown)) return;
    var key = recipientKey(meta.recipient);
    if (!key) return;
    var previous = recentRecipients.get(key);
    var windowMs = settings.sendSafetyRecipientCooldownMinutes * 60000;
    if (previous && Date.now() - previous < windowMs) {
      metrics.blocked++;
      throw makeError("SEND_SAFETY_RECIPIENT_COOLDOWN", "Este contato já recebeu uma automação recentemente e foi protegido contra reenvio duplicado.", { retryAt:previous + windowMs });
    }
  }

  function ensureCampaign(meta) {
    if (!settings.sendSafetyEnabled || isExempt(meta) || !meta || !meta.campaignId || meta.enforceCampaignLimit !== true) return;
    var key = String(meta.campaignId);
    var entry = campaignCounts.get(key) || { count:0, updatedAt:Date.now() };
    if (entry.count >= settings.sendSafetyMaxCampaignRecipients) {
      metrics.blocked++;
      throw makeError("SEND_SAFETY_CAMPAIGN_LIMIT", "O limite de destinatários por campanha configurado em Proteção de Envio foi atingido.", { limit:settings.sendSafetyMaxCampaignRecipients });
    }
  }

  function recordSuccess(meta) {
    var now = Date.now();
    sentMinute.push(now); sentHour.push(now); lastSuccessAt = now;
    consecutiveFailures = 0; lastError = null; metrics.sent++;
    if (meta && meta.recipient && meta.enforceRecipientCooldown && settings.sendSafetyRecipientCooldownMinutes > 0) recentRecipients.set(recipientKey(meta.recipient), now);
    if (meta && meta.campaignId && meta.enforceCampaignLimit === true) {
      var key = String(meta.campaignId), entry = campaignCounts.get(key) || { count:0, updatedAt:now };
      entry.count++; entry.updatedAt = now; campaignCounts.set(key, entry);
    }
    emitHealth();
  }

  function isOperationalFailure(err) {
    var code = String(err && err.code || "");
    return !/^SEND_SAFETY_(?:CANCELLED|OUTSIDE_WINDOW|RECIPIENT_COOLDOWN|CAMPAIGN_LIMIT|DAY_LIMIT|CIRCUIT_OPEN|GLOBAL_PAUSED|DO_NOT_CONTACT|CONSENT_REQUIRED)$/.test(code);
  }

  function isDurableTerminalError(err) {
    return /^(?:SEND_EFFECT_(?:AMBIGUOUS|COMMIT_UNCERTAIN|ID_REQUIRED)|SEND_SAFETY_(?:GLOBAL_PAUSED|DO_NOT_CONTACT|CONSENT_REQUIRED|DAY_LIMIT))$/.test(String(err&&err.code||""));
  }

  function recordFailure(err) {
    if (!isOperationalFailure(err)) return;
    consecutiveFailures++;
    lastError = { code:(err && err.code) || "SEND_ERROR", message:String(err && err.message || err || "Falha de envio"), at:Date.now() };
    metrics.failed++;
    if (consecutiveFailures >= settings.sendSafetyFailureThreshold) {
      circuitOpenUntil = Date.now() + settings.sendSafetyCircuitPauseSeconds * 1000;
    }
    lastProbeAt = 0;
    emitHealth();
  }

  async function runJob(meta, task) {
    await ensureSettingsReady();
    meta = meta || {};
    meta.signal = meta.signal || meta.context && meta.context.cancellationSignal || null;
    await ensureSuppressionReady();
    ensureGlobalPause(meta);
    await ensureNotSuppressed(meta);
    var effect = await prepareDurableEffect(meta);
    if(effect&&effect.recovered)return{__extDurableEffectRecovered:true,committedAt:effect.committedAt||null};
    ensureQuietHours(meta);
    await ensureCircuit(meta);
    ensureRecipientCooldown(meta);
    ensureCampaign(meta);
    if (!isExempt(meta)) {
      await ensureCompatible(meta.method, meta.signal);
      await ensureSessionReady(meta.signal);
    }
    await waitRateLimits(meta);
    ensureGlobalPause(meta);
    await ensureNotSuppressed(meta);
    var reservationToken = await reserveGlobalSafety(meta);
    var remoteSucceeded=false;
    try {
      if(effect){await beginDurableEffect(effect);if(effect.recovered){if(reservationToken){try{await finalizeGlobalSafety(reservationToken,true,null);}catch(_){}}return{__extDurableEffectRecovered:true,committedAt:effect.committedAt||null};}}
      var result = (typeof window.__extPreserveChatListScroll === "function") ? await window.__extPreserveChatListScroll(task) : await task();
      remoteSucceeded=true;
      if(effect){
        try{if(!await commitDurableEffect(effect))throw makeError("SEND_EFFECT_COMMIT_FAILED","O journal durável não confirmou o envio concluído.");}
        catch(commitErr){
          if(reservationToken){try{await finalizeGlobalSafety(reservationToken,true,null);}catch(finalizeErr){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SEND_SAFETY_GLOBAL_FINALIZE_FAILED",finalizeErr);}}
          recordSuccess(meta);
          throw makeError("SEND_EFFECT_COMMIT_UNCERTAIN","O WhatsApp confirmou o envio, mas a extensão não conseguiu concluir o registro durável. O reenvio automático foi bloqueado por segurança.",{cause:commitErr,remoteEffectSucceeded:true,effectDigest:effect.effectDigest});
        }
      }
      if (reservationToken) {
        try { await finalizeGlobalSafety(reservationToken, true, null); }
        catch (finalizeErr) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("SEND_SAFETY_GLOBAL_FINALIZE_FAILED", finalizeErr); }
      }
      recordSuccess(meta);
      return result;
    } catch (err) {
      if(remoteSucceeded)throw err;
      if(effect&&effect.begun){try{await failDurableEffect(effect);}catch(journalErr){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SEND_EFFECT_FAIL_RECORD_FAILED",journalErr);}}
      if (reservationToken) {
        try { await finalizeGlobalSafety(reservationToken, false, err); }
        catch (finalizeErr) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("SEND_SAFETY_GLOBAL_RELEASE_FAILED", finalizeErr); }
      }
      recordFailure(err);
      throw err;
    }
  }

  function enqueue(meta, task) {
    if (typeof task !== "function") return Promise.reject(makeError("SEND_SAFETY_TASK_REQUIRED", "Operação de envio inválida."));
    if (queueDepth >= MAX_QUEUE_DEPTH) return Promise.reject(makeError("SEND_SAFETY_QUEUE_FULL", "A fila de proteção atingiu o limite interno. Aguarde os envios atuais terminarem."));
    queueDepth++; metrics.queued++; emitHealth();
    var start = function () { return runJob(meta || {}, task); };
    var promise = tail.then(start, start);
    tail = promise.catch(function () { return null; });
    return promise.finally(function () { queueDepth = Math.max(0, queueDepth - 1); emitHealth(); });
  }

  function sendChat(method, payload, context, options) {
    options = options || {};
    var bridge = window.__extWppBridge;
    if (!bridge || typeof bridge.invoke !== "function") return Promise.reject(makeError("WPP_BRIDGE_UNAVAILABLE", "O WhatsApp ainda não está pronto. Aguarde alguns segundos e tente novamente."));
    var recipient = payload && (payload.id || payload.chatId || payload.contactId) || context && (context.contactId || context.remetente) || "";
    var meta = Object.assign({}, options, {
      method:method,
      source:options.source || context && context.source || "unknown",
      context:context || {},
      recipient:recipient,
      effectPayload:payload,
      signal:context && context.cancellationSignal || options.signal || null
    });
    return enqueue(meta, function () { return bridge.invoke("Chat", method, payload); });
  }

  function riskAssessment(result) {
    var score=0,reasons=[];
    if(result.allowedCount>Math.max(50,Math.floor(settings.sendSafetyMaxCampaignRecipients*0.5))){score+=2;reasons.push("campanha de volume elevado para os seus guardrails");}
    if(result.dayRemaining!=null&&result.allowedCount>Math.max(1,Math.floor(result.dayRemaining*0.5))){score+=2;reasons.push("consome mais da metade do limite restante de 24h");}
    if(result.cooldownSkippedCount>0||result.suppressionSkippedCount>0){score+=1;reasons.push("a lista contém destinatários bloqueados por proteção/opt-out");}
    if(!result.withinWindow){score+=3;reasons.push("fora da janela de automações configurada");}
    var level=score>=4?"high":score>=2?"medium":"low";
    return{level:level,label:level==="high"?"Atenção alta":level==="medium"?"Atenção moderada":"Atenção baixa",reasons:reasons};
  }

  async function preflightRecipients(recipients, options) {
    await ensureSettingsReady(); await ensureSuppressionReady(); if (suppressionSyncError) throw suppressionSyncError;
    recipients = Array.isArray(recipients) ? recipients : []; options = options || {};
    if (settings.sendSafetyEnabled === false) {
      var uniqueAll = [], seenAll = new Set();
      recipients.forEach(function(value){ var key = recipientKey(value); if(!key || seenAll.has(key)) return; seenAll.add(key); uniqueAll.push(value); });
      return { ok:true, code:"SEND_SAFETY_DISABLED", message:"A Proteção de Envio está desligada manualmente.", total:recipients.length, unique:uniqueAll, allowedRecipients:uniqueAll.slice(), uniqueCount:uniqueAll.length, allowedCount:uniqueAll.length, duplicateCount:Math.max(0, recipients.length - uniqueAll.length), duplicates:[], cooldownSkippedCount:0, cooldownBlocked:[], suppressionSkippedCount:0, suppressionBlocked:[], limit:null, dayLimit:null, dayCount:0, dayRemaining:null, withinWindow:true, globalPaused:false, circuitOpenUntil:null, settingsMinGap:0, estimateMs:0, policyRevision:POLICY_REVISION, risk:{level:"low", label:"Proteção desligada", reasons:["Os guardrails foram desativados manualmente para esta instalação."]} };
    }
    var seen = new Set(), unique = [], duplicates = [];
    recipients.forEach(function (value) { var key=recipientKey(value); if(!key)return; if(seen.has(key))duplicates.push(value);else{seen.add(key);unique.push(value);} });
    var suppressionBlocked=[], cooldownBlocked=[], allowed=[];
    for(var i=0;i<unique.length;i++){var value=unique[i];if(!options.interactive&&await isRecipientSuppressed(value)){suppressionBlocked.push(value);continue;}var info=options.enforceRecipientCooldown?recipientCooldownInfo(value):{blocked:false};if(info.blocked){cooldownBlocked.push({recipient:value,retryAt:info.retryAt});continue;}allowed.push(value);}
    var globalStatus=options.interactive?{dayCount:0,dayRemaining:settings.sendSafetyMaxPerDay}:await coordinatorRequestRetry({action:"send_status",maxMinute:settings.sendSafetyMaxPerMinute,maxHour:settings.sendSafetyMaxPerHour,maxDay:settings.sendSafetyMaxPerDay});
    var result={ok:true,total:recipients.length,unique:unique,allowedRecipients:allowed,uniqueCount:unique.length,allowedCount:allowed.length,duplicateCount:duplicates.length,duplicates:duplicates,cooldownSkippedCount:cooldownBlocked.length,cooldownBlocked:cooldownBlocked,suppressionSkippedCount:suppressionBlocked.length,suppressionBlocked:suppressionBlocked,limit:settings.sendSafetyMaxCampaignRecipients,dayLimit:settings.sendSafetyMaxPerDay,dayCount:Number(globalStatus.dayCount)||0,dayRemaining:Math.max(0,Number(globalStatus.dayRemaining)||0),withinWindow:isWithinAllowedWindow(new Date()),globalPaused:settings.sendSafetyGlobalPause===true,circuitOpenUntil:circuitOpenUntil||null,settingsMinGap:settings.sendSafetyMinGapSeconds,estimateMs:allowed.length*settings.sendSafetyMinGapSeconds*1000,policyRevision:POLICY_REVISION};
    result.risk=riskAssessment(result);
    if(!options.interactive&&result.globalPaused){result.ok=false;result.code="SEND_SAFETY_GLOBAL_PAUSED";result.message="Os novos envios automáticos estão pausados pelo Kill Switch.";}
    else if(allowed.length>settings.sendSafetyMaxCampaignRecipients){result.ok=false;result.code="SEND_SAFETY_CAMPAIGN_LIMIT";result.message="A campanha possui "+allowed.length+" destinatários elegíveis, acima do limite configurado de "+settings.sendSafetyMaxCampaignRecipients+".";}
    else if(allowed.length>result.dayRemaining){result.ok=false;result.code="SEND_SAFETY_DAY_LIMIT";result.message="A campanha excede o saldo de "+result.dayRemaining+" envio(s) automáticos disponível nas últimas 24 horas.";}
    else if(unique.length>0&&allowed.length===0){result.ok=false;result.code=suppressionBlocked.length?"SEND_SAFETY_DO_NOT_CONTACT":"SEND_SAFETY_RECIPIENT_COOLDOWN";result.message=suppressionBlocked.length?"Todos os destinatários elegíveis estão na lista Não contatar.":"Todos os destinatários estão dentro da janela de proteção contra reenvio.";}
    else if(!options.interactive&&!result.withinWindow){result.ok=false;result.code="SEND_SAFETY_OUTSIDE_WINDOW";result.message="O horário atual está fora da janela permitida para automações.";}
    else if(circuitOpenUntil>Date.now()){result.ok=false;result.code="SEND_SAFETY_CIRCUIT_OPEN";result.message="A Proteção de Envio está temporariamente pausada após falhas consecutivas.";}
    return result;
  }

  function resetCircuit() {
    circuitOpenUntil = 0; consecutiveFailures = 0; lastError = null; lastProbeAt = 0; emitHealth(); return true;
  }

  var api = Object.freeze({
    version:"2.0.0",
    defaults:DEFAULTS,
    sendChat:sendChat,
    enqueue:enqueue,
    preflightRecipients:preflightRecipients,
    probeCompatibility:probeCompatibility,
    probeSession:probeSession,
    probeAll:probeAll,
    deriveReadiness:deriveReadiness,
    ensureSessionReady:ensureSessionReady,
    getHealth:snapshot,
    getSettings:function () { return Object.assign({}, settings); },
    isWithinAllowedWindow:isWithinAllowedWindow,
    recipientCooldownInfo:recipientCooldownInfo,
    markRecipientTouched:markRecipientTouched,
    addSuppressedRecipient:addSuppressedRecipient,
    removeSuppressedRecipient:removeSuppressedRecipient,
    listSuppressedRecipients:listSuppressedRecipients,
    isRecipientSuppressed:isRecipientSuppressed,
    isDurableTerminalError:isDurableTerminalError,
    resetCircuit:resetCircuit
  });

  window.__extSendSafetyManager = api;
  window.ExtensionCore = window.ExtensionCore || {};
  

  try {
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      if (!message || typeof message !== "object" || !sender || sender.id !== chrome.runtime.id) return;
      if (message.type === "EXTUI_SEND_SAFETY_GET_HEALTH") { sendResponse({ ok:true, result:snapshot() }); return; }
      if (message.type === "EXTUI_SEND_SAFETY_RESET_CIRCUIT") { resetCircuit(); sendResponse({ ok:true, result:snapshot() }); return; }
      if (message.type === "EXTUI_SEND_SAFETY_PREFLIGHT") { var requestId=message.requestId||null; preflightRecipients(message.recipients||[],message.options||{}).then(function(result){sendResponse({requestId:requestId,data:result,error:null});}).catch(function(err){sendResponse({requestId:requestId,data:null,error:{code:err&&err.code||"SEND_SAFETY_PREFLIGHT_FAILED",message:err&&err.message||String(err)}});}); return true; }
      if (message.type === "EXTUI_SEND_SAFETY_TEST_COMPATIBILITY") {
        probeCompatibility(true).then(function (result) { sendResponse({ ok:true, result:result, health:snapshot() }); }).catch(function (err) { sendResponse({ ok:false, error:{ code:err && err.code || "SEND_SAFETY_COMPATIBILITY_TEST_FAILED", message:err && err.message || String(err) } }); });
        return true;
      }
      if (message.type === "EXTUI_SEND_SAFETY_TEST_SESSION") {
        probeSession(true).then(function (result) { sendResponse({ ok:true, result:result, health:snapshot() }); }).catch(function (err) { sendResponse({ ok:false, error:{ code:err && err.code || "SEND_SAFETY_SESSION_TEST_FAILED", message:err && err.message || String(err) } }); });
        return true;
      }
      if (message.type === "EXTUI_SEND_SAFETY_TEST_ALL" || message.type === "EXTUI_SEND_SAFETY_PROBE") {
        probeAll(true).then(function (result) { sendResponse({ ok:true, result:result, health:snapshot() }); }).catch(function (err) { sendResponse({ ok:false, error:{ code:err && err.code || "SEND_SAFETY_PROBE_FAILED", message:err && err.message || String(err) } }); });
        return true;
      }
    });
  } catch (_) {}

  function incomingBody(payload){var data=payload&&payload.data||payload||{};return String(data.body||data.text||data.caption||data.message||"").trim();}
  function incomingRecipient(payload){var data=payload&&payload.data||payload||{};return data.from&&data.from._serialized||data.from||data.author&&data.author._serialized||data.author||payload&&payload.author||"";}
  function looksLikeOptOut(text){var t=String(text||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9 ]+/g," ").replace(/\s+/g," ").trim();if(!t||t.length>180)return false;return /^(?:pare|parar|sair|stop|cancelar|remover|remova)$/.test(t)||/(?:nao quero (?:mais )?receber|nao me (?:mande|envie)|pare de (?:mandar|enviar)|remova (?:meu )?(?:numero|contato)|quero sair|descadastrar)/.test(t);}
  var optOutPrompted=new Map(),OPT_OUT_PROMPT_TTL_MS=10*60*1000,OPT_OUT_PROMPT_CACHE_MAX=256;
  function rememberOptOutPrompt(key,now){var cutoff=now-OPT_OUT_PROMPT_TTL_MS;optOutPrompted.forEach(function(ts,k){if(!Number.isFinite(ts)||ts<cutoff)optOutPrompted.delete(k);});optOutPrompted.set(key,now);while(optOutPrompted.size>OPT_OUT_PROMPT_CACHE_MAX){var oldest=optOutPrompted.keys().next().value;optOutPrompted.delete(oldest);}}
  function bindOptOutAssistant(){var bus=window.__extEventBus;if(!bus||typeof bus.on!=="function")return false;bus.on("MessageReceived",function(payload){Promise.resolve().then(async function(){var text=incomingBody(payload),recipient=incomingRecipient(payload);if(!recipient||!looksLikeOptOut(text))return;var key=recipientKey(recipient),now=Date.now(),prev=optOutPrompted.get(key)||0;if(now-prev<OPT_OUT_PROMPT_TTL_MS)return;rememberOptOutPrompt(key,now);if(await isRecipientSuppressed(recipient))return;var message="O contato parece ter pedido para não receber mensagens. Adicionar à lista Não contatar?";try{if(typeof window.extConfirm==="function"){if(await window.extConfirm(message,{danger:false})){await addSuppressedRecipient(recipient);if(typeof window.__extNotify==="function")window.__extNotify("Contato adicionado à lista Não contatar.",false);}}else{window.dispatchEvent(new CustomEvent("ext:send-safety-optout-suggestion",{detail:{recipientDigest:await suppressionDigestFor(recipient)}}));}}catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("SEND_SAFETY_OPTOUT_ASSIST_FAILED",err);}});});return true;}
  var optOutBindAttempts=0,optOutBindTimer=setInterval(function(){optOutBindAttempts++;if(bindOptOutAssistant()||optOutBindAttempts>30)clearInterval(optOutBindTimer);},500);

  try {
    window.addEventListener("ext:wpp-readiness", function () {
      lastProbe = null;
      lastProbeAt = 0;
      lastSession = null;
      lastSessionAt = 0;
      emitHealth();
    });
  } catch (_) {}

  setTimeout(function () { probeCompatibility(false).catch(function () {}); }, 2500);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
