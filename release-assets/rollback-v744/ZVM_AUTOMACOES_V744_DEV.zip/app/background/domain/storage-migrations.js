(function (root) {
  "use strict";
  if (root.__extStorageMigrations) return;
  var schema = root.__extStorageSchema;

  function schemaHas(key) {
    return !!(schema && schema.byKey && schema.byKey[String(key || "")]);
  }
  function historicalKeyTransform(key) {
    key = String(key || "");
    if (schemaHas(key) || key === "ext:bulkQueue") return key;
    var colon = key.indexOf(":");
    if (colon < 1 || colon > 16) return key;
    var tail = key.slice(colon + 1);
    var exact = "EXTUI:" + tail;
    if (schemaHas(exact)) return exact;
    var appMatch = /^([a-z]{2,12})([A-Z][A-Za-z0-9_]*)$/.exec(tail);
    if (appMatch) {
      var appCandidate = "EXTUI:extapp" + appMatch[2];
      if (schemaHas(appCandidate)) return appCandidate;
    }
    return key;
  }
  function historicalValueTransform(key, value) {
    function normalizeMediaRef(input) {
      return input.replace(/(^|[^A-Za-z0-9_-])([a-z]{2,12})-media:([A-Za-z0-9_-]{8,96})/g, function (all, before, owner, id) {
        if (owner === "extapp") return all;
        return before + "extapp-media:" + id;
      });
    }
    function mapValue(input, depth) {
      if (depth > 10 || input == null) return input;
      if (typeof input === "string") return normalizeMediaRef(input);
      if (Array.isArray(input)) {
        var changedArray = false, mapped = new Array(input.length);
        for (var i = 0; i < input.length; i++) { mapped[i] = mapValue(input[i], depth + 1); if (mapped[i] !== input[i]) changedArray = true; }
        return changedArray ? mapped : input;
      }
      if (typeof input === "object") {
        var proto = Object.getPrototypeOf(input);
        if (proto !== Object.prototype && proto !== null) return input;
        var changedObject = false, copy = {};
        Object.keys(input).forEach(function (name) { var mappedValue = mapValue(input[name], depth + 1); Object.defineProperty(copy, name, { value: mappedValue, enumerable: true, writable: true, configurable: true }); if (mappedValue !== input[name]) changedObject = true; });
        return changedObject ? copy : input;
      }
      return input;
    }
    return mapValue(value, 0);
  }
  async function migrateHistoricalNamespace(storage) {
    if (!storage || typeof storage.get !== "function" || typeof storage.set !== "function") return { moved: 0 };
    var all = await storage.get(null), write = Object.create(null), remove = [], moved = 0;
    Object.keys(all || {}).forEach(function (key) {
      var next = historicalKeyTransform(key), value = historicalValueTransform(next, all[key]);
      if (next === key && value === all[key]) return;
      if (next !== key && Object.prototype.hasOwnProperty.call(all, next)) return;
      Object.defineProperty(write, next, { value: value, enumerable: true, writable: true, configurable: true }); if (next !== key) remove.push(key); moved++;
    });
    if (Object.keys(write).length) await storage.set(write);
    if (remove.length && typeof storage.remove === "function") await storage.remove(remove);
    return { moved: moved };
  }
  async function runAll(storage) {
    if (!storage || typeof storage.get !== "function") throw new Error("A extensão recebeu uma configuração inválida para acessar os dados");
    var namespaceMigration = await migrateHistoricalNamespace(storage);
    return { schemaVersion: schema && schema.schemaVersion || 1, results: [namespaceMigration], ledger: null };
  }
  root.__extStorageMigrations = Object.freeze({ version: "5.0.0", definitions: [], runAll: runAll });
  try {
    var jobs = [];
    if (root.chrome && chrome.storage && chrome.storage.local) jobs.push(runAll(chrome.storage.local));
    if (root.chrome && chrome.storage && chrome.storage.session) jobs.push(runAll(chrome.storage.session));
    root.__extNamespaceMigrationReady = Promise.all(jobs).catch(function (error) {
      if (root.__extReportRuntimeError) root.__extReportRuntimeError("STORAGE_NAMESPACE_MIGRATION_FAILED", error);
      throw error;
    });
  } catch (error) {
    if (root.__extReportRuntimeError) root.__extReportRuntimeError("STORAGE_NAMESPACE_MIGRATION_BOOT_FAILED", error);
    root.__extNamespaceMigrationReady = Promise.reject(error);
    root.__extNamespaceMigrationReady.catch(function () {});
  }
})(typeof self !== "undefined" ? self : globalThis);;
