(function (root) {
  "use strict";

  var core = root.__extKnowledgeCore;
  var idbApi = root.__extKnowledgeIdb;
  var integrationCore = root.__extIntegrationCore;
  var providers = root.__extIntegrationProviders;

  function createRuntime(dependencies) {
    var storage = dependencies.storage;
    var repository = dependencies.repository;
    var fetchImpl = dependencies.fetch;
    var now = dependencies.now || Date.now;
    var createId = dependencies.createId || function () { return core.createUuid(dependencies.crypto); };
    var emitProgress = dependencies.emitProgress || function () {};
    var writeQueue = Promise.resolve();
    var indexJobs = new Map();
    var retrievals = new Map();
    var MAX_CONCURRENT_INDEX_JOBS = 2;
    var MAX_CONCURRENT_RETRIEVALS = 16;
    var reconcilePromise = null;
    function notify(progress) { try { emitProgress(progress); } catch (error) {} }

    function serialize(operation) {
      var job = writeQueue.catch(function () {}).then(operation);
      writeQueue = job.catch(function () {}); return job;
    }
    async function readValues(keys) { return storage.get(keys); }
    async function readStore() { var values = await readValues(core.STORE_KEY); return core.normalizeStore(values && values[core.STORE_KEY]); }
    async function writeStore(store) { var payload = {}; payload[core.STORE_KEY] = core.serializeStore(store); await storage.set(payload); return store; }
    async function mutateStore(operation) {
      return serialize(async function () { var current = await readStore(); var outcome = operation(current); await writeStore(outcome.store || outcome); return outcome; });
    }
    function jobStateIsActive(job) { return !!(job && [core.JOB_STATES.PREPARING, core.JOB_STATES.EMBEDDING, core.JOB_STATES.SAVING].indexOf(job.state) >= 0); }
    function reconcileInterruptedJobs() {
      if (reconcilePromise) return reconcilePromise;
      reconcilePromise = serialize(async function () {
        var store = await readStore(); var changed = false; var stamp = now();
        store.bases = store.bases.map(function (base) {
          if (!jobStateIsActive(base.job)) return base;
          if (indexJobs.has(base.id) && indexJobs.get(base.id).jobId === base.job.jobId) return base;
          changed = true;
          return core.normalizeBase(Object.assign({}, base, {
            status: base.activeIndex ? core.STATUSES.ATTENTION : core.STATUSES.ERROR,
            pendingChanges: true, lastErrorCode: core.ERRORS.INTERRUPTED, updatedAt: stamp,
            job: Object.assign({}, base.job, { state: core.JOB_STATES.FAILED, updatedAt: stamp, errorCode: core.ERRORS.INTERRUPTED })
          }));
        });
        if (changed) await writeStore(store);
        return { changed: changed, store: store };
      }).catch(function (error) { reconcilePromise = null; throw error; });
      return reconcilePromise;
    }
    function requireBase(store, baseId) {
      var base = core.findBase(store, baseId);
      if (!base) throw core.error(core.ERRORS.BASE_NOT_FOUND, "Base de Conhecimento não encontrada.");
      return base;
    }
    function replaceBase(store, baseId, transform) {
      var index = store.bases.findIndex(function (base) { return base.id === baseId; });
      if (index < 0) throw core.error(core.ERRORS.BASE_NOT_FOUND, "Base de Conhecimento não encontrada.");
      store.bases[index] = core.normalizeBase(transform(store.bases[index])); return store.bases[index];
    }
    async function getState() { await reconcileInterruptedJobs(); return readStore(); }
    async function createBase(draft) {
      return mutateStore(function (store) { return core.createBase(store, draft, { createId: createId, now: now }); });
    }
    async function updateBase(baseId, draft) {
      return mutateStore(function (store) { return core.updateBase(store, baseId, draft, { now: now }); });
    }
                                                                          
                                                                          
                                                                            
    async function setBaseAcl(baseId, allowedAgentIds) {
      return mutateStore(function (store) { return core.setBaseAllowedAgents(store, baseId, allowedAgentIds, { now: now }); });
    }
    function publicDocument(document, includeContent) {
      var result = Object.assign({}, document);
      if (!includeContent) { delete result.text; delete result.pages; }
      return result;
    }
    async function listDocuments(baseId) {
      var store = await readStore(); requireBase(store, baseId);
      return (await repository.listDocuments(baseId)).map(function (document) { return publicDocument(document, false); });
    }
    async function getDocument(baseId, documentId) {
      var store = await readStore(); requireBase(store, baseId); var document = await repository.getDocument(documentId);
      if (!document || document.baseId !== baseId) throw core.error(core.ERRORS.BASE_NOT_FOUND, "Fonte não encontrada.");
      return publicDocument(document, true);
    }
    async function previewIndex(baseId) {
      var store = await readStore(); requireBase(store, baseId); var documents = await repository.listDocuments(baseId);
      var chunks = core.chunkDocuments(documents, "preview", { createId: createId });
      return { documentCount: documents.length, chunkCount: chunks.length, totalChars: core.validateDocumentLimits(documents).totalChars };
    }
    async function saveDocument(baseId, rawDocument) {
      var store = await readStore(); requireBase(store, baseId);
      var existing = rawDocument && rawDocument.id ? await repository.getDocument(rawDocument.id) : null;
      if (existing && existing.baseId !== baseId) throw core.error(core.ERRORS.BASE_NOT_FOUND, "A fonte não pertence a esta base.");
      var document = core.createDocument(baseId, Object.assign({}, rawDocument, { createdAt: existing && existing.createdAt }), { createId: createId, now: now });
      var documents = await repository.listDocuments(baseId);
      var projected = documents.filter(function (entry) { return entry.id !== document.id; }).concat(document);
      core.validateDocumentLimits(projected);
      await repository.putDocument(document);
      await mutateStore(function (fresh) {
        requireBase(fresh, baseId);
        replaceBase(fresh, baseId, function (base) { return Object.assign({}, base, {
          documentCount: projected.length, pendingChanges: true,
          status: base.activeIndex ? core.STATUSES.ATTENTION : core.STATUSES.EMPTY,
          updatedAt: now(), lastErrorCode: null
        }); });
        return fresh;
      });
      return document;
    }
    async function removeDocument(baseId, documentId) {
      var store = await readStore(); requireBase(store, baseId);
      var document = await repository.getDocument(documentId);
      if (!document || document.baseId !== baseId) throw core.error(core.ERRORS.BASE_NOT_FOUND, "Fonte não encontrada.");
      await repository.removeDocument(documentId);
      var documents = await repository.listDocuments(baseId);
      await mutateStore(function (fresh) {
        replaceBase(fresh, baseId, function (base) { return Object.assign({}, base, {
          documentCount: documents.length, pendingChanges: true,
          status: base.activeIndex ? core.STATUSES.ATTENTION : core.STATUSES.EMPTY,
          updatedAt: now(), lastErrorCode: null
        }); }); return fresh;
      });
      return { removed: true, documentId: documentId };
    }
    async function countAssistantReferences(baseId) {
      var assistantCore = root.__extAiAssistantsCore;
      if (!assistantCore) return 0;
      var values = await readValues(assistantCore.STORE_KEY);
      return assistantCore.normalizeStore(values && values[assistantCore.STORE_KEY]).assistants.filter(function (assistant) {
        return assistant.knowledge && assistant.knowledge.mode === "base" && assistant.knowledge.baseId === baseId;
      }).length;
    }
    async function deleteBase(baseId) {
      var references = await countAssistantReferences(baseId);
      var removed = await mutateStore(function (store) { return core.removeBase(store, baseId); });
      try { await repository.deleteBase(baseId); }
      catch (deleteError) {
        await mutateStore(function (store) { if (!core.findBase(store, baseId)) store.bases.push(removed.base); return store; });
        throw deleteError;
      }
      return { deleted: true, baseId: baseId, assistantReferences: references };
    }
    async function referenceCount(baseId) { var store = await readStore(); requireBase(store, baseId); return { count: await countAssistantReferences(baseId) }; }

    async function integrationAccess(providerId) {
      var values = await readValues([integrationCore.STORE_KEY, integrationCore.SECRETS_KEY]);
      var metadata = integrationCore.normalizeStore(values && values[integrationCore.STORE_KEY]).providers[providerId];
      var secret = integrationCore.normalizeSecrets(values && values[integrationCore.SECRETS_KEY]).providers[providerId];
      var adapter = providers.get(providerId);
      if (!integrationCore.providerHasCapability(providerId, "busca inteligente") || !adapter || typeof adapter.embedTexts !== "function" || !secret || !secret.apiKey || !metadata || metadata.enabled !== true || metadata.status !== integrationCore.STATUSES.CONNECTED) {
        throw core.error(core.ERRORS.PROVIDER_UNAVAILABLE, "Configure " + (providerId === "gemini" ? "Google Gemini" : "OpenAI") + " antes de preparar a busca desta base.");
      }
      return { metadata: metadata, secret: secret, adapter: adapter };
    }
    function assertNotCancelled(record) {
      if (record.controller.signal.aborted) throw core.error(core.ERRORS.CANCELLED, "A preparação da busca foi cancelada.");
    }
    async function updateJob(baseId, jobId, state, completed, total, errorCode) {
      var result = await mutateStore(function (store) {
        var base = replaceBase(store, baseId, function (current) { return Object.assign({}, current, {
          status: state === core.JOB_STATES.PREPARING ? core.STATUSES.PREPARING : state === core.JOB_STATES.EMBEDDING || state === core.JOB_STATES.SAVING ? core.STATUSES.INDEXING : current.status,
          job: { jobId: jobId, state: state, completed: completed, total: total, updatedAt: now(), errorCode: errorCode || null }, updatedAt: now()
        }); }); return { store: store, base: base };
      });
      notify({ baseId: baseId, jobId: jobId, state: state, completed: completed, total: total, errorCode: errorCode || null });
      return result.base;
    }
    async function embedChunks(base, chunks, record) {
      var access = await integrationAccess(base.embeddingProviderId); var vectors = [];
      for (var offset = 0; offset < chunks.length; offset += core.LIMITS.EMBEDDING_BATCH_SIZE) {
        assertNotCancelled(record);
        var batch = chunks.slice(offset, offset + core.LIMITS.EMBEDDING_BATCH_SIZE);
        var result;
        try {
          result = await access.adapter.embedTexts({ apiKey: access.secret.apiKey }, {
            model: base.embeddingModel, purpose: "document",
            items: batch.map(function (chunk) { return { title: chunk.sourceTitle, text: chunk.text }; })
          }, { fetch: fetchImpl, signal: record.controller.signal, timeoutMs: providers.DEFAULT_EMBEDDING_TIMEOUT_MS });
        } catch (embeddingError) {
          if (record.controller.signal.aborted || embeddingError && embeddingError.code === "ai_cancelled") throw core.error(core.ERRORS.CANCELLED, "A preparação da busca foi cancelada.");
          if (embeddingError && embeddingError.code === core.ERRORS.EMBEDDING_FAILED) throw embeddingError;
          throw core.error(core.ERRORS.EMBEDDING_FAILED, "Não foi possível gerar os embeddings da base.");
        }
        var validated = core.validateVectors(result && result.vectors, batch.length, core.EMBEDDING_DIMENSIONS);
        vectors = vectors.concat(validated.vectors);
        await updateJob(base.id, record.jobId, core.JOB_STATES.EMBEDDING, vectors.length, chunks.length);
      }
      return vectors;
    }
    async function indexBase(baseId, requestedJobId) {
      await reconcileInterruptedJobs();
      var jobId = requestedJobId || createId();
      if (indexJobs.has(baseId)) throw core.error("KNOWLEDGE_INDEX_CONFLICT", "Esta base já está sendo preparada para busca.");
      if (indexJobs.size >= MAX_CONCURRENT_INDEX_JOBS) throw core.error(core.ERRORS.LIMIT_EXCEEDED, "Aguarde a preparação de outra Base de Conhecimento terminar.");
      var record = { jobId: jobId, controller: new AbortController() }; indexJobs.set(baseId, record);
      var previousIndex = null;
      var stagedRevision = null;
      try {
        var store = await readStore(); var base = requireBase(store, baseId); previousIndex = base.activeIndex;
        await updateJob(baseId, jobId, core.JOB_STATES.PREPARING, 0, 0);
        await integrationAccess(base.embeddingProviderId); assertNotCancelled(record);
        var documents = await repository.listDocuments(baseId);
        core.validateDocumentLimits(documents);
        if (!documents.length) throw core.error(core.ERRORS.BASE_NOT_READY, "Adicione ao menos uma fonte antes de preparar a busca.");
        var revision = createId();
        var chunks = core.chunkDocuments(documents, revision, { createId: createId });
        if (!chunks.length) throw core.error(core.ERRORS.BASE_NOT_READY, "Nenhum texto válido foi encontrado para preparar a busca.");
        await updateJob(baseId, jobId, core.JOB_STATES.EMBEDDING, 0, chunks.length);
        var vectors = await embedChunks(base, chunks, record); assertNotCancelled(record);
        chunks.forEach(function (chunk, index) { chunk.vector = vectors[index]; });
        await updateJob(baseId, jobId, core.JOB_STATES.SAVING, chunks.length, chunks.length);
        var revisionRecord = {
          baseId: baseId, revision: revision, embeddingProviderId: base.embeddingProviderId,
          embeddingModel: base.embeddingModel, dimensions: vectors[0].length, chunkCount: chunks.length, createdAt: now()
        };
        stagedRevision = revision;
        await repository.saveRevision(revisionRecord, chunks); assertNotCancelled(record);
        var counts = Object.create(null); chunks.forEach(function (chunk) { counts[chunk.documentId] = (counts[chunk.documentId] || 0) + 1; });
        for (var i = 0; i < documents.length; i++) await repository.putDocument(Object.assign({}, documents[i], { chunkCount: counts[documents[i].id] || 0, status: "indexed", updatedAt: now() }));
        await mutateStore(function (fresh) {
          replaceBase(fresh, baseId, function (current) { return Object.assign({}, current, {
            status: core.STATUSES.READY, documentCount: documents.length, chunkCount: chunks.length,
            pendingChanges: false, activeIndex: {
              revision: revision, embeddingProviderId: base.embeddingProviderId, embeddingModel: base.embeddingModel,
              dimensions: vectors[0].length, chunkCount: chunks.length, indexedAt: now()
            }, indexedAt: now(), job: { jobId: jobId, state: core.JOB_STATES.COMPLETE, completed: chunks.length, total: chunks.length, updatedAt: now(), errorCode: null },
            updatedAt: now(), lastErrorCode: null
          }); }); return fresh;
        });
        stagedRevision = null;
        notify({ baseId: baseId, jobId: jobId, state: core.JOB_STATES.COMPLETE, completed: chunks.length, total: chunks.length });
        if (previousIndex && previousIndex.revision !== revision) { try { await repository.deleteRevision(baseId, previousIndex.revision); } catch (cleanupError) {} }
        return { jobId: jobId, revision: revision, chunkCount: chunks.length, dimensions: vectors[0].length };
      } catch (jobError) {
        if (stagedRevision) { try { await repository.deleteRevision(baseId, stagedRevision); } catch (cleanupError) {} }
        var cancelled = jobError && jobError.code === core.ERRORS.CANCELLED;
        var code = cancelled ? core.ERRORS.CANCELLED : jobError && jobError.code || core.ERRORS.EMBEDDING_FAILED;
        await mutateStore(function (fresh) {
          var existing = core.findBase(fresh, baseId); if (!existing) return fresh;
          replaceBase(fresh, baseId, function (current) { return Object.assign({}, current, {
            status: current.activeIndex ? core.STATUSES.ATTENTION : (cancelled ? core.STATUSES.EMPTY : core.STATUSES.ERROR),
            pendingChanges: true, lastErrorCode: code,
            job: { jobId: jobId, state: cancelled ? core.JOB_STATES.CANCELLED : core.JOB_STATES.FAILED, completed: current.job && current.job.completed || 0, total: current.job && current.job.total || 0, updatedAt: now(), errorCode: code }, updatedAt: now()
          }); }); return fresh;
        });
        notify({ baseId: baseId, jobId: jobId, state: cancelled ? core.JOB_STATES.CANCELLED : core.JOB_STATES.FAILED, errorCode: code });
        throw jobError;
      } finally { if (indexJobs.get(baseId) === record) indexJobs.delete(baseId); }
    }
    function cancelIndex(baseId, jobId) {
      var record = indexJobs.get(baseId);
      if (!record || jobId && record.jobId !== jobId) return { cancelled: false };
      record.controller.abort(); return { cancelled: true, jobId: record.jobId };
    }

    async function retrieveKnowledge(rawRequest) {
      await reconcileInterruptedJobs();
      rawRequest = rawRequest || {}; var requestId = String(rawRequest.requestId || "").trim();
      if (!requestId || !String(rawRequest.executionId || "").trim()) throw core.error(core.ERRORS.RETRIEVAL_FAILED, "A solicitação de Knowledge é inválida.");
      if (retrievals.has(requestId)) throw core.error(core.ERRORS.RETRIEVAL_FAILED, "Esta busca já está em andamento.");
      if (retrievals.size >= MAX_CONCURRENT_RETRIEVALS) throw core.error(core.ERRORS.LIMIT_EXCEEDED, "Há muitas consultas à Base de Conhecimento em andamento. Tente novamente em instantes.");
      var record = { controller: new AbortController(), executionId: String(rawRequest.executionId) }; retrievals.set(requestId, record);
      try {
        var store = await readStore(); var base = requireBase(store, String(rawRequest.baseId || ""));
        if (!core.isBaseReady(base)) throw core.error(core.ERRORS.BASE_NOT_READY, "A Base de Conhecimento precisa ter a busca preparada.");
        var access = await integrationAccess(base.activeIndex.embeddingProviderId);
        var revision = await repository.getRevision(base.id, base.activeIndex.revision);
        if (!revision || revision.embeddingProviderId !== base.activeIndex.embeddingProviderId || revision.embeddingModel !== base.activeIndex.embeddingModel || revision.dimensions !== base.activeIndex.dimensions) throw core.error(core.ERRORS.BASE_NOT_READY, "A revisão ativa da base é inválida.");
        var chunks = await repository.listChunks(base.id, revision.revision);
        if (chunks.length !== revision.chunkCount || chunks.some(function (chunk) { return !Array.isArray(chunk.vector) || chunk.vector.length !== revision.dimensions; })) throw core.error(core.ERRORS.BASE_NOT_READY, "A revisão ativa da base é inválida.");
        var query = core.normalizeText(rawRequest.query);
        if (!query) throw core.error(core.ERRORS.RETRIEVAL_FAILED, "A consulta de Knowledge está vazia.");
        var embedding;
        try {
          embedding = await access.adapter.embedTexts({ apiKey: access.secret.apiKey }, { model: revision.embeddingModel, purpose: "query", items: [{ text: query }] }, { fetch: fetchImpl, signal: record.controller.signal, timeoutMs: providers.DEFAULT_EMBEDDING_TIMEOUT_MS });
        } catch (embeddingError) {
          if (record.controller.signal.aborted || embeddingError && embeddingError.code === "ai_cancelled") throw core.error(core.ERRORS.CANCELLED, "A busca foi cancelada.");
          throw core.error(core.ERRORS.EMBEDDING_FAILED, "Não foi possível preparar a busca desta consulta.");
        }
        var queryVector = core.validateVectors(embedding && embedding.vectors, 1, revision.dimensions).vectors[0];
        if (record.controller.signal.aborted) throw core.error(core.ERRORS.CANCELLED, "A busca foi cancelada.");
        var results = core.retrieve(chunks, queryVector, { topK: core.LIMITS.TOP_K, minSimilarity: core.LIMITS.MIN_SIMILARITY });
        return { baseId: base.id, baseName: base.name, knowledge: core.sanitizeRetrieved(results), count: results.length };
      } catch (retrievalError) {
        if (retrievalError && [core.ERRORS.BASE_NOT_FOUND, core.ERRORS.BASE_NOT_READY, core.ERRORS.PROVIDER_UNAVAILABLE, core.ERRORS.EMBEDDING_FAILED, core.ERRORS.CANCELLED].indexOf(retrievalError.code) >= 0) throw retrievalError;
        throw core.error(core.ERRORS.RETRIEVAL_FAILED, "Não foi possível consultar a Base de Conhecimento.");
      } finally { if (retrievals.get(requestId) === record) retrievals.delete(requestId); }
    }
    function cancelRetrieval(requestId, executionId) {
      var record = retrievals.get(requestId);
      if (!record || executionId && record.executionId !== executionId) return { cancelled: false };
      record.controller.abort(); return { cancelled: true, requestId: requestId };
    }
    function userMessage(error) {
      var messages = {};
      messages[core.ERRORS.BASE_NOT_FOUND] = "A Base de Conhecimento não foi encontrada.";
      messages[core.ERRORS.BASE_NOT_READY] = "A Base de Conhecimento requer atenção.";
      messages[core.ERRORS.PROVIDER_UNAVAILABLE] = "O serviço usado para preparar a busca da base não está disponível.";
      messages[core.ERRORS.EMBEDDING_FAILED] = "Não foi possível gerar os embeddings da Base de Conhecimento.";
      messages[core.ERRORS.RETRIEVAL_FAILED] = "Não foi possível consultar a Base de Conhecimento.";
      messages[core.ERRORS.INTERRUPTED] = "A preparação da Base de Conhecimento foi interrompida e precisa ser iniciada novamente.";
      messages[core.ERRORS.CANCELLED] = "A operação de Knowledge foi cancelada.";
      return messages[error && error.code] || error && error.message || "Não foi possível concluir a operação de Knowledge.";
    }
    async function handle(message) {
      try {
        var result;
        if (message.type === "EXTUI_KNOWLEDGE_GET_STATE") result = await getState();
        else if (message.type === "EXTUI_KNOWLEDGE_CREATE_BASE") result = await createBase(message.base);
        else if (message.type === "EXTUI_KNOWLEDGE_UPDATE_BASE") result = await updateBase(message.baseId, message.base);
        else if (message.type === "EXTUI_KNOWLEDGE_SET_BASE_ACL") result = await setBaseAcl(message.baseId, message.allowedAgentIds);
        else if (message.type === "EXTUI_KNOWLEDGE_LIST_DOCUMENTS") result = await listDocuments(message.baseId);
        else if (message.type === "EXTUI_KNOWLEDGE_GET_DOCUMENT") result = await getDocument(message.baseId, message.documentId);
        else if (message.type === "EXTUI_KNOWLEDGE_INDEX_PREVIEW") result = await previewIndex(message.baseId);
        else if (message.type === "EXTUI_KNOWLEDGE_SAVE_DOCUMENT") result = await saveDocument(message.baseId, message.document);
        else if (message.type === "EXTUI_KNOWLEDGE_REMOVE_DOCUMENT") result = await removeDocument(message.baseId, message.documentId);
        else if (message.type === "EXTUI_KNOWLEDGE_REFERENCE_COUNT") result = await referenceCount(message.baseId);
        else if (message.type === "EXTUI_KNOWLEDGE_DELETE_BASE") result = await deleteBase(message.baseId);
        else if (message.type === "EXTUI_KNOWLEDGE_INDEX_START") result = await indexBase(message.baseId, message.jobId);
        else if (message.type === "EXTUI_KNOWLEDGE_INDEX_CANCEL") result = cancelIndex(message.baseId, message.jobId);
        else if (message.type === "EXTUI_KNOWLEDGE_RETRIEVE") result = await retrieveKnowledge(message.request);
        else if (message.type === "EXTUI_KNOWLEDGE_RETRIEVAL_CANCEL") result = cancelRetrieval(message.requestId, message.executionId);
        else return null;
        return { ok: true, result: result };
      } catch (runtimeError) {
        return { ok: false, errorCode: runtimeError && runtimeError.code || core.ERRORS.RETRIEVAL_FAILED, userMessage: userMessage(runtimeError), retryable: false };
      }
    }
    return Object.freeze({ handle: handle, getState: getState, indexBase: indexBase, retrieve: retrieveKnowledge, cancelIndex: cancelIndex, cancelRetrieval: cancelRetrieval, pendingIndexCount: function () { return indexJobs.size; }, pendingRetrievalCount: function () { return retrievals.size; } });
  }

  if (root.chrome && chrome.runtime && chrome.storage && root.indexedDB && typeof fetch === "function") {
    var runtime = createRuntime({
      storage: chrome.storage.local, repository: idbApi.createRepository(indexedDB), fetch: fetch.bind(root), now: Date.now,
      createId: function () { return core.createUuid(root.crypto); },
      emitProgress: function (progress) { chrome.runtime.sendMessage({ type: "EXTUI_KNOWLEDGE_INDEX_PROGRESS", progress: progress }, function () { void chrome.runtime.lastError; }); }
    });
    function senderPolicy() { var policy = root.__extSenderPolicy; return policy && typeof policy.isExtensionPage === "function" && typeof policy.isWhatsApp === "function" ? policy : null; }
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      if (!message || typeof message.type !== "string" || message.type.indexOf("EXTUI_KNOWLEDGE_") !== 0 || message.type === "EXTUI_KNOWLEDGE_INDEX_PROGRESS") return;
      var retrieval = message.type === "EXTUI_KNOWLEDGE_RETRIEVE" || message.type === "EXTUI_KNOWLEDGE_RETRIEVAL_CANCEL";
      var policy = senderPolicy();
      var allowed = !!(policy && (retrieval ? (policy.isExtensionPage(sender) || policy.isWhatsApp(sender)) : policy.isExtensionPage(sender)));
      if (!allowed) { sendResponse({ ok: false, errorCode: "UNAUTHORIZED_SENDER", userMessage: "Esta operação não é permitida neste contexto." }); return; }
      Promise.resolve().then(function () { return extServerAuthorityRequire("ai.agents"); }).then(function () { return extPlanRequirePaidBg("assistentes-ia"); }).then(function () { return runtime.handle(message); }).then(sendResponse).catch(function (error) { sendResponse({ ok: false, errorCode: error && error.code || "EXTENSION_INTEGRITY_FAILED", userMessage: error && error.message || "A instalação da extensão não passou na verificação de integridade." }); }); return true;
    });
  }
})(typeof globalThis !== "undefined" ? globalThis : this);

