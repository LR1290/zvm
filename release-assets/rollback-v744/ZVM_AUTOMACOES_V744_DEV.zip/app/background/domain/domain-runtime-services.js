(function (root) {
  "use strict";
  var core = root.__extIntegrationCore;
  var providers = root.__extIntegrationProviders;
  var toolsRegistry = root.__extAiToolsRegistry;
  var assistantsCore = root.__extAiAssistantsCore;
  var agentsCore = root.__extAiAgentsCore;
  var crmCore = root.__extCrmProfessionalCore;
  var memoryCore = root.__extAiMemoryCore;
  var externalActionsCore = root.__extExternalActionsCore;

  function createRuntime(dependencies) {
    var storage = dependencies.storage;
    var fetchImpl = dependencies.fetch;
    var now = dependencies.now || Date.now;
    var timeoutMs = dependencies.timeoutMs || providers.DEFAULT_TIMEOUT_MS;
    var generationTimeoutMs = dependencies.generationTimeoutMs || providers.DEFAULT_GENERATION_TIMEOUT_MS;
                                                                              
                                                                        
                                                  
    var permissionsContains = dependencies.permissionsContains || function () { return Promise.resolve(false); };
    var permissionPattern = dependencies.permissionPattern || function (value) { var url = new URL(String(value || "")); return "https://" + url.hostname + "/*"; };
    var externalActionTimeoutMs = dependencies.externalActionTimeoutMs || (externalActionsCore && externalActionsCore.REQUEST_TIMEOUT_MS) || 20000;
    var writeQueue = Promise.resolve();
    var crmStateWriteQueue = Promise.resolve();
    var pendingAiRequests = new Map();
    var MAX_CONCURRENT_AI_REQUESTS = 16;
    var agentRunLedgers = new Map();
    var AGENT_CONTROL_TOOL_ID = "extui_agent_control";
    var AGENT_LEDGER_TTL_MS = 5 * 60 * 1000;
    var AGENT_CONTROL_DEFINITION = Object.freeze({
      id: AGENT_CONTROL_TOOL_ID,
      label: "Controle interno do agente",
      description: "Finaliza a etapa atual do Agent. Use complete assim que o objetivo estiver concluído; use continue somente quando houver trabalho concreto restante.",
      category: "internal",
      risk: "read",
      parametersSchema: {
        type: "object",
        properties: {
          action: { type: "string", enum: ["continue", "complete"] },
          finalText: { type: "string", maxLength: 60000, description: "Resposta final ao cliente quando action=complete." },
          summary: { type: "string", maxLength: 1200, description: "Fatos operacionais mínimos para a próxima etapa; nunca inclua raciocínio." }
        },
        required: ["action"],
        additionalProperties: false
      }
    });

    function readKey(key) { return storage.get(key).then(function (stored) { return stored && stored[key]; }); }
    function writeKey(key, value) { var payload = {}; payload[key] = value; return storage.set(payload); }
    function createId(prefix) {
      if (root.crypto && typeof root.crypto.randomUUID === "function") return root.crypto.randomUUID();
      return (prefix || "extui") + "-" + now() + "-" + Math.random().toString(36).slice(2, 12);
    }
    var professionalRepository = crmCore && crmCore.createRepository ? crmCore.createRepository({
      read: function (key) { return readKey(key); },
      write: function (key, value) { return writeKey(key, value); },
      now: now,
      idFactory: function (prefix) { return createId(prefix); }
    }) : null;
    var memoryRepository = memoryCore && memoryCore.createRepository ? memoryCore.createRepository({
      read: function () { return readKey(memoryCore.STORE_KEY); },
      write: function (value) { return writeKey(memoryCore.STORE_KEY, value); },
      createId: function () { return createId("memory"); },
      now: now
    }) : null;

    function mutateCrmState(mutator) {
      var job = crmStateWriteQueue.catch(function () {}).then(async function () {
        var currentRaw = await readKey(toolsRegistry.CRM_STORE_KEY);
        var outcome = await mutator(currentRaw);
        if (!outcome || !outcome.store) throw new Error("CRM mutation did not return a store");
        await writeKey(toolsRegistry.CRM_STORE_KEY, JSON.stringify({ state: crmCore.normalizeCrmState(outcome.store), version: 0 }));
        return outcome;
      });
      crmStateWriteQueue = job.catch(function () {});
      return job;
    }
    function recordColumnEvent(event) {
      var authority = root.__extColumnEventQueueAuthority;
      if (!authority || typeof authority.enqueue !== "function") {
        var unavailable = new Error("A autoridade da fila de eventos do CRM não está disponível.");
        unavailable.code = "CRM_COLUMN_EVENT_QUEUE_UNAVAILABLE";
        return Promise.reject(unavailable);
      }
      return authority.enqueue({ crmId: event && event.crmId, columnId: event && event.columnId, contactId: event && event.contactId, atMs: now() });
    }
    function applyProfessionalOperation(operation) {
      if (typeof root.__extCrmProfessionalMutate === "function") return root.__extCrmProfessionalMutate(operation);
      if (!professionalRepository) return Promise.reject(new Error("CRM Professional Core unavailable"));
      return professionalRepository.apply(operation);
    }
    function toolDependencies(assistantId, signal) {
      return {
        now: now,
        readCrmState: function () { return readKey(toolsRegistry.CRM_STORE_KEY); },
        mutateCrmState: mutateCrmState,
        readProfessionalStore: function () { return readKey(crmCore.STORE_KEY); },
        applyProfessionalOperation: applyProfessionalOperation,
        recordColumnEvent: recordColumnEvent,
        addMemory: function (subjectKey, draft) {
          if (!memoryRepository) return Promise.reject(new Error("Memory Core unavailable"));
          return memoryRepository.add(subjectKey, draft);
        },
        runExternalAction: runExternalActionForAssistant(assistantId, signal)
      };
    }

    function strictProviderStore(raw, code, message) {
      if (raw == null || raw === "") return null;
      var parsed = raw;
      if (typeof parsed === "string") {
        try { parsed = JSON.parse(parsed); }
        catch (_) { var parseError = new Error(message); parseError.code = code; throw parseError; }
      }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) { var objectError = new Error(message); objectError.code = code; throw objectError; }
      var source = parsed.state && typeof parsed.state === "object" && !Array.isArray(parsed.state) ? parsed.state : parsed;
      if (!source.providers || typeof source.providers !== "object" || Array.isArray(source.providers)) { var shapeError = new Error(message); shapeError.code = code; throw shapeError; }
      return parsed;
    }
    async function readAll() {
      var stored = await storage.get([core.STORE_KEY, core.SECRETS_KEY, core.WEBHOOKS_KEY]);
      var rawMetadata = strictProviderStore(stored[core.STORE_KEY], "INTEGRATION_STORE_CORRUPT", "A configuração dos serviços de IA está corrompida e foi preservada sem alterações.");
      var rawSecrets = strictProviderStore(stored[core.SECRETS_KEY], "INTEGRATION_SECRETS_CORRUPT", "As credenciais dos serviços de IA estão inválidas. Reconfigure a integração antes de alterar outras credenciais.");
      return { rawMetadata: rawMetadata, metadata: core.normalizeStore(rawMetadata), secrets: core.normalizeSecrets(rawSecrets), webhooks: stored[core.WEBHOOKS_KEY] };
    }
    function write(values) { return storage.set(values); }
    function serialize(operation) {
      var job = writeQueue.catch(function () {}).then(operation);
      writeQueue = job.catch(function () {});
      return job;
    }
    async function publicSnapshot() {
      var state = await readAll();
      return core.publicState(state.metadata, state.secrets, state.webhooks);
    }
    async function aiRoutingSnapshot() {
      var snapshot = await publicSnapshot(), source = snapshot && snapshot.providers || {}, providers = {};
      ["openai", "gemini", "xai"].forEach(function (id) {
        var item = source[id] || {};
        providers[id] = {
          configured: item.configured === true,
          enabled: item.enabled === true,
          status: typeof item.status === "string" ? item.status : "",
          model: typeof item.model === "string" ? item.model : null,
          availableModels: Array.isArray(item.availableModels) ? item.availableModels.map(function (model) {
            return model && typeof model.id === "string" ? { id: model.id, label: typeof model.label === "string" ? model.label : model.id } : null;
          }).filter(Boolean) : []
        };
      });
      return { providers: providers };
    }
    function requireProvider(providerId) {
      var adapter = providers.get(providerId);
      if (!adapter) { var error = new Error("provider_not_found"); error.code = "provider_not_found"; throw error; }
      return adapter;
    }
    async function configure(providerId, apiKey) {
      return serialize(async function () {
        var adapter = requireProvider(providerId);
        var validation = adapter.validateConfig({ apiKey: apiKey });
        if (!validation.valid) { var invalid = new Error(validation.errorCode); invalid.code = validation.errorCode; throw invalid; }
        var state = await readAll();
        var timestamp = now();
        state.secrets.providers[providerId] = { apiKey: validation.apiKey, updatedAt: timestamp };
        state.metadata.providers[providerId] = Object.assign({}, state.metadata.providers[providerId], { enabled: true, status: core.STATUSES.ATTENTION, updatedAt: timestamp, lastErrorCode: null });
        var payload = {}; payload[core.SECRETS_KEY] = state.secrets; payload[core.STORE_KEY] = state.metadata;
        await write(payload);
        return { configured: true, keyHint: core.maskSecret(validation.apiKey) };
      });
    }
    async function test(providerId) {
      var adapter = requireProvider(providerId);
      var state = await readAll();
      var secret = state.secrets.providers[providerId];
      if (!secret) { var missing = new Error("credential_missing"); missing.code = "credential_missing"; throw missing; }
      try {
        var result = await adapter.testConnection({ apiKey: secret.apiKey }, { fetch: fetchImpl, timeoutMs: timeoutMs });
        return await serialize(async function () {
          var fresh = await readAll();
          var timestamp = now();
          fresh.metadata.providers[providerId] = Object.assign({}, fresh.metadata.providers[providerId], { enabled: true, status: core.STATUSES.CONNECTED, availableModels: core.normalizeAvailableModels(result.models), lastTestedAt: timestamp, updatedAt: timestamp, lastErrorCode: null });
          var payload = {}; payload[core.STORE_KEY] = fresh.metadata; await write(payload);
          return { provider: providerId, connected: true, models: result.models };
        });
      } catch (error) {
        await serialize(async function () {
          var fresh = await readAll(); var timestamp = now();
          fresh.metadata.providers[providerId] = Object.assign({}, fresh.metadata.providers[providerId], { enabled: true, status: core.STATUSES.ATTENTION, lastTestedAt: timestamp, updatedAt: timestamp, lastErrorCode: core.sanitizeError(error).errorCode });
          var payload = {}; payload[core.STORE_KEY] = fresh.metadata; await write(payload);
        });
        throw error;
      }
    }
    async function listEmbeddingModels(providerId) {
      var adapter = requireProvider(providerId); var state = await readAll(); var secret = state.secrets.providers[providerId];
      if (!core.providerHasCapability(providerId, "busca inteligente") || typeof adapter.listEmbeddingModels !== "function") { var unsupported = new Error("provider_not_found"); unsupported.code = "provider_not_found"; throw unsupported; }
      if (!secret) { var missing = new Error("credential_missing"); missing.code = "credential_missing"; throw missing; }
      return { provider: providerId, models: await adapter.listEmbeddingModels({ apiKey: secret.apiKey }, { fetch: fetchImpl, timeoutMs: timeoutMs }) };
    }
    async function setModel(providerId, model) {
      requireProvider(providerId);
      if (typeof model !== "string" || !model.trim()) { var invalid = new Error("model_required"); invalid.code = "invalid_response"; throw invalid; }
      return serialize(async function () {
        var state = await readAll();
        if (!state.secrets.providers[providerId]) { var missing = new Error("credential_missing"); missing.code = "credential_missing"; throw missing; }
        state.metadata.providers[providerId] = Object.assign({}, state.metadata.providers[providerId], { model: model.trim(), enabled: true, updatedAt: now() });
        var payload = {}; payload[core.STORE_KEY] = state.metadata; await write(payload); return { provider: providerId, model: model.trim() };
      });
    }
    async function remove(providerId) {
      requireProvider(providerId);
      return serialize(async function () {
        var state = await readAll(); delete state.secrets.providers[providerId]; state.metadata.providers[providerId] = { enabled: false, model: null, status: core.STATUSES.NOT_CONFIGURED, lastTestedAt: null, updatedAt: now(), lastErrorCode: null };
        var payload = {}; payload[core.SECRETS_KEY] = state.secrets; payload[core.STORE_KEY] = state.metadata; await write(payload); return { provider: providerId, removed: true };
      });
    }
                                                                           
                                                                         
                                                                         
                                                                         
                                                                        
                                                                           
    function requireExternalActionsCore() {
      if (!externalActionsCore) { var error = new Error("external_actions_unavailable"); error.code = "external_actions_unavailable"; throw error; }
      return externalActionsCore;
    }
                                                                            
                                                                           
                                                                             
                                                                                 
    function externalActionError(code, message) { var error = new Error(message); error.code = code; return error; }
    async function readExternalActionsRaw() {
      var raw = await readKey(externalActionsCore.STORE_KEY);
      if (raw == null) return null;
      if (typeof raw === "string") { try { return JSON.parse(raw); } catch (error) { throw externalActionError("EXTERNAL_ACTION_STORE_CORRUPT", "A configuração das ações externas está corrompida."); } }
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw externalActionError("EXTERNAL_ACTION_STORE_CORRUPT", "A configuração das ações externas está corrompida.");
      return raw;
    }
    async function readExternalActionSecrets() {
      var raw = await readKey(externalActionsCore.SECRETS_KEY);
      if (raw == null) return Object.create(null);
      var parsed = raw;
      if (typeof raw === "string") {
        try { parsed = JSON.parse(raw); }
        catch (error) { throw externalActionError("EXTERNAL_ACTION_SECRETS_CORRUPT", "O cofre de credenciais das ações externas está corrompido."); }
      }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw externalActionError("EXTERNAL_ACTION_SECRETS_CORRUPT", "O cofre de credenciais das ações externas está corrompido.");
      var safe = Object.create(null);
      Object.keys(parsed).forEach(function (key) { if (key !== "__proto__" && key !== "prototype" && key !== "constructor") safe[key] = parsed[key]; });
      return safe;
    }
    async function writeExternalActionsRaw(store) { await writeKey(externalActionsCore.STORE_KEY, externalActionsCore.serializeStore(store)); }
    async function writeExternalActionSecrets(secrets) { await writeKey(externalActionsCore.SECRETS_KEY, JSON.stringify(secrets)); }

    async function listExternalActions() {
      requireExternalActionsCore();
      var rawStore = await readExternalActionsRaw();
      var secrets = await readExternalActionSecrets();
      return externalActionsCore.normalizeStore(rawStore).actions.map(function (action) {
        return Object.assign({}, action, { hasSecret: !!(secrets && secrets[action.id]) });
      });
    }
    async function createExternalAction(draft) {
      requireExternalActionsCore();
      return serialize(async function () {
        var rawStore = await readExternalActionsRaw();
        var outcome = externalActionsCore.createAction(rawStore, draft, { now: now, createId: function () { return createId("action"); } });
        await writeExternalActionsRaw(outcome.store);
        return outcome.action;
      });
    }
    async function updateExternalAction(actionId, draft) {
      requireExternalActionsCore();
      return serialize(async function () {
        var rawStore = await readExternalActionsRaw();
        var outcome = externalActionsCore.updateAction(rawStore, actionId, draft, { now: now });
        await writeExternalActionsRaw(outcome.store);
        return outcome.action;
      });
    }
    async function deleteExternalAction(actionId) {
      requireExternalActionsCore();
      return serialize(async function () {
        var rawStore = await readExternalActionsRaw();
        var outcome = externalActionsCore.deleteAction(rawStore, actionId);
        await writeExternalActionsRaw(outcome.store);
        var secrets = await readExternalActionSecrets();
        if (secrets && secrets[actionId]) { delete secrets[actionId]; await writeExternalActionSecrets(secrets); }
        var assistantsRaw = assistantsCore ? await readKey(assistantsCore.STORE_KEY) : null;
        var referenceCount = assistantsCore ? externalActionsCore.countAssistantReferences(assistantsCore.normalizeStore(assistantsRaw).assistants, actionId) : 0;
        return { deletedId: actionId, assistantReferenceCount: referenceCount };
      });
    }
    async function setExternalActionSecret(actionId, secretValue) {
      requireExternalActionsCore();
      var value = typeof secretValue === "string" ? secretValue.trim() : "";
      if (!value) { var invalid = new Error("credential_missing"); invalid.code = "credential_missing"; throw invalid; }
      return serialize(async function () {
        var rawStore = await readExternalActionsRaw();
        var action = externalActionsCore.normalizeStore(rawStore).actions.find(function (entry) { return entry.id === actionId; });
        if (!action) throw externalActionError(externalActionsCore.ERRORS.NOT_FOUND, "Ação externa não encontrada.");
        var secrets = await readExternalActionSecrets();
        secrets[actionId] = { value: value, updatedAt: now() };
        await writeExternalActionSecrets(secrets);
        return { actionId: actionId, hasSecret: true };
      });
    }
    async function removeExternalActionSecret(actionId) {
      requireExternalActionsCore();
      return serialize(async function () {
        var secrets = await readExternalActionSecrets();
        delete secrets[actionId];
        await writeExternalActionSecrets(secrets);
        return { actionId: actionId, hasSecret: false };
      });
    }
    async function checkExternalActionPermission(actionId) {
      requireExternalActionsCore();
      var rawStore = await readExternalActionsRaw();
      var action = externalActionsCore.normalizeStore(rawStore).actions.find(function (entry) { return entry.id === actionId; });
      var origin = action ? externalActionsCore.actionOrigin(action) : null;
      if (!origin) return { actionId: actionId, granted: false };
      var granted = await permissionsContains({ origins: [permissionPattern(origin)] });
      return { actionId: actionId, granted: !!granted, origin: origin };
    }

                                                                        
                                                                            
                                                                     
                                                                         
                                                                       
    async function executeExternalAction(action, args, signal) {
      var extCore = requireExternalActionsCore();
      if (!action.enabled) throw externalActionError(extCore.ERRORS.DISABLED, "Esta ação externa está desativada.");
      var origin = extCore.actionOrigin(action);
      if (!origin) throw externalActionError(extCore.ERRORS.INVALID_URL, "O endereço de destino desta ação precisa ser revisado.");
      var granted = await permissionsContains({ origins: [permissionPattern(origin)] });
      if (!granted) throw externalActionError(extCore.ERRORS.PERMISSION_REQUIRED, "Esta ação precisa de permissão para acessar o endereço configurado. Conceda o acesso na Central de Integrações.");
      var validatedArgs = extCore.validateArguments(action, args);
      var built = extCore.buildRequest(action, validatedArgs);
      var secrets = await readExternalActionSecrets();
      var secretEntry = secrets && secrets[action.id];
      var secretValue = secretEntry ? secretEntry.value : "";
      if (action.auth.mode !== "none" && !secretValue) throw externalActionError(extCore.ERRORS.AUTH_MISSING, "A credencial desta ação não está configurada.");
      var headers = Object.assign({}, built.headers);
      if (action.auth.mode === "bearer") headers.Authorization = "Bearer " + secretValue;
      else if (action.auth.mode === "apiKeyHeader") headers[action.auth.headerName] = secretValue;
      var controller = new AbortController();
      var externalSignal = signal;
      var timedOut = false;
      var onExternalAbort = function () { controller.abort(); };
      if (externalSignal) { if (externalSignal.aborted) controller.abort(); else externalSignal.addEventListener("abort", onExternalAbort, { once: true }); }
      var timer = setTimeout(function () { timedOut = true; controller.abort(); }, externalActionTimeoutMs);
      var response;
      try {
        try {
                                                                         
                                                                 
                                                                             
                                                                    
                                                             
                                                                          
                                                        
          response = await fetchImpl(built.url, { method: built.method, headers: headers, body: built.body, credentials: "omit", cache: "no-store", redirect: "manual", targetAddressSpace: "public", signal: controller.signal });
        } catch (error) {
          if (controller.signal.aborted) {
            if (!timedOut && externalSignal && externalSignal.aborted) throw externalActionError(extCore.ERRORS.CANCELLED, "A ação externa foi cancelada.");
            throw externalActionError(extCore.ERRORS.TIMEOUT, "A ação externa demorou demais para responder.");
          }
          throw externalActionError(extCore.ERRORS.NETWORK_ERROR, "Não foi possível conectar ao endereço desta ação.");
        }
        if (response.type === "opaqueredirect") throw externalActionError(extCore.ERRORS.HTTP_ERROR, "O endereço redirecionou para outro local, o que não é permitido por segurança.");
        var rawText = "";
        if (action.responsePolicy.mode !== "statusOnly") {
          try {
            var reader = response.body && typeof response.body.getReader === "function" ? response.body.getReader() : null;
            if (reader) {
              var received = 0; var chunks = [];
              for (;;) {
                var chunk = await reader.read();
                if (chunk.done) break;
                received += chunk.value.length;
                if (received > extCore.MAX_RAW_RESPONSE_BYTES) { reader.cancel().catch(function () {}); throw externalActionError(extCore.ERRORS.RESPONSE_TOO_LARGE, "A resposta desta ação excede o limite seguro de tamanho."); }
                chunks.push(chunk.value);
              }
              var decoder = new TextDecoder("utf-8");
              rawText = chunks.map(function (bytes, index) { return decoder.decode(bytes, { stream: index < chunks.length - 1 }); }).join("") + decoder.decode();
            } else {
              rawText = await response.text();
              if (new TextEncoder().encode(rawText).byteLength > extCore.MAX_RAW_RESPONSE_BYTES) throw externalActionError(extCore.ERRORS.RESPONSE_TOO_LARGE, "A resposta desta ação excede o limite seguro de tamanho.");
            }
          } catch (error) {
            if (error && error.code === extCore.ERRORS.RESPONSE_TOO_LARGE) throw error;
            if (controller.signal.aborted) {
              if (!timedOut && externalSignal && externalSignal.aborted) throw externalActionError(extCore.ERRORS.CANCELLED, "A ação externa foi cancelada.");
              throw externalActionError(extCore.ERRORS.TIMEOUT, "A ação externa demorou demais para responder.");
            }
            throw error;
          }
        }
        var result = extCore.applyResponsePolicy(action, response.status, rawText);
        return extCore.redactSecret(result, secretValue);
      } finally {
        clearTimeout(timer);
        if (externalSignal) externalSignal.removeEventListener("abort", onExternalAbort);
      }
    }
                                                                            
                                                                          
                                                             
    function runExternalActionForAssistant(assistantId, signal) {
      return async function (actionId, args) {
        var extCore = requireExternalActionsCore();
        if (!assistantsCore) throw externalActionError(extCore.ERRORS.NOT_ALLOWED, "Não foi possível verificar a autorização deste Assistente para ações externas.");
        var assistantsRaw = await readKey(assistantsCore.STORE_KEY);
        var assistant = assistantsCore.normalizeStore(assistantsRaw).assistants.find(function (entry) { return entry.id === assistantId; });
        var enabledIds = assistant && assistant.externalActions && Array.isArray(assistant.externalActions.enabled) ? assistant.externalActions.enabled : [];
        var rawStore = await readExternalActionsRaw();
        var action = extCore.resolveForExecution(rawStore, actionId, enabledIds);
        return executeExternalAction(action, args, signal);
      };
    }
                                                                       
                                                                      
    async function testExternalAction(actionId, args) {
      var extCore = requireExternalActionsCore();
      var rawStore = await readExternalActionsRaw();
      var action = extCore.normalizeStore(rawStore).actions.find(function (entry) { return entry.id === actionId; });
      if (!action) throw externalActionError(extCore.ERRORS.NOT_FOUND, "Ação externa não encontrada.");
      return executeExternalAction(action, args, null);
    }
    async function resolveAssistantExternalActions(assistantId) {
      if (!assistantsCore || !externalActionsCore || !assistantId) return [];
      var assistantsRaw = await readKey(assistantsCore.STORE_KEY);
      var assistant = assistantsCore.normalizeStore(assistantsRaw).assistants.find(function (entry) { return entry.id === assistantId; });
      var enabledIds = assistant && assistant.externalActions && Array.isArray(assistant.externalActions.enabled) ? assistant.externalActions.enabled : [];
      if (!enabledIds.length) return [];
      var rawStore = await readExternalActionsRaw();
      var allActions = externalActionsCore.normalizeStore(rawStore).actions;
      return allActions.filter(function (action) { return enabledIds.indexOf(action.id) >= 0 && action.enabled && externalActionsCore.actionOrigin(action); });
    }

    function rawProviderEntry(rawMetadata, providerId) {
      var source = rawMetadata && rawMetadata.state && rawMetadata.state.providers ? rawMetadata.state : rawMetadata;
      return source && source.providers && source.providers[providerId] || null;
    }
    async function canonicalAssistantTools(request) {
      if (!request.assistantId) return [];
      if (!assistantsCore || !toolsRegistry) { var unavailable = new Error("AI_TOOL_NOT_FOUND"); unavailable.code = "AI_TOOL_NOT_FOUND"; throw unavailable; }
      var ledger = request.agentControl ? getAgentLedger(request) : null;
      if (ledger && ledger.initialized) {
        if (request.agentControl.maxSteps !== ledger.maxSteps || request.agentControl.step > ledger.maxSteps) { var staleRun = new Error("AI_AGENT_RUNTIME_FAILED"); staleRun.code = "AI_AGENT_RUNTIME_FAILED"; throw staleRun; }
        return ledger.enabledToolIds.slice();
      }
      var raw = await readKey(assistantsCore.STORE_KEY);
      var assistant = assistantsCore.normalizeStore(raw).assistants.find(function (entry) { return entry.id === request.assistantId; });
      if (!assistant || assistant.enabled === false || assistant.providerId !== request.providerId) { var blocked = new Error("AI_TOOL_NOT_ALLOWED"); blocked.code = "AI_TOOL_NOT_ALLOWED"; throw blocked; }
      if (request.agentControl) {
        if (!agentsCore) { var missingCore = new Error("AI_AGENT_RUNTIME_FAILED"); missingCore.code = "AI_AGENT_RUNTIME_FAILED"; throw missingCore; }
        var rawAgents = await readKey(agentsCore.STORE_KEY);
        var agent = agentsCore.normalizeStore(rawAgents).agents.find(function (entry) { return entry.id === request.agentControl.agentId; });
        if (!agent) { var missingAgent = new Error("AI_AGENT_NOT_FOUND"); missingAgent.code = "AI_AGENT_NOT_FOUND"; throw missingAgent; }
        if (!agent.enabled) { var disabledAgent = new Error("AI_AGENT_DISABLED"); disabledAgent.code = "AI_AGENT_DISABLED"; throw disabledAgent; }
        if (agent.assistantId !== assistant.id || request.agentControl.maxSteps !== agent.maxSteps || request.agentControl.step > agent.maxSteps) { var invalidAgent = new Error("AI_AGENT_ASSISTANT_INVALID"); invalidAgent.code = "AI_AGENT_ASSISTANT_INVALID"; throw invalidAgent; }
      }
      var enabledToolIds = toolsRegistry.normalizeEnabledToolIds(assistant.tools);
      if (ledger) {
        ledger.initialized = true;
        ledger.maxSteps = request.agentControl.maxSteps;
        ledger.enabledToolIds = enabledToolIds.slice();
        ledger.touchedAt = now();
      }
      return enabledToolIds;
    }
    function parseAgentControlArguments(rawArguments) {
      var parsed = rawArguments;
      if (typeof parsed === "string") {
        try { parsed = JSON.parse(parsed); } catch (error) { parsed = null; }
      }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) { var invalidObject = new Error("AI_AGENT_RUNTIME_FAILED"); invalidObject.code = "AI_AGENT_RUNTIME_FAILED"; throw invalidObject; }
      var allowed = { action: true, finalText: true, summary: true };
      if (Object.keys(parsed).some(function (key) { return !allowed[key]; }) || (parsed.action !== "continue" && parsed.action !== "complete")) { var invalidAction = new Error("AI_AGENT_RUNTIME_FAILED"); invalidAction.code = "AI_AGENT_RUNTIME_FAILED"; throw invalidAction; }
      if (parsed.finalText != null && typeof parsed.finalText !== "string" || parsed.summary != null && typeof parsed.summary !== "string") { var invalidText = new Error("AI_AGENT_RUNTIME_FAILED"); invalidText.code = "AI_AGENT_RUNTIME_FAILED"; throw invalidText; }
      var finalText = typeof parsed.finalText === "string" ? parsed.finalText.trim().slice(0, 60000) : "";
      var summary = typeof parsed.summary === "string" ? parsed.summary.trim().slice(0, 1200) : "";
      if (parsed.action === "continue" && !summary) { var missingSummary = new Error("AI_AGENT_RUNTIME_FAILED"); missingSummary.code = "AI_AGENT_RUNTIME_FAILED"; throw missingSummary; }
      return { action: parsed.action, finalText: finalText, summary: summary };
    }
    function pruneAgentLedgers() {
      var threshold = now() - AGENT_LEDGER_TTL_MS;
      agentRunLedgers.forEach(function (ledger, runId) { if (ledger.touchedAt < threshold) agentRunLedgers.delete(runId); });
    }
    function getAgentLedger(request) {
      if (!request.agentControl) return null;
      pruneAgentLedgers();
      if (agentRunLedgers.size >= 128 && !agentRunLedgers.has(request.agentControl.agentRunId)) {
        var oldestRun = null, oldestAt = Infinity;
        agentRunLedgers.forEach(function (entry, id) { if (Number(entry.touchedAt) < oldestAt) { oldestAt = Number(entry.touchedAt); oldestRun = id; } });
        if (oldestRun) agentRunLedgers.delete(oldestRun);
      }
      var runId = request.agentControl.agentRunId;
      var ledger = agentRunLedgers.get(runId);
      if (ledger && (ledger.executionId !== request.executionId || ledger.agentId !== request.agentControl.agentId || ledger.assistantId !== request.assistantId)) { var conflict = new Error("AI_AGENT_RUNTIME_FAILED"); conflict.code = "AI_AGENT_RUNTIME_FAILED"; throw conflict; }
      if (!ledger) {
        ledger = { executionId: request.executionId, agentId: request.agentControl.agentId, assistantId: request.assistantId, results: new Map(), touchedAt: now() };
        agentRunLedgers.set(runId, ledger);
      }
      ledger.touchedAt = now();
      return ledger;
    }
    function endAgentRun(agentRunId, executionId) {
      var ledger = agentRunLedgers.get(agentRunId);
      if (!ledger || executionId && ledger.executionId !== executionId) return { agentRunId: agentRunId || null, cleared: false };
      agentRunLedgers.delete(agentRunId);
      return { agentRunId: agentRunId, cleared: true };
    }
    function cancelledToolError() { var error = new Error("AI_TOOL_CANCELLED"); error.code = "AI_TOOL_CANCELLED"; return error; }
    function ensureToolActive(signal) { if (signal && signal.aborted) throw cancelledToolError(); }
    function addUsage(total, usage) {
      ["inputTokens", "outputTokens", "totalTokens"].forEach(function (key) {
        if (!Number.isFinite(Number(usage && usage[key]))) return;
        total[key] = (Number.isFinite(Number(total[key])) ? Number(total[key]) : 0) + Number(usage[key]);
      });
    }
    async function generateWithTools(adapter, secret, request, controller) {
      var enabledToolIds = await canonicalAssistantTools(request);
      var perRequestToolLimit = request.agentControl ? request.agentControl.toolCallLimit : toolsRegistry.MAX_TOOL_CALLS;
      var executableToolIds = perRequestToolLimit > 0 ? enabledToolIds : [];
      request.requestedToolIds = executableToolIds.slice();
      request.tools = toolsRegistry.definitionsFor(executableToolIds);
                                                                            
                                                                           
                                                                          
                                                  
      var enabledExternalActionIds = [];
      if (request.assistantId && perRequestToolLimit > 0) {
        var authorizedExternalActions = await resolveAssistantExternalActions(request.assistantId);
        if (authorizedExternalActions.length) {
          request.tools.push(toolsRegistry.externalActionToolDefinition(authorizedExternalActions));
          enabledExternalActionIds = authorizedExternalActions.map(function (action) { return action.id; });
        }
      }
      if (request.agentControl) request.tools.push(JSON.parse(JSON.stringify(AGENT_CONTROL_DEFINITION)));
      if (!request.tools.length) return adapter.generateText({ apiKey: secret.apiKey }, request, { fetch: fetchImpl, signal: controller.signal, timeoutMs: generationTimeoutMs, now: now });
      if (typeof adapter.generateRound !== "function" || typeof adapter.continueRound !== "function") { var unsupported = new Error("AI_TOOL_NOT_FOUND"); unsupported.code = "AI_TOOL_NOT_FOUND"; throw unsupported; }
      var securityInstructions = toolsRegistry.runtimeInstructions(request.toolContext);
      request.instructions = [request.instructions, securityInstructions].filter(Boolean).join("\n\n");
                                                                             
                                                                           
                                                                       
                                                                        
                                                                             
                                                                      
                                                                            
                                                                             
                                                                 
      var toolExecutionIds = enabledExternalActionIds.length ? executableToolIds.concat(["external_action"]) : executableToolIds;
      var executionContext = Object.assign({}, request.toolContext, { enabledToolIds: toolExecutionIds, enabledExternalActionIds: enabledExternalActionIds, assistantId: request.assistantId, executionId: request.executionId });
      var agentLedger = getAgentLedger(request);
      var resultsByCall = agentLedger ? agentLedger.results : new Map();
      var activityByCall = new Map();
      var usage = { inputTokens: null, outputTokens: null, totalTokens: null };
      var durationMs = 0;
      var toolCallCount = 0;
      var toolRoundCount = 0;
      var round;
      try {
        round = await adapter.generateRound({ apiKey: secret.apiKey }, request, { fetch: fetchImpl, signal: controller.signal, timeoutMs: generationTimeoutMs, now: now });
      } catch (error) {
        if (request.agentControl && error && (error.code === "openai_invalid_request" || error.code === "invalid_request" || Number(error.httpStatus) === 400)) { var unsupportedAgentModel = new Error("AI_AGENT_MODEL_TOOL_UNSUPPORTED"); unsupportedAgentModel.code = "AI_AGENT_MODEL_TOOL_UNSUPPORTED"; throw unsupportedAgentModel; }
        throw error;
      }
      while (round && round.type === "tool_calls") {
        ensureToolActive(controller.signal);
        var controlCalls = round.calls.filter(function (call) { return call.toolName === AGENT_CONTROL_TOOL_ID; });
        if (controlCalls.length) {
          if (!request.agentControl || controlCalls.length !== 1 || round.calls.length !== 1) { var invalidControl = new Error("AI_AGENT_RUNTIME_FAILED"); invalidControl.code = "AI_AGENT_RUNTIME_FAILED"; throw invalidControl; }
          addUsage(usage, round.usage); durationMs += Number(round.durationMs) || 0;
          var control = parseAgentControlArguments(controlCalls[0].arguments);
          if (agentLedger) agentLedger.touchedAt = now();
          return { ok: true, provider: round.provider, model: round.model, text: "", agentControl: control, usage: usage, durationMs: durationMs, tools: { count: activityByCall.size, calls: toolCallCount, rounds: toolRoundCount, events: Array.from(activityByCall.values()) } };
        }
        toolRoundCount += 1;
        if (toolRoundCount > toolsRegistry.MAX_TOOL_ROUNDS || toolCallCount + round.calls.length > perRequestToolLimit) { var limit = new Error("AI_TOOL_LIMIT_EXCEEDED"); limit.code = "AI_TOOL_LIMIT_EXCEEDED"; throw limit; }
        addUsage(usage, round.usage); durationMs += Number(round.durationMs) || 0;
        var toolResults = [];
        for (var index = 0; index < round.calls.length; index++) {
          ensureToolActive(controller.signal);
          var call = round.calls[index];
          toolCallCount += 1;
          var identity = request.executionId + "|" + call.callId + "|" + call.toolName;
          var toolResult;
          if (resultsByCall.has(identity)) toolResult = resultsByCall.get(identity);
          else {
            try {
              toolResult = await toolsRegistry.execute(call.toolName, call.arguments, executionContext, toolDependencies(request.assistantId, controller.signal));
            } catch (error) {
              if ((error && error.code === "AI_TOOL_CANCELLED") || controller.signal.aborted) throw cancelledToolError();
              toolResult = toolsRegistry.safeFailure(error);
            }
            resultsByCall.set(identity, cloneToolResult(toolResult));
            var definition = toolsRegistry.get(call.toolName);
            activityByCall.set(identity, { toolId: call.toolName, label: definition ? definition.activityLabel : "IA · ferramenta não concluída", risk: definition ? definition.risk : "read", success: toolResult && toolResult.success !== false });
          }
          ensureToolActive(controller.signal);
          toolResults.push({ callId: call.callId, toolName: call.toolName, result: cloneToolResult(toolResult) });
        }
        ensureToolActive(controller.signal);
        try {
          round = await adapter.continueRound({ apiKey: secret.apiKey }, request, round.providerState, toolResults, { fetch: fetchImpl, signal: controller.signal, timeoutMs: generationTimeoutMs, now: now });
        } catch (error) {
          if (request.agentControl && error && (error.code === "openai_invalid_request" || error.code === "invalid_request" || Number(error.httpStatus) === 400)) { var unsupportedAgentModelRound = new Error("AI_AGENT_MODEL_TOOL_UNSUPPORTED"); unsupportedAgentModelRound.code = "AI_AGENT_MODEL_TOOL_UNSUPPORTED"; throw unsupportedAgentModelRound; }
          throw error;
        }
      }
      ensureToolActive(controller.signal);
      if (request.agentControl) { var missingControl = new Error("AI_AGENT_CONTROL_REQUIRED"); missingControl.code = "AI_AGENT_CONTROL_REQUIRED"; throw missingControl; }
      if (!round || round.type !== "text") { var invalid = new Error("invalid_response"); invalid.code = "invalid_response"; throw invalid; }
      addUsage(usage, round.usage); durationMs += Number(round.durationMs) || 0;
      return { ok: true, provider: round.provider, model: round.model, text: round.text, usage: usage, durationMs: durationMs, tools: { count: activityByCall.size, calls: toolCallCount, rounds: toolRoundCount, events: Array.from(activityByCall.values()) } };
    }
    function cloneToolResult(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
    async function generate(rawRequest) {
      var validation = core.normalizeAiRequest(rawRequest);
      if (!validation.valid) { var invalid = new Error(validation.errorCode); invalid.code = validation.errorCode; throw invalid; }
      var request = validation.request;
      var adapter = requireProvider(request.providerId);
      if (typeof adapter.generateText !== "function") { var unsupported = new Error("provider_not_found"); unsupported.code = "provider_not_found"; throw unsupported; }
      if (pendingAiRequests.has(request.requestId)) { var conflict = new Error("ai_request_conflict"); conflict.code = "ai_request_conflict"; throw conflict; }
      if (pendingAiRequests.size >= MAX_CONCURRENT_AI_REQUESTS) { var saturated = new Error("AI_REQUEST_LIMIT_EXCEEDED"); saturated.code = "AI_REQUEST_LIMIT_EXCEEDED"; throw saturated; }
      var controller = new AbortController();
      var record = { controller: controller, executionId: request.executionId, providerId: request.providerId };
      pendingAiRequests.set(request.requestId, record);
      try {
        var state = await readAll();
        if (controller.signal.aborted) { var cancelled = new Error("ai_cancelled"); cancelled.code = "ai_cancelled"; throw cancelled; }
        var rawMetadata = rawProviderEntry(state.rawMetadata, request.providerId);
        var metadata = state.metadata.providers[request.providerId];
        var secret = state.secrets.providers[request.providerId];
        if (!rawMetadata) { var absent = new Error("integration_not_configured"); absent.code = "integration_not_configured"; throw absent; }
        if (!secret || !secret.apiKey) { var missing = new Error("credential_missing"); missing.code = "credential_missing"; throw missing; }
        if (metadata.enabled !== true) { var disabled = new Error("integration_disabled"); disabled.code = "integration_disabled"; throw disabled; }
        if (metadata.status !== core.STATUSES.CONNECTED) { var notReady = new Error("integration_not_ready"); notReady.code = "integration_not_ready"; throw notReady; }
        var selectedModel = request.model || metadata.model;
        if (!selectedModel) { var noModel = new Error("model_required"); noModel.code = "model_required"; throw noModel; }
        var modelIsKnown = Array.isArray(metadata.availableModels) && metadata.availableModels.some(function (model) { return model && model.id === request.model; });
        if (request.model && request.model !== metadata.model && !modelIsKnown) { var badModel = new Error("model_invalid"); badModel.code = "model_invalid"; throw badModel; }
        request.model = selectedModel;
        return await generateWithTools(adapter, secret, request, controller);
      } finally {
        if (pendingAiRequests.get(request.requestId) === record) pendingAiRequests.delete(request.requestId);
      }
    }
    async function transcribe(request) {
      request=request&&typeof request==="object"?request:{};
      if(!request.requestId||!request.executionId){var bad=new Error("ai_request_id_required");bad.code="ai_request_id_required";throw bad;}
      if(!request.providerId||!(request.media&&request.media.kind==="audio"&&request.media.dataBase64)){var invalid=new Error("invalid_request");invalid.code="invalid_request";throw invalid;}
      if(pendingAiRequests.has(request.requestId)){var conflict=new Error("ai_request_conflict");conflict.code="ai_request_conflict";throw conflict;}
      if(pendingAiRequests.size>=MAX_CONCURRENT_AI_REQUESTS){var saturated=new Error("AI_REQUEST_LIMIT_EXCEEDED");saturated.code="AI_REQUEST_LIMIT_EXCEEDED";throw saturated;}
      var adapter=requireProvider(request.providerId);if(typeof adapter.transcribeAudio!=="function"){var unsupported=new Error("provider_capability_unsupported");unsupported.code="provider_capability_unsupported";throw unsupported;}
      var controller=new AbortController(),record={controller:controller,executionId:request.executionId};pendingAiRequests.set(request.requestId,record);
      try{
        var state=await readAll(),metadata=state.metadata.providers[request.providerId],secret=state.secrets.providers[request.providerId];
        if(!secret||!secret.apiKey){var missing=new Error("credential_missing");missing.code="credential_missing";throw missing;}
        if(!metadata||metadata.enabled!==true){var disabled=new Error("integration_disabled");disabled.code="integration_disabled";throw disabled;}
        if(metadata.status!==core.STATUSES.CONNECTED){var notReady=new Error("integration_not_ready");notReady.code="integration_not_ready";throw notReady;}
        return await adapter.transcribeAudio({apiKey:secret.apiKey},{model:request.model||null,language:request.language||null,mimeType:request.media.mimeType,dataBase64:request.media.dataBase64},{fetch:fetchImpl,timeoutMs:generationTimeoutMs,signal:controller.signal});
      }finally{if(pendingAiRequests.get(request.requestId)===record)pendingAiRequests.delete(request.requestId);}
    }
    function cancel(requestId, executionId) {
      var record = pendingAiRequests.get(requestId);
      if (!record || (executionId && record.executionId !== executionId)) return { requestId: requestId || null, cancelled: false };
      record.controller.abort();
      return { requestId: requestId, cancelled: true };
    }
    async function handle(message) {
      try {
        var result;
        if (message.type === "EXTUI_INTEGRATION_GET_STATE") result = await publicSnapshot();
        else if (message.type === "EXTUI_AI_ROUTING_STATE") result = await aiRoutingSnapshot();
        else if (message.type === "EXTUI_INTEGRATION_CONFIGURE") result = await configure(message.provider, message.apiKey);
        else if (message.type === "EXTUI_INTEGRATION_TEST") result = await test(message.provider);
        else if (message.type === "EXTUI_INTEGRATION_LIST_EMBEDDING_MODELS") result = await listEmbeddingModels(message.provider);
        else if (message.type === "EXTUI_INTEGRATION_SET_MODEL") result = await setModel(message.provider, message.model);
        else if (message.type === "EXTUI_INTEGRATION_REMOVE") result = await remove(message.provider);
        else if (message.type === "EXTUI_AI_GENERATE") result = await generate(message.request);
        else if (message.type === "EXTUI_AI_TRANSCRIBE") result = await transcribe(message.request);
        else if (message.type === "EXTUI_AI_CANCEL") result = cancel(message.requestId, message.executionId);
        else if (message.type === "EXTUI_AI_AGENT_END") result = endAgentRun(message.agentRunId, message.executionId);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_LIST") result = await listExternalActions();
        else if (message.type === "EXTUI_EXTERNAL_ACTION_CREATE") result = await createExternalAction(message.draft);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_UPDATE") result = await updateExternalAction(message.actionId, message.draft);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_DELETE") result = await deleteExternalAction(message.actionId);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_SET_SECRET") result = await setExternalActionSecret(message.actionId, message.secretValue);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_REMOVE_SECRET") result = await removeExternalActionSecret(message.actionId);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_CHECK_PERMISSION") result = await checkExternalActionPermission(message.actionId);
        else if (message.type === "EXTUI_EXTERNAL_ACTION_TEST") result = await testExternalAction(message.actionId, message.testArguments);
        else return null;
        return { ok: true, result: result };
      } catch (error) {
        if (message && typeof message.type === "string" && message.type.indexOf("EXTUI_AI_") === 0) return core.sanitizeGenerationError(error, message.request && message.request.providerId);
                                                                             
                                                                        
                                                                            
                                                                 
        if (error && typeof error.code === "string" && /^EXTERNAL_ACTION_[A-Z_]+$/.test(error.code)) {
          return { ok: false, errorCode: error.code, userMessage: error.message || "Não foi possível concluir a operação." };
        }
        if (error && (error.code === "INTEGRATION_STORE_CORRUPT" || error.code === "INTEGRATION_SECRETS_CORRUPT")) {
          if (root.__extReportRuntimeError) root.__extReportRuntimeError(error.code, error);
          return { ok: false, errorCode: error.code, userMessage: error.message || "A configuração da integração precisa ser reparada." };
        }
        return Object.assign({ ok: false }, core.sanitizeError(error));
      }
    }
    return Object.freeze({ handle: handle, getState: publicSnapshot, pendingAiCount: function () { return pendingAiRequests.size; }, agentLedgerCount: function () { return agentRunLedgers.size; } });
  }
  if (root.chrome && chrome.runtime && chrome.storage && chrome.storage.local && root.indexedDB && root.crypto && crypto.subtle) {
    (function installSensitiveStorageVault(){
      if(root.__extSensitiveStorage)return;
      var base=chrome.storage.local;
      var sensitive=new Set(["EXTUI:integrationSecrets","EXTUI:externalActionSecrets","EXTUI:webhookSecrets","EXTUI:trackingSecrets","EXTUI:backupProtectionSecret"]);
      var DB_DEFAULT="EXTAPP_SECURE_VAULT_V1",DB=DB_DEFAULT,STORE="keys",KEY_ID="config-secrets-v1",MAX_PLAIN=1024*1024,keyPending=null,dbNamePending=null;
      function err(code,message){var e=new Error(message);e.code=code;return e;}
      function b64(bytes){var out="";for(var i=0;i<bytes.length;i++)out+=String.fromCharCode(bytes[i]);return btoa(out);}
      function unb64(text){var raw=atob(String(text||"")),out=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
      function envelope(v){return !!(v&&typeof v==="object"&&v.__extVault===1&&Number(v.version)===1&&v.alg==="A256GCM"&&typeof v.iv==="string"&&typeof v.ciphertext==="string");}
      function probeVaultDbName(name){return new Promise(function(resolve){var req;try{req=indexedDB.open(name);}catch(_){resolve(false);return;}req.onsuccess=function(){var db=req.result;if(!db.objectStoreNames.contains(STORE)){try{db.close();}catch(_){}resolve(false);return;}try{var tx=db.transaction(STORE,"readonly"),store=tx.objectStore(STORE),a=store.get(KEY_ID),b=store.get("license-v1"),done=0,found=false;function finish(v){found=found||!!v;done++;if(done<2)return;try{db.close();}catch(_){}resolve(found);}a.onsuccess=function(){finish(a.result||null);};a.onerror=function(){finish(null);};b.onsuccess=function(){finish(b.result||null);};b.onerror=function(){finish(null);};}catch(_){try{db.close();}catch(__){}resolve(false);}};req.onerror=function(){resolve(false);};req.onblocked=function(){resolve(false);};});}
      function resolveVaultDbName(){if(dbNamePending)return dbNamePending;dbNamePending=Promise.resolve().then(async function(){if(!indexedDB.databases)return DB_DEFAULT;var list=await indexedDB.databases();if((list||[]).some(function(row){return row&&row.name===DB_DEFAULT;}))return DB_DEFAULT;for(var i=0;i<(list||[]).length;i++){var name=String(list[i]&&list[i].name||"");if(!name||name===DB_DEFAULT)continue;if(!await probeVaultDbName(name))continue;var migration=globalThis.__extIdbNeutralMigration;if(!migration||typeof migration.migrate!=="function")return name;try{var result=await migration.migrate({indexedDB:indexedDB,sourceName:name,targetName:DB_DEFAULT,version:1,allowExistingTarget:false,probe:function(db){if(!db.objectStoreNames.contains(STORE))return false;return true;},upgrade:function(db){if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE);},stores:[{name:STORE,compare:function(a,b){return a===undefined?b===undefined:b!==undefined;}}]});if(result&&result.migrated)return DB_DEFAULT;}catch(error){if(globalThis.__extReportRuntimeError)globalThis.__extReportRuntimeError("SENSITIVE_VAULT_NEUTRALIZATION_FAILED",error);}return name;}return DB_DEFAULT;}).catch(function(){return DB_DEFAULT;});return dbNamePending;}
      function openDb(){return resolveVaultDbName().then(function(name){DB=name;return new Promise(function(resolve,reject){try{var req=indexedDB.open(name,1);req.onupgradeneeded=function(){var db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE);};req.onsuccess=function(){var db=req.result;db.onversionchange=function(){try{db.close();}catch(_){}keyPending=null;dbNamePending=null;};resolve(db);};req.onerror=function(){reject(req.error||err("SENSITIVE_VAULT_UNAVAILABLE","O cofre seguro de integrações não pôde ser aberto."));};}catch(e){reject(e);}});});}
      async function key(){if(keyPending)return keyPending;var task=(async function(){var db=await openDb();try{var existing=await new Promise(function(resolve,reject){var tx=db.transaction(STORE,"readonly"),rq=tx.objectStore(STORE).get(KEY_ID);rq.onsuccess=function(){resolve(rq.result||null);};rq.onerror=function(){reject(rq.error);};});if(existing)return existing;var created=await crypto.subtle.generateKey({name:"AES-GCM",length:256},false,["encrypt","decrypt"]);await new Promise(function(resolve,reject){var tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put(created,KEY_ID);tx.oncomplete=resolve;tx.onerror=function(){reject(tx.error);};tx.onabort=function(){reject(tx.error||err("SENSITIVE_VAULT_UNAVAILABLE","A chave do cofre seguro não pôde ser persistida."));};});return created;}finally{db.close();}})();keyPending=task;try{return await task;}catch(e){keyPending=null;throw e;}}
      function aad(storageKey){return new TextEncoder().encode("Extensão|config-vault|v1|"+String(chrome.runtime.id||"")+"|"+String(storageKey));}
      async function seal(storageKey,value){var json=JSON.stringify({value:value,storedAt:Date.now()}),plain=new TextEncoder().encode(json);if(plain.byteLength>MAX_PLAIN)throw err("SENSITIVE_VAULT_VALUE_TOO_LARGE","A credencial excede o limite seguro de armazenamento.");var iv=new Uint8Array(12);crypto.getRandomValues(iv);var cipher=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:iv,additionalData:aad(storageKey),tagLength:128},await key(),plain));return{__extVault:1,version:1,alg:"A256GCM",iv:b64(iv),ciphertext:b64(cipher),updatedAt:Date.now()};}
      async function open(storageKey,record){if(!envelope(record))return{legacy:true,value:record};try{var iv=unb64(record.iv),cipher=unb64(record.ciphertext);if(iv.byteLength!==12||cipher.byteLength<17||cipher.byteLength>MAX_PLAIN+64)throw err("SENSITIVE_VAULT_CORRUPT","Registro protegido inválido.");var plain=await crypto.subtle.decrypt({name:"AES-GCM",iv:iv,additionalData:aad(storageKey),tagLength:128},await key(),cipher);if(plain.byteLength>MAX_PLAIN)throw err("SENSITIVE_VAULT_CORRUPT","Registro protegido excede o limite.");var decoded=JSON.parse(new TextDecoder().decode(new Uint8Array(plain)));if(!decoded||typeof decoded!=="object"||!("value" in decoded))throw err("SENSITIVE_VAULT_CORRUPT","Registro protegido inválido.");return{legacy:false,value:decoded.value};}catch(e){throw err("SENSITIVE_VAULT_CORRUPT","Não foi possível abrir uma credencial protegida. Reconfigure essa integração.");}}
      function requestedKeys(keys,raw){if(keys==null)return Object.keys(raw||{});if(typeof keys==="string")return[keys];if(Array.isArray(keys))return keys.map(String);if(keys&&typeof keys==="object")return Object.keys(keys);return[];}
      async function get(keys){var raw=await base.get(keys),out=Object.assign({},raw||{}),migrate={};for(var k of requestedKeys(keys,raw)){if(!sensitive.has(k)||!Object.prototype.hasOwnProperty.call(out,k)||out[k]==null)continue;var decoded=await open(k,out[k]);out[k]=decoded.value;if(decoded.legacy){migrate[k]=await seal(k,decoded.value);}}if(Object.keys(migrate).length)await base.set(migrate);return out;}
      async function set(values){values=values&&typeof values==="object"?values:{};var protectedValues={};for(var k of Object.keys(values)){if(sensitive.has(k)&&values[k]!==undefined)protectedValues[k]=await seal(k,values[k]);else protectedValues[k]=values[k];}return base.set(protectedValues);}
      async function remove(keys){return base.remove(keys);}
      async function clear(){return base.clear();}
      root.__extSensitiveStorage=Object.freeze({get:get,set:set,remove:remove,clear:clear,isSensitiveKey:function(k){return sensitive.has(String(k));},databaseName:DB,resetKeyCache:function(){keyPending=null;},format:"EXTAPP_CONFIG_VAULT_V1"});
    })();
  }

  if (root.chrome && chrome.runtime && chrome.storage && typeof fetch === "function") {
    var runtime = createRuntime({
      storage: root.__extSensitiveStorage || chrome.storage.local, fetch: fetch.bind(root), now: Date.now,
                                                                            
                                                                       
                                              
      permissionsContains: (chrome.permissions && typeof chrome.permissions.contains === "function")
        ? function (permissions) { return chrome.permissions.contains(permissions); }
        : function () { return Promise.resolve(false); },
      permissionPattern: root.__extRuntimeConfig && root.__extRuntimeConfig.permissionPattern
        ? root.__extRuntimeConfig.permissionPattern
        : function (value) { var url = new URL(String(value || "")); return "https://" + url.hostname + "/*"; }
    });
    function senderPolicy(){return root.__extSenderPolicy||null;}
    function senderIsExtensionPage(sender){var p=senderPolicy();return !!(p&&p.isExtensionPage&&p.isExtensionPage(sender));}
    function senderIsWhatsApp(sender){var p=senderPolicy();return !!(p&&p.isWhatsApp&&p.isWhatsApp(sender));}
    function senderCanRuntime(sender){var p=senderPolicy();return !!(p&&p.canRuntime&&p.canRuntime(sender));}
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      if (!message || typeof message.type !== "string" || (message.type.indexOf("EXTUI_INTEGRATION_") !== 0 && message.type.indexOf("EXTUI_AI_") !== 0 && message.type.indexOf("EXTUI_EXTERNAL_ACTION_") !== 0)) return;
      var isAi = message.type.indexOf("EXTUI_AI_") === 0;
      var allowed = isAi ? senderCanRuntime(sender) : senderIsExtensionPage(sender);
      if (!allowed) { sendResponse({ ok: false, errorCode: "UNAUTHORIZED_SENDER", userMessage: "Esta operação não é permitida neste contexto." }); return; }
      Promise.resolve().then(function () { return extServerAuthorityRequire(isAi?"ai.agents":"integrations.manage"); }).then(function () { return extPlanRequirePaidBg(isAi?"assistentes-ia":"integracoes"); }).then(function () { return runtime.handle(message); }).then(sendResponse).catch(function (error) { sendResponse({ ok: false, errorCode: error && error.code || "EXTENSION_INTEGRITY_FAILED", userMessage: error && error.message || "A instalação da extensão não passou na verificação de integridade." }); });
      return true;
    });
  }
})(typeof globalThis !== "undefined" ? globalThis : this);;
