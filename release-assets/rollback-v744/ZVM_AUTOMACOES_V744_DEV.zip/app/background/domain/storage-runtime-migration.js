(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extKnowledgeIdb = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var DB_NAME = "EXTAPPKnowledgeDB";
  var DB_VERSION = 1;
  var DOCUMENTS = "documents";
  var REVISIONS = "revisions";
  var CHUNKS = "trechos";
  var repositoryClosers = new Set();

  function requestResult(request) {
    return new Promise(function (resolve, reject) {
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || new Error("IndexedDB request failed")); };
    });
  }
  function transactionDone(transaction) {
    return new Promise(function (resolve, reject) {
      transaction.oncomplete = function () { resolve(); };
      transaction.onerror = function () { reject(transaction.error || new Error("IndexedDB transaction failed")); };
      transaction.onabort = function () { reject(transaction.error || new Error("IndexedDB transaction aborted")); };
    });
  }
  function probeDatabase(indexedDb, name) {
    return new Promise(function (resolve) {
      var request; try { request = indexedDb.open(name); } catch (_) { resolve(false); return; }
      request.onsuccess = function () {
        var db = request.result, ok = false;
        try {
          ok = db.objectStoreNames.contains(DOCUMENTS) && db.objectStoreNames.contains(REVISIONS) && db.objectStoreNames.contains(CHUNKS);
          if (ok) {
            var tx = db.transaction([DOCUMENTS, REVISIONS, CHUNKS], "readonly");
            ok = tx.objectStore(DOCUMENTS).keyPath === "id" && tx.objectStore(DOCUMENTS).indexNames.contains("baseId") &&
              tx.objectStore(REVISIONS).keyPath === "storageId" && tx.objectStore(REVISIONS).indexNames.contains("baseId") &&
              tx.objectStore(CHUNKS).keyPath === "storageId" && tx.objectStore(CHUNKS).indexNames.contains("baseId") && tx.objectStore(CHUNKS).indexNames.contains("baseRevision");
          }
        } catch (_) { ok = false; }
        try { db.close(); } catch (_) {} resolve(ok);
      };
      request.onerror = function () { resolve(false); }; request.onblocked = function () { resolve(false); };
    });
  }
  async function resolveDatabaseName(indexedDb) {
    if (!indexedDb || typeof indexedDb.databases !== "function") return DB_NAME;
    try {
      var list = await indexedDb.databases();
      if ((list || []).some(function (row) { return row && row.name === DB_NAME; })) return DB_NAME;
      for (var i = 0; i < (list || []).length; i++) {
        var name = String(list[i] && list[i].name || "");
        if (!name || name === DB_NAME) continue;
        if (!await probeDatabase(indexedDb, name)) continue;
        var migration = globalThis.__extIdbNeutralMigration;
        if (!migration || typeof migration.migrate !== "function") return name;
        try {
          var result = await migration.migrate({
            indexedDB: indexedDb,
            sourceName: name,
            targetName: DB_NAME,
            version: DB_VERSION,
            allowExistingTarget: true,
            probe: function (db) {
              try {
                if (!db.objectStoreNames.contains(DOCUMENTS) || !db.objectStoreNames.contains(REVISIONS) || !db.objectStoreNames.contains(CHUNKS)) return false;
                var tx = db.transaction([DOCUMENTS, REVISIONS, CHUNKS], "readonly");
                return tx.objectStore(DOCUMENTS).keyPath === "id" && tx.objectStore(DOCUMENTS).indexNames.contains("baseId") &&
                  tx.objectStore(REVISIONS).keyPath === "storageId" && tx.objectStore(REVISIONS).indexNames.contains("baseId") &&
                  tx.objectStore(CHUNKS).keyPath === "storageId" && tx.objectStore(CHUNKS).indexNames.contains("baseId") && tx.objectStore(CHUNKS).indexNames.contains("baseRevision");
              } catch (_) { return false; }
            },
            upgrade: function (db) {
              if (!db.objectStoreNames.contains(DOCUMENTS)) { var documents = db.createObjectStore(DOCUMENTS, { keyPath: "id" }); documents.createIndex("baseId", "baseId", { unique: false }); }
              if (!db.objectStoreNames.contains(REVISIONS)) { var revisions = db.createObjectStore(REVISIONS, { keyPath: "storageId" }); revisions.createIndex("baseId", "baseId", { unique: false }); }
              if (!db.objectStoreNames.contains(CHUNKS)) { var chunks = db.createObjectStore(CHUNKS, { keyPath: "storageId" }); chunks.createIndex("baseId", "baseId", { unique: false }); chunks.createIndex("baseRevision", "baseRevision", { unique: false }); }
            },
            stores: [{ name: DOCUMENTS }, { name: REVISIONS }, { name: CHUNKS }]
          });
          if (result && result.migrated) return DB_NAME;
        } catch (error) {
          if (globalThis.__extReportRuntimeError) globalThis.__extReportRuntimeError("KNOWLEDGE_STORAGE_NEUTRALIZATION_FAILED", error);
        }
        return name;
      }
    } catch (_) {}
    return DB_NAME;
  }
  function open(indexedDb, onVersionChange) {
    return resolveDatabaseName(indexedDb).then(function (databaseName) { return new Promise(function (resolve, reject) {
      var settled = false, request = indexedDb.open(databaseName, DB_VERSION);
      request.onupgradeneeded = function () {
        var db = request.result;
        if (!db.objectStoreNames.contains(DOCUMENTS)) {
          var documents = db.createObjectStore(DOCUMENTS, { keyPath: "id" });
          documents.createIndex("baseId", "baseId", { unique: false });
        }
        if (!db.objectStoreNames.contains(REVISIONS)) {
          var revisions = db.createObjectStore(REVISIONS, { keyPath: "storageId" });
          revisions.createIndex("baseId", "baseId", { unique: false });
        }
        if (!db.objectStoreNames.contains(CHUNKS)) {
          var chunks = db.createObjectStore(CHUNKS, { keyPath: "storageId" });
          chunks.createIndex("baseId", "baseId", { unique: false });
          chunks.createIndex("baseRevision", "baseRevision", { unique: false });
        }
      };
      request.onsuccess = function () { var db=request.result;if(settled){try{db.close();}catch(_){}return;}settled=true;db.onversionchange=function(){try{db.close();}catch(_){} if(typeof onVersionChange==="function")onVersionChange();}; resolve(db); };
      request.onerror = function () { if(settled)return;settled=true;reject(request.error || new Error("IndexedDB open failed")); };
      request.onblocked = function () { if(settled)return;settled=true;reject(new Error("IndexedDB open blocked")); };
    }); });
  }
  function deleteIndexRecords(store, indexName, value) {
    return new Promise(function (resolve, reject) {
      var request = store.index(indexName).openKeyCursor(IDBKeyRange.only(value));
      request.onsuccess = function () {
        var cursor = request.result;
        if (!cursor) { resolve(); return; }
        store.delete(cursor.primaryKey); cursor.continue();
      };
      request.onerror = function () { reject(request.error || new Error("IndexedDB cursor failed")); };
    });
  }

  function createRepository(indexedDb) {
    var databasePromise = null;
    function resetDatabasePromise() { databasePromise = null; }
    function database() { if (!databasePromise) { var pending=open(indexedDb, resetDatabasePromise);databasePromise=pending;pending.catch(function(){if(databasePromise===pending)databasePromise=null;}); } return databasePromise; }
    async function close() { var pending=databasePromise; databasePromise=null; if(!pending)return; try{var db=await pending;if(db&&typeof db.close==="function")db.close();}catch(_){} }
    async function listDocuments(baseId) {
      var db = await database(); var tx = db.transaction(DOCUMENTS, "readonly");
      var rows = await requestResult(tx.objectStore(DOCUMENTS).index("baseId").getAll(baseId));
      return rows.sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
    }
    async function getDocument(documentId) {
      var db = await database(); var tx = db.transaction(DOCUMENTS, "readonly");
      var row = await requestResult(tx.objectStore(DOCUMENTS).get(documentId)); return row || null;
    }
    async function putDocument(document) {
      var db = await database(); var tx = db.transaction(DOCUMENTS, "readwrite");
      var done = transactionDone(tx); tx.objectStore(DOCUMENTS).put(document); await done; return document;
    }
    async function removeDocument(documentId) {
      var db = await database(); var tx = db.transaction(DOCUMENTS, "readwrite");
      var done = transactionDone(tx); tx.objectStore(DOCUMENTS).delete(documentId); await done;
    }
    async function saveRevision(revision, chunks) {
      var db = await database(); var tx = db.transaction([REVISIONS, CHUNKS], "readwrite");
      var done = transactionDone(tx);
      var revisionRecord = Object.assign({}, revision, { storageId: revision.baseId + ":" + revision.revision });
      tx.objectStore(REVISIONS).put(revisionRecord);
      chunks.forEach(function (chunk) {
        tx.objectStore(CHUNKS).put(Object.assign({}, chunk, {
          storageId: revision.baseId + ":" + revision.revision + ":" + chunk.id,
          baseId: revision.baseId, baseRevision: revision.baseId + ":" + revision.revision
        }));
      });
      await done; return revisionRecord;
    }
    async function getRevision(baseId, revisionId) {
      var db = await database(); var tx = db.transaction(REVISIONS, "readonly");
      var row = await requestResult(tx.objectStore(REVISIONS).get(baseId + ":" + revisionId)); return row || null;
    }
    async function listChunks(baseId, revisionId) {
      var db = await database(); var tx = db.transaction(CHUNKS, "readonly");
      var rows = await requestResult(tx.objectStore(CHUNKS).index("baseRevision").getAll(baseId + ":" + revisionId));
      return rows.sort(function (a, b) { return a.ordinal - b.ordinal; });
    }
    async function deleteRevision(baseId, revisionId) {
      var db = await database(); var tx = db.transaction([REVISIONS, CHUNKS], "readwrite");
      var done = transactionDone(tx);
      tx.objectStore(REVISIONS).delete(baseId + ":" + revisionId);
      await deleteIndexRecords(tx.objectStore(CHUNKS), "baseRevision", baseId + ":" + revisionId);
      await done;
    }
    async function deleteBase(baseId) {
      var db = await database(); var tx = db.transaction([DOCUMENTS, REVISIONS, CHUNKS], "readwrite");
      var done = transactionDone(tx);
      await Promise.all([
        deleteIndexRecords(tx.objectStore(DOCUMENTS), "baseId", baseId),
        deleteIndexRecords(tx.objectStore(REVISIONS), "baseId", baseId),
        deleteIndexRecords(tx.objectStore(CHUNKS), "baseId", baseId)
      ]);
      await done;
    }
    var api=Object.freeze({ listDocuments: listDocuments, getDocument: getDocument, putDocument: putDocument, removeDocument: removeDocument, saveRevision: saveRevision, getRevision: getRevision, listChunks: listChunks, deleteRevision: deleteRevision, deleteBase: deleteBase, close: close }); repositoryClosers.add(close); return api;
  }

  function createMemoryRepository() {
    var documents = new Map(); var revisions = new Map(); var chunks = new Map();
    function copy(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
    return Object.freeze({
      listDocuments: async function (baseId) { return Array.from(documents.values()).filter(function (item) { return item.baseId === baseId; }).map(copy); },
      getDocument: async function (id) { return copy(documents.get(id) || null); },
      putDocument: async function (document) { documents.set(document.id, copy(document)); return copy(document); },
      removeDocument: async function (id) { documents.delete(id); },
      saveRevision: async function (revision, list) {
        var key = revision.baseId + ":" + revision.revision; revisions.set(key, copy(revision));
        chunks.set(key, copy(list)); return copy(revision);
      },
      getRevision: async function (baseId, revisionId) { return copy(revisions.get(baseId + ":" + revisionId) || null); },
      listChunks: async function (baseId, revisionId) { return copy(chunks.get(baseId + ":" + revisionId) || []); },
      deleteRevision: async function (baseId, revisionId) { var key = baseId + ":" + revisionId; revisions.delete(key); chunks.delete(key); },
      deleteBase: async function (baseId) {
        Array.from(documents.values()).forEach(function (item) { if (item.baseId === baseId) documents.delete(item.id); });
        Array.from(revisions.keys()).forEach(function (key) { if (key.indexOf(baseId + ":") === 0) revisions.delete(key); });
        Array.from(chunks.keys()).forEach(function (key) { if (key.indexOf(baseId + ":") === 0) chunks.delete(key); });
      },
      debug: function () { return { documents: documents, revisions: revisions, chunks: chunks }; }
    });
  }

  async function closeAll() { var jobs=[]; repositoryClosers.forEach(function(close){jobs.push(Promise.resolve().then(close));}); await Promise.all(jobs); }
  return Object.freeze({ DB_NAME: DB_NAME, DB_VERSION: DB_VERSION, createRepository: createRepository, createMemoryRepository: createMemoryRepository, closeAll: closeAll });
});

                                                                                  
if (self.__extNamespaceMigrationReady && typeof self.__extNamespaceMigrationReady.catch === "function") self.__extNamespaceMigrationReady.catch(function () { return null; });

var _extuiCrmProfessionalWrite = Promise.resolve();

function mutateCrmProfessionalStore(operation) {
  var core = self.__extCrmProfessionalCore;
  if (!core || typeof core.applyOperation !== "function") return Promise.reject(new Error("CRM Professional Core indisponível."));
  var job = _extuiCrmProfessionalWrite.catch(function () {}).then(async function () {
    var stored = await chrome.storage.local.get(core.STORE_KEY);
    var current = core.normalizeStore(stored && stored[core.STORE_KEY]);
    var outcome = core.applyOperation(current, operation);
    outcome.store.revision = current.revision + 1;
    var payload = {};
    payload[core.STORE_KEY] = core.serializeStore(outcome.store);
    await chrome.storage.local.set(payload);
    return outcome;
  });
  _extuiCrmProfessionalWrite = job.catch(function () {});
  return job;
}

                                                                            
                                                                    
self.__extCrmProfessionalMutate = mutateCrmProfessionalStore;
