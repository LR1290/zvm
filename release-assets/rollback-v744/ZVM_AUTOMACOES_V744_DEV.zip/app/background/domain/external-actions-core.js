(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extExternalActionsCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

                                                                         
                                                                          
                                                                            
                                                                     
                                                                           
                                                                       
                                       

  var STORE_KEY = "EXTUI:externalActionsStore";
  var SECRETS_KEY = "EXTUI:externalActionSecrets";
  var SCHEMA_VERSION = 1;
  var METHODS = Object.freeze(["GET", "POST"]);
  var AUTH_MODES = Object.freeze(["none", "bearer", "apiKeyHeader"]);
  var FIELD_TYPES = Object.freeze(["text", "number", "boolean"]);
  var RESPONSE_MODES = Object.freeze(["statusOnly", "selectedFields"]);
  var MAX_FIELDS = 20;
  var MAX_TEXT_FIELD_LENGTH = 2000;
  var MAX_RESPONSE_PATHS = 10;
  var MAX_RESPONSE_PATH_DEPTH = 6;
  var MAX_RAW_RESPONSE_BYTES = 256 * 1024;
  var MAX_OUTPUT_BYTES = 12 * 1024;
  var REQUEST_TIMEOUT_MS = 20000;
                                                                       
                                                                
  var FORBIDDEN_HEADER_NAMES = Object.freeze(["host", "origin", "referer", "cookie", "set-cookie", "content-length", "connection", "transfer-encoding", "authorization"]);
  var RESERVED_KEYS = Object.freeze(["__proto__", "prototype", "constructor"]);
  var FIELD_NAME_PATTERN = /^[A-Za-z][A-Za-z0-9_]{0,63}$/;
  var HEADER_NAME_PATTERN = /^[A-Za-z0-9!#$%&'*+\-.^_`|~]+$/;
  var RESPONSE_PATH_SEGMENT = /^[A-Za-z][A-Za-z0-9_]{0,63}$/;

  var ERRORS = Object.freeze({
    NOT_FOUND: "EXTERNAL_ACTION_NOT_FOUND",
    NOT_ALLOWED: "EXTERNAL_ACTION_NOT_ALLOWED",
    DISABLED: "EXTERNAL_ACTION_DISABLED",
    PERMISSION_REQUIRED: "EXTERNAL_ACTION_PERMISSION_REQUIRED",
    INVALID_URL: "EXTERNAL_ACTION_INVALID_URL",
    INVALID_ARGUMENTS: "EXTERNAL_ACTION_INVALID_ARGUMENTS",
    AUTH_MISSING: "EXTERNAL_ACTION_AUTH_MISSING",
    TIMEOUT: "EXTERNAL_ACTION_TIMEOUT",
    CANCELLED: "EXTERNAL_ACTION_CANCELLED",
    NETWORK_ERROR: "EXTERNAL_ACTION_NETWORK_ERROR",
    HTTP_ERROR: "EXTERNAL_ACTION_HTTP_ERROR",
    RESPONSE_TOO_LARGE: "EXTERNAL_ACTION_RESPONSE_TOO_LARGE",
    INVALID_RESPONSE: "EXTERNAL_ACTION_INVALID_RESPONSE",
    INVALID: "EXTERNAL_ACTION_INVALID"
  });

  function object(value) { return !!value && typeof value === "object" && !Array.isArray(value); }
  function text(value, maxLength) { var s = typeof value === "string" ? value.trim() : ""; return maxLength ? s.slice(0, maxLength) : s; }
  function timestamp(value) { return Number.isFinite(Number(value)) ? Number(value) : null; }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function safeKey(key) { return RESERVED_KEYS.indexOf(key) < 0; }
  function actionError(code, message) { var error = new Error(message || code); error.code = code; return error; }
                                                                                   
                                                                    
  function parse(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { return null; }
  }

                                                                            
                                                                           
                                                                         
                                                                      
                                                                       
                                                                       
  function isIPv4Literal(hostname) { return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname); }
  function isPrivateIPv4(hostname) {
    if (!isIPv4Literal(hostname)) return false;
    var parts = hostname.split(".").map(Number);
    if (parts.some(function (part) { return !Number.isInteger(part) || part < 0 || part > 255; })) return true;
    var a = parts[0], b = parts[1];
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    return false;
  }
  var EXACT_BLOCKED_HOSTNAMES = Object.freeze(["localhost", "0.0.0.0", "metadata.google.internal"]);
  var BLOCKED_HOSTNAME_SUFFIXES = Object.freeze([".localhost", ".local", ".internal", ".lan", ".home.arpa"]);
  function isBlockedHostname(hostname) {
    var h = String(hostname || "").toLowerCase().replace(/\.+$/, "");
    if (!h) return true;
    if (EXACT_BLOCKED_HOSTNAMES.indexOf(h) >= 0) return true;
    if (BLOCKED_HOSTNAME_SUFFIXES.some(function (suffix) { return h === suffix.slice(1) || h.slice(-suffix.length) === suffix; })) return true;
    if (isPrivateIPv4(h)) return true;
                                                                            
                                                                               
    if (h.indexOf(":") >= 0) return true;
    return false;
  }
  function validateActionUrl(rawUrl) {
    var value = text(rawUrl, 2000);
    if (!value) throw actionError(ERRORS.INVALID_URL, "Informe o endereço de destino da ação.");
    var parsed;
    try { parsed = new URL(value); } catch (error) { throw actionError(ERRORS.INVALID_URL, "URL inválida."); }
    if (parsed.protocol !== "https:") throw actionError(ERRORS.INVALID_URL, "Apenas endpoints https:// são permitidos.");
    if (parsed.username || parsed.password) throw actionError(ERRORS.INVALID_URL, "Credenciais na URL não são permitidas.");
    if (isBlockedHostname(parsed.hostname)) throw actionError(ERRORS.INVALID_URL, "Este endereço aponta para uma rede local ou privada e não é permitido.");
    return parsed;
  }
  function safeUrlOrNull(rawUrl) { try { return validateActionUrl(rawUrl); } catch (error) { return null; } }
  function actionOrigin(action) { var parsed = safeUrlOrNull(action && action.endpoint); return parsed ? parsed.origin : null; }

                                                        
  function validateHeaderName(name) {
    if (typeof name !== "string" || !name || name.length > 64) return false;
    if (/[\r\n]/.test(name)) return false;
    if (!HEADER_NAME_PATTERN.test(name)) return false;
    var lower = name.toLowerCase();
    if (FORBIDDEN_HEADER_NAMES.indexOf(lower) >= 0 || RESERVED_KEYS.indexOf(lower) >= 0) return false;
    return true;
  }

                                                               
  function validateFieldName(name) { return typeof name === "string" && FIELD_NAME_PATTERN.test(name) && RESERVED_KEYS.indexOf(name) < 0; }
  function normalizeFieldStrict(raw) {
    raw = object(raw) ? raw : {};
    var name = text(raw.name, 64);
    if (!validateFieldName(name)) throw actionError(ERRORS.INVALID, "Nome de campo inválido: \"" + name + "\".");
    var type = FIELD_TYPES.indexOf(raw.type) >= 0 ? raw.type : null;
    if (!type) throw actionError(ERRORS.INVALID, "Tipo de campo inválido para \"" + name + "\".");
    var field = { name: name, type: type, description: text(raw.description, 300), required: raw.required === true };
    if (Array.isArray(raw.enum) && raw.enum.length) field.enumValues = raw.enum.slice(0, 20).map(function (value) { return text(value, 120); }).filter(Boolean);
    return field;
  }
  function normalizeFieldsStrict(rawFields) {
    var list = Array.isArray(rawFields) ? rawFields : [];
    if (list.length > MAX_FIELDS) throw actionError(ERRORS.INVALID, "Máximo de " + MAX_FIELDS + " campos de entrada.");
    var seen = Object.create(null);
    return list.map(function (raw) {
      var field = normalizeFieldStrict(raw);
      if (seen[field.name]) throw actionError(ERRORS.INVALID, "Campo de entrada duplicado: \"" + field.name + "\".");
      seen[field.name] = true;
      return field;
    });
  }
  function normalizeFieldsLenient(rawFields) {
    try { return normalizeFieldsStrict(rawFields); } catch (error) { return []; }
  }

                                                                              
  function normalizeAuthStrict(raw) {
    raw = object(raw) ? raw : {};
    var mode = AUTH_MODES.indexOf(raw.mode) >= 0 ? raw.mode : "none";
    if (mode === "apiKeyHeader") {
      var headerName = text(raw.headerName, 64);
      if (!validateHeaderName(headerName)) throw actionError(ERRORS.INVALID, "O nome do campo personalizado é inválido ou reservado.");
      return { mode: mode, headerName: headerName };
    }
    return { mode: mode };
  }
  function normalizeAuthLenient(raw) {
    try { return normalizeAuthStrict(raw); } catch (error) { return { mode: "none" }; }
  }

                                                                  
  function validateResponsePath(path) {
    var segments = String(path || "").split(".");
    if (!segments.length || segments.length > MAX_RESPONSE_PATH_DEPTH) return false;
    return segments.every(function (segment) { return RESPONSE_PATH_SEGMENT.test(segment) && RESERVED_KEYS.indexOf(segment) < 0; });
  }
  function normalizeResponsePolicyStrict(raw) {
    raw = object(raw) ? raw : {};
    var mode = RESPONSE_MODES.indexOf(raw.mode) >= 0 ? raw.mode : "statusOnly";
    if (mode !== "selectedFields") return { mode: "statusOnly", paths: [] };
    var paths = Array.isArray(raw.paths) ? raw.paths : [];
    if (paths.length > MAX_RESPONSE_PATHS) throw actionError(ERRORS.INVALID, "Máximo de " + MAX_RESPONSE_PATHS + " campos de resposta.");
    var normalized = paths.map(function (path) { return text(path, 200); }).filter(Boolean);
    normalized.forEach(function (path) { if (!validateResponsePath(path)) throw actionError(ERRORS.INVALID, "Caminho de resposta inválido: \"" + path + "\"."); });
    return { mode: mode, paths: normalized };
  }
  function normalizeResponsePolicyLenient(raw) {
    try { return normalizeResponsePolicyStrict(raw); } catch (error) { return { mode: "statusOnly", paths: [] }; }
  }

                        
                                                                       
                                                                       
                                          
  function normalizeAction(raw) {
    if (!object(raw)) return null;
    var id = text(raw.id, 160);
    if (!id || !safeKey(id)) return null;
    return Object.freeze({
      id: id,
      name: text(raw.name, 80),
      description: text(raw.description, 600),
      endpoint: text(raw.endpoint, 2000),
      method: METHODS.indexOf(raw.method) >= 0 ? raw.method : "GET",
      auth: Object.freeze(normalizeAuthLenient(raw.auth)),
      fields: Object.freeze(normalizeFieldsLenient(raw.fields)),
      responsePolicy: Object.freeze(normalizeResponsePolicyLenient(raw.responsePolicy)),
      enabled: raw.enabled !== false,
      createdAt: timestamp(raw.createdAt),
      updatedAt: timestamp(raw.updatedAt)
    });
  }
  function normalizeStore(raw) {
    var parsed = parse(raw);
    var source = object(parsed) && object(parsed.state) ? parsed.state : parsed;
    var actions = source && Array.isArray(source.actions) ? source.actions.map(normalizeAction).filter(Boolean) : [];
    return { version: SCHEMA_VERSION, actions: actions };
  }
  function serializeStore(raw) {
    var store = normalizeStore(raw);
    return JSON.stringify({ state: { actions: store.actions }, version: SCHEMA_VERSION });
  }
                                                                                  
  function validateDraft(raw) {
    raw = object(raw) ? raw : {};
    var name = text(raw.name, 80);
    if (!name) throw actionError(ERRORS.INVALID, "Informe um nome para a ação.");
    var description = text(raw.description, 600);
    if (!description) throw actionError(ERRORS.INVALID, "Informe a descrição para a IA.");
    var endpoint = validateActionUrl(raw.endpoint).toString();
    var method = METHODS.indexOf(raw.method) >= 0 ? raw.method : null;
    if (!method) throw actionError(ERRORS.INVALID, "Esta opção não é aceita. Use “Consultar dados” ou “Enviar dados”.");
    return {
      name: name,
      description: description,
      endpoint: endpoint,
      method: method,
      auth: normalizeAuthStrict(raw.auth),
      fields: normalizeFieldsStrict(raw.fields),
      responsePolicy: normalizeResponsePolicyStrict(raw.responsePolicy),
      enabled: raw.enabled !== false
    };
  }
  function createAction(rawStore, draft, dependencies) {
    var store = normalizeStore(rawStore);
    var data = validateDraft(draft);
    var now = dependencies.now();
    var generatedId = text(dependencies.createId(), 160); if (!generatedId || !safeKey(generatedId)) throw actionError(ERRORS.INVALID, "Não foi possível criar a ação."); var action = Object.assign({ id: generatedId }, data, { createdAt: now, updatedAt: now });
    store.actions.push(action);
    return { store: store, action: clone(action) };
  }
  function updateAction(rawStore, actionId, draft, dependencies) {
    var store = normalizeStore(rawStore);
    var index = store.actions.findIndex(function (action) { return action.id === actionId; });
    if (index < 0) throw actionError(ERRORS.NOT_FOUND, "Ação externa não encontrada.");
    var current = store.actions[index];
    var updated = Object.assign({ id: current.id }, validateDraft(draft), { createdAt: current.createdAt, updatedAt: dependencies.now() });
    store.actions[index] = updated;
    return { store: store, action: clone(updated) };
  }
  function deleteAction(rawStore, actionId) {
    var store = normalizeStore(rawStore);
    var before = store.actions.length;
    store.actions = store.actions.filter(function (action) { return action.id !== actionId; });
    if (store.actions.length === before) throw actionError(ERRORS.NOT_FOUND, "Ação externa não encontrada.");
    return { store: store, deletedId: actionId };
  }
  function countAssistantReferences(assistants, actionId) {
    return (Array.isArray(assistants) ? assistants : []).filter(function (assistant) {
      return assistant && assistant.externalActions && Array.isArray(assistant.externalActions.enabled) && assistant.externalActions.enabled.indexOf(actionId) >= 0;
    }).length;
  }

                                                                            
                                                                          
                                                                    
  function resolveForExecution(rawStore, actionId, enabledActionIds) {
    var allowed = Array.isArray(enabledActionIds) ? enabledActionIds : [];
    if (allowed.indexOf(actionId) < 0) throw actionError(ERRORS.NOT_ALLOWED, "Esta ação não está autorizada para este Assistente.");
    var action = normalizeStore(rawStore).actions.find(function (entry) { return entry.id === actionId; });
    if (!action) throw actionError(ERRORS.NOT_FOUND, "Ação externa não encontrada.");
    if (!action.enabled) throw actionError(ERRORS.DISABLED, "Esta ação externa está desativada.");
    var origin = actionOrigin(action);
    if (!origin) throw actionError(ERRORS.INVALID_URL, "O endereço de destino desta ação precisa ser revisado.");
    return action;
  }

                                                     
  function validateArguments(action, rawArguments) {
    var parsed = rawArguments;
    if (typeof rawArguments === "string") { try { parsed = JSON.parse(rawArguments); } catch (error) { throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumentos inválidos."); } }
    if (!object(parsed)) throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumentos inválidos.");
    var fieldsByName = Object.create(null);
    (action.fields || []).forEach(function (field) { fieldsByName[field.name] = field; });
    Object.keys(parsed).forEach(function (key) {
      if (!safeKey(key) || !fieldsByName[key]) throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumento não declarado: \"" + key + "\".");
    });
    (action.fields || []).forEach(function (field) {
      if (field.required && !Object.prototype.hasOwnProperty.call(parsed, field.name)) throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumento obrigatório ausente: \"" + field.name + "\".");
    });
    var result = {};
    Object.keys(parsed).forEach(function (key) {
      var field = fieldsByName[key];
      var value = parsed[key];
      if (field.type === "text") {
        if (typeof value !== "string") throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumento \"" + key + "\" deve ser texto.");
        if (value.length > MAX_TEXT_FIELD_LENGTH) throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumento \"" + key + "\" excede o tamanho máximo.");
        if (field.enumValues && field.enumValues.indexOf(value) < 0) throw actionError(ERRORS.INVALID_ARGUMENTS, "Valor não permitido para \"" + key + "\".");
        result[key] = value;
      } else if (field.type === "number") {
        if (typeof value !== "number" || !Number.isFinite(value)) throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumento \"" + key + "\" deve ser numérico.");
        result[key] = value;
      } else if (field.type === "boolean") {
        if (typeof value !== "boolean") throw actionError(ERRORS.INVALID_ARGUMENTS, "Argumento \"" + key + "\" deve ser verdadeiro/falso.");
        result[key] = value;
      } else {
        throw actionError(ERRORS.INVALID_ARGUMENTS, "Tipo de argumento desconhecido para \"" + key + "\".");
      }
    });
    return result;
  }

                                                                        
                                                                        
                                                                         
                                      
  function buildFieldsSchema(action) {
    var properties = {};
    var required = [];
    (action.fields || []).forEach(function (field) {
      var propertySchema = { type: field.type === "number" ? "number" : field.type === "boolean" ? "boolean" : "string", description: field.description || undefined };
      if (field.enumValues) propertySchema.enum = field.enumValues.slice();
      properties[field.name] = propertySchema;
      if (field.required) required.push(field.name);
    });
    return { type: "object", properties: properties, required: required, additionalProperties: false };
  }

                                                                           
  function buildRequest(action, args) {
    var url = new URL(action.endpoint);
    if (action.method === "GET") {
      Object.keys(args).forEach(function (key) { url.searchParams.set(key, String(args[key])); });
      return { url: url.toString(), method: "GET", headers: { "Accept": "application/json" }, body: null };
    }
    return { url: url.toString(), method: "POST", headers: { "Accept": "application/json", "Content-Type": "application/json" }, body: JSON.stringify(args) };
  }

                                                                            
  function extractPath(source, path) {
    var segments = path.split(".");
    var current = source;
    for (var i = 0; i < segments.length; i++) {
      var segment = segments[i];
      if (!safeKey(segment)) return undefined;
      if (current == null || typeof current !== "object") return undefined;
      if (!Object.prototype.hasOwnProperty.call(current, segment)) return undefined;
      current = current[segment];
    }
    return current;
  }
  function safeOutputValue(value) {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
    if (Array.isArray(value)) return value.slice(0, 20).map(function (entry) { return (entry === null || typeof entry === "string" || typeof entry === "number" || typeof entry === "boolean") ? entry : null; });
    return undefined;
  }
  function extractResponseFields(json, paths) {
    var output = {};
    (paths || []).forEach(function (path) {
      var raw = extractPath(json, path);
      var safe = safeOutputValue(raw);
      if (safe !== undefined) output[path] = safe;
    });
    return output;
  }

                                                                          
                                                    
  function redactSecret(payload, secretValue) {
    if (!secretValue) return payload;
    var serialized = JSON.stringify(payload);
    if (serialized.indexOf(secretValue) < 0) return payload;
    return JSON.parse(serialized.split(secretValue).join("[REDACTED]"));
  }

                                                                 
  function applyResponsePolicy(action, httpStatus, rawText) {
    if (action.responsePolicy.mode === "statusOnly" || !rawText) {
      return { success: httpStatus >= 200 && httpStatus < 300, status: httpStatus };
    }
    var parsed;
    try { parsed = JSON.parse(rawText); } catch (error) { throw actionError(ERRORS.INVALID_RESPONSE, "A resposta recebida está em um formato inválido."); }
    var fields = extractResponseFields(parsed, action.responsePolicy.paths);
    var output = Object.assign({ success: httpStatus >= 200 && httpStatus < 300, status: httpStatus }, fields);
    var outputText = JSON.stringify(output);
    if (outputText.length > MAX_OUTPUT_BYTES) throw actionError(ERRORS.RESPONSE_TOO_LARGE, "A resposta extraída excede o limite seguro.");
    return output;
  }

  return Object.freeze({
    STORE_KEY: STORE_KEY,
    SECRETS_KEY: SECRETS_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    METHODS: METHODS,
    AUTH_MODES: AUTH_MODES,
    FIELD_TYPES: FIELD_TYPES,
    RESPONSE_MODES: RESPONSE_MODES,
    ERRORS: ERRORS,
    MAX_FIELDS: MAX_FIELDS,
    MAX_RESPONSE_PATHS: MAX_RESPONSE_PATHS,
    MAX_RAW_RESPONSE_BYTES: MAX_RAW_RESPONSE_BYTES,
    MAX_OUTPUT_BYTES: MAX_OUTPUT_BYTES,
    REQUEST_TIMEOUT_MS: REQUEST_TIMEOUT_MS,
    FORBIDDEN_HEADER_NAMES: FORBIDDEN_HEADER_NAMES,
    validateActionUrl: validateActionUrl,
    isBlockedHostname: isBlockedHostname,
    validateHeaderName: validateHeaderName,
    actionOrigin: actionOrigin,
    normalizeAction: normalizeAction,
    normalizeStore: normalizeStore,
    serializeStore: serializeStore,
    validateDraft: validateDraft,
    createAction: createAction,
    updateAction: updateAction,
    deleteAction: deleteAction,
    countAssistantReferences: countAssistantReferences,
    resolveForExecution: resolveForExecution,
    validateArguments: validateArguments,
    buildFieldsSchema: buildFieldsSchema,
    buildRequest: buildRequest,
    extractResponseFields: extractResponseFields,
    redactSecret: redactSecret,
    applyResponsePolicy: applyResponsePolicy
  });
});;
