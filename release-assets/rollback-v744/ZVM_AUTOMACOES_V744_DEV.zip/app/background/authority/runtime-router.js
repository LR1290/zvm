chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {

  if (msg && (msg.type === "EXTUI_PANEL_DRAFT_GET" || msg.type === "EXTUI_PANEL_DRAFT_SET" || msg.type === "EXTUI_PANEL_DRAFT_CLEAR")) {
    if (!extSenderIsWhatsApp(sender) || !sender.tab || !Number.isInteger(sender.tab.id)) { sendResponse({ ok:false, errorCode:"UNAUTHORIZED_SENDER" }); return; }
    var draftPanelKey=String(msg.panelKey||"");
    if(!/^[A-Za-z0-9:_-]{3,120}$/.test(draftPanelKey)){sendResponse({ok:false,errorCode:"PANEL_DRAFT_KEY_INVALID"});return;}
    var draftStoreKey="EXTUI:panelDraft:"+sender.tab.id+":"+draftPanelKey, now=Date.now(), ttl=6*60*60*1000;
    Promise.resolve().then(async function(){
      if(!chrome.storage||!chrome.storage.session)throw extError("PANEL_DRAFT_SESSION_UNAVAILABLE","Persistência temporária indisponível.");
      if(msg.type==="EXTUI_PANEL_DRAFT_CLEAR"){await chrome.storage.session.remove(draftStoreKey);return{cleared:true};}
      if(msg.type==="EXTUI_PANEL_DRAFT_SET"){var state=msg.state&&typeof msg.state==="object"?msg.state:null;if(!state||extJsonBytes(state)>192*1024)throw extError("PANEL_DRAFT_TOO_LARGE","Estado temporário grande demais.");await chrome.storage.session.set({[draftStoreKey]:{expiresAt:now+ttl,state:state}});return{stored:true};}
      var got=await chrome.storage.session.get(draftStoreKey),record=got&&got[draftStoreKey];if(!record||Number(record.expiresAt||0)<=now){if(record)await chrome.storage.session.remove(draftStoreKey);return{state:null};}return{state:record.state&&typeof record.state==="object"?record.state:null};
    }).then(function(result){sendResponse({ok:true,result:result});}).catch(function(err){sendResponse({ok:false,errorCode:err&&err.code||"PANEL_DRAFT_FAILED",userMessage:err&&err.message||"Não foi possível preservar o estado temporário."});});
    return true;
  }
  if (msg && msg.type === "EXTUI_FLOW_WEBHOOK_SEND") { Promise.resolve().then(function(){extAssertSender(extSenderIsWhatsApp(sender),"UNAUTHORIZED_SENDER","O aviso automático do fluxo só pode ser enviado pela área segura do WhatsApp.");return extServerAuthorityRequire("flows.manage");}).then(function(){return extPlanRequirePaidBg("fluxos");}).then(function(){return extFlowWebhookSend(msg);}).then(function(result){sendResponse({ok:true,result:result});}).catch(function(err){var code=err.code||"FLOW_WEBHOOK_ERROR",text=err.message||"Falha ao enviar o aviso automático do fluxo.";sendResponse({ok:false,errorCode:code,userMessage:text,error:{code:code,message:text}});}); return true; }
  if (msg && typeof msg.type === "string" && msg.type.indexOf("EXTUI_TRACKING_") === 0) { var trackingSecret=/^EXTUI_TRACKING_SECRET_(SET|REMOVE|STATUS)$/.test(msg.type),trackingReadOnly=msg.type==="EXTUI_TRACKING_SECRET_STATUS";Promise.resolve().then(function(){extAssertSender(trackingSecret?extSenderIsExtensionPage(sender):extSenderCanRuntime(sender),"UNAUTHORIZED_SENDER","Esta operação de rastreamento não é permitida neste contexto.");return extServerAuthorityRequire("integrations.manage");}).then(function(){return trackingReadOnly?null:extPlanRequirePaidBg("integracoes");}).then(function(){return extTrackingHandle(msg);}).then(function(result){sendResponse({ok:true,result:result});}).catch(function(err){var code=err.code||"TRACKING_ERROR",text=err.message||"Falha na integração de rastreamento.";sendResponse({ok:false,errorCode:code,userMessage:text,error:{code:code,message:text}});}); return true; }
  if (msg && typeof msg.type === "string" && msg.type.indexOf("EXTUI_WEBHOOK_") === 0) { var webhookSecret=/^EXTUI_WEBHOOK_SECRET_(SET|REMOVE|STATUS)$/.test(msg.type),webhookReadOnly=msg.type==="EXTUI_WEBHOOK_SECRET_STATUS";Promise.resolve().then(function(){extAssertSender(webhookSecret?extSenderIsExtensionPage(sender):extSenderCanRuntime(sender),"UNAUTHORIZED_SENDER","Esta operação de aviso automático não é permitida neste contexto.");return extServerAuthorityRequire("integrations.manage");}).then(function(){return webhookReadOnly?null:extPlanRequirePaidBg("integracoes");}).then(function(){return extWebhookHandle(msg);}).then(function(result){sendResponse({ok:true,result:result});}).catch(function(err){var code=err.code||"WEBHOOK_ERROR",text=err.message||"Falha no aviso automático.";sendResponse({ok:false,errorCode:code,userMessage:text,error:{code:code,message:text}});}); return true; }

  if (msg && msg.type === "EXTUI_OPEN_PROVIDER_HELP") {
    if (!extSenderIsExtensionPage(sender)) { sendResponse({ ok:false, errorCode:"UNAUTHORIZED_SENDER", userMessage:"Origem não autorizada." }); return; }
    var integrationCore = self.__extIntegrationCore;
    var providerHelpUrl = integrationCore && integrationCore.resolveProviderHelpLink(msg.provider, msg.linkType);
    if (!providerHelpUrl || !integrationCore.isAllowedProviderHelpUrl(providerHelpUrl)) {
      sendResponse({ ok: false, errorCode: "provider_help_link_rejected", userMessage: "Este destino oficial não está disponível." });
      return;
    }
    chrome.tabs.create({ url: providerHelpUrl }, function (tab) {
      if (chrome.runtime.lastError) sendResponse({ ok: false, errorCode: "provider_help_link_failed", userMessage: "Não foi possível abrir a página oficial." });
      else sendResponse({ ok: true, result: { opened: true, tabId: tab && tab.id } });
    });
    return true;
  }
  if (msg && msg.__extCrmProfessionalOperation === true) {
    if (!extSenderCanRuntime(sender)) { sendResponse({ ok:false, error:"Origem não autorizada." }); return; }
    var crmOperation = msg.operation && typeof msg.operation === "object" ? msg.operation : null;
    if (!crmOperation || extJsonBytes(crmOperation) > 128 * 1024) { sendResponse({ ok:false, error:"Operação CRM inválida ou grande demais." }); return; }
    if (extSenderIsWhatsApp(sender)) {
      var crmWhatsAllowed = { "note.add": true, "note.update": true, "note.remove": true, "task.add": true, "task.update": true, "task.remove": true, "event.add": true };
      if (!crmWhatsAllowed[String(crmOperation.type || "")]) { sendResponse({ ok:false, error:"Operação CRM não permitida a partir do WhatsApp." }); return; }
    }
    Promise.resolve().then(function(){return extServerAuthorityRequire("crm.use");}).then(function(){return extPlanRequirePaidBg("crm");}).then(function(){return mutateCrmProfessionalStore(crmOperation);}).then(function (outcome) {
      sendResponse({ ok: true, result: outcome.result || null });
    }).catch(function (error) {
      sendResponse({ ok: false, errorCode:error&&error.code||"CRM_OPERATION_FAILED", error: error && error.message ? error.message : String(error) });
    });
    return true;
  }
  if (msg && msg.__extOpenShell === true) {
    if (!extSenderCanRuntime(sender)) { sendResponse({ ok:false, error:"Origem não autorizada." }); return; }
    var shellUrl = chrome.runtime.getURL("pages/dashboard/index.html");
    var shellParams = new URLSearchParams();
    var shellSection=extSafeShellParam(msg.section,80), shellFocus=extSafeShellParam(msg.focus,120), shellCrmId=extSafeShellParam(msg.crmContactId,160), shellBoardId=extSafeShellParam(msg.crmId,160), shellCrmView=extSafeShellParam(msg.crmView,32), shellProfileTab=extSafeShellParam(msg.crmProfileTab,32), shellFlowId=extSafeShellParam(msg.flowId,160), shellFunnelId=extSafeShellParam(msg.funnelId,160);
    if (shellSection) shellParams.set("section", shellSection);
    if (shellFocus) shellParams.set("focus", shellFocus);
    if (shellCrmId) shellParams.set("crmContactId", shellCrmId);
    if (shellBoardId) shellParams.set("crmId", shellBoardId);
    if (shellCrmView) shellParams.set("crmView", shellCrmView);
    if (shellProfileTab) shellParams.set("crmProfileTab", shellProfileTab);
    if (shellFlowId) shellParams.set("flowId", shellFlowId);
    if (shellFunnelId) shellParams.set("funnelId", shellFunnelId);
    if (msg.crmCreate === true) shellParams.set("crmCreate", "1");
    if (msg.crmCopilot === true) shellParams.set("crmCopilot", "1");
    if (shellParams.toString()) shellUrl += "?" + shellParams.toString();
                                                                         
                                                                           
    var reuseShell = msg.newTab === true ? false : (msg.reuseExisting === true || extSenderIsWhatsApp(sender));
    if (!reuseShell) {
      chrome.tabs.create({ url: shellUrl }, function (tab) {
        if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        else sendResponse({ ok: true, tabId: tab && tab.id, reused: false });
      });
      return true;
    }
    var shellBaseUrl = chrome.runtime.getURL("pages/dashboard/index.html");
    Promise.resolve(chrome.runtime.getContexts({ contextTypes: ["TAB"] })).then(function (contexts) {
      var existingContext = (contexts || []).find(function (context) {
        return context && Number.isInteger(context.tabId) && context.tabId >= 0 && typeof context.documentUrl === "string" && context.documentUrl.indexOf(shellBaseUrl) === 0;
      });
      var existing = existingContext ? { id: existingContext.tabId, windowId: existingContext.windowId } : null;
      function focusWindow(tab) {
        if (chrome.windows && chrome.windows.update && tab && tab.windowId != null && tab.windowId >= 0) chrome.windows.update(tab.windowId, { focused: true });
      }
      if (existing) {
        chrome.tabs.update(existing.id, { active: true }, function (tab) {
          if (chrome.runtime.lastError) { sendResponse({ ok: false, error: chrome.runtime.lastError.message }); return; }
          focusWindow(tab || existing);
          var routeMessage = {
            __extShellNavigate: true,
            targetTabId: existing.id,
            section: shellSection || null,
            focus: shellFocus || null,
            crmContactId: shellCrmId || null,
            crmId: shellBoardId || null,
            crmView: shellCrmView || null,
            crmProfileTab: shellProfileTab || null,
            flowId: shellFlowId || null,
            funnelId: shellFunnelId || null,
            crmCreate: msg.crmCreate === true,
            crmCopilot: msg.crmCopilot === true
          };
          var completed = false;
          function fallbackToUrl() {
            if (completed) return;
            completed = true;
            chrome.tabs.update(existing.id, { active: true, url: shellUrl }, function (fallbackTab) {
              if (chrome.runtime.lastError) { sendResponse({ ok: false, error: chrome.runtime.lastError.message }); return; }
              focusWindow(fallbackTab || existing);
              sendResponse({ ok: true, tabId: existing.id, reused: true, reloaded: true });
            });
          }
          function dispatchRoute(attempt) {
            chrome.runtime.sendMessage(routeMessage, function (reply) {
              var err = chrome.runtime.lastError;
              if (!err && reply && reply.ok === true) {
                if (completed) return;
                completed = true;
                sendResponse({ ok: true, tabId: existing.id, reused: true, reloaded: false });
                return;
              }
              if (attempt < 4) { setTimeout(function () { dispatchRoute(attempt + 1); }, 140 + attempt * 90); return; }
              fallbackToUrl();
            });
          }
          dispatchRoute(0);
        });
        return;
      }
      chrome.tabs.create({ url: shellUrl }, function (tab) {
        if (chrome.runtime.lastError) { sendResponse({ ok: false, error: chrome.runtime.lastError.message }); return; }
        focusWindow(tab);
        sendResponse({ ok: true, tabId: tab && tab.id, reused: false });
      });
    }).catch(function (error) {
      sendResponse({ ok: false, error: error && error.message ? error.message : "Não foi possível localizar o Painel de Controle." });
    });
    return true;
  }
  if (msg && msg.__extSetKeepAwake === true) {
    if (!extSenderIsExtensionPage(sender)) { sendResponse({ ok:false, error:"Origem não autorizada." }); return; }
    try { applyKeepAwake(msg.level); sendResponse({ ok: true }); }
    catch (err) { sendResponse({ ok:false,error:err&&err.message||"Não foi possível aplicar a preferência de energia." }); }
  }
});

                                                                         
                                                                            
                                                                           
                                                                    
                                                                            
