function applyKeepAwake(level) {
  try {
    chrome.power.releaseKeepAwake();
    if (level === "system" || level === "display") chrome.power.requestKeepAwake(level);
    return true;
  } catch (err) {
    if (self.__extReportRuntimeError) self.__extReportRuntimeError("POWER_KEEP_AWAKE_FAILED", err);
    throw err;
  }
}

                                                                           
                                                                         
chrome.storage.local.get("EXTUI:extappOptionsStore", function (res) {
  try {
    if (chrome.runtime.lastError) throw new Error(chrome.runtime.lastError.message || "Não foi possível carregar a preferência de energia.");
    var raw = res && res["EXTUI:extappOptionsStore"];
    var opts = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null;
    if (opts && opts.keepAwakeLevel) applyKeepAwake(opts.keepAwakeLevel);
  } catch (err) { if (self.__extReportRuntimeError) self.__extReportRuntimeError("POWER_OPTIONS_BOOT_FAILED", err); }
});


                                                                         
                                                                            
