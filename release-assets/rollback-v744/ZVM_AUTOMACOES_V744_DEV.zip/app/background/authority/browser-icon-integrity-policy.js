(function(root){
  "use strict";
  var MODE="browser-icon-v1";
  var MAX_BYTES=256*1024;
  var ICONS=Object.freeze({
    "assets/icons/icon16.png":Object.freeze([16,16]),
    "assets/icons/icon32.png":Object.freeze([32,32]),
    "assets/icons/icon48.png":Object.freeze([48,48]),
    "assets/icons/icon64.png":Object.freeze([64,64]),
    "assets/icons/icon128.png":Object.freeze([128,128]),
    "assets/icons/icon128-action.png":Object.freeze([128,128])
  });
  var PNG_SIG=Object.freeze([137,80,78,71,13,10,26,10]);
  function fail(code){var e=new Error(code);e.code=code;throw e;}
  function u32be(bytes,offset){return (((bytes[offset]<<24)>>>0)|(bytes[offset+1]<<16)|(bytes[offset+2]<<8)|bytes[offset+3])>>>0;}
  function crc32Range(bytes,start,end){var crc=0xffffffff;for(var i=start;i<end;i++){crc^=bytes[i];for(var j=0;j<8;j++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return(crc^0xffffffff)>>>0;}
  function typeAt(bytes,offset){return String.fromCharCode(bytes[offset],bytes[offset+1],bytes[offset+2],bytes[offset+3]);}
  function validChunkType(bytes,offset){for(var i=0;i<4;i++){var c=bytes[offset+i];if(!((c>=65&&c<=90)||(c>=97&&c<=122)))return false;}return true;}
  function validate(path,bytes){
    path=String(path||"");
    var expected=ICONS[path];
    if(!expected)fail("BROWSER_ICON_PATH_UNTRUSTED");
    if(!(bytes instanceof Uint8Array))bytes=new Uint8Array(bytes||0);
    if(bytes.byteLength>MAX_BYTES)fail("BROWSER_ICON_TOO_LARGE");
    if(bytes.byteLength<33)fail("BROWSER_ICON_PNG_INVALID");
    for(var i=0;i<PNG_SIG.length;i++)if(bytes[i]!==PNG_SIG[i])fail("BROWSER_ICON_PNG_INVALID");
    var offset=8,sawIHDR=false,sawIEND=false,width=0,height=0;
    while(offset<bytes.byteLength){
      if(sawIEND)fail("BROWSER_ICON_PNG_TRAILING_DATA");
      if(offset+12>bytes.byteLength)fail("BROWSER_ICON_PNG_INVALID");
      var length=u32be(bytes,offset),typeOffset=offset+4,dataOffset=offset+8,crcOffset=dataOffset+length,end=crcOffset+4;
      if(!validChunkType(bytes,typeOffset)||end>bytes.byteLength)fail("BROWSER_ICON_PNG_INVALID");
      var type=typeAt(bytes,typeOffset);
      if(!sawIHDR){
        if(type!=="IHDR"||length!==13)fail("BROWSER_ICON_PNG_INVALID");
        width=u32be(bytes,dataOffset);height=u32be(bytes,dataOffset+4);
        if(width!==expected[0]||height!==expected[1])fail("BROWSER_ICON_DIMENSIONS_INVALID");
        if(bytes[dataOffset+8]!==8)fail("BROWSER_ICON_BIT_DEPTH_INVALID");
        var colorType=bytes[dataOffset+9];
        if(colorType!==2&&colorType!==3&&colorType!==6)fail("BROWSER_ICON_COLOR_TYPE_INVALID");
        if(bytes[dataOffset+10]!==0||bytes[dataOffset+11]!==0||(bytes[dataOffset+12]!==0&&bytes[dataOffset+12]!==1))fail("BROWSER_ICON_PNG_INVALID");
        sawIHDR=true;
      }else if(type==="IHDR")fail("BROWSER_ICON_PNG_INVALID");
      if(crc32Range(bytes,typeOffset,crcOffset)!==u32be(bytes,crcOffset))fail("BROWSER_ICON_PNG_CRC_INVALID");
      if(type==="IEND"){
        if(length!==0)fail("BROWSER_ICON_PNG_INVALID");
        sawIEND=true;
        if(end!==bytes.byteLength)fail("BROWSER_ICON_PNG_TRAILING_DATA");
      }
      offset=end;
    }
    if(!sawIHDR||!sawIEND)fail("BROWSER_ICON_PNG_INVALID");
    return{ok:true,path:path,width:width,height:height,bytes:bytes.byteLength};
  }
  root.__extBrowserIconIntegrityPolicy=Object.freeze({schema:1,mode:MODE,maxBytes:MAX_BYTES,paths:Object.freeze(Object.keys(ICONS)),validate:validate});
})(self);
