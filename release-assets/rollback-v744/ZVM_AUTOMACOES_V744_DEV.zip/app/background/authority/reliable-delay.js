try{
(function(){
  "use strict";
  var MAX_DELAY_MS=20000;
  chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){if(!message||message.type!=="EXTUI_RELIABLE_DELAY_WAIT")return false;var policy=globalThis.__extSenderPolicy;var allowed=!!(policy&&typeof policy.isWhatsApp==="function"&&typeof policy.isWhatsAppUrl==="function"&&policy.isWhatsApp(sender)&&policy.isWhatsAppUrl(sender&&sender.tab&&sender.tab.url));if(!allowed){sendResponse({ok:false,requestId:String(message.requestId||""),error:"UNAUTHORIZED"});return false;}var requestId=String(message.requestId||"");var delayMs=Math.max(0,Math.min(MAX_DELAY_MS,Number(message.delayMs)||0));if(!requestId||requestId.length>120){sendResponse({ok:false,requestId:requestId,error:"INVALID_REQUEST"});return false;}setTimeout(function(){try{sendResponse({ok:true,requestId:requestId,elapsedMs:delayMs});}catch(_){}},delayMs);return true;});
})();
}catch(_extuiReliableDelayAuthorityError){try{console.error("[EXTUI][RELIABLE_DELAY]",_extuiReliableDelayAuthorityError);}catch(_){}}
