(function(root){
  "use strict";
  var TRUSTED_UPDATE_URL="https://clients2.google.com/service/update2/crx";
  var TOP_LEVEL_BROWSER_MANAGED_FIELDS=Object.freeze(["key","update_url"]);
  function normalizeValue(value,depth){
    if(value===null||typeof value==="string"||typeof value==="boolean")return value;
    if(typeof value==="number"){
      if(!Number.isFinite(value))throw new Error("MANIFEST_CANONICAL_NUMBER_INVALID");
      return value;
    }
    if(Array.isArray(value))return value.map(function(item){return normalizeValue(item,depth+1);});
    if(value&&typeof value==="object"){
      var out={};
      Object.keys(value).sort(function(a,b){return a<b?-1:a>b?1:0;}).forEach(function(key){
        var child=value[key];
        if(depth===0&&key==="key"){if(typeof child!=="string"||!child.trim())throw new Error("MANIFEST_KEY_INVALID");return;}
        if(depth===0&&key==="update_url"){if(child!==TRUSTED_UPDATE_URL)throw new Error("MANIFEST_UPDATE_URL_UNTRUSTED");return;}
        if(child===undefined)throw new Error("MANIFEST_CANONICAL_UNDEFINED");
        out[key]=normalizeValue(child,depth+1);
      });
      return out;
    }
    throw new Error("MANIFEST_CANONICAL_TYPE_INVALID");
  }
  function normalize(manifest){
    if(!manifest||typeof manifest!=="object"||Array.isArray(manifest))throw new Error("MANIFEST_CANONICAL_ROOT_INVALID");
    return normalizeValue(manifest,0);
  }
  function canonicalize(manifest){return JSON.stringify(normalize(manifest));}
  function canonicalBytes(manifest){return new TextEncoder().encode(canonicalize(manifest));}
  root.__extManifestIntegrityPolicy=Object.freeze({
    schema:1,
    mode:"manifest-json-v1",
    browserManagedTopLevelFields:TOP_LEVEL_BROWSER_MANAGED_FIELDS,
    trustedUpdateUrl:TRUSTED_UPDATE_URL,
    normalize:normalize,
    canonicalize:canonicalize,
    canonicalBytes:canonicalBytes
  });
})(self);
