var __extWppMainBridgeInFlight = new Map();
function extWppTargetForSender(sender){var frameId=Number.isInteger(sender&&sender.frameId)?sender.frameId:0,documentId=sender&&typeof sender.documentId==="string"?sender.documentId:"";return documentId?{tabId:sender.tab.id,documentIds:[documentId]}:{tabId:sender.tab.id,frameIds:[frameId]};}
function extWppBridgeKey(sender){var frameId=Number.isInteger(sender&&sender.frameId)?sender.frameId:0,documentId=sender&&typeof sender.documentId==="string"?sender.documentId:"";return String(sender.tab.id)+":"+String(frameId)+":"+(documentId||"current");}
async function extEnsureWppMainBridge(sender){
  if(!extSenderIsWhatsApp(sender)||!sender.tab||!Number.isInteger(sender.tab.id)){var unauthorized=new Error("UNAUTHORIZED_SENDER");unauthorized.code="UNAUTHORIZED_SENDER";throw unauthorized;}
  if(!chrome.scripting||typeof chrome.scripting.executeScript!=="function"){var unavailable=new Error("SCRIPTING_UNAVAILABLE");unavailable.code="SCRIPTING_UNAVAILABLE";throw unavailable;}
  var target=extWppTargetForSender(sender),key=extWppBridgeKey(sender),inFlight=__extWppMainBridgeInFlight.get(key);
  if(inFlight)return inFlight;
  var work=(async function(){
    var connectedResult=await chrome.scripting.executeScript({target:target,world:"ISOLATED",func:function(){var selectors=["#pane-side","#side",'[aria-label="Lista de conversas"]','[aria-label="Chat list"]'];for(var i=0;i<selectors.length;i++){try{if(document.querySelector(selectors[i]))return true;}catch(_){}}return false;}});
    var connected=Array.isArray(connectedResult)&&connectedResult.some(function(entry){return entry&&entry.result===true;});
    if(!connected){var notConnected=new Error("WHATSAPP_NOT_CONNECTED");notConnected.code="WHATSAPP_NOT_CONNECTED";throw notConnected;}
    var existing=await chrome.scripting.executeScript({target:target,world:"MAIN",func:function(){var desc=Object.getOwnPropertyDescriptor(window,"__extWppBridge"),bridge=desc&&desc.value;return !!(desc&&desc.configurable===false&&desc.writable===false&&bridge&&bridge.__extSecureBridgeV2===true&&Object.isFrozen(bridge));}});
    if(Array.isArray(existing)&&existing.some(function(entry){return entry&&entry.result===true;}))return {injected:false,alreadyReady:true};
    var files=["app/bridge/main/wa-js-preconfig.js","vendor/wa-js/wa-js.js","app/bridge/main/secure-bridge.js"];
    for(var i=0;i<files.length;i++)await chrome.scripting.executeScript({target:target,world:"MAIN",files:[files[i]]});
    var verified=await chrome.scripting.executeScript({target:target,world:"MAIN",func:function(){var desc=Object.getOwnPropertyDescriptor(window,"__extWppBridge"),bridge=desc&&desc.value;return !!(desc&&desc.configurable===false&&desc.writable===false&&bridge&&bridge.__extSecureBridgeV2===true&&Object.isFrozen(bridge));}});
    if(!Array.isArray(verified)||!verified.some(function(entry){return entry&&entry.result===true;})){var failed=new Error("WPP_MAIN_BRIDGE_NOT_READY");failed.code="WPP_MAIN_BRIDGE_NOT_READY";throw failed;}
    return {injected:true,alreadyReady:false};
  })();
  __extWppMainBridgeInFlight.set(key,work);
  try{return await work;}finally{if(__extWppMainBridgeInFlight.get(key)===work)__extWppMainBridgeInFlight.delete(key);}
}

chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){
  if(!msg||msg.type!=="EXTUI_WPP_MAIN_BRIDGE_ENSURE")return;
  extEnsureWppMainBridge(sender).then(function(result){sendResponse({ok:true,injected:result.injected===true,alreadyReady:result.alreadyReady===true});}).catch(function(err){sendResponse({ok:false,error:err&&err.code||err&&err.message||"WPP_MAIN_BRIDGE_FAILED"});});
  return true;
});

var __extWppEventChannels = new Map();
function extBytesToBase64(bytes){var out="";for(var i=0;i<bytes.length;i++)out+=String.fromCharCode(bytes[i]);return btoa(out);}
function extRandomBase64(size){var bytes=new Uint8Array(size);crypto.getRandomValues(bytes);return extBytesToBase64(bytes);}
function extRandomId(){var bytes=new Uint8Array(16);crypto.getRandomValues(bytes);return Array.from(bytes).map(function(b){return b.toString(16).padStart(2,"0");}).join("");}

chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){
  if(!msg||msg.type!=="EXTUI_WPP_EVENT_CHANNEL_INIT")return;
  if(!extSenderIsWhatsApp(sender)||!sender.tab||!Number.isInteger(sender.tab.id)){sendResponse({ok:false,error:"UNAUTHORIZED_SENDER"});return;}
  if(!chrome.scripting||typeof chrome.scripting.executeScript!=="function"){sendResponse({ok:false,error:"SCRIPTING_UNAVAILABLE"});return;}
  var frameId=Number.isInteger(sender.frameId)?sender.frameId:0;
  var documentId=typeof sender.documentId==="string"?sender.documentId:"";
  var cacheKey=documentId?(sender.tab.id+":"+frameId+":"+documentId):null;
  var cached=cacheKey&&__extWppEventChannels.get(cacheKey);
  if(cached){sendResponse({ok:true,channelId:cached.channelId,keyB64:cached.keyB64});return;}
  var channelId="extapp-wpp-event:"+extRandomId(),keyB64=extRandomBase64(32);
  var injectionTarget=documentId?{tabId:sender.tab.id,documentIds:[documentId]}:{tabId:sender.tab.id,frameIds:[frameId]};
  chrome.scripting.executeScript({
    target:injectionTarget,
    world:"MAIN",
    func:function(channelId,keyB64){
      (function(){
        "use strict";
        var marker="__extSecureWppEventForwarder";
        var current=window[marker];
        if(current&&current.channelId===channelId&&current.ready!==false)return;
        if(current&&typeof current.dispose==="function"){try{current.dispose();}catch(_){}}
        var state={channelId:channelId,installedAt:Date.now(),ready:false,disposed:false};
        window[marker]=state;
        function b64ToBytes(text){var raw=atob(String(text||"")),out=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
        function bytesToB64(buffer){var bytes=new Uint8Array(buffer),raw="";for(var i=0;i<bytes.length;i++)raw+=String.fromCharCode(bytes[i]);return btoa(raw);}
        function canonical(seq,ts,name,payloadText){return ["EXTAPP-WPP-EVENT-V1",channelId,String(seq),String(ts),String(name),String(payloadText)].join("\n");}
        function safeJson(value){
          var seen=typeof WeakSet!=="undefined"?new WeakSet():null;
          try{return JSON.stringify(value===undefined?null:value,function(key,val){
            if(typeof val==="function"||typeof val==="symbol")return undefined;
            if(typeof val==="bigint")return String(val);
            if(val&&typeof val==="object"&&seen){if(seen.has(val))return undefined;seen.add(val);}
            return val;
          });}catch(_){return null;}
        }
        crypto.subtle.importKey("raw",b64ToBytes(keyB64),{name:"HMAC",hash:"SHA-256"},false,["sign","verify"]).then(function(key){
          var seq=0,encoder=new TextEncoder(),maxBytes=1024*1024,bound=false,tries=0,disposed=false,bindTimer=null,bridgeReadyHandler=null,messageHandler=null,unsubscribers=[];
          var rpcPending=new Map(),rpcSeen=new Set(),rpcVerifyInFlight=0,RPC_CHUNK=524288,RPC_MAX_CHUNKS=256,RPC_VERIFY_MAX=512,RPC_ID_MAX=160,RPC_TYPE_MAX=32,RPC_ACTION_MAX=64;
          function dispose(){
            if(disposed)return;disposed=true;state.disposed=true;state.ready=false;
            if(bindTimer){clearTimeout(bindTimer);bindTimer=null;}
            if(messageHandler){try{window.removeEventListener("message",messageHandler);}catch(_){ }messageHandler=null;}if(bridgeReadyHandler){try{window.removeEventListener("ext:wpp-bridge-ready",bridgeReadyHandler);}catch(_){ }bridgeReadyHandler=null;}
            rpcPending.forEach(function(rec){if(rec&&rec.timer)clearTimeout(rec.timer);});rpcPending.clear();rpcSeen.clear();
            while(unsubscribers.length){var unsubscribe=unsubscribers.pop();try{if(typeof unsubscribe==="function")unsubscribe();}catch(_){}}
          }
          state.dispose=dispose;
          function reqCanonical(d,chunk){return ["EXTAPP-WPP-RPC-REQ-CHUNK-V1",channelId,String(d.seq),String(d.id),String(d.type),String(d.action),String(d.index),String(d.total),chunk].join("\n");}
          function resCanonical(seqValue,id,index,total,chunk){return ["EXTAPP-WPP-RPC-RESP-CHUNK-V1",channelId,String(seqValue),String(id),String(index),String(total),chunk].join("\n");}
          async function verifyText(text,signature){try{return crypto.subtle.verify("HMAC",key,b64ToBytes(signature),encoder.encode(text));}catch(_){return false;}}
          async function signText(text){return bytesToB64(await crypto.subtle.sign("HMAC",key,encoder.encode(text)));}
          function chunkString(text){var out=[];if(!text.length)return[""];for(var i=0;i<text.length;i+=RPC_CHUNK)out.push(text.slice(i,i+RPC_CHUNK));return out;}
          function validSignature(value){return typeof value==="string"&&value.length===44&&/^[A-Za-z0-9+/]{43}=$/.test(value);}
          function validRpcToken(value,max){return typeof value==="string"&&value.length>0&&value.length<=max&&/^[A-Za-z0-9:_-]+$/.test(value);}
          function trustedBridge(){var desc=Object.getOwnPropertyDescriptor(window,"__extWppBridge"),bridge=desc&&desc.value;return desc&&desc.configurable===false&&desc.writable===false&&bridge&&bridge.__extSecureBridgeV2===true&&Object.isFrozen(bridge)&&typeof bridge.invoke==="function"&&typeof bridge.on==="function"?bridge:null;}
          function waitBridge(){return new Promise(function(resolve,reject){var bridge=trustedBridge();if(bridge){resolve(bridge);return;}var done=false,timer=null;function finish(ok,value){if(done)return;done=true;if(timer)clearTimeout(timer);window.removeEventListener("ext:wpp-bridge-ready",onReady);ok?resolve(value):reject(value);}function onReady(){var next=trustedBridge();if(next)finish(true,next);}window.addEventListener("ext:wpp-bridge-ready",onReady);timer=setTimeout(function(){var next=trustedBridge();if(next)finish(true,next);else finish(false,new Error("WPP bridge unavailable"));},30000);});}
          async function postRpcResponse(d,response){
            var text=safeJson(response);if(text==null)text=JSON.stringify({ok:false,result:null,error:"O WhatsApp retornou dados em um formato inválido",code:"WPP_RESULT_NOT_SERIALIZABLE"});
            var chunks=chunkString(text);if(chunks.length>RPC_MAX_CHUNKS){chunks=chunkString(JSON.stringify({ok:false,result:null,error:"A resposta do WhatsApp excede o limite seguro",code:"WPP_RPC_TOO_LARGE"}));}
            for(var i=0;i<chunks.length;i++){var signature=await signText(resCanonical(d.seq,d.id,i,chunks.length,chunks[i]));window.postMessage({__extSecureWppRpc:true,direction:"MAIN_TO_ISOLATED",channelId:channelId,seq:d.seq,id:d.id,index:i,total:chunks.length,chunk:chunks[i],signature:signature},"*");}
          }
          messageHandler=function(ev){
            if(disposed||ev.source!==window)return;var d=ev.data;
            if(!d||d.__extSecureWppRpc!==true||d.direction!=="ISOLATED_TO_MAIN"||d.channelId!==channelId)return;
            if(!validRpcToken(d.id,RPC_ID_MAX)||!validRpcToken(d.type,RPC_TYPE_MAX)||!validRpcToken(d.action,RPC_ACTION_MAX)||typeof d.chunk!=="string"||d.chunk.length>RPC_CHUNK+16||!validSignature(d.signature))return;
            var total=d.total,index=d.index,seqValue=d.seq,id=d.id,type=d.type,action=d.action,chunk=d.chunk;
            if(!Number.isSafeInteger(seqValue)||seqValue<1||!Number.isInteger(total)||total<1||total>RPC_MAX_CHUNKS||!Number.isInteger(index)||index<0||index>=total)return;
            if(rpcVerifyInFlight>=RPC_VERIFY_MAX)return;rpcVerifyInFlight++;
            verifyText(reqCanonical({seq:seqValue,id:id,type:type,action:action,index:index,total:total},chunk),d.signature).then(function(valid){
              if(!valid)return;var replayKey=String(seqValue)+":"+id;if(rpcSeen.has(replayKey))return;
              var rec=rpcPending.get(id);
              if(!rec){if(rpcPending.size>=32)return;rec={seq:seqValue,type:type,action:action,total:total,chunks:new Array(total),received:0,timer:setTimeout(function(){rpcPending.delete(id);},30000)};rpcPending.set(id,rec);}
              if(rec.seq!==seqValue||rec.type!==type||rec.action!==action||rec.total!==total||rec.chunks[index]!==undefined)return;
              rec.chunks[index]=chunk;rec.received++;if(rec.received!==rec.total)return;
              rpcPending.delete(id);clearTimeout(rec.timer);rpcSeen.add(replayKey);if(rpcSeen.size>1000){var first=rpcSeen.values().next().value;rpcSeen.delete(first);}
              var payload;try{payload=JSON.parse(rec.chunks.join(""));}catch(_){postRpcResponse({seq:seqValue,id:id},{ok:false,result:null,error:"Os dados enviados ao WhatsApp são inválidos",code:"WPP_RPC_INVALID_PAYLOAD"});return;}
              waitBridge().then(function(bridge){return bridge.invoke(type,action,payload);}).then(function(result){return postRpcResponse({seq:seqValue,id:id},{ok:true,result:result,error:null});}).catch(function(err){return postRpcResponse({seq:seqValue,id:id},{ok:false,result:null,error:err&&err.message||String(err),code:err&&err.code||"WPP_RPC_ERROR"});});
            }).catch(function(){}).finally(function(){rpcVerifyInFlight=Math.max(0,rpcVerifyInFlight-1);});
          };
          window.addEventListener("message",messageHandler);
          async function publish(name,payload){
            if(disposed)return;var payloadText=safeJson(payload);if(payloadText==null||encoder.encode(payloadText).byteLength>maxBytes)return;
            var n=++seq,ts=Date.now(),sig=await crypto.subtle.sign("HMAC",key,encoder.encode(canonical(n,ts,name,payloadText)));
            window.postMessage({__extSecureWppEvent:true,direction:"MAIN_TO_ISOLATED",channelId:channelId,seq:n,ts:ts,name:String(name),payloadText:payloadText,signature:bytesToB64(sig)},"*");
          }
          function bind(){
            if(disposed||bound)return;
            var bridge=trustedBridge();
            if(!bridge){if(!bridgeReadyHandler){bridgeReadyHandler=function(){bind();};window.addEventListener("ext:wpp-bridge-ready",bridgeReadyHandler);}if(++tries<80&&!bindTimer)bindTimer=setTimeout(function(){bindTimer=null;bind();},750);return;}
            bound=true;if(bindTimer){clearTimeout(bindTimer);bindTimer=null;}if(bridgeReadyHandler){window.removeEventListener("ext:wpp-bridge-ready",bridgeReadyHandler);bridgeReadyHandler=null;}
            ["chat.new_message","chat.active_chat","webpack.full_ready","chat.presence_change","chat.update_label","conn.stream_info_changed"].forEach(function(name){
              try{var unsubscribe=bridge.on(name,function(payload){publish(name,payload).catch(function(){});});if(typeof unsubscribe==="function")unsubscribers.push(unsubscribe);}catch(_){}
            });
          }
          bind();
          if(window[marker]===state&&!disposed)state.ready=true;
        }).catch(function(err){if(window[marker]===state){state.ready=false;state.error=err&&err.message||String(err);if(typeof state.dispose==="function")state.dispose();}});
      })();
    },
    args:[channelId,keyB64]
  }).then(function(){
    return chrome.scripting.executeScript({
      target:injectionTarget,
      world:"MAIN",
      func:async function(expectedChannelId){
        var started=Date.now();
        while(Date.now()-started<5000){
          var state=window.__extSecureWppEventForwarder;
          if(state&&state.channelId===expectedChannelId&&state.ready===true)return true;
          if(state&&state.channelId===expectedChannelId&&state.error)throw new Error(state.error);
          await new Promise(function(resolve){setTimeout(resolve,40);});
        }
        throw new Error("SECURE_FORWARDER_NOT_READY");
      },
      args:[channelId]
    });
  }).then(function(){
    if(cacheKey){__extWppEventChannels.set(cacheKey,{channelId:channelId,keyB64:keyB64,createdAt:Date.now()});while(__extWppEventChannels.size>64){var oldestKey=__extWppEventChannels.keys().next().value;__extWppEventChannels.delete(oldestKey);}}
    sendResponse({ok:true,channelId:channelId,keyB64:keyB64});
  }).catch(function(err){sendResponse({ok:false,error:err&&err.message||"EVENT_CHANNEL_INJECTION_FAILED"});});
  return true;
});

