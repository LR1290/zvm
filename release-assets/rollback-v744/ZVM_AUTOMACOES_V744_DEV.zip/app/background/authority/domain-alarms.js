(function setupDomainAlarms() {
  if (!chrome.alarms || !chrome.alarms.create) return;
  var defs = [
    { name: "extui-domain-1m", periodInMinutes: 1 },
    { name: "extui-domain-5m", periodInMinutes: 5 },
    { name: "extui-domain-10m", periodInMinutes: 10 },
    { name: "extui-domain-30m", periodInMinutes: 30 }
  ];
  defs.forEach(function (d) {
    try {
      chrome.alarms.get(d.name, function (existing) {
        var getErr=chrome.runtime.lastError;
        if(getErr){if(self.__extReportRuntimeError)self.__extReportRuntimeError("BACKGROUND_ALARM_GET_FAILED",getErr);return;}
        if(existing&&Number(existing.periodInMinutes)===Number(d.periodInMinutes))return;
        function createAlarm(){try{var created=chrome.alarms.create(d.name,{periodInMinutes:d.periodInMinutes});if(created&&typeof created.catch==="function")created.catch(function(createErr){if(self.__extReportRuntimeError)self.__extReportRuntimeError("BACKGROUND_ALARM_CREATE_FAILED",createErr);});}catch(createErr){if(self.__extReportRuntimeError)self.__extReportRuntimeError("BACKGROUND_ALARM_CREATE_FAILED",createErr);}}
        if(!existing){createAlarm();return;}
        try{chrome.alarms.clear(d.name,function(){var clearErr=chrome.runtime.lastError;if(clearErr){if(self.__extReportRuntimeError)self.__extReportRuntimeError("BACKGROUND_ALARM_CLEAR_FAILED",clearErr);return;}createAlarm();});}
        catch(clearThrown){if(self.__extReportRuntimeError)self.__extReportRuntimeError("BACKGROUND_ALARM_CLEAR_FAILED",clearThrown);}
      });
    } catch (e) { if(self.__extReportRuntimeError)self.__extReportRuntimeError("BACKGROUND_ALARM_GET_FAILED",e); }
  });

  var domainSeq = 0;
  function envelope(name, payload) {
    return { protocol: "EXTAPP_DOMAIN_EVENT", version: 1, id: "extui-bg-" + Date.now().toString(36) + "-" + (++domainSeq), name: name, source: "background", timestamp: Date.now(), correlationId: null, payload: payload || null };
  }
  function broadcast(name, payload) {
    var env = envelope(name, payload);
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
      if (chrome.runtime.lastError) { if(self.__extReportRuntimeError)self.__extReportRuntimeError("DOMAIN_EVENT_TAB_QUERY_FAILED",chrome.runtime.lastError); return; }
      (tabs || []).forEach(function (tab) {
        if (tab.id == null) return;
        try { chrome.tabs.sendMessage(tab.id, { __extDomainEventRelay: true, envelope: env }, function () { var err=chrome.runtime.lastError;if(err&&self.__extReportRuntimeError&&!/Receiving end does not exist|Could not establish connection/i.test(String(err.message||"")))self.__extReportRuntimeError("DOMAIN_EVENT_DELIVERY_FAILED",err); }); } catch (e) { if(self.__extReportRuntimeError)self.__extReportRuntimeError("DOMAIN_EVENT_DELIVERY_FAILED",e); }
      });
    });
  }
  chrome.alarms.onAlarm.addListener(function (alarm) {
    if (!alarm || typeof alarm.name !== "string" || alarm.name.indexOf("extui-domain-") !== 0) return;
    if (alarm.name === "extui-domain-1m") {
      broadcast("AgendaTick", { cadenceMinutes: 1 });
      broadcast("StatusTick", { cadenceMinutes: 1 });
      broadcast("BackupTick", { cadenceMinutes: 1 });
      extRunAutomaticFileBackup().catch(function(err){if(self.__extReportRuntimeError)self.__extReportRuntimeError("AUTOMATIC_BACKUP_TICK_FAILED",err);});
      broadcast("MeetLiveTick", { cadenceMinutes: 1 });
      broadcast("NotificationTick", { cadenceMinutes: 1 });
    } else if (alarm.name === "extui-domain-5m") {
      broadcast("LicenseRefresh", { cadenceMinutes: 5, nativeLicensePreserved: true });
      broadcast("FollowUpTimingTick", { cadenceMinutes: 5 });
    } else if (alarm.name === "extui-domain-10m") {
      broadcast("ConfigRefresh", { cadenceMinutes: 10 });
    } else if (alarm.name === "extui-domain-30m") {
      broadcast("RemoteNotificationTick", { cadenceMinutes: 30 });
    }
  });
})();

;(function setupAutomationCoordinator(){
  "use strict";
  var KEY="EXTUI:automationCoordinatorV1",queue=Promise.resolve();
  var MAX_SEND_ROWS=6000,MAX_RECIPIENT_ROWS=12000,MAX_CAMPAIGN_ROWS=4096;
  var LEASE_SCOPES=new Set(["agenda-tick","followup-tick","funnel-tick","flow-tick","status-tick","meet-calendar-tick","notification-tick"]),ONCE_SCOPES=new Set(["message-received"]);
  function fail(code,message){var e=new Error(message);e.code=code;return e;}
  function token(){var c=globalThis.crypto;return c&&typeof c.randomUUID==="function"?c.randomUUID():("coord-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2));}
  function validObject(value){return !!value&&typeof value==="object"&&!Array.isArray(value);}
  function validateSendSafetyShape(safety){
    if(!validObject(safety)||!Array.isArray(safety.sends)||!validObject(safety.recipients)||!validObject(safety.campaigns))throw fail("AUTOMATION_COORDINATOR_CORRUPT","O estado temporário da Proteção de Envio está inválido.");
    if(Object.prototype.hasOwnProperty.call(safety,"consecutiveFailures")&&(!Number.isFinite(Number(safety.consecutiveFailures))||Number(safety.consecutiveFailures)<0))throw fail("AUTOMATION_COORDINATOR_CORRUPT","O circuit breaker temporário da Proteção de Envio está inválido.");
    if(Object.prototype.hasOwnProperty.call(safety,"circuitOpenUntil")&&(!Number.isFinite(Number(safety.circuitOpenUntil))||Number(safety.circuitOpenUntil)<0))throw fail("AUTOMATION_COORDINATOR_CORRUPT","O circuit breaker temporário da Proteção de Envio está inválido.");
    safety.sends.forEach(function(row){
      var at=Number(row&&row.at),expiresAt=Number(row&&row.expiresAt),rowToken=String(row&&row.token||"");
      if(!validObject(row)||!/^[A-Za-z0-9._:-]{8,160}$/.test(rowToken)||!Number.isFinite(at)||at<0||!Number.isFinite(expiresAt)||expiresAt<at||(row.pending!==true&&row.pending!==false)||(row.recipientDigest&&!/^[a-f0-9]{64}$/.test(String(row.recipientDigest)))||(row.campaignDigest&&!/^[a-f0-9]{64}$/.test(String(row.campaignDigest))))throw fail("AUTOMATION_COORDINATOR_CORRUPT","O histórico temporário da Proteção de Envio está inválido.");
      if(row.pending===true&&(!/^[A-Za-z0-9._:-]{8,128}$/.test(String(row.requestId||""))))throw fail("AUTOMATION_COORDINATOR_CORRUPT","Uma reserva temporária da Proteção de Envio está inválida.");
      if(Object.prototype.hasOwnProperty.call(row,"cooldownMs")&&(!Number.isFinite(Number(row.cooldownMs))||Number(row.cooldownMs)<0||Number(row.cooldownMs)>604800000))throw fail("AUTOMATION_COORDINATOR_CORRUPT","O cooldown temporário da Proteção de Envio está inválido.");
    });
    Object.keys(safety.recipients).forEach(function(key){var row=safety.recipients[key],at=Number(row&&row.at),expiresAt=Number(row&&row.expiresAt);if(!/^[a-f0-9]{64}$/.test(key)||!validObject(row)||!Number.isFinite(at)||at<0||!Number.isFinite(expiresAt)||expiresAt<at)throw fail("AUTOMATION_COORDINATOR_CORRUPT","O controle temporário de destinatários está inválido.");});
    Object.keys(safety.campaigns).forEach(function(key){var row=safety.campaigns[key],count=Number(row&&row.count),updatedAt=Number(row&&row.updatedAt),expiresAt=Number(row&&row.expiresAt);if(!/^[a-f0-9]{64}$/.test(key)||!validObject(row)||!Number.isFinite(count)||count<0||Math.floor(count)!==count||!Number.isFinite(updatedAt)||updatedAt<0||!Number.isFinite(expiresAt)||expiresAt<updatedAt)throw fail("AUTOMATION_COORDINATOR_CORRUPT","O controle temporário de campanhas está inválido.");});
  }
  function assertSendSafetyCapacity(safety){if(safety.sends.length>MAX_SEND_ROWS||Object.keys(safety.recipients).length>MAX_RECIPIENT_ROWS||Object.keys(safety.campaigns).length>MAX_CAMPAIGN_ROWS)throw fail("SEND_SAFETY_STATE_CAPACITY","A Proteção de Envio atingiu o limite interno seguro e bloqueou novas automações.");}
  async function readState(){
    if(!chrome.storage||!chrome.storage.session||!chrome.storage.session.get)throw fail("AUTOMATION_COORDINATOR_UNAVAILABLE","A coordenação segura entre abas não está disponível.");
    var got=await chrome.storage.session.get(KEY),raw=got&&got[KEY];
    if(raw==null)return{version:1,leases:Object.create(null),once:Object.create(null),sendSafety:{sends:[],recipients:Object.create(null),campaigns:Object.create(null),consecutiveFailures:0,circuitOpenUntil:0}};
    if(!validObject(raw)||Number(raw.version)!==1||!validObject(raw.leases)||!validObject(raw.once))throw fail("AUTOMATION_COORDINATOR_CORRUPT","O estado temporário de coordenação entre abas está inválido.");
    var hasSendSafety=Object.prototype.hasOwnProperty.call(raw,"sendSafety"),safeSend=hasSendSafety?raw.sendSafety:{sends:[],recipients:Object.create(null),campaigns:Object.create(null)};
    if(hasSendSafety)validateSendSafetyShape(safeSend);
    var sendRows=hasSendSafety?safeSend.sends.map(function(row){var copy=Object.assign({},row);if(copy.pending===true&&!Object.prototype.hasOwnProperty.call(copy,"cooldownMs"))copy.cooldownMs=604800000;return copy;}):[];
    var normalized={version:1,leases:Object.assign(Object.create(null),raw.leases),once:Object.assign(Object.create(null),raw.once),sendSafety:{sends:sendRows,recipients:hasSendSafety?Object.assign(Object.create(null),safeSend.recipients):Object.create(null),campaigns:hasSendSafety?Object.assign(Object.create(null),safeSend.campaigns):Object.create(null),consecutiveFailures:hasSendSafety&&Object.prototype.hasOwnProperty.call(safeSend,"consecutiveFailures")?Number(safeSend.consecutiveFailures):0,circuitOpenUntil:hasSendSafety&&Object.prototype.hasOwnProperty.call(safeSend,"circuitOpenUntil")?Number(safeSend.circuitOpenUntil):0}};
    validateSendSafetyShape(normalized.sendSafety);
    return normalized;
  }
  async function writeState(state){var payload={};payload[KEY]=state;await chrome.storage.session.set(payload);}
  function onceExpiry(row){return validObject(row)?Number(row.expiresAt)||0:Number(row)||0;}
  function prune(state,now){
    Object.keys(state.leases).forEach(function(scope){var row=state.leases[scope];if(!validObject(row)||(Number(row.expiresAt)||0)<=now)delete state.leases[scope];});
    Object.keys(state.once).forEach(function(key){if(onceExpiry(state.once[key])<=now)delete state.once[key];});
    var keys=Object.keys(state.once),limit=2048;if(keys.length>limit){keys.sort(function(a,b){return onceExpiry(state.once[a])-onceExpiry(state.once[b]);});keys.slice(0,keys.length-limit).forEach(function(k){delete state.once[k];});}
    var safety=state.sendSafety;if(!validObject(safety))return;
    safety.sends=(Array.isArray(safety.sends)?safety.sends:[]).filter(function(row){return validObject(row)&&(Number(row.expiresAt)||0)>now;});
    Object.keys(safety.recipients||{}).forEach(function(k){var row=safety.recipients[k];if(!validObject(row)||(Number(row.expiresAt)||0)<=now)delete safety.recipients[k];});
    Object.keys(safety.campaigns||{}).forEach(function(k){var row=safety.campaigns[k];if(!validObject(row)||(Number(row.expiresAt)||0)<=now)delete safety.campaigns[k];});
    if((Number(safety.circuitOpenUntil)||0)<=now)safety.circuitOpenUntil=0;
    validateSendSafetyShape(safety);assertSendSafetyCapacity(safety);
  }
  function digestOrEmpty(value){value=String(value||"").toLowerCase();if(!value)return"";if(!/^[a-f0-9]{64}$/.test(value))throw fail("SEND_SAFETY_DIGEST_INVALID","Identificador interno da Proteção de Envio inválido.");return value;}
  function clampNumber(value,min,max,fallback){var n=Number(value);if(!Number.isFinite(n))n=fallback;return Math.max(min,Math.min(max,n));}
  function sendSafetyParams(message){return{minGapMs:clampNumber(message.minGapMs,1000,300000,8000),maxMinute:Math.round(clampNumber(message.maxMinute,1,60,6)),maxHour:Math.round(clampNumber(message.maxHour,1,1000,60)),maxDay:Math.round(clampNumber(message.maxDay,1,2000,250)),cooldownMs:clampNumber(message.cooldownMs,0,604800000,86400000),campaignLimit:Math.round(clampNumber(message.campaignLimit,1,1000,100)),failureThreshold:Math.round(clampNumber(message.failureThreshold,1,20,4)),circuitPauseMs:clampNumber(message.circuitPauseMs,10000,3600000,120000),recipientDigest:digestOrEmpty(message.recipientDigest),campaignDigest:digestOrEmpty(message.campaignDigest)};}
  function pendingCount(safety,digest,kind){return safety.sends.reduce(function(n,row){return n+(row&&row.pending===true&&String(row[kind]||"")===digest?1:0);},0);}
  function trackedDigestCount(safety,field,map){var seen=new Set(Object.keys(map||{}));safety.sends.forEach(function(row){var digest=row&&row.pending===true?String(row[field]||""):"";if(digest)seen.add(digest);});return seen;}
  async function reserveSendSafety(message,state,now){
    var p=sendSafetyParams(message),s=state.sendSafety,requestId=String(message.requestId||"");if(!/^[A-Za-z0-9._:-]{8,128}$/.test(requestId))throw fail("SEND_SAFETY_REQUEST_INVALID","Identificador interno da reserva de envio inválido.");
    var existing=s.sends.find(function(row){return row&&row.requestId===requestId&&row.pending===true;});if(existing)return{reserved:true,token:existing.token,replayed:true};
    if((Number(s.circuitOpenUntil)||0)>now)return{reserved:false,code:"SEND_SAFETY_CIRCUIT_OPEN",retryAfterMs:Number(s.circuitOpenUntil)-now};
    var minute=s.sends.filter(function(row){return now-Number(row.at||0)<60000;}),hour=s.sends.filter(function(row){return now-Number(row.at||0)<3600000;}),day=s.sends.filter(function(row){return now-Number(row.at||0)<86400000;}),wait=0;
    var latest=s.sends.reduce(function(v,row){return Math.max(v,Number(row.at)||0);},0);if(p.minGapMs&&latest)wait=Math.max(wait,p.minGapMs-(now-latest));
    if(minute.length>=p.maxMinute){var oldest=Math.min.apply(Math,minute.map(function(r){return Number(r.at)||now;}));wait=Math.max(wait,60000-(now-oldest)+20);}
    if(hour.length>=p.maxHour){var oldestH=Math.min.apply(Math,hour.map(function(r){return Number(r.at)||now;}));wait=Math.max(wait,3600000-(now-oldestH)+20);}
    var pendingDay=day.filter(function(row){return row&&row.pending===true;}).length,durableDay=await durableDayCount(now),effectiveDay=Math.max(day.length-pendingDay,durableDay)+pendingDay;if(effectiveDay>=p.maxDay){var finalized=day.filter(function(row){return row&&row.pending!==true;}),oldestD=finalized.length?Math.min.apply(Math,finalized.map(function(r){return Number(r.at)||now;})):now;return{reserved:false,code:"SEND_SAFETY_DAY_LIMIT",retryAfterMs:Math.max(50,86400000-(now-oldestD)+20),limit:p.maxDay,dayCount:effectiveDay};}
    if(wait>0)return{reserved:false,code:"SEND_SAFETY_RATE_WAIT",retryAfterMs:Math.max(50,Math.ceil(wait))};
    if(p.recipientDigest&&p.cooldownMs>0){var rr=s.recipients[p.recipientDigest],last=Number(rr&&rr.at)||0,pendingRecipient=s.sends.some(function(row){return row&&row.pending===true&&row.recipientDigest===p.recipientDigest;});if(pendingRecipient||last&&now-last<p.cooldownMs)return{reserved:false,code:"SEND_SAFETY_RECIPIENT_COOLDOWN",retryAfterMs:pendingRecipient?2000:Math.max(50,p.cooldownMs-(now-last))};var trackedRecipients=trackedDigestCount(s,"recipientDigest",s.recipients);if(!trackedRecipients.has(p.recipientDigest)&&trackedRecipients.size>=MAX_RECIPIENT_ROWS)return{reserved:false,code:"SEND_SAFETY_STATE_CAPACITY"};}
    if(p.campaignDigest){var campaign=s.campaigns[p.campaignDigest],count=Math.max(0,Number(campaign&&campaign.count)||0)+pendingCount(s,p.campaignDigest,"campaignDigest");if(count>=p.campaignLimit)return{reserved:false,code:"SEND_SAFETY_CAMPAIGN_LIMIT",limit:p.campaignLimit};var trackedCampaigns=trackedDigestCount(s,"campaignDigest",s.campaigns);if(!trackedCampaigns.has(p.campaignDigest)&&trackedCampaigns.size>=MAX_CAMPAIGN_ROWS)return{reserved:false,code:"SEND_SAFETY_STATE_CAPACITY"};}
    if(s.sends.length>=MAX_SEND_ROWS)return{reserved:false,code:"SEND_SAFETY_STATE_CAPACITY"};
    var reservationToken=token();s.sends.push({token:reservationToken,requestId:requestId,at:now,expiresAt:now+3600000,pending:true,recipientDigest:p.recipientDigest,campaignDigest:p.campaignDigest,cooldownMs:p.cooldownMs});prune(state,now);await writeState(state);return{reserved:true,token:reservationToken,replayed:false};
  }
  async function finalizeSendSafety(message,state,now){
    var s=state.sendSafety,reservation=String(message.token||""),index=s.sends.findIndex(function(row){return row&&row.token===reservation&&row.pending===true;});if(index<0)return{finalized:false};
    var row=s.sends[index],success=message.success===true;
    if(!success){s.sends.splice(index,1);if(message.operationalFailure===true){var threshold=Math.round(clampNumber(message.failureThreshold,1,20,4)),pauseMs=clampNumber(message.circuitPauseMs,10000,3600000,120000);s.consecutiveFailures=Math.max(0,Number(s.consecutiveFailures)||0)+1;if(s.consecutiveFailures>=threshold)s.circuitOpenUntil=now+pauseMs;}await writeState(state);return{finalized:true,success:false,circuitOpenUntil:Number(s.circuitOpenUntil)||0};}
    row.pending=false;row.expiresAt=row.at+86400000;delete row.requestId;s.consecutiveFailures=0;s.circuitOpenUntil=0;
    if(row.recipientDigest){var cooldownMs=clampNumber(row.cooldownMs,0,604800000,0);if(cooldownMs>0)s.recipients[row.recipientDigest]={at:row.at,expiresAt:row.at+cooldownMs};}
    if(row.campaignDigest){var campaign=s.campaigns[row.campaignDigest];if(!validObject(campaign))campaign={count:0,updatedAt:0,expiresAt:0};campaign.count=Math.max(0,Number(campaign.count)||0)+1;campaign.updatedAt=row.at;campaign.expiresAt=row.at+86400000;s.campaigns[row.campaignDigest]=campaign;}
    prune(state,now);await writeState(state);return{finalized:true,success:true};
  }
  async function durableDayCount(now){var journal=self.__extSendEffectJournalAuthority;if(!journal||typeof journal.countCommittedSince!=="function")throw fail("SEND_EFFECT_JOURNAL_UNAVAILABLE","O histórico durável da Proteção de Envio não está disponível.");return await journal.countCommittedSince(now-86400000);}
  async function statusSendSafety(message,state,now){var p=sendSafetyParams(message),s=state.sendSafety,minute=0,hour=0,sessionDay=0,pendingDay=0;s.sends.forEach(function(row){var at=Number(row&&row.at)||0;if(!at)return;if(now-at<86400000){sessionDay++;if(row.pending===true)pendingDay++;}if(now-at<3600000)hour++;if(now-at<60000)minute++;});var durable=await durableDayCount(now),day=Math.max(sessionDay-pendingDay,durable)+pendingDay;return{minuteCount:minute,hourCount:hour,dayCount:day,durableDayCount:durable,minuteRemaining:Math.max(0,p.maxMinute-minute),hourRemaining:Math.max(0,p.maxHour-hour),dayRemaining:Math.max(0,p.maxDay-day),maxMinute:p.maxMinute,maxHour:p.maxHour,maxDay:p.maxDay,circuitOpenUntil:Number(s.circuitOpenUntil)||0};}
  async function run(message,sender){
    if(!extSenderIsWhatsApp(sender))throw fail("UNAUTHORIZED_SENDER","A coordenação automática só pode ser usada dentro do WhatsApp Web.");
    var action=String(message.action||""),scope=String(message.scope||""),now=Date.now();
    if(action.indexOf("effect_")===0){
      var journal=self.__extSendEffectJournalAuthority;if(!journal)throw fail("SEND_EFFECT_JOURNAL_UNAVAILABLE","O journal durável de envios não está disponível.");
      if(action==="effect_prepare")return journal.prepare(message);
      if(action==="effect_begin")return journal.begin(message);
      if(action==="effect_commit")return journal.commit(message);
      if(action==="effect_fail")return journal.fail(message);
      if(action==="effect_summary")return journal.summary();
      throw fail("SEND_EFFECT_ACTION_INVALID","Ação do journal durável inválida.");
    }
    var state=await readState();prune(state,now);
    if(action==="acquire"){
      if(!LEASE_SCOPES.has(scope))throw fail("AUTOMATION_COORDINATOR_SCOPE_INVALID","Área de coordenação inválida.");
      var claimant=String(message.claimant||"");if(!/^[A-Za-z0-9._:-]{8,128}$/.test(claimant))throw fail("AUTOMATION_COORDINATOR_CLAIMANT_INVALID","Identificador interno do lease inválido.");
      var senderTabId=sender.tab&&sender.tab.id!=null?sender.tab.id:null,existing=state.leases[scope];
      if(existing&&Number(existing.expiresAt)>now){if(existing.claimant===claimant&&existing.tabId===senderTabId)return{acquired:true,token:String(existing.token||""),expiresAt:Number(existing.expiresAt)||0,replayed:true};return{acquired:false,retryAfterMs:Math.max(250,Number(existing.expiresAt)-now)};}
      var leaseToken=token(),ttl=Math.max(30000,Math.min(Number(message.ttlMs)||120000,300000));state.leases[scope]={token:leaseToken,claimant:claimant,tabId:senderTabId,expiresAt:now+ttl};await writeState(state);return{acquired:true,token:leaseToken,expiresAt:now+ttl,replayed:false};
    }
    if(action==="renew"){
      if(!LEASE_SCOPES.has(scope))throw fail("AUTOMATION_COORDINATOR_SCOPE_INVALID","Área de coordenação inválida.");
      var lease=state.leases[scope],renewToken=String(message.token||""),renewTabId=sender.tab&&sender.tab.id!=null?sender.tab.id:null;if(!lease||lease.token!==renewToken||lease.tabId!==renewTabId)return{renewed:false};
      var renewTtl=Math.max(30000,Math.min(Number(message.ttlMs)||120000,300000));lease.expiresAt=now+renewTtl;await writeState(state);return{renewed:true,expiresAt:lease.expiresAt};
    }
    if(action==="release"){
      if(!LEASE_SCOPES.has(scope))throw fail("AUTOMATION_COORDINATOR_SCOPE_INVALID","Área de coordenação inválida.");
      var current=state.leases[scope],releaseToken=String(message.token||""),releaseTabId=sender.tab&&sender.tab.id!=null?sender.tab.id:null;if(current&&current.token===releaseToken&&current.tabId===releaseTabId){delete state.leases[scope];await writeState(state);return{released:true};}return{released:false};
    }
    if(action==="claim_once"){
      if(!ONCE_SCOPES.has(scope))throw fail("AUTOMATION_COORDINATOR_SCOPE_INVALID","Área de deduplicação inválida.");
      var digest=String(message.digest||"").toLowerCase();if(!/^[a-f0-9]{64}$/.test(digest))throw fail("AUTOMATION_COORDINATOR_DIGEST_INVALID","Identificador de deduplicação inválido.");
      var claimant=String(message.claimant||"");if(!/^[A-Za-z0-9._:-]{8,128}$/.test(claimant))throw fail("AUTOMATION_COORDINATOR_CLAIMANT_INVALID","Identificador interno da deduplicação inválido.");
      var claimKey=scope+":"+digest,existingClaim=state.once[claimKey],existingExpiry=onceExpiry(existingClaim);
      if(existingExpiry>now){if(validObject(existingClaim)&&existingClaim.claimant===claimant)return{claimed:true,replayed:true,expiresAt:existingExpiry};return{claimed:false,expiresAt:existingExpiry};}
      var onceTtl=Math.max(60000,Math.min(Number(message.ttlMs)||900000,1800000));state.once[claimKey]={expiresAt:now+onceTtl,claimant:claimant};prune(state,now);await writeState(state);return{claimed:true,replayed:false,expiresAt:now+onceTtl};
    }
    if(action==="send_status")return await statusSendSafety(message,state,now);
    if(action==="send_reserve")return await reserveSendSafety(message,state,now);
    if(action==="send_finalize")return await finalizeSendSafety(message,state,now);
    throw fail("AUTOMATION_COORDINATOR_ACTION_INVALID","Ação de coordenação inválida.");
  }
  chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
    if(!message||message.type!=="EXTUI_AUTOMATION_COORDINATOR")return false;
    var task=queue.then(function(){return run(message,sender);});queue=task.catch(function(){});
    task.then(function(result){sendResponse({ok:true,result:result});}).catch(function(err){if(self.__extReportRuntimeError)self.__extReportRuntimeError("AUTOMATION_COORDINATOR_FAILED",err);sendResponse({ok:false,errorCode:err&&err.code||"AUTOMATION_COORDINATOR_FAILED",userMessage:err&&err.message||"A coordenação entre abas falhou."});});
    return true;
  });
})();

;(function setupColumnEventQueueAuthority(){
  "use strict";
  var LEGACY_KEY="EXTUI:extappColumnEventQueue",SESSION_KEY="EXTUI:extappColumnEventQueueSessionV2",CRM_KEY="EXTUI:CrmStore",MAX_EVENTS=10000,serial=Promise.resolve();
  function fail(code,message){var e=new Error(message);e.code=code;return e;}
  function safeObject(value){return !!value&&typeof value==="object"&&!Array.isArray(value);}
  function own(obj,key){return !!obj&&Object.prototype.hasOwnProperty.call(obj,key);}
  function eventId(){var c=globalThis.crypto;return c&&typeof c.randomUUID==="function"?("crm-event:"+c.randomUUID()):("crm-event:"+Date.now().toString(36)+":"+Math.random().toString(36).slice(2)+":"+Math.random().toString(36).slice(2));}
  function field(value,name,max){var text=String(value==null?"":value).trim();if(!text||text.length>max)throw fail("CRM_COLUMN_EVENT_INVALID","O evento de movimentação do CRM está inválido ("+name+").");return text;}
  function parseObject(raw,code,message){if(raw==null||raw==="")return null;var parsed=raw;if(typeof parsed==="string"){try{parsed=JSON.parse(parsed);}catch(_){throw fail(code,message);}}if(!safeObject(parsed))throw fail(code,message);return parsed;}
  function normalizeEvent(row,allowLegacy){
    if(!safeObject(row))throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém um item inválido e foi preservada sem alterações.");
    var id=String(row.id==null?"":row.id).trim();
    if(id&&!/^[A-Za-z0-9._:-]{8,160}$/.test(id))throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém um identificador inválido.");
    if(!id&&!allowLegacy)throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém um item sem identificador.");
    var atMs=Number(row.atMs);if(!Number.isFinite(atMs)||atMs<=0)throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém uma data inválida.");
    var contactId=String(row.contactId==null?"":row.contactId).trim(),legacyPhone="";
    if(contactId){if(contactId.length>200)throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém um contato inválido.");}
    else if(allowLegacy){legacyPhone=String(row.phoneNumber==null?"":row.phoneNumber).replace(/\D/g,"");if(!legacyPhone||legacyPhone.length>32)throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila antiga de eventos do CRM contém um contato inválido.");}
    else throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM não possui o identificador interno do contato.");
    return{id:id,crmId:field(row.crmId,"CRM",200),columnId:field(row.columnId,"etapa",200),contactId:contactId,legacyPhone:legacyPhone,atMs:atMs};
  }
  function parseQueue(raw,allowLegacy){
    if(raw==null||raw==="")return{events:[],exists:false};
    var parsed=parseObject(raw,"CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM está corrompida e foi preservada sem alterações.");
    if(!safeObject(parsed.state)||!Array.isArray(parsed.state.events))throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM está corrompida e foi preservada sem alterações.");
    if(parsed.state.events.length>MAX_EVENTS)throw fail("CRM_COLUMN_EVENT_QUEUE_LIMIT","A fila de eventos do CRM excedeu o limite seguro e não será truncada.");
    var seen=Object.create(null),events=parsed.state.events.map(function(row){var item=normalizeEvent(row,allowLegacy);if(item.id){if(seen[item.id])throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém identificadores duplicados.");seen[item.id]=true;}return item;});
    return{events:events,exists:true};
  }
  function parseCrm(raw){
    var parsed=parseObject(raw,"CRM_COLUMN_EVENT_MIGRATION_CRM_CORRUPT","O CRM não pôde ser lido com segurança para migrar a fila de automações.");
    if(!parsed||!safeObject(parsed.state)||!Array.isArray(parsed.state.crmList))throw fail("CRM_COLUMN_EVENT_MIGRATION_CRM_CORRUPT","O CRM não pôde ser lido com segurança para migrar a fila de automações.");
    return parsed.state.crmList;
  }
  function resolveLegacyContactId(event,crmList){
    if(event.contactId)return event.contactId;
    var crm=crmList.find(function(item){return item&&String(item.id||"")===event.crmId;});
    if(!crm||!Array.isArray(crm.columns))throw fail("CRM_COLUMN_EVENT_MIGRATION_CONTACT_UNRESOLVED","Um evento antigo do CRM não pôde ser associado ao quadro original e foi preservado.");
    var matches=[],seen=Object.create(null);
    function scan(columns){columns.forEach(function(column){(Array.isArray(column&&column.items)?column.items:[]).forEach(function(item){var phone=String(item&&item.contact&&item.contact.phoneNumber||"").replace(/\D/g,"");var id=String(item&&item.id||"").trim();if(phone===event.legacyPhone&&id&&!seen[id]){seen[id]=true;matches.push(id);}});});}
    var target=crm.columns.filter(function(column){return column&&String(column.id||"")===event.columnId;});scan(target);
    if(matches.length===0)scan(crm.columns.filter(function(column){return !column||String(column.id||"")!==event.columnId;}));
    if(matches.length!==1)throw fail("CRM_COLUMN_EVENT_MIGRATION_CONTACT_UNRESOLVED","Um evento antigo do CRM não pôde ser associado de forma inequívoca ao contato e foi preservado.");
    return matches[0];
  }
  async function legacyEventId(event,index){
    if(event.id)return event.id;
    if(!globalThis.crypto||!crypto.subtle)throw fail("CRM_COLUMN_EVENT_MIGRATION_DIGEST_UNAVAILABLE","A fila antiga do CRM não pôde ser migrada com identificação segura.");
    var source=[event.crmId,event.columnId,event.legacyPhone,String(event.atMs),String(index)].join("\u001f");
    var digest=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(source)),hex=Array.from(new Uint8Array(digest)).map(function(v){return v.toString(16).padStart(2,"0");}).join("");
    return"legacy:"+hex;
  }
  async function convertLegacy(events,crmList){var out=[];for(var i=0;i<events.length;i++){var event=events[i],id=await legacyEventId(event,i);out.push({id:id,crmId:event.crmId,columnId:event.columnId,contactId:resolveLegacyContactId(event,crmList),atMs:event.atMs});}return out;}
  function cleanEvent(event){return{id:event.id,crmId:event.crmId,columnId:event.columnId,contactId:event.contactId,atMs:event.atMs};}
  function mergeEvents(base,extra){
    var byId=Object.create(null),out=[];
    function add(row){var current=byId[row.id];if(current){if(current.crmId!==row.crmId||current.columnId!==row.columnId||current.contactId!==row.contactId||Number(current.atMs)!==Number(row.atMs))throw fail("CRM_COLUMN_EVENT_ID_CONFLICT","O mesmo identificador de evento foi reutilizado com dados diferentes.");return;}byId[row.id]=row;out.push(row);}
    base.forEach(add);extra.forEach(add);if(out.length>MAX_EVENTS)throw fail("CRM_COLUMN_EVENT_QUEUE_LIMIT","A fila de eventos do CRM excedeu o limite seguro e não será truncada.");return out;
  }
  async function readSession(){var got=await chrome.storage.session.get(SESSION_KEY);if(!own(got,SESSION_KEY))return null;return parseQueue(got[SESSION_KEY],false).events.map(cleanEvent);}
  async function writeSession(events){if(!Array.isArray(events)||events.length>MAX_EVENTS)throw fail("CRM_COLUMN_EVENT_QUEUE_LIMIT","A fila de eventos do CRM excedeu o limite seguro e não será truncada.");var seen=Object.create(null),safe=events.map(function(row){var item=normalizeEvent(row,false);if(seen[item.id])throw fail("CRM_COLUMN_EVENT_QUEUE_CORRUPT","A fila de eventos do CRM contém identificadores duplicados.");seen[item.id]=true;return cleanEvent(item);});var payload={};payload[SESSION_KEY]=JSON.stringify({state:{events:safe},version:2});await chrome.storage.session.set(payload);}
  async function removeLegacyVerified(){var before=await chrome.storage.local.get(LEGACY_KEY);if(!own(before,LEGACY_KEY))return;await chrome.storage.local.remove(LEGACY_KEY);var after=await chrome.storage.local.get(LEGACY_KEY);if(own(after,LEGACY_KEY))throw fail("CRM_COLUMN_EVENT_LEGACY_CLEANUP_FAILED","A fila antiga do CRM foi migrada, mas sua cópia persistente não pôde ser removida com segurança.");}
  async function ensureReady(){
    var sessionEvents=await readSession(),legacyGot=await chrome.storage.local.get([LEGACY_KEY,CRM_KEY]);
    if(!own(legacyGot,LEGACY_KEY))return sessionEvents===null?[]:sessionEvents;
    var legacy=parseQueue(legacyGot[LEGACY_KEY],true).events,needsCrm=legacy.some(function(event){return !event.contactId;}),crmList=needsCrm?parseCrm(legacyGot[CRM_KEY]):[],converted=await convertLegacy(legacy,crmList),merged=mergeEvents(sessionEvents||[],converted);
    await writeSession(merged);
    await removeLegacyVerified();
    return merged;
  }
  function runExclusive(operation){var task=serial.catch(function(){}).then(operation);serial=task.catch(function(){});return task;}
  function enqueue(input){return runExclusive(async function(){
    input=input&&typeof input==="object"?input:{};
    var id=input.id==null||input.id===""?eventId():String(input.id);if(!/^[A-Za-z0-9._:-]{8,160}$/.test(id))throw fail("CRM_COLUMN_EVENT_INVALID","O identificador do evento de movimentação do CRM está inválido.");
    var atMs=input.atMs==null?Date.now():Number(input.atMs);if(!Number.isFinite(atMs)||atMs<=0)throw fail("CRM_COLUMN_EVENT_INVALID","A data do evento de movimentação do CRM está inválida.");
    var normalized={id:id,crmId:field(input.crmId,"CRM",200),columnId:field(input.columnId,"etapa",200),contactId:field(input.contactId,"contato",200),atMs:atMs};
    var events=await ensureReady(),existing=events.find(function(row){return row.id===id;});
    if(existing){if(existing.crmId!==normalized.crmId||existing.columnId!==normalized.columnId||existing.contactId!==normalized.contactId||Number(existing.atMs)!==normalized.atMs)throw fail("CRM_COLUMN_EVENT_ID_CONFLICT","O mesmo identificador de evento foi reutilizado com dados diferentes.");return Object.assign({replayed:true},existing);}
    if(events.length>=MAX_EVENTS)throw fail("CRM_COLUMN_EVENT_QUEUE_LIMIT","A fila de eventos do CRM atingiu o limite seguro; a movimentação foi preservada, mas a automação não foi enfileirada.");
    events.push(normalized);await writeSession(events);return Object.assign({replayed:false},normalized);
  });}
  function list(){return runExclusive(async function(){var events=await ensureReady();return events.map(function(row){return Object.assign({},row);});});}
  function ack(ids){return runExclusive(async function(){ids=Array.isArray(ids)?ids:[];if(ids.length>MAX_EVENTS)throw fail("CRM_COLUMN_EVENT_ACK_INVALID","A confirmação da fila do CRM excedeu o limite seguro.");var wanted=Object.create(null);ids.forEach(function(id){id=String(id||"");if(!id||id.length>160)throw fail("CRM_COLUMN_EVENT_ACK_INVALID","A confirmação da fila do CRM está inválida.");wanted[id]=true;});var events=await ensureReady(),next=events.filter(function(row){return !wanted[row.id];}),removed=events.length-next.length;if(removed)await writeSession(next);return{removed:removed,remaining:next.length};});}
  var authority=Object.freeze({enqueue:enqueue,list:list,ack:ack,maxEvents:MAX_EVENTS});
  globalThis.__extColumnEventQueueAuthority=authority;
  chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
    if(!message||message.type!=="EXTUI_COLUMN_EVENT_QUEUE")return false;
    var action=String(message.action||"");
    var allowed=action==="enqueue"?(typeof extSenderCanRuntime==="function"&&extSenderCanRuntime(sender)):(typeof extSenderIsWhatsApp==="function"&&extSenderIsWhatsApp(sender));
    if(!allowed){sendResponse({ok:false,errorCode:"UNAUTHORIZED_SENDER",userMessage:"Esta operação do CRM não é permitida neste contexto."});return false;}
    var task=action==="enqueue"?enqueue(message.event):action==="list"?list():action==="ack"?ack(message.ids):Promise.reject(fail("CRM_COLUMN_EVENT_ACTION_INVALID","Ação da fila de eventos do CRM inválida."));
    task.then(function(result){sendResponse({ok:true,result:result});}).catch(function(err){if(globalThis.__extReportRuntimeError)globalThis.__extReportRuntimeError("CRM_COLUMN_EVENT_QUEUE_FAILED",err);sendResponse({ok:false,errorCode:err&&err.code||"CRM_COLUMN_EVENT_QUEUE_FAILED",userMessage:err&&err.message||"A fila de eventos do CRM não pôde ser atualizada."});});
    return true;
  });
})();


async function extFixedFetchReadText(response,maxBytes){var declared=Number(response&&response.headers&&response.headers.get?response.headers.get("content-length")||0:0);if(declared&&declared>maxBytes)throw extError("FIXED_FETCH_TOO_LARGE","Resposta excede o limite seguro.");var reader=response&&response.body&&typeof response.body.getReader==="function"?response.body.getReader():null;if(!reader){var fallback=await response.text();if(new TextEncoder().encode(fallback).byteLength>maxBytes)throw extError("FIXED_FETCH_TOO_LARGE","Resposta excede o limite seguro.");return fallback;}var received=0,chunks=[],decoder=new TextDecoder("utf-8"),text="";try{for(;;){var part=await reader.read();if(part.done)break;received+=part.value.byteLength;if(received>maxBytes){try{await reader.cancel();}catch(_){}throw extError("FIXED_FETCH_TOO_LARGE","Resposta excede o limite seguro.");}chunks.push(part.value);}for(var i=0;i<chunks.length;i++)text+=decoder.decode(chunks[i],{stream:i<chunks.length-1});text+=decoder.decode();return text;}finally{try{reader.releaseLock&&reader.releaseLock();}catch(_){}}}
try{chrome.runtime.onMessage.addListener(function(msg,sender,sendResponse){if(!msg||msg.type!=="EXTUI_FIXED_JSON_FETCH")return false;Promise.resolve().then(async function(){if(typeof extSenderCanRuntime==="function"&&!extSenderCanRuntime(sender))throw extError("UNAUTHORIZED_SENDER","Origem não autorizada.");var kind=String(msg.kind||"");if(kind!=="notificationFeed"&&kind!=="tutorialLookup")throw extError("FIXED_FETCH_KIND_INVALID","Consulta não permitida.");var feature=String(msg.feature||"").replace(/[^a-z0-9_-]/gi,"").slice(0,80);if(kind==="tutorialLookup"&&!feature)throw extError("FIXED_FETCH_FEATURE_INVALID","Feature inválida.");if(kind==="tutorialLookup"){var availability=self.ExtensionCore&&self.ExtensionCore.FeatureAvailability;if(availability&&typeof availability.ready==="function")await availability.ready();var tutorialAllowed=false;try{tutorialAllowed=!!(availability&&typeof availability.isSurfaceVisible==="function"&&availability.isSurfaceVisible("tutorials","tutorialLookup",{requireRegistered:true})===true);}catch(_){tutorialAllowed=false;}if(!tutorialAllowed)throw extError("FEATURE_UNAVAILABLE","Recurso temporariamente indisponível.");}var url=kind==="notificationFeed"?self.__extRuntimeConfig.backendUrl("/extension/v3/notifications"):self.__extRuntimeConfig.backendUrl("/extension/v3/tutorial?feature="+encodeURIComponent(feature));var limit=kind==="notificationFeed"?524288:65536;var controller=new AbortController(),timer=setTimeout(function(){controller.abort();},kind==="notificationFeed"?5000:7000);try{var res=await fetch(url,{method:"GET",headers:{"Accept":"application/json"},cache:"no-store",credentials:"omit",redirect:"error",signal:controller.signal});if(!res.ok)throw extError("FIXED_FETCH_HTTP","O serviço da extensão respondeu HTTP "+res.status+".");var text=await extFixedFetchReadText(res,limit);var data;try{data=JSON.parse(text);}catch(_){throw extError("FIXED_FETCH_INVALID_JSON","Resposta inválida do serviço da extensão.");}return data;}catch(err){if(err&&err.name==="AbortError")throw extError("FIXED_FETCH_TIMEOUT","O serviço da extensão demorou demais para responder.");throw err;}finally{clearTimeout(timer);}}).then(function(data){sendResponse({ok:true,data:data});}).catch(function(err){sendResponse({ok:false,code:err&&err.code||"FIXED_FETCH_ERROR",error:err&&err.message||String(err)});});return true;});}catch(_extuiFixedFetchBootError){if(globalThis.__extReportRuntimeError)globalThis.__extReportRuntimeError("FIXED_FETCH_LISTENER_BOOT_FAILED",_extuiFixedFetchBootError);else throw _extuiFixedFetchBootError;}

