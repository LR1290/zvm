(function setupSendEffectJournalAuthority(){
  "use strict";
  if(self.__extSendEffectJournalAuthority)return;
  var DB="EXTUI_SEND_EFFECT_JOURNAL",STORE="effects",VERSION=2,MAX_ENTRIES=120000,dbp=null,lastPrune=0;
  var TTL={prepared:21600000,dispatching:31536000000,ambiguous:31536000000,committed:31536000000,failed:86400000};
  function fail(code,message){var e=new Error(message);e.code=code;return e;}
  function obj(v){return !!v&&typeof v==="object"&&!Array.isArray(v);}
  function digest(v,name){v=String(v||"").toLowerCase();if(!/^[a-f0-9]{64}$/.test(v))throw fail("SEND_EFFECT_DIGEST_INVALID","Identificador durável de envio inválido ("+name+").");return v;}
  function token(){var c=globalThis.crypto;return c&&typeof c.randomUUID==="function"?c.randomUUID():("effect-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2));}
  function validateEntry(row){
    if(!obj(row)||!/^[a-f0-9]{64}$/.test(String(row.id||""))||!/^[a-f0-9]{64}$/.test(String(row.payloadDigest||"")))throw fail("SEND_EFFECT_JOURNAL_CORRUPT","O journal durável de envios contém identificadores inválidos.");
    if(["prepared","dispatching","ambiguous","committed","failed"].indexOf(String(row.status||""))<0)throw fail("SEND_EFFECT_JOURNAL_CORRUPT","O journal durável de envios contém estado inválido.");
    ["createdAt","updatedAt","expiresAt"].forEach(function(k){var n=Number(row[k]);if(!Number.isFinite(n)||n<=0)throw fail("SEND_EFFECT_JOURNAL_CORRUPT","O journal durável de envios contém data inválida.");});
    if(Number(row.expiresAt)<Number(row.updatedAt))throw fail("SEND_EFFECT_JOURNAL_CORRUPT","O journal durável de envios contém expiração inválida.");
    if(row.token&&!/^[A-Za-z0-9._:-]{8,160}$/.test(String(row.token)))throw fail("SEND_EFFECT_JOURNAL_CORRUPT","O journal durável de envios contém token inválido.");
    return row;
  }
  function open(){
    if(dbp)return dbp;
    var pending=new Promise(function(resolve,reject){
      var settled=false,request;
      try{request=indexedDB.open(DB,VERSION);}catch(err){reject(fail("SEND_EFFECT_JOURNAL_UNAVAILABLE","O armazenamento durável de proteção de envio não pôde ser aberto."));return;}
      request.onupgradeneeded=function(){var db=request.result,store;if(!db.objectStoreNames.contains(STORE)){store=db.createObjectStore(STORE,{keyPath:"id"});store.createIndex("expiresAt","expiresAt",{unique:false});store.createIndex("status","status",{unique:false});store.createIndex("committedAt","committedAt",{unique:false});}else{store=request.transaction.objectStore(STORE);if(!store.indexNames.contains("committedAt"))store.createIndex("committedAt","committedAt",{unique:false});}};
      request.onsuccess=function(){var db=request.result;if(settled){try{db.close();}catch(_){}return;}settled=true;db.onversionchange=function(){try{db.close();}catch(_){}if(dbp===pending)dbp=null;};resolve(db);};
      request.onerror=function(){if(settled)return;settled=true;if(dbp===pending)dbp=null;reject(request.error||fail("SEND_EFFECT_JOURNAL_UNAVAILABLE","O journal durável de envios não pôde ser aberto."));};
      request.onblocked=function(){if(settled)return;settled=true;if(dbp===pending)dbp=null;reject(fail("SEND_EFFECT_JOURNAL_BLOCKED","O journal durável de envios está temporariamente bloqueado."));};
    });
    dbp=pending;return pending;
  }
  function requestResult(request){return new Promise(function(resolve,reject){request.onsuccess=function(){resolve(request.result);};request.onerror=function(){reject(request.error||fail("SEND_EFFECT_JOURNAL_IO","Falha ao acessar o journal durável de envios."));};});}
  function transactionDone(tx){return new Promise(function(resolve,reject){tx.oncomplete=function(){resolve(true);};tx.onerror=function(){reject(tx.error||fail("SEND_EFFECT_JOURNAL_IO","Falha ao persistir o journal durável de envios."));};tx.onabort=function(){reject(tx.error||fail("SEND_EFFECT_JOURNAL_IO","A gravação do journal durável foi cancelada."));};});}
  async function getRow(id){var db=await open(),tx=db.transaction(STORE,"readonly"),done=transactionDone(tx),row=await requestResult(tx.objectStore(STORE).get(id));await done;return row==null?null:validateEntry(row);}
  async function putRow(row){validateEntry(row);var db=await open(),tx=db.transaction(STORE,"readwrite"),done=transactionDone(tx);tx.objectStore(STORE).put(row);await done;return row;}
  async function deleteRow(id){var db=await open(),tx=db.transaction(STORE,"readwrite"),done=transactionDone(tx);tx.objectStore(STORE).delete(id);await done;return true;}
  async function countRows(){var db=await open(),tx=db.transaction(STORE,"readonly"),done=transactionDone(tx),count=await requestResult(tx.objectStore(STORE).count());await done;return Number(count)||0;}
  async function pruneExpired(now,force){
    if(!force&&lastPrune&&now-lastPrune<900000)return 0;lastPrune=now;
    var db=await open(),tx=db.transaction(STORE,"readwrite"),done=transactionDone(tx),store=tx.objectStore(STORE),index=store.index("expiresAt"),removed=0;
    await new Promise(function(resolve,reject){var req=index.openCursor(IDBKeyRange.upperBound(now));req.onerror=function(){reject(req.error||fail("SEND_EFFECT_JOURNAL_IO","Falha ao limpar o journal durável."));};req.onsuccess=function(){var cursor=req.result;if(!cursor){resolve();return;}cursor.delete();removed++;cursor.continue();};});
    await done;return removed;
  }
  function samePayload(row,payloadDigest){return String(row&&row.payloadDigest||"")===payloadDigest;}
  async function prepare(input){
    var now=Date.now(),effectDigest=digest(input&&input.effectDigest,"effect"),payloadDigest=digest(input&&input.payloadDigest,"payload");await pruneExpired(now,false);var row=await getRow(effectDigest);
    if(row&&Number(row.expiresAt)<=now){await deleteRow(effectDigest);row=null;}
    if(row){
      if(!samePayload(row,payloadDigest))throw fail("SEND_EFFECT_ID_CONFLICT","O mesmo identificador durável foi reutilizado para um envio diferente.");
      if(row.status==="committed")return{prepared:false,committed:true,recovered:true,committedAt:Number(row.committedAt)||Number(row.updatedAt)};
      if(row.status==="dispatching"){row.status="ambiguous";row.updatedAt=now;row.expiresAt=now+TTL.ambiguous;await putRow(row);return{prepared:false,ambiguous:true,code:"SEND_EFFECT_AMBIGUOUS",updatedAt:row.updatedAt};}
      if(row.status==="ambiguous")return{prepared:false,ambiguous:true,code:"SEND_EFFECT_AMBIGUOUS",updatedAt:Number(row.updatedAt)||0};
      if(row.status==="prepared")return{prepared:true,token:String(row.token),replayed:true};
      if(row.status==="failed"){await deleteRow(effectDigest);row=null;}
    }
    if(await countRows()>=MAX_ENTRIES){await pruneExpired(now,true);if(await countRows()>=MAX_ENTRIES)throw fail("SEND_EFFECT_JOURNAL_CAPACITY","O journal durável de envios atingiu o limite seguro; novas automações foram bloqueadas.");}
    var journalToken=token();row={id:effectDigest,payloadDigest:payloadDigest,status:"prepared",token:journalToken,createdAt:now,updatedAt:now,expiresAt:now+TTL.prepared};await putRow(row);return{prepared:true,token:journalToken,replayed:false};
  }
  async function begin(input){
    var now=Date.now(),effectDigest=digest(input&&input.effectDigest,"effect"),payloadDigest=digest(input&&input.payloadDigest,"payload"),journalToken=String(input&&input.token||""),row=await getRow(effectDigest);
    if(!row)throw fail("SEND_EFFECT_PREPARE_REQUIRED","O journal durável não encontrou a preparação deste envio.");
    if(!samePayload(row,payloadDigest))throw fail("SEND_EFFECT_ID_CONFLICT","O identificador durável não corresponde ao conteúdo preparado.");
    if(row.status==="committed")return{begun:false,committed:true,recovered:true,committedAt:Number(row.committedAt)||Number(row.updatedAt)};
    if(row.status==="ambiguous")return{begun:false,ambiguous:true,code:"SEND_EFFECT_AMBIGUOUS"};
    if(String(row.token||"")!==journalToken)throw fail("SEND_EFFECT_TOKEN_INVALID","O token durável deste envio não corresponde à preparação.");
    if(row.status==="dispatching")return{begun:true,replayed:true};
    if(row.status!=="prepared")throw fail("SEND_EFFECT_STATE_INVALID","O journal durável não permite iniciar este envio no estado atual.");
    row.status="dispatching";row.updatedAt=now;row.expiresAt=now+TTL.dispatching;await putRow(row);return{begun:true,replayed:false};
  }
  async function commit(input){
    var now=Date.now(),effectDigest=digest(input&&input.effectDigest,"effect"),payloadDigest=digest(input&&input.payloadDigest,"payload"),journalToken=String(input&&input.token||""),row=await getRow(effectDigest);
    if(!row)throw fail("SEND_EFFECT_COMMIT_MISSING","O journal durável perdeu a preparação do envio concluído.");
    if(!samePayload(row,payloadDigest))throw fail("SEND_EFFECT_ID_CONFLICT","O identificador durável não corresponde ao envio concluído.");
    if(row.status==="committed")return{committed:true,replayed:true,committedAt:Number(row.committedAt)||Number(row.updatedAt)};
    if(row.status!=="dispatching"||String(row.token||"")!==journalToken)throw fail("SEND_EFFECT_COMMIT_STATE_INVALID","O journal durável recusou um commit fora de ordem.");
    row.status="committed";row.committedAt=now;row.updatedAt=now;row.expiresAt=now+TTL.committed;delete row.token;await putRow(row);return{committed:true,replayed:false,committedAt:now};
  }
  async function failEffect(input){
    var now=Date.now(),effectDigest=digest(input&&input.effectDigest,"effect"),payloadDigest=digest(input&&input.payloadDigest,"payload"),journalToken=String(input&&input.token||""),row=await getRow(effectDigest);
    if(!row)return{failed:false,missing:true};
    if(!samePayload(row,payloadDigest))throw fail("SEND_EFFECT_ID_CONFLICT","O identificador durável não corresponde ao envio que falhou.");
    if(row.status==="committed")return{failed:false,committed:true};
    if(row.status==="ambiguous")return{failed:false,ambiguous:true};
    if(String(row.token||"")!==journalToken)throw fail("SEND_EFFECT_TOKEN_INVALID","O token durável deste envio não corresponde à preparação.");
    row.status="failed";row.updatedAt=now;row.expiresAt=now+TTL.failed;delete row.token;await putRow(row);return{failed:true};
  }
  async function countCommittedSince(since){since=Number(since)||0;if(!Number.isFinite(since)||since<0)throw fail("SEND_EFFECT_RANGE_INVALID","A janela do journal durável é inválida.");var db=await open(),tx=db.transaction(STORE,"readonly"),done=transactionDone(tx),index=tx.objectStore(STORE).index("committedAt"),count=await requestResult(index.count(IDBKeyRange.lowerBound(since)));await done;return Number(count)||0;}
  async function summary(){var now=Date.now();await pruneExpired(now,true);var db=await open(),tx=db.transaction(STORE,"readonly"),done=transactionDone(tx),store=tx.objectStore(STORE),counts={prepared:0,dispatching:0,ambiguous:0,committed:0,failed:0},total=0;await new Promise(function(resolve,reject){var req=store.openCursor();req.onerror=function(){reject(req.error||fail("SEND_EFFECT_JOURNAL_IO","Falha ao resumir o journal durável."));};req.onsuccess=function(){var cursor=req.result;if(!cursor){resolve();return;}var row=validateEntry(cursor.value);counts[row.status]++;total++;cursor.continue();};});await done;return{version:VERSION,total:total,counts:counts};}
  async function close(){var pending=dbp;dbp=null;if(!pending)return true;try{var db=await pending;if(db&&typeof db.close==="function")db.close();}catch(_){}return true;}
  self.__extSendEffectJournalAuthority=Object.freeze({databaseName:DB,prepare:prepare,begin:begin,commit:commit,fail:failEffect,summary:summary,countCommittedSince:countCommittedSince,close:close});
})();
