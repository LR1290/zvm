try{
(function (root, factory) {
  "use strict";
  var contextCore = root && root.__extAiConversationContext;
  var knowledgeCore = root && root.__extKnowledgeCore;
  var toolsCore = root && root.__extAiToolsRegistry;
  var api = factory(contextCore, knowledgeCore, toolsCore);
  if (root) root.__extAiAssistantsCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (contextCore, knowledgeCore, toolsCore) {
  "use strict";

  var STORE_KEY = "EXTUI:aiAssistantsStore";
  var SCHEMA_VERSION = 5;
  var MODEL_MODES = Object.freeze({ DEFAULT: "default", SPECIFIC: "specific" });
  var EXECUTION_ERRORS = Object.freeze({
    NOT_FOUND: "AI_ASSISTANT_NOT_FOUND",
    DISABLED: "AI_ASSISTANT_DISABLED",
    PROVIDER_UNAVAILABLE: "AI_ASSISTANT_PROVIDER_UNAVAILABLE",
    MODEL_UNAVAILABLE: "AI_ASSISTANT_MODEL_UNAVAILABLE",
    INVALID: "AI_ASSISTANT_INVALID",
    KNOWLEDGE_INVALID: "KNOWLEDGE_BASE_NOT_READY"
  });

  function object(value) { return value && typeof value === "object" && !Array.isArray(value); }
  function text(value) { return typeof value === "string" ? value.trim() : ""; }
  function timestamp(value) { return Number.isFinite(Number(value)) ? Number(value) : null; }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function parse(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { return null; }
  }
  function assistantError(code, message) { var error = new Error(message); error.code = code; return error; }
  function normalizeContext(raw) {
    return contextCore && typeof contextCore.normalizeConfig === "function"
      ? contextCore.normalizeConfig(raw)
      : { mode: "none", messageCount: 5 };
  }


  function normalizeAgentIdAllowlist(raw) {
    if (!Array.isArray(raw)) return null;
    var seen = {}; var out = [];
    raw.forEach(function (id) {
      var clean = text(id);
      if (clean && !seen[clean]) { seen[clean] = true; out.push(clean); }
    });
    return out;
  }
  function normalizeMemory(raw) {
    return {
      mode: raw && raw.mode === "customer" ? "customer" : "none",
      allowedAgentIds: normalizeAgentIdAllowlist(raw && raw.allowedAgentIds)
    };
  }
  function normalizeKnowledge(raw) {
    return knowledgeCore && typeof knowledgeCore.assistantKnowledge === "function"
      ? knowledgeCore.assistantKnowledge(raw)
      : { mode: "none", baseId: null };
  }
  function normalizeTools(raw) {
    return toolsCore && typeof toolsCore.normalizeToolsConfig === "function" ? toolsCore.normalizeToolsConfig(raw) : { enabled: [] };
  }


  function normalizeMultimodal(raw) {
    return { image: !!(raw && raw.image === true), audio: !!(raw && raw.audio === true) };
  }


  function normalizeExternalActions(raw) {
    var list = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.enabled) ? raw.enabled : []);
    var seen = Object.create(null);
    return { enabled: list.map(function (id) { return typeof id === "string" ? id.trim() : ""; }).filter(function (id) { if (!id || seen[id]) return false; seen[id] = true; return true; }) };
  }

  function normalizeAssistant(raw) {
    if (!object(raw) || !text(raw.id)) return null;
    var modelMode = raw.modelMode === MODEL_MODES.SPECIFIC ? MODEL_MODES.SPECIFIC : MODEL_MODES.DEFAULT;
    return {
      id: text(raw.id),
      name: text(raw.name),
      description: text(raw.description),
      providerId: text(raw.providerId),
      modelMode: modelMode,
      model: modelMode === MODEL_MODES.SPECIFIC ? (text(raw.model) || null) : null,
      instructions: typeof raw.instructions === "string" ? raw.instructions.trim() : "",
      context: normalizeContext(raw.context),
      memory: normalizeMemory(raw.memory),
      knowledge: normalizeKnowledge(raw.knowledge),
      tools: normalizeTools(raw.tools),
      multimodal: normalizeMultimodal(raw.multimodal),
      externalActions: normalizeExternalActions(raw.externalActions),
      enabled: raw.enabled !== false,
      createdAt: timestamp(raw.createdAt),
      updatedAt: timestamp(raw.updatedAt)
    };
  }

  function normalizeStore(raw) {
    var parsed = parse(raw);
    var source = object(parsed) && object(parsed.state) ? parsed.state : parsed;
    var assistants = source && Array.isArray(source.assistants) ? source.assistants.map(normalizeAssistant).filter(Boolean) : [];
    return { version: SCHEMA_VERSION, assistants: assistants };
  }

  function serializeStore(raw) {
    var store = normalizeStore(raw);
    return JSON.stringify({ state: { assistants: store.assistants }, version: SCHEMA_VERSION });
  }

  function validateDraft(raw) {
    raw = object(raw) ? raw : {};
    var name = text(raw.name);
    var providerId = text(raw.providerId);
    var modelMode = raw.modelMode === MODEL_MODES.SPECIFIC ? MODEL_MODES.SPECIFIC : MODEL_MODES.DEFAULT;
    var model = text(raw.model);
    if (!name) throw assistantError(EXECUTION_ERRORS.INVALID, "Informe um nome para o assistente.");
    if (!providerId) throw assistantError(EXECUTION_ERRORS.INVALID, "Selecione um serviço de IA para o assistente.");
    if (modelMode === MODEL_MODES.SPECIFIC && !model) throw assistantError(EXECUTION_ERRORS.INVALID, "Selecione um modelo específico.");
    return {
      name: name,
      description: text(raw.description),
      providerId: providerId,
      modelMode: modelMode,
      model: modelMode === MODEL_MODES.SPECIFIC ? model : null,
      instructions: typeof raw.instructions === "string" ? raw.instructions.trim() : "",
      context: normalizeContext(raw.context),
      memory: normalizeMemory(raw.memory),
      knowledge: normalizeKnowledge(raw.knowledge),
      tools: normalizeTools(raw.tools),
      multimodal: normalizeMultimodal(raw.multimodal),
      externalActions: normalizeExternalActions(raw.externalActions),
      enabled: raw.enabled !== false
    };
  }

  function createAssistant(rawStore, draft, dependencies) {
    var store = normalizeStore(rawStore);
    var data = validateDraft(draft);
    var now = dependencies.now();
    var assistant = Object.assign({ id: dependencies.createId() }, data, { createdAt: now, updatedAt: now });
    store.assistants.push(assistant);
    return { store: store, assistant: clone(assistant) };
  }

  function updateAssistant(rawStore, assistantId, draft, dependencies) {
    var store = normalizeStore(rawStore);
    var index = store.assistants.findIndex(function (assistant) { return assistant.id === assistantId; });
    if (index < 0) throw assistantError(EXECUTION_ERRORS.NOT_FOUND, "Assistente não encontrado.");
    var current = store.assistants[index];
    var updated = Object.assign({ id: current.id }, validateDraft(draft), { createdAt: current.createdAt, updatedAt: dependencies.now() });
    store.assistants[index] = updated;
    return { store: store, assistant: clone(updated) };
  }

  function duplicateAssistant(rawStore, assistantId, dependencies) {
    var store = normalizeStore(rawStore);
    var source = store.assistants.find(function (assistant) { return assistant.id === assistantId; });
    if (!source) throw assistantError(EXECUTION_ERRORS.NOT_FOUND, "Assistente não encontrado.");
    return createAssistant(store, {
      name: source.name + " — Cópia",
      description: source.description,
      providerId: source.providerId,
      modelMode: source.modelMode,
      model: source.model,
      instructions: source.instructions,
      context: source.context,
      memory: source.memory,
      knowledge: source.knowledge,
      tools: source.tools,
      multimodal: source.multimodal,
      externalActions: source.externalActions,
      enabled: source.enabled
    }, dependencies);
  }

  function deleteAssistant(rawStore, assistantId) {
    var store = normalizeStore(rawStore);
    var before = store.assistants.length;
    store.assistants = store.assistants.filter(function (assistant) { return assistant.id !== assistantId; });
    if (store.assistants.length === before) throw assistantError(EXECUTION_ERRORS.NOT_FOUND, "Assistente não encontrado.");
    return { store: store, deletedId: assistantId };
  }

  function providerMetadata(integrations, providerId) {
    return integrations && integrations.providers && integrations.providers[providerId] || null;
  }

  function knownModel(metadata, modelId) {
    return !!(metadata && Array.isArray(metadata.availableModels) && metadata.availableModels.some(function (model) {
      return model && model.id === modelId;
    }));
  }

  function knowledgeHealth(assistant, integrations, knowledgeStore) {
    if (!assistant || !assistant.knowledge || assistant.knowledge.mode !== "base") return null;
    var base = knowledgeCore && knowledgeCore.findBase ? knowledgeCore.findBase(knowledgeStore, assistant.knowledge.baseId) : null;
    if (!base || !knowledgeCore.isBaseReady(base)) return { state: "attention", code: EXECUTION_ERRORS.KNOWLEDGE_INVALID, label: "Base de Conhecimento requer atenção" };
    var embeddingProvider = providerMetadata(integrations, base.activeIndex.embeddingProviderId);
    if (!embeddingProvider || embeddingProvider.configured === false || embeddingProvider.enabled !== true || embeddingProvider.status !== "connected") return { state: "attention", code: EXECUTION_ERRORS.KNOWLEDGE_INVALID, label: "Base de Conhecimento requer atenção" };
    return null;
  }

  function healthFor(assistant, integrations, providerIds, knowledgeStore) {
    if (!assistant || !assistant.name || !assistant.providerId) return { state: "attention", code: EXECUTION_ERRORS.INVALID, label: "Configuração incompleta" };
    if (assistant.enabled === false) return { state: "disabled", code: null, label: "Desativado" };
    if (Array.isArray(providerIds) && providerIds.indexOf(assistant.providerId) < 0) return { state: "attention", code: EXECUTION_ERRORS.PROVIDER_UNAVAILABLE, label: "Serviço indisponível" };
    var metadata = providerMetadata(integrations, assistant.providerId);
    if (!metadata || metadata.configured === false || metadata.enabled !== true || metadata.status !== "connected") return { state: "attention", code: EXECUTION_ERRORS.PROVIDER_UNAVAILABLE, label: "Serviço precisa ser configurado" };
    if (assistant.modelMode === MODEL_MODES.DEFAULT && !text(metadata.model)) return { state: "attention", code: EXECUTION_ERRORS.MODEL_UNAVAILABLE, label: "Modelo padrão ausente" };
    if (assistant.modelMode === MODEL_MODES.SPECIFIC && (!assistant.model || !knownModel(metadata, assistant.model))) return { state: "attention", code: EXECUTION_ERRORS.MODEL_UNAVAILABLE, label: "Modelo indisponível" };
    var knowledgeIssue = knowledgeHealth(assistant, integrations, knowledgeStore);
    if (knowledgeIssue) return knowledgeIssue;
    return { state: "ready", code: null, label: "Pronto" };
  }

  function resolveForExecution(rawStore, integrations, assistantId, providerIds, knowledgeStore) {
    var store = normalizeStore(rawStore);
    var assistant = store.assistants.find(function (entry) { return entry.id === assistantId; });
    if (!assistant) throw assistantError(EXECUTION_ERRORS.NOT_FOUND, "O assistente de IA desta etapa não foi encontrado.");
    if (!assistant.enabled) throw assistantError(EXECUTION_ERRORS.DISABLED, "O assistente de IA desta etapa está desativado.");
    var health = healthFor(assistant, integrations, providerIds, knowledgeStore);
    if (health.code === EXECUTION_ERRORS.PROVIDER_UNAVAILABLE) throw assistantError(health.code, "O serviço de IA do assistente não está configurado ou disponível.");
    if (health.code === EXECUTION_ERRORS.MODEL_UNAVAILABLE) throw assistantError(health.code, "O modelo configurado no assistente não está disponível.");
    if (health.code === EXECUTION_ERRORS.KNOWLEDGE_INVALID) throw assistantError(health.code, "A Base de Conhecimento deste assistente requer atenção.");
    if (health.code) throw assistantError(EXECUTION_ERRORS.INVALID, "A configuração do assistente de IA está incompleta.");
    var metadata = providerMetadata(integrations, assistant.providerId);


    var knowledgeConfig = normalizeKnowledge(assistant.knowledge);
    var knowledgeBase = knowledgeConfig.mode === "base" && knowledgeCore && typeof knowledgeCore.findBase === "function"
      ? knowledgeCore.findBase(knowledgeStore, knowledgeConfig.baseId)
      : null;
    return Object.freeze({
      assistantId: assistant.id,
      assistantName: assistant.name,
      providerId: assistant.providerId,
      model: assistant.modelMode === MODEL_MODES.DEFAULT ? metadata.model : assistant.model,
      modelMode: assistant.modelMode,
      instructions: assistant.instructions,
      context: normalizeContext(assistant.context),
      memory: normalizeMemory(assistant.memory),
      knowledge: Object.assign({}, knowledgeConfig, { allowedAgentIds: knowledgeBase ? knowledgeBase.allowedAgentIds : null }),
      tools: normalizeTools(assistant.tools),
      multimodal: normalizeMultimodal(assistant.multimodal),
      externalActions: normalizeExternalActions(assistant.externalActions)
    });
  }

  function summarize(rawStore, integrations, providerIds, knowledgeStore) {
    var assistants = normalizeStore(rawStore).assistants;
    return {
      total: assistants.length,
      active: assistants.filter(function (assistant) { return assistant.enabled; }).length,
      attention: assistants.filter(function (assistant) { return healthFor(assistant, integrations, providerIds, knowledgeStore).state === "attention"; }).length
    };
  }

  function countFlowReferences(flows, assistantId) {
    return (Array.isArray(flows) ? flows : []).filter(function (flow) {
      return flow && Array.isArray(flow.nodes) && flow.nodes.some(function (node) {
        return node && node.type === "aiGenerate" && node.data && node.data.mode === "assistant" && node.data.assistantId === assistantId;
      });
    }).length;
  }

  function nodeMode(data) { return data && data.mode === "assistant" ? "assistant" : "manual"; }
  function serializeAiNodeData(raw) {
    raw = object(raw) ? raw : {};
    if (nodeMode(raw) === "assistant") return { mode: "assistant", assistantId: text(raw.assistantId) || null, prompt: typeof raw.prompt === "string" ? raw.prompt : "", outputMode: "sendText" };
    return { mode: "manual", providerId: text(raw.providerId), model: text(raw.model) || null, instructions: typeof raw.instructions === "string" ? raw.instructions : "", prompt: typeof raw.prompt === "string" ? raw.prompt : "", outputMode: "sendText" };
  }

  function createRepository(dependencies) {
    var queue = Promise.resolve();
    function readFresh() { return Promise.resolve(dependencies.read()).then(normalizeStore); }
    function mutate(operation) {
      var job = queue.catch(function () {}).then(async function () {
        var current = await readFresh();
        var outcome = operation(current);
        await dependencies.write(serializeStore(outcome.store));
        return outcome;
      });
      queue = job.catch(function () {});
      return job;
    }
    var mutationDeps = { createId: dependencies.createId, now: dependencies.now };
    return Object.freeze({
      get: readFresh,
      create: function (draft) { return mutate(function (store) { return createAssistant(store, draft, mutationDeps); }); },
      update: function (id, draft) { return mutate(function (store) { return updateAssistant(store, id, draft, mutationDeps); }); },
      duplicate: function (id) { return mutate(function (store) { return duplicateAssistant(store, id, mutationDeps); }); },
      remove: function (id) { return mutate(function (store) { return deleteAssistant(store, id); }); }
    });
  }

  return Object.freeze({
    STORE_KEY: STORE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    MODEL_MODES: MODEL_MODES,
    EXECUTION_ERRORS: EXECUTION_ERRORS,
    normalizeMemory: normalizeMemory,
    normalizeKnowledge: normalizeKnowledge,
    normalizeTools: normalizeTools,
    normalizeMultimodal: normalizeMultimodal,
    normalizeExternalActions: normalizeExternalActions,
    normalizeAssistant: normalizeAssistant,
    normalizeStore: normalizeStore,
    serializeStore: serializeStore,
    validateDraft: validateDraft,
    createAssistant: createAssistant,
    updateAssistant: updateAssistant,
    duplicateAssistant: duplicateAssistant,
    deleteAssistant: deleteAssistant,
    healthFor: healthFor,
    resolveForExecution: resolveForExecution,
    summarize: summarize,
    countFlowReferences: countFlowReferences,
    nodeMode: nodeMode,
    serializeAiNodeData: serializeAiNodeData,
    createRepository: createRepository
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
