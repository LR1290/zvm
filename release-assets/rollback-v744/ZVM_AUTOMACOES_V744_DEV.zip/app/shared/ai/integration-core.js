try{
(function (root, factory) {
  var contextCore = root && root.__extAiConversationContext;
  var memoryCore = root && root.__extAiMemoryCore;
  var knowledgeCore = root && root.__extKnowledgeCore;
  var toolsCore = root && root.__extAiToolsRegistry;
  var api = factory(contextCore, memoryCore, knowledgeCore, toolsCore);
  root.__extIntegrationCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (contextCore, memoryCore, knowledgeCore, toolsCore) {
  "use strict";

                                                                            
                                                                            
                                                                             

  var STORE_KEY = "EXTUI:integrationsStore";
  var SECRETS_KEY = "EXTUI:integrationSecrets";
                                                                            
                                                                             
  var AI_MEMORY_STORE_KEY = "EXTUI:aiMemoryStore";
  var KNOWLEDGE_STORE_KEY = "EXTUI:knowledgeBasesStore";
  var WEBHOOKS_KEY = "EXTUI:extappWebhookStore";
  var SCHEMA_VERSION = 1;
  var AI_OUTPUT_MAX_CHARS = 60000;
  var PROVIDER_HELP_LINK_TYPES = Object.freeze(["createKey", "manageAccount", "documentation"]);
  var PROVIDER_HELP_ORIGINS = Object.freeze([
    "https://platform.openai.com",
    "https://developers.openai.com",
    "https://aistudio.google.com",
    "https://ai.google.dev",
    "https://console.x.ai",
    "https://docs.x.ai",
    "https://grok.com"
  ]);
  function onboarding(title, createKeyLabel, createKey, manageAccount, documentation) {
    return Object.freeze({
      title: title,
      createKeyLabel: createKeyLabel,
      helpLinks: Object.freeze({ createKey: createKey, manageAccount: manageAccount, documentation: documentation })
    });
  }
                                                                             
                                                                       
                                                                          
                                                                           
                                                                          
                                                                             
                                                                            
                                                                           
                                                                       
                                                                        
                                                                         
                                                                  
                                                                               
                                                                  
  var PROVIDERS = Object.freeze([
    Object.freeze({ id: "openai", label: "OpenAI", description: "OpenAI para Perfis e Agentes.", kind: "ai", capabilities: Object.freeze({ generation: true, embedding: true, vision: true, audioInput: false, transcription: true, functionCalling: true }), onboarding: onboarding("Conectar OpenAI", "Criar chave na OpenAI", "https://platform.openai.com/api-keys", "https://platform.openai.com/settings/organization/api-keys", "https://developers.openai.com/api/docs/quickstart") }),
    Object.freeze({ id: "gemini", label: "Google Gemini", description: "Gemini para Perfis e Agentes.", kind: "ai", capabilities: Object.freeze({ generation: true, embedding: true, vision: true, audioInput: true, transcription: true, functionCalling: true }), onboarding: onboarding("Conectar Google Gemini", "Criar chave no Google AI Studio", "https://aistudio.google.com/apikey", "https://aistudio.google.com/apikey", "https://ai.google.dev/gemini-api/docs/api-key") }),
    Object.freeze({ id: "xai", label: "Grok", description: "Use o Grok oficial da xAI (grok.com) nas automações inteligentes da extensão.", kind: "ai", capabilities: Object.freeze({ generation: true, embedding: false, vision: true, audioInput: false, functionCalling: true }), onboarding: onboarding("Conectar Grok", "Criar chave da API Grok", "https://console.x.ai/team/default/api-keys", "https://grok.com/", "https://docs.x.ai/developers/quickstart") }),
    Object.freeze({ id: "webhooks", label: "Webhooks", description: "Envie eventos da extensão para sistemas externos pelo mecanismo já existente.", kind: "existing", capabilities: Object.freeze({ generation: false, embedding: false, vision: false, audioInput: false }) })
  ]);
                                                                          
                                                                            
                                                                         
                                                                        
                                                                      
                                                                            
                                                                            
                                                        
  var MEDIA_LIMITS = Object.freeze({
    image: Object.freeze({ maxBytes: 6 * 1024 * 1024 }),
    audio: Object.freeze({ maxBytes: 8 * 1024 * 1024, maxDurationSeconds: 120 })
  });
  var MEDIA_KIND_CAPABILITY = Object.freeze({ image: "vision", audio: "audioInput" });
  var PROVIDER_IDS = PROVIDERS.filter(function (provider) { return provider.kind === "ai"; }).map(function (provider) { return provider.id; });
  var EMBEDDING_PROVIDER_IDS = PROVIDERS.filter(function (provider) { return provider.capabilities && provider.capabilities.embedding; }).map(function (provider) { return provider.id; });
  var STATUSES = Object.freeze({ NOT_CONFIGURED: "not_configured", CONNECTED: "connected", ATTENTION: "attention" });

  function object(value) { return value && typeof value === "object" && !Array.isArray(value); }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function providerExists(id) { return PROVIDER_IDS.indexOf(id) >= 0; }
  function providerById(id) { return PROVIDERS.find(function (provider) { return provider.id === id; }) || null; }
  function providerHasCapability(id, capability) { var provider = providerById(id); return !!(provider && provider.capabilities && provider.capabilities[capability] === true); }
  function isAllowedProviderHelpUrl(rawUrl) {
    if (typeof rawUrl !== "string" || !rawUrl) return false;
    try {
      var parsed = new URL(rawUrl);
      return parsed.protocol === "https:" && !parsed.username && !parsed.password && !parsed.search && !parsed.hash && PROVIDER_HELP_ORIGINS.indexOf(parsed.origin) >= 0;
    } catch (error) { return false; }
  }
  function resolveProviderHelpLink(providerId, linkType) {
    if (PROVIDER_HELP_LINK_TYPES.indexOf(linkType) < 0) return null;
    var provider = providerById(providerId);
    if (!provider || provider.kind !== "ai" || !provider.onboarding) return null;
    var url = provider.onboarding.helpLinks[linkType];
    return isAllowedProviderHelpUrl(url) ? url : null;
  }
  function normalizeAvailableModels(raw) {
    var seen = Object.create(null);
    return (Array.isArray(raw) ? raw : []).map(function (model) {
      var id = model && typeof model.id === "string" ? model.id.trim() : "";
      if (!id || seen[id]) return null;
      seen[id] = true;
      return { id: id, label: model && typeof model.label === "string" && model.label.trim() ? model.label.trim() : id };
    }).filter(Boolean);
  }
  function normalizeProvider(raw) {
    raw = object(raw) ? raw : {};
    var allowedStatus = [STATUSES.NOT_CONFIGURED, STATUSES.CONNECTED, STATUSES.ATTENTION];
    return {
      enabled: raw.enabled === true,
      model: typeof raw.model === "string" && raw.model.trim() ? raw.model.trim() : null,
      availableModels: normalizeAvailableModels(raw.availableModels),
      status: allowedStatus.indexOf(raw.status) >= 0 ? raw.status : STATUSES.NOT_CONFIGURED,
      lastTestedAt: Number.isFinite(Number(raw.lastTestedAt)) ? Number(raw.lastTestedAt) : null,
      updatedAt: Number.isFinite(Number(raw.updatedAt)) ? Number(raw.updatedAt) : null,
      lastErrorCode: typeof raw.lastErrorCode === "string" ? raw.lastErrorCode : null
    };
  }
  function normalizeStore(raw) {
    var source = object(raw) && object(raw.state) ? raw.state : raw;
    var store = { version: SCHEMA_VERSION, providers: {} };
    PROVIDER_IDS.forEach(function (id) { store.providers[id] = normalizeProvider(source && source.providers && source.providers[id]); });
    return store;
  }
  function normalizeSecrets(raw) {
    var source = object(raw) && object(raw.state) ? raw.state : raw;
    var secrets = { version: SCHEMA_VERSION, providers: {} };
    PROVIDER_IDS.forEach(function (id) {
      var entry = source && source.providers && source.providers[id];
      if (object(entry) && typeof entry.apiKey === "string" && entry.apiKey.trim()) secrets.providers[id] = { apiKey: entry.apiKey.trim(), updatedAt: Number(entry.updatedAt) || null };
    });
    return secrets;
  }
  function validateConfig(providerId, config) {
    if (!providerExists(providerId)) return { valid: false, errorCode: "provider_not_found" };
    if (!config || typeof config.apiKey !== "string" || !config.apiKey.trim()) return { valid: false, errorCode: "credential_missing" };
    return { valid: true, apiKey: config.apiKey.trim() };
  }
  function maskSecret(secret) {
    if (typeof secret !== "string" || !secret) return null;
    return "••••••••••••" + secret.slice(-4).toUpperCase();
  }
  function publicState(metadataRaw, secretsRaw, webhookRaw) {
    var metadata = normalizeStore(metadataRaw);
    var secrets = normalizeSecrets(secretsRaw);
    var providers = {};
    PROVIDER_IDS.forEach(function (id) {
      var meta = clone(metadata.providers[id]);
      var secret = secrets.providers[id];
      meta.configured = !!secret;
      meta.keyHint = secret ? maskSecret(secret.apiKey) : null;
      if (!secret) {
        meta.status = meta.enabled || meta.model || meta.lastTestedAt ? STATUSES.ATTENTION : STATUSES.NOT_CONFIGURED;
        meta.enabled = false;
      }
      providers[id] = meta;
    });
    var parsedWebhook = webhookRaw;
    try { if (typeof parsedWebhook === "string") parsedWebhook = JSON.parse(parsedWebhook); } catch (error) { parsedWebhook = null; }
    var webhookList = parsedWebhook && parsedWebhook.state && Array.isArray(parsedWebhook.state.webhookList) ? parsedWebhook.state.webhookList : [];
    providers.webhooks = { configured: webhookList.some(function (item) { return !!(item && item.url); }), activeCount: webhookList.filter(function (item) { return item && item.active === true && item.url; }).length, status: webhookList.some(function (item) { return item && item.active === true && item.url; }) ? STATUSES.CONNECTED : STATUSES.NOT_CONFIGURED };
    return { version: SCHEMA_VERSION, providers: providers };
  }
  function summarize(publicRaw) {
    var providers = publicRaw && publicRaw.providers || {};
    var entries = PROVIDERS.map(function (provider) { return providers[provider.id] || {}; });
    return {
      configured: entries.filter(function (item) { return item.configured; }).length,
      connected: entries.filter(function (item) { return item.status === STATUSES.CONNECTED; }).length,
      attention: entries.filter(function (item) { return item.status === STATUSES.ATTENTION; }).length
    };
  }
  function sanitizeError(error) {
    var code = error && typeof error.code === "string" ? error.code : "unknown_error";
    var messages = {
      provider_not_found: "Serviço de IA não reconhecido.", credential_missing: "Informe a chave de acesso para continuar.",
      auth_failed: "A chave de acesso foi recusada pelo serviço.", access_denied: "A credencial não possui acesso a este recurso.",
      rate_limited: "O limite de uso do serviço foi atingido. Tente novamente mais tarde.", timeout: "O serviço demorou demais para responder.",
      network_error: "Não foi possível conectar ao serviço.", provider_unavailable: "O serviço está temporariamente indisponível.", invalid_response: "O serviço retornou uma resposta inesperada."
    };
    return { errorCode: messages[code] ? code : "unknown_error", userMessage: messages[code] || "Não foi possível concluir a operação." };
  }
  function normalizeAiRequest(raw) {
    raw = object(raw) ? raw : {};
    var requestId = typeof raw.requestId === "string" ? raw.requestId.trim() : "";
    var executionId = typeof raw.executionId === "string" ? raw.executionId.trim() : "";
    var providerId = typeof raw.providerId === "string" ? raw.providerId.trim() : "";
    var model = typeof raw.model === "string" && raw.model.trim() ? raw.model.trim() : null;
    var instructions = typeof raw.instructions === "string" ? raw.instructions.trim() : "";
    var input = typeof raw.input === "string" ? raw.input.trim() : "";
    var conversation = contextCore && typeof contextCore.normalizeConversation === "function" ? contextCore.normalizeConversation(raw.conversation, 20) : [];
    var memory = memoryCore && typeof memoryCore.normalizeRuntimeMemory === "function" ? memoryCore.normalizeRuntimeMemory(raw.memory) : [];
    var knowledge = knowledgeCore && typeof knowledgeCore.normalizeRuntimeKnowledge === "function" ? knowledgeCore.normalizeRuntimeKnowledge(raw.knowledge) : [];
    var assistantId = typeof raw.assistantId === "string" ? raw.assistantId.trim().slice(0, 160) : "";
    var requestedToolIds = toolsCore && typeof toolsCore.normalizeEnabledToolIds === "function" ? toolsCore.normalizeEnabledToolIds(raw.tools) : [];
    var toolContextRaw = object(raw.toolContext) ? raw.toolContext : {};
    var toolContext = {
      crmContactId: typeof toolContextRaw.crmContactId === "string" ? toolContextRaw.crmContactId.trim().slice(0, 160) : "",
      crmId: typeof toolContextRaw.crmId === "string" ? toolContextRaw.crmId.trim().slice(0, 160) : "",
      memorySubjectKey: typeof toolContextRaw.memorySubjectKey === "string" && /^sha256:[a-f0-9]{64}$/.test(toolContextRaw.memorySubjectKey) ? toolContextRaw.memorySubjectKey : "",
      localDateTime: typeof toolContextRaw.localDateTime === "string" ? toolContextRaw.localDateTime.trim().slice(0, 80) : ""
    };
    var agentControl = null;
    if (object(raw.agentControl)) {
      var agentId = typeof raw.agentControl.agentId === "string" ? raw.agentControl.agentId.trim().slice(0, 160) : "";
      var agentRunId = typeof raw.agentControl.agentRunId === "string" ? raw.agentControl.agentRunId.trim().slice(0, 200) : "";
      var agentStep = Math.floor(Number(raw.agentControl.step));
      var agentMaxSteps = Math.floor(Number(raw.agentControl.maxSteps));
      var toolCallLimit = Math.floor(Number(raw.agentControl.toolCallLimit));
      if (!agentId || !agentRunId || !Number.isFinite(agentStep) || agentStep < 1 || agentStep > 8 || !Number.isFinite(agentMaxSteps) || agentMaxSteps < 1 || agentMaxSteps > 8 || !Number.isFinite(toolCallLimit) || toolCallLimit < 0 || toolCallLimit > 5) return { valid: false, errorCode: "AI_AGENT_RUNTIME_FAILED" };
      agentControl = { agentId: agentId, agentRunId: agentRunId, step: agentStep, maxSteps: agentMaxSteps, toolCallLimit: toolCallLimit };
    }
    var options = {};
    if (object(raw.options) && Number.isFinite(Number(raw.options.maxOutputTokens))) {
      options.maxOutputTokens = Math.max(1, Math.floor(Number(raw.options.maxOutputTokens)));
    }
                                                                             
                                                                       
                                                                        
                                                                         
                         
    var media = null;
    if (object(raw.media)) {
      var mediaKind = raw.media.kind === "image" || raw.media.kind === "audio" ? raw.media.kind : "";
      var mediaMime = typeof raw.media.mimeType === "string" ? raw.media.mimeType.trim().slice(0, 100) : "";
      var mediaData = typeof raw.media.dataBase64 === "string" ? raw.media.dataBase64 : "";
      if (!mediaKind || !mediaMime || !mediaData) return { valid: false, errorCode: "AI_MEDIA_UNSUPPORTED" };
      var limits = MEDIA_LIMITS[mediaKind];
                                                                          
                                                                           
                                                
      var approxBytes = Math.floor(mediaData.length * 0.75);
      if (approxBytes > limits.maxBytes) return { valid: false, errorCode: "AI_MEDIA_TOO_LARGE" };
      media = { kind: mediaKind, mimeType: mediaMime, dataBase64: mediaData };
    }
    if (!requestId) return { valid: false, errorCode: "ai_request_id_required" };
    if (!executionId) return { valid: false, errorCode: "ai_execution_id_required" };
    if (!providerExists(providerId)) return { valid: false, errorCode: "provider_not_found" };
    if (!input) return { valid: false, errorCode: "ai_prompt_required" };
    if (media && !providerHasCapability(providerId, MEDIA_KIND_CAPABILITY[media.kind])) return { valid: false, errorCode: "AI_MULTIMODAL_NOT_SUPPORTED" };
    var request = { requestId: requestId, executionId: executionId, providerId: providerId, model: model, instructions: instructions, input: input, conversation: conversation, memory: memory, knowledge: knowledge, assistantId: assistantId || null, requestedToolIds: requestedToolIds, tools: toolsCore && toolsCore.definitionsFor ? toolsCore.definitionsFor(requestedToolIds) : [], toolContext: toolContext, agentControl: agentControl, options: options };
    if (media) request.media = media;
    return { valid: true, request: request };
  }
  function normalizeUsage(raw) {
    raw = object(raw) ? raw : {};
    function token(value) { return Number.isFinite(Number(value)) ? Number(value) : null; }
    return { inputTokens: token(raw.inputTokens), outputTokens: token(raw.outputTokens), totalTokens: token(raw.totalTokens) };
  }
  function normalizeGenerationResult(providerId, model, text, usage, durationMs) {
    var normalizedText = typeof text === "string" ? text.trim() : "";
    if (!normalizedText) { var empty = new Error("ai_empty_response"); empty.code = "ai_empty_response"; throw empty; }
    if (normalizedText.length > AI_OUTPUT_MAX_CHARS) { var large = new Error("ai_response_too_long"); large.code = "ai_response_too_long"; throw large; }
    return { ok: true, provider: providerId, model: model, text: normalizedText, usage: normalizeUsage(usage), durationMs: Math.max(0, Number(durationMs) || 0) };
  }
  function sanitizeGenerationError(error, providerId) {
    var code = error && typeof error.code === "string" ? error.code : "unknown_error";
    var messages = {
      provider_not_found: "Serviço de IA não reconhecido.", integration_not_configured: "Configure esta integração antes de executar o fluxo.",
      integration_disabled: "Esta integração está desabilitada.", integration_not_ready: "Valide novamente a integração antes de usá-la em automações.",
      credential_missing: "A credencial desta integração não está disponível.", model_required: "Escolha o modelo de IA que será usado por padrão.",
      model_invalid: "O modelo configurado nesta etapa não está disponível.", ai_prompt_required: "Informe as instruções desta etapa de IA.",
      AI_CONTEXT_UNAVAILABLE: "Não foi possível carregar o contexto recente desta conversa.",
      KNOWLEDGE_BASE_NOT_FOUND: "A Base de Conhecimento não foi encontrada.", KNOWLEDGE_BASE_NOT_READY: "A Base de Conhecimento requer atenção.",
      KNOWLEDGE_EMBEDDING_PROVIDER_UNAVAILABLE: "O serviço usado para preparar a busca da base não está disponível.", KNOWLEDGE_EMBEDDING_FAILED: "Não foi possível preparar a busca para esta consulta.",
      KNOWLEDGE_RETRIEVAL_FAILED: "Não foi possível consultar a Base de Conhecimento.", KNOWLEDGE_CANCELLED: "A consulta à Base de Conhecimento foi cancelada.",
      AI_TOOL_NOT_ALLOWED: "Este Assistente não possui permissão para a ferramenta solicitada.", AI_TOOL_NOT_FOUND: "A ferramenta solicitada não está disponível.",
      AI_TOOL_INVALID_ARGUMENTS: "A ferramenta recebeu argumentos inválidos.", AI_TOOL_CONTEXT_UNAVAILABLE: "A ferramenta não está disponível para este contato.",
      AI_TOOL_EXECUTION_FAILED: "Não foi possível concluir a ação solicitada pela IA.", AI_TOOL_LIMIT_EXCEEDED: "A execução excedeu o limite seguro de ferramentas.", AI_REQUEST_LIMIT_EXCEEDED: "Há muitas operações de IA em andamento. Aguarde algumas concluírem e tente novamente.",
      AI_TOOL_CANCELLED: "A execução da ferramenta foi cancelada.",
      AI_AGENT_NOT_FOUND: "O agente desta etapa não foi encontrado.", AI_AGENT_DISABLED: "O agente desta etapa está desativado.",
      AI_AGENT_ASSISTANT_INVALID: "O Assistente associado ao agente requer atenção.", AI_AGENT_STEP_LIMIT_EXCEEDED: "O agente atingiu o limite seguro de etapas.",
      AI_AGENT_TOOL_LIMIT_EXCEEDED: "O agente atingiu o limite seguro de ferramentas.", AI_AGENT_MODEL_TOOL_UNSUPPORTED: "O modelo selecionado não aceitou o modo de ferramentas exigido pelo Agente. Escolha outro modelo compatível com uso de ferramentas.", AI_AGENT_CONTROL_REQUIRED: "O modelo respondeu sem acionar o controle obrigatório do Agente. Escolha um modelo compatível com uso de ferramentas.", AI_AGENT_RUNTIME_FAILED: "Não foi possível concluir a execução do agente.",
      AI_AGENT_EMPTY_RESPONSE: "O agente concluiu sem produzir uma resposta.", AI_AGENT_CANCELLED: "A execução do agente foi cancelada.",
      ai_request_id_required: "A solicitação de IA é inválida.", ai_execution_id_required: "A execução de IA é inválida.",
      AI_MULTIMODAL_NOT_SUPPORTED: "O serviço ou modelo escolhido não aceita este tipo de conteúdo.",
      AI_MEDIA_TOO_LARGE: "O arquivo de mídia excede o limite seguro de tamanho.",
      AI_MEDIA_UNSUPPORTED: "Este tipo de mídia não pode ser usado nesta etapa.",
      AI_MEDIA_DOWNLOAD_FAILED: "Não foi possível baixar a mídia desta mensagem.",
      AI_AUDIO_PROCESSING_FAILED: "Não foi possível processar o áudio desta mensagem.",
      ai_request_conflict: "Esta solicitação de IA já está em andamento.", ai_empty_response: "O serviço de IA retornou uma resposta vazia.",
      ai_response_too_long: "A resposta de IA excede o limite seguro para envio.", ai_cancelled: "A geração de IA foi cancelada.",
      auth_failed: "A chave de acesso foi recusada pelo serviço.", access_denied: "A credencial não possui acesso ao modelo solicitado.",
      openai_credits_exhausted: "Sua conta da OpenAI está sem créditos disponíveis. Confira o faturamento da conta.",
      openai_model_unavailable: "O modelo OpenAI está indisponível para esta conta.", openai_invalid_request: "A OpenAI recusou o modelo ou os parâmetros desta solicitação.",
      openai_response_failed: "A OpenAI não conseguiu concluir a geração.", openai_response_incomplete: "A resposta OpenAI foi interrompida antes de concluir.",
      rate_limited: "O limite temporário de uso do serviço foi atingido.", timeout: "A geração de IA excedeu o tempo limite.",
      network_error: "Não foi possível conectar ao serviço.", provider_unavailable: "O serviço está temporariamente indisponível.",
      invalid_response: "O serviço retornou uma resposta inesperada."
    };
    var retryable = ["rate_limited", "timeout", "network_error", "provider_unavailable", "AI_REQUEST_LIMIT_EXCEEDED"].indexOf(code) >= 0;
    var userMessage = messages[code] || "Não foi possível gerar a resposta com IA.";
    if (providerId === "openai") {
      if (code === "auth_failed") userMessage = "A chave de acesso da OpenAI é inválida ou foi revogada.";
      else if (code === "access_denied") userMessage = "A conta OpenAI não possui acesso ao recurso solicitado.";
      else if (code === "rate_limited") userMessage = "O limite temporário de solicitações da OpenAI foi atingido.";
    }
    var result = { ok: false, provider: providerExists(providerId) ? providerId : null, errorCode: messages[code] ? code : "unknown_error", userMessage: userMessage, retryable: retryable };
    if (error && error.httpStatus != null && Number.isFinite(Number(error.httpStatus))) result.httpStatus = Number(error.httpStatus);
    if (error && typeof error.providerErrorCode === "string" && /^[a-z0-9_.:-]{1,80}$/i.test(error.providerErrorCode)) result.providerErrorCode = error.providerErrorCode;
    if (error && typeof error.providerErrorType === "string" && /^[a-z0-9_.:-]{1,80}$/i.test(error.providerErrorType)) result.providerErrorType = error.providerErrorType;
    return result;
  }
                                                                           
                                                                          
                                                                     
                                                                
  var EXTERNAL_ACTION_SECRETS_KEY = "EXTUI:externalActionSecrets";
  function stripSecretsFromBackup(raw) {
    var data = object(raw) ? Object.assign({}, raw) : {};
    delete data[SECRETS_KEY];
    delete data[AI_MEMORY_STORE_KEY];
    delete data[KNOWLEDGE_STORE_KEY];
    delete data[EXTERNAL_ACTION_SECRETS_KEY];
    return data;
  }
  return Object.freeze({ STORE_KEY: STORE_KEY, SECRETS_KEY: SECRETS_KEY, WEBHOOKS_KEY: WEBHOOKS_KEY, KNOWLEDGE_STORE_KEY: KNOWLEDGE_STORE_KEY, SCHEMA_VERSION: SCHEMA_VERSION, AI_OUTPUT_MAX_CHARS: AI_OUTPUT_MAX_CHARS, PROVIDERS: PROVIDERS, PROVIDER_IDS: PROVIDER_IDS, EMBEDDING_PROVIDER_IDS: EMBEDDING_PROVIDER_IDS, PROVIDER_HELP_LINK_TYPES: PROVIDER_HELP_LINK_TYPES, PROVIDER_HELP_ORIGINS: PROVIDER_HELP_ORIGINS, STATUSES: STATUSES, providerExists: providerExists, providerById: providerById, providerHasCapability: providerHasCapability, isAllowedProviderHelpUrl: isAllowedProviderHelpUrl, resolveProviderHelpLink: resolveProviderHelpLink, normalizeAvailableModels: normalizeAvailableModels, normalizeStore: normalizeStore, normalizeSecrets: normalizeSecrets, validateConfig: validateConfig, maskSecret: maskSecret, publicState: publicState, summarize: summarize, sanitizeError: sanitizeError, normalizeAiRequest: normalizeAiRequest, normalizeUsage: normalizeUsage, normalizeGenerationResult: normalizeGenerationResult, sanitizeGenerationError: sanitizeGenerationError, stripSecretsFromBackup: stripSecretsFromBackup });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
