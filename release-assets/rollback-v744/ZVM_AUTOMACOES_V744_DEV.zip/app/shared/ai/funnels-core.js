try{
(function (root, factory) {
  "use strict";
  var assistantsCore = root && root.__extAiAssistantsCore;
  var agentsCore = root && root.__extAiAgentsCore;
  var api = factory(assistantsCore, agentsCore);
  if (root) root.__extFunnelsCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (assistantsCore, agentsCore) {
  "use strict";

  var STEP_TYPES = Object.freeze({
    MESSAGE: "message",
    AUDIO: "audio",
    IMAGE: "image",
    VIDEO: "video",
    MEDIA: "media",
    STICKER: "sticker",
    DOCUMENT: "document",
    PIX: "pix",
    INTERACTIVE_LIST: "interactive-list",
    CONTACT: "contact",
    SIGNATURE: "signature",
    AI_GENERATE: "aiGenerate",
    AI_AGENT: "aiAgent"
  });
  var AI_STEP_TYPES = Object.freeze([STEP_TYPES.AI_GENERATE, STEP_TYPES.AI_AGENT]);
  var ITEM_STEP_TYPES = Object.freeze([STEP_TYPES.MESSAGE, STEP_TYPES.AUDIO, STEP_TYPES.IMAGE, STEP_TYPES.VIDEO, STEP_TYPES.MEDIA, STEP_TYPES.STICKER, STEP_TYPES.DOCUMENT, STEP_TYPES.PIX, STEP_TYPES.INTERACTIVE_LIST, STEP_TYPES.CONTACT, STEP_TYPES.SIGNATURE]);
  var DELAY_UNIT_MS = Object.freeze({ seconds: 1000, minutes: 60000, hours: 3600000, days: 86400000 });
  var PREFLIGHT_ERRORS = Object.freeze({
    ASSISTANT_REQUIRED: "FUNNEL_AI_ASSISTANT_REQUIRED",
    ASSISTANT_NOT_FOUND: "FUNNEL_AI_ASSISTANT_NOT_FOUND",
    ASSISTANT_DISABLED: "FUNNEL_AI_ASSISTANT_DISABLED",
    ASSISTANT_INVALID: "FUNNEL_AI_ASSISTANT_INVALID",
    PROMPT_REQUIRED: "FUNNEL_AI_PROMPT_REQUIRED",
    AGENT_REQUIRED: "FUNNEL_AI_AGENT_REQUIRED",
    AGENT_NOT_FOUND: "FUNNEL_AI_AGENT_NOT_FOUND",
    AGENT_DISABLED: "FUNNEL_AI_AGENT_DISABLED",
    AGENT_INVALID: "FUNNEL_AI_AGENT_INVALID",
    TASK_REQUIRED: "FUNNEL_AI_TASK_REQUIRED"
  });

  function object(value) { return !!value && typeof value === "object" && !Array.isArray(value); }
  function text(value, limit) {
    var normalized = typeof value === "string" ? value.trim() : "";
    return limit ? normalized.slice(0, limit) : normalized;
  }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function normalizeDelayAmount(value) { return Math.max(0, Number.isFinite(Number(value)) ? Number(value) : 0); }
  function normalizeDelayUnit(value) { return Object.prototype.hasOwnProperty.call(DELAY_UNIT_MS, value) ? value : "minutes"; }
  function delayMetadata(raw) {
    var amount = normalizeDelayAmount(raw && raw.delayAmount);
    var unit = normalizeDelayUnit(raw && raw.delayUnit);
      if (unit === "days") { amount = amount * 24; unit = "hours"; }
    return { delayAmount: amount, delayUnit: unit };
  }
  function isAiStepType(type) { return AI_STEP_TYPES.indexOf(type) >= 0; }
  function isItemStepType(type) { return ITEM_STEP_TYPES.indexOf(type) >= 0; }

  function createStep(type, structural) {
    var delay = delayMetadata(structural);
    if (type === STEP_TYPES.AI_GENERATE) return Object.assign({ type: type, assistantId: null, prompt: "" }, delay);
    if (type === STEP_TYPES.AI_AGENT) return Object.assign({ type: type, agentId: null, task: "" }, delay);
    return Object.assign({ type: isItemStepType(type) ? type : STEP_TYPES.MESSAGE, itemId: "" }, delay);
  }

  function serializeStep(raw) {
    raw = object(raw) ? raw : {};
    var type = text(raw.type, 80) || STEP_TYPES.MESSAGE;
    var delay = delayMetadata(raw);
    if (type === STEP_TYPES.AI_GENERATE) {
      return Object.assign({
        type: type,
        assistantId: text(raw.assistantId, 160) || null,
        prompt: typeof raw.prompt === "string" ? raw.prompt.slice(0, 12000) : ""
      }, delay);
    }
    if (type === STEP_TYPES.AI_AGENT) {
      return Object.assign({
        type: type,
        agentId: text(raw.agentId, 160) || null,
        task: typeof raw.task === "string" ? raw.task.slice(0, 6000) : ""
      }, delay);
    }
    if (isItemStepType(type)) {
      return Object.assign({ type: type, itemId: text(raw.itemId, 240) }, delay);
    }
    var preserved = clone(raw) || {};
    preserved.type = type;
    preserved.delayAmount = delay.delayAmount;
    preserved.delayUnit = delay.delayUnit;
    return preserved;
  }

  function serializeDefinition(raw) {
    raw = object(raw) ? raw : {};
    var definition = Object.assign({}, clone(raw));
    definition.id = text(raw.id, 240);
    definition.name = text(raw.name, 160) || "Novo funil";
    definition.description = typeof raw.description === "string" ? raw.description.trim().slice(0, 300) : "";
    definition.color = text(raw.color, 32) || "#f43f5e";
    definition.favorite = raw.favorite === true;
    definition.items = (Array.isArray(raw.items) ? raw.items : []).map(serializeStep);
    return definition;
  }

  function duplicateDefinition(raw, createId) {
    var duplicate = serializeDefinition(raw);
    duplicate.id = createId();
    duplicate.name = (duplicate.name || "Funil") + " — Cópia";
    duplicate.favorite = false;
    return duplicate;
  }

  function hasAiSteps(funnel) {
    return !!(funnel && Array.isArray(funnel.items) && funnel.items.some(function (step) {
      return step && isAiStepType(step.type);
    }));
  }

  function issue(index, type, code, message) {
    return { index: index, stepNumber: index + 1, type: type, code: code, message: message };
  }

  function preflight(rawFunnel, rawAssistants, rawAgents) {
    var funnel = serializeDefinition(rawFunnel);
    var assistants = assistantsCore ? assistantsCore.normalizeStore(rawAssistants).assistants : [];
    var agents = agentsCore ? agentsCore.normalizeStore(rawAgents).agents : [];
    var issues = [];
    funnel.items.forEach(function (step, index) {
      if (step.type === STEP_TYPES.AI_GENERATE) {
        if (!step.assistantId) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.ASSISTANT_REQUIRED, "Selecione um Assistente para a etapa " + (index + 1) + "."));
        if (!text(step.prompt)) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.PROMPT_REQUIRED, "Informe as instruções da etapa " + (index + 1) + "."));
        if (!step.assistantId) return;
        var assistant = assistants.find(function (entry) { return entry.id === step.assistantId; });
        if (!assistant) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.ASSISTANT_NOT_FOUND, "O Assistente da etapa " + (index + 1) + " não foi encontrado."));
        else if (!assistant.enabled) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.ASSISTANT_DISABLED, "O Assistente da etapa " + (index + 1) + " está desativado."));
        else if (!assistant.name || !assistant.providerId) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.ASSISTANT_INVALID, "O Assistente da etapa " + (index + 1) + " está incompleto."));
        return;
      }
      if (step.type !== STEP_TYPES.AI_AGENT) return;
      if (!step.agentId) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.AGENT_REQUIRED, "Selecione um Agente para a etapa " + (index + 1) + "."));
      if (!text(step.task)) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.TASK_REQUIRED, "Informe a tarefa da etapa " + (index + 1) + "."));
      if (!step.agentId) return;
      var agent = agents.find(function (entry) { return entry.id === step.agentId; });
      if (!agent) {
        issues.push(issue(index, step.type, PREFLIGHT_ERRORS.AGENT_NOT_FOUND, "O Agente da etapa " + (index + 1) + " não foi encontrado."));
        return;
      }
      if (!agent.enabled) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.AGENT_DISABLED, "O Agente da etapa " + (index + 1) + " está desativado."));
      if (!agent.name || !agent.objective || !agent.assistantId) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.AGENT_INVALID, "O Agente da etapa " + (index + 1) + " está incompleto."));
      var assistant = assistants.find(function (entry) { return entry.id === agent.assistantId; });
      if (!assistant) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.ASSISTANT_NOT_FOUND, "O Assistente do Agente da etapa " + (index + 1) + " não foi encontrado."));
      else if (!assistant.enabled) issues.push(issue(index, step.type, PREFLIGHT_ERRORS.ASSISTANT_DISABLED, "O Assistente do Agente da etapa " + (index + 1) + " está desativado."));
    });
    return { ok: issues.length === 0, issues: issues };
  }

  function delayToMs(amount, unit) {
    return normalizeDelayAmount(amount) * DELAY_UNIT_MS[normalizeDelayUnit(unit)];
  }

  return Object.freeze({
    STEP_TYPES: STEP_TYPES,
    AI_STEP_TYPES: AI_STEP_TYPES,
    ITEM_STEP_TYPES: ITEM_STEP_TYPES,
    DELAY_UNIT_MS: DELAY_UNIT_MS,
    PREFLIGHT_ERRORS: PREFLIGHT_ERRORS,
    isAiStepType: isAiStepType,
    isItemStepType: isItemStepType,
    createStep: createStep,
    serializeStep: serializeStep,
    serializeDefinition: serializeDefinition,
    duplicateDefinition: duplicateDefinition,
    hasAiSteps: hasAiSteps,
    preflight: preflight,
    delayToMs: delayToMs
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
