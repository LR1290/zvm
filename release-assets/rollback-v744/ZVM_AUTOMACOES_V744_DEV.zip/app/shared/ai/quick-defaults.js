;(function(root){
  "use strict";
  if(root.__extAiQuickDefaults)return;
  var STORE_KEY="EXTUI:aiQuickDefaults",VERSION=1,TRANSCRIPTION_MODELS=["gpt-4o-mini-transcribe","gpt-transcribe","gpt-4o-transcribe"];
  function object(v){return v&&typeof v==="object"&&!Array.isArray(v);}
  function parse(raw){if(typeof raw!=="string")return raw;try{return JSON.parse(raw);}catch(_){return null;}}
  function normalize(raw){raw=parse(raw);raw=object(raw)?raw:{};var provider=["auto","openai","gemini"].indexOf(String(raw.providerId||""))>=0?String(raw.providerId):"auto";var model=TRANSCRIPTION_MODELS.indexOf(String(raw.transcriptionModel||""))>=0?String(raw.transcriptionModel):"gpt-4o-mini-transcribe";return{version:VERSION,providerId:provider,transcriptionModel:model,updatedAt:Number(raw.updatedAt)||0};}
  function ready(meta){return !!(meta&&meta.configured===true&&meta.enabled===true&&meta.status==="connected");}
  function chooseDefaultProvider(providers,preferred){providers=object(providers)?providers:{};preferred=String(preferred||"auto");if((preferred==="openai"||preferred==="gemini")&&ready(providers[preferred]))return preferred;if(ready(providers.openai))return"openai";if(ready(providers.gemini))return"gemini";return"auto";}
  function openAiTranscriptionModel(available,current){var ids=(Array.isArray(available)?available:[]).map(function(item){return typeof item==="string"?item:item&&item.id;}).filter(Boolean);if(TRANSCRIPTION_MODELS.indexOf(String(current||""))>=0&&(!ids.length||ids.indexOf(String(current))>=0))return String(current);for(var i=0;i<TRANSCRIPTION_MODELS.length;i++)if(!ids.length||ids.indexOf(TRANSCRIPTION_MODELS[i])>=0)return TRANSCRIPTION_MODELS[i];return"gpt-4o-mini-transcribe";}
  function label(providerId){return providerId==="openai"?"OpenAI":providerId==="gemini"?"Google Gemini":"Automático";}
  root.__extAiQuickDefaults=Object.freeze({STORE_KEY:STORE_KEY,VERSION:VERSION,TRANSCRIPTION_MODELS:Object.freeze(TRANSCRIPTION_MODELS.slice()),normalize:normalize,ready:ready,chooseDefaultProvider:chooseDefaultProvider,openAiTranscriptionModel:openAiTranscriptionModel,label:label});
})(typeof globalThis!=="undefined"?globalThis:this);
