try{
(function (root, factory) {
  "use strict";
  var assistantsCore = root && root.__extAiAssistantsCore;
  var api = factory(assistantsCore);
  if (root) root.__extAiAgentsCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (assistantsCore) {
  "use strict";

  var STORE_KEY = "EXTUI:aiAgentsStore";
  var SCHEMA_VERSION = 1;
  var MAX_STEPS_OPTIONS = Object.freeze([3, 5, 8]);
  var DEFAULT_MAX_STEPS = 5;
  var HARD_MAX_STEPS = 8;
  var MAX_TOTAL_TOOL_CALLS = 10;
  var COMPLETION_MODE = "structured";
  var ERRORS = Object.freeze({
    NOT_FOUND: "AI_AGENT_NOT_FOUND",
    DISABLED: "AI_AGENT_DISABLED",
    ASSISTANT_INVALID: "AI_AGENT_ASSISTANT_INVALID",
    STEP_LIMIT: "AI_AGENT_STEP_LIMIT_EXCEEDED",
    TOOL_LIMIT: "AI_AGENT_TOOL_LIMIT_EXCEEDED",
    RUNTIME_FAILED: "AI_AGENT_RUNTIME_FAILED",
    MODEL_TOOL_UNSUPPORTED: "AI_AGENT_MODEL_TOOL_UNSUPPORTED",
    CONTROL_REQUIRED: "AI_AGENT_CONTROL_REQUIRED",
    EMPTY_RESPONSE: "AI_AGENT_EMPTY_RESPONSE",
    CANCELLED: "AI_AGENT_CANCELLED",
    INVALID: "AI_AGENT_INVALID"
  });

  function object(value) { return !!value && typeof value === "object" && !Array.isArray(value); }
  function text(value, maxLength) {
    var normalized = typeof value === "string" ? value.trim() : "";
    return maxLength ? normalized.slice(0, maxLength) : normalized;
  }
  function timestamp(value) { return Number.isFinite(Number(value)) ? Number(value) : null; }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function parse(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { return null; }
  }
  function agentError(code, message) { var error = new Error(message); error.code = code; return error; }
  function normalizeMaxSteps(value) {
    var numeric = Number(value);
    return MAX_STEPS_OPTIONS.indexOf(numeric) >= 0 ? numeric : DEFAULT_MAX_STEPS;
  }

  function normalizeAgent(raw) {
    if (!object(raw) || !text(raw.id, 160)) return null;
    return {
      id: text(raw.id, 160),
      name: text(raw.name, 120),
      description: text(raw.description, 500),
      assistantId: text(raw.assistantId, 160) || null,
      objective: text(raw.objective, 6000),
      maxSteps: normalizeMaxSteps(raw.maxSteps),
      completionMode: COMPLETION_MODE,


      useMemory: raw.useMemory !== false,
      useKnowledge: raw.useKnowledge !== false,
      enabled: raw.enabled !== false,
      createdAt: timestamp(raw.createdAt),
      updatedAt: timestamp(raw.updatedAt)
    };
  }

  function normalizeStore(raw) {
    var parsed = parse(raw);
    var source = object(parsed) && object(parsed.state) ? parsed.state : parsed;
    var agents = source && Array.isArray(source.agents) ? source.agents.map(normalizeAgent).filter(Boolean) : [];
    return { version: SCHEMA_VERSION, agents: agents };
  }

  function serializeStore(raw) {
    var store = normalizeStore(raw);
    return JSON.stringify({ state: { agents: store.agents }, version: SCHEMA_VERSION });
  }

  function validateDraft(raw) {
    raw = object(raw) ? raw : {};
    var name = text(raw.name, 120);
    var assistantId = text(raw.assistantId, 160);
    var objective = text(raw.objective, 6000);
    if (!name) throw agentError(ERRORS.INVALID, "Informe um nome para o agente.");
    if (!assistantId) throw agentError(ERRORS.INVALID, "Selecione um Assistente para o agente.");
    if (!objective) throw agentError(ERRORS.INVALID, "Informe o objetivo do agente.");
    return {
      name: name,
      description: text(raw.description, 500),
      assistantId: assistantId,
      objective: objective,
      maxSteps: normalizeMaxSteps(raw.maxSteps),
      completionMode: COMPLETION_MODE,
      useMemory: raw.useMemory !== false,
      useKnowledge: raw.useKnowledge !== false,
      enabled: raw.enabled !== false
    };
  }

  function createAgent(rawStore, draft, dependencies) {
    var store = normalizeStore(rawStore);
    var now = dependencies.now();
    var agent = Object.assign({ id: dependencies.createId() }, validateDraft(draft), { createdAt: now, updatedAt: now });
    store.agents.push(agent);
    return { store: store, agent: clone(agent) };
  }

  function updateAgent(rawStore, agentId, draft, dependencies) {
    var store = normalizeStore(rawStore);
    var index = store.agents.findIndex(function (agent) { return agent.id === agentId; });
    if (index < 0) throw agentError(ERRORS.NOT_FOUND, "Agente não encontrado.");
    var current = store.agents[index];
    var updated = Object.assign({ id: current.id }, validateDraft(draft), { createdAt: current.createdAt, updatedAt: dependencies.now() });
    store.agents[index] = updated;
    return { store: store, agent: clone(updated) };
  }

  function duplicateAgent(rawStore, agentId, dependencies) {
    var store = normalizeStore(rawStore);
    var source = store.agents.find(function (agent) { return agent.id === agentId; });
    if (!source) throw agentError(ERRORS.NOT_FOUND, "Agente não encontrado.");
    return createAgent(store, {
      name: source.name + " — Cópia",
      description: source.description,
      assistantId: source.assistantId,
      objective: source.objective,
      maxSteps: source.maxSteps,
      useMemory: source.useMemory,
      useKnowledge: source.useKnowledge,
      enabled: source.enabled
    }, dependencies);
  }

  function deleteAgent(rawStore, agentId) {
    var store = normalizeStore(rawStore);
    var before = store.agents.length;
    store.agents = store.agents.filter(function (agent) { return agent.id !== agentId; });
    if (store.agents.length === before) throw agentError(ERRORS.NOT_FOUND, "Agente não encontrado.");
    return { store: store, deletedId: agentId };
  }

  function findAssistant(rawAssistants, assistantId) {
    if (!assistantsCore) return null;
    return assistantsCore.normalizeStore(rawAssistants).assistants.find(function (assistant) { return assistant.id === assistantId; }) || null;
  }

  function healthFor(agent, rawAssistants, integrations, providerIds, knowledgeStore) {
    if (!agent || !agent.name || !agent.objective || !agent.assistantId) return { state: "attention", code: ERRORS.INVALID, label: "Configuração incompleta" };
    if (agent.enabled === false) return { state: "disabled", code: null, label: "Desativado" };
    var assistant = findAssistant(rawAssistants, agent.assistantId);
    if (!assistant || !assistantsCore) return { state: "attention", code: ERRORS.ASSISTANT_INVALID, label: "Assistente não encontrado" };
    var assistantHealth = assistantsCore.healthFor(assistant, integrations, providerIds, knowledgeStore);
    if (!assistantHealth || assistantHealth.state !== "ready") return { state: "attention", code: ERRORS.ASSISTANT_INVALID, label: assistantHealth && assistantHealth.label || "Assistente requer atenção" };
    return { state: "ready", code: null, label: "Ativo" };
  }

  function resolveForExecution(rawAgents, rawAssistants, integrations, agentId, providerIds, knowledgeStore) {
    var agent = normalizeStore(rawAgents).agents.find(function (entry) { return entry.id === agentId; });
    if (!agent) throw agentError(ERRORS.NOT_FOUND, "O agente desta etapa não foi encontrado.");
    if (!agent.enabled) throw agentError(ERRORS.DISABLED, "O agente desta etapa está desativado.");
    if (!assistantsCore) throw agentError(ERRORS.ASSISTANT_INVALID, "O Assistente deste agente não está disponível.");
    var assistant;
    try {
      assistant = assistantsCore.resolveForExecution(rawAssistants, integrations, agent.assistantId, providerIds, knowledgeStore);
    } catch (error) {
      throw agentError(ERRORS.ASSISTANT_INVALID, "O Assistente associado a este agente requer atenção.");
    }
    return Object.freeze({
      agentId: agent.id,
      agentName: agent.name,
      description: agent.description,
      objective: agent.objective,
      maxSteps: agent.maxSteps,
      completionMode: COMPLETION_MODE,


      useMemory: agent.useMemory,
      useKnowledge: agent.useKnowledge,
      assistant: assistant
    });
  }

  function countFlowReferences(flows, agentId) {
    return (Array.isArray(flows) ? flows : []).filter(function (flow) {
      return flow && Array.isArray(flow.nodes) && flow.nodes.some(function (node) {
        return node && node.type === "aiAgent" && node.data && node.data.agentId === agentId;
      });
    }).length;
  }

  function serializeAgentNodeData(raw) {
    raw = object(raw) ? raw : {};
    return { agentId: text(raw.agentId, 160) || null, task: typeof raw.task === "string" ? raw.task : "", outputMode: "sendText" };
  }

  function createRepository(dependencies) {
    var queue = Promise.resolve();
    function readFresh() { return Promise.resolve(dependencies.read()).then(normalizeStore); }
    function mutate(operation) {
      var job = queue.catch(function () {}).then(async function () {
        var current = await readFresh();
        var outcome = operation(current);
        await dependencies.write(serializeStore(outcome.store));
        return outcome;
      });
      queue = job.catch(function () {});
      return job;
    }
    var mutationDependencies = { createId: dependencies.createId, now: dependencies.now };
    return Object.freeze({
      get: readFresh,
      create: function (draft) { return mutate(function (store) { return createAgent(store, draft, mutationDependencies); }); },
      update: function (id, draft) { return mutate(function (store) { return updateAgent(store, id, draft, mutationDependencies); }); },
      duplicate: function (id) { return mutate(function (store) { return duplicateAgent(store, id, mutationDependencies); }); },
      remove: function (id) { return mutate(function (store) { return deleteAgent(store, id); }); }
    });
  }

  return Object.freeze({
    STORE_KEY: STORE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    MAX_STEPS_OPTIONS: MAX_STEPS_OPTIONS,
    DEFAULT_MAX_STEPS: DEFAULT_MAX_STEPS,
    HARD_MAX_STEPS: HARD_MAX_STEPS,
    MAX_TOTAL_TOOL_CALLS: MAX_TOTAL_TOOL_CALLS,
    COMPLETION_MODE: COMPLETION_MODE,
    ERRORS: ERRORS,
    normalizeMaxSteps: normalizeMaxSteps,
    normalizeAgent: normalizeAgent,
    normalizeStore: normalizeStore,
    serializeStore: serializeStore,
    validateDraft: validateDraft,
    createAgent: createAgent,
    updateAgent: updateAgent,
    duplicateAgent: duplicateAgent,
    deleteAgent: deleteAgent,
    healthFor: healthFor,
    resolveForExecution: resolveForExecution,
    countFlowReferences: countFlowReferences,
    serializeAgentNodeData: serializeAgentNodeData,
    createRepository: createRepository
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
