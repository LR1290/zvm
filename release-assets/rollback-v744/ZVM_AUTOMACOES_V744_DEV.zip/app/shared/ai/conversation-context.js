;
try{
(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extAiConversationContext = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var MODES = Object.freeze({ NONE: "none", RECENT: "recent" });
  var MESSAGE_COUNTS = Object.freeze([5, 10, 20]);
  var DEFAULT_MESSAGE_COUNT = 5;
  var MESSAGE_MAX_CHARS = 4000;
  var TOTAL_MAX_CHARS = 16000;
  var SCAN_MULTIPLIER = 3;
  var SCAN_MAX_MESSAGES = 60;
  var TRUNCATION_MARKER = "…[conteúdo reduzido]";
  var ERROR_CODE = "AI_CONTEXT_UNAVAILABLE";

  function object(value) { return value && typeof value === "object" && !Array.isArray(value); }
  function cleanText(value) { return typeof value === "string" ? value.trim() : ""; }
  function allowedCount(value) {
    var count = Number(value);
    return MESSAGE_COUNTS.indexOf(count) >= 0 ? count : DEFAULT_MESSAGE_COUNT;
  }
  function normalizeConfig(raw) {
    raw = object(raw) ? raw : {};
    var validRecent = raw.mode === MODES.RECENT && MESSAGE_COUNTS.indexOf(Number(raw.messageCount)) >= 0;
    return {
      mode: validRecent ? MODES.RECENT : MODES.NONE,
      messageCount: validRecent ? Number(raw.messageCount) : DEFAULT_MESSAGE_COUNT
    };
  }
  function scanLimit(messageCount) {
    return Math.min(allowedCount(messageCount) * SCAN_MULTIPLIER, SCAN_MAX_MESSAGES);
  }
  function truncateText(value, limit) {
    var source = cleanText(value);
    var max = Math.max(0, Math.floor(Number(limit) || 0));
    if (source.length <= max) return source;
    if (max <= TRUNCATION_MARKER.length) return source.slice(0, max);
    return source.slice(0, max - TRUNCATION_MARKER.length).trimEnd() + TRUNCATION_MARKER;
  }
  function boundedConversation(raw, messageCount) {
    var count = allowedCount(messageCount);
    var normalized = (Array.isArray(raw) ? raw : []).map(function (entry) {
      if (!object(entry) || (entry.role !== "user" && entry.role !== "assistant")) return null;
      var content = truncateText(entry.text, MESSAGE_MAX_CHARS);
      return content ? { role: entry.role, text: content } : null;
    }).filter(Boolean).slice(-count);
    var remaining = TOTAL_MAX_CHARS;
    var selected = [];
    for (var index = normalized.length - 1; index >= 0 && remaining > 0; index -= 1) {
      var item = normalized[index];
      var content = truncateText(item.text, remaining);
      if (!content) continue;
      selected.push({ role: item.role, text: content });
      remaining -= content.length;
    }
    return selected.reverse();
  }
  function messageTimestamp(message, fallback) {
    var raw = message && (message.t != null ? message.t : message.timestamp);
    return Number.isFinite(Number(raw)) ? Number(raw) : fallback;
  }
  function fromWppMessages(raw, messageCount) {
    var candidates = (Array.isArray(raw) ? raw : []).map(function (message, index) {
      if (!object(message) || message.type !== "chat" || message.isNotification === true || message.isSystemMsg === true) return null;
      var content = cleanText(message.body);
      if (!content) return null;
      return {
        role: message.fromMe === true || message.isSentByMe === true ? "assistant" : "user",
        text: content,
        timestamp: messageTimestamp(message, index),
        index: index
      };
    }).filter(Boolean);
    candidates.sort(function (left, right) {
      return left.timestamp === right.timestamp ? left.index - right.index : left.timestamp - right.timestamp;
    });
    return boundedConversation(candidates.map(function (entry) {
      return { role: entry.role, text: entry.text };
    }), messageCount);
  }
  function contextError() {
    var error = new Error("Não foi possível carregar o contexto recente desta conversa.");
    error.code = ERROR_CODE;
    return error;
  }
  function cancellationError() {
    var error = new Error("A execução foi cancelada.");
    error.code = "ai_cancelled";
    return error;
  }
  async function fetchRecent(options) {
    options = object(options) ? options : {};
    var isCancelled = typeof options.isCancelled === "function" ? options.isCancelled : function () { return false; };
    if (isCancelled()) throw cancellationError();
    if (!cleanText(options.chatId) || typeof options.getMessages !== "function") throw contextError();
    var count = allowedCount(options.messageCount);
    var messages;
    try {
      messages = await options.getMessages(options.chatId, { count: scanLimit(count), direction: "before", id: null });
    } catch (error) {
      if (error && error.code === "ai_cancelled") throw error;
      throw contextError();
    }
    if (isCancelled()) throw cancellationError();
    if (!Array.isArray(messages)) throw contextError();
    return fromWppMessages(messages, count);
  }

  return Object.freeze({
    MODES: MODES,
    MESSAGE_COUNTS: MESSAGE_COUNTS,
    DEFAULT_MESSAGE_COUNT: DEFAULT_MESSAGE_COUNT,
    MESSAGE_MAX_CHARS: MESSAGE_MAX_CHARS,
    TOTAL_MAX_CHARS: TOTAL_MAX_CHARS,
    SCAN_MAX_MESSAGES: SCAN_MAX_MESSAGES,
    ERROR_CODE: ERROR_CODE,
    normalizeConfig: normalizeConfig,
    scanLimit: scanLimit,
    truncateText: truncateText,
    normalizeConversation: boundedConversation,
    fromWppMessages: fromWppMessages,
    fetchRecent: fetchRecent
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
