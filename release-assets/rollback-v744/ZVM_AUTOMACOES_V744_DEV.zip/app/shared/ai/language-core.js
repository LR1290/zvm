(function(root){
  "use strict";
  try{
    if(root.__extAiLanguageCore)return;
    var TRANSLATION_LANGUAGES=Object.freeze([
      Object.freeze({code:"pt-BR",base:"pt",label:"Português (Brasil)"}),
      Object.freeze({code:"en",base:"en",label:"Inglês"}),
      Object.freeze({code:"es",base:"es",label:"Espanhol"}),
      Object.freeze({code:"fr",base:"fr",label:"Francês"}),
      Object.freeze({code:"de",base:"de",label:"Alemão"}),
      Object.freeze({code:"it",base:"it",label:"Italiano"}),
      Object.freeze({code:"ja",base:"ja",label:"Japonês"}),
      Object.freeze({code:"ko",base:"ko",label:"Coreano"}),
      Object.freeze({code:"zh-CN",base:"zh",label:"Chinês simplificado"}),
      Object.freeze({code:"ar",base:"ar",label:"Árabe"})
    ]);
    var TRANSCRIPTION_LANGUAGES=Object.freeze([
      Object.freeze({code:"",label:"Detectar automaticamente — recomendado"}),
      Object.freeze({code:"pt",label:"Português (Brasil)"}),
      Object.freeze({code:"en",label:"Inglês"}),
      Object.freeze({code:"es",label:"Espanhol"}),
      Object.freeze({code:"fr",label:"Francês"}),
      Object.freeze({code:"de",label:"Alemão"}),
      Object.freeze({code:"it",label:"Italiano"})
    ]);
    var byCode=Object.create(null);
    TRANSLATION_LANGUAGES.forEach(function(item){byCode[item.code]=item;});
    function base(code){
      code=String(code||"").trim();
      if(!code)return"";
      var known=byCode[code];
      if(known)return known.base;
      var normalized=code.replace(/_/g,"-").toLowerCase();
      if(normalized==="zh-cn"||normalized.indexOf("zh-")===0)return"zh";
      return normalized.split("-")[0];
    }
    function label(code){var item=byCode[String(code||"")];return item?item.label:String(code||"");}
    function targetSupported(code){return !!byCode[String(code||"")];}
    function detect(text){
      text=String(text||"").trim();
      if(!text)return Promise.resolve({language:"",baseLanguage:"",confidence:0,reliable:false});
      return new Promise(function(resolve){
        var settled=false;
        function finish(result){
          if(settled)return;settled=true;
          var rows=result&&Array.isArray(result.languages)?result.languages.slice():[];
          rows.sort(function(a,b){return Number(b&&b.percentage||0)-Number(a&&a.percentage||0);});
          var best=rows[0]||{},raw=best&&best.language&&best.language!=="und"?String(best.language):"",pct=Number(best&&best.percentage||0);
          if(!Number.isFinite(pct))pct=0;
          var confidence=pct>1?pct/100:pct;
          confidence=Math.max(0,Math.min(1,confidence));
          resolve({language:raw,baseLanguage:base(raw),confidence:confidence,reliable:!!(result&&result.isReliable)&&!!raw});
        }
        try{
          if(root.chrome&&chrome.i18n&&typeof chrome.i18n.detectLanguage==="function"){
            var maybe=chrome.i18n.detectLanguage(text,finish);
            if(maybe&&typeof maybe.then==="function")maybe.then(finish).catch(function(){finish(null);});
            return;
          }
        }catch(_){}
        finish(null);
      });
    }
    async function analyze(text,targetCode,sourceCode){
      text=String(text||"").trim();
      var target=base(targetCode),info;
      if(sourceCode){info={language:String(sourceCode),baseLanguage:base(sourceCode),confidence:1,reliable:true};}
      else info=await detect(text);
      var same=!!(target&&info.baseLanguage&&target===info.baseLanguage);
      var skip=same&&info.reliable&&info.confidence>=0.65&&text.length>=8;
      return Object.freeze({sourceLanguage:info.language,sourceBase:info.baseLanguage,targetLanguage:String(targetCode||""),targetBase:target,confidence:info.confidence,reliable:info.reliable,sameLanguage:same,skipTranslation:skip});
    }
    root.__extAiLanguageCore=Object.freeze({version:"1.0.0",translationLanguages:TRANSLATION_LANGUAGES,transcriptionLanguages:TRANSCRIPTION_LANGUAGES,base:base,label:label,targetSupported:targetSupported,detect:detect,analyze:analyze});
  }catch(error){if(root.__extReportRuntimeError)root.__extReportRuntimeError("AI_LANGUAGE_CORE_BOOT_FAILED",error);}
})(typeof self!=="undefined"?self:globalThis);
