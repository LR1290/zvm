try{
(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extKnowledgeCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var STORE_KEY = "EXTUI:knowledgeBasesStore";
  var SCHEMA_VERSION = 1;
  var DEFAULT_EMBEDDING_MODELS = Object.freeze({ openai: "text-embedding-3-small", gemini: "gemini-embedding-2" });
  var EMBEDDING_DIMENSIONS = 768;
  var STATUSES = Object.freeze({
    EMPTY: "empty", PREPARING: "preparing", INDEXING: "indexing",
    READY: "ready", ATTENTION: "attention", ERROR: "error"
  });
  var JOB_STATES = Object.freeze({
    PREPARING: "preparing", EMBEDDING: "busca inteligente", SAVING: "saving",
    COMPLETE: "complete", FAILED: "failed", CANCELLED: "cancelled"
  });
  var ERRORS = Object.freeze({
    BASE_NOT_FOUND: "KNOWLEDGE_BASE_NOT_FOUND",
    BASE_NOT_READY: "KNOWLEDGE_BASE_NOT_READY",
    PROVIDER_UNAVAILABLE: "KNOWLEDGE_EMBEDDING_PROVIDER_UNAVAILABLE",
    EMBEDDING_FAILED: "KNOWLEDGE_EMBEDDING_FAILED",
    RETRIEVAL_FAILED: "KNOWLEDGE_RETRIEVAL_FAILED",
    INTERRUPTED: "KNOWLEDGE_INDEX_INTERRUPTED",
    LIMIT_EXCEEDED: "KNOWLEDGE_LIMIT_EXCEEDED",
    PDF_NO_TEXT: "KNOWLEDGE_PDF_NO_TEXT",
    CANCELLED: "KNOWLEDGE_CANCELLED"
  });


  var LIMITS = Object.freeze({
    MAX_FILE_BYTES: 5 * 1024 * 1024,
    MAX_DOCUMENTS_PER_BASE: 25,
    MAX_TOTAL_TEXT_CHARS: 1000000,
    MAX_CHUNKS_PER_BASE: 800,
    CHUNK_TARGET_CHARS: 1400,
    CHUNK_MAX_CHARS: 1800,
    CHUNK_OVERLAP_CHARS: 180,
    EMBEDDING_BATCH_SIZE: 32,
    TOP_K: 5,
    MIN_SIMILARITY: 0.2
  });

  function object(value) { return value && typeof value === "object" && !Array.isArray(value); }
  function text(value) { return typeof value === "string" ? value.trim() : ""; }
  function number(value, fallback) { return Number.isFinite(Number(value)) ? Number(value) : fallback; }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function parse(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { return null; }
  }
  function error(code, message) { var result = new Error(message || code); result.code = code; return result; }
  function createUuid(cryptoImpl) {
    var source = cryptoImpl || (typeof crypto !== "undefined" ? crypto : null);
    if (source && typeof source.randomUUID === "function") return source.randomUUID();
    var bytes = new Uint8Array(16);
    if (source && typeof source.getRandomValues === "function") source.getRandomValues(bytes);
    else for (var i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
    bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
    var hex = Array.prototype.map.call(bytes, function (value) { return value.toString(16).padStart(2, "0"); }).join("");
    return hex.slice(0, 8) + "-" + hex.slice(8, 12) + "-" + hex.slice(12, 16) + "-" + hex.slice(16, 20) + "-" + hex.slice(20);
  }
  function embeddingProvider(providerId) { return providerId === "openai" || providerId === "gemini"; }

  function normalizeIndex(raw) {
    if (!object(raw) || !text(raw.revision)) return null;
    var dimensions = Math.floor(number(raw.dimensions, 0));
    if (!embeddingProvider(raw.embeddingProviderId) || !text(raw.embeddingModel) || dimensions < 1) return null;
    return {
      revision: text(raw.revision), embeddingProviderId: raw.embeddingProviderId,
      embeddingModel: text(raw.embeddingModel), dimensions: dimensions,
      chunkCount: Math.max(0, Math.floor(number(raw.chunkCount, 0))), indexedAt: number(raw.indexedAt, null)
    };
  }
  function normalizeJob(raw) {
    if (!object(raw) || !text(raw.jobId)) return null;
    var valid = Object.keys(JOB_STATES).map(function (key) { return JOB_STATES[key]; });
    return {
      jobId: text(raw.jobId), state: valid.indexOf(raw.state) >= 0 ? raw.state : JOB_STATES.PREPARING,
      completed: Math.max(0, Math.floor(number(raw.completed, 0))), total: Math.max(0, Math.floor(number(raw.total, 0))),
      updatedAt: number(raw.updatedAt, null), errorCode: text(raw.errorCode) || null
    };
  }


  function normalizeAgentIdAllowlist(raw) {
    if (!Array.isArray(raw)) return null;
    var seen = {}; var out = [];
    raw.forEach(function (id) {
      var clean = text(id);
      if (clean && !seen[clean]) { seen[clean] = true; out.push(clean); }
    });
    return out;
  }
  function normalizeBase(raw) {
    if (!object(raw) || !text(raw.id)) return null;
    var providerId = embeddingProvider(raw.embeddingProviderId) ? raw.embeddingProviderId : "openai";
    var validStatuses = Object.keys(STATUSES).map(function (key) { return STATUSES[key]; });
    var activeIndex = normalizeIndex(raw.activeIndex);
    return {
      id: text(raw.id), name: text(raw.name), description: text(raw.description),
      allowedAgentIds: normalizeAgentIdAllowlist(raw.allowedAgentIds),
      embeddingProviderId: providerId,
      embeddingModel: text(raw.embeddingModel) || DEFAULT_EMBEDDING_MODELS[providerId],
      status: validStatuses.indexOf(raw.status) >= 0 ? raw.status : (activeIndex ? STATUSES.READY : STATUSES.EMPTY),
      documentCount: Math.max(0, Math.floor(number(raw.documentCount, 0))),
      chunkCount: activeIndex ? activeIndex.chunkCount : Math.max(0, Math.floor(number(raw.chunkCount, 0))),
      pendingChanges: raw.pendingChanges === true,
      activeIndex: activeIndex,
      job: normalizeJob(raw.job),
      lastErrorCode: text(raw.lastErrorCode) || null,
      createdAt: number(raw.createdAt, null), updatedAt: number(raw.updatedAt, null),
      indexedAt: activeIndex && activeIndex.indexedAt || number(raw.indexedAt, null)
    };
  }
  function normalizeStore(raw) {
    var parsed = parse(raw);
    var source = object(parsed) && object(parsed.state) ? parsed.state : parsed;
    var bases = source && Array.isArray(source.bases) ? source.bases.map(normalizeBase).filter(Boolean) : [];
    return { version: SCHEMA_VERSION, bases: bases };
  }
  function serializeStore(raw) {
    var store = normalizeStore(raw);
    return JSON.stringify({ state: { bases: store.bases }, version: SCHEMA_VERSION });
  }
  function validateBaseDraft(raw) {
    raw = object(raw) ? raw : {};
    var providerId = embeddingProvider(raw.embeddingProviderId) ? raw.embeddingProviderId : "";
    if (!text(raw.name)) throw error("KNOWLEDGE_NAME_REQUIRED", "Informe um nome para a Base de Conhecimento.");
    if (!providerId) throw error(ERRORS.PROVIDER_UNAVAILABLE, "Selecione OpenAI ou Google Gemini para preparar a busca da base.");
    return {
      name: text(raw.name).slice(0, 100), description: text(raw.description).slice(0, 300),
      embeddingProviderId: providerId,
      embeddingModel: text(raw.embeddingModel) || DEFAULT_EMBEDDING_MODELS[providerId]
    };
  }
  function createBase(rawStore, draft, dependencies) {
    var store = normalizeStore(rawStore); var data = validateBaseDraft(draft); var now = dependencies.now();
    var base = Object.assign({ id: dependencies.createId() }, data, {
      status: STATUSES.EMPTY, documentCount: 0, chunkCount: 0, pendingChanges: false,
      activeIndex: null, job: null, lastErrorCode: null, createdAt: now, updatedAt: now, indexedAt: null
    });
    store.bases.push(base); return { store: store, base: clone(base) };
  }
  function updateBase(rawStore, baseId, draft, dependencies) {
    var store = normalizeStore(rawStore); var index = store.bases.findIndex(function (base) { return base.id === baseId; });
    if (index < 0) throw error(ERRORS.BASE_NOT_FOUND, "Base de Conhecimento não encontrada.");
    var current = store.bases[index]; var data = validateBaseDraft(draft);
    var embeddingChanged = current.embeddingProviderId !== data.embeddingProviderId || current.embeddingModel !== data.embeddingModel;
    store.bases[index] = Object.assign({}, current, data, {
      pendingChanges: current.pendingChanges || embeddingChanged,
      status: embeddingChanged && current.activeIndex ? STATUSES.ATTENTION : current.status,
      updatedAt: dependencies.now()
    });
    return { store: store, base: clone(store.bases[index]), embeddingChanged: embeddingChanged };
  }


  function setBaseAllowedAgents(rawStore, baseId, allowedAgentIds, dependencies) {
    var store = normalizeStore(rawStore); var index = store.bases.findIndex(function (base) { return base.id === baseId; });
    if (index < 0) throw error(ERRORS.BASE_NOT_FOUND, "Base de Conhecimento não encontrada.");
    store.bases[index] = Object.assign({}, store.bases[index], { allowedAgentIds: normalizeAgentIdAllowlist(allowedAgentIds), updatedAt: dependencies.now() });
    return { store: store, base: clone(store.bases[index]) };
  }
  function findBase(rawStore, baseId) { return normalizeStore(rawStore).bases.find(function (base) { return base.id === baseId; }) || null; }
  function removeBase(rawStore, baseId) {
    var store = normalizeStore(rawStore); var found = findBase(store, baseId);
    if (!found) throw error(ERRORS.BASE_NOT_FOUND, "Base de Conhecimento não encontrada.");
    store.bases = store.bases.filter(function (base) { return base.id !== baseId; });
    return { store: store, base: found };
  }

  function normalizeText(raw) {
    return String(raw == null ? "" : raw).replace(/\0/g, "").replace(/\r\n?/g, "\n")
      .split("\n").map(function (line) { return line.replace(/[\t\f\v ]+/g, " ").trimEnd(); })
      .join("\n").replace(/\n[ \t]+/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function normalizeDocument(raw) {
    if (!object(raw) || !text(raw.id) || !text(raw.baseId)) return null;
    var kind = ["manual", "txt", "md", "pdf"].indexOf(raw.kind) >= 0 ? raw.kind : "manual";
    var pages = kind === "pdf" && Array.isArray(raw.pages) ? raw.pages.map(function (page, index) {
      var pageText = normalizeText(page && page.text);
      return pageText ? { pageNumber: Math.max(1, Math.floor(number(page && page.pageNumber, index + 1))), text: pageText } : null;
    }).filter(Boolean) : [];
    var content = kind === "pdf" ? normalizeText(pages.map(function (page) { return page.text; }).join("\n\n")) : normalizeText(raw.text);
    return {
      id: text(raw.id), baseId: text(raw.baseId), title: text(raw.title).slice(0, 180), kind: kind,
      text: kind === "pdf" ? "" : content, pages: pages,
      charCount: content.length, sizeBytes: Math.max(0, Math.floor(number(raw.sizeBytes, content.length))),
      chunkCount: Math.max(0, Math.floor(number(raw.chunkCount, 0))), status: text(raw.status) || "pending",
      createdAt: number(raw.createdAt, null), updatedAt: number(raw.updatedAt, null)
    };
  }
  function createDocument(baseId, raw, dependencies) {
    raw = object(raw) ? raw : {}; var now = dependencies.now();
    var document = normalizeDocument(Object.assign({}, raw, { id: text(raw.id) || dependencies.createId(), baseId: baseId, createdAt: raw.createdAt || now, updatedAt: now }));
    if (!document || !document.title) throw error("KNOWLEDGE_DOCUMENT_TITLE_REQUIRED", "Informe um título para a fonte.");
    if (!document.charCount) throw error(document.kind === "pdf" ? ERRORS.PDF_NO_TEXT : "KNOWLEDGE_DOCUMENT_EMPTY", document.kind === "pdf" ? "Este PDF não contém texto legível." : "Informe o conteúdo da fonte.");
    if (document.sizeBytes > LIMITS.MAX_FILE_BYTES) throw error(ERRORS.LIMIT_EXCEEDED, "O arquivo excede o limite de 5 MB.");
    return document;
  }
  function validateDocumentLimits(documents) {
    var list = (Array.isArray(documents) ? documents : []).map(normalizeDocument).filter(Boolean);
    if (list.length > LIMITS.MAX_DOCUMENTS_PER_BASE) throw error(ERRORS.LIMIT_EXCEEDED, "A base aceita até 25 documentos na V1.");
    var totalChars = list.reduce(function (total, document) { return total + document.charCount; }, 0);
    if (totalChars > LIMITS.MAX_TOTAL_TEXT_CHARS) throw error(ERRORS.LIMIT_EXCEEDED, "A base excede o limite de 1.000.000 de caracteres.");
    return { documents: list, totalChars: totalChars };
  }

  function hardSplit(value, maximum) {
    var result = []; var remaining = value;
    while (remaining.length > maximum) {
      var boundary = Math.max(1, remaining.lastIndexOf(" ", maximum));
      result.push(remaining.slice(0, boundary).trim()); remaining = remaining.slice(boundary).trim();
    }
    if (remaining) result.push(remaining); return result;
  }
  function overlapTail(value) {
    if (value.length <= LIMITS.CHUNK_OVERLAP_CHARS) return value;
    var start = value.length - LIMITS.CHUNK_OVERLAP_CHARS;
    var boundary = value.indexOf(" ", start);
    return value.slice(boundary >= 0 ? boundary + 1 : start).trim();
  }
  function chunkText(raw) {
    var normalized = normalizeText(raw); if (!normalized) return [];
    var blocks = normalized.split(/\n{2,}/).reduce(function (result, block) {
      return result.concat(hardSplit(block.trim(), LIMITS.CHUNK_MAX_CHARS));
    }, []).filter(Boolean);
    var chunks = []; var current = "";
    function commit() { if (current) { chunks.push(current); current = ""; } }
    blocks.forEach(function (block) {
      var candidate = current ? current + "\n\n" + block : block;
      if (candidate.length <= LIMITS.CHUNK_TARGET_CHARS || !current) { current = candidate; return; }
      var previous = current; commit(); var overlap = overlapTail(previous);
      current = overlap && overlap !== block ? overlap + "\n\n" + block : block;
      if (current.length > LIMITS.CHUNK_MAX_CHARS) {
        var split = hardSplit(current, LIMITS.CHUNK_MAX_CHARS);
        split.slice(0, -1).forEach(function (part) { chunks.push(part); }); current = split[split.length - 1] || "";
      }
    });
    commit(); return chunks;
  }
  function chunkDocuments(documents, revision, dependencies) {
    var checked = validateDocumentLimits(documents); var chunks = [];
    checked.documents.forEach(function (document) {
      var sources = document.kind === "pdf" ? document.pages : [{ pageNumber: null, text: document.text }];
      sources.forEach(function (source) {
        chunkText(source.text).forEach(function (chunkValue) {
          chunks.push({
            id: dependencies.createId(), knowledgeBaseId: document.baseId, indexRevision: revision,
            documentId: document.id, sourceTitle: document.title,
            pageNumber: source.pageNumber || null, ordinal: chunks.length, text: chunkValue, vector: null
          });
        });
      });
    });
    if (chunks.length > LIMITS.MAX_CHUNKS_PER_BASE) throw error(ERRORS.LIMIT_EXCEEDED, "A base excede o limite de 800 trechos.");
    return chunks;
  }

  function normalizeVector(raw) {
    if (!Array.isArray(raw) || !raw.length) return null;
    var vector = raw.map(Number);
    return vector.every(Number.isFinite) ? vector : null;
  }
  function validateVectors(vectors, expectedCount, expectedDimensions) {
    if (!Array.isArray(vectors) || vectors.length !== expectedCount) throw error(ERRORS.EMBEDDING_FAILED, "O serviço retornou uma quantidade inesperada de dados para a busca.");
    var dimensions = 0;
    var normalized = vectors.map(function (raw) {
      var vector = normalizeVector(raw);
      if (!vector) throw error(ERRORS.EMBEDDING_FAILED, "O serviço retornou dados inválidos para a busca.");
      if (!dimensions) dimensions = vector.length;
      if (vector.length !== dimensions || (expectedDimensions && vector.length !== expectedDimensions)) throw error(ERRORS.EMBEDDING_FAILED, "Os dados recebidos para a busca são incompatíveis.");
      return vector;
    });
    return { vectors: normalized, dimensions: dimensions };
  }
  function cosineSimilarity(left, right) {
    var a = normalizeVector(left); var b = normalizeVector(right);
    if (!a || !b || a.length !== b.length) throw error(ERRORS.RETRIEVAL_FAILED, "Não foi possível comparar vetores incompatíveis.");
    var dot = 0, normA = 0, normB = 0;
    for (var i = 0; i < a.length; i++) { dot += a[i] * b[i]; normA += a[i] * a[i]; normB += b[i] * b[i]; }
    return normA && normB ? dot / (Math.sqrt(normA) * Math.sqrt(normB)) : 0;
  }
  function retrieve(chunks, queryVector, options) {
    options = object(options) ? options : {};
    var topK = Math.max(1, Math.min(10, Math.floor(number(options.topK, LIMITS.TOP_K))));
    var threshold = number(options.minSimilarity, LIMITS.MIN_SIMILARITY);
    return (Array.isArray(chunks) ? chunks : []).map(function (chunk) {
      var score = cosineSimilarity(queryVector, chunk.vector);
      return score >= threshold ? { chunk: chunk, score: score } : null;
    }).filter(Boolean).sort(function (a, b) { return b.score - a.score || a.chunk.ordinal - b.chunk.ordinal; }).slice(0, topK);
  }
  function sanitizeRetrieved(results) {
    return (Array.isArray(results) ? results : []).map(function (entry) {
      var source = entry && entry.chunk ? entry.chunk : entry;
      var clean = { sourceTitle: text(source && source.sourceTitle), text: normalizeText(source && source.text) };
      if (Number.isFinite(Number(source && source.pageNumber))) clean.pageNumber = Math.max(1, Math.floor(Number(source.pageNumber)));
      return clean.sourceTitle && clean.text ? clean : null;
    }).filter(Boolean);
  }
  function normalizeRuntimeKnowledge(raw) { return sanitizeRetrieved(raw).slice(0, LIMITS.TOP_K); }
  function assistantKnowledge(raw) { return { mode: raw && raw.mode === "base" && text(raw.baseId) ? "base" : "none", baseId: raw && raw.mode === "base" && text(raw.baseId) ? text(raw.baseId) : null }; }
  function isBaseReady(base) { return !!(base && base.activeIndex && base.activeIndex.revision && base.activeIndex.dimensions > 0); }

  return Object.freeze({
    STORE_KEY: STORE_KEY, SCHEMA_VERSION: SCHEMA_VERSION, DEFAULT_EMBEDDING_MODELS: DEFAULT_EMBEDDING_MODELS,
    EMBEDDING_DIMENSIONS: EMBEDDING_DIMENSIONS, STATUSES: STATUSES, JOB_STATES: JOB_STATES, ERRORS: ERRORS, LIMITS: LIMITS,
    createUuid: createUuid, embeddingProvider: embeddingProvider, normalizeStore: normalizeStore, serializeStore: serializeStore,
    normalizeBase: normalizeBase, validateBaseDraft: validateBaseDraft, createBase: createBase, updateBase: updateBase,
    findBase: findBase, removeBase: removeBase, setBaseAllowedAgents: setBaseAllowedAgents, normalizeText: normalizeText, normalizeDocument: normalizeDocument,
    createDocument: createDocument, validateDocumentLimits: validateDocumentLimits, chunkText: chunkText,
    chunkDocuments: chunkDocuments, validateVectors: validateVectors, cosineSimilarity: cosineSimilarity,
    retrieve: retrieve, sanitizeRetrieved: sanitizeRetrieved, normalizeRuntimeKnowledge: normalizeRuntimeKnowledge,
    assistantKnowledge: assistantKnowledge, isBaseReady: isBaseReady, error: error, clone: clone
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
