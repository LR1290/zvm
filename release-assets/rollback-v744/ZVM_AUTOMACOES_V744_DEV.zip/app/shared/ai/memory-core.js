try{
(function (root, factory) {
  "use strict";
  var api = factory(root);
  if (root) root.__extAiMemoryCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";

  var STORE_KEY = "EXTUI:aiMemoryStore";
  var SCHEMA_VERSION = 2;
  var MAX_ENTRIES_PER_SUBJECT = 20;
  var MAX_ENTRY_CHARS = 500;
  var RUNTIME_MAX_CHARS = 6000;
  var TRUNCATION_MARKER = "…[conteúdo reduzido]";
  var CATEGORIES = Object.freeze(["preference", "interest", "requirement", "context"]);
  var CATEGORY_LABELS = Object.freeze({ preference: "Preferência", interest: "Interesse", requirement: "Requisito", context: "Contexto" });
  var ERRORS = Object.freeze({
    SUBJECT_UNAVAILABLE: "MEMORY_UNAVAILABLE_FOR_CONTACT",
    INVALID_SUBJECT: "AI_MEMORY_INVALID_SUBJECT",
    INVALID_ENTRY: "AI_MEMORY_INVALID_ENTRY",
    INVALID_CATEGORY: "AI_MEMORY_INVALID_CATEGORY",
    ENTRY_TOO_LONG: "AI_MEMORY_ENTRY_TOO_LONG",
    LIMIT_REACHED: "AI_MEMORY_LIMIT_REACHED",
    ENTRY_NOT_FOUND: "AI_MEMORY_ENTRY_NOT_FOUND"
  });

  function object(value) { return value && typeof value === "object" && !Array.isArray(value); }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function cleanText(value) { return typeof value === "string" ? value.trim() : ""; }
  function timestamp(value) { return Number.isFinite(Number(value)) ? Number(value) : null; }
  function memoryError(code, message) { var error = new Error(message); error.code = code; return error; }
  function parse(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { return null; }
  }
  function validSubjectKey(value) { return typeof value === "string" && /^sha256:[a-f0-9]{64}$/.test(value); }
  function requireSubjectKey(value) {
    if (!validSubjectKey(value)) throw memoryError(ERRORS.INVALID_SUBJECT, "A identidade deste cliente não está disponível.");
    return value;
  }
  function normalizePhone(raw) {
    if (typeof raw !== "string" && typeof raw !== "number") return null;
    var source = String(raw).trim().toLowerCase();
    if (!source || source.indexOf("@lid") >= 0 || source.indexOf("@g.us") >= 0) return null;
    if (source.indexOf("@") >= 0 && source.indexOf("@c.us") < 0) return null;
    var digits = source.replace(/\D/g, "");
    return digits.length >= 8 && digits.length <= 15 ? digits : null;
  }
  async function deriveSubjectKey(rawPhone, dependencies) {
    var canonical = normalizePhone(rawPhone);
    if (!canonical) return null;
    dependencies = object(dependencies) ? dependencies : {};
    var subtle = dependencies.subtle || root && root.crypto && root.crypto.subtle;
    var Encoder = dependencies.TextEncoder || root && root.TextEncoder;
    if (!subtle || typeof subtle.digest !== "function" || typeof Encoder !== "function") return null;
    try {
      var digest = await subtle.digest("SHA-256", new Encoder().encode("ext:customer:" + canonical));
      var hex = Array.from(new Uint8Array(digest)).map(function (value) { return value.toString(16).padStart(2, "0"); }).join("");
      return "sha256:" + hex;
    } catch (error) { return null; }
  }
  function normalizeAgentIdAllowlist(raw) {
    if (!Array.isArray(raw)) return null;
    var seen = {}; var out = [];
    raw.forEach(function (id) {
      var clean = cleanText(id).slice(0, 160);
      if (clean && !seen[clean]) { seen[clean] = true; out.push(clean); }
    });
    return out;
  }
  function memoryEntryAllowedForAgent(entry, agentId) {
    if (!agentId) return true;
    var allowlist = entry && entry.allowedAgentIds;
    return !Array.isArray(allowlist) || allowlist.indexOf(agentId) !== -1;
  }
  function normalizeEntry(raw) {
    if (!object(raw) || !cleanText(raw.id) || CATEGORIES.indexOf(raw.category) < 0) return null;
    var entryText = cleanText(raw.text);
    if (!entryText) return null;
    return {
      id: cleanText(raw.id).slice(0, 120),
      category: raw.category,
      text: entryText.slice(0, MAX_ENTRY_CHARS),


      allowedAgentIds: normalizeAgentIdAllowlist(raw.allowedAgentIds),
      createdAt: timestamp(raw.createdAt),
      updatedAt: timestamp(raw.updatedAt)
    };
  }
  function normalizeStore(raw) {
    var parsed = parse(raw);
    var source = object(parsed) && object(parsed.state) ? parsed.state : parsed;
    var subjects = {};
    var rawSubjects = source && object(source.subjects) ? source.subjects : {};
    Object.keys(rawSubjects).forEach(function (subjectKey) {
      if (!validSubjectKey(subjectKey)) return;
      var rawSubject = rawSubjects[subjectKey];
      var entries = rawSubject && Array.isArray(rawSubject.entries) ? rawSubject.entries.map(normalizeEntry).filter(Boolean).slice(0, MAX_ENTRIES_PER_SUBJECT) : [];
      if (!entries.length) return;
      subjects[subjectKey] = { entries: entries, updatedAt: timestamp(rawSubject.updatedAt) };
    });
    return { version: SCHEMA_VERSION, revision: Math.max(0, Math.floor(Number(source && source.revision) || 0)), subjects: subjects };
  }
  function serializeStore(raw) {
    var store = normalizeStore(raw);
    return JSON.stringify({ state: { revision: store.revision, subjects: store.subjects }, version: SCHEMA_VERSION });
  }
  function validateDraft(raw) {
    raw = object(raw) ? raw : {};
    if (CATEGORIES.indexOf(raw.category) < 0) throw memoryError(ERRORS.INVALID_CATEGORY, "Selecione um tipo de memória válido.");
    var value = cleanText(raw.text);
    if (!value) throw memoryError(ERRORS.INVALID_ENTRY, "Informe a memória do cliente.");
    if (value.length > MAX_ENTRY_CHARS) throw memoryError(ERRORS.ENTRY_TOO_LONG, "A memória pode ter no máximo 500 caracteres.");
    return { category: raw.category, text: value, allowedAgentIds: normalizeAgentIdAllowlist(raw.allowedAgentIds) };
  }
  function listForSubject(rawStore, subjectKey) {
    var store = normalizeStore(rawStore);
    if (!validSubjectKey(subjectKey) || !store.subjects[subjectKey]) return [];
    return clone(store.subjects[subjectKey].entries).sort(function (left, right) { return (right.updatedAt || 0) - (left.updatedAt || 0); });
  }
  function add(rawStore, subjectKey, draft, dependencies) {
    var store = normalizeStore(rawStore);
    requireSubjectKey(subjectKey);
    var data = validateDraft(draft);
    var subject = store.subjects[subjectKey] || { entries: [], updatedAt: null };
    if (subject.entries.length >= MAX_ENTRIES_PER_SUBJECT) throw memoryError(ERRORS.LIMIT_REACHED, "Este cliente já possui o limite de 20 memórias.");
    var now = dependencies.now();
    var entry = { id: cleanText(dependencies.createId()), category: data.category, text: data.text, allowedAgentIds: data.allowedAgentIds, createdAt: now, updatedAt: now };
    if (!entry.id) throw memoryError(ERRORS.INVALID_ENTRY, "Não foi possível criar a memória.");
    subject.entries.push(entry); subject.updatedAt = now; store.subjects[subjectKey] = subject; store.revision += 1;
    return { store: store, entry: clone(entry) };
  }
  function update(rawStore, subjectKey, entryId, draft, dependencies) {
    var store = normalizeStore(rawStore); requireSubjectKey(subjectKey); var data = validateDraft(draft);
    var subject = store.subjects[subjectKey];
    var index = subject && subject.entries.findIndex(function (entry) { return entry.id === entryId; });
    if (index == null || index < 0) throw memoryError(ERRORS.ENTRY_NOT_FOUND, "Memória não encontrada.");
    var current = subject.entries[index]; var now = dependencies.now();
    var entry = {
      id: current.id, category: data.category, text: data.text,
      allowedAgentIds: Object.prototype.hasOwnProperty.call(draft || {}, "allowedAgentIds") ? data.allowedAgentIds : current.allowedAgentIds,
      createdAt: current.createdAt, updatedAt: now
    };
    subject.entries[index] = entry; subject.updatedAt = now; store.revision += 1;
    return { store: store, entry: clone(entry) };
  }
  function remove(rawStore, subjectKey, entryId) {
    var store = normalizeStore(rawStore); requireSubjectKey(subjectKey); var subject = store.subjects[subjectKey];
    var before = subject && subject.entries.length || 0;
    if (!before) throw memoryError(ERRORS.ENTRY_NOT_FOUND, "Memória não encontrada.");
    subject.entries = subject.entries.filter(function (entry) { return entry.id !== entryId; });
    if (subject.entries.length === before) throw memoryError(ERRORS.ENTRY_NOT_FOUND, "Memória não encontrada.");
    if (subject.entries.length) subject.updatedAt = Math.max.apply(null, subject.entries.map(function (entry) { return entry.updatedAt || 0; }));
    else delete store.subjects[subjectKey];
    store.revision += 1; return { store: store, deletedId: entryId };
  }
  function clearSubject(rawStore, subjectKey) {
    var store = normalizeStore(rawStore); requireSubjectKey(subjectKey);
    var removed = store.subjects[subjectKey] ? store.subjects[subjectKey].entries.length : 0;
    delete store.subjects[subjectKey]; if (removed) store.revision += 1;
    return { store: store, removed: removed };
  }
  function clearAll(rawStore) {
    var store = normalizeStore(rawStore);
    var removed = Object.keys(store.subjects).reduce(function (sum, key) { return sum + store.subjects[key].entries.length; }, 0);
    store.subjects = {}; if (removed) store.revision += 1;
    return { store: store, removed: removed };
  }
  function normalizeRuntimeMemory(raw, agentId) {
    var entries = (Array.isArray(raw) ? raw : []).map(normalizeEntry).filter(Boolean).filter(function (entry) {
      return memoryEntryAllowedForAgent(entry, agentId);
    }).map(function (entry) {
      return { category: entry.category, text: entry.text, updatedAt: timestamp(entry.updatedAt) || 0 };
    }).sort(function (left, right) { return right.updatedAt - left.updatedAt; }).slice(0, MAX_ENTRIES_PER_SUBJECT);
    var remaining = RUNTIME_MAX_CHARS;
    var output = [];
    entries.forEach(function (entry) {
      if (remaining <= 0) return;
      var value = entry.text;
      if (value.length > remaining) {
        value = remaining > TRUNCATION_MARKER.length ? value.slice(0, remaining - TRUNCATION_MARKER.length).trimEnd() + TRUNCATION_MARKER : value.slice(0, remaining);
      }
      if (value) output.push({ category: entry.category, text: value });
      remaining -= value.length;
    });
    return output;
  }
  function createRepository(dependencies) {
    var queue = Promise.resolve();
    function readFresh() { return Promise.resolve(dependencies.read()).then(normalizeStore); }
    function mutate(operation) {
      var job = queue.catch(function () {}).then(async function () {
        var current = await readFresh(); var outcome = operation(current);
        await dependencies.write(serializeStore(outcome.store)); return outcome;
      });
      queue = job.catch(function () {}); return job;
    }
    var mutationDependencies = { createId: dependencies.createId, now: dependencies.now };
    return Object.freeze({
      get: readFresh,
      listForSubject: async function (key) { return listForSubject(await readFresh(), key); },
      add: function (key, draft) { return mutate(function (store) { return add(store, key, draft, mutationDependencies); }); },
      update: function (key, entryId, draft) { return mutate(function (store) { return update(store, key, entryId, draft, mutationDependencies); }); },
      remove: function (key, entryId) { return mutate(function (store) { return remove(store, key, entryId); }); },
      clearSubject: function (key) { return mutate(function (store) { return clearSubject(store, key); }); },
      clearAll: function () { return mutate(clearAll); }
    });
  }

  return Object.freeze({
    STORE_KEY: STORE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    MAX_ENTRIES_PER_SUBJECT: MAX_ENTRIES_PER_SUBJECT,
    MAX_ENTRY_CHARS: MAX_ENTRY_CHARS,
    RUNTIME_MAX_CHARS: RUNTIME_MAX_CHARS,
    CATEGORIES: CATEGORIES,
    CATEGORY_LABELS: CATEGORY_LABELS,
    ERRORS: ERRORS,
    normalizePhone: normalizePhone,
    deriveSubjectKey: deriveSubjectKey,
    normalizeEntry: normalizeEntry,
    normalizeAgentIdAllowlist: normalizeAgentIdAllowlist,
    memoryEntryAllowedForAgent: memoryEntryAllowedForAgent,
    normalizeStore: normalizeStore,
    serializeStore: serializeStore,
    validateDraft: validateDraft,
    listForSubject: listForSubject,
    add: add,
    update: update,
    remove: remove,
    clearSubject: clearSubject,
    clearAll: clearAll,
    normalizeRuntimeMemory: normalizeRuntimeMemory,
    createRepository: createRepository
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
