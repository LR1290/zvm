(function(root){
  "use strict";
  var COLORS=Object.freeze({
    emerald:"#10b981",lime:"#84cc16",teal:"#14b8a6",cyan:"#06b6d4",
    blue:"#3b82f6",indigo:"#6366f1",violet:"#8b5cf6",fuchsia:"#d946ef",
    rose:"#f43f5e",amber:"#f59e0b",orange:"#f97316",slate:"#64748b"
  });
  var SECTIONS=Object.freeze({
    home:COLORS.cyan,academy:COLORS.emerald,"meta-oficial":COLORS.blue,core:COLORS.emerald,atividades:COLORS.amber,
    disparos:COLORS.fuchsia,"itens-message":COLORS.teal,"quick-responses":COLORS.lime,
    fluxos:COLORS.cyan,funis:COLORS.violet,agenda:COLORS.amber,followup:COLORS.indigo,laboratorio:COLORS.emerald,"ai-connect":COLORS.violet,
    crm:COLORS.blue,encomendas:COLORS.amber,delivery:COLORS.orange,salvar:COLORS.emerald,
    integracoes:COLORS.cyan,segredos:COLORS.fuchsia,personalizacao:COLORS.violet,ajustes:COLORS.indigo,backup:COLORS.emerald,trash:COLORS.slate
  });
  var SIDEBAR=Object.freeze({
    items:SECTIONS["itens-message"],crm:SECTIONS.crm,"crm-funnel":COLORS.violet,orders:SECTIONS.encomendas,delivery:SECTIONS.delivery,
    activity:SECTIONS.atividades,broadcast:SECTIONS.disparos,flow:SECTIONS.fluxos,funnel:SECTIONS.funis,"quick-response":SECTIONS["quick-responses"],
    followup:SECTIONS.followup,"auto-service":COLORS.cyan,status:COLORS.emerald,export:SECTIONS.salvar,agenda:SECTIONS.agenda,
    notes:COLORS.indigo,reminder:COLORS.amber,"google-calendar":COLORS.blue,signature:COLORS.violet,"text-assistant":COLORS.fuchsia,
    "text-replace":COLORS.cyan,google:COLORS.blue,webhooks:COLORS.teal,integrations:SECTIONS.integracoes,actions:COLORS.orange,
    notifications:COLORS.rose,tools:COLORS.amber,system:SECTIONS.ajustes,"theme-toggle":COLORS.violet,"rail-toggle":COLORS.teal,dashboard:SECTIONS.home
  });
  function section(name,fallback){ return SECTIONS[String(name||"")]||fallback||COLORS.teal; }
  function sidebar(key,fallback){ return SIDEBAR[String(key||"")]||fallback||COLORS.teal; }
  root.ExtensionSectionPalette=Object.freeze({colors:COLORS,sections:SECTIONS,sidebarItems:SIDEBAR,forSection:section,forSidebarKey:sidebar});
})(typeof window!=="undefined"?window:self);
