(function(g){
"use strict";
if(g.ExtensionAudioCodec&&g.ExtensionAudioCodec.version==="2.1.0")return;
var MIME="audio/ogg";
var WORKER_PATH="vendor/audio-codec/encoderWorker.umd.js";
var WASM_PATH="vendor/audio-codec/OggOpusEncoder.wasm";
var CACHE=new Map();
function runtimeUrl(path){
  if(g.chrome&&chrome.runtime&&typeof chrome.runtime.getURL==="function")return chrome.runtime.getURL(path);
  throw new Error("A extensão não conseguiu iniciar o preparo de áudio.");
}
function clamp(n,min,max){return Math.max(min,Math.min(max,n));}
function bytesToDataUrl(bytes,mime){
  var CH=32768,s="";
  for(var i=0;i<bytes.length;i+=CH)s+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(bytes.length,i+CH)));
  return "data:"+(mime||MIME)+";base64,"+btoa(s);
}
function dataUrlToBytes(dataUrl){
  var m=/^data:([^;,]+)?(?:;[^,]*)?;base64,(.*)$/i.exec(String(dataUrl||""));
  if(!m)throw new Error("Áudio armazenado em formato inválido.");
  var bin=atob(m[2]),out=new Uint8Array(bin.length);
  for(var i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);
  return {bytes:out,mimeType:(m[1]||"").toLowerCase()};
}
function asciiAt(bytes,offset,text){
  if(!bytes||offset<0||offset+text.length>bytes.length)return false;
  for(var i=0;i<text.length;i++)if(bytes[offset+i]!==text.charCodeAt(i))return false;
  return true;
}
function findAscii(bytes,text,limit){
  var max=Math.min(bytes.length-text.length,limit==null?bytes.length:limit);
  for(var i=0;i<=max;i++)if(asciiAt(bytes,i,text))return i;
  return -1;
}
function inspectBytes(bytes){
  var ogg=asciiAt(bytes,0,"OggS");
  var opus=ogg&&findAscii(bytes,"OpusHead",4096)>=0;
  var tags=ogg&&findAscii(bytes,"OpusTags",8192)>=0;
  return {isOgg:ogg,isOpus:!!opus,hasTags:!!tags,compatible:!!(ogg&&opus)};
}
function inspectDataUrl(dataUrl){
  try{var p=dataUrlToBytes(dataUrl),i=inspectBytes(p.bytes);i.mimeType=p.mimeType;i.sizeBytes=p.bytes.length;return i;}catch(e){return {isOgg:false,isOpus:false,hasTags:false,compatible:false,mimeType:"",sizeBytes:0,error:e&&e.message?e.message:String(e)};}
}
function baseName(name){
  var s=String(name||"audio").replace(/[\\/:*?"<>|]+/g,"_").replace(/\.[^.]+$/,"").trim();
  return (s||"audio")+".ogg";
}
function cacheKey(dataUrl){
  var s=String(dataUrl||"");
  return s.length+":"+s.slice(0,96)+":"+s.slice(-96);
}
function blobToDataUrl(blob){
  return new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(String(r.result||""));};r.onerror=function(){reject(r.error||new Error("Falha ao ler o áudio convertido."));};r.readAsDataURL(blob);});
}
function dataUrlToBlob(dataUrl){
  var p=dataUrlToBytes(dataUrl);
  return new Blob([p.bytes],{type:p.mimeType||"application/octet-stream"});
}
async function inputToBlob(input){
  if(input instanceof Blob)return input;
  if(input instanceof ArrayBuffer)return new Blob([input],{type:"application/octet-stream"});
  if(ArrayBuffer.isView(input))return new Blob([input.buffer.slice(input.byteOffset,input.byteOffset+input.byteLength)],{type:"application/octet-stream"});
  if(typeof input==="string"&&/^data:/i.test(input))return dataUrlToBlob(input);
  throw new Error("Entrada de áudio não suportada.");
}
async function decodeMono(blob,progress){
  var size=Number(blob.size||0);
  if(size>80*1024*1024)throw new Error("O áudio excede 80 MB e não pode ser convertido com segurança no navegador.");
  if(progress)progress({stage:"decode",percent:8,label:"Decodificando áudio"});
  var arr=await blob.arrayBuffer();
  var AC=g.AudioContext||g.webkitAudioContext;
  if(!AC)throw new Error("Web Audio indisponível neste navegador.");
  var ctx=new AC();
  try{
    var audio;
    try{audio=await ctx.decodeAudioData(arr.slice(0));}catch(decodeErr){throw new Error("Este arquivo de áudio não pôde ser aberto pelo navegador. Tente outro formato de áudio.");}
    if(!audio||!audio.length||!audio.sampleRate)throw new Error("O navegador não conseguiu decodificar este áudio.");
    if(audio.duration>45*60)throw new Error("Áudios acima de 45 minutos não são convertidos automaticamente por segurança.");
    var mono=new Float32Array(audio.length),channels=Math.max(1,audio.numberOfChannels||1);
    for(var c=0;c<channels;c++){
      var ch=audio.getChannelData(c),gain=1/channels;
      for(var i=0;i<mono.length;i++)mono[i]+=ch[i]*gain;
    }
    return {samples:mono,sampleRate:audio.sampleRate,durationMs:Math.round(audio.duration*1000),sourceChannels:channels};
  }finally{try{await ctx.close();}catch(e){}}
}
async function createEncoderWorker(){
  var url=runtimeUrl(WORKER_PATH);
  if(typeof location!=="undefined"&&location.protocol==="chrome-extension:")return new Worker(url);
  var controller=typeof AbortController!=="undefined"?new AbortController():null,timer=controller?setTimeout(function(){controller.abort();},8000):0,response;
  try{var options={method:"GET",credentials:"omit",cache:"no-store",redirect:"error"};if(controller)options.signal=controller.signal;response=await fetch(url,options);}finally{if(timer)clearTimeout(timer);}
  if(!response.ok)throw new Error("Não foi possível carregar o encoder de áudio da extensão.");
  var declared=Number(response.headers&&response.headers.get&&response.headers.get("content-length")||0);if(declared&&declared>2*1024*1024)throw new Error("O encoder de áudio excedeu o limite seguro.");
  var source=await response.text();if((typeof TextEncoder!=="undefined"?new TextEncoder().encode(source).byteLength:source.length)>2*1024*1024)throw new Error("O encoder de áudio excedeu o limite seguro.");var blobUrl=URL.createObjectURL(new Blob([source],{type:"text/javascript"}));
  try{var worker=new Worker(blobUrl);worker.__extBlobUrl=blobUrl;return worker;}catch(e){URL.revokeObjectURL(blobUrl);throw e;}
}
function disposeWorker(worker){
  if(!worker)return;
  try{worker.terminate();}catch(e){}
  if(worker.__extBlobUrl)try{URL.revokeObjectURL(worker.__extBlobUrl);}catch(e){}
}
async function encodeMono(decoded,opts){
  opts=opts||{};
  var worker=await createEncoderWorker();
  return new Promise(function(resolve,reject){
    var done=false,timeoutMs=clamp(Math.round((decoded.durationMs||0)*0.35)+15000,20000,180000),timer;
    function finishError(err){if(done)return;done=true;clearTimeout(timer);disposeWorker(worker);reject(err instanceof Error?err:new Error(String(err||"Não foi possível preparar o áudio para o WhatsApp.")));}
    function finishOk(buffers){
      if(done)return;
      done=true;clearTimeout(timer);disposeWorker(worker);
      try{
        var total=0,i;for(i=0;i<buffers.length;i++)total+=buffers[i].byteLength;
        var bytes=new Uint8Array(total),off=0;for(i=0;i<buffers.length;i++){var u=new Uint8Array(buffers[i]);bytes.set(u,off);off+=u.byteLength;}
        var check=inspectBytes(bytes);if(!check.compatible)throw new Error("O áudio preparado não ficou em um formato válido para o WhatsApp.");
        resolve(bytes);
      }catch(e){reject(e);}
    }
    timer=setTimeout(function(){finishError(new Error("Tempo limite excedido ao converter áudio."));},timeoutMs);
    worker.onerror=function(ev){finishError(new Error(ev&&ev.message?ev.message:"Falha no worker de áudio."));};
    worker.onmessage=function(ev){
      var d=ev.data||{};
      if(d.command==="readyToInit"){
        var bitrate=clamp(Number(opts.bitrate||32000),16000,64000);
        worker.postMessage({command:"init",sampleRate:decoded.sampleRate,channelCount:1,bitsPerSecond:bitrate});
        var samples=decoded.samples,chunkFrames=32768,totalChunks=Math.max(1,Math.ceil(samples.length/chunkFrames)),sent=0;
        function pump(){
          if(done)return;
          var burst=0;
          while(sent<totalChunks&&burst<8){
            var start=sent*chunkFrames,end=Math.min(samples.length,start+chunkFrames),part=samples.slice(start,end);
            worker.postMessage({command:"pushInputData",channelBuffers:[part],length:part.length,duration:part.length/decoded.sampleRate},[part.buffer]);
            sent++;burst++;
          }
          if(opts.onProgress)opts.onProgress({stage:"encode",percent:10+Math.round(82*sent/totalChunks),label:"Preparando áudio para o WhatsApp"});
          if(sent<totalChunks)setTimeout(pump,0);else worker.postMessage({command:"done"});
        }
        pump();
      }else if(d.command==="lastEncodedData")finishOk(Array.isArray(d.buffers)?d.buffers:[]);
    };
    worker.postMessage({command:"loadEncoder",mimeType:MIME,wasmPath:runtimeUrl(WASM_PATH)});
  });
}
async function validateDecode(blob){
  var AC=g.AudioContext||g.webkitAudioContext;
  if(!AC)return {ok:true,durationMs:0};
  var ctx=new AC();
  try{
    var ab=await blob.arrayBuffer(),decoded=await ctx.decodeAudioData(ab.slice(0));
    if(!decoded||!decoded.duration||!isFinite(decoded.duration))throw new Error("O áudio convertido não pôde ser validado.");
    return {ok:true,durationMs:Math.round(decoded.duration*1000),sampleRate:decoded.sampleRate,channels:decoded.numberOfChannels};
  }finally{try{await ctx.close();}catch(e){}}
}
async function normalizeBlob(input,opts){
  opts=opts||{};
  var blob=await inputToBlob(input),originalName=opts.fileName||(input&&input.name)||"audio",sourceMimeType=String(blob.type||opts.mimeType||"").toLowerCase();
  var head=new Uint8Array(await blob.slice(0,8192).arrayBuffer()),initial=inspectBytes(head);
  if(initial.compatible&&!opts.force){
    var passUrl=opts.returnDataUrl===false?null:(typeof input==="string"?input:await blobToDataUrl(blob));
    return {dataUrl:passUrl,blob:blob,mimeType:MIME,fileName:baseName(originalName),sizeBytes:blob.size,durationMs:0,converted:false,compatible:true,sourceMimeType:sourceMimeType||MIME,codec:"opus",container:"ogg",version:2};
  }
  var decoded=await decodeMono(blob,opts.onProgress),bytes=await encodeMono(decoded,{bitrate:opts.bitrate,onProgress:opts.onProgress});
  var outBlob=new Blob([bytes],{type:MIME}),validated=opts.skipDecodeValidation?{durationMs:decoded.durationMs}:await validateDecode(outBlob);
  if(opts.onProgress)opts.onProgress({stage:"done",percent:100,label:"Áudio compatível pronto"});
  return {dataUrl:opts.returnDataUrl===false?null:bytesToDataUrl(bytes,MIME),blob:outBlob,mimeType:MIME,fileName:baseName(originalName),sizeBytes:bytes.byteLength,durationMs:validated.durationMs||decoded.durationMs,converted:true,compatible:true,sourceMimeType:sourceMimeType||"application/octet-stream",sourceChannels:decoded.sourceChannels,codec:"opus",container:"ogg",version:2};
}
async function normalizeDataUrl(dataUrl,opts){
  opts=opts||{};
  var info=inspectDataUrl(dataUrl);
  if(info.compatible&&!opts.force)return {dataUrl:dataUrl,blob:dataUrlToBlob(dataUrl),mimeType:MIME,fileName:baseName(opts.fileName||"audio"),sizeBytes:info.sizeBytes,durationMs:0,converted:false,compatible:true,sourceMimeType:info.mimeType||MIME,codec:"opus",container:"ogg",version:2};
  var key=cacheKey(dataUrl);
  if(!opts.force&&CACHE.has(key))return CACHE.get(key);
  var promise=normalizeBlob(dataUrl,opts).catch(function(err){CACHE.delete(key);throw err;});
  CACHE.set(key,promise);
  return promise;
}
async function normalizeFile(file,opts){opts=Object.assign({},opts||{},{fileName:(opts&&opts.fileName)||file.name,mimeType:(opts&&opts.mimeType)||file.type});return normalizeBlob(file,opts);}
function supportsInput(file){var n=String(file&&file.name||""),t=String(file&&file.type||"");return /^audio\//i.test(t)||/\.(mp3|wav|m4a|aac|ogg|opus|flac|weba|webm)$/i.test(n);}
g.ExtensionAudioCodec=Object.freeze({version:"2.1.0",mimeType:MIME,inspectBytes:inspectBytes,inspectDataUrl:inspectDataUrl,isCompatibleDataUrl:function(v){return inspectDataUrl(v).compatible;},normalizeBlob:normalizeBlob,normalizeDataUrl:normalizeDataUrl,normalizeFile:normalizeFile,supportsInput:supportsInput,blobToDataUrl:blobToDataUrl,dataUrlToBlob:dataUrlToBlob});
})(typeof globalThis!=="undefined"?globalThis:window);
