;(function(root){
  "use strict";
  if(root.__extSenderPolicy)return;
  function runtimeId(){try{return String(root.chrome&&root.chrome.runtime&&root.chrome.runtime.id||"");}catch(_){return"";}}
  function own(sender){var id=runtimeId();return !!(sender&&id&&sender.id===id);}
  function parsedUrl(value){try{if(typeof value!=="string")return null;var raw=value.trim();if(!raw||raw==="null")return null;return new URL(raw);}catch(_){return null;}}
  function isWhatsAppUrl(value){var u=parsedUrl(value);return !!(u&&u.protocol==="https:"&&u.hostname==="web.whatsapp.com"&&(!u.port||u.port==="443"));}
  function isExtensionUrl(value){try{if(!value||!root.chrome||!root.chrome.runtime)return false;var base=root.chrome.runtime.getURL("");return String(value).indexOf(base)===0;}catch(_){return false;}}
  function urls(sender){if(!sender)return[];return[sender.origin,sender.url,sender.documentUrl,sender.tab&&sender.tab.url,sender.tab&&sender.tab.pendingUrl].filter(function(v){return typeof v==="string"&&v.trim()&&v.trim()!=="null";});}
  function extensionPage(sender){return own(sender)&&urls(sender).some(isExtensionUrl);}
  function whatsApp(sender){
    if(!own(sender)||!sender.tab||!Number.isInteger(sender.tab.id))return false;
    if(typeof sender.frameId==="number"&&sender.frameId!==0)return false;
    var values=urls(sender),absolute=values.map(parsedUrl).filter(Boolean);
    if(absolute.some(function(u){return (u.protocol==="http:"||u.protocol==="https:")&&!isWhatsAppUrl(u.href);}))return false;
    return absolute.some(function(u){return isWhatsAppUrl(u.href);});
  }
  function canRuntime(sender){return extensionPage(sender)||whatsApp(sender);}
  root.__extSenderPolicy=Object.freeze({isOwn:own,isWhatsAppUrl:isWhatsAppUrl,isExtensionUrl:isExtensionUrl,isExtensionPage:extensionPage,isWhatsApp:whatsApp,canRuntime:canRuntime});
})(typeof globalThis!=="undefined"?globalThis:this);
