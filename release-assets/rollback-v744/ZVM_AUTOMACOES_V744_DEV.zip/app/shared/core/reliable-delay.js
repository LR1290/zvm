;
try{
(function(){
  "use strict";
  if(window.__extReliableDelay)return;
  var MAX_CHUNK_MS=20000,seq=0;
  function abortError(){var err=new Error("Espera cancelada.");err.name="AbortError";return err;}
  function waitChunk(ms,signal){return new Promise(function(resolve,reject){if(signal&&signal.aborted){reject(abortError());return;}var settled=false,requestId="delay-"+Date.now().toString(36)+"-"+(++seq).toString(36);function finish(err){if(settled)return;settled=true;if(signal&&signal.removeEventListener)signal.removeEventListener("abort",onAbort);if(err)reject(err);else resolve();}function onAbort(){finish(abortError());}if(signal&&signal.addEventListener)signal.addEventListener("abort",onAbort,{once:true});try{chrome.runtime.sendMessage({type:"EXTUI_RELIABLE_DELAY_WAIT",requestId:requestId,delayMs:ms},function(response){if(settled)return;var runtimeError=chrome.runtime&&chrome.runtime.lastError;if(runtimeError){finish(new Error(runtimeError.message||"Temporizador confiável indisponível."));return;}if(!response||response.ok!==true||response.requestId!==requestId){finish(new Error("Temporizador confiável não confirmou a espera."));return;}finish();});}catch(err){finish(err);}});}
  async function wait(ms,signal){var remaining=Math.max(0,Number(ms)||0);while(remaining>0){if(signal&&signal.aborted)throw abortError();var chunk=Math.min(MAX_CHUNK_MS,remaining);await waitChunk(chunk,signal);remaining-=chunk;}}
  window.__extReliableDelay=Object.freeze({wait:wait});
})();
}catch(_extuiReliableDelayError){if(window.__extRecordBootError)window.__extRecordBootError(_extuiReliableDelayError);}
