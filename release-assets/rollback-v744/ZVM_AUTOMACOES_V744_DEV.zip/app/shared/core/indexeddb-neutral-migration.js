(function(root){
  "use strict";
  if(root.__extIdbNeutralMigration)return;
  function requestResult(request){return new Promise(function(resolve,reject){request.onsuccess=function(){resolve(request.result);};request.onerror=function(){reject(request.error||new Error("Falha ao acessar IndexedDB"));};});}
  function transactionDone(tx){return new Promise(function(resolve,reject){tx.oncomplete=function(){resolve(true);};tx.onerror=function(){reject(tx.error||new Error("Falha na transação IndexedDB"));};tx.onabort=function(){reject(tx.error||new Error("Transação IndexedDB cancelada"));};});}
  async function listNames(idb){if(!idb||typeof idb.databases!=="function")return[];var rows=await idb.databases();return(rows||[]).map(function(row){return String(row&&row.name||"");}).filter(Boolean);}
  function openExisting(idb,name){return new Promise(function(resolve,reject){var request;try{request=idb.open(name);}catch(err){reject(err);return;}request.onsuccess=function(){resolve(request.result);};request.onerror=function(){reject(request.error||new Error("Falha ao abrir armazenamento existente"));};request.onblocked=function(){reject(new Error("Armazenamento existente bloqueado"));};});}
  function openTarget(idb,name,version,upgrade){return new Promise(function(resolve,reject){var request;try{request=idb.open(name,version);}catch(err){reject(err);return;}request.onupgradeneeded=function(){if(typeof upgrade==="function")upgrade(request.result,request.transaction);};request.onsuccess=function(){resolve(request.result);};request.onerror=function(){reject(request.error||new Error("Falha ao abrir armazenamento de destino"));};request.onblocked=function(){reject(new Error("Armazenamento de destino bloqueado"));};});}
  async function readOne(db,storeName,key){var tx=db.transaction(storeName,"readonly"),done=transactionDone(tx),value=await requestResult(tx.objectStore(storeName).get(key));await done;return value;}
  async function keysOf(db,storeName){var tx=db.transaction(storeName,"readonly"),done=transactionDone(tx),keys=await requestResult(tx.objectStore(storeName).getAllKeys());await done;return Array.isArray(keys)?keys:[];}
  async function putOne(db,storeName,key,value){var tx=db.transaction(storeName,"readwrite"),done=transactionDone(tx),store=tx.objectStore(storeName);if(store.keyPath==null)store.put(value,key);else store.put(value);await done;}
  function deleteDb(idb,name){return new Promise(function(resolve,reject){var request;try{request=idb.deleteDatabase(name);}catch(err){reject(err);return;}request.onsuccess=function(){resolve(true);};request.onerror=function(){reject(request.error||new Error("Falha ao remover armazenamento histórico"));};request.onblocked=function(){reject(new Error("Armazenamento histórico bloqueado"));};});}
  function sameJson(a,b){if(a===b)return true;try{return JSON.stringify(a)===JSON.stringify(b);}catch(_){return false;}}
  async function migrate(options){
    options=options||{};var idb=options.indexedDB,sourceName=String(options.sourceName||""),targetName=String(options.targetName||"");
    if(!idb||!sourceName||!targetName||sourceName===targetName)return{migrated:false,reason:"invalid"};
    var names=await listNames(idb),targetExisted=names.indexOf(targetName)>=0;
    if(targetExisted&&options.allowExistingTarget===false)return{migrated:false,reason:"target-exists",sourceRetained:true};
    var source=null,target=null,copied=0,verified=0;
    try{
      source=await openExisting(idb,sourceName);
      if(typeof options.probe==="function"&&!await options.probe(source))return{migrated:false,reason:"shape-mismatch",sourceRetained:true};
      target=await openTarget(idb,targetName,Number(options.version)||1,options.upgrade);
      var stores=Array.isArray(options.stores)?options.stores:[];
      for(var i=0;i<stores.length;i++){
        var spec=stores[i]||{},storeName=String(spec.name||"");if(!storeName||!source.objectStoreNames.contains(storeName)||!target.objectStoreNames.contains(storeName))throw new Error("Estrutura de armazenamento incompatível");
        var keys=await keysOf(source,storeName);
        for(var k=0;k<keys.length;k++){
          var key=keys[k],sourceValue=await readOne(source,storeName,key),targetValue=await readOne(target,storeName,key);
          if(targetValue===undefined){await putOne(target,storeName,key,sourceValue);copied++;continue;}
          var compare=typeof spec.compare==="function"?spec.compare:sameJson;
          if(!compare(sourceValue,targetValue,key)){var conflict=new Error("Conflito ao neutralizar armazenamento histórico");conflict.code="IDB_NEUTRALIZATION_CONFLICT";throw conflict;}
        }
      }
      for(var j=0;j<stores.length;j++){
        var check=stores[j]||{},name=String(check.name||""),sourceKeys=await keysOf(source,name),cmp=typeof check.compare==="function"?check.compare:sameJson;
        for(var q=0;q<sourceKeys.length;q++){
          var checkKey=sourceKeys[q],a=await readOne(source,name,checkKey),b=await readOne(target,name,checkKey);
          if(b===undefined||!cmp(a,b,checkKey)){var verifyError=new Error("A neutralização do armazenamento não pôde ser verificada");verifyError.code="IDB_NEUTRALIZATION_VERIFY_FAILED";throw verifyError;}verified++;
        }
      }
      try{source.close();}catch(_){}source=null;try{target.close();}catch(_){}target=null;
      await deleteDb(idb,sourceName);
      return{migrated:true,copied:copied,verified:verified,targetExisted:targetExisted,sourceRemoved:true};
    }finally{try{if(source)source.close();}catch(_){}try{if(target)target.close();}catch(_){}}
  }
  root.__extIdbNeutralMigration=Object.freeze({migrate:migrate,listNames:listNames,sameJson:sameJson});
})(typeof globalThis!=="undefined"?globalThis:this);
