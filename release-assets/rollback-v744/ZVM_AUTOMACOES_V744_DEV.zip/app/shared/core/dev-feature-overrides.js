;(function(root){
  'use strict';
  var core=root.ExtensionCore=root.ExtensionCore||{};
  var KEY='EXTUI:devFeatureOverridesSession';
  var MESSAGE='EXTUI_DEV_FEATURE_OVERRIDES';
  var OFFICIAL_DEV_ID='ckbffcbmanboelbihfkhiahgafnimcho';
  var cache=Object.create(null),authorized=false,readyPromise=null;

  function safeId(value){return String(value==null?'':value).trim().slice(0,120);}
  function sanitize(raw){
    var out=Object.create(null);
    if(!raw||typeof raw!=='object')return out;
    Object.keys(raw).forEach(function(key){var id=safeId(key),value=String(raw[key]||'');if(id&&value==='active')out[id]='active';});
    return out;
  }
  function snapshot(){var out={};Object.keys(cache).forEach(function(key){out[key]=cache[key];});return Object.freeze(out);}
  function isAuthorizedDescriptor(identity,integrity,runtimeId){
    var att=integrity&&integrity.devAttestation,d=att&&att.descriptor,runtime=String(runtimeId||'').toLowerCase();
    if(!identity||!integrity||integrity.ok!==true||runtime!==OFFICIAL_DEV_ID)return false;
    if(identity.schema!==1||identity.channel!=='dev'||identity.profile!=='dev'||identity.securityProtocol!==2)return false;
    if(!att||typeof att!=='object'||att.schema!==1||att.algorithm!=='Ed25519'||!String(att.keyId||'').trim()||!String(att.signature||'').trim())return false;
    if(!d||typeof d!=='object'||d.schema!==1||d.securityProtocol!==2)return false;
    if(String(d.buildId||'')!==String(identity.buildId||'')||String(d.channel||'')!=='dev'||String(d.profile||'')!=='dev')return false;
    if(String(d.extensionVersion||'')!==String(identity.extensionVersion||'')||String(d.extensionId||'').toLowerCase()!==runtime)return false;
    if(String(d.sourceTreeSha256||'').toLowerCase()!==String(identity.sourceTreeSha256||'').toLowerCase())return false;
    if(String(d.buildFingerprint||'').toLowerCase()!==String(integrity.buildFingerprint||'').toLowerCase())return false;
    if(Number(d.protectedFiles)!==Number(integrity.fileCount))return false;
    return !!String(identity.extensionVersion||'').trim();
  }
  function publish(next,auth){
    cache=sanitize(next);authorized=auth===true;
    try{if(root.dispatchEvent&&typeof root.CustomEvent==='function')root.dispatchEvent(new root.CustomEvent('EXTUI_DEV_FEATURE_OVERRIDES_CHANGED',{detail:{authorized:authorized,overrides:snapshot()}}));}catch(_){}
    return snapshot();
  }
  function isWorker(){return typeof root.document==='undefined';}
  function sameExtensionSender(sender){try{return !!(sender&&sender.id&&root.chrome&&root.chrome.runtime&&sender.id===root.chrome.runtime.id);}catch(_){return false;}}
  async function workerAuthorized(){
    if(!root.chrome||!root.chrome.runtime||String(root.chrome.runtime.id||'').toLowerCase()!==OFFICIAL_DEV_ID)return false;
    var requireIntegrity=typeof root.extIntegrityRequire==='function'?root.extIntegrityRequire:(typeof extIntegrityRequire==='function'?extIntegrityRequire:null);
    var readIdentity=typeof root.extBuildIdentityRead==='function'?root.extBuildIdentityRead:(typeof extBuildIdentityRead==='function'?extBuildIdentityRead:null);
    if(typeof requireIntegrity!=='function'||typeof readIdentity!=='function')return false;
    try{
      var integrity=await requireIntegrity();
      var identity=await readIdentity();
      return isAuthorizedDescriptor(identity,integrity,root.chrome.runtime.id);
    }catch(_){return false;}
  }
  async function sessionGet(){
    if(!root.chrome||!root.chrome.storage||!root.chrome.storage.session||typeof root.chrome.storage.session.get!=='function')return {};
    var data=await root.chrome.storage.session.get(KEY);return sanitize(data&&data[KEY]);
  }
  async function sessionSet(values){
    if(!root.chrome||!root.chrome.storage||!root.chrome.storage.session||typeof root.chrome.storage.session.set!=='function')throw new Error('DEV_FEATURE_OVERRIDE_SESSION_UNAVAILABLE');
    var patch={};patch[KEY]=sanitize(values);await root.chrome.storage.session.set(patch);return patch[KEY];
  }
  async function handleWorkerAction(message,sender){
    if(!sameExtensionSender(sender))return {ok:false,code:'UNAUTHORIZED_SENDER'};
    if(!await workerAuthorized())return {ok:false,code:'DEV_FEATURE_OVERRIDE_UNAVAILABLE'};
    var current=await sessionGet(),action=String(message&&message.action||'');
    if(action==='list')return {ok:true,authorized:true,overrides:current};
    if(action==='set'){
      var id=safeId(message.featureId),availability=core.FeatureAvailability;
      if(!id||!availability||typeof availability.get!=='function'||!availability.get(id))return {ok:false,code:'DEV_FEATURE_ID_INVALID'};
      current[id]='active';return {ok:true,authorized:true,overrides:await sessionSet(current)};
    }
    if(action==='clear'){
      var clearId=safeId(message.featureId);if(clearId)delete current[clearId];return {ok:true,authorized:true,overrides:await sessionSet(current)};
    }
    if(action==='reset')return {ok:true,authorized:true,overrides:await sessionSet({})};
    return {ok:false,code:'DEV_FEATURE_OVERRIDE_ACTION_INVALID'};
  }
  if(isWorker()&&root.chrome&&root.chrome.runtime&&root.chrome.runtime.onMessage&&typeof root.chrome.runtime.onMessage.addListener==='function'){
    root.chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
      if(!message||message.type!==MESSAGE)return false;
      Promise.resolve(handleWorkerAction(message,sender)).then(sendResponse,function(error){sendResponse({ok:false,code:error&&error.code||'DEV_FEATURE_OVERRIDE_ERROR',error:error&&error.message||String(error)});});
      return true;
    });
  }
  function request(action,featureId){
    if(isWorker())return handleWorkerAction({type:MESSAGE,action:action,featureId:featureId},{id:root.chrome&&root.chrome.runtime&&root.chrome.runtime.id});
    return new Promise(function(resolve,reject){
      try{
        if(!root.chrome||!root.chrome.runtime||typeof root.chrome.runtime.sendMessage!=='function'){reject(new Error('DEV_FEATURE_OVERRIDE_UNAVAILABLE'));return;}
        root.chrome.runtime.sendMessage({type:MESSAGE,action:action,featureId:featureId},function(response){
          var last=root.chrome.runtime.lastError;if(last){reject(new Error(last.message));return;}
          if(!response||response.ok!==true){var err=new Error(response&&response.code||'DEV_FEATURE_OVERRIDE_UNAVAILABLE');err.code=response&&response.code||'DEV_FEATURE_OVERRIDE_UNAVAILABLE';reject(err);return;}
          resolve(response);
        });
      }catch(error){reject(error);}
    });
  }
  function applyResponse(response){return publish(response&&response.overrides,response&&response.authorized===true);}
  function ready(){
    if(readyPromise)return readyPromise;
    readyPromise=request('list').then(function(response){applyResponse(response);return true;},function(){publish({},false);return false;});
    return readyPromise;
  }
  function setActive(featureId){return request('set',safeId(featureId)).then(function(response){applyResponse(response);return snapshot();});}
  function clear(featureId){return request('clear',safeId(featureId)).then(function(response){applyResponse(response);return snapshot();});}
  function reset(){return request('reset').then(function(response){applyResponse(response);return snapshot();});}
  function getOverride(featureId){return authorized&&cache[safeId(featureId)]==='active'?'active':null;}
  function list(){return snapshot();}
  function isAuthorizedDev(){return authorized===true;}
  core.DevFeatureOverrides=Object.freeze({
    schema:1,key:KEY,messageType:MESSAGE,officialDevExtensionId:OFFICIAL_DEV_ID,
    ready:ready,list:list,getOverride:getOverride,setActive:setActive,clear:clear,reset:reset,isAuthorizedDev:isAuthorizedDev,isAuthorizedDescriptor:isAuthorizedDescriptor
  });
})(typeof globalThis!=='undefined'?globalThis:this);
