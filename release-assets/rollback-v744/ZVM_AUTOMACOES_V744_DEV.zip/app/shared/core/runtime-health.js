;(function(root){
  "use strict";
  if(root.__extRuntimeHealth&&root.__extRecordBootError&&root.__extReportRuntimeError)return;
  var bootErrors=[],runtimeErrors=[],runtimeIndex=Object.create(null),correlationTrace=[],MAX_BOOT=20,MAX_RUNTIME=48,MAX_TRACE=128;
  function cleanCode(value){var code=String(value||"RUNTIME_FAILURE").toUpperCase().replace(/[^A-Z0-9_.:-]+/g,"_").replace(/^_+|_+$/g,"");return(code||"RUNTIME_FAILURE").slice(0,96);}
  function errorName(err){return String(err&&err.name||"Error").replace(/[^A-Za-z0-9_.:-]+/g,"_").slice(0,64)||"Error";}
  function safeMessage(err){var value=String(err&&err.message||err||"");value=value.replace(/https?:\/\/[^\s]+/gi,"[url]").replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,"[email]").replace(/\+?\d[\d\s().-]{6,}\d/g,"[number]").replace(/(?:^|[\s:=])(?:[A-F0-9]{32,})(?=$|[\s,;.])/gi," [token]");return value.slice(0,180);}
  function recordBoot(err){try{if(bootErrors.length>=MAX_BOOT)return;bootErrors.push(Object.freeze({at:Date.now(),name:errorName(err),message:safeMessage(err)}));}catch(_){}}

  var TRACE_FIELDS={activityId:1,executionId:1,sourceColumnEventId:1,crmEventId:1,requestId:1,source:1,trigger:1,provider:1,model:1,status:1,action:1,ack:1,errorCode:1};
  function traceScalar(value,max){if(value==null)return undefined;if(typeof value==="boolean")return value;if(typeof value==="number")return Number.isFinite(value)?value:undefined;return String(value).replace(/[^A-Za-z0-9_.:@-]+/g,"_").slice(0,max||160);}
  function trace(kind,detail){try{var row={at:Date.now(),kind:traceScalar(kind,80)||"runtime"};detail=detail&&typeof detail==="object"?detail:{};Object.keys(detail).forEach(function(key){if(!TRACE_FIELDS[key])return;var value=traceScalar(detail[key],key==="model"?120:180);if(value!==undefined&&value!=="")row[key]=value;});correlationTrace.push(Object.freeze(row));if(correlationTrace.length>MAX_TRACE)correlationTrace.splice(0,correlationTrace.length-MAX_TRACE);return row;}catch(_){return null;}}
  function report(code,err){try{code=cleanCode(code);var now=Date.now(),entry=runtimeIndex[code];if(entry){entry.count++;entry.lastAt=now;entry.lastErrorName=errorName(err);return;}entry={code:code,count:1,firstAt:now,lastAt:now,lastErrorName:errorName(err)};runtimeIndex[code]=entry;runtimeErrors.push(entry);if(runtimeErrors.length>MAX_RUNTIME){var removed=runtimeErrors.shift();if(removed)delete runtimeIndex[removed.code];}}catch(_){}}
  var api=Object.freeze({version:"1.1.0-correlation",getBootErrors:function(){return bootErrors.slice();},getRuntimeErrors:function(){return runtimeErrors.map(function(x){return Object.freeze({code:x.code,count:x.count,firstAt:x.firstAt,lastAt:x.lastAt,lastErrorName:x.lastErrorName});});},getRuntimeErrorSummary:function(){var total=0;runtimeErrors.forEach(function(x){total+=x.count;});return Object.freeze({codes:runtimeErrors.length,total:total});},getCorrelationTrace:function(){return correlationTrace.slice();},getCorrelationTraceSummary:function(){var byKind={};correlationTrace.forEach(function(row){byKind[row.kind]=(byKind[row.kind]||0)+1;});return Object.freeze({total:correlationTrace.length,byKind:Object.freeze(byKind)});}});
  if(!root.__extRuntimeHealth)Object.defineProperty(root,"__extRuntimeHealth",{value:api,enumerable:false,configurable:false,writable:false});
  if(!root.__extRecordBootError)Object.defineProperty(root,"__extRecordBootError",{value:recordBoot,enumerable:false,configurable:false,writable:false});
  if(!root.__extReportRuntimeError)Object.defineProperty(root,"__extReportRuntimeError",{value:report,enumerable:false,configurable:false,writable:false});
  if(!root.__extTraceRuntime)Object.defineProperty(root,"__extTraceRuntime",{value:trace,enumerable:false,configurable:false,writable:false});
})(globalThis);
