(function(root){
  "use strict";
  if(root.__extRuntimeConfig)return;
  var FIXED_BACKEND_SUFFIX=".onrender.com";
  function manifest(){try{return root.chrome&&chrome.runtime&&typeof chrome.runtime.getManifest==="function"?chrome.runtime.getManifest():null;}catch(_){return null;}}
  function parsePermissionOrigin(pattern){
    try{
      var value=String(pattern||"");
      if(value.slice(-2)==="/*")value=value.slice(0,-2)+"/";
      var url=new URL(value);
      if(url.protocol!=="https:"||!url.hostname||url.hostname.indexOf("*")>=0)return null;
      return url.origin;
    }catch(_){return null;}
  }
  function backendOrigin(){
    var m=manifest(),list=m&&Array.isArray(m.host_permissions)?m.host_permissions:[],matches=[];
    for(var i=0;i<list.length;i++){
      var origin=parsePermissionOrigin(list[i]);
      if(!origin)continue;
      try{var host=new URL(origin).hostname.toLowerCase();if(host.slice(-FIXED_BACKEND_SUFFIX.length)===FIXED_BACKEND_SUFFIX)matches.push(origin);}catch(_){}
    }
    matches=Array.from(new Set(matches));
    if(matches.length!==1)throw new Error("BACKEND_ORIGIN_CONFIGURATION_INVALID");
    return matches[0];
  }
  function backendUrl(path){
    var value=String(path||"");
    if(!value.startsWith("/")||value.startsWith("//"))throw new Error("BACKEND_PATH_INVALID");
    return backendOrigin()+value;
  }
  function permissionPattern(value){
    var url=value instanceof URL?value:new URL(String(value||""));
    if(url.protocol!=="https:"||!url.hostname||url.username||url.password||url.hostname.indexOf("*")>=0)throw new Error("HOST_PERMISSION_PATTERN_INVALID");
    return "https://"+url.hostname+"/*";
  }
  root.__extRuntimeConfig=Object.freeze({backendOrigin:backendOrigin,backendUrl:backendUrl,permissionPattern:permissionPattern});
})(typeof globalThis!=="undefined"?globalThis:this);
