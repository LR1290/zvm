try{
(function (root) {
  "use strict";
  if (root.__extStorageServiceBooted) return;
  root.__extStorageServiceBooted = true;

  var MAX_KEYS = 256;
  var LOCAL_ECHO_TTL_MS = 10000;
  var LOCAL_ECHO_MAX_PER_KEY = 16;
  var subscribers = new Map();
  var schema = root.__extStorageSchema || null;
  var localWriteEchoes = new Map();
  var expectedLocalEchoes = new Map();
  var expectedLocalEchoSeq = 0;
  var contextId = (function () {
    try { if (root.crypto && typeof root.crypto.randomUUID === "function") return root.crypto.randomUUID(); } catch (_) {}
    return "storage-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
  })();

  function valueFingerprint(value) {
    if (value === undefined) return "undefined";
    try { return "json:" + JSON.stringify(value); } catch (_) { return "text:" + String(value); }
  }
  function pruneLocalQueue(key, nowMs) {
    var queue = localWriteEchoes.get(key);
    if (!queue || !queue.length) return null;
    nowMs = Number(nowMs) || Date.now();
    queue = queue.filter(function (entry) { return entry && entry.expiresAt > nowMs; });
    if (!queue.length) { localWriteEchoes.delete(key); return null; }
    if (queue.length > LOCAL_ECHO_MAX_PER_KEY) queue = queue.slice(queue.length - LOCAL_ECHO_MAX_PER_KEY);
    localWriteEchoes.set(key, queue);
    return queue;
  }
  function markLocalValue(key, value) {
    if (!safeKey(key)) return;
    var nowMs = Date.now(), queue = pruneLocalQueue(key, nowMs);
    if (!queue) { queue = []; localWriteEchoes.set(key, queue); }
    queue.push({ fingerprint: valueFingerprint(value), expiresAt: nowMs + LOCAL_ECHO_TTL_MS });
    if (queue.length > LOCAL_ECHO_MAX_PER_KEY) queue.splice(0, queue.length - LOCAL_ECHO_MAX_PER_KEY);
  }
  function markLocalValues(values) {
    values = values && typeof values === "object" ? values : {};
    Object.keys(values).filter(safeKey).slice(0, MAX_KEYS).forEach(function (key) { markLocalValue(key, values[key]); });
  }
  function markLocalRemovals(keys) { safeKeys(keys).forEach(function (key) { markLocalValue(key, undefined); }); }
  function discardLatestLocalKeys(keys) {
    safeKeys(keys).forEach(function (key) {
      var queue = pruneLocalQueue(key, Date.now());
      if (!queue || !queue.length) return;
      queue.pop();
      if (!queue.length) localWriteEchoes.delete(key);
    });
  }
  function consumeLocalKey(key, newValue) {
    var queue = pruneLocalQueue(key, Date.now());
    if (!queue || !queue.length) return false;
    var fingerprint = valueFingerprint(newValue), index = queue.findIndex(function (entry) { return entry.fingerprint === fingerprint; });
    if (index < 0) return false;
    queue.splice(index, 1);
    if (!queue.length) localWriteEchoes.delete(key);
    return true;
  }


  function pruneExpectedLocalQueue(key, nowMs) {
    var queue = expectedLocalEchoes.get(key);
    if (!queue || !queue.length) return null;
    nowMs = Number(nowMs) || Date.now();
    queue = queue.filter(function (entry) { return entry && entry.active !== false && entry.expiresAt > nowMs; });
    if (!queue.length) { expectedLocalEchoes.delete(key); return null; }
    if (queue.length > LOCAL_ECHO_MAX_PER_KEY) queue = queue.slice(queue.length - LOCAL_ECHO_MAX_PER_KEY);
    expectedLocalEchoes.set(key, queue);
    return queue;
  }
  function consumeExpectedLocalKey(key) {
    var queue = pruneExpectedLocalQueue(key, Date.now());
    if (!queue || !queue.length) return false;
    var entry = queue.shift();
    if (entry) entry.active = false;
    if (queue.length) expectedLocalEchoes.set(key, queue); else expectedLocalEchoes.delete(key);
    return true;
  }
  function expectLocalEcho(keys, ttlMs) {
    keys = safeKeys(Array.isArray(keys) ? keys : [keys]);
    if (!keys.length) return function () {};
    ttlMs = Math.max(100, Math.min(5000, Number(ttlMs) || 1500));
    var nowMs = Date.now(), entries = [], id = ++expectedLocalEchoSeq;
    keys.forEach(function (key) {
      var queue = pruneExpectedLocalQueue(key, nowMs);
      if (!queue) { queue = []; expectedLocalEchoes.set(key, queue); }
      var entry = { id: id, expiresAt: nowMs + ttlMs, active: true };
      queue.push(entry); entries.push({ key: key, entry: entry });
      if (queue.length > LOCAL_ECHO_MAX_PER_KEY) queue.splice(0, queue.length - LOCAL_ECHO_MAX_PER_KEY);
    });
    return function cancelExpectedLocalEcho() {
      entries.forEach(function (item) { if (item && item.entry) item.entry.active = false; });
      keys.forEach(function (key) { pruneExpectedLocalQueue(key, Date.now()); });
    };
  }

  function safeKey(key) { return typeof key === "string" && key.length > 0 && key.length <= 512 && key !== "__proto__" && key !== "prototype" && key !== "constructor"; }
  function safeKeys(keys) { return (Array.isArray(keys) ? keys : []).filter(safeKey).slice(0, MAX_KEYS); }
  function requireStorage() {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
      var err = new Error("O armazenamento da extensão não está disponível neste contexto.");
      err.code = "STORAGE_UNAVAILABLE";
      throw err;
    }
    return chrome.storage.local;
  }
  function storageError(prefix) {
    var last = null;
    try { last = chrome.runtime && chrome.runtime.lastError; } catch (_) {}
    if (!last) return null;
    var err = new Error(prefix + ": " + (last.message || String(last)));
    err.code = "STORAGE_ERROR";
    return err;
  }
  function directCall(method, arg) {
    return new Promise(function (resolve, reject) {
      try {
        var storage = requireStorage();
        var settled = false;
        function done(result) {
          if (settled) return;
          settled = true;
          var err = storageError("chrome.storage.local." + method);
          if (err) reject(err); else resolve(result);
        }
        var ret = arg === undefined ? storage[method](done) : storage[method](arg, done);
        if (ret && typeof ret.then === "function") {
          ret.then(function (value) { if (!settled) { settled = true; resolve(value); } }, function (err) { if (!settled) { settled = true; reject(err); } });
        }
      } catch (err) { reject(err); }
    });
  }
  function notifySubscribers(key, newValue, oldValue, meta) {
    [subscribers.get(key), subscribers.get("*")].forEach(function (set) {
      if (!set) return;
      set.forEach(function (fn) { try { fn(newValue, oldValue, key, meta || { local: false, area: "local" }); } catch (err) { if(root.__extReportRuntimeError)root.__extReportRuntimeError("STORAGE_SUBSCRIBER_FAILED",err); } });
    });
  }
  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local") return;
      Object.keys(changes || {}).forEach(function (key) {
        var c = changes[key] || {};
        var local = consumeLocalKey(key, c.newValue) || consumeExpectedLocalKey(key);
        notifySubscribers(key, c.newValue, c.oldValue, { local: local, area: area, origin: local ? "local" : "external", contextId: local ? contextId : null });
      });
    });
  } catch (_) {}

  async function get(key) {
    if (!safeKey(key)) throw Object.assign(new Error("Referência de dados inválida"), { code: "INVALID_STORAGE_KEY" });
    var result = await directCall("get", key);
    return result ? result[key] : undefined;
  }
  async function getMany(keys) { return directCall("get", safeKeys(keys)); }
  async function set(key, value) {
    if (!safeKey(key)) throw Object.assign(new Error("Referência de dados inválida"), { code: "INVALID_STORAGE_KEY" });
    var obj = {}; obj[key] = value; markLocalValues(obj);
    try { await directCall("set", obj); return true; } catch (error) { discardLatestLocalKeys([key]); throw error; }
  }
  async function setMany(values) {
    values = values && typeof values === "object" ? values : {};
    var out = {};
    Object.keys(values).filter(safeKey).slice(0, MAX_KEYS).forEach(function (key) { out[key] = values[key]; });
    var keys = Object.keys(out); markLocalValues(out);
    try { await directCall("set", out); return true; } catch (error) { discardLatestLocalKeys(keys); throw error; }
  }
  async function remove(key) {
    if (!safeKey(key)) throw Object.assign(new Error("Referência de dados inválida"), { code: "INVALID_STORAGE_KEY" });
    markLocalRemovals([key]);
    try { await directCall("remove", key); return true; } catch (error) { discardLatestLocalKeys([key]); throw error; }
  }
  async function removeMany(keys) {
    keys = safeKeys(keys); markLocalRemovals(keys);
    try { await directCall("remove", keys); return true; } catch (error) { discardLatestLocalKeys(keys); throw error; }
  }
  async function getParsed(key, fallback) {
    var value = await get(key);
    return schema && schema.safeParse ? schema.safeParse(value, fallback) : (typeof value === "string" ? (function () { try { return JSON.parse(value); } catch (_) { return fallback === undefined ? value : fallback; } })() : value);
  }
  async function setParsed(key, value) {
    var desc = schema && schema.describe ? schema.describe(key) : null;
    var codec = desc && desc.codec || "json";
    var serialized = schema && schema.serialize ? schema.serialize(value, codec) : JSON.stringify(value);
    return set(key, serialized);
  }
  function subscribe(key, fn) {
    if (typeof fn !== "function") throw new TypeError("subscribe exige função");
    key = key || "*";
    var set = subscribers.get(key);
    if (!set) { set = new Set(); subscribers.set(key, set); }
    set.add(fn);
    return function () { set.delete(fn); if (!set.size) subscribers.delete(key); };
  }
  var api = Object.freeze({
    version: "1.6.0-origin-aware",
    protocolVersion: 1,
    schemaVersion: schema && schema.schemaVersion || 1,
    transport: "direct",
    get: get, getMany: getMany, set: set, setMany: setMany,
    remove: remove, removeMany: removeMany,
    getParsed: getParsed, setParsed: setParsed, subscribe: subscribe, expectLocalEcho: expectLocalEcho,
    waitUntilReady: function () { try { requireStorage(); return Promise.resolve(true); } catch (err) { return Promise.reject(err); } },
    isReady: function () { try { requireStorage(); return true; } catch (_) { return false; } },
    describe: function (key) { return schema && schema.describe ? schema.describe(key) : null; },
    canonicalKey: function (key) { return schema && schema.canonicalKey ? schema.canonicalKey(key) : key; }
  });
  root.ExtensionStorage = api;
  root.ExtensionCore = root.ExtensionCore || {};
  

})(typeof globalThis!=="undefined"?globalThis:window);
}catch(_extuiBundleError){var _extStorageRoot=typeof globalThis!=="undefined"?globalThis:null;if(_extStorageRoot&&_extStorageRoot.__extRecordBootError)_extStorageRoot.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;

