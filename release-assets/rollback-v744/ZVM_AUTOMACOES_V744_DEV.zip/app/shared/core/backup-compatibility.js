;
try{
(function(root){
  "use strict";
  if(root.__extBackupCompatibility)return;

  var CURRENT_FORMAT="EXTAPP_BACKUP", CURRENT_VERSION=5;
  var SAFE_UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  var SAFE_ID=/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|id-\d{10,16}-[A-Za-z0-9_-]{4,40}|[0-9a-f]{24,64}|[0-9]{8,20})$/i;
  var UNSAFE=new Set(["__proto__","prototype","constructor"]);
  function legacyKeyFingerprint(text){text=String(text||"");var a=2166136261,b=0x9e3779b9;for(var i=0;i<text.length;i++){var c=text.charCodeAt(i);a=Math.imul(a^c,16777619)>>>0;b=Math.imul(b^c,0x85ebca6b)>>>0;}a=(a^(a>>>16))>>>0;b=(b^(b>>>13))>>>0;return text.length+":"+a+":"+b;}
  var LEGACY_KEY_FINGERPRINT_MAP=Object.freeze({
    "15:1692097994:2043451823":"EXTUI:extappFlowStore",
    "17:386961333:2074891365":"EXTUI:extappFunnelStore",
    "24:386296731:755625557":"EXTUI:extappQuickResponseStore",
    "19:4278090668:1082086780":"EXTUI:textMessageStore",
    "13:2157222170:3159798408":"EXTUI:audioStore",
    "13:1835068776:4167584480":"EXTUI:mediaStore",
    "16:1966655073:1838528907":"EXTUI:documentStore",
    "15:1100951838:2690949616":"EXTUI:stickerStore",
    "11:1500428349:466041736":"EXTUI:pixStore",
    "19:4032227340:1598125386":"EXTUI:contactCardStore",
    "20:717298173:1561387240":"EXTUI:quickItemsRecents",
    "11:1841955286:49347943":"EXTUI:CrmStore",
    "26:4038088250:1206876044":"EXTUI:crmFunnelAnalyticsStore",
    "20:1929338090:3177341133":"EXTUI:meetCalendarStore",
    "18:3571550630:2036075005":"EXTUI:extappOptionsStore",
    "21:1535050452:4134796605":"EXTUI:extappAppearanceStore",
    "29:3559263659:375257027":"EXTUI:extappDashboardSidebarCompact",
    "23:3725527601:2513264413":"EXTUI:externalActionsStore",
    "23:276255564:4207527671":"EXTUI:contactMetadataStore"
  });
  function legacyKeyTarget(key){return LEGACY_KEY_FINGERPRINT_MAP[legacyKeyFingerprint(key)]||"";}
  function legacyDataScore(data){var score=0;Object.keys(data&&typeof data==="object"?data:{}).slice(0,96).forEach(function(key){if(legacyKeyTarget(key))score++;});return score;}
  var CATEGORY_BY_KEY=Object.freeze({
    "EXTUI:extappFlowStore":"flows","EXTUI:flowFilesStore":"flows","EXTUI:extappFunnelStore":"funnels",
    "EXTUI:extappFollowUpStore":"followups","EXTUI:extappQuickResponseStore":"quickResponses","EXTUI:quickAssetsStore":"quickResponses",
    "EXTUI:textMessageStore":"items","EXTUI:audioStore":"items","EXTUI:mediaStore":"items","EXTUI:documentStore":"items","EXTUI:stickerStore":"items","EXTUI:pixStore":"items","EXTUI:interactiveListStore":"items","EXTUI:contactCardStore":"items","EXTUI:quickItemsRecents":"items","EXTUI:greetingMessagesStore":"items","EXTUI:signaturesStore":"items",
    "EXTUI:labelStore":"labels","EXTUI:CrmStore":"crm","EXTUI:crmFunnelAnalyticsStore":"crm","EXTUI:meetCalendarStore":"agenda",
    "EXTUI:extappOptionsStore":"settings","EXTUI:extappAppearanceStore":"personalization","EXTUI:extappDashboardSidebarCompact":"personalization",
    "EXTUI:externalActionsStore":"integrations","EXTUI:contactMetadataStore":"contacts"
  });

  function own(o,k){return !!o&&Object.prototype.hasOwnProperty.call(o,k);}
  function safeKey(k){return !UNSAFE.has(String(k||""));}
  function clone(v){
    if(v==null||typeof v!=="object")return v;
    if(Array.isArray(v))return v.map(clone);
    var out={};Object.keys(v).forEach(function(k){if(safeKey(k))out[k]=clone(v[k]);});return out;
  }
  function parse(v){if(typeof v!=="string")return clone(v);try{return JSON.parse(v);}catch(_){return v;}}
  function stringifyLike(source,value){return typeof source==="string"?JSON.stringify(value):value;}
  function nowIso(){return new Date().toISOString();}
  function safeId(v){v=String(v||"");return SAFE_ID.test(v)?v:"";}
  function categoryList(data){var out=[];Object.keys(data||{}).forEach(function(k){var id=CATEGORY_BY_KEY[k];if(id&&out.indexOf(id)<0)out.push(id);});return out;}
  function mimeFromDataUri(data){var m=String(data||"").match(/^data:([^;,]+)/i);return m?m[1]:"";}

  function hash128(text){
    text=String(text||"");var h1=0x9e3779b9,h2=0x243f6a88,h3=0xb7e15162,h4=0xdeadbeef;
    for(var i=0;i<text.length;i++){var c=text.charCodeAt(i);h1=Math.imul(h1^c,0x85ebca6b);h2=Math.imul(h2^c,0xc2b2ae35);h3=Math.imul(h3^c,0x27d4eb2f);h4=Math.imul(h4^c,0x165667b1);}
    h1=(h1^(h1>>>16))>>>0;h2=(h2^(h2>>>13))>>>0;h3=(h3^(h3>>>16))>>>0;h4=(h4^(h4>>>13))>>>0;return[h1,h2,h3,h4];
  }
  function mappedUuid(namespace,id){
    var h=hash128(String(namespace||"ext")+":"+String(id||"")),hex=h.map(function(n){return n.toString(16).padStart(8,"0");}).join("");
    return hex.slice(0,8)+"-"+hex.slice(8,12)+"-5"+hex.slice(13,16)+"-a"+hex.slice(17,20)+"-"+hex.slice(20,32);
  }
  function normalizeLegacyValue(value){
    if(typeof value==="string"){var trimmed=value.trim();if((trimmed.charAt(0)==="{"&&trimmed.charAt(trimmed.length-1)==="}")||(trimmed.charAt(0)==="["&&trimmed.charAt(trimmed.length-1)==="]")){try{return JSON.stringify(normalizeLegacyValue(JSON.parse(value)));}catch(_){}}var colon=value.indexOf(":");if(colon===9&&value.slice(3,10)==="-media:"&&/^[A-Za-z0-9]{3}$/.test(value.slice(0,3)))return "extapp-media:"+value.slice(10);return value;}
    if(Array.isArray(value))return value.map(normalizeLegacyValue);
    if(value&&typeof value==="object"){var out={};Object.keys(value).forEach(function(k){if(safeKey(k))out[k]=normalizeLegacyValue(value[k]);});return out;}
    return value;
  }
  function migrateAppearance(raw,report){
    var source=raw,parsed=parse(raw);if(!parsed||typeof parsed!=="object"||Array.isArray(parsed))return raw;
    var changed=false;
    function patch(obj){if(!obj||typeof obj!=="object"||Array.isArray(obj))return;var theme=String(obj.visualTheme||"");var known=["padrao","whatsapp","system","dark","classic","vibrant","gray"];if(theme&&known.indexOf(theme)<0){obj.visualTheme="padrao";changed=true;}if(Number(obj.themeStateVersion||0)<7){obj.themeStateVersion=7;changed=true;}}
    patch(parsed);patch(parsed.state);
    if(changed)report.repairs.push({code:"LEGACY_APPEARANCE_NORMALIZED",message:"Tema antigo ajustado para o tema padrão atual."});
    return stringifyLike(source,parsed);
  }
  function deactivateStore(raw,listField,report,label){
    var source=raw,parsed=parse(raw);if(!parsed||typeof parsed!=="object"||Array.isArray(parsed))return raw;
    var state=parsed.state&&typeof parsed.state==="object"?parsed.state:parsed,list=Array.isArray(state[listField])?state[listField]:[],changed=0;
    list.forEach(function(item){if(!item||typeof item!=="object")return;["isActive","active","enabled"].forEach(function(k){if(own(item,k)&&item[k]!==false){item[k]=false;changed++;}});});
    if(changed)report.repairs.push({code:"IMPORTED_AUTOMATION_DISABLED",count:changed,message:label+": automações importadas foram desativadas para revisão."});
    return stringifyLike(source,parsed);
  }
  function importedFlowTargets(node){
    var out=[];if(!node||typeof node!=="object")return out;
    (Array.isArray(node.nextNodeIds)?node.nextNodeIds:[]).forEach(function(id){if(id&&out.indexOf(String(id))<0)out.push(String(id));});
    [node.nextNodeIdOnExpiration,node.nextNodeIdOnDifferentAnswer,node.nextNodeIdOnConditionFalse].forEach(function(id){if(id&&out.indexOf(String(id))<0)out.push(String(id));});
    var weights=node.data&&Array.isArray(node.data.weights)?node.data.weights:[];weights.forEach(function(w){var id=w&&w.nextNodeId;if(id&&out.indexOf(String(id))<0)out.push(String(id));});
    return out;
  }
  function layoutImportedFlowNodes(nodes,startNodeId){
    if(!Array.isArray(nodes)||!nodes.length)return false;var byId={},order={};nodes.forEach(function(node,index){if(node&&node.id){byId[String(node.id)]=node;order[String(node.id)]=index;}});
    var start=byId[String(startNodeId||"")]||nodes.find(function(node){return node&&node.type==="start";})||nodes[0],depth={},queue=[];if(start&&start.id){depth[String(start.id)]=0;queue.push(String(start.id));}
    while(queue.length){var id=queue.shift(),d=depth[id],node=byId[id];importedFlowTargets(node).forEach(function(target){if(!byId[target])return;if(depth[target]===undefined||depth[target]>d+1){depth[target]=d+1;queue.push(target);}});}
    var maxDepth=Object.keys(depth).reduce(function(max,id){return Math.max(max,depth[id]);},-1);nodes.forEach(function(node){var id=node&&String(node.id||"");if(id&&depth[id]===undefined)depth[id]=++maxDepth;});
    var layers={};nodes.forEach(function(node){if(!node||!node.id)return;var d=depth[String(node.id)]||0;(layers[d]||(layers[d]=[])).push(node);});
    var wave=[0,110,-70,150,35,-115,90,-35],baseY=280,xGap=330,yGap=180,minY=Infinity;Object.keys(layers).map(Number).sort(function(a,b){return a-b;}).forEach(function(d){var layer=layers[d].slice().sort(function(a,b){return(order[String(a.id)]||0)-(order[String(b.id)]||0);}),center=baseY+wave[d%wave.length],count=layer.length;layer.forEach(function(node,index){var y=center+(index-(count-1)/2)*yGap;node.position={x:90+d*xGap,y:Math.round(y/20)*20};minY=Math.min(minY,node.position.y);});});
    if(minY<60){var shift=Math.ceil((60-minY)/20)*20;nodes.forEach(function(node){if(node&&node.position)node.position.y+=shift;});}
    return true;
  }
  function importedFlowLayoutLooksDegenerate(nodes){
    if(!Array.isArray(nodes)||nodes.length<4)return false;var positions=nodes.map(function(node){return node&&node.position;}).filter(function(pos){return pos&&Number.isFinite(Number(pos.x))&&Number.isFinite(Number(pos.y));});if(positions.length!==nodes.length)return true;
    var ys=positions.map(function(pos){return Number(pos.y);}),minY=Math.min.apply(Math,ys),maxY=Math.max.apply(Math,ys),bands=new Set(ys.map(function(y){return Math.round(y/80);}));return maxY-minY<140||bands.size<=Math.max(2,Math.floor(nodes.length*.12));
  }
  function normalizeLegacyFlowLayout(raw,report){
    var source=raw,parsed=parse(raw);if(!parsed||typeof parsed!=="object"||Array.isArray(parsed))return raw;var state=parsed.state&&typeof parsed.state==="object"?parsed.state:parsed,list=Array.isArray(state.flowList)?state.flowList:[],changed=0;
    list.forEach(function(flow){if(!flow||!Array.isArray(flow.nodes)||!flow.nodes.length)return;if(importedFlowLayoutLooksDegenerate(flow.nodes)&&layoutImportedFlowNodes(flow.nodes,flow.startNodeId)){changed++;flow.updatedAtInMs=Number(flow.updatedAtInMs)||Date.now();}});
    if(changed)report.repairs.push({code:"IMPORTED_FLOW_LAYOUT_NORMALIZED",count:changed,message:"Fluxos antigos com layout colinear foram reorganizados em camadas para facilitar a revisão."});return stringifyLike(source,parsed);
  }
  function baseReport(source,label,version,family){var out={source:source,sourceLabel:label,certification:"verified",repairs:[],warnings:[],unsupported:[],secretsRemoved:[],stats:{}};if(version)out.sourceVersion=String(version);if(family)out.sourceFamily=String(family);return out;}
  function currentShape(data,assets,report,createdAt){
    data=data||{};assets=assets||{};var cats=categoryList(data),assetKeys=Object.keys(assets);
    var out={format:CURRENT_FORMAT,version:CURRENT_VERSION,createdAt:createdAt||nowIso(),mode:"portable",assetEncoding:"source",categories:cats,keys:Object.keys(data),assetKeys:assetKeys,data:data,assets:assets,ownerBound:null,compatibilityReport:[report],security:{secretsIncluded:false,ownerBoundProgress:false,ownerBinding:null}};
    out.integrity={itemRefs:assetKeys.length,itemAssets:assetKeys.length,missingItemAssets:[]};
    return out;
  }

  function detectStructuredA(raw){
    if(!Array.isArray(raw.objectsList))return null;
    var listKeys=["messages","audios","medias","docs","flows","funnels","labels","triggers"],present=listKeys.filter(function(k){return Array.isArray(raw[k]);});
    if(present.length<4)return null;
    var objectIds=new Set(),validObjects=0;raw.objectsList.slice(0,2000).forEach(function(o){if(o&&safeId(o.id)&&typeof o.data==="string"){objectIds.add(String(o.id));validObjects++;}});
    var refs=0,matched=0;["messages","audios","medias","docs"].forEach(function(k){(raw[k]||[]).slice(0,500).forEach(function(item){if(item&&safeId(item.id)){refs++;if(objectIds.has(String(item.id)))matched++;}});});
    var semantic=Number(Array.isArray(raw.flows)&&raw.flows.length>0)+Number(Array.isArray(raw.funnels)&&raw.funnels.length>0)+Number(Array.isArray(raw.labels)&&raw.labels.length>0);
    if(validObjects<1||((refs<1||matched<1)&&semantic<1))return null;
    var confidence=Math.min(1,.56+present.length*.035+Math.min(matched,8)*.025+semantic*.025);
    return{source:"external",family:"structured-a",label:"Backup externo compatível",confidence:confidence,certification:"structural-verified"};
  }
  function detect(raw){
    if(!raw||typeof raw!=="object"||Array.isArray(raw))return{source:"unknown",confidence:0};
    if(raw.format===CURRENT_FORMAT&&raw.data&&typeof raw.data==="object")return{source:"extapp",label:"Backup desta extensão",version:String(raw.version||""),confidence:1,certification:"native"};
    if(raw.data&&typeof raw.data==="object"&&legacyDataScore(raw.data)>=2)return{source:"native-legacy",label:"Backup antigo compatível",version:String(raw.version||""),confidence:1,certification:"verified"};
    if(root.__extExternalStructuredBackupAdapter&&typeof root.__extExternalStructuredBackupAdapter.detect==="function"){var b=root.__extExternalStructuredBackupAdapter.detect(raw);if(b&&b.source==="external"&&b.family==="structured-b")return b;}
    var a=detectStructuredA(raw);if(a)return a;
    return{source:"unknown",confidence:0};
  }

  function convertLegacy(raw){
    var info=detect(raw),report=baseReport("native-legacy",info.label,info.version),data={},assets={};
    Object.keys(raw.data||{}).forEach(function(oldKey){
      if(!safeKey(oldKey))return;var next=legacyKeyTarget(oldKey)||(/^EXTUI:/.test(oldKey)?oldKey:"");
      if(!next){report.unsupported.push({key:oldKey,reason:"no-current-equivalent"});return;}
      var value=normalizeLegacyValue(raw.data[oldKey]);
      if(next==="EXTUI:extappOptionsStore"||next==="EXTUI:extappAppearanceStore")value=migrateAppearance(value,report);
      if(next==="EXTUI:extappFlowStore"){value=deactivateStore(value,"flowList",report,"Fluxos");value=normalizeLegacyFlowLayout(value,report);}
      if(next==="EXTUI:extappFunnelStore")value=deactivateStore(value,"funnelList",report,"Funis");
      data[next]=value;
    });
    Object.keys(raw.assets||{}).forEach(function(id){if(safeId(id))assets[id]=normalizeLegacyValue(raw.assets[id]);});
    report.stats={dataKeys:Object.keys(data).length,assets:Object.keys(assets).length,unsupportedKeys:report.unsupported.length};
    return currentShape(data,assets,report,raw.createdAt||nowIso());
  }

  var EXTERNAL_A_ID_SEEDS=Object.freeze({
    item:Object.freeze([2633172212,1147856987,1994554051,3598842496]),
    node:Object.freeze([4257688069,660302894,2708936158,1295182613]),
    flow:Object.freeze([4116079525,1778066960,1875910910,1842287383]),
    funnelStep:Object.freeze([3952150732,749107647,1835843817,938232464]),
    funnel:Object.freeze([2291332417,3257974912,4052137442,3315348415]),
    label:Object.freeze([4145570221,168090104,274239144,2597534723])
  });
  function hash128Seeded(text,seed){text=String(text||"");var h1=seed[0]>>>0,h2=seed[1]>>>0,h3=seed[2]>>>0,h4=seed[3]>>>0;for(var i=0;i<text.length;i++){var c=text.charCodeAt(i);h1=Math.imul(h1^c,0x85ebca6b);h2=Math.imul(h2^c,0xc2b2ae35);h3=Math.imul(h3^c,0x27d4eb2f);h4=Math.imul(h4^c,0x165667b1);}h1=(h1^(h1>>>16))>>>0;h2=(h2^(h2>>>13))>>>0;h3=(h3^(h3>>>16))>>>0;h4=(h4^(h4>>>13))>>>0;return[h1,h2,h3,h4];}
  function externalAUuid(kind,id){var seed=EXTERNAL_A_ID_SEEDS[kind];if(!seed)return mappedUuid("external",String(kind)+":"+String(id||""));var h=hash128Seeded(String(id||""),seed),hex=h.map(function(n){return n.toString(16).padStart(8,"0");}).join("");return hex.slice(0,8)+"-"+hex.slice(8,12)+"-5"+hex.slice(13,16)+"-a"+hex.slice(17,20)+"-"+hex.slice(20,32);}

  var EXTERNAL_A_ITEM_SPECS=Object.freeze([
    {source:"messages",key:"EXTUI:textMessageStore",field:"textMessageList",kind:"message"},
    {source:"audios",key:"EXTUI:audioStore",field:"audioList",kind:"audio"},
    {source:"medias",key:"EXTUI:mediaStore",field:"mediaList",kind:"media"},
    {source:"docs",key:"EXTUI:documentStore",field:"documentList",kind:"document"}
  ]);
  function externalAMeta(item,kind,mappedId){
    var out={id:mappedId,importSource:"external",importSourceId:String(item.id),name:String(item.name||item.fileName||({message:"Mensagem",audio:"Áudio",media:"Imagem/Vídeo",document:"Documento"}[kind])+" importado"),favorite:item.isFavorite===true||item.favorite===true};
    if(kind==="audio"){out.isPtt=item.isPtt!==false;out.asViewOnce=item.asViewOnce===true;}
    if(kind==="media"){out.asViewOnce=item.asViewOnce===true;out.isPtv=item.isPtv===true;}
    if(kind==="document"&&item.fileName)out.fileName=String(item.fileName);return out;
  }
  function externalAAsset(object,kind){var out={data:object.data};if(kind==="audio"&&own(object,"isPtt"))out.isPtt=object.isPtt!==false;if(kind==="media"&&object.caption!=null)out.caption=String(object.caption);if(kind==="document"&&object.fileName)out.fileName=String(object.fileName);var mime=mimeFromDataUri(object.data);if(mime)out.mimeType=mime;return out;}
  function externalATrigger(start){var t=start&&start.trigger&&typeof start.trigger==="object"?start.trigger:{};return{isCaseSensitive:t.isCaseSensitive===true,keywordRules:Array.isArray(t.keywordRules)?t.keywordRules.map(function(r){return{id:String(r&&r.id||""),type:["contains","notContains","equals","startsWith","endsWith"].indexOf(String(r&&r.type))>=0?String(r.type):"contains",keywords:Array.isArray(r&&r.keywords)?r.keywords.map(String).filter(Boolean):[]};}).filter(function(r){return r.keywords.length;}):[],sendToContacts:t.sendToContacts!==false,sendToGroups:t.sendToGroups===true};}
  function externalAFlowNode(node){var base={id:String(node.id),position:clone(node.position)||{x:80,y:160},nextNodeIds:Array.isArray(node.nextNodeIds)?node.nextNodeIds.map(String).filter(Boolean):[],nextNodeIdOnExpiration:null,nextNodeIdOnDifferentAnswer:null,expirationTimeoutInMs:null,data:{}};if(node.type==="text"){base.type="sendText";base.data={itemId:String(node.itemId||"")};}else if(node.type==="audio"||node.type==="media"||node.type==="document"){base.type="sendMedia";base.data={itemId:String(node.itemId||""),itemKind:node.type};}else{base.type="unsupported";base.data={type:String(node.type||"unknown"),externalItemId:String(node.itemId||"")};}return base;}
  function convertExternalAFlows(raw,report,itemMap){
    var list=[];Array.isArray(raw.flows)&&raw.flows.forEach(function(flow){if(!flow||!safeId(flow.id))return;var body=flow.published&&Array.isArray(flow.published.nodes)?flow.published:flow.draft&&Array.isArray(flow.draft.nodes)?flow.draft:null,start=flow.publishedStartNode||flow.draftStartNode;if(!body||!start||!start.id){report.warnings.push({code:"EXTERNAL_FLOW_SKIPPED",message:"Um Fluxo sem estrutura publicável foi ignorado."});return;}
      var nodeMap={};nodeMap[String(start.id)]=externalAUuid("node",flow.id+":"+start.id);body.nodes.forEach(function(n){if(n&&n.id)nodeMap[String(n.id)]=externalAUuid("node",flow.id+":"+n.id);});
      function mapNext(ids){return Array.isArray(ids)?ids.map(function(id){return nodeMap[String(id)]||"";}).filter(Boolean):[];}
      var nodes=[{id:nodeMap[String(start.id)],type:"start",position:clone(start.position)||{x:80,y:160},data:{},nextNodeIds:mapNext(start.nextNodeIds),nextNodeIdOnExpiration:null,nextNodeIdOnDifferentAnswer:null,expirationTimeoutInMs:null}],unsupported=0;
      body.nodes.forEach(function(n){var mapped=externalAFlowNode(n);mapped.id=nodeMap[String(n.id)];mapped.nextNodeIds=mapNext(n.nextNodeIds);if(mapped.data&&mapped.data.itemId){var nextItem=itemMap[String(mapped.data.itemId)];mapped.data.itemId=nextItem||"";if(!nextItem){mapped.type="unsupported";mapped.data.type="missingItem";unsupported++;}}if(mapped.type==="unsupported")unsupported++;nodes.push(mapped);});
      layoutImportedFlowNodes(nodes,nodeMap[String(start.id)]);list.push({id:externalAUuid("flow",flow.id),importSource:"external",importSourceId:String(flow.id),name:String(body.name||flow.name||"Fluxo importado"),description:String(body.description||body.desc||flow.description||flow.desc||"").slice(0,300),color:String(body.color||body.hexColor||flow.color||flow.hexColor||"#10b981"),isActive:false,startNodeId:nodeMap[String(start.id)],favorite:flow.isFavorite===true,trigger:externalATrigger(start),nodes:nodes,createdAtInMs:Date.parse(flow.createdAt||"")||Date.now(),updatedAtInMs:Date.parse(body.updatedAt||flow.updatedAt||"")||Date.now()});if(unsupported)report.warnings.push({code:"EXTERNAL_FLOW_UNSUPPORTED_NODES",count:unsupported,message:"Um Fluxo contém "+unsupported+" etapa(s) sem equivalente e foi importado desativado para revisão."});
    });if(list.length)report.repairs.push({code:"EXTERNAL_FLOW_LAYOUT_LAYERED",count:list.length,message:"Fluxos do backup externo foram organizados em camadas com variação vertical para facilitar a leitura."});return list;
  }
  function delayFromMs(ms){ms=Math.max(0,Number(ms)||0);if(ms%86400000===0&&ms>=86400000)return{delayAmount:ms/86400000,delayUnit:"days"};if(ms%3600000===0&&ms>=3600000)return{delayAmount:ms/3600000,delayUnit:"hours"};if(ms%60000===0&&ms>=60000)return{delayAmount:ms/60000,delayUnit:"minutes"};return{delayAmount:Math.round(ms/1000),delayUnit:"seconds"};}
  function convertExternalAFunnels(raw,itemMap){var out=[];Array.isArray(raw.funnels)&&raw.funnels.forEach(function(f){if(!f||!safeId(f.id))return;var items=(Array.isArray(f.itemsSequence)?f.itemsSequence:[]).map(function(item,index){var d=delayFromMs(item&&item.delayBeforeSend),sourceItem=String(item&&item.itemId||"");return{id:externalAUuid("funnelStep",String(f.id)+":"+String(item&&item.id||index)),importSource:"external",importSourceId:String(item&&item.id||index),type:String(item&&item.type||"message"),itemId:itemMap[sourceItem]||"",delayAmount:d.delayAmount,delayUnit:d.delayUnit};}).filter(function(item){return !!item.itemId;});out.push({id:externalAUuid("funnel",f.id),importSource:"external",importSourceId:String(f.id),name:String(f.name||"Funil importado"),description:String(f.description||f.desc||"").slice(0,300),color:String(f.color||f.hexColor||"#f43f5e"),items:items,favorite:f.isFavorite===true});});return out;}
  function convertExternalALabels(raw){var list=[];Array.isArray(raw.labels)&&raw.labels.forEach(function(x){if(!x||!x.id)return;list.push({id:externalAUuid("label",x.id),importSource:"external",importSourceId:String(x.id),name:String(x.name||x.label||"Etiqueta importada"),color:x.color||x.hexColor||"#10b981",favorite:false});});return list;}
  function convertExternalA(raw){
    var info=detect(raw);if(info.source!=="external"||info.family!=="structured-a"){var notDetected=new Error("O arquivo não corresponde ao formato externo esperado.");notDetected.code="BACKUP_EXTERNAL_NOT_DETECTED";throw notDetected;}
    var report=baseReport("external","Backup externo compatível","","structured-a"),data={},assets={},objects=new Map(),itemMap={};
    (raw.objectsList||[]).forEach(function(o){if(o&&safeId(o.id)&&!objects.has(String(o.id)))objects.set(String(o.id),o);});var missing=[];
    EXTERNAL_A_ITEM_SPECS.forEach(function(spec){var list=[];(raw[spec.source]||[]).forEach(function(item){if(!item||!safeId(item.id))return;var id=String(item.id),obj=objects.get(id);if(!obj||typeof obj.data!=="string"){missing.push(id);return;}var mapped=externalAUuid("item",id);itemMap[id]=mapped;list.push(externalAMeta(item,spec.kind,mapped));assets[mapped]=externalAAsset(obj,spec.kind);});if(list.length){var state={};state[spec.field]=list;data[spec.key]=JSON.stringify({state:state,version:0});}});
    var flows=convertExternalAFlows(raw,report,itemMap);if(flows.length)data["EXTUI:extappFlowStore"]=JSON.stringify({state:{flowList:flows},version:0});
    var funnels=convertExternalAFunnels(raw,itemMap);if(funnels.length)data["EXTUI:extappFunnelStore"]=JSON.stringify({state:{funnelList:funnels},version:0});
    var labels=convertExternalALabels(raw);if(labels.length)data["EXTUI:labelStore"]=JSON.stringify({state:{labelList:labels},version:0});
    if(Array.isArray(raw.triggers)&&raw.triggers.length)report.unsupported.push({key:"triggers",count:raw.triggers.length,reason:"standalone-trigger-needs-review",message:"Gatilhos avulsos foram preservados apenas no relatório; Fluxos importados usam seus próprios gatilhos."});
    if(missing.length)report.warnings.push({code:"EXTERNAL_MISSING_OBJECTS",count:missing.length,message:missing.length+" item(ns) sem conteúdo correspondente em objectsList foram ignorados."});
    report.repairs.push({code:"IMPORTED_AUTOMATIONS_DISABLED",message:"Fluxos importados foram desativados para revisão antes do primeiro uso."});
    report.stats={messages:(raw.messages||[]).length,audios:(raw.audios||[]).length,medias:(raw.medias||[]).length,documents:(raw.docs||[]).length,flows:flows.length,funnels:funnels.length,labels:labels.length,assets:Object.keys(assets).length,missingAssets:missing.length};return currentShape(data,assets,report,nowIso());
  }

  function convert(raw){var info=detect(raw);if(info.source==="extapp")return clone(raw);if(info.source==="native-legacy")return convertLegacy(raw);if(info.source==="external"&&info.family==="structured-a")return convertExternalA(raw);if(info.source==="external"&&info.family==="structured-b"){var e=new Error("Este formato externo requer preparação segura antes da conversão.");e.code="BACKUP_EXTERNAL_ASYNC_REQUIRED";e.detected=info;throw e;}var invalid=new Error("Formato de backup não reconhecido por esta extensão.");invalid.code="BACKUP_FORMAT_UNSUPPORTED";throw invalid;}
  async function convertAsync(raw){var info=detect(raw);if(info.source==="external"&&info.family==="structured-b"){if(!root.__extExternalStructuredBackupAdapter||typeof root.__extExternalStructuredBackupAdapter.convert!=="function"){var unavailable=new Error("O conversor do formato externo não está disponível nesta build.");unavailable.code="BACKUP_EXTERNAL_ADAPTER_UNAVAILABLE";throw unavailable;}return await root.__extExternalStructuredBackupAdapter.convert(raw);}return convert(raw);}
  function analyze(raw){var info=detect(raw);if(info.source==="unknown")return{detected:info,convertible:false};if(info.source==="external"&&info.family==="structured-b")return{detected:info,convertible:true,asyncRequired:true,certification:info.certification||"structural-verified"};var converted=convert(raw),rep=converted.compatibilityReport&&converted.compatibilityReport[0]||null;return{detected:info,convertible:true,categories:converted.categories||[],dataKeys:converted.keys||[],assetCount:(converted.assetKeys||[]).length,report:rep};}
  async function analyzeAsync(raw){var info=detect(raw);if(info.source==="unknown")return{detected:info,convertible:false};var converted=await convertAsync(raw),rep=converted.compatibilityReport&&converted.compatibilityReport[0]||null;return{detected:info,convertible:true,categories:converted.categories||[],dataKeys:converted.keys||[],assetCount:(converted.assetKeys||[]).length,report:rep};}

  root.__extBackupCompatibility=Object.freeze({version:"2.0.0",detect:detect,analyze:analyze,analyzeAsync:analyzeAsync,convert:convert,convertAsync:convertAsync});
})(typeof window!=="undefined"?window:self);
}catch(_extBackupCompatibilityError){if(typeof window!=="undefined"&&window.__extRecordBootError)window.__extRecordBootError(_extBackupCompatibilityError);else throw _extBackupCompatibilityError;}
