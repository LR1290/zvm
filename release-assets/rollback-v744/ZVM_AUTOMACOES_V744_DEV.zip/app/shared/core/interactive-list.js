(function(root){
  "use strict";
  if(root.__extInteractiveList)return;

  var LIMITS=Object.freeze({
    title:60,
    description:1024,
    footer:60,
    buttonText:20,
    sectionTitle:24,
    rowTitle:24,
    rowDescription:72,
    rowId:200,
    maxRows:10
  });

  function text(value){return String(value==null?"":value).trim();}
  function token(prefix){
    try{if(root.crypto&&typeof root.crypto.randomUUID==="function")return prefix+"-"+root.crypto.randomUUID();}catch(_){}
    return prefix+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10);
  }
  function safeId(value,prefix,seen){
    var id=text(value).replace(/[^A-Za-z0-9._:-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,LIMITS.rowId);
    if(!id||seen&&seen.has(id))id=token(prefix).slice(0,LIMITS.rowId);
    if(seen){while(seen.has(id))id=token(prefix).slice(0,LIMITS.rowId);seen.add(id);}
    return id;
  }
  function newRow(input){
    input=input&&typeof input==="object"?input:{};
    return{rowId:safeId(input.rowId,"row"),title:text(input.title),description:text(input.description)};
  }
  function newSection(input){
    input=input&&typeof input==="object"?input:{};
    var rows=Array.isArray(input.rows)?input.rows:[];
    return{id:safeId(input.id,"section"),title:text(input.title||"Opções"),rows:rows.map(newRow)};
  }
  function normalize(value){
    value=value&&typeof value==="object"&&!Array.isArray(value)?value:{};
    var sectionIds=new Set(),rowIds=new Set(),sections=Array.isArray(value.sections)?value.sections:[];
    sections=sections.filter(function(section){return section&&typeof section==="object"&&!Array.isArray(section);}).map(function(section){
      var rows=Array.isArray(section.rows)?section.rows:[];
      return{
        id:safeId(section.id,"section",sectionIds),
        title:text(section.title||"Opções"),
        rows:rows.filter(function(row){return row&&typeof row==="object"&&!Array.isArray(row);}).map(function(row){
          return{rowId:safeId(row.rowId,"row",rowIds),title:text(row.title),description:text(row.description)};
        })
      };
    });
    return{
      schemaVersion:1,
      title:text(value.title),
      description:text(value.description),
      footer:text(value.footer),
      buttonText:text(value.buttonText),
      sections:sections
    };
  }
  function countRows(value){
    var sections=value&&Array.isArray(value.sections)?value.sections:[];
    return sections.reduce(function(total,section){return total+(section&&Array.isArray(section.rows)?section.rows.length:0);},0);
  }
  function validate(value){
    var v=normalize(value),errors=[],total=countRows(v);
    if(!v.description)errors.push("Digite a mensagem da lista.");
    if(v.description.length>LIMITS.description)errors.push("A mensagem deve ter no máximo "+LIMITS.description+" caracteres.");
    if(v.title.length>LIMITS.title)errors.push("O título deve ter no máximo "+LIMITS.title+" caracteres.");
    if(v.footer.length>LIMITS.footer)errors.push("O rodapé deve ter no máximo "+LIMITS.footer+" caracteres.");
    if(!v.buttonText)errors.push("Digite o texto do botão.");
    if(v.buttonText.length>LIMITS.buttonText)errors.push("O texto do botão deve ter no máximo "+LIMITS.buttonText+" caracteres.");
    if(!v.sections.length)errors.push("Adicione pelo menos uma seção.");
    if(total<1)errors.push("Adicione pelo menos uma opção.");
    if(total>LIMITS.maxRows)errors.push("A lista pode ter no máximo "+LIMITS.maxRows+" opções.");
    v.sections.forEach(function(section,sectionIndex){
      if(!section.title)errors.push("A seção "+(sectionIndex+1)+" precisa de um título.");
      if(section.title.length>LIMITS.sectionTitle)errors.push("O título da seção "+(sectionIndex+1)+" deve ter no máximo "+LIMITS.sectionTitle+" caracteres.");
      if(!section.rows.length)errors.push("A seção "+(sectionIndex+1)+" precisa ter pelo menos uma opção.");
      section.rows.forEach(function(row,rowIndex){
        if(!row.title)errors.push("A opção "+(rowIndex+1)+" da seção "+(sectionIndex+1)+" precisa de um título.");
        if(row.title.length>LIMITS.rowTitle)errors.push("O título da opção "+(rowIndex+1)+" da seção "+(sectionIndex+1)+" deve ter no máximo "+LIMITS.rowTitle+" caracteres.");
        if(row.description.length>LIMITS.rowDescription)errors.push("A descrição da opção "+(rowIndex+1)+" da seção "+(sectionIndex+1)+" deve ter no máximo "+LIMITS.rowDescription+" caracteres.");
        if(!row.rowId||row.rowId.length>LIMITS.rowId)errors.push("A opção "+(rowIndex+1)+" da seção "+(sectionIndex+1)+" possui um identificador inválido.");
      });
    });
    return{ok:errors.length===0,errors:errors,value:v};
  }
  function toSendOptions(value){
    var result=validate(value);
    if(!result.ok){var err=new Error(result.errors[0]||"Lista interativa inválida.");err.code="INTERACTIVE_LIST_INVALID";err.details=result.errors.slice();throw err;}
    var v=result.value,out={description:v.description,buttonText:v.buttonText,sections:v.sections.map(function(section){return{title:section.title,rows:section.rows.map(function(row){return{rowId:row.rowId,title:row.title,description:row.description};})};})};
    if(v.title)out.title=v.title;
    if(v.footer)out.footer=v.footer;
    return out;
  }

  var api=Object.freeze({version:1,limits:LIMITS,normalize:normalize,validate:validate,toSendOptions:toSendOptions,countRows:countRows,newSection:newSection,newRow:newRow});
  Object.defineProperty(root,"__extInteractiveList",{value:api,enumerable:false,configurable:false,writable:false});
})(typeof window!=="undefined"?window:globalThis);
