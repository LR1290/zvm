;
try{
(function (root, factory) {
  "use strict";

  var api = factory();
  if (root) root.__extCrmProfessionalCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var STORE_KEY = "EXTUI:crmProfessionalStore";
  var SCHEMA_VERSION = 1;
  var FIELD_TYPES = Object.freeze(["text", "number", "date", "select", "boolean"]);
  var TASK_STATUSES = Object.freeze(["open", "completed", "cancelled"]);
  var sharedQueues = typeof WeakMap === "function" ? new WeakMap() : null;

  function own(object, key) {
    return Object.prototype.hasOwnProperty.call(object, key);
  }

  function isObject(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
  }

  function isSafeKey(key) {
    return key !== "__proto__" && key !== "prototype" && key !== "constructor";
  }

  function clone(value) {
    if (value == null) return value;
    return JSON.parse(JSON.stringify(value));
  }

  function finiteNumber(value, fallback) {
    if (value == null || value === "") return fallback;
    var parsed = typeof value === "number" ? value : Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function nonEmptyString(value) {
    return typeof value === "string" && !!value.trim();
  }

  function parseRaw(raw) {
    if (!raw) return null;
    if (typeof raw !== "string") return raw;
    try { return JSON.parse(raw); } catch (error) { return null; }
  }

  function unwrapState(raw) {
    var parsed = parseRaw(raw);
    if (!isObject(parsed)) return {};
    return isObject(parsed.state) ? parsed.state : parsed;
  }

  function repositoryStoreError(cause) {
    var error = new Error("Os dados avançados do CRM estão corrompidos. O último estado válido foi preservado e a sobrescrita foi bloqueada.");
    error.code = "CRM_PROFESSIONAL_STORE_CORRUPT";
    if (cause) error.cause = cause;
    return error;
  }

  function decodeRepositoryStore(raw) {
    if (raw == null || raw === "") return {};
    var parsed = raw;
    if (typeof parsed === "string") {
      try { parsed = JSON.parse(parsed); } catch (error) { throw repositoryStoreError(error); }
    }
    if (!isObject(parsed)) throw repositoryStoreError();
    var state = own(parsed, "state") ? parsed.state : parsed;
    if (!isObject(state)) throw repositoryStoreError();
    ["boards", "contacts"].forEach(function (key) {
      if (state[key] !== undefined && !isObject(state[key]) && !Array.isArray(state[key])) throw repositoryStoreError();
    });
    var profiles = state.contacts;
    if (isObject(profiles)) Object.keys(profiles).forEach(function (key) {
      var profile = profiles[key];
      if (!isObject(profile)) throw repositoryStoreError();
      if (profile.notes !== undefined && !Array.isArray(profile.notes)) throw repositoryStoreError();
      if (profile.tasks !== undefined && !Array.isArray(profile.tasks)) throw repositoryStoreError();
      if (profile.timeline !== undefined && !Array.isArray(profile.timeline) && !Array.isArray(profile.timelineEvents)) throw repositoryStoreError();
    });
    return parsed;
  }

  function normalizeCrmState(raw) {
    var source = unwrapState(raw);
    var state = clone(source) || {};
    delete state.dummyTrigger;
    state.revision = Math.max(0, finiteNumber(state.revision, 0));
    state.selectedCrmId = typeof state.selectedCrmId === "string" ? state.selectedCrmId : "";
    state.crmList = Array.isArray(state.crmList) ? state.crmList : [];
    state.crmList.forEach(function (crm) {
      if (!isObject(crm)) return;
      crm.columns = Array.isArray(crm.columns) ? crm.columns : [];
      crm.columns.forEach(function (column) {
        if (!isObject(column)) return;
        column.items = Array.isArray(column.items) ? column.items : [];
        column.items.forEach(function (item) {
          if (!isObject(item)) return;
          item.contact = isObject(item.contact) ? item.contact : {};
        });
      });
    });
    return state;
  }

  function getCrmContactId(item) {
    if (!isObject(item)) return null;
    if (typeof item.id === "string" && item.id.trim()) return item.id;
    if (typeof item.id === "number" && Number.isFinite(item.id)) return String(item.id);
    return null;
  }

  function hashText(value) {
    var text = String(value || "");
    var hash = 2166136261;
    for (var index = 0; index < text.length; index++) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }

  function createLegacyContactId(context) {
    context = context || {};
    var item = isObject(context.item) ? context.item : {};
    var contact = isObject(item.contact) ? item.contact : {};


    var seed = [
      "crm-contact-legacy-v1",
      context.crmId || "",
      context.columnId || "",
      finiteNumber(context.crmIndex, 0),
      finiteNumber(context.columnIndex, 0),
      finiteNumber(context.itemIndex, 0),
      finiteNumber(item.createdAtInMs, 0),
      item.createdBy || "",
      contact.name || ""
    ].join("|");
    return "crm-contact-legacy-" + hashText(seed);
  }

  function upgradeLegacyContactIds(raw, options) {
    options = options || {};
    var state = normalizeCrmState(raw);
    var used = Object.create(null);
    var upgrades = [];

    state.crmList.forEach(function (crm) {
      if (!isObject(crm)) return;
      (crm.columns || []).forEach(function (column) {
        if (!isObject(column)) return;
        (column.items || []).forEach(function (item) {
          var existing = getCrmContactId(item);
          if (existing) used[existing] = true;
        });
      });
    });

    state.crmList.forEach(function (crm, crmIndex) {
      if (!isObject(crm)) return;
      (crm.columns || []).forEach(function (column, columnIndex) {
        if (!isObject(column)) return;
        (column.items || []).forEach(function (item, itemIndex) {
          if (!isObject(item)) return;
          var current = getCrmContactId(item);
          if (current) return;
          var context = {
            crmId: crm.id,
            columnId: column.id,
            crmIndex: crmIndex,
            columnIndex: columnIndex,
            itemIndex: itemIndex,
            item: item
          };
          var base = typeof options.createId === "function" ? options.createId(context) : createLegacyContactId(context);
          base = nonEmptyString(base) ? base.trim() : createLegacyContactId(context);
          var candidate = base;
          var suffix = 2;
          while (used[candidate]) candidate = base + "-" + suffix++;
          item.id = candidate;
          used[candidate] = true;
          upgrades.push({ crmContactId: candidate, crmId: crm.id || null, columnId: column.id || null, itemIndex: itemIndex });
        });
      });
    });

    return { state: state, changed: upgrades.length > 0, upgrades: upgrades };
  }

  function normalizePhone(value) {
    if (value == null) return null;
    var digits = String(value).replace(/\D/g, "");
    return digits || null;
  }

  function buildContactIndex(raw) {
    var state = normalizeCrmState(raw);
    var all = [];
    var byId = Object.create(null);
    var byPhone = Object.create(null);
    var duplicateIds = [];

    state.crmList.forEach(function (crm) {
      if (!isObject(crm)) return;
      (crm.columns || []).forEach(function (column) {
        if (!isObject(column)) return;
        (column.items || []).forEach(function (item, itemIndex) {
          if (!isObject(item)) return;
          var crmContactId = getCrmContactId(item);
          var phone = normalizePhone(item.contact && item.contact.phoneNumber);
          var membership = {
            crmContactId: crmContactId,
            crmId: crm.id || null,
            columnId: column.id || null,
            crm: crm,
            column: column,
            item: item,
            itemIndex: itemIndex
          };
          all.push(membership);
          if (crmContactId) {
            if (byId[crmContactId]) duplicateIds.push(crmContactId);
            else byId[crmContactId] = membership;
          }
          if (phone) {
            if (!byPhone[phone]) byPhone[phone] = [];
            byPhone[phone].push(membership);
          }
        });
      });
    });

    return { state: state, all: all, byId: byId, byPhone: byPhone, duplicateIds: duplicateIds };
  }

  function findContactById(raw, crmContactId) {
    if (!nonEmptyString(String(crmContactId == null ? "" : crmContactId))) return null;
    return buildContactIndex(raw).byId[String(crmContactId)] || null;
  }

  function findContactsByPhone(raw, phoneNumber) {
    var phone = normalizePhone(phoneNumber);
    if (!phone) return [];
    return buildContactIndex(raw).byPhone[phone] || [];
  }

  function normalizeOption(option, index) {
    if (typeof option === "string") {
      if (!option.trim()) return null;
      return { id: option, label: option };
    }
    if (!isObject(option)) return null;
    var label = typeof option.label === "string" ? option.label.trim() : "";
    var id = nonEmptyString(option.id) ? option.id.trim() : label || "option-" + index;
    if (!label) label = id;
    return Object.assign({}, option, { id: id, label: label });
  }

  function normalizeFieldDefinition(definition) {
    if (!isObject(definition)) return null;
    var type = FIELD_TYPES.indexOf(definition.type) >= 0 ? definition.type : "text";
    var id = nonEmptyString(definition.id) ? definition.id.trim() : "";
    var label = nonEmptyString(definition.label) ? definition.label.trim() : "";
    if (!id || !label) return null;
    var options = type === "select" && Array.isArray(definition.options)
      ? definition.options.map(normalizeOption).filter(Boolean)
      : [];
    var seenOptions = Object.create(null);
    options = options.filter(function (option) {
      if (seenOptions[option.id]) return false;
      seenOptions[option.id] = true;
      return true;
    });
    return Object.assign({}, definition, {
      id: id,
      label: label,
      type: type,
      required: definition.required === true,
      options: options
    });
  }

  function normalizeNote(note) {
    if (!isObject(note) || !nonEmptyString(note.id)) return null;
    return Object.assign({}, note, {
      id: note.id.trim(),
      title: typeof note.title === "string" ? note.title : "",
      text: typeof note.text === "string" ? note.text : "",
      author: typeof note.author === "string" ? note.author : "",
      createdAtMs: finiteNumber(note.createdAtMs, 0),
      updatedAtMs: finiteNumber(note.updatedAtMs, finiteNumber(note.createdAtMs, 0))
    });
  }

  function normalizeTaskStatus(status) {
    if (status === "done") return "completed";
    if (status === "pending") return "open";
    return TASK_STATUSES.indexOf(status) >= 0 ? status : "open";
  }

  function normalizeTask(task) {
    if (!isObject(task) || !nonEmptyString(task.id)) return null;
    var status = normalizeTaskStatus(task.status);
    return Object.assign({}, task, {
      id: task.id.trim(),
      title: typeof task.title === "string" ? task.title : "",
      description: typeof task.description === "string" ? task.description : "",
      priority: ["low", "normal", "high"].indexOf(task.priority) >= 0 ? task.priority : "normal",
      status: status,
      dueAtMs: finiteNumber(task.dueAtMs, null),
      action: isObject(task.action) ? clone(task.action) : null,
      actionScheduleId: nonEmptyString(task.actionScheduleId) ? task.actionScheduleId.trim() : null,
      actionStatus: ["none", "scheduled", "executed", "error", "cancelled"].indexOf(task.actionStatus) >= 0 ? task.actionStatus : (isObject(task.action) ? "scheduled" : "none"),
      actionExecutedAtMs: finiteNumber(task.actionExecutedAtMs, null),
      completedAtMs: status === "completed" ? finiteNumber(task.completedAtMs, null) : null,
      createdAtMs: finiteNumber(task.createdAtMs, 0),
      updatedAtMs: finiteNumber(task.updatedAtMs, finiteNumber(task.createdAtMs, 0))
    });
  }

  function normalizeTimelineEvent(event) {
    if (!isObject(event) || !nonEmptyString(event.id)) return null;
    return Object.assign({}, event, {
      id: event.id.trim(),
      type: nonEmptyString(event.type) ? event.type.trim() : "crm_activity",
      title: typeof event.title === "string" ? event.title : "",
      description: typeof event.description === "string" ? event.description : "",
      atMs: finiteNumber(event.atMs, 0),
      source: "crm",
      metadata: isObject(event.metadata) ? clone(event.metadata) : {}
    });
  }

  function normalizeBoardProfile(board) {
    var normalized = isObject(board) ? Object.assign({}, board) : {};
    var definitions = Array.isArray(normalized.fieldDefinitions)
      ? normalized.fieldDefinitions
      : (Array.isArray(normalized.fields) ? normalized.fields : []);
    normalized.fieldDefinitions = definitions.map(normalizeFieldDefinition).filter(Boolean);
    delete normalized.fields;
    return normalized;
  }

  function normalizeContactProfile(profile) {
    var normalized = isObject(profile) ? Object.assign({}, profile) : {};
    normalized.notes = (Array.isArray(normalized.notes) ? normalized.notes : []).map(normalizeNote).filter(Boolean);
    normalized.notesUpdatedAtMs = finiteNumber(normalized.notesUpdatedAtMs, normalized.notes.reduce(function (max, note) { return Math.max(max, finiteNumber(note.updatedAtMs, finiteNumber(note.createdAtMs, 0))); }, 0));
    normalized.fieldValues = isObject(normalized.fieldValues) ? clone(normalized.fieldValues) : {};
    normalized.tasks = (Array.isArray(normalized.tasks) ? normalized.tasks : []).map(normalizeTask).filter(Boolean);
    var timeline = Array.isArray(normalized.timeline) ? normalized.timeline : (Array.isArray(normalized.timelineEvents) ? normalized.timelineEvents : []);
    normalized.timeline = timeline.map(normalizeTimelineEvent).filter(Boolean);
    delete normalized.timelineEvents;
    return normalized;
  }

  function normalizeStore(raw) {
    var source = unwrapState(raw);
    var store = isObject(source) ? Object.assign({}, clone(source)) : {};
    store.version = SCHEMA_VERSION;
    store.schemaVersion = SCHEMA_VERSION;
    store.revision = Math.max(0, Math.floor(finiteNumber(store.revision, 0)));
    store.updatedAtMs = finiteNumber(store.updatedAtMs, 0);

    var rawBoards = isObject(store.boards) ? store.boards : {};
    if (Array.isArray(store.boards)) {
      rawBoards = {};
      store.boards.forEach(function (board) { if (isObject(board) && nonEmptyString(board.id)) rawBoards[board.id] = board; });
    }
    var boards = {};
    Object.keys(rawBoards).forEach(function (boardId) {
      if (isSafeKey(boardId)) boards[boardId] = normalizeBoardProfile(rawBoards[boardId]);
    });
    store.boards = boards;

    var rawContacts = isObject(store.contacts) ? store.contacts : {};
    if (Array.isArray(store.contacts)) {
      rawContacts = {};
      store.contacts.forEach(function (profile) {
        var id = isObject(profile) && (profile.crmContactId || profile.id);
        if (nonEmptyString(id)) rawContacts[id] = profile;
      });
    }
    var contacts = {};
    Object.keys(rawContacts).forEach(function (crmContactId) {
      if (isSafeKey(crmContactId)) contacts[crmContactId] = normalizeContactProfile(rawContacts[crmContactId]);
    });
    store.contacts = contacts;
    return store;
  }

  function serializeStore(raw) {
    return JSON.stringify({ state: normalizeStore(raw), version: SCHEMA_VERSION });
  }

  function validateFieldDefinition(definition) {
    var errors = [];
    if (!isObject(definition)) errors.push("field-invalid");
    else {
      if (!nonEmptyString(definition.id)) errors.push("field-id-required");
      if (!nonEmptyString(definition.label)) errors.push("field-label-required");
      if (FIELD_TYPES.indexOf(definition.type) < 0) errors.push("field-type-invalid");
      if (definition.type === "select") {
        var normalized = (Array.isArray(definition.options) ? definition.options : []).map(normalizeOption).filter(Boolean);
        var seen = Object.create(null);
        if (!normalized.length) errors.push("field-options-required");
        normalized.forEach(function (option) {
          if (seen[option.id]) errors.push("field-option-duplicate");
          seen[option.id] = true;
        });
      }
    }
    return { valid: errors.length === 0, errors: errors, definition: errors.length ? null : normalizeFieldDefinition(definition) };
  }

  function isValidDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    var parts = value.split("-").map(Number);
    var date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
    return date.getUTCFullYear() === parts[0] && date.getUTCMonth() === parts[1] - 1 && date.getUTCDate() === parts[2];
  }

  function validateFieldValue(definition, value) {
    var defCheck = validateFieldDefinition(definition);
    if (!defCheck.valid) return { valid: false, value: null, error: "field-definition-invalid" };
    var def = defCheck.definition;
    var empty = value == null || value === "";
    if (empty) {
      return def.required
        ? { valid: false, value: null, error: "field-value-required" }
        : { valid: true, value: null, error: null };
    }
    if (def.type === "text") return { valid: true, value: String(value), error: null };
    if (def.type === "number") {
      var number = typeof value === "number" ? value : Number(value);
      return Number.isFinite(number)
        ? { valid: true, value: number, error: null }
        : { valid: false, value: null, error: "field-number-invalid" };
    }
    if (def.type === "date") {
      return isValidDate(value)
        ? { valid: true, value: value, error: null }
        : { valid: false, value: null, error: "field-date-invalid" };
    }
    if (def.type === "boolean") {
      return typeof value === "boolean"
        ? { valid: true, value: value, error: null }
        : { valid: false, value: null, error: "field-boolean-invalid" };
    }
    var optionExists = def.options.some(function (option) { return option.id === value; });
    return optionExists
      ? { valid: true, value: value, error: null }
      : { valid: false, value: null, error: "field-option-invalid" };
  }

  function idFactory(options, prefix, seed) {
    options = options || {};
    if (typeof options.createId === "function") {
      var custom = options.createId(prefix, seed);
      if (nonEmptyString(custom)) return custom.trim();
    }
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
    return prefix + "-" + hashText([seed || "", finiteNumber(options.now, Date.now()), Math.random()].join("|"));
  }

  function nowFrom(options) {
    var value = options && options.now;
    if (typeof value === "function") value = value();
    return finiteNumber(value, Date.now());
  }

  function touch(store, now) {
    store.updatedAtMs = now;
    return store;
  }

  function ensureContactProfile(store, crmContactId) {
    if (!nonEmptyString(crmContactId)) throw new TypeError("crmContactId is required");
    if (!isSafeKey(crmContactId)) throw new TypeError("crmContactId is invalid");
    if (!store.contacts[crmContactId]) store.contacts[crmContactId] = normalizeContactProfile({});
    return store.contacts[crmContactId];
  }

  function findFieldDefinition(store, boardId, fieldId) {
    if (!store || !isObject(store.boards)) store = normalizeStore(store);
    var board = store.boards[boardId];
    if (!board) return null;
    return board.fieldDefinitions.find(function (definition) { return definition.id === fieldId; }) || null;
  }

  function appendEventMutable(store, crmContactId, input, options) {
    input = input || {};
    options = options || {};
    var profile = ensureContactProfile(store, crmContactId);
    var atMs = finiteNumber(input.atMs, nowFrom(options));
    var event = normalizeTimelineEvent({
      id: nonEmptyString(input.id) ? input.id : idFactory(options, "crm-event", [crmContactId, input.type, atMs].join("|")),
      type: input.type,
      title: input.title,
      description: input.description,
      atMs: atMs,
      source: "crm",
      metadata: input.metadata
    });
    profile.timeline.push(event);
    return event;
  }

  function addTimelineEvent(raw, crmContactId, input, options) {
    var store = normalizeStore(raw);
    var event = appendEventMutable(store, crmContactId, input, options);
    return { store: touch(store, event.atMs), event: clone(event) };
  }

  function upsertFieldDefinition(raw, boardId, input, options) {
    if (!nonEmptyString(boardId)) throw new TypeError("boardId is required");
    input = Object.assign({}, input || {});
    options = options || {};
    var store = normalizeStore(raw);
    if (!nonEmptyString(input.id)) input.id = idFactory(options, "crm-field", boardId + "|" + (input.label || ""));
    var validation = validateFieldDefinition(input);
    if (!validation.valid) throw new TypeError(validation.errors.join(","));
    var duplicateOwner = null;
    Object.keys(store.boards).some(function (existingBoardId) {
      if (existingBoardId === boardId) return false;
      if (findFieldDefinition(store, existingBoardId, input.id)) duplicateOwner = existingBoardId;
      return !!duplicateOwner;
    });
    if (duplicateOwner) throw new TypeError("field-id-already-used");
    if (!store.boards[boardId]) store.boards[boardId] = normalizeBoardProfile({});
    var definitions = store.boards[boardId].fieldDefinitions;
    var index = definitions.findIndex(function (definition) { return definition.id === input.id; });
    var now = nowFrom(options);
    var definition = Object.assign({}, validation.definition, {
      createdAtMs: index >= 0 ? finiteNumber(definitions[index].createdAtMs, now) : now,
      updatedAtMs: now
    });
    if (index >= 0) definitions[index] = definition;
    else definitions.push(definition);
    return { store: touch(store, now), definition: clone(definition), created: index < 0 };
  }

  function removeFieldDefinition(raw, boardId, fieldId, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var board = store.boards[boardId];
    if (!board) return { store: store, removed: false };
    var before = board.fieldDefinitions.length;
    board.fieldDefinitions = board.fieldDefinitions.filter(function (definition) { return definition.id !== fieldId; });
    var removed = board.fieldDefinitions.length !== before;
    if (removed && options.purgeValues === true) {
      Object.keys(store.contacts).forEach(function (crmContactId) { delete store.contacts[crmContactId].fieldValues[fieldId]; });
    }
    if (removed) touch(store, nowFrom(options));
    return { store: store, removed: removed };
  }

  function reorderFieldDefinition(raw, boardId, fieldId, toIndex, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var board = store.boards[boardId];
    if (!board) return { store: store, moved: false };
    var fromIndex = board.fieldDefinitions.findIndex(function (definition) { return definition.id === fieldId; });
    if (fromIndex < 0) return { store: store, moved: false };
    var destination = Math.max(0, Math.min(board.fieldDefinitions.length - 1, Number(toIndex)));
    if (!Number.isFinite(destination) || destination === fromIndex) return { store: store, moved: false };
    var definition = board.fieldDefinitions.splice(fromIndex, 1)[0];
    board.fieldDefinitions.splice(destination, 0, definition);
    return { store: touch(store, nowFrom(options)), moved: true, definition: clone(definition) };
  }

  function setContactFieldValue(raw, boardId, crmContactId, fieldId, value, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var definition = findFieldDefinition(store, boardId, fieldId);
    if (!definition) throw new TypeError("field-definition-not-found");
    var validation = validateFieldValue(definition, value);
    if (!validation.valid) throw new TypeError(validation.error);
    var profile = ensureContactProfile(store, crmContactId);
    if (validation.value == null) delete profile.fieldValues[fieldId];
    else profile.fieldValues[fieldId] = validation.value;
    var now = nowFrom(options);
    var event = null;
    if (options.recordEvent !== false) {
      event = appendEventMutable(store, crmContactId, {
        type: "field_updated",
        title: definition.label + " atualizado",
        atMs: now,
        metadata: { boardId: boardId, fieldId: fieldId }
      }, options);
    }
    return { store: touch(store, now), value: validation.value, event: clone(event) };
  }

  function addNote(raw, crmContactId, input, options) {
    input = input || {};
    options = options || {};
    if (!nonEmptyString(input.text)) throw new TypeError("note-text-required");
    var store = normalizeStore(raw);
    var profile = ensureContactProfile(store, crmContactId);
    var now = nowFrom(options);
    var note = normalizeNote({
      id: nonEmptyString(input.id) ? input.id : idFactory(options, "crm-note", crmContactId + "|" + now),
      title: typeof input.title === "string" ? input.title.trim().slice(0, 120) : "",
      text: input.text.trim(),
      author: typeof input.author === "string" ? input.author.trim() : "",
      createdAtMs: now,
      updatedAtMs: now
    });
    profile.notes.push(note);
    profile.notesUpdatedAtMs = now;
    var event = options.recordEvent === false ? null : appendEventMutable(store, crmContactId, {
      type: "note_created",
      title: "Nota criada",
      atMs: now,
      metadata: { noteId: note.id }
    }, options);
    return { store: touch(store, now), note: clone(note), event: clone(event) };
  }

  function updateNote(raw, crmContactId, noteId, patch, options) {
    patch = patch || {};
    options = options || {};
    var store = normalizeStore(raw);
    var profile = ensureContactProfile(store, crmContactId);
    var note = profile.notes.find(function (candidate) { return candidate.id === noteId; });
    if (!note) throw new TypeError("note-not-found");
    if (own(patch, "title")) note.title = typeof patch.title === "string" ? patch.title.trim().slice(0, 120) : "";
    if (own(patch, "text")) {
      if (!nonEmptyString(patch.text)) throw new TypeError("note-text-required");
      note.text = patch.text.trim();
    }
    var now = nowFrom(options);
    note.updatedAtMs = now;
    profile.notesUpdatedAtMs = now;
    if (own(patch, "author")) note.author = typeof patch.author === "string" ? patch.author.trim() : "";
    var event = options.recordEvent === false ? null : appendEventMutable(store, crmContactId, {
      type: "note_updated",
      title: "Nota editada",
      atMs: now,
      metadata: { noteId: note.id }
    }, options);
    return { store: touch(store, now), note: clone(note), event: clone(event) };
  }

  function removeNote(raw, crmContactId, noteId, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var profile = ensureContactProfile(store, crmContactId);
    var before = profile.notes.length;
    profile.notes = profile.notes.filter(function (note) { return note.id !== noteId; });
    var removed = profile.notes.length !== before;
    var now = nowFrom(options);
    var event = null;
    if (removed && options.recordEvent !== false) {
      event = appendEventMutable(store, crmContactId, {
        type: "note_removed",
        title: "Nota removida",
        atMs: now,
        metadata: { noteId: noteId }
      }, options);
    }
    if (removed) {
      profile.notesUpdatedAtMs = now;
      touch(store, now);
    }
    return { store: store, removed: removed, event: clone(event) };
  }

  function validateTaskInput(input, partial) {
    var errors = [];
    if (!partial || own(input, "title")) if (!nonEmptyString(input.title)) errors.push("task-title-required");
    if (own(input, "dueAtMs") && input.dueAtMs != null && !Number.isFinite(Number(input.dueAtMs))) errors.push("task-due-invalid");
    if (own(input, "priority") && ["low", "normal", "high"].indexOf(input.priority) < 0) errors.push("task-priority-invalid");
    if (own(input, "status") && TASK_STATUSES.indexOf(input.status) < 0 && input.status !== "done" && input.status !== "pending") errors.push("task-status-invalid");
    return errors;
  }

  function addTask(raw, crmContactId, input, options) {
    input = input || {};
    options = options || {};
    var errors = validateTaskInput(input, false);
    if (errors.length) throw new TypeError(errors.join(","));
    var store = normalizeStore(raw);
    var profile = ensureContactProfile(store, crmContactId);
    var now = nowFrom(options);
    var status = normalizeTaskStatus(input.status);
    var task = normalizeTask(Object.assign({}, input, {
      id: nonEmptyString(input.id) ? input.id : idFactory(options, "crm-task", crmContactId + "|" + now),
      title: input.title.trim(),
      description: typeof input.description === "string" ? input.description : "",
      priority: ["low", "normal", "high"].indexOf(input.priority) >= 0 ? input.priority : "normal",
      status: status,
      dueAtMs: input.dueAtMs == null ? null : Number(input.dueAtMs),
      completedAtMs: status === "completed" ? finiteNumber(input.completedAtMs, now) : null,
      createdAtMs: now,
      updatedAtMs: now
    }));
    profile.tasks.push(task);
    var event = options.recordEvent === false ? null : appendEventMutable(store, crmContactId, {
      type: "task_created",
      title: "Tarefa criada",
      description: task.title,
      atMs: now,
      metadata: { taskId: task.id }
    }, options);
    return { store: touch(store, now), task: clone(task), event: clone(event) };
  }

  function updateTask(raw, crmContactId, taskId, patch, options) {
    patch = patch || {};
    options = options || {};
    var errors = validateTaskInput(patch, true);
    if (errors.length) throw new TypeError(errors.join(","));
    var store = normalizeStore(raw);
    var profile = ensureContactProfile(store, crmContactId);
    var task = profile.tasks.find(function (candidate) { return candidate.id === taskId; });
    if (!task) throw new TypeError("task-not-found");
    var previousStatus = task.status;
    if (own(patch, "title")) task.title = patch.title.trim();
    if (own(patch, "description")) task.description = typeof patch.description === "string" ? patch.description : "";
    if (own(patch, "priority")) task.priority = patch.priority;
    if (own(patch, "dueAtMs")) task.dueAtMs = patch.dueAtMs == null ? null : Number(patch.dueAtMs);
    if (own(patch, "action")) task.action = isObject(patch.action) ? clone(patch.action) : null;
    if (own(patch, "actionScheduleId")) task.actionScheduleId = nonEmptyString(patch.actionScheduleId) ? patch.actionScheduleId.trim() : null;
    if (own(patch, "actionStatus")) task.actionStatus = ["none", "scheduled", "executed", "error", "cancelled"].indexOf(patch.actionStatus) >= 0 ? patch.actionStatus : task.actionStatus;
    if (own(patch, "actionExecutedAtMs")) task.actionExecutedAtMs = patch.actionExecutedAtMs == null ? null : Number(patch.actionExecutedAtMs);
    if (own(patch, "status")) task.status = normalizeTaskStatus(patch.status);
    var now = nowFrom(options);
    task.completedAtMs = task.status === "completed" ? finiteNumber(task.completedAtMs, now) : null;
    task.updatedAtMs = now;
    var event = null;
    if (options.recordEvent !== false && task.status !== previousStatus) {
      event = appendEventMutable(store, crmContactId, {
        type: task.status === "completed" ? "task_completed" : "task_reopened",
        title: task.status === "completed" ? "Tarefa concluída" : "Tarefa reaberta",
        description: task.title,
        atMs: now,
        metadata: { taskId: task.id }
      }, options);
    }
    return { store: touch(store, now), task: clone(task), event: clone(event) };
  }

  function removeTask(raw, crmContactId, taskId, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var profile = ensureContactProfile(store, crmContactId);
    var before = profile.tasks.length;
    profile.tasks = profile.tasks.filter(function (task) { return task.id !== taskId; });
    var removed = profile.tasks.length !== before;
    if (removed) touch(store, nowFrom(options));
    return { store: store, removed: removed };
  }

  function isTaskOverdue(task, now) {
    if (!isObject(task) || normalizeTaskStatus(task.status) !== "open") return false;
    var dueAtMs = finiteNumber(task.dueAtMs, null);
    return dueAtMs != null && dueAtMs < finiteNumber(now, Date.now());
  }

  function getOverdueTasks(raw, now, crmContactId) {
    var store = normalizeStore(raw);
    var result = [];
    Object.keys(store.contacts).forEach(function (id) {
      if (crmContactId && id !== crmContactId) return;
      store.contacts[id].tasks.forEach(function (task) {
        if (isTaskOverdue(task, now)) result.push({ crmContactId: id, task: clone(task) });
      });
    });
    return result.sort(function (left, right) { return left.task.dueAtMs - right.task.dueAtMs; });
  }

  function countTasks(raw, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var allowed = null;
    if (Array.isArray(options.crmContactIds)) {
      allowed = Object.create(null);
      options.crmContactIds.forEach(function (id) { allowed[id] = true; });
    }
    var count = 0;
    Object.keys(store.contacts).forEach(function (crmContactId) {
      if (options.crmContactId && crmContactId !== options.crmContactId) return;
      if (allowed && !allowed[crmContactId]) return;
      store.contacts[crmContactId].tasks.forEach(function (task) {
        if (options.status && task.status !== normalizeTaskStatus(options.status)) return;
        if (options.overdue === true && !isTaskOverdue(task, options.now)) return;
        if (options.overdue === false && isTaskOverdue(task, options.now)) return;
        count++;
      });
    });
    return count;
  }

  function summarizeContact(raw, crmContactId, options) {
    options = options || {};
    var store = normalizeStore(raw);
    var profile = store.contacts[crmContactId];
    if (!profile) return null;
    var notes = profile.notes.slice().sort(function (left, right) { return right.updatedAtMs - left.updatedAtMs; });
    var openTasks = profile.tasks.filter(function (task) { return task.status === "open"; }).sort(function (left, right) {
      if (left.dueAtMs == null) return 1;
      if (right.dueAtMs == null) return -1;
      return left.dueAtMs - right.dueAtMs;
    });
    var timeline = profile.timeline.slice().sort(function (left, right) { return right.atMs - left.atMs; });
    return {
      crmContactId: crmContactId,
      fieldValues: clone(profile.fieldValues),
      noteCount: profile.notes.length,
      latestNote: notes[0] || null,
      taskCount: profile.tasks.length,
      openTaskCount: openTasks.length,
      completedTaskCount: profile.tasks.filter(function (task) { return task.status === "completed"; }).length,
      overdueTaskCount: openTasks.filter(function (task) { return isTaskOverdue(task, options.now); }).length,
      nextTask: openTasks[0] || null,
      recentEvents: timeline.slice(0, Math.max(0, finiteNumber(options.eventLimit, 5)))
    };
  }

  function operationOptions(operation, dependencies) {
    operation = operation || {};
    dependencies = dependencies || {};
    var now = own(operation, "atMs") ? operation.atMs
      : (typeof dependencies.now === "function" ? dependencies.now() : dependencies.now);
    return {
      now: finiteNumber(now, Date.now()),
      createId: typeof dependencies.idFactory === "function" ? dependencies.idFactory : dependencies.createId,
      recordEvent: operation.recordEvent !== false
    };
  }

  function applyOperation(raw, operation, dependencies) {
    if (!isObject(operation) || !nonEmptyString(operation.type)) throw new TypeError("operation-type-required");
    var options = operationOptions(operation, dependencies);
    var crmContactId = operation.crmContactId;
    if (operation.type === "note.add") return addNote(raw, crmContactId, operation.note || operation.value, options);
    if (operation.type === "note.update") return updateNote(raw, crmContactId, operation.noteId, operation.patch, options);
    if (operation.type === "note.remove") return removeNote(raw, crmContactId, operation.noteId, options);
    if (operation.type === "field.upsert") return upsertFieldDefinition(raw, operation.boardId, operation.field || operation.value, options);
    if (operation.type === "field.remove") {
      options.purgeValues = operation.purgeValues === true;
      return removeFieldDefinition(raw, operation.boardId, operation.fieldId, options);
    }
    if (operation.type === "field.reorder") return reorderFieldDefinition(raw, operation.boardId, operation.fieldId, operation.toIndex, options);
    if (operation.type === "fieldValue.set") return setContactFieldValue(raw, operation.boardId, crmContactId, operation.fieldId, operation.value, options);
    if (operation.type === "task.add") return addTask(raw, crmContactId, operation.task || operation.value, options);
    if (operation.type === "task.update") return updateTask(raw, crmContactId, operation.taskId, operation.patch, options);
    if (operation.type === "task.remove") return removeTask(raw, crmContactId, operation.taskId, options);
    if (operation.type === "event.add") return addTimelineEvent(raw, crmContactId, operation.event || operation.value, options);
    throw new TypeError("operation-type-unsupported:" + operation.type);
  }

  function createDashboardSummary(crmRaw, professionalRaw, options) {
    options = options || {};
    var index = buildContactIndex(crmRaw);
    var store = normalizeStore(professionalRaw);
    var boardId = options.boardId || null;
    var memberships = boardId ? index.all.filter(function (entry) { return entry.crmId === boardId; }) : index.all;
    var ids = Object.create(null);
    var byColumn = {};
    index.state.crmList.forEach(function (crm) {
      if (!isObject(crm) || (boardId && crm.id !== boardId)) return;
      (crm.columns || []).forEach(function (column) {
        if (!isObject(column)) return;
        var key = column.id || "";
        if (!byColumn[key]) byColumn[key] = { columnId: column.id || null, title: column.title || "", contactCount: 0 };
      });
    });
    memberships.forEach(function (entry) {
      if (entry.crmContactId) ids[entry.crmContactId] = true;
      var key = entry.columnId || "";
      if (!byColumn[key]) byColumn[key] = { columnId: entry.columnId, title: entry.column && entry.column.title || "", contactCount: 0 };
      byColumn[key].contactCount++;
    });
    var notes = 0;
    var openTasks = 0;
    var completedTasks = 0;
    var overdueTasks = 0;
    var events = [];
    Object.keys(ids).forEach(function (id) {
      var profile = store.contacts[id];
      if (!profile) return;
      notes += profile.notes.length;
      profile.tasks.forEach(function (task) {
        if (task.status === "completed") completedTasks++;
        else if (task.status === "open") {
          openTasks++;
          if (isTaskOverdue(task, options.now)) overdueTasks++;
        }
      });
      profile.timeline.forEach(function (event) { events.push(Object.assign({ crmContactId: id }, clone(event))); });
    });
    events.sort(function (left, right) { return right.atMs - left.atMs; });
    return {
      boardId: boardId,
      contactCount: memberships.length,
      uniqueContactCount: Object.keys(ids).length,
      columnCount: Object.keys(byColumn).length,
      noteCount: notes,
      openTaskCount: openTasks,
      completedTaskCount: completedTasks,
      overdueTaskCount: overdueTasks,
      byColumn: Object.keys(byColumn).map(function (key) { return byColumn[key]; }),
      recentEvents: events.slice(0, Math.max(0, finiteNumber(options.eventLimit, 10)))
    };
  }

  function createDockedContactSummary(crmRaw, professionalRaw, crmContactId, options) {
    options = options || {};
    var membership = findContactById(crmRaw, crmContactId);
    var store = normalizeStore(professionalRaw);
    var profile = store.contacts[crmContactId] || normalizeContactProfile({});
    if (!membership && !store.contacts[crmContactId]) return null;
    var openTasks = profile.tasks.filter(function (task) { return task.status === "open"; });
    openTasks.sort(function (left, right) {
      if (left.dueAtMs == null) return 1;
      if (right.dueAtMs == null) return -1;
      return left.dueAtMs - right.dueAtMs;
    });
    var timeline = profile.timeline.slice().sort(function (left, right) { return right.atMs - left.atMs; });
    var notes = profile.notes.slice().sort(function (left, right) { return right.updatedAtMs - left.updatedAtMs; });
    return {
      crmContactId: crmContactId,
      contact: membership ? clone(membership.item.contact) : null,
      crmId: membership ? membership.crmId : null,
      crmName: membership && membership.crm ? membership.crm.name || "" : "",
      columnId: membership ? membership.columnId : null,
      columnTitle: membership && membership.column ? membership.column.title || "" : "",
      fieldValues: clone(profile.fieldValues),
      noteCount: profile.notes.length,
      latestNote: notes[0] || null,
      openTaskCount: openTasks.length,
      overdueTaskCount: openTasks.filter(function (task) { return isTaskOverdue(task, options.now); }).length,
      nextTask: openTasks[0] || null,
      recentEvents: timeline.slice(0, Math.max(0, finiteNumber(options.eventLimit, 5)))
    };
  }

  function getQueue(adapter, key) {
    if (!sharedQueues) return null;
    var byKey = sharedQueues.get(adapter);
    if (!byKey) {
      byKey = Object.create(null);
      sharedQueues.set(adapter, byKey);
    }
    if (!byKey[key]) byKey[key] = Promise.resolve();
    return byKey;
  }

  function enqueue(adapter, key, operation) {
    var byKey = getQueue(adapter, key);
    if (!byKey) return Promise.resolve().then(operation);
    var job = byKey[key].catch(function () {}).then(operation);
    byKey[key] = job.then(function () {}, function () {});
    return job;
  }

  function createRepository(adapter, options) {
    options = options || {};
    if (!adapter || (typeof adapter.read !== "function" && typeof adapter.get !== "function")) throw new TypeError("repository adapter requires read/get");
    if (typeof adapter.write !== "function" && typeof adapter.set !== "function") throw new TypeError("repository adapter requires write/set");
    var key = options.key || STORE_KEY;

    function repositoryNow(callOptions) {
      if (callOptions && own(callOptions, "now")) return nowFrom(callOptions);
      if (own(options, "now")) return nowFrom({ now: options.now });
      if (own(adapter, "now")) return nowFrom({ now: adapter.now });
      return Date.now();
    }

    function readRaw() {
      var operation = typeof adapter.read === "function" ? adapter.read(key) : adapter.get(key);
      return Promise.resolve(operation).then(function (value) {
        return isObject(value) && own(value, key) ? value[key] : value;
      });
    }

    function writeRaw(value) {
      return Promise.resolve(typeof adapter.write === "function" ? adapter.write(key, value) : adapter.set(key, value));
    }

    function exclusively(operation) {
      return typeof adapter.runExclusive === "function" ? adapter.runExclusive(key, operation) : operation();
    }

    function read() {
      return enqueue(adapter, key, function () { return readRaw().then(decodeRepositoryStore).then(normalizeStore); });
    }

    function replace(next, replaceOptions) {
      replaceOptions = replaceOptions || {};
      return enqueue(adapter, key, function () {
        return exclusively(async function () {
          var current = normalizeStore(decodeRepositoryStore(await readRaw()));
          var normalized = normalizeStore(next);
          normalized.revision = current.revision + 1;
          normalized.updatedAtMs = repositoryNow(replaceOptions);
          await writeRaw(serializeStore(normalized));
          return normalized;
        });
      });
    }

    function update(mutator, updateOptions) {
      if (typeof mutator !== "function") return Promise.reject(new TypeError("repository update requires a mutator"));
      updateOptions = updateOptions || {};
      return enqueue(adapter, key, function () {
        return exclusively(async function () {


          var current = normalizeStore(decodeRepositoryStore(await readRaw()));
          var draft = clone(current);
          var output = await mutator(draft);
          var candidate = draft;
          if (isObject(output) && isObject(output.store)) candidate = output.store;
          else if (isObject(output) && isObject(output.state)) candidate = output.state;
          else if (isObject(output) && (own(output, "contacts") || own(output, "boards"))) candidate = output;
          var next = normalizeStore(candidate);
          next.revision = current.revision + 1;
          next.updatedAtMs = repositoryNow(updateOptions);
          await writeRaw(serializeStore(next));
          return { state: next, result: output };
        });
      });
    }

    function apply(operation, applyOptions) {
      var dependencies = {
        idFactory: options.idFactory || adapter.idFactory,
        now: own(applyOptions || {}, "now") ? applyOptions.now : (options.now || adapter.now)
      };
      return update(function (current) { return applyOperation(current, operation, dependencies); }, applyOptions);
    }

    return Object.freeze({ key: key, read: read, replace: replace, update: update, apply: apply });
  }

  function createChromeStorageAdapter(storageArea, runtime) {
    if (!storageArea || typeof storageArea.get !== "function" || typeof storageArea.set !== "function") throw new TypeError("A área de dados informada é inválida");
    function lastError() {
      return runtime && runtime.lastError ? new Error(runtime.lastError.message || String(runtime.lastError)) : null;
    }
    return {
      read: function (key) {
        return new Promise(function (resolve, reject) {
          storageArea.get(key, function (result) {
            var error = lastError();
            if (error) reject(error);
            else resolve(result && result[key]);
          });
        });
      },
      write: function (key, value) {
        return new Promise(function (resolve, reject) {
          var payload = {}; payload[key] = value;
          storageArea.set(payload, function () {
            var error = lastError();
            if (error) reject(error);
            else resolve();
          });
        });
      }
    };
  }

  return Object.freeze({
    STORE_KEY: STORE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    FIELD_TYPES: FIELD_TYPES,
    TASK_STATUSES: TASK_STATUSES,
    normalizeCrmState: normalizeCrmState,
    getCrmContactId: getCrmContactId,
    createLegacyContactId: createLegacyContactId,
    upgradeLegacyContactIds: upgradeLegacyContactIds,
    normalizePhone: normalizePhone,
    buildContactIndex: buildContactIndex,
    findContactById: findContactById,
    findContactsByPhone: findContactsByPhone,
    normalizeStore: normalizeStore,
    serializeStore: serializeStore,
    normalizeFieldDefinition: normalizeFieldDefinition,
    validateFieldDefinition: validateFieldDefinition,
    validateFieldValue: validateFieldValue,
    findFieldDefinition: findFieldDefinition,
    upsertFieldDefinition: upsertFieldDefinition,
    removeFieldDefinition: removeFieldDefinition,
    reorderFieldDefinition: reorderFieldDefinition,
    setContactFieldValue: setContactFieldValue,
    addNote: addNote,
    updateNote: updateNote,
    removeNote: removeNote,
    addTask: addTask,
    updateTask: updateTask,
    removeTask: removeTask,
    isTaskOverdue: isTaskOverdue,
    getOverdueTasks: getOverdueTasks,
    countTasks: countTasks,
    addTimelineEvent: addTimelineEvent,
    applyOperation: applyOperation,
    summarizeContact: summarizeContact,
    createDashboardSummary: createDashboardSummary,
    createDockedContactSummary: createDockedContactSummary,
    createRepository: createRepository,
    createChromeStorageAdapter: createChromeStorageAdapter
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
