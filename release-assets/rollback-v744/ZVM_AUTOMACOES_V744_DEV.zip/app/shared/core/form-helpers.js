(function (global) {
  "use strict";
  var core = global.ExtensionCore = global.ExtensionCore || {};
  var LABELS = Object.freeze({
    contains: "Contém",
    notContains: "Não contém",
    equals: "É igual a",
    startsWith: "Começa com",
    endsWith: "Termina com"
  });
  var ALIASES = Object.freeze({
    contains: "contains",
    contem: "contains",
    "contém": "contains",
    notcontains: "notContains",
    "not_contains": "notContains",
    "naocontem": "notContains",
    "não contém": "notContains",
    equals: "equals",
    equal: "equals",
    igual: "equals",
    eiguala: "equals",
    "é igual a": "equals",
    startswith: "startsWith",
    "starts_with": "startsWith",
    "comecacom": "startsWith",
    "começa com": "startsWith",
    endswith: "endsWith",
    "ends_with": "endsWith",
    "terminacom": "endsWith",
    "termina com": "endsWith"
  });

  function text(value) {
    return value == null ? "" : String(value);
  }

  function trim(value) {
    return text(value).replace(/\s+/g, " ").trim();
  }

  function fold(value) {
    var out = trim(value).toLocaleLowerCase("pt-BR");
    try { out = out.normalize("NFD").replace(/[\u0300-\u036f]/g, ""); } catch (_) {}
    return out;
  }

  function digits(value, maxLength) {
    var out = text(value).replace(/\D+/g, "");
    if (Number.isFinite(maxLength) && maxLength > 0) out = out.slice(0, maxLength);
    return out;
  }

  function maskCep(value) {
    var raw = digits(value, 8);
    return raw.length > 5 ? raw.slice(0, 5) + "-" + raw.slice(5) : raw;
  }

  function normalizeOperator(value) {
    var raw = trim(value);
    if (Object.prototype.hasOwnProperty.call(LABELS, raw)) return raw;
    var key = fold(raw).replace(/\s+/g, "");
    return ALIASES[key] || ALIASES[fold(raw)] || "contains";
  }

  function operatorLabel(value) {
    var token = normalizeOperator(value);
    return LABELS[token] || LABELS.contains;
  }

  function compareOne(type, haystack, needle) {
    if (type === "startsWith") return haystack.indexOf(needle) === 0;
    if (type === "endsWith") return haystack.slice(-needle.length) === needle;
    if (type === "equals") return haystack === needle;
    if (type === "notContains") return haystack.indexOf(needle) < 0;
    return haystack.indexOf(needle) >= 0;
  }

  function matchesTextRule(rule, inputText, caseSensitive) {
    rule = rule && typeof rule === "object" ? rule : {};
    var type = normalizeOperator(rule.type || "contains");
    var needles = Array.isArray(rule.keywords) ? rule.keywords.map(text).filter(Boolean) : [];
    if (!needles.length) return false;
    var haystack = text(inputText);
    if (!caseSensitive) {
      haystack = haystack.toLocaleLowerCase("pt-BR");
      needles = needles.map(function (item) { return item.toLocaleLowerCase("pt-BR"); });
    }
    if (type === "notContains") return needles.every(function (needle) { return compareOne(type, haystack, needle); });
    return needles.some(function (needle) { return compareOne(type, haystack, needle); });
  }

  function matchesRuleSet(rules, inputText, caseSensitive) {
    rules = Array.isArray(rules) ? rules.filter(Boolean) : [];
    if (!rules.length) return false;
    var positive = rules.filter(function (rule) { return normalizeOperator(rule.type) !== "notContains"; });
    var negative = rules.filter(function (rule) { return normalizeOperator(rule.type) === "notContains"; });
    var positiveMatch = positive.length === 0 || positive.some(function (rule) { return matchesTextRule(rule, inputText, caseSensitive); });
    return positiveMatch && negative.every(function (rule) { return matchesTextRule(rule, inputText, caseSensitive); });
  }

  function focusables(root) {
    if (!root || !root.querySelectorAll) return [];
    return Array.prototype.slice.call(root.querySelectorAll('input,textarea,select,button,a[href],[contenteditable="true"],[tabindex]:not([tabindex="-1"])'));
  }

  function focusSignature(node, index) {
    return {
      id: node.id || "",
      name: node.getAttribute && (node.getAttribute("name") || ""),
      key: node.getAttribute && (node.getAttribute("data-extui-focus-key") || ""),
      aria: node.getAttribute && (node.getAttribute("aria-label") || ""),
      placeholder: node.getAttribute && (node.getAttribute("placeholder") || ""),
      tag: String(node.tagName || "").toLowerCase(),
      type: node.getAttribute && (node.getAttribute("type") || ""),
      index: index,
      start: typeof node.selectionStart === "number" ? node.selectionStart : null,
      end: typeof node.selectionEnd === "number" ? node.selectionEnd : null
    };
  }

  function captureView(root) {
    if (!root || !root.querySelectorAll) return null;
    var active = root.ownerDocument && root.ownerDocument.activeElement;
    var focus = null;
    if (active && root.contains(active)) {
      var all = focusables(root);
      focus = focusSignature(active, all.indexOf(active));
    }
    var scroll = [];
    root.querySelectorAll("[data-extui-preserve-scroll],.extuiCrmHub,.extui-board,.extuiCrmKanban").forEach(function (node, index) {
      if (node.scrollTop || node.scrollLeft) {
        scroll.push({
          index: index,
          id: node.id || "",
          key: node.getAttribute && (node.getAttribute("data-extui-preserve-scroll") || ""),
          top: node.scrollTop,
          left: node.scrollLeft
        });
      }
    });
    return { focus: focus, scroll: scroll };
  }

  function restoreView(root, state) {
    if (!root || !state) return;
    var scrollers = root.querySelectorAll ? Array.prototype.slice.call(root.querySelectorAll("[data-extui-preserve-scroll],.extuiCrmHub,.extui-board,.extuiCrmKanban")) : [];
    (state.scroll || []).forEach(function (item) {
      var node = null;
      if (item.id) node = scrollers.find(function (candidate) { return candidate.id === item.id; }) || null;
      if (!node && item.key) node = scrollers.find(function (candidate) { return candidate.getAttribute && candidate.getAttribute("data-extui-preserve-scroll") === item.key; }) || null;
      if (!node) node = scrollers[item.index] || null;
      if (node) { node.scrollTop = item.top || 0; node.scrollLeft = item.left || 0; }
    });
    if (!state.focus) return;
    var all = focusables(root);
    var target = null;
    if (state.focus.id) target = all.find(function (node) { return node.id === state.focus.id; }) || null;
    if (!target && state.focus.name) target = all.find(function (node) { return node.getAttribute && node.getAttribute("name") === state.focus.name; }) || null;
    if (!target && state.focus.key) target = all.find(function (node) { return node.getAttribute && node.getAttribute("data-extui-focus-key") === state.focus.key; }) || null;
    if (!target && state.focus.aria) target = all.find(function (node) { return String(node.tagName || "").toLowerCase() === state.focus.tag && (node.getAttribute("aria-label") || "") === state.focus.aria; }) || null;
    if (!target && state.focus.placeholder) target = all.find(function (node) { return String(node.tagName || "").toLowerCase() === state.focus.tag && (node.getAttribute("placeholder") || "") === state.focus.placeholder; }) || null;
    if (!target && state.focus.index >= 0 && all[state.focus.index]) {
      var indexed = all[state.focus.index];
      if (String(indexed.tagName || "").toLowerCase() === state.focus.tag && (!state.focus.type || (indexed.getAttribute("type") || "") === state.focus.type)) target = indexed;
    }
    if (target && typeof target.focus === "function") {
      try { target.focus({ preventScroll: true }); } catch (_) { target.focus(); }
      if (typeof target.setSelectionRange === "function" && state.focus.start != null) {
        try { target.setSelectionRange(state.focus.start, state.focus.end == null ? state.focus.start : state.focus.end); } catch (_) {}
      }
    }
  }


  function isOwned(node) {
    if (!node || node.nodeType !== 1) return false;
    var doc = node.ownerDocument;
    if (doc && doc.documentElement && doc.documentElement.id === "extappDashboard") return true;
    if (node.id && (node.id.indexOf("extui") === 0 || node.id.indexOf("extapp") === 0)) return true;
    if (node.closest) return !!node.closest('[id^="extui"],[id^="extapp"],[class*="extui"],[class*="extapp"]');
    return false;
  }

  function prepareInput(input) {
    if (!input || input.nodeType !== 1 || !isOwned(input)) return;
    var type = (input.getAttribute("type") || "text").toLowerCase();
    var identity = fold([input.id, input.getAttribute("name"), input.getAttribute("placeholder"), input.getAttribute("aria-label")].filter(Boolean).join(" "));
    var isCep = /\bcep\b|codigo postal|postal/.test(identity);
    if (type === "email") {
      if (!input.getAttribute("inputmode")) input.setAttribute("inputmode", "email");
      if (!input.getAttribute("autocomplete")) input.setAttribute("autocomplete", "email");
    } else if (type === "tel" || /telefone|celular|whatsapp|phone/.test(identity)) {
      if (!input.getAttribute("inputmode")) input.setAttribute("inputmode", "tel");
      if (!input.getAttribute("autocomplete")) input.setAttribute("autocomplete", "tel");
    } else if (isCep) {
      if (!input.getAttribute("inputmode")) input.setAttribute("inputmode", "numeric");
      if (!input.getAttribute("autocomplete")) input.setAttribute("autocomplete", "postal-code");
    }
    if (input.required && !input.getAttribute("aria-required")) input.setAttribute("aria-required", "true");
    if (input.dataset && input.dataset.extuiFormHelpersBound !== "1") {
      input.dataset.extuiFormHelpersBound = "1";
      input.addEventListener("invalid", function () { input.setAttribute("aria-invalid", "true"); });
      input.addEventListener("input", function () {
        if (isCep && typeof input.value === "string") input.value = maskCep(input.value);
        if (typeof input.checkValidity !== "function" || input.checkValidity()) input.removeAttribute("aria-invalid");
      });
      input.addEventListener("change", function () { if (typeof input.checkValidity !== "function" || input.checkValidity()) input.removeAttribute("aria-invalid"); });
    }
  }

  function localizeOperatorOptions(root) {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll("option").forEach(function (option) {
      if (!isOwned(option)) return;
      var value = option.value;
      if (Object.prototype.hasOwnProperty.call(LABELS, value) && trim(option.textContent) === value) option.textContent = LABELS[value];
    });
  }

  function enhance(root) {
    if (!root) return;
    if (root.matches && root.matches("input,textarea,select")) prepareInput(root);
    if (root.querySelectorAll) root.querySelectorAll("input,textarea,select").forEach(prepareInput);
    localizeOperatorOptions(root);
  }

  var observer = null;
  function start() {
    if (!global.document || observer || typeof global.MutationObserver !== "function") return;
    enhance(global.document.documentElement);
    observer = new global.MutationObserver(function (records) {
      records.forEach(function (record) {
        Array.prototype.forEach.call(record.addedNodes || [], function (node) { if (node && node.nodeType === 1) enhance(node); });
      });
    });
    observer.observe(global.document.documentElement, { childList: true, subtree: true });
  }

  core.FormHelpers = Object.freeze({
    labels: LABELS,
    trim: trim,
    normalizeSearch: fold,
    digits: digits,
    maskCep: maskCep,
    normalizeOperator: normalizeOperator,
    operatorLabel: operatorLabel,
    matchesTextRule: matchesTextRule,
    matchesRuleSet: matchesRuleSet,
    captureView: captureView,
    restoreView: restoreView,
    enhance: enhance,
    start: start
  });

  start();
})(typeof window !== "undefined" ? window : globalThis);
