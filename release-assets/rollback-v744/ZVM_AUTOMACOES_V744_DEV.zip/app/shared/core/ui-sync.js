try{
(function (root) {
  "use strict";
  if (root.__extUISyncBooted || !root.ExtensionStorage) return;
  root.__extUISyncBooted = true;
  var listeners = new Set();
  var pendingKeys = new Set();
  var pendingDomains = new Set();
  var pendingExternal = false;
  var pendingExternalKeys = new Set();
  var pendingExternalDomains = new Set();
  var scheduled = false;

  function domainFor(key) {
    try { var d = root.ExtensionStorage.describe && root.ExtensionStorage.describe(key); return d && d.domain ? String(d.domain) : "other"; } catch (_) { return "other"; }
  }
  function expectLocalEcho(keys, ttlMs) {
    if (root.ExtensionStorage && typeof root.ExtensionStorage.expectLocalEcho === "function") return root.ExtensionStorage.expectLocalEcho(keys, ttlMs);
    return function () {};
  }
  function flush() {
    scheduled = false;
    if (!pendingKeys.size) return;
    var detail = Object.freeze({
      keys: Object.freeze(Array.from(pendingKeys)),
      domains: Object.freeze(Array.from(pendingDomains)),
      externalKeys: Object.freeze(Array.from(pendingExternalKeys)),
      externalDomains: Object.freeze(Array.from(pendingExternalDomains)),
      external: pendingExternal,
      at: Date.now()
    });
    pendingKeys.clear(); pendingDomains.clear(); pendingExternalKeys.clear(); pendingExternalDomains.clear(); pendingExternal = false;
    listeners.forEach(function (entry) {
      if (!entry || typeof entry.fn !== "function") return;
      var match = entry.domains === "*" || detail.domains.some(function (d) { return entry.domains.has(d); });
      if (match) try { entry.fn(detail); } catch (err) { if(root.__extReportRuntimeError)root.__extReportRuntimeError("UI_SYNC_LISTENER_FAILED",err); }
    });
    try { root.dispatchEvent(new CustomEvent("ext:ui-sync", { detail: detail })); } catch (_) {}
    try { if (root.document) root.document.dispatchEvent(new CustomEvent("ext:data-sync", { detail: detail })); } catch (_) {}
  }
  function queue(key, meta) {
    key = String(key || "");
    var domain = domainFor(key);
    pendingKeys.add(key);
    pendingDomains.add(domain);
    var isLocal = !!(meta && meta.local === true);
    if (!isLocal) { pendingExternal = true; pendingExternalKeys.add(key); pendingExternalDomains.add(domain); }
    if (!scheduled) { scheduled = true; Promise.resolve().then(flush); }
  }
  var storageUnsubscribe = null;
  function ensureStorageBinding() {
    if (storageUnsubscribe || !root.ExtensionStorage || typeof root.ExtensionStorage.subscribe !== "function") return;
    storageUnsubscribe = root.ExtensionStorage.subscribe("*", function (next, previous, key, meta) { queue(key, meta); });
  }
  function subscribe(domains, fn) {
    if (typeof fn !== "function") throw new TypeError("subscribe exige função");
    var normalized = domains === "*" ? "*" : new Set((Array.isArray(domains) ? domains : [domains]).map(String));
    var entry = { domains: normalized, fn: fn }; listeners.add(entry);
    ensureStorageBinding();
    return function () {
      listeners.delete(entry);
      if (!listeners.size && storageUnsubscribe) { try { storageUnsubscribe(); } catch (_) {} storageUnsubscribe = null; }
    };
  }
  var api = Object.freeze({ version: "1.2.0", subscribe: subscribe, domainFor: domainFor, expectLocalEcho: expectLocalEcho });
  root.ExtensionCore = root.ExtensionCore || {}; root.ExtensionCore.UISync = api;
})(window);
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
