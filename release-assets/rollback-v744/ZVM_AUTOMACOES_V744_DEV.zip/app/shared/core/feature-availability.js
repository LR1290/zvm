;(function(root){
  'use strict';
  var core=root.ExtensionCore=root.ExtensionCore||{};
  var STATES={active:true,hidden:true,dormant:true};
  function deepFreeze(value){
    if(!value||typeof value!=='object'||Object.isFrozen(value))return value;
    Object.keys(value).forEach(function(key){deepFreeze(value[key]);});
    return Object.freeze(value);
  }
  var REGISTRY=deepFreeze({
    tutorials:{
      id:'tutorials',
      state:'dormant',
      owner:'product',
      since:'0.8.539',
      reason:'Temporariamente removido da experiência pública',
      restoration:'change-policy-and-release',
      surfaces:{
        onboarding:false,
        shell:false,
        shellGuideActions:false,
        panelTutorialButton:false,
        tutorialLookup:false
      }
    }
  });
  function normalizeId(id){return String(id==null?'':id).trim();}
  function get(id){var key=normalizeId(id);return Object.prototype.hasOwnProperty.call(REGISTRY,key)?REGISTRY[key]:null;}
  function resolveUnknown(id,surface,options){
    var requireRegistered=!!(options&&options.requireRegistered===true);
    return Object.freeze({feature:normalizeId(id),registered:false,canonicalState:'unregistered',effectiveState:requireRegistered?'dormant':'active',surface:surface||null,canonicalSurface:null,override:null,allowed:!requireRegistered,reason:requireRegistered?'feature-unregistered':'legacy-unenrolled'});
  }
  function canonicalDecision(id,surface,options){
    var entry=get(id);
    if(!entry)return resolveUnknown(id,surface,options);
    var overrideOwner=core.DevFeatureOverrides,override=overrideOwner&&typeof overrideOwner.getOverride==='function'?overrideOwner.getOverride(entry.id):null;
    var effectiveState=override==='active'?'active':entry.state;
    var operational=effectiveState==='active'||effectiveState==='hidden';
    var canonicalSurface=surface?entry.surfaces[surface]!==false:null;
    var surfaceAllowed=surface?(override==='active'?true:canonicalSurface):true;
    var allowed=operational&&surfaceAllowed;
    return Object.freeze({feature:entry.id,registered:true,canonicalState:entry.state,effectiveState:effectiveState,surface:surface||null,canonicalSurface:canonicalSurface,override:override,allowed:allowed,reason:allowed?(override==='active'?'dev-override':'available'):effectiveState==='dormant'?'feature-dormant':'surface-hidden'});
  }
  function ready(){var owner=core.DevFeatureOverrides;return owner&&typeof owner.ready==='function'?Promise.resolve(owner.ready()).then(function(){return true;}):Promise.resolve(true);}
  function getEffective(id,options){return canonicalDecision(id,null,options);}
  function isOperational(id,options){return getEffective(id,options).allowed===true;}
  function isSurfaceVisible(id,surface,options){return canonicalDecision(id,String(surface||''),options).allowed===true;}
  function explain(id,surface,options){return canonicalDecision(id,surface?String(surface):null,options);}
  function list(){return Object.freeze(Object.keys(REGISTRY).map(function(key){return REGISTRY[key];}));}
  core.FeatureAvailability=Object.freeze({
    schema:1,
    states:Object.freeze(Object.keys(STATES)),
    get:get,
    ready:ready,
    getEffective:getEffective,
    isOperational:isOperational,
    isSurfaceVisible:isSurfaceVisible,
    explain:explain,
    list:list
  });
})(typeof globalThis!=='undefined'?globalThis:this);
