;
try{
(function () {
  "use strict";
  if (window.__extS0) return;

  var _0 = "EXTUI:license";
  var _1 = 20000;
  var _2 = 500;
  var _3 = 5 * 60 * 1000;
  var _4 = 5 * 60 * 1000;
  var _5 = 45000;
  var _6 = null;
  var _7 = false;
  var _8 = null;

  var _9 = {
    keyNotFound: "Chave não encontrada. Verifique se copiou corretamente ou contate o vendedor.",
    keyExpired: "Sua chave expirou. Renove-a ou entre em contato com o suporte.",
    keyBlocked: "Sua chave está bloqueada. Entre em contato com o suporte.",
    phoneLimitGlobal: "Limite máximo de dispositivos atingido para esta chave.",
    activationFailed: "Falha ao ativar a chave. Tente novamente em instantes.",
    rateLimited: "O servidor bloqueou novas tentativas por segurança. Aguarde cerca de 5 minutos e tente uma única vez. Sua chave não foi invalidada.",
    invalidRequest: "Requisição inválida.",
    networkError: "Erro de conexão. Verifique sua internet e tente novamente.",
    serverUnavailable: "Servidor de licenciamento temporariamente indisponível. Tente novamente em instantes.",
    phoneUnavailable: "Não foi possível identificar o WhatsApp conectado. Aguarde o carregamento do WhatsApp Web e tente novamente.",
    phone_removed: "Este número foi desvinculado desta chave. Contate o vendedor ou ative novamente.",
    expired: "Sua licença expirou. Renove-a para continuar usando a extensão.",
    validationUnavailable: "Não foi possível confirmar a licença com o servidor.",
    EXTENSION_INTEGRITY_FAILED: "A instalação da extensão foi alterada ou está incompleta. Reinstale a versão oficial.",
    EXTENSION_INTEGRITY_RESOURCE_MISSING: "A instalação da extensão está incompleta. Reinstale a versão oficial.",
    EXTENSION_INTEGRITY_VERSION_MISMATCH: "A instalação da extensão contém arquivos de versões diferentes. Reinstale a versão oficial.",
    EXTENSION_INTEGRITY_MANIFEST_INVALID: "Não foi possível validar esta instalação da extensão. Recarregue a extensão e, se necessário, reinstale a versão oficial.",
    BUILD_NOT_ALLOWED: "Esta versão da extensão não foi reconhecida pelo servidor. Atualize ou reinstale a versão oficial.",
    SERVER_AUTHORITY_UNAVAILABLE: "Não foi possível renovar a autorização de segurança com o servidor da extensão. Tente novamente em instantes.",
    SERVER_CAPABILITY_REQUIRED: "A autorização de segurança desta sessão expirou. Reconecte a extensão e tente novamente.",
    SERVER_CAPABILITY_INVALID: "O servidor recusou a autorização de segurança desta sessão. Reconecte a extensão.",
    SERVER_SECURITY_DOWNGRADE_BLOCKED: "A proteção exigida pelo servidor não está disponível nesta instalação. Atualize ou reinstale a extensão oficial.",
    SECURITY_BINDING_REQUIRED: "Não foi possível vincular esta instalação à sessão. Reabra o WhatsApp Web e tente novamente.",
    unknown: "Não foi possível validar sua chave. Tente novamente ou contate o suporte."
  };

  function _a(state, extra) {
    try { window.dispatchEvent(new CustomEvent("extui-s0-state", { detail: Object.assign({ state: state }, extra || {}) })); }
    catch (_) {}
  }

  function _b(key) {
    return new Promise(function (resolve, reject) {
      try { chrome.storage.local.get(key, function (res) { if (chrome.runtime && chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message || "STORAGE_READ_FAILED")); return; } resolve(res && res[key]); }); }
      catch (err) { reject(err); }
    });
  }

  async function _c(forceFresh) {
    if (_6 && !forceFresh) return _6;
    _6 = (await _b(_0)) || { authenticated: false };
    return _6;
  }

  function _d(cache) {
    return !!(cache && cache.authenticated === true && cache.credentialPresent === true);
  }

  function _e(message) {
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        reject(new Error("LICENSE_WORKER_TIMEOUT"));
      }, _5);
      try {
        chrome.runtime.sendMessage(message, function (response) {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          if (chrome.runtime.lastError) { reject(chrome.runtime.lastError); return; }
          if (!response || response.ok !== true) {
            var err = new Error(response && response.userMessage || "Falha ao validar licença.");
            err.code = response && response.errorCode || "LICENSE_ERROR";
            reject(err);
            return;
          }
          resolve(response.result || {});
        });
      } catch (err) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(err);
      }
    });
  }

  function _f(forceNetwork) {
    if (_8) return _8;
    var wrapped = _e({ type: "EXTUI_S0_C", forceNetwork: forceNetwork === true });
    _8 = wrapped;
    wrapped.then(function () { if (_8 === wrapped) _8 = null; }, function () { if (_8 === wrapped) _8 = null; });
    return wrapped;
  }

  function _g(timeoutMs) {
    return new Promise(function (resolve) {
      var waited = 0;
      (function tick() {
        _b("EXTUI:wppPhoneNumber").then(function (phone) {
          if (phone) { resolve(phone); return; }
          waited += _2;
          if (waited >= timeoutMs) { resolve(null); return; }
          setTimeout(tick, _2);
        }).catch(function (err) {
          if(window.__extReportRuntimeError)window.__extReportRuntimeError("SESSION_PHONE_STORAGE_READ_FAILED",err);
          waited += _2;
          if (waited >= timeoutMs) { resolve(null); return; }
          setTimeout(tick, _2);
        });
      })();
    });
  }

  async function _h(rawKey) {
    var key = String(rawKey || "").trim();
    if (!key) return { ok: false, authError: "keyNotFound", message: _9.keyNotFound };
    var phone = await _b("EXTUI:wppPhoneNumber");
    if (!phone) {
      _a("waitingForPhone", {});
      phone = await _g(_1);
    }
    if (!phone) return { ok: false, authError: "phoneUnavailable", message: _9.phoneUnavailable, retryable: true };
    try {
      var result = await _e({ type: "EXTUI_S0_A", authKey: key });
      _6 = result.license || await _c(true);
      _q();
      _a("restored", { reason: "_h" });
      return { ok: true, license: _6 };
    } catch (err) {
      var code = err && err.code || "unknown";
      return { ok: false, authError: code, message: _9[code] || err.message || _9.unknown, retryable: /network|unavailable|timeout/i.test(code) };
    }
  }

  async function _i() {
    try {
      await _e({ type: "EXTUI_S0_B" });
      _6 = { authenticated: false };
      _a("_i", {});
      return true;
    } catch (err) {
      if (window.__extReportRuntimeError) window.__extReportRuntimeError("SESSION_LOGOUT_FAILED", err);
      throw err;
    }
  }

  async function _n(feature) {
    try {
      var result = await _e({ type: "EXTUI_S0_D", feature: String(feature || "") });
      return result.authorized === true && result.enabled === true;
    } catch (_) { return false; }
  }

  async function _o() {
    try {
      var result = await _f(true);
      _6 = result.license || await _c(true);
      if (result.authorized === true) {
        if (result.grace) _a("offlineGrace", { reason: result.reason });
        else _a("restored", { reason: result.reason });
        return { active: true, retryable: !!result.grace, reason: result.reason, grace: !!result.grace };
      }
      if (result.reason === "validationUnavailable") _a("validationUnavailable", { reason: result.reason });
      else if (result.reason === "expired" || result.active === false) _a("forceLogout", { reason: result.reason || "inactive" });
      return { active: false, blocked: true, reason: result.reason || "validationFailed" };
    } catch (err) {
      _a("validationUnavailable", { reason: err && err.code || "workerError" });
      return { active: false, blocked: true, reason: "validationUnavailable" };
    }
  }

  async function _p() {
    try {
      var result = await _f(false);
      _6 = result.license || await _c(true);
      if (result.authorized === true) {
        if (result.grace) _a("offlineGrace", { reason: result.reason });
        else _a("restored", { reason: result.reason || "active" });
        return { authorized: true, reason: result.reason || "active", grace: !!result.grace, license: _6 };
      }
      if (result.reason === "validationUnavailable") _a("validationUnavailable", { reason: result.reason });
      return { authorized: false, reason: result.reason || "validationFailed", license: _6 };
    } catch (err) {
      _a("validationUnavailable", { reason: err && err.code || "workerError" });
      return { authorized: false, reason: "validationUnavailable", error: err, license: _6 };
    }
  }

  function _q() {
    if (_7) return;
    _7 = true;
    setInterval(function () { _o().catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("SESSION_PERIODIC_REFRESH_FAILED",err); }); }, _3);
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState !== "visible") return;
      _c(true).then(function (cache) {
        if (!_d(cache)) return;
        var last = Number(cache.lastValidatedAt || 0);
        if (Date.now() - last > _4) _o().catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("SESSION_VISIBLE_REFRESH_FAILED",err); });
      }).catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("SESSION_VISIBLE_STORAGE_READ_FAILED",err); });
    });
  }

  Object.defineProperty(window, "__extS0", {
    value: Object.freeze({_h:_h,_i:_i,_n:_n,_o:_o,_p:_p}),
    enumerable: false,
    configurable: false,
    writable: false
  });

  try { window.dispatchEvent(new CustomEvent("extui-s0-ready")); } catch (_) {}

  var _storageValidationTimer = 0;
  function _r(cache) {
    cache = cache && typeof cache === "object" ? cache : {};
    return [
      cache.authenticated === true ? "1" : "0",
      cache.credentialPresent === true ? "1" : "0",
      String(cache.authMethod || ""),
      String(cache.serverSubjectId || ""),
      String(cache.keyHint || ""),
      String(cache.plan_id || ""),
      String(cache.serverEntitlementRevision || ""),
      String(cache.serverEntitlementExpiresAt || "")
    ].join("|");
  }
  function _s(previous, next) {
    if (_storageValidationTimer) { clearTimeout(_storageValidationTimer); _storageValidationTimer = 0; }
    if (!_d(next) || (_d(previous) && _r(previous) === _r(next))) return;
    _storageValidationTimer = setTimeout(function () {
      _storageValidationTimer = 0;
      _f(false).then(function (result) {
        if (result && result.authorized === true) {
          if (result.grace) _a("offlineGrace", { reason: result.reason });
          else _a("restored", { reason: result.reason || "storageValidated" });
          return;
        }
        if (result && result.reason === "validationUnavailable") _a("validationUnavailable", { reason: result.reason });
        else _a("forceLogout", { reason: result && result.reason || "licenseTamperOrRevoked" });
      }).catch(function (err) { _a("validationUnavailable", { reason: err && err.code || "workerError" }); });
    }, 120);
  }

  try {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") window.ExtensionStorage.subscribe(_0, function (newValue) {
      var previous = _6;
      _6 = newValue || { authenticated: false };
      _a("storageChanged", { license: _6 });
      if (_d(_6)) _s(previous, _6);
      else if (_d(previous)) _a("forceLogout", { reason: "credentialsRemoved" });
    });
  } catch (_) {}

  _c(true).then(function (cache) { if (_d(cache)) _q(); }).catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("SESSION_INITIAL_STORAGE_READ_FAILED",err); });
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
