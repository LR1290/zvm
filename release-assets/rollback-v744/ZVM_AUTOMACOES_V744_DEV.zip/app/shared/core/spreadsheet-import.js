try{
(function(root){
  "use strict";
  if(root.__extSpreadsheetImport)return;
  var NUMBER_HEADERS=["NUMEROS","NUMERO","NÚMERO","NÚMEROS","PHONE","PHONES","WHATSAPP"];
  var NAME_HEADERS=["NOMES","NOME","NAMES","NAME"];
  var CONTENT_SURFACE=!!(root.location&&root.location.hostname==="web.whatsapp.com");
  var MESSAGES=CONTENT_SURFACE?Object.freeze({deflate:"Este navegador não conseguiu abrir a planilha.",zip:"A planilha não pôde ser lida.",structure:"A planilha está em um formato inesperado.",compression:"Esta planilha usa um formato de compactação não suportado."}):Object.freeze({deflate:"Descompressão XLSX indisponível neste navegador.",zip:"Arquivo XLSX inválido.",structure:"Estrutura XLSX inválida.",compression:"Método de compactação XLSX não suportado."});
  var LIMITS=Object.freeze({MAX_FILE_BYTES:25*1024*1024,MAX_ZIP_ENTRIES:512,MAX_ZIP_ENTRY_BYTES:32*1024*1024,MAX_ZIP_TOTAL_BYTES:64*1024*1024,MAX_ROWS:100000,MAX_COLUMNS:256,MAX_SHARED_STRINGS:200000});
  function limitError(code,message){return Object.assign(new Error(message),{code:code});}
  function normalizeHeader(v){return String(v==null?"":v).trim().toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");}
  function parseCsv(text){
    text=String(text||"").replace(/^\uFEFF/,"");var rows=[],row=[],cell="",quoted=false;
    function pushCell(){if(row.length>=LIMITS.MAX_COLUMNS)throw limitError("SPREADSHEET_TOO_MANY_COLUMNS","A planilha excede o limite seguro de "+LIMITS.MAX_COLUMNS+" colunas.");row.push(cell);cell="";}
    function pushRow(){pushCell();if(rows.length>=LIMITS.MAX_ROWS)throw limitError("SPREADSHEET_TOO_MANY_ROWS","A planilha excede o limite seguro de "+LIMITS.MAX_ROWS+" linhas.");rows.push(row);row=[];}
    for(var i=0;i<text.length;i++){var ch=text[i];if(quoted){if(ch==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(ch==='"')quoted=false;else cell+=ch;}else if(ch==='"')quoted=true;else if(ch===',')pushCell();else if(ch==='\n')pushRow();else if(ch!=='\r')cell+=ch;}
    if(row.length||cell.trim()){pushRow();}return rows;
  }
  function u16(d,o){return d[o]|d[o+1]<<8;}function u32(d,o){return (d[o]|d[o+1]<<8|d[o+2]<<16|d[o+3]<<24)>>>0;}
  function decode(bytes){return new TextDecoder("utf-8").decode(bytes);}
  async function inflateRaw(bytes,maxBytes){
    if(typeof DecompressionStream!=="function")throw Object.assign(new Error(MESSAGES.deflate),{code:"XLSX_DEFLATE_UNAVAILABLE"});
    maxBytes=Math.max(1,Number(maxBytes)||LIMITS.MAX_ZIP_ENTRY_BYTES);
    var reader=new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw")).getReader(),chunks=[],total=0;
    try{for(;;){var part=await reader.read();if(part.done)break;var chunk=part.value instanceof Uint8Array?part.value:new Uint8Array(part.value||0);total+=chunk.byteLength;if(total>maxBytes){try{await reader.cancel();}catch(_){}throw limitError("XLSX_UNCOMPRESSED_TOO_LARGE","A planilha descompactada excede o limite seguro.");}chunks.push(chunk);}}finally{try{reader.releaseLock();}catch(_){}}
    var out=new Uint8Array(total),pos=0;chunks.forEach(function(chunk){out.set(chunk,pos);pos+=chunk.byteLength;});return out;
  }
  async function unzip(buffer){
    var d=new Uint8Array(buffer);if(d.length>LIMITS.MAX_FILE_BYTES)throw limitError("SPREADSHEET_FILE_TOO_LARGE","A planilha excede o limite seguro de 25 MB.");
    var eocd=-1;for(var i=Math.max(0,d.length-65557);i<=d.length-22;i++)if(u32(d,i)===0x06054b50)eocd=i;
    if(eocd<0)throw Object.assign(new Error(MESSAGES.zip),{code:"XLSX_ZIP_INVALID"});
    var count=u16(d,eocd+10),offset=u32(d,eocd+16),files=Object.create(null),totalOut=0;
    if(count>LIMITS.MAX_ZIP_ENTRIES)throw limitError("XLSX_TOO_MANY_ENTRIES","A planilha contém arquivos internos demais.");
    for(var n=0;n<count;n++){
      if(offset+46>d.length||u32(d,offset)!==0x02014b50)throw Object.assign(new Error(MESSAGES.structure),{code:"XLSX_ZIP_INVALID"});
      var method=u16(d,offset+10),size=u32(d,offset+20),unpackedSize=u32(d,offset+24),nameLen=u16(d,offset+28),extraLen=u16(d,offset+30),commentLen=u16(d,offset+32),local=u32(d,offset+42),next=offset+46+nameLen+extraLen+commentLen;
      if(next>d.length||local+30>d.length)throw Object.assign(new Error(MESSAGES.structure),{code:"XLSX_ZIP_INVALID"});
      if(unpackedSize>LIMITS.MAX_ZIP_ENTRY_BYTES||totalOut+unpackedSize>LIMITS.MAX_ZIP_TOTAL_BYTES)throw limitError("XLSX_UNCOMPRESSED_TOO_LARGE","A planilha descompactada excede o limite seguro.");
      var name=decode(d.slice(offset+46,offset+46+nameLen));
      if(!name||name==="__proto__"||name==="prototype"||name==="constructor"||Object.prototype.hasOwnProperty.call(files,name))throw Object.assign(new Error(MESSAGES.structure),{code:"XLSX_ZIP_INVALID"});
      if(u32(d,local)!==0x04034b50)throw Object.assign(new Error(MESSAGES.structure),{code:"XLSX_ZIP_INVALID"});
      var ln=u16(d,local+26),le=u16(d,local+28),start=local+30+ln+le,endPacked=start+size;if(start<0||endPacked>d.length)throw Object.assign(new Error(MESSAGES.structure),{code:"XLSX_ZIP_INVALID"});
      var packed=d.slice(start,endPacked),out,maxOut=Math.min(LIMITS.MAX_ZIP_ENTRY_BYTES,LIMITS.MAX_ZIP_TOTAL_BYTES-totalOut);if(method===0)out=packed;else if(method===8)out=await inflateRaw(packed,maxOut);else throw Object.assign(new Error(MESSAGES.compression),{code:"XLSX_COMPRESSION_UNSUPPORTED"});
      if(out.length!==unpackedSize)throw Object.assign(new Error(MESSAGES.structure),{code:"XLSX_SIZE_MISMATCH"});
      if(out.length>LIMITS.MAX_ZIP_ENTRY_BYTES||totalOut+out.length>LIMITS.MAX_ZIP_TOTAL_BYTES)throw limitError("XLSX_UNCOMPRESSED_TOO_LARGE","A planilha descompactada excede o limite seguro.");
      totalOut+=out.length;files[name]=out;offset=next;
    }
    return files;
  }
  function xmlDecode(s){return String(s||"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,"&").replace(/&#(\d+);/g,function(_,n){return String.fromCodePoint(Number(n));}).replace(/&#x([0-9a-f]+);/gi,function(_,n){return String.fromCodePoint(parseInt(n,16));});}
  function sharedStrings(xml){var out=[],m;var re=/<si\b[^>]*>([\s\S]*?)<\/si>/g;while((m=re.exec(xml))){if(out.length>=LIMITS.MAX_SHARED_STRINGS)throw limitError("XLSX_TOO_MANY_SHARED_STRINGS","A planilha contém textos compartilhados demais.");var text="",tm,reT=/<t\b[^>]*>([\s\S]*?)<\/t>/g;while((tm=reT.exec(m[1])))text+=xmlDecode(tm[1]);out.push(text);}return out;}
  function colIndex(ref){var m=String(ref||"").match(/^([A-Z]+)/i),n=0;if(!m)return 0;for(var i=0;i<m[1].length;i++)n=n*26+(m[1].toUpperCase().charCodeAt(i)-64);return n-1;}
  function sheetRows(xml,strings){var rows=[],rm,reRow=/<row\b[^>]*>([\s\S]*?)<\/row>/g;while((rm=reRow.exec(xml))){if(rows.length>=LIMITS.MAX_ROWS)throw limitError("SPREADSHEET_TOO_MANY_ROWS","A planilha excede o limite seguro de "+LIMITS.MAX_ROWS+" linhas.");var row=[],cm,reCell=/<c\b([^>]*)>([\s\S]*?)<\/c>/g;while((cm=reCell.exec(rm[1]))){var attrs=cm[1],body=cm[2],ref=(attrs.match(/\br="([^"]+)"/)||[])[1],type=(attrs.match(/\bt="([^"]+)"/)||[])[1]||"",idx=colIndex(ref);if(idx<0||idx>=LIMITS.MAX_COLUMNS)throw limitError("SPREADSHEET_TOO_MANY_COLUMNS","A planilha excede o limite seguro de "+LIMITS.MAX_COLUMNS+" colunas.");var vm=(body.match(/<v\b[^>]*>([\s\S]*?)<\/v>/)||[])[1],im=(body.match(/<is\b[^>]*>([\s\S]*?)<\/is>/)||[])[1],value="";if(type==="s")value=strings[Number(vm)]||"";else if(type==="inlineStr"&&im){var tm,reT=/<t\b[^>]*>([\s\S]*?)<\/t>/g;while((tm=reT.exec(im)))value+=xmlDecode(tm[1]);}else value=xmlDecode(vm||"");row[idx]=value;}rows.push(row.map(function(v){return v==null?"":v;}));}return rows;}
  function firstWorksheet(files){var names=Object.keys(files).filter(function(n){return /^xl\/worksheets\/sheet\d+\.xml$/i.test(n);}).sort(function(a,b){return Number((a.match(/sheet(\d+)/i)||[])[1])-Number((b.match(/sheet(\d+)/i)||[])[1]);});return names[0]||null;}
  async function parseXlsx(buffer){var files=await unzip(buffer),sheet=firstWorksheet(files);if(!sheet)throw Object.assign(new Error("A planilha não possui uma aba legível."),{code:"XLSX_SHEET_MISSING"});var strings=files["xl/sharedStrings.xml"]?sharedStrings(decode(files["xl/sharedStrings.xml"])):[];return sheetRows(decode(files[sheet]),strings);}
  function cleanNumber(v,options){options=options||{};var digits=String(v==null?"":v).replace(/\D/g,"");if(options.ninthDigit&&/^55\d{10}$/.test(digits)){var ddd=digits.slice(2,4),rest=digits.slice(4);if(rest.length===8&&rest.charAt(0)>="6")digits="55"+ddd+"9"+rest;}if(!options.international&&digits.length>=10&&digits.length<=11&&!/^55/.test(digits))digits="55"+digits;return digits;}
  async function extractContacts(rows,options){options=options||{};if(!Array.isArray(rows)||!rows.length)return{contacts:[],invalidCount:0,duplicateCount:0,headers:[]};var headers=(rows[0]||[]).map(function(h){return String(h==null?"":h).trim();}),norm=headers.map(normalizeHeader),numberIdx=norm.findIndex(function(h){return NUMBER_HEADERS.map(normalizeHeader).indexOf(h)>=0;}),nameIdx=norm.findIndex(function(h){return NAME_HEADERS.map(normalizeHeader).indexOf(h)>=0;});if(numberIdx<0)throw Object.assign(new Error("Não encontrei uma coluna de números. Use NUMERO, NUMEROS, PHONE ou WHATSAPP."),{code:"SPREADSHEET_NUMBER_COLUMN_MISSING"});var seen=new Set(),contacts=[],invalidCount=0,duplicateCount=0,validator=typeof options.validator==="function"?options.validator:null;
    for(var i=1;i<rows.length;i++){var source=rows[i]||[],value=cleanNumber(source[numberIdx],options);if(value.length<8||value.length>17){if(String(source[numberIdx]||"").trim())invalidCount++;continue;}if(seen.has(value)){duplicateCount++;continue;}if(validator){var valid=await validator(value);if(valid===false){invalidCount++;continue;}}seen.add(value);var fields=Object.create(null);headers.forEach(function(h,j){if(h&&h!=="__proto__"&&h!=="prototype"&&h!=="constructor")fields[h]=source[j]==null?"":source[j];});contacts.push({value:value,label:String(nameIdx>=0&&source[nameIdx]?source[nameIdx]:value),name:nameIdx>=0?String(source[nameIdx]||""):"",fields:fields,source:"spreadsheet"});}
    return{contacts:contacts,invalidCount:invalidCount,duplicateCount:duplicateCount,headers:headers,numberColumn:headers[numberIdx],nameColumn:nameIdx>=0?headers[nameIdx]:null};
  }
  async function parseArrayBuffer(buffer,fileName,options){if(!buffer||Number(buffer.byteLength)>LIMITS.MAX_FILE_BYTES)throw limitError("SPREADSHEET_FILE_TOO_LARGE","A planilha excede o limite seguro de 25 MB.");var name=String(fileName||"").toLowerCase();if(name.endsWith(".csv")){var rows=parseCsv(decode(new Uint8Array(buffer)));return Object.assign({rows:rows},await extractContacts(rows,options));}if(name.endsWith(".xlsx")){var xr=await parseXlsx(buffer);return Object.assign({rows:xr},await extractContacts(xr,options));}if(name.endsWith(".xls"))throw Object.assign(new Error("O formato .xls antigo não é suportado. Salve a planilha como .xlsx ou .csv."),{code:"XLS_LEGACY_UNSUPPORTED"});throw Object.assign(new Error("Use um arquivo .xlsx ou .csv."),{code:"SPREADSHEET_FORMAT_UNSUPPORTED"});}
  async function parseFile(file,options){if(!file||typeof file.arrayBuffer!=="function")throw Object.assign(new Error("Arquivo inválido."),{code:"SPREADSHEET_FILE_INVALID"});if(Number(file.size)>LIMITS.MAX_FILE_BYTES)throw limitError("SPREADSHEET_FILE_TOO_LARGE","A planilha excede o limite seguro de 25 MB.");return parseArrayBuffer(await file.arrayBuffer(),file.name,options);}
  function templateCsv(){return "NOME,NUMERO\nCliente Exemplo,5511999999999\n";}
  var api=Object.freeze({version:"1.1.0",limits:LIMITS,numberHeaders:NUMBER_HEADERS.slice(),nameHeaders:NAME_HEADERS.slice(),parseCsv:parseCsv,parseXlsx:parseXlsx,extractContacts:extractContacts,parseArrayBuffer:parseArrayBuffer,parseFile:parseFile,templateCsv:templateCsv});root.__extSpreadsheetImport=api;root.ExtensionCore=root.ExtensionCore||{};
})(typeof window!=="undefined"?window:self);
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
