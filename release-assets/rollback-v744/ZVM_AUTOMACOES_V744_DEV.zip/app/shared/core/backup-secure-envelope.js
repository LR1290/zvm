;
try{
(function(root){
  "use strict";
  if(root.__extBackupSecureEnvelope)return;

  var MAGIC_BYTES=new Uint8Array([69,88,84,66,75,80,48,49]),LEGACY_MAGIC_BYTES=new Uint8Array([90,86,77,66,75,80,48,49]);
  var VERSION=1;
  var CIPHER="AES-256-GCM";
  var KDF="PBKDF2-HMAC-SHA-256";
  var KDF_ITERATIONS=600000;
  var CHUNK_SIZE=4*1024*1024;
  var TAG_BYTES=16;
  var MAX_HEADER_BYTES=16*1024;
  var MAX_PLAIN_BYTES=2200*1024*1024;
  var MIN_PASSWORD_CHARS=12;
  var MAX_PASSWORD_BYTES=1024;
  var AAD_DOMAIN=new Uint8Array([69,88,84,65,80,80,124,83,69,67,85,82,69,45,66,65,67,75,85,80,124,86,49,124]),LEGACY_AAD_DOMAIN=new Uint8Array([90,86,77,45,65,85,84,79,77,65,67,79,69,83,124,83,69,67,85,82,69,45,66,65,67,75,85,80,124,86,49,124]);
  var FORMAT="EXTAPP_SECURE_BACKUP";

  function err(code,message,cause){var e=new Error(message||code);e.code=code;if(cause)try{e.cause=cause;}catch(_){}return e;}
  function u32le(n){var a=new Uint8Array(4),v=new DataView(a.buffer);v.setUint32(0,Number(n)>>>0,true);return a;}
  function u32be(n){var a=new Uint8Array(4),v=new DataView(a.buffer);v.setUint32(0,Number(n)>>>0,false);return a;}
  function concat(parts){var len=0;parts.forEach(function(p){len+=p.byteLength||p.length||0;});var out=new Uint8Array(len),off=0;parts.forEach(function(p){p=p instanceof Uint8Array?p:new Uint8Array(p);out.set(p,off);off+=p.length;});return out;}
  function equal(a,b){a=a instanceof Uint8Array?a:new Uint8Array(a);b=b instanceof Uint8Array?b:new Uint8Array(b);if(a.length!==b.length)return false;var d=0;for(var i=0;i<a.length;i++)d|=a[i]^b[i];return d===0;}
  function b64u(bytes){bytes=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);var s="";for(var i=0;i<bytes.length;i++)s+=String.fromCharCode(bytes[i]);return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");}
  function unb64u(text){text=String(text||"");if(!/^[A-Za-z0-9_-]+$/.test(text))throw err("BACKUP_SECURE_HEADER_INVALID","O cabeçalho da cópia protegida é inválido.");var s=text.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";var raw;try{raw=atob(s);}catch(e){throw err("BACKUP_SECURE_HEADER_INVALID","O cabeçalho da cópia protegida é inválido.",e);}var out=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
  function passwordBytes(password,creating){password=String(password==null?"":password);if(creating&&password.length<MIN_PASSWORD_CHARS)throw err("BACKUP_SECURE_PASSWORD_WEAK","Use uma senha com pelo menos "+MIN_PASSWORD_CHARS+" caracteres para proteger a cópia.");var bytes=new TextEncoder().encode(password);if(!bytes.length||bytes.length>MAX_PASSWORD_BYTES)throw err("BACKUP_SECURE_PASSWORD_INVALID","A senha da cópia é inválida.");return bytes;}
  async function derive(password,salt,iterations){var raw=passwordBytes(password,false),base=await crypto.subtle.importKey("raw",raw,"PBKDF2",false,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",hash:"SHA-256",salt:salt,iterations:iterations},base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);}
  function nonce(prefix,index){if(!(prefix instanceof Uint8Array)||prefix.length!==8)throw err("BACKUP_SECURE_HEADER_INVALID","O nonce da cópia protegida é inválido.");return concat([prefix,u32be(index)]);}
  function aad(headerBytes,index,legacy){return concat([legacy?LEGACY_AAD_DOMAIN:AAD_DOMAIN,headerBytes,u32be(index)]);}
  function normalizeInnerExtension(v){v=String(v||"").toLowerCase();return v==="json"?"json":"zip";}
  function safeOutputName(name){name=String(name||"").replace(/[^A-Za-z0-9._-]/g,"-").slice(0,140);return name||("secure-backup-"+Date.now()+".tmp");}
  function headerShape(header,headerBytes,fileSize,legacy){
    if(!header||typeof header!=="object"||Array.isArray(header)||(!legacy&&header.format!==FORMAT)||Number(header.version)!==VERSION)throw err("BACKUP_SECURE_HEADER_INVALID","O cabeçalho da cópia protegida é inválido.");
    if(header.cipher!==CIPHER||!header.kdf||header.kdf.name!==KDF||header.kdf.hash!=="SHA-256")throw err("BACKUP_SECURE_ALGORITHM_UNSUPPORTED","Esta cópia usa uma proteção não suportada por esta versão.");
    var iterations=Number(header.kdf.iterations),plainSize=Number(header.plainSize),chunkSize=Number(header.chunkSize),chunkCount=Number(header.chunkCount);
    if(!Number.isInteger(iterations)||iterations<300000||iterations>2000000)throw err("BACKUP_SECURE_HEADER_INVALID","Os parâmetros de proteção da cópia são inválidos.");
    if(!Number.isInteger(plainSize)||plainSize<1||plainSize>MAX_PLAIN_BYTES)throw err("BACKUP_SECURE_SIZE_INVALID","O tamanho interno da cópia protegida é inválido ou excede o limite seguro.");
    if(!Number.isInteger(chunkSize)||chunkSize<256*1024||chunkSize>8*1024*1024)throw err("BACKUP_SECURE_HEADER_INVALID","O tamanho dos blocos da cópia é inválido.");
    var expectedCount=Math.ceil(plainSize/chunkSize);if(!Number.isInteger(chunkCount)||chunkCount!==expectedCount||chunkCount<1)throw err("BACKUP_SECURE_HEADER_INVALID","A quantidade de blocos da cópia é inválida.");
    var salt=unb64u(header.kdf.salt),prefix=unb64u(header.noncePrefix);if(salt.length!==16||prefix.length!==8)throw err("BACKUP_SECURE_HEADER_INVALID","Os parâmetros aleatórios da cópia são inválidos.");
    var expected=8+4+headerBytes.length+plainSize+chunkCount*TAG_BYTES;if(Number(fileSize)!==expected)throw err("BACKUP_SECURE_TRUNCATED","A cópia protegida está truncada ou possui bytes extras inesperados.");
    return{iterations:iterations,plainSize:plainSize,chunkSize:chunkSize,chunkCount:chunkCount,salt:salt,prefix:prefix,innerExtension:normalizeInnerExtension(header.innerExtension),mimeType:String(header.mimeType||"application/octet-stream")};
  }
  async function parseHeader(file){
    if(!file||typeof file.slice!=="function"||!Number.isFinite(Number(file.size)))throw err("BACKUP_SECURE_FILE_INVALID","O arquivo protegido é inválido.");
    if(Number(file.size)<8+4+2)throw err("BACKUP_SECURE_NOT_RECOGNIZED","O arquivo não é uma cópia protegida reconhecida por esta extensão.");
    var first=new Uint8Array(await file.slice(0,12).arrayBuffer()),head=first.slice(0,8),legacy=equal(head,LEGACY_MAGIC_BYTES),current=equal(head,MAGIC_BYTES);if(!legacy&&!current)throw err("BACKUP_SECURE_NOT_RECOGNIZED","O arquivo não é uma cópia protegida reconhecida por esta extensão.");
    var headerLen=new DataView(first.buffer,first.byteOffset+8,4).getUint32(0,true);if(headerLen<2||headerLen>MAX_HEADER_BYTES||12+headerLen>Number(file.size))throw err("BACKUP_SECURE_HEADER_INVALID","O cabeçalho da cópia protegida tem tamanho inválido.");
    var headerBytes=new Uint8Array(await file.slice(12,12+headerLen).arrayBuffer()),header;try{header=JSON.parse(new TextDecoder("utf-8",{fatal:true}).decode(headerBytes));}catch(e){throw err("BACKUP_SECURE_HEADER_INVALID","Não foi possível ler o cabeçalho da cópia protegida.",e);}var shape=headerShape(header,headerBytes,Number(file.size),legacy);return{header:header,headerBytes:headerBytes,dataOffset:12+headerLen,shape:shape,legacy:legacy};
  }
  async function isSecureFile(file){try{var head=new Uint8Array(await file.slice(0,8).arrayBuffer());return equal(head,MAGIC_BYTES)||equal(head,LEGACY_MAGIC_BYTES);}catch(_){return false;}}
  async function encryptToSink(file,password,sink,opts){
    opts=opts||{};if(!file||typeof file.slice!=="function")throw err("BACKUP_SECURE_FILE_INVALID","O arquivo interno da cópia é inválido.");var plainSize=Number(file.size);if(!Number.isInteger(plainSize)||plainSize<1||plainSize>MAX_PLAIN_BYTES)throw err("BACKUP_SECURE_SIZE_INVALID","A cópia excede o limite seguro atual de 2,2 GB.");passwordBytes(password,true);
    var salt=new Uint8Array(16),prefix=new Uint8Array(8);crypto.getRandomValues(salt);crypto.getRandomValues(prefix);var chunkSize=CHUNK_SIZE,chunkCount=Math.ceil(plainSize/chunkSize),header={format:FORMAT,version:VERSION,createdAt:String(opts.createdAt||new Date().toISOString()),cipher:CIPHER,kdf:{name:KDF,hash:"SHA-256",iterations:KDF_ITERATIONS,salt:b64u(salt)},noncePrefix:b64u(prefix),chunkSize:chunkSize,chunkCount:chunkCount,plainSize:plainSize,innerExtension:normalizeInnerExtension(opts.innerExtension),mimeType:String(opts.mimeType||file.type||"application/octet-stream"),security:{credentialsIncluded:false,authenticatedEncryption:true}};
    var headerBytes=new TextEncoder().encode(JSON.stringify(header));if(headerBytes.length>MAX_HEADER_BYTES)throw err("BACKUP_SECURE_HEADER_INVALID","O cabeçalho da cópia protegida excede o limite.");var key=await derive(password,salt,KDF_ITERATIONS);await sink.write(concat([MAGIC_BYTES,u32le(headerBytes.length),headerBytes]));var written=12+headerBytes.length;
    for(var i=0;i<chunkCount;i++){var start=i*chunkSize,end=Math.min(plainSize,start+chunkSize),plain=new Uint8Array(await file.slice(start,end).arrayBuffer()),cipher;try{cipher=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:nonce(prefix,i),additionalData:aad(headerBytes,i,false),tagLength:128},key,plain));}catch(e){throw err("BACKUP_SECURE_ENCRYPT_FAILED","Não foi possível proteger a cópia.",e);}await sink.write(cipher);written+=cipher.length;}
    if(typeof sink.close==="function")await sink.close();return{header:header,sizeBytes:written,innerExtension:header.innerExtension,mimeType:"application/x-extension-backup"};
  }
  async function decryptToSink(file,password,sink){
    var parsed=await parseHeader(file),s=parsed.shape,key;try{key=await derive(password,s.salt,s.iterations);}catch(e){throw err("BACKUP_SECURE_PASSWORD_INVALID","Não foi possível preparar a senha desta cópia.",e);}var offset=parsed.dataOffset,written=0;
    try{for(var i=0;i<s.chunkCount;i++){var plainLen=Math.min(s.chunkSize,s.plainSize-i*s.chunkSize),cipherLen=plainLen+TAG_BYTES,cipher=new Uint8Array(await file.slice(offset,offset+cipherLen).arrayBuffer()),plain;offset+=cipherLen;try{plain=new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM",iv:nonce(s.prefix,i),additionalData:aad(parsed.headerBytes,i,parsed.legacy),tagLength:128},key,cipher));}catch(e){throw err("BACKUP_SECURE_PASSWORD_OR_INTEGRITY","Senha incorreta ou a cópia protegida foi alterada/corrompida.",e);}if(plain.length!==plainLen)throw err("BACKUP_SECURE_DECRYPT_SIZE","Um bloco da cópia protegida apresentou tamanho inválido.");await sink.write(plain);written+=plain.length;}if(written!==s.plainSize)throw err("BACKUP_SECURE_DECRYPT_SIZE","O tamanho restaurado da cópia protegida é inválido.");if(typeof sink.close==="function")await sink.close();return{header:parsed.header,sizeBytes:written,innerExtension:s.innerExtension,mimeType:s.mimeType};}catch(e){if(typeof sink.abort==="function")try{await sink.abort(e);}catch(_){}throw e;}
  }
  async function encryptFileToOpfs(file,password,opts){opts=opts||{};if(!navigator.storage||typeof navigator.storage.getDirectory!=="function")throw err("BACKUP_SECURE_OPFS_UNAVAILABLE","O armazenamento temporário do navegador não está disponível.");var rootDir=await navigator.storage.getDirectory(),name=safeOutputName(opts.outputName||("extapp-backup-secure-"+Date.now()+".extbackup")),handle=await rootDir.getFileHandle(name,{create:true}),w=await handle.createWritable({keepExistingData:false}),closed=false;try{var result=await encryptToSink(file,password,{write:function(b){return w.write(b);},close:async function(){await w.close();closed=true;},abort:function(){return w.abort?w.abort():w.close();}},opts);var out=await handle.getFile();return Object.assign(result,{opfsName:name,file:out});}catch(e){try{if(!closed&&w.abort)await w.abort();}catch(_){}try{await rootDir.removeEntry(name);}catch(_){}throw e;}}
  async function decryptFileToOpfs(file,password,opts){opts=opts||{};if(!navigator.storage||typeof navigator.storage.getDirectory!=="function")throw err("BACKUP_SECURE_OPFS_UNAVAILABLE","O armazenamento temporário do navegador não está disponível.");var rootDir=await navigator.storage.getDirectory(),name=safeOutputName(opts.outputName||("extapp-backup-decrypted-"+Date.now()+".tmp")),handle=await rootDir.getFileHandle(name,{create:true}),w=await handle.createWritable({keepExistingData:false}),closed=false;try{var result=await decryptToSink(file,password,{write:function(b){return w.write(b);},close:async function(){await w.close();closed=true;},abort:function(){return w.abort?w.abort():w.close();}});var out=await handle.getFile();return Object.assign(result,{opfsName:name,file:out});}catch(e){try{if(!closed&&w.abort)await w.abort();}catch(_){}try{await rootDir.removeEntry(name);}catch(_){}throw e;}}
  async function removeOpfs(name){if(!name||!navigator.storage||typeof navigator.storage.getDirectory!=="function")return false;try{var rootDir=await navigator.storage.getDirectory();await rootDir.removeEntry(String(name));return true;}catch(_){return false;}}

  root.__extBackupSecureEnvelope=Object.freeze({version:"1.1.0",format:FORMAT,extension:"extbackup",cipher:CIPHER,kdf:KDF,kdfIterations:KDF_ITERATIONS,chunkSize:CHUNK_SIZE,minPasswordChars:MIN_PASSWORD_CHARS,maxPlainBytes:MAX_PLAIN_BYTES,isSecureFile:isSecureFile,parseHeader:parseHeader,encryptToSink:encryptToSink,decryptToSink:decryptToSink,encryptFileToOpfs:encryptFileToOpfs,decryptFileToOpfs:decryptFileToOpfs,removeOpfs:removeOpfs});
})(typeof window!=="undefined"?window:self);
}catch(_extBackupSecureEnvelopeError){if(typeof window!=="undefined"&&window.__extRecordBootError)window.__extRecordBootError(_extBackupSecureEnvelopeError);else if(typeof self!=="undefined"&&self.__extReportRuntimeError)self.__extReportRuntimeError("BACKUP_SECURE_ENVELOPE_BOOT_FAILED",_extBackupSecureEnvelopeError);else throw _extBackupSecureEnvelopeError;}
