(function(){
  "use strict";
  function csvSafeCell(value){
    var text=String(value==null?"":value).replace(/\u0000/g,"");
    var probe=text.replace(/^[ \t\r\n]+/,"");
    if(/^[=+\-@]/.test(probe))text="'"+text;
    return /[",\r\n]/.test(text)?'"'+text.replace(/"/g,'""')+'"':text;
  }
  Object.defineProperty(window,"__extCsvSafeCell",{value:csvSafeCell,writable:false,configurable:false});
})();
