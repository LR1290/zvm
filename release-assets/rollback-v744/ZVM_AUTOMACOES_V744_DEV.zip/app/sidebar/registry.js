(function (root) {
  "use strict";
  var C = root.ExtensionUI.sidebarConstants;
  var catalog = Object.freeze([
    { key: "items", label: "Itens", command: "items.open", icon: "items", group: "conteudo", pinEligible: true },
    { key: "crm", label: "CRM", command: "crm.open", icon: "crm", group: "gestao", pinEligible: true },
    { key: "crm-funnel", label: "Funil CRM", command: "crm-funnel.open", icon: "crm-funnel", group: "gestao", pinEligible: true },
    { key: "orders", label: "Encomendas", command: "orders.open", icon: "orders", group: "gestao", pinEligible: true },
    { key: "delivery", label: "Entregas", command: "delivery.open", icon: "delivery", group: "gestao", pinEligible: true },
    { key: "activity", label: "Envios", command: "activity.open", icon: "activity", group: "automacao", pinEligible: true },
    { key: "broadcast", label: "Disparo em massa", command: "broadcast.open", icon: "broadcast", group: "automacao", pinEligible: true },
    { key: "broadcast-shell", label: "Disparos", command: "broadcast-shell.open", icon: "broadcast", group: "automacao", pinEligible: true },
    { key: "flow", label: "Fluxos", command: "flow.open", icon: "flow", group: "automacao", pinEligible: true },
    { key: "funnel", label: "Funis", command: "funnel.open", icon: "funnel", group: "automacao", pinEligible: true },
    { key: "quick-response", label: "Respostas Rápidas", command: "quick-response.open", icon: "quick-response", group: "produtividade", pinEligible: true },
    { key: "labels", label: "Etiquetas", command: "labels.open", icon: "labels-manager", group: "produtividade", pinEligible: true },
    { key: "followup", label: "FollowUp", command: "followup.open", icon: "followup", group: "produtividade", pinEligible: true },
    { key: "auto-service", label: "Autoatendimento", command: "auto-service.open", icon: "auto-service", group: "produtividade", pinEligible: true },
    { key: "status", label: "Status", command: "status.open", icon: "status", group: "produtividade", pinEligible: true },
    { key: "export", label: "Exportar contatos", command: "export-contacts.open", icon: "export", group: "produtividade", pinEligible: true },
    { key: "agenda", label: "Agenda", command: "agenda.open", icon: "agenda", group: "produtividade", pinEligible: true },
    { key: "notes", label: "Notas", command: "note.open", icon: "notes", group: "produtividade", pinEligible: true },
    { key: "reminder", label: "Lembrete", command: "reminder.open", icon: "reminder", group: "produtividade", pinEligible: true },
    { key: "google-calendar", label: "Google Calendar", command: "google-calendar.open", icon: "google-calendar", group: "produtividade", pinEligible: true },
    { key: "signature", label: "Assinatura", command: "signature.open", icon: "signature", group: "produtividade", pinEligible: true },
    { key: "text-assistant", label: "Assistente de texto", command: "text-assistant.open", icon: "text-assistant", group: "produtividade", pinEligible: true },
    { key: "text-replace", label: "Substituição de texto", command: "text-replace.open", icon: "text-replace", group: "produtividade", pinEligible: true },
    { key: "google", label: "Google", command: "google.open", icon: "google", group: "produtividade", pinEligible: true },
    { key: "webhooks", label: "Webhooks", command: "webhooks.open", icon: "webhooks", group: "sistema", pinEligible: true },
    { key: "theme-toggle", label: "Alterar Modo", command: "appearance.mode.toggle", icon: "theme-toggle", group: "sistema", pinEligible: true },
    { key: "integrations", label: "Integrações", command: "dashboard.open", payload: { section: "integracoes" }, icon: "integrations", group: "sistema", pinEligible: false }
  ]);
  var footerMutable = Object.freeze([
    { key: "tools", label: "Ferramentas", command: "tools.open", icon: "tools", group: "sistema" },
    { key: "notifications", label: "Notificações", command: "notifications.open", icon: "notifications", group: "sistema" }
  ]);
  var footerImmutable = Object.freeze([
    { key: "system", label: "Sistema", command: "system.open", icon: "system", group: "sistema" },
    { key: "rail-toggle", label: "Expandir menu", command: "sidebar.expand.toggle", icon: "rail-toggle", group: "sistema" }
  ]);
  var footer = Object.freeze(footerMutable.concat(footerImmutable));
  var byKey = Object.create(null);
  catalog.concat(footer).forEach(function (item) { byKey[item.key] = item; });
  function isSeparatorKey(key) { return typeof key === "string" && /^separator:[a-z0-9_-]{6,64}$/i.test(key); }
  function get(key) {
    if (isSeparatorKey(key)) return { key:key, label:"Separador", separator:true, group:"separator", pinEligible:false };
    return byKey[key] || null;
  }
  function pinEligibleKeys() { return catalog.filter(function (x) { return x.pinEligible; }).map(function (x) { return x.key; }); }
  function configurableKeys() { return pinEligibleKeys().concat(footerMutable.map(function (x) { return x.key; })); }
  function orderedPinned(state) {
    var keys = Array.isArray(state && state.order) && state.order.length ? state.order.slice() : Array.isArray(state && state.pinned) ? state.pinned.slice() : C.DEFAULTS.pinned.slice();
    var pinnedSet = new Set(Array.isArray(state && state.pinned) ? state.pinned : C.DEFAULTS.pinned);
    var separatorSet = new Set(Array.isArray(state && state.separators) ? state.separators.filter(isSeparatorKey) : []);
    var configurableSet = new Set(configurableKeys());
    var out = [];
    keys.concat(Array.from(pinnedSet)).forEach(function (key) {
      var item = get(key);
      var allowed = item && ((configurableSet.has(key) && !item.separator) || (item.separator && separatorSet.has(key)));
      if (allowed && pinnedSet.has(key) && out.indexOf(key) < 0 && out.length < C.MAX_PINNED + separatorSet.size) out.push(key);
    });
    return out;
  }
  function primary(state) { return orderedPinned(state).map(get).filter(Boolean); }
  function tray(kind) { return catalog.filter(function (item) { return item.tray === kind; }); }
  root.ExtensionUI.sidebarRegistry = Object.freeze({ catalog: catalog, footer: footer, footerMutable: footerMutable, footerImmutable: footerImmutable, get: get, primary: primary, tray: tray, orderedPinned: orderedPinned, pinEligibleKeys: pinEligibleKeys, configurableKeys: configurableKeys, isSeparatorKey: isSeparatorKey });
})(globalThis);
