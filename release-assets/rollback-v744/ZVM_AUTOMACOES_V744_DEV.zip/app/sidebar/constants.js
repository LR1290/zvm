(function (root) {
  "use strict";
  var legacyDefaultPinnedV2 = ["crm","crm-funnel","items","broadcast","agenda","automations","status","tools"];
  var legacyCollapsedPinnedV3 = ["crm","crm-funnel","items","broadcast","status","tools"];
  var legacyDefaultPinnedV3 = ["items","crm","crm-funnel","orders","activity","broadcast","flow","funnel","quick-response","followup","auto-service","status","tools","export"];
  var legacyDefaultPinnedV6 = ["crm","crm-funnel","items","broadcast","activity","orders","flow","funnel","followup","auto-service","quick-response","status","tools","export"];
  var legacyDefaultPinnedV12 = ["items","crm","crm-funnel","orders","delivery","activity","broadcast","flow","funnel","quick-response","followup","auto-service","status","agenda","notes","reminder","google-calendar","signature","text-assistant","text-replace","export","google","webhooks"];
  var legacyDefaultPinnedV13 = ["items","crm","broadcast","flow","funnel","followup","activity","quick-response","auto-service","orders","delivery","crm-funnel","text-assistant","text-replace","export","google"];
  var legacyDefaultFooterPinnedV15 = ["tools","notifications"];
  var defaultPinned = ["items","crm","broadcast","flow","funnel","followup","activity","quick-response","auto-service","orders","delivery","crm-funnel","text-assistant","text-replace","export","google"];
  var defaultFooterPinned = ["notifications"];
  var defaultHidden = ["status","agenda","notes","reminder","signature","google-calendar","webhooks","theme-toggle","tools","broadcast-shell","labels"];
  var defaultOrder = defaultPinned.concat(defaultFooterPinned,defaultHidden);
  var defaults = Object.freeze({
    schemaVersion: 19,
    expanded: false,
    panelMode: "docked",
    pinned: defaultPinned,
    footerPinned: defaultFooterPinned,
    order: defaultOrder,
    separators: [],
    dismissedHints: []
  });
  root.ExtensionUI = root.ExtensionUI || {};
  root.ExtensionUI.sidebarConstants = Object.freeze({
    HOST_ID: "ext-sidebar-host",
    STORE_KEY: "EXTUI:sidebarV2",
    SCHEMA_VERSION: 19,
    DEFAULTS: defaults,
    LEGACY_DEFAULT_PINNED_V2: Object.freeze(legacyDefaultPinnedV2.slice()),
    LEGACY_COLLAPSED_PINNED_V3: Object.freeze(legacyCollapsedPinnedV3.slice()),
    LEGACY_DEFAULT_PINNED_V3: Object.freeze(legacyDefaultPinnedV3.slice()),
    LEGACY_DEFAULT_PINNED_V6: Object.freeze(legacyDefaultPinnedV6.slice()),
    LEGACY_DEFAULT_PINNED_V12: Object.freeze(legacyDefaultPinnedV12.slice()),
    LEGACY_DEFAULT_PINNED_V13: Object.freeze(legacyDefaultPinnedV13.slice()),
    LEGACY_DEFAULT_FOOTER_PINNED_V15: Object.freeze(legacyDefaultFooterPinnedV15.slice()),
    MAX_PINNED: 32,
    COLLAPSED_WIDTH: 64,
    EXPANDED_WIDTH: 236
  });
})(globalThis);
