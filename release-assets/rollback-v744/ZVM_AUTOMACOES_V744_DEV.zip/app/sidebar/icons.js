(function (root) {
  "use strict";
  var paths = Object.freeze({
    items:'<rect x="4" y="4" width="6" height="6" rx="1.35"/><rect x="14" y="4" width="6" height="6" rx="1.35"/><rect x="4" y="14" width="6" height="6" rx="1.35"/><rect x="14" y="14" width="6" height="6" rx="1.35"/>',
    crm:'<path d="M5 3v14"/><path d="M12 3v8"/><path d="M19 3v18"/>',
    "crm-funnel":'<path d="M3 4h18l-7 8v6l-4 2v-8z"/><path d="M7 8h10"/>',
    orders:'<path d="m16.5 9.4-9-5.19"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" x2="12" y1="22" y2="12"/>',
    delivery:'<path d="M3 7h11v8H3z"/><path d="M14 10h3l4 4v1h-7z"/><circle cx="7.5" cy="18" r="1.5"/><circle cx="17.5" cy="18" r="1.5"/>',
    activity:'<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
    broadcast:'<path d="M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"/><path d="M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14"/><path d="M8 6v8"/>',
    flow:'<rect width="8" height="8" x="3" y="3" rx="2"/><path d="M7 11v4a2 2 0 0 0 2 2h4"/><rect width="8" height="8" x="13" y="13" rx="2"/>',
    funnel:'<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>',
    "quick-response":'<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
    "labels-manager":'<path d="M4 4h6l8 8-6 6-8-8z"/><path d="M9 3h5l7 7-5 5"/><circle cx="7.5" cy="7.5" r="1"/>',
    followup:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    "auto-service":'<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
    status:'<circle cx="12" cy="12" r="9"/><path d="M8 12h8"/><path d="M12 8v8"/>',
    tools:'<path d="M14.7 6.3a4.2 4.2 0 0 0-5.45 5.45L3.6 17.4a2.12 2.12 0 0 0 3 3l5.65-5.65a4.2 4.2 0 0 0 5.45-5.45l-2.55 2.55-3-3z"/><path d="m5.1 18.9.01.01"/>',
    google:'<text x="12" y="16.2" text-anchor="middle" font-size="15.5" font-family="Arial,Helvetica,sans-serif" font-weight="800" fill="currentColor" stroke="none">G</text>',
    export:'<path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/>',
    notifications:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
    system:'<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
    agenda:'<path d="M8 2v3"/><path d="M16 2v3"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>',
    webhooks:'<path d="M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2"/><path d="m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06"/><path d="m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8"/>',
    notes:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h6"/>',
    reminder:'<path d="M6 8a6 6 0 1 1 12 0c0 5 2 6 2 8H4c0-2 2-3 2-8"/><path d="M10 20h4"/><path d="M12 4v5l3 2"/>',
    "google-calendar":'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 9h18"/><text x="12" y="17.2" text-anchor="middle" font-size="7.2" font-family="Arial,sans-serif" font-weight="800" fill="currentColor" stroke="none">31</text>',
    signature:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/>',
    "text-assistant":'<path d="M4 6h10M4 12h8M4 18h12"/><path d="m18 5 .8 2.2L21 8l-2.2.8L18 11l-.8-2.2L15 8l2.2-.8z"/><path d="m20 14 .55 1.45L22 16l-1.45.55L20 18l-.55-1.45L18 16l1.45-.55z"/>',
    "text-replace":'<path d="M4 7h12"/><path d="m13 4 3 3-3 3"/><path d="M20 17H8"/><path d="m11 14-3 3 3 3"/>',
    integrations:'<path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a6 6 0 0 1-12 0V8Z"/><path d="M4 8h16"/>',
    dashboard:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    customize:'<path d="M4 6h10M18 6h2M4 12h3M11 12h9M4 18h7M15 18h5"/><circle cx="16" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="13" cy="18" r="2"/>',
    pin:'<path d="m12 17 0 5"/><path d="M5 3h14l-3 5v4l2 2H6l2-2V8z"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    "rail-toggle":'<path d="m9 18 6-6-6-6"/>',
    "theme-toggle":'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'
  });
  function svg(name) {
    var body = paths[name] || paths.items;
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + body + '</svg>';
  }
  root.ExtensionUI.sidebarIcons = Object.freeze({ svg: svg });
})(globalThis);
