(function (root) {
  "use strict";
  var ids = [
    "crm.open","crm-funnel.open","items.open","broadcast.open","broadcast-shell.open","quick-response.open","agenda.open",
    "flow.open","funnel.open","followup.open","auto-service.open","status.open",
    "tools.open","google.open","activity.open","notifications.open","orders.open","webhooks.open",
    "note.open","reminder.open","google-calendar.open","signature.open","text-assistant.open","text-replace.open","labels.open",
    "delivery.open","system.open","dashboard.open","export-contacts.open"
  ];

  function host() {
    var coreApi = root.ExtensionCore;
    return coreApi && coreApi.CommandHost && typeof coreApi.CommandHost.execute === "function" ? coreApi.CommandHost : null;
  }

  function register(id) {
    if (root.ExtensionUI.commands.has(id)) return;
    root.ExtensionUI.commands.register(id, {
      canExecute: function () {
        var api = host();
        return !!(api && (!api.has || api.has(id)));
      },
      getState: function () {
        var api = host();
        if (!api) return { available: false, active: false };
        if (typeof api.state === "function") return api.state(id);
        return { available: true, active: false };
      },
      execute: function (payload) {
        var api = host();
        if (!api) {
          var err = new Error("Command host unavailable");
          err.code = "EXT_COMMAND_HOST_UNAVAILABLE";
          throw err;
        }
        return api.execute(id, payload || {});
      }
    });
  }

  ids.forEach(register);
  root.ExtensionUI.commandHostAdapter = Object.freeze({ ids: ids.slice() });
})(globalThis);
