(function (root) {
  "use strict";
  var C = root.ExtensionUI.sidebarConstants;
  var registry = root.ExtensionUI.sidebarRegistry;
  var trays = root.ExtensionUI.sidebarTrays;
  var icons = root.ExtensionUI.sidebarIcons;

  function safeLogoUrl() {
    try { return chrome.runtime.getURL("assets/brand/logo-icon-light.png"); } catch (_) { return ""; }
  }
  var SHARED_PALETTE=root.ExtensionSectionPalette||null;
  function itemAccent(key){return SHARED_PALETTE&&typeof SHARED_PALETTE.forSidebarKey==="function"?SHARED_PALETTE.forSidebarKey(key,"#14b8a6"):"#14b8a6";}
  function commandButton(item, className) {
    var el = document.createElement("button");
    el.type = "button";
    el.className = className || "extappRailItem";
    el.dataset.key = item.key;
    el.dataset.command = item.command;
    el.setAttribute("data-extui-academy-target", "v2-" + item.key);
    el.style.setProperty("--extapp-item-accent",itemAccent(item.key));
    if (item.payload) el.dataset.payload = JSON.stringify(item.payload);
    el.setAttribute("aria-label", item.hint ? item.label + ": " + item.hint : item.label);
    el.dataset.hoverLabel = item.label;
    el.innerHTML = '<span class="extappRailIcon">' + icons.svg(item.icon) + '</span><span class="extappRailLabel"></span><span class="extappRailBadge" hidden></span><span class="extappRailBusy" hidden aria-hidden="true"></span>';
    el.querySelector(".extappRailLabel").textContent = item.label;
    return el;
  }
  function renderItems(container, items) {
    container.innerHTML = "";
    items.forEach(function (item) {
      if (!item) return;
      if (item.separator) {
        var divider = document.createElement("div");
        divider.className = "extappRailDivider";
        divider.dataset.key = item.key;
        divider.setAttribute("role", "separator");
        divider.setAttribute("aria-label", "Separador");
        container.appendChild(divider);
        return;
      }
      container.appendChild(commandButton(item));
    });
  }
  function trayTitle(kind) {
    if (kind === "automations") return ["Automações", "Fluxos, funis e regras automáticas"];
    if (kind === "customize") return ["Atalhos da Sidebar", "Escolha até " + C.MAX_PINNED + " atalhos para acesso rápido"];
    return ["Recursos", "Recursos complementares da extensão"];
  }
  function trayFrame(tray, kind) {
    var title = trayTitle(kind);
    tray.innerHTML = '<div class="extappRailTrayHead"><div><strong></strong><span></span></div><button type="button" class="extappRailTrayClose" data-sidebar-action="close-tray" aria-label="Fechar">×</button></div><div class="extappRailTrayBody"></div>';
    tray.querySelector("strong").textContent = title[0];
    tray.querySelector(".extappRailTrayHead span").textContent = title[1];
    return tray.querySelector(".extappRailTrayBody");
  }
  function genericTrayItems(kind, state) {
    return (trays[kind] || []).slice();
  }
  function renderGenericTray(tray, kind, state, workspaceState) {
    var body = trayFrame(tray, kind);
    var list = document.createElement("div"); list.className = "extappRailTrayList";
    var focusedPrimary=new Set(root.ExtensionUI.workspaceProfile&&root.ExtensionUI.workspaceProfile.orderedKeys(workspaceState)?root.ExtensionUI.workspaceProfile.primary(state,workspaceState).map(function(item){return item.key;}):[]);
    genericTrayItems(kind, state).filter(function(item){if(root.ExtensionUI.workspaceProfile&&!root.ExtensionUI.workspaceProfile.visible(item,workspaceState))return false;return item.key==="customize"||!focusedPrimary.has(item.key);}).forEach(function (item) {
      var btn = commandButton(item, "extappRailTrayItem");
      var hint = document.createElement("small"); hint.className = "extappRailTrayHint"; hint.textContent = item.hint || ""; btn.appendChild(hint);
      list.appendChild(btn);
    });
    body.appendChild(list);
  }
  function renderCustomizeTray(tray, state) {
    var body = trayFrame(tray, "customize");
    var intro = document.createElement("div"); intro.className = "extappRailCustomizeIntro";
    intro.innerHTML = '<div><strong>Atalhos rápidos</strong><span>Escolha o que fica fixo na Sidebar.</span></div><div class="extappRailCount"><b></b>/' + C.MAX_PINNED + '</div>';
    intro.querySelector("b").textContent = String(state.pinned.length);
    body.appendChild(intro);

    var expansion = document.createElement("div"); expansion.className = "extappRailSettingRow";
    expansion.innerHTML = '<div><strong>Manter expandida</strong><span>Mostra os nomes e reserva espaço no WhatsApp.</span></div><button type="button" class="extappRailSwitch" data-sidebar-action="toggle-expanded" role="switch"><span></span></button>';
    var sw = expansion.querySelector("button"); sw.setAttribute("aria-label", "Manter Sidebar expandida"); sw.setAttribute("aria-checked", String(!!state.expanded)); sw.toggleAttribute("data-on", !!state.expanded);
    body.appendChild(expansion);

    var list = document.createElement("div"); list.className = "extappRailCustomizeList";
    var pinnedOrder = registry.orderedPinned(state);
    registry.catalog.filter(function (item) { return item.pinEligible; }).forEach(function (item) {
      var isPinned = state.pinned.indexOf(item.key) >= 0;
      var pos = pinnedOrder.indexOf(item.key);
      var row = document.createElement("div"); row.className = "extappRailCustomizeRow"; row.dataset.pinKey = item.key; row.style.setProperty("--extapp-item-accent",itemAccent(item.key)); row.toggleAttribute("data-pinned", isPinned);
      row.innerHTML = '<span class="extappRailCustomizeIcon">' + icons.svg(item.icon) + '</span><div class="extappRailCustomizeCopy"><strong></strong><span></span></div><div class="extappRailOrderButtons"></div><button type="button" class="extappRailPinButton" data-sidebar-action="toggle-pin"></button>';
      row.querySelector(".extappRailCustomizeCopy strong").textContent = item.label;
      row.querySelector(".extappRailCustomizeCopy span").textContent = isPinned ? "Fixado na posição " + (pos + 1) : "Disponível no Configurar Menu";
      var orderButtons = row.querySelector(".extappRailOrderButtons");
      if (isPinned) {
        var up = document.createElement("button"); up.type = "button"; up.dataset.sidebarAction = "move-up"; up.textContent = "↑"; up.title = "Mover para cima"; up.setAttribute("aria-label", "Mover " + item.label + " para cima"); up.disabled = pos <= 0;
        var down = document.createElement("button"); down.type = "button"; down.dataset.sidebarAction = "move-down"; down.textContent = "↓"; down.title = "Mover para baixo"; down.setAttribute("aria-label", "Mover " + item.label + " para baixo"); down.disabled = pos < 0 || pos >= pinnedOrder.length - 1;
        orderButtons.appendChild(up); orderButtons.appendChild(down);
      }
      var pin = row.querySelector(".extappRailPinButton"); pin.textContent = isPinned ? "Remover" : "Fixar"; pin.setAttribute("aria-pressed", String(isPinned)); pin.setAttribute("aria-label", (isPinned ? "Remover " : "Fixar ") + item.label + (isPinned ? " da Sidebar" : " na Sidebar"));
      if (!isPinned && state.pinned.length >= C.MAX_PINNED) pin.disabled = true;
      list.appendChild(row);
    });
    body.appendChild(list);
    var footer = document.createElement("div"); footer.className = "extappRailCustomizeFooter";
    footer.innerHTML = '<button type="button" class="extappRailResetButton" data-sidebar-action="reset-layout">Restaurar padrão</button><span>Alterações são salvas automaticamente.</span>';
    body.appendChild(footer);
  }

  function create(styles, initialState, initialWorkspace) {
    var state = initialState;
    var workspaceState = root.ExtensionUI.workspaceProfile ? root.ExtensionUI.workspaceProfile.normalize(initialWorkspace) : {};
    var existing = document.getElementById(C.HOST_ID); if (existing) existing.remove();
    var host = document.createElement("aside"); host.id = C.HOST_ID; host.setAttribute("aria-label", "ZVM - Automações"); host.setAttribute("data-extui-academy-target", "rail");
    var shadow = host.attachShadow({ mode: "open" });
    var sheet = new CSSStyleSheet(); sheet.replaceSync(styles); shadow.adoptedStyleSheets = [sheet];
    var stage = document.createElement("div"); stage.className = "extappRailStage";
    var shell = document.createElement("div"); shell.className = "extappRail";
    var logo = safeLogoUrl();
    shell.innerHTML = '<header class="extappRailHeader"><button class="extappRailBrand" type="button" data-command="dashboard.open" data-extui-academy-target="rail-logo" aria-label="Abrir Painel de Controle" title="Painel de Controle"><span class="extappRailBrandMark">' + (logo ? '<img alt="" src="' + logo + '">' : 'Z') + '</span><span class="extappRailBrandText">ZVM - Automações</span></button></header><div class="extappRailViewport"><nav class="extappRailPrimary" aria-label="Atalhos ZVM - Automações"></nav></div><footer class="extappRailFooter"></footer>';
    var tray = document.createElement("section"); tray.className = "extappRailTray"; tray.hidden = true; tray.setAttribute("role", "dialog"); tray.setAttribute("aria-modal", "false"); tray.setAttribute("aria-label", "Recursos da Sidebar");
    var toast = document.createElement("div"); toast.className = "extappRailToast"; toast.hidden = true; toast.setAttribute("role", "status");
    var hoverTip = document.createElement("div"); hoverTip.className = "extappRailHoverTip"; hoverTip.hidden = true; hoverTip.setAttribute("role", "tooltip");
    stage.appendChild(shell); stage.appendChild(tray); stage.appendChild(toast); stage.appendChild(hoverTip); shadow.appendChild(stage); document.body.appendChild(host);
    var toastTimer = null;
    var trayReturnFocus = null;

    var hoverTipTarget = null;
    function hideHoverTip() { hoverTipTarget = null; hoverTip.hidden = true; hoverTip.textContent = ""; hoverTip.style.top = ""; }
    function showHoverTip(button) {
      if (!button || state.expanded || !button.isConnected || button.disabled) { hideHoverTip(); return; }
      var label = String(button.dataset.hoverLabel || button.querySelector(".extappRailLabel") && button.querySelector(".extappRailLabel").textContent || "").trim();
      if (!label) { hideHoverTip(); return; }
      hoverTipTarget = button; hoverTip.textContent = label; hoverTip.hidden = false;
      var rect = button.getBoundingClientRect(), stageRect = stage.getBoundingClientRect();
      var top = Math.max(8, Math.min(stageRect.height - hoverTip.offsetHeight - 8, rect.top - stageRect.top + (rect.height - hoverTip.offsetHeight) / 2));
      hoverTip.style.top = Math.round(top) + "px";
    }
    shell.addEventListener("pointerover", function (event) { var button = event.target && event.target.closest ? event.target.closest(".extappRailItem") : null; if (button) showHoverTip(button); });
    shell.addEventListener("pointerout", function (event) { var button = event.target && event.target.closest ? event.target.closest(".extappRailItem") : null; if (!button || button !== hoverTipTarget) return; var next = event.relatedTarget; if (next && button.contains(next)) return; hideHoverTip(); });
    shell.addEventListener("focusin", function (event) { var button = event.target && event.target.closest ? event.target.closest(".extappRailItem") : null; if (button) showHoverTip(button); });
    shell.addEventListener("focusout", function (event) { var button = event.target && event.target.closest ? event.target.closest(".extappRailItem") : null; if (button === hoverTipTarget) hideHoverTip(); });
    function syncWidthFlags() {
      stage.toggleAttribute("data-expanded", !!state.expanded); if (state.expanded) hideHoverTip();
      shell.toggleAttribute("data-expanded", !!state.expanded);
      host.style.width = (state.expanded ? C.EXPANDED_WIDTH : C.COLLAPSED_WIDTH) + "px";
      var toggle = shadow.querySelector('[data-command="sidebar.expand.toggle"]');
      if (toggle) {
        var toggleLabel=state.expanded?"Recolher menu":"Expandir menu";
        toggle.setAttribute("aria-pressed", String(!!state.expanded));toggle.title=toggleLabel;toggle.setAttribute("aria-label",toggleLabel);
        var labelEl=toggle.querySelector(".extappRailLabel");if(labelEl)labelEl.textContent=toggleLabel;
      }
    }
    function uniqueItems(items) {
      var seen = new Set();
      var out = [];
      (Array.isArray(items) ? items : []).forEach(function (item) {
        if (!item || !item.key || seen.has(item.key)) return;
        seen.add(item.key);
        out.push(item);
      });
      return out;
    }
    function sanitizeRenderedRail() {
      var primaryAllowed = new Set(Array.isArray(state.pinned) ? state.pinned : []);
      var footerAllowed = new Set((Array.isArray(state.footerPinned) ? state.footerPinned : []).concat(["system","rail-toggle"]));
      var primaryEl = shell.querySelector(".extappRailPrimary");
      if (primaryEl) {
        var primarySeen = new Set();
        primaryEl.querySelectorAll(".extappRailItem").forEach(function (button) {
          var key = String(button.dataset.key || "");
          if (!key || !primaryAllowed.has(key) || primarySeen.has(key)) { button.remove(); return; }
          primarySeen.add(key);
        });
      }
      var footerEl = shell.querySelector(".extappRailFooter");
      if (footerEl) {
        var footerSeen = new Set();
        footerEl.querySelectorAll(".extappRailItem").forEach(function (button) {
          var key = String(button.dataset.key || "");
          if (!key || !footerAllowed.has(key) || footerSeen.has(key)) { button.remove(); return; }
          footerSeen.add(key);
        });
      }
    }
    function renderPrimary() {
      var items=root.ExtensionUI.workspaceProfile?root.ExtensionUI.workspaceProfile.primary(state,workspaceState):registry.primary(state);
      renderItems(shell.querySelector(".extappRailPrimary"), uniqueItems(items));
    }
    function renderFooter() {
      var footerSet = new Set(Array.isArray(state.footerPinned) ? state.footerPinned : []);
      var footerOrder = [];
      (Array.isArray(state.order) ? state.order : []).concat(Array.from(footerSet)).forEach(function (key) {
        if (!footerSet.has(key) || footerOrder.indexOf(key) >= 0 || key === "system" || key === "rail-toggle") return;
        var item = registry.get(key);
        if (item) footerOrder.push(key);
      });
      var footerItems = footerOrder.map(registry.get).filter(Boolean);
      renderItems(shell.querySelector(".extappRailFooter"), uniqueItems(footerItems.concat(registry.footerImmutable || [])));
    }
    function applyState(next) {
      state = root.ExtensionUI.sidebarStorage.normalize(next || state);
      renderPrimary(); renderFooter(); syncWidthFlags(); sanitizeRenderedRail();
      if (!tray.hidden && tray.getAttribute("data-kind") === "customize") renderCustomizeTray(tray, state);
      else if (!tray.hidden && tray.getAttribute("data-kind")) renderGenericTray(tray, tray.getAttribute("data-kind"), state, workspaceState);
      return state;
    }
    function applyWorkspace(next) {
      workspaceState = root.ExtensionUI.workspaceProfile ? root.ExtensionUI.workspaceProfile.normalize(next || {}) : {};
      renderPrimary();
      if (!tray.hidden && tray.getAttribute("data-kind") && tray.getAttribute("data-kind") !== "customize") renderGenericTray(tray, tray.getAttribute("data-kind"), state, workspaceState);
      return workspaceState;
    }
    function syncTrayTriggerState(activeKind) {
      var commandByKind = { automations: "sidebar.automations.open", customize: "sidebar.customize.open" };
      Object.keys(commandByKind).forEach(function (kind) {
        var command = commandByKind[kind];
        shadow.querySelectorAll('[data-command="' + command + '"]').forEach(function (button) {
          var active = !!activeKind && activeKind === kind;
          button.toggleAttribute("data-active", active);
          button.setAttribute("aria-pressed", String(active));
          if (active) button.setAttribute("aria-current", "page"); else button.removeAttribute("aria-current");
        });
      });
    }
    function closeTray(restoreFocus) {
      var activeBefore = shadow.activeElement;
      var triggerBefore = trayReturnFocus;
      tray.hidden = true; tray.removeAttribute("data-kind"); tray.innerHTML = ""; stage.removeAttribute("data-tray-open");
      syncTrayTriggerState(null);
      if (restoreFocus !== false && triggerBefore && triggerBefore.isConnected && typeof triggerBefore.focus === "function") { try { triggerBefore.focus({ preventScroll: true }); } catch (_) { try { triggerBefore.focus(); } catch (_) {} } }
      else if (restoreFocus === false) {
        if (activeBefore && typeof activeBefore.blur === "function") { try { activeBefore.blur(); } catch (_) {} }
        if (triggerBefore && typeof triggerBefore.blur === "function") { try { triggerBefore.blur(); } catch (_) {} }
        shadow.querySelectorAll('[data-command="sidebar.automations.open"],[data-command="sidebar.customize.open"]').forEach(function(button){
          button.removeAttribute("data-active"); button.removeAttribute("data-tray-open"); button.setAttribute("aria-pressed","false"); button.removeAttribute("aria-current");
          if (button !== shadow.activeElement && typeof button.blur === "function") { try { button.blur(); } catch (_) {} }
        });
      }
      trayReturnFocus = null;
    }
    function openTray(kind) {
      if (kind !== "customize" && !trays[kind]) return false;
      if (!tray.hidden && tray.getAttribute("data-kind") === kind) { closeTray(); return false; }
      trayReturnFocus = shadow.activeElement || document.activeElement;
      if (kind === "customize") renderCustomizeTray(tray, state); else renderGenericTray(tray, kind, state, workspaceState);
      tray.hidden = false; tray.setAttribute("data-kind", kind); tray.setAttribute("aria-label", trayTitle(kind)[0]); stage.setAttribute("data-tray-open", "true");
      syncTrayTriggerState(kind);
      requestAnimationFrame(function () { var first = tray.querySelector(".extappRailTrayClose,button:not([disabled])"); if (first) first.focus(); });
      return true;
    }
    function setCommandState(command, descriptor) {
      var trayKindByCommand = { "sidebar.automations.open": "automations", "sidebar.customize.open": "customize" };
      var localTrayKind = trayKindByCommand[command] || "";
      shadow.querySelectorAll('[data-command="' + command.replace(/"/g, "") + '"]').forEach(function (button) {
        var enabled = !descriptor || descriptor.registered !== false && descriptor.enabled !== false;
        var active = localTrayKind ? (!tray.hidden && tray.getAttribute("data-kind") === localTrayKind) : !!(descriptor && descriptor.state && descriptor.state.active);
        var planLocked = !!(descriptor && descriptor.state && descriptor.state.locked);
        button.disabled = !enabled; button.setAttribute("aria-disabled", String(!enabled));
        button.toggleAttribute("data-active", active);
        button.toggleAttribute("data-plan-locked",planLocked); button.setAttribute("aria-pressed", String(active));
        if (active) button.setAttribute("aria-current", "page"); else button.removeAttribute("aria-current");
        var badge = descriptor && descriptor.state ? descriptor.state.badge : null;
        var badgeEl = button.querySelector(".extappRailBadge");
        if (badgeEl) {
          var n = Number(badge); var show = Number.isFinite(n) && n > 0;
          badgeEl.hidden = !show; badgeEl.textContent = show ? (n > 99 ? "99+" : String(n)) : "";
          if (show) badgeEl.setAttribute("aria-label", n + " pendente(s)"); else badgeEl.removeAttribute("aria-label");
        }
      });
    }
    function setBusy(button, busy) { if (!button) return; button.toggleAttribute("data-busy", !!busy); if (button.__extBusyVisualTimer) { clearTimeout(button.__extBusyVisualTimer); button.__extBusyVisualTimer = 0; } var indicator = button.querySelector(".extappRailBusy"); if (!busy) { button.removeAttribute("aria-busy"); button.removeAttribute("data-busy-visible"); if (indicator) indicator.hidden = true; return; } button.setAttribute("aria-busy", "true"); if (indicator) indicator.hidden = true; button.__extBusyVisualTimer = setTimeout(function () { button.__extBusyVisualTimer = 0; if (!button.hasAttribute("data-busy")) return; button.setAttribute("data-busy-visible", "true"); if (indicator) indicator.hidden = false; }, 450); }
    function notify(message, error) {
      if (toastTimer) clearTimeout(toastTimer);
      toast.setAttribute("role", error ? "alert" : "status"); toast.setAttribute("aria-live", error ? "assertive" : "polite"); toast.setAttribute("aria-atomic","true");
      toast.textContent = String(message || ""); toast.toggleAttribute("data-error", !!error); toast.hidden = !message;
      if (message) toastTimer = setTimeout(function () { toast.hidden = true; }, error ? 4200 : 2600);
    }
    function setPeek(on) { if (state.expanded || stage.hasAttribute("data-tray-open")) stage.removeAttribute("data-peek"); else stage.toggleAttribute("data-peek", !!on); }
    applyState(state);
    return { host: host, shadow: shadow, stage: stage, shell: shell, tray: tray, openTray: openTray, closeTray: closeTray, applyState: applyState, applyWorkspace: applyWorkspace, getState: function () { return state; }, getWorkspace: function(){return workspaceState;}, setCommandState: setCommandState, setBusy: setBusy, notify: notify, setPeek: setPeek };
  }
  root.ExtensionUI.sidebarShell = Object.freeze({ create: create });
})(globalThis);
