(function (root) {
  "use strict";
  var C = root.ExtensionUI.sidebarConstants;
  var original = null;
  var app = null;
  var treeObserver = null;
  var styleObserver = null;
  var placementObserver = null;
  var scheduled = false;
  var width = C.COLLAPSED_WIDTH;
  var side = "left";

  function findApp() { var node = document.getElementById("app"); return node && node.isConnected ? node : null; }
  function readSide() { return document.documentElement && document.documentElement.getAttribute("data-extui-sidebar-placement") === "right-conversation" ? "right" : "left"; }
  function snapshot(node) { return { marginLeft: node.style.marginLeft, marginRight: node.style.marginRight, width: node.style.width, maxWidth: node.style.maxWidth }; }
  function expectedWidth() { return "calc(100% - " + width + "px)"; }
  function syncHostSide() { var host=document.getElementById(C.HOST_ID);if(host)host.setAttribute("data-placement",side === "right" ? "right-conversation" : "left-native"); }
  function ensureOffset(node) {
    if (!node) return false;
    var targetWidth = expectedWidth();
    if (side === "right") {
      if (node.style.marginLeft !== (original && original.marginLeft || "")) node.style.marginLeft = original && original.marginLeft || "";
      if (node.style.marginRight !== width + "px") node.style.marginRight = width + "px";
    } else {
      if (node.style.marginRight !== (original && original.marginRight || "")) node.style.marginRight = original && original.marginRight || "";
      if (node.style.marginLeft !== width + "px") node.style.marginLeft = width + "px";
    }
    if (node.style.width !== targetWidth) node.style.width = targetWidth;
    if (node.style.maxWidth !== targetWidth) node.style.maxWidth = targetWidth;
    if (node.getAttribute("data-ext-v2-offset") !== String(width)) node.setAttribute("data-ext-v2-offset", String(width));
    node.setAttribute("data-ext-v2-side",side);syncHostSide();
    return true;
  }
  function observeStyle(node) {
    if (styleObserver) styleObserver.disconnect();
    styleObserver = new MutationObserver(function () {
      if (!scheduled) { scheduled = true; requestAnimationFrame(function () { scheduled = false; if (app && app.isConnected) ensureOffset(app); }); }
    });
    styleObserver.observe(node, { attributes: true, attributeFilter: ["style"] });
  }
  function applyTo(node) {
    if (!node) return false;
    if (app !== node) { releaseApp(); app = node; original = snapshot(node); observeStyle(node); }
    return ensureOffset(node);
  }
  function releaseApp() {
    if (styleObserver) styleObserver.disconnect(); styleObserver = null;
    if (!app) return;
    if (original) { app.style.marginLeft = original.marginLeft; app.style.marginRight = original.marginRight; app.style.width = original.width; app.style.maxWidth = original.maxWidth; }
    app.removeAttribute("data-ext-v2-offset"); app.removeAttribute("data-ext-v2-side"); app = null; original = null;
  }
  function emitLayout() {
    try { root.dispatchEvent(new CustomEvent("ext:sidebar-v2-layout", { detail: { width: width, side: side } })); } catch (_) {}
  }
  function setWidth(next) {
    next = Number(next) === C.EXPANDED_WIDTH ? C.EXPANDED_WIDTH : C.COLLAPSED_WIDTH;
    if (next === width) return width;
    width = next;
    if (app && app.isConnected) ensureOffset(app); else applyTo(findApp());
    emitLayout();
    return width;
  }
  function setSide(next) {
    next = next === "right" || next === "right-conversation" ? "right" : "left";
    if (side === next) { syncHostSide(); return side; }
    side = next;syncHostSide();
    if (app && app.isConnected) ensureOffset(app); else applyTo(findApp());
    emitLayout();return side;
  }
  function syncSideFromDocument(){return setSide(readSide());}
  function mount() {
    side=readSide();syncHostSide();applyTo(findApp()); emitLayout();
    if (!treeObserver && document.documentElement) {
      treeObserver = new MutationObserver(function () { var next = findApp(); if (next && next !== app) applyTo(next); });
      treeObserver.observe(document.documentElement, { childList: true, subtree: true });
    }
    if (!placementObserver && document.documentElement) {
      placementObserver = new MutationObserver(function(){syncSideFromDocument();});
      placementObserver.observe(document.documentElement,{attributes:true,attributeFilter:["data-extui-sidebar-placement"]});
    }
  }
  function unmount() { if (treeObserver) treeObserver.disconnect(); treeObserver = null;if(placementObserver)placementObserver.disconnect();placementObserver=null; releaseApp(); }
  root.ExtensionUI.sidebarPlacement = Object.freeze({ mount: mount, unmount: unmount, setWidth: setWidth, setSide:setSide, syncSide:syncSideFromDocument, width: function () { return width; }, side:function(){return side;} });
})(globalThis);
