(function (root) {
  "use strict";
  var registry = new Map();
  var listeners = new Set();

  function assertId(id) {
    if (typeof id !== "string" || !/^[a-z][a-z0-9.-]+$/.test(id)) throw new Error("Invalid command id");
  }

  function register(id, descriptor) {
    assertId(id);
    if (!descriptor || typeof descriptor.execute !== "function") throw new Error("Command execute handler required");
    if (registry.has(id)) throw new Error("Command already registered: " + id);
    registry.set(id, Object.freeze({
      execute: descriptor.execute,
      canExecute: typeof descriptor.canExecute === "function" ? descriptor.canExecute : function () { return true; },
      getState: typeof descriptor.getState === "function" ? descriptor.getState : function () { return null; }
    }));
    emit({ type: "registered", id: id });
    return function () { unregister(id); };
  }

  function unregister(id) {
    if (registry.delete(id)) emit({ type: "unregistered", id: id });
  }

  async function execute(id, payload) {
    var item = registry.get(id);
    if (!item) throw new Error("Unknown command: " + id);
    var context = payload || {};
    if (!(await item.canExecute(context))) {
      var err = new Error("Command unavailable: " + id);
      err.code = "COMMAND_UNAVAILABLE";
      throw err;
    }
    emit({ type: "executing", id: id, payload: context });
    try {
      var result = await item.execute(context);
      emit({ type: "executed", id: id, payload: context, result: result });
      return result;
    } catch (error) {
      emit({ type: "failed", id: id, payload: context, error: error });
      throw error;
    }
  }

  async function state(id, payload) {
    var item = registry.get(id);
    if (!item) return { registered: false, enabled: false, state: null };
    var context = payload || {};
    var enabled = !!(await item.canExecute(context));
    var value = await item.getState(context);
    return { registered: true, enabled: enabled, state: value };
  }

  function has(id) { return registry.has(id); }
  function list() { return Array.from(registry.keys()); }
  function subscribe(listener) {
    if (typeof listener !== "function") throw new Error("Listener required");
    listeners.add(listener);
    return function () { listeners.delete(listener); };
  }
  function emit(event) {
    listeners.forEach(function (listener) {
      try { listener(event); } catch (error) { if (root.__extReportRuntimeError) root.__extReportRuntimeError("COMMAND_BUS_LISTENER_FAILED", error); }
    });
  }

  root.ExtensionUI = root.ExtensionUI || {};
  root.ExtensionUI.commands = Object.freeze({ register: register, unregister: unregister, execute: execute, state: state, has: has, list: list, subscribe: subscribe });
})(globalThis);
