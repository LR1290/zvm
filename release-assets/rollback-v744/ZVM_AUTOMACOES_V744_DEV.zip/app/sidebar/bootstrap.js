(function (root) {
  "use strict";
  function mountAuthorized() {
    if (!root.ExtensionUI || !root.ExtensionUI.sidebarLifecycle) return;
    root.ExtensionUI.sidebarLifecycle.mount(root.__EXT_SIDEBAR_CSS__).catch(function (error) {
      if (root.__extReportRuntimeError) root.__extReportRuntimeError("SIDEBAR_MOUNT_FAILED", error);
      else if (root.__extRecordBootError) root.__extRecordBootError(error);
    });
  }
  function onAuthState(ev) {
    var state = ev && ev.detail && ev.detail.state || "";
    if (state === "forceLogout" || state === "validationUnavailable") {
      if (root.ExtensionUI && root.ExtensionUI.sidebarLifecycle) root.ExtensionUI.sidebarLifecycle.unmount();
      return;
    }
    if (state === "restored" || state === "offlineGrace") mountAuthorized();
  }
  root.addEventListener("extui-s0-state", onAuthState);
  mountAuthorized();
})(globalThis);
