(function (root) {
  "use strict";
  var STORE_KEY = "EXTUI:adaptiveWorkspaceStore";
  var MODEL_KEYS = Object.freeze({
    sales: Object.freeze(["crm","crm-funnel","quick-response","flow","funnel","followup","agenda","export"]),
    clinic: Object.freeze(["agenda","crm","quick-response","followup","flow","funnel"]),
    realestate: Object.freeze(["crm","crm-funnel","quick-response","agenda","followup","flow","funnel"]),
    billing: Object.freeze(["crm","quick-response","followup","agenda","flow","funnel"]),
    restaurant: Object.freeze(["orders","crm","quick-response","agenda","flow","funnel"]),
    store: Object.freeze(["orders","crm","items","quick-response","flow","funnel","export"]),
    support: Object.freeze(["crm","quick-response","followup","agenda","items","flow"]),
    services: Object.freeze(["agenda","crm","quick-response","followup","flow","funnel"]),
    delivery: Object.freeze(["orders","delivery","crm","quick-response","agenda","integrations","flow","funnel"]),
    b2b: Object.freeze(["crm","crm-funnel","quick-response","agenda","followup","flow","funnel"]),
    team: Object.freeze(["crm","agenda","quick-response","integrations","export"]),
    automation: Object.freeze(["flow","funnel","followup","auto-service","quick-response","integrations","webhooks","tools"])
  });
  function parse(raw){try{if(typeof raw==="string")raw=JSON.parse(raw);if(raw&&raw.state)raw=raw.state;}catch(_){raw={};}return raw&&typeof raw==="object"&&!Array.isArray(raw)?raw:{};}
  function normalize(raw){var source=parse(raw),ids=(Array.isArray(source.activeModels)?source.activeModels:[]).filter(function(id,index,list){return (id==="custom"||Object.prototype.hasOwnProperty.call(MODEL_KEYS,id))&&list.indexOf(id)===index;});return{schemaVersion:Math.max(1,Number(source.schemaVersion)||1),activeModels:ids,focusedMode:source.focusedMode===true,updatedAt:Math.max(0,Number(source.updatedAt)||0)};}
  function orderedKeys(state){state=normalize(state);if(!state.focusedMode||!state.activeModels.length||state.activeModels.indexOf("custom")>=0)return null;var out=[];state.activeModels.forEach(function(id){var keys=MODEL_KEYS[id]||[];keys.forEach(function(key){if(out.indexOf(key)<0)out.push(key);});});if(out.indexOf("activity")<0)out.push("activity");return out;}
  function allowed(state){var order=orderedKeys(state);return order?new Set(order):null;}
  function visible(item,state){return !!item;}
  function primary(sidebarState,workspaceState){var order=orderedKeys(workspaceState),registry=root.ExtensionUI.sidebarRegistry;if(!registry)return[];var base=registry.primary(sidebarState)||[];if(!order)return base;var max=root.ExtensionUI.sidebarConstants&&root.ExtensionUI.sidebarConstants.MAX_PINNED||15,out=[],seen=new Set(),baseByKey=new Map();base.forEach(function(item){if(item)baseByKey.set(item.key,item);});order.forEach(function(key){var item=baseByKey.get(key);if(item&&!seen.has(item.key)){out.push(item);seen.add(item.key);}});base.forEach(function(item){if(item&&!seen.has(item.key)){out.push(item);seen.add(item.key);}});return out.slice(0,max);}
  async function load(){try{if(root.chrome&&chrome.storage&&chrome.storage.local){var result=await chrome.storage.local.get(STORE_KEY);return normalize(result&&result[STORE_KEY]);}}catch(_){}return normalize({});}
  function subscribe(listener){if(typeof listener!=="function")return function(){};try{if(root.chrome&&chrome.storage&&chrome.storage.onChanged){var fn=function(changes,area){if(area!=="local"||!changes[STORE_KEY])return;listener(normalize(changes[STORE_KEY].newValue));};chrome.storage.onChanged.addListener(fn);return function(){try{chrome.storage.onChanged.removeListener(fn);}catch(_){}};}}catch(_){}return function(){};}
  root.ExtensionUI.workspaceProfile=Object.freeze({version:"2.1.0",STORE_KEY:STORE_KEY,models:MODEL_KEYS,normalize:normalize,orderedKeys:orderedKeys,allowed:allowed,visible:visible,primary:primary,load:load,subscribe:subscribe});
})(globalThis);
