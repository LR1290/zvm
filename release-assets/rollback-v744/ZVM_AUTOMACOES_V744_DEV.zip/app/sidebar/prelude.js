;(function(root){
  "use strict";
  root.__EXT_SIDEBAR_ENABLED__=true;
  if(root.__extBootPhases)return;

  var startedAt=(root.performance&&typeof root.performance.now==="function")?root.performance.now():Date.now();
  var states={1:true,2:false,3:false};
  var queues={2:[],3:[]};
  var marks=Object.create(null);
  var longTasks={count:0,totalMs:0,maxMs:0,items:[]};
  var budget=Object.freeze({sidebarVisibleMs:1200,contentCompleteMs:3600,phase3Ms:4200,longTaskMaxMs:220,longTaskTotalMs:900});
  marks["boot:start"]=startedAt;
  try{if(root.PerformanceObserver){var po=new PerformanceObserver(function(list){list.getEntries().forEach(function(entry){var d=Math.max(0,Number(entry.duration)||0);longTasks.count++;longTasks.totalMs+=d;longTasks.maxMs=Math.max(longTasks.maxMs,d);if(longTasks.items.length<12)longTasks.items.push({startTime:Math.round((Number(entry.startTime)||0)*10)/10,duration:Math.round(d*10)/10});});});po.observe({entryTypes:["longtask"]});setTimeout(function(){try{po.disconnect();}catch(_){}},15000);}}catch(_){}

  function now(){return(root.performance&&typeof root.performance.now==="function")?root.performance.now():Date.now();}
  function mark(name){marks[String(name)]=now();try{if(root.performance&&root.performance.mark)root.performance.mark("ext:"+String(name));}catch(_){}return marks[String(name)];}
  function elapsed(name){var t=marks[String(name)];return typeof t==="number"?Math.max(0,now()-t):null;}
  function run(fn){try{var r=fn();if(r&&typeof r.catch==="function")r.catch(function(err){if(root.__extReportRuntimeError)root.__extReportRuntimeError("BOOT_PHASE_TASK_FAILED",err);});}catch(err){if(root.__extReportRuntimeError)root.__extReportRuntimeError("BOOT_PHASE_TASK_FAILED",err);} }
  function when(phase,fn){phase=Number(phase)||1;if(phase<=1||states[phase]){queueMicrotask(function(){run(fn);});return function(){};}var list=queues[phase]||(queues[phase]=[]);list.push(fn);return function(){var i=list.indexOf(fn);if(i>=0)list.splice(i,1);};}
  function enter(phase){phase=Number(phase)||1;if(states[phase])return;states[phase]=true;mark("phase"+phase);var list=(queues[phase]||[]).splice(0);list.forEach(function(fn){queueMicrotask(function(){run(fn);});});try{root.dispatchEvent(new CustomEvent("ext:boot-phase"+phase,{detail:{phase:phase,at:Date.now()}}));}catch(_){} }
  function metric(name){var t=marks[String(name)];return typeof t==="number"?Math.max(0,t-startedAt):null;}
  function evaluate(){var sidebar=metric("sidebar:visible"),content=metric("content:complete"),phase3=metric("phase3");return{sidebar:sidebar==null?"pending":(sidebar<=budget.sidebarVisibleMs?"pass":"slow"),content:content==null?"pending":(content<=budget.contentCompleteMs?"pass":"slow"),phase3:phase3==null?"pending":(phase3<=budget.phase3Ms?"pass":"slow"),longTasks:(longTasks.maxMs<=budget.longTaskMaxMs&&longTasks.totalMs<=budget.longTaskTotalMs)?"pass":"slow"};}
  function snapshot(){return{startedAt:startedAt,phase1:states[1],phase2:states[2],phase3:states[3],marks:Object.assign({},marks),metrics:{sidebarVisibleMs:metric("sidebar:visible"),sidebarMountedMs:metric("sidebar:mounted"),contentStartMs:metric("content:start"),contentCompleteMs:metric("content:complete"),secureChannelReadyMs:metric("wpp:secure-channel-ready"),phase2Ms:metric("phase2"),phase3Ms:metric("phase3")},longTasks:{count:longTasks.count,totalMs:Math.round(longTasks.totalMs*10)/10,maxMs:Math.round(longTasks.maxMs*10)/10,items:longTasks.items.slice()},budget:budget,status:evaluate(),uptimeMs:Math.max(0,now()-startedAt)};}

  Object.defineProperty(root,"__extBootPhases",{value:Object.freeze({when:when,enter:enter,mark:mark,elapsed:elapsed,snapshot:snapshot,evaluate:evaluate,budget:budget}),configurable:false,writable:false});
  mark("phase1");

  function mountFastRail(){
    if(!root.document||document.getElementById("extapp-fast-boot-rail"))return;
    var style=document.createElement("style");style.id="extapp-fast-boot-style";style.textContent="#extapp-fast-boot-rail{position:fixed;left:0;top:0;bottom:0;width:54px;z-index:1495;display:flex;align-items:flex-start;justify-content:center;padding-top:14px;background:transparent;border-right:1px solid transparent;box-sizing:border-box;transition:opacity .16s ease,transform .16s ease}#extapp-fast-boot-rail .extuifb-logo{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;color:var(--extui-primary-bright,#19e58c);border:1px solid color-mix(in srgb,var(--extui-primary,#19e58c) 28%,transparent);font:800 18px/1 system-ui,sans-serif;background:color-mix(in srgb,var(--extui-primary,#19e58c) 7%,var(--extui-card,rgba(11,16,14,.97)));box-shadow:0 0 0 1px color-mix(in srgb,var(--extui-text,#fff) 14%,transparent) inset}#extapp-fast-boot-rail .extuifb-pulse{position:absolute;top:54px;width:4px;height:4px;border-radius:999px;background:var(--extui-primary-bright,#19e58c);animation:extuifbPulse 1s ease-in-out infinite}@keyframes extuifbPulse{0%,100%{opacity:.28;transform:scale(.8)}50%{opacity:1;transform:scale(1.35)}}#extapp-fast-boot-rail.is-done{opacity:0;transform:translateX(-6px);pointer-events:none}@media(prefers-reduced-motion:reduce){#extapp-fast-boot-rail,.extuifb-pulse{transition:none;animation:none}}";
    (document.head||document.documentElement).appendChild(style);
    var rail=document.createElement("div");rail.id="extapp-fast-boot-rail";rail.setAttribute("aria-hidden","true");rail.innerHTML='<span class="extuifb-logo" aria-hidden="true">•</span><span class="extuifb-pulse"></span>';
    (document.documentElement||document.body).appendChild(rail);
    function remove(){var r=document.getElementById("extapp-fast-boot-rail");if(!r)return;r.classList.add("is-done");setTimeout(function(){if(r&&r.isConnected)r.remove();var s=document.getElementById("extapp-fast-boot-style");if(s&&s.isConnected)s.remove();},190);mark("sidebar:visible");}
    root.addEventListener("ext:sidebar-v2-ready",remove,{once:true});
    setTimeout(remove,4500);
  }
  function removeFastRail(){var r=document.getElementById("extapp-fast-boot-rail");if(r&&r.isConnected)r.remove();var st=document.getElementById("extapp-fast-boot-style");if(st&&st.isConnected)st.remove();}
  function mountFastRailIfAuthorized(){
    try{
      if(!root.chrome||!chrome.runtime||!chrome.runtime.sendMessage)return;
      chrome.runtime.sendMessage({type:"EXTUI_S0_C",forceNetwork:false},function(response){
        if(chrome.runtime.lastError){void chrome.runtime.lastError;return;}
        if(response&&response.ok===true&&response.result&&response.result.authorized===true)mountFastRail();
        else removeFastRail();
      });
    }catch(_){}
  }
  root.addEventListener("extui-s0-state",function(ev){var state=ev&&ev.detail&&ev.detail.state||"";if(state==="restored"||state==="offlineGrace")mountFastRailIfAuthorized();else if(state==="forceLogout"||state==="validationUnavailable")removeFastRail();});
  mountFastRailIfAuthorized();

  function schedulePhase2(){
    if(states[2])return;
    setTimeout(function(){enter(2);schedulePhase3();},0);
  }
  function schedulePhase3(){
    if(states[3])return;
    var launch=function(){if(document.visibilityState==="hidden"){var once=function(){if(document.visibilityState!=="visible")return;document.removeEventListener("visibilitychange",once);launch();};document.addEventListener("visibilitychange",once);return;}enter(3);};
    if(typeof root.requestIdleCallback==="function")root.requestIdleCallback(launch,{timeout:2400});
    else setTimeout(launch,1600);
  }

  root.addEventListener("ext:boot-phase3",function(){
    try{if(root.chrome&&chrome.runtime&&chrome.runtime.sendMessage)chrome.runtime.sendMessage({type:"EXTUI_IDLE_SECURITY_PRIME"},function(){void chrome.runtime.lastError;});}catch(_){}
    setTimeout(function(){try{if(root.chrome&&chrome.storage&&chrome.storage.session){var report=snapshot(),payload={};payload["EXTUI:perfLastBoot"]=report;chrome.storage.session.set(payload,function(){void chrome.runtime.lastError;});}}catch(_){}},1400);
  },{once:true});
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",schedulePhase2,{once:true});else schedulePhase2();
})(globalThis);
