(function (root) {
  "use strict";
  var C = root.ExtensionUI.sidebarConstants;
  var mounted = null;
  var unsubscribeBus = null;
  var unsubscribeStorage = null;
  var unsubscribeWorkspace = null;
  var unsubscribeTheme = null;
  var localUnregister = [];
  var stateRefreshTimer = null;
  var panelStateHandler = null;
  var outsideHandler = null;
  var keyHandler = null;

  async function dispatch(command, source, payload) {
    var bus = root.ExtensionUI.commands;
    var context = Object.assign({ source: source || "sidebar-v2" }, payload || {});
    if (context.source === "sidebar-v2" && !Object.prototype.hasOwnProperty.call(context,"toggle")) context.toggle = true;
    var state = await bus.state(command, context);
    if (!state.registered || !state.enabled) return false;
    await bus.execute(command, context);
    return true;
  }
  function payloadFrom(target) {
    if (!target || !target.dataset.payload) return {};
    try { return JSON.parse(target.dataset.payload) || {}; } catch (_) { return {}; }
  }
  async function refreshStates() {
    if (!mounted) return;
    var commands = new Set();
    mounted.shadow.querySelectorAll("[data-command]").forEach(function (node) { if (node.dataset.command) commands.add(node.dataset.command); });
    await Promise.all(Array.from(commands).map(async function (id) {
      try { mounted.setCommandState(id, await root.ExtensionUI.commands.state(id, { source: "sidebar-v2-state" })); }
      catch (_) { mounted.setCommandState(id, { registered: true, enabled: false, state: null }); }
    }));
  }
  function scheduleStateRefresh(delay) {
    if (stateRefreshTimer) clearTimeout(stateRefreshTimer);
    stateRefreshTimer = setTimeout(function () { stateRefreshTimer = null; refreshStates().catch(function () {}); }, typeof delay === "number" ? delay : 40);
  }
  function localGroupState(ids, trayKind) {
    return async function () {
      var active = !!(mounted && !mounted.tray.hidden && mounted.tray.getAttribute("data-kind") === trayKind);
      if (!active && ids && ids.length) {
        for (var i = 0; i < ids.length; i++) {
          try { var s = await root.ExtensionUI.commands.state(ids[i], { source: "sidebar-v2-group-state" }); if (s && s.state && s.state.active) { active = true; break; } } catch (_) {}
        }
      }
      return { active: active };
    };
  }
  function registerLocalCommands() {
    var bus = root.ExtensionUI.commands;
    var defs = [
      ["sidebar.automations.open", "automations", ["flow.open", "funnel.open", "followup.open", "auto-service.open"]],
      ["sidebar.customize.open", "customize", []]
    ];
    defs.forEach(function (def) {
      if (bus.has(def[0])) return;
      localUnregister.push(bus.register(def[0], {
        getState: localGroupState(def[2], def[1]),
        execute: function () { var opened = mounted && mounted.openTray(def[1]); scheduleStateRefresh(0); return opened; }
      }));
    });
    if(!bus.has("sidebar.expand.toggle")){
      localUnregister.push(bus.register("sidebar.expand.toggle",{
        getState:function(){return {active:!!(mounted&&mounted.getState().expanded)};},
        execute:async function(){if(!mounted)return false;var next=await root.ExtensionUI.sidebarStorage.setExpanded(!mounted.getState().expanded);await applyStoredState(next);return true;}
      }));
    }
    if(!bus.has("appearance.mode.toggle")){
      localUnregister.push(bus.register("appearance.mode.toggle",{
        getState:async function(){var api=root.__extThemeSystem||(root.ExtensionCore&&root.ExtensionCore.ThemeSystem);if(!api)return {available:false};try{var opts=await api.load(),mode=api.resolvedMode(opts);return {available:true,mode:mode,active:mode==="light"};}catch(_){return {available:false};}},
        canExecute:function(){var api=root.__extThemeSystem||(root.ExtensionCore&&root.ExtensionCore.ThemeSystem);return !!(api&&typeof api.load==="function"&&typeof api.save==="function");},
        execute:async function(){var api=root.__extThemeSystem||(root.ExtensionCore&&root.ExtensionCore.ThemeSystem);if(!api)throw new Error("Sistema de aparência indisponível.");var opts=await api.load();opts=api.normalize(opts);opts.mode=api.resolvedMode(opts)==="light"?"dark":"light";if(typeof api.withDefinition==="function")opts=api.withDefinition(opts);var saved=await api.save(opts);try{document.dispatchEvent(new CustomEvent("ext:appearance-updated",{detail:saved||opts}));}catch(_){}return saved||opts;}
      }));
    }
  }
  function captureCustomizeFocus() {
    if (!mounted || mounted.tray.hidden || mounted.tray.getAttribute("data-kind") !== "customize") return null;
    var active = mounted.shadow.activeElement;
    if (!active || !active.dataset || !active.dataset.sidebarAction) return null;
    var row = active.closest && active.closest("[data-pin-key]");
    return { action: active.dataset.sidebarAction, key: row && row.dataset.pinKey || "" };
  }
  function restoreCustomizeFocus(snapshot) {
    if (!snapshot || !mounted) return;
    requestAnimationFrame(function () {
      if (!mounted || mounted.tray.hidden || mounted.tray.getAttribute("data-kind") !== "customize") return;
      var action = String(snapshot.action || "").replace(/"/g, "");
      var key = String(snapshot.key || "").replace(/"/g, "");
      var selector = key ? '[data-pin-key="' + key + '"] [data-sidebar-action="' + action + '"]' : '[data-sidebar-action="' + action + '"]';
      var replacement = mounted.shadow.querySelector(selector);
      if (!replacement && key) replacement = mounted.shadow.querySelector('[data-pin-key="' + key + '"] button:not([disabled])');
      if (replacement && typeof replacement.focus === "function") replacement.focus();
    });
  }
  async function applyStoredState(next, focusHint) {
    if (!mounted) return;
    var focusSnapshot = focusHint || captureCustomizeFocus();
    mounted.applyState(next);
    root.ExtensionUI.sidebarPlacement.setWidth(next.expanded ? C.EXPANDED_WIDTH : C.COLLAPSED_WIDTH);
    restoreCustomizeFocus(focusSnapshot);
    scheduleStateRefresh(0);
  }
  async function handleSidebarAction(target) {
    if (!mounted || !target) return;
    var action = target.dataset.sidebarAction;
    if (!action) return;
    if (action === "close-tray") { mounted.closeTray(); scheduleStateRefresh(0); return; }
    var rowBefore = target.closest && target.closest("[data-pin-key]");
    var focusKey = rowBefore && rowBefore.dataset.pinKey || "";
    try {
      var next = null;
      if (action === "toggle-expanded") next = await root.ExtensionUI.sidebarStorage.setExpanded(!mounted.getState().expanded);
      else if (action === "reset-layout") next = await root.ExtensionUI.sidebarStorage.reset();
      else {
        var row = target.closest("[data-pin-key]"); var key = row && row.dataset.pinKey;
        if (!key) return;
        if (action === "toggle-pin") next = await root.ExtensionUI.sidebarStorage.togglePin(key);
        else if (action === "move-up") next = await root.ExtensionUI.sidebarStorage.move(key, -1);
        else if (action === "move-down") next = await root.ExtensionUI.sidebarStorage.move(key, 1);
      }
      if (next) await applyStoredState(next, { key: focusKey, action: action });
    } catch (error) { mounted.notify(error && error.message ? error.message : "Não foi possível salvar a Sidebar.", true); }
  }
  function bindInteraction() {
    mounted.shadow.addEventListener("click", function (event) {
      var local = event.target.closest && event.target.closest("[data-sidebar-action]");
      if (local) { event.preventDefault(); handleSidebarAction(local); return; }
      var target = event.target.closest && event.target.closest("[data-command]");
      if (!target || target.disabled || target.hasAttribute("data-busy")) return;
      var commandId = String(target.dataset.command || "");
      var trayCommand = commandId === "sidebar.automations.open" || commandId === "sidebar.customize.open";
      if (mounted && !target.closest(".extappRailTray") && !trayCommand) {
        mounted.closeTray(false);
        try { target.focus({ preventScroll: true }); } catch (_) { try { target.focus(); } catch (_) {} }
        scheduleStateRefresh(0);
      }
      mounted.setBusy(target, true);
      dispatch(target.dataset.command, "sidebar-v2", payloadFrom(target)).then(function (ok) {
        if (ok && mounted && target.closest(".extappRailTray") && target.dataset.command.indexOf("sidebar.") !== 0) mounted.closeTray(false);
        scheduleStateRefresh(25);
      }).catch(function (error) {
        mounted.notify(error && error.message ? error.message : "Recurso indisponível nesta aba.", true);
        scheduleStateRefresh(25);
      }).finally(function () { if (mounted) mounted.setBusy(target, false); });
    });
  }
  function authAllowsSidebar() {
    return new Promise(function (resolve) {
      try {
        if (!root.chrome || !chrome.runtime || !chrome.runtime.sendMessage) { resolve(false); return; }
        chrome.runtime.sendMessage({ type: "EXTUI_S0_C", forceNetwork: false }, function (response) {
          if (chrome.runtime.lastError) { void chrome.runtime.lastError; resolve(false); return; }
          resolve(!!(response && response.ok === true && response.result && response.result.authorized === true));
        });
      } catch (_) { resolve(false); }
    });
  }
  async function mount(styles) {
    if (mounted) return mounted;
    if (!(await authAllowsSidebar())) { unmount(); return null; }
    var state = await root.ExtensionUI.sidebarStorage.load();
    var workspaceState = root.ExtensionUI.workspaceProfile ? await root.ExtensionUI.workspaceProfile.load() : {};
    mounted = root.ExtensionUI.sidebarShell.create(styles, state, workspaceState);
    root.ExtensionUI.sidebarPlacement.setWidth(state.expanded ? C.EXPANDED_WIDTH : C.COLLAPSED_WIDTH);
    root.ExtensionUI.sidebarPlacement.mount();
    unsubscribeTheme = root.ExtensionUI.sidebarTheme.watch(mounted.shell);
    registerLocalCommands(); bindInteraction();
    unsubscribeStorage = root.ExtensionUI.sidebarStorage.subscribe(function (next) { applyStoredState(next).catch(function () {}); });
    if(root.ExtensionUI.workspaceProfile)unsubscribeWorkspace = root.ExtensionUI.workspaceProfile.subscribe(function(next){if(mounted&&typeof mounted.applyWorkspace==="function"){mounted.applyWorkspace(next);scheduleStateRefresh(0);}});
    unsubscribeBus = root.ExtensionUI.commands.subscribe(function (event) { if (event && ["executed", "registered", "unregistered", "failed"].indexOf(event.type) >= 0) scheduleStateRefresh(20); });
    panelStateHandler = function () { scheduleStateRefresh(20); };
    root.addEventListener("ext:panel-state", panelStateHandler);
    outsideHandler = function (event) { if (mounted && !mounted.tray.hidden && event.target !== mounted.host && !mounted.host.contains(event.target)) { mounted.closeTray(); scheduleStateRefresh(0); } };
    document.addEventListener("pointerdown", outsideHandler, true);
    keyHandler = function (event) { if (event.key === "Escape" && mounted && !mounted.tray.hidden) { mounted.closeTray(); scheduleStateRefresh(0); event.stopPropagation(); } };
    document.addEventListener("keydown", keyHandler, true);
    scheduleStateRefresh(0);
    try { if (root.__extBootPhases && root.__extBootPhases.mark) root.__extBootPhases.mark("sidebar:mounted"); } catch (_) {}
    try { root.dispatchEvent(new CustomEvent("ext:sidebar-v2-ready", { detail: { mounted: true, at: Date.now() } })); } catch (_) {}
    return mounted;
  }
  function unmount() {
    if (stateRefreshTimer) clearTimeout(stateRefreshTimer); stateRefreshTimer = null;
    if (unsubscribeBus) unsubscribeBus(); unsubscribeBus = null;
    if (unsubscribeStorage) unsubscribeStorage(); unsubscribeStorage = null;
    if (unsubscribeWorkspace) unsubscribeWorkspace(); unsubscribeWorkspace = null;
    if (unsubscribeTheme) unsubscribeTheme(); unsubscribeTheme = null;
    if (panelStateHandler) root.removeEventListener("ext:panel-state", panelStateHandler); panelStateHandler = null;
    if (outsideHandler) document.removeEventListener("pointerdown", outsideHandler, true); outsideHandler = null;
    if (keyHandler) document.removeEventListener("keydown", keyHandler, true); keyHandler = null;
    localUnregister.splice(0).forEach(function (fn) { try { fn(); } catch (_) {} });
    root.ExtensionUI.sidebarPlacement.unmount();
    if (mounted) mounted.closeTray(false);
    if (mounted && mounted.host) mounted.host.remove(); mounted = null;
  }
  function isVisible() { return !!(mounted && mounted.host && mounted.host.isConnected && !mounted.host.hidden); }
  async function setVisible(visible) {
    visible = visible !== false;
    if (!mounted && visible) await mount(root.__EXT_SIDEBAR_CSS__);
    if (!mounted) return false;
    mounted.host.hidden = !visible;
    if (visible) {
      var current = mounted.getState();
      root.ExtensionUI.sidebarPlacement.setWidth(current.expanded ? C.EXPANDED_WIDTH : C.COLLAPSED_WIDTH);
      root.ExtensionUI.sidebarPlacement.mount();
      scheduleStateRefresh(0);
    } else {
      mounted.closeTray();
      root.ExtensionUI.sidebarPlacement.unmount();
    }
    try { root.dispatchEvent(new CustomEvent("ext:sidebar-v2-visibility", { detail: { visible: visible } })); } catch (_) {}
    return visible;
  }
  function toggleVisible() { return setVisible(!isVisible()); }
  root.ExtensionUI.sidebarLifecycle = Object.freeze({ mount: mount, unmount: unmount, dispatch: dispatch, refreshStates: refreshStates, isVisible: isVisible, setVisible: setVisible, toggleVisible: toggleVisible });
})(globalThis);
