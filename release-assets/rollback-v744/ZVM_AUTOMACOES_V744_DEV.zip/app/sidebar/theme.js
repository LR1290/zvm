(function (root) {
  "use strict";
  function resolve() {
    var configured = document.documentElement.getAttribute("data-extui-mode");
    var extapp = document.documentElement.getAttribute("data-extui-theme");
    if (configured === "light" || configured === "dark") return configured;
    if (extapp === "light" || extapp === "dark") return extapp;
    var legacy = document.documentElement.getAttribute("data-ext-v2-theme");
    if (legacy === "light" || legacy === "dark") return legacy;
    try { return root.matchMedia && root.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark"; } catch (_) { return "dark"; }
  }
  function usableColor(value){value=String(value||"").trim();return !!value&&value!=="transparent"&&value!=="rgba(0, 0, 0, 0)"&&value!=="rgba(0,0,0,0)";}
  function readFirstVar(names,fallback){try{var style=getComputedStyle(document.documentElement);for(var i=0;i<names.length;i++){var value=style.getPropertyValue(names[i]).trim();if(usableColor(value))return value;}}catch(_){}return fallback;}
  function nativeRailSurface(){
    var selectors=['[data-testid="navbar-primary-section"]','[data-testid="navbar-footer-section"]'];
    for(var i=0;i<selectors.length;i++){
      var seed=document.querySelector(selectors[i]),node=seed,depth=0;
      while(node&&depth++<6){
        try{var rect=node.getBoundingClientRect(),style=getComputedStyle(node);if(rect.width>=44&&rect.width<=110&&rect.height>=Math.min(420,window.innerHeight*.55)&&usableColor(style.backgroundColor))return style;}catch(_){}
        node=node.parentElement;
      }
    }
    return null;
  }
  function colorMode(value){
    value=String(value||"").trim();if(!value)return "";
    var r,g,b,m=value.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/i);
    if(m){r=Number(m[1]);g=Number(m[2]);b=Number(m[3]);}
    else{m=value.match(/^#([0-9a-f]{6})$/i);if(m){r=parseInt(m[1].slice(0,2),16);g=parseInt(m[1].slice(2,4),16);b=parseInt(m[1].slice(4,6),16);}else{m=value.match(/^#([0-9a-f]{3})$/i);if(!m)return "";r=parseInt(m[1][0]+m[1][0],16);g=parseInt(m[1][1]+m[1][1],16);b=parseInt(m[1][2]+m[1][2],16);}}
    var luminance=(0.2126*r+0.7152*g+0.0722*b)/255;return luminance>=0.62?"light":"dark";
  }
  function nativeDocumentMode(detected){
    var detectedBg=detected&&usableColor(detected.backgroundColor)?detected.backgroundColor:"",fromDetected=colorMode(detectedBg);
    if(fromDetected)return fromDetected;
    var rootBg=readFirstVar(["--navbar-background","--panel-background","--background-default","--app-background"],"");
    var fromVars=colorMode(rootBg);if(fromVars)return fromVars;
    var nodes=[document.querySelector("[data-testid=\"app\"]"),document.getElementById("app"),document.body];
    for(var i=0;i<nodes.length;i++){var node=nodes[i];if(!node)continue;try{var style=getComputedStyle(node),candidate=style&&style.backgroundColor,fromNode=colorMode(candidate);if(usableColor(candidate)&&fromNode)return fromNode;}catch(_){}}
    try{if(document.documentElement.classList.contains("dark")||document.body&&document.body.classList.contains("dark"))return "dark";}catch(_){}
    try{return root.matchMedia&&root.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";}catch(_){return "dark";}
  }
  function nativePalette(mode,visual){
    var detected=nativeRailSurface(),detectedBg=detected&&usableColor(detected.backgroundColor)?detected.backgroundColor:"",detectedFg=detected&&usableColor(detected.color)?detected.color:"";
    var rootBg=readFirstVar(["--navbar-background","--panel-background","--background-default","--app-background"],detectedBg||"");
    var nativeMode=nativeDocumentMode(detected),configured=document.documentElement.getAttribute("data-extui-mode"),forcedMode=configured==="light"||configured==="dark"?configured:"",targetMode=forcedMode||mode||nativeMode,mismatch=!!forcedMode&&forcedMode!==nativeMode,light=targetMode==="light";
    var fallbackBg=light?"#f0f2f5":"#202c33",fallbackSurface=light?"#ffffff":"#202c33",fallbackSurface2=light?"#f0f2f5":"#111b21",fallbackHover=light?"#e9edef":"#2a3942",fallbackActive=light?"#dfe3e5":"#374248",fallbackBorder=light?"#d8dcde":"#303d45",fallbackBorderStrong=light?"#c5cace":"#3b4a54",fallbackText=light?"#111b21":"#e9edef",fallbackMuted=light?"#54656f":"#aebac1",fallbackMuted2=light?"#667781":"#8696a0";
    var resolvedBg=mismatch?fallbackBg:(detectedBg||rootBg||fallbackBg);
    var nativeSurface=mismatch?fallbackSurface:readFirstVar(["--panel-background","--navbar-background"],detectedBg||fallbackSurface);
    var nativeSurface2=mismatch?fallbackSurface2:readFirstVar(["--background-default","--panel-background-lighter","--panel-background-deep"],fallbackSurface2);
    var nativeHover=mismatch?fallbackHover:readFirstVar(["--background-default-hover","--panel-background-hover","--button-secondary-background-hover"],fallbackHover);
    var nativeActive=mismatch?fallbackActive:readFirstVar(["--background-default-active","--panel-background-active","--button-secondary-background"],fallbackActive);
    var nativeBorder=mismatch?fallbackBorder:readFirstVar(["--border-list","--border-panel","--border-strong"],detected&&usableColor(detected.borderRightColor)?detected.borderRightColor:fallbackBorder);
    var nativeBorderStrong=mismatch?fallbackBorderStrong:readFirstVar(["--border-strong","--border-panel","--border-list"],fallbackBorderStrong);
    var nativeIcon=mismatch?fallbackMuted:readFirstVar(["--icon","--secondary","--primary-strong"],detectedFg||fallbackMuted);
    var nativeText=mismatch?fallbackText:readFirstVar(["--primary-strong","--primary"],detectedFg||fallbackText);
    var nativeMuted2=mismatch?fallbackMuted2:readFirstVar(["--secondary","--icon"],fallbackMuted2);
    var extPrimary=readFirstVar(["--extui-primary"],"#00c85a"),extPrimaryBright=readFirstVar(["--extui-primary-bright","--extui-primary"],"#00e676");
    return {
      bg:resolvedBg,
      surface:nativeSurface,
      surface2:nativeSurface2,
      hover:nativeHover,
      active:nativeActive,
      border:nativeBorder,
      borderStrong:nativeBorderStrong,
      text:nativeText||fallbackText,
      muted:nativeIcon||fallbackMuted,
      muted2:nativeMuted2,
      icon:nativeIcon||fallbackMuted,
      primary:extPrimary,
      primaryBright:extPrimaryBright
    };
  }
  function setPaletteVar(shell,name,value){if(value)shell.style.setProperty(name,value);}
  function apply(shell) {
    if (!shell) return;
    var mode=resolve(),visual=document.documentElement.getAttribute("data-extui-visual-theme")||"padrao",iconTheme=document.documentElement.getAttribute("data-extui-icon-theme")||"monochrome";
    shell.setAttribute("data-theme",mode);shell.setAttribute("data-visual-theme",visual);shell.setAttribute("data-icon-theme",iconTheme);
    var native=nativePalette(mode);
    setPaletteVar(shell,"--extapp-bg",native.bg);
    setPaletteVar(shell,"--extapp-surface",native.surface);
    setPaletteVar(shell,"--extapp-surface-2",native.surface2);
    setPaletteVar(shell,"--extapp-hover",native.hover);
    setPaletteVar(shell,"--extapp-active",native.active);
    setPaletteVar(shell,"--extapp-border",native.border);
    setPaletteVar(shell,"--extapp-border-strong",native.borderStrong);
    setPaletteVar(shell,"--extapp-text",native.text);
    setPaletteVar(shell,"--extapp-muted",native.muted);
    setPaletteVar(shell,"--extapp-muted-2",native.muted2);
    setPaletteVar(shell,"--extapp-primary",native.primary);
    setPaletteVar(shell,"--extapp-primary-2",native.primaryBright);
    setPaletteVar(shell,"--extapp-focus",native.borderStrong);
  }
  function watch(shell) {
    apply(shell);
    var observer = new MutationObserver(function () { apply(shell); });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-extui-theme", "data-extui-mode", "data-extui-visual-theme", "data-extui-icon-theme", "data-ext-v2-theme", "style", "class"] });
    var media = null, mediaHandler = null;
    try {
      media = root.matchMedia("(prefers-color-scheme: light)");
      mediaHandler = function () { apply(shell); };
      if (media.addEventListener) media.addEventListener("change", mediaHandler);
    } catch (_) {}
    return function () {
      observer.disconnect();
      try { if (media && mediaHandler && media.removeEventListener) media.removeEventListener("change", mediaHandler); } catch (_) {}
    };
  }
  root.ExtensionUI.sidebarTheme = Object.freeze({ resolve: resolve, apply: apply, watch: watch });
})(globalThis);
