(function (root) {
  "use strict";
  var C = root.ExtensionUI.sidebarConstants;
  var R = root.ExtensionUI.sidebarRegistry;
  var memory = Object.create(null);

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function validKeys() { return new Set((typeof R.configurableKeys === "function" ? R.configurableKeys() : R.pinEligibleKeys())); }
  function isSeparatorKey(key) { return !!(R && typeof R.isSeparatorKey === "function" && R.isSeparatorKey(key)); }
  function normalize(raw) {
    raw = raw && typeof raw === "object" ? raw : {};
    var sourceVersion = Number(raw.schemaVersion || 0);
    if (sourceVersion < C.SCHEMA_VERSION) {
      var migrated = Object.assign({}, C.DEFAULTS, raw);
      var rawPinned = Array.isArray(raw.pinned) ? raw.pinned : [];
      var rawOrder = Array.isArray(raw.order) ? raw.order : [];
      var same = function (a, b) { return a.length === b.length && a.every(function (x, i) { return x === b[i]; }); };
      var isGeneratedLegacyDefault = false;
      if (Array.isArray(C.LEGACY_DEFAULT_PINNED_V2) && same(rawPinned, C.LEGACY_DEFAULT_PINNED_V2) && same(rawOrder, C.LEGACY_DEFAULT_PINNED_V2)) isGeneratedLegacyDefault = true;
      if (Array.isArray(C.LEGACY_COLLAPSED_PINNED_V3) && same(rawPinned, C.LEGACY_COLLAPSED_PINNED_V3) && same(rawOrder, C.LEGACY_COLLAPSED_PINNED_V3)) isGeneratedLegacyDefault = true;
      if (Array.isArray(C.LEGACY_DEFAULT_PINNED_V3) && same(rawPinned, C.LEGACY_DEFAULT_PINNED_V3) && same(rawOrder, C.LEGACY_DEFAULT_PINNED_V3)) isGeneratedLegacyDefault = true;
      if (Array.isArray(C.LEGACY_DEFAULT_PINNED_V6) && same(rawPinned, C.LEGACY_DEFAULT_PINNED_V6) && same(rawOrder, C.LEGACY_DEFAULT_PINNED_V6)) isGeneratedLegacyDefault = true;
      if (Array.isArray(C.LEGACY_DEFAULT_PINNED_V12) && same(rawPinned, C.LEGACY_DEFAULT_PINNED_V12) && same(rawOrder, C.LEGACY_DEFAULT_PINNED_V12)) isGeneratedLegacyDefault = true;
      if (Array.isArray(C.LEGACY_DEFAULT_PINNED_V13) && same(rawPinned, C.LEGACY_DEFAULT_PINNED_V13) && same(rawOrder, C.LEGACY_DEFAULT_PINNED_V13)) isGeneratedLegacyDefault = true;
      if (isGeneratedLegacyDefault) {
        migrated.pinned = C.DEFAULTS.pinned.slice();
        migrated.order = C.DEFAULTS.order.slice();
      }
      if (sourceVersion < 9) {
        var placeGoogle = function (list) {
          list = Array.isArray(list) ? list.slice() : [];
          list = list.filter(function (key) { return key !== "google"; });
          var at = list.indexOf("export");
          list.splice(at >= 0 ? at + 1 : list.length, 0, "google");
          return list;
        };
        migrated.pinned = placeGoogle(migrated.pinned);
        migrated.order = placeGoogle(migrated.order);
      }
      if (sourceVersion < 10) {
        var placeDelivery = function (list) {
          list = Array.isArray(list) ? list.slice() : [];
          list = list.filter(function (key) { return key !== "delivery"; });
          var at = list.indexOf("orders");
          list.splice(at >= 0 ? at + 1 : Math.min(4, list.length), 0, "delivery");
          return list;
        };
        migrated.pinned = placeDelivery(migrated.pinned);
        migrated.order = placeDelivery(migrated.order);
      }
      if (sourceVersion < 11) {
        var newDirectKeys = ["agenda","notes","reminder","google-calendar","signature","text-assistant","text-replace","webhooks"];
        var addDirectKeys = function (list) {
          list = Array.isArray(list) ? list.slice() : [];
          newDirectKeys.forEach(function (key) { if (list.indexOf(key) < 0) list.push(key); });
          return list;
        };
        migrated.pinned = addDirectKeys(migrated.pinned);
        migrated.order = addDirectKeys(migrated.order);
      }
      if (sourceVersion < 12) {
        var removeFixedTools = function (list) {
          return (Array.isArray(list) ? list : []).filter(function (key) { return key !== "tools"; });
        };
        migrated.pinned = removeFixedTools(migrated.pinned);
        migrated.order = removeFixedTools(migrated.order);
      }
      if (sourceVersion < 13) {
        migrated.pinned = (Array.isArray(migrated.pinned) ? migrated.pinned : []).filter(function (key) { return key !== "tools"; });
        migrated.order = (Array.isArray(migrated.order) ? migrated.order : []).filter(function (key) { return key !== "tools"; });
      }
      if (sourceVersion < 14) {
        var footerDefault = Array.isArray(C.DEFAULTS.footerPinned) ? C.DEFAULTS.footerPinned.slice() : ["tools","notifications"];
        var footerSeed = Array.isArray(raw.footerPinned) ? raw.footerPinned.slice() : [];
        ["tools","notifications"].forEach(function (key) {
          if (footerSeed.indexOf(key) < 0) footerSeed.push(key);
        });
        var uniquePrimary = [];
        (Array.isArray(migrated.pinned) ? migrated.pinned : []).forEach(function (key) {
          if (footerDefault.indexOf(key) >= 0 || key === "system" || key === "rail-toggle") return;
          if (uniquePrimary.indexOf(key) < 0) uniquePrimary.push(key);
        });
        var uniqueFooter = [];
        footerSeed.forEach(function (key) {
          if (key === "system" || key === "rail-toggle") return;
          if (uniquePrimary.indexOf(key) >= 0) return;
          if (uniqueFooter.indexOf(key) < 0) uniqueFooter.push(key);
        });
        var combinedOrder = [];
        (Array.isArray(migrated.order) ? migrated.order : []).concat(uniqueFooter).forEach(function (key) {
          if (key === "system" || key === "rail-toggle") return;
          if (combinedOrder.indexOf(key) < 0) combinedOrder.push(key);
        });
        migrated.pinned = uniquePrimary;
        migrated.footerPinned = uniqueFooter;
        migrated.order = combinedOrder;
      }
      if (sourceVersion < 15) {
        migrated.order = (Array.isArray(migrated.order) ? migrated.order : []).filter(function (key) { return !isSeparatorKey(key); });
        migrated.separators = [];
      }
      if (sourceVersion < 16) {
        migrated.pinned = (Array.isArray(migrated.pinned) ? migrated.pinned : []).filter(function (key) { return key !== "actions" && key !== "tools"; });
        migrated.footerPinned = (Array.isArray(migrated.footerPinned) ? migrated.footerPinned : []).filter(function (key) { return key !== "actions" && key !== "tools"; });
        migrated.footerPinned.unshift("actions");
        var v16Order = (Array.isArray(migrated.order) ? migrated.order : []).filter(function (key) { return key !== "actions" && key !== "tools"; });
        var notificationAt = v16Order.indexOf("notifications");
        v16Order.splice(notificationAt >= 0 ? notificationAt : v16Order.length, 0, "actions");
        v16Order.push("tools");
        migrated.order = v16Order;
      }
      if (sourceVersion < 17) {
        var removeLegacyActions = function (list) { return (Array.isArray(list) ? list : []).filter(function (key) { return key !== "actions"; }); };
        migrated.pinned = removeLegacyActions(migrated.pinned);
        migrated.footerPinned = removeLegacyActions(migrated.footerPinned);
        migrated.order = removeLegacyActions(migrated.order);
      }
      if (sourceVersion < 18) {
        var removeEmbeddedBroadcastPin = function (list) { return (Array.isArray(list) ? list : []).filter(function (key) { return key !== "broadcast-shell"; }); };
        migrated.pinned = removeEmbeddedBroadcastPin(migrated.pinned);
        migrated.footerPinned = removeEmbeddedBroadcastPin(migrated.footerPinned);
        migrated.order = Array.isArray(migrated.order) ? migrated.order.slice() : [];
        if (migrated.order.indexOf("broadcast-shell") < 0) migrated.order.push("broadcast-shell");
      }
      if (sourceVersion < 19) {
        migrated.pinned = (Array.isArray(migrated.pinned) ? migrated.pinned : []).filter(function (key) { return key !== "labels"; });
        migrated.footerPinned = (Array.isArray(migrated.footerPinned) ? migrated.footerPinned : []).filter(function (key) { return key !== "labels"; });
        migrated.order = Array.isArray(migrated.order) ? migrated.order.slice() : [];
        if (migrated.order.indexOf("labels") < 0) migrated.order.push("labels");
      }
      migrated.schemaVersion = C.SCHEMA_VERSION;
      raw = migrated;
    }
    var valid = validKeys();
    var separators = [];
    (Array.isArray(raw.separators) ? raw.separators : []).forEach(function (x) {
      if (isSeparatorKey(x) && separators.indexOf(x) < 0 && separators.length < 24) separators.push(x);
    });
    var separatorSet = new Set(separators);
    var sourcePinned = Array.isArray(raw.pinned) ? raw.pinned : C.DEFAULTS.pinned;
    var pinned = [];
    sourcePinned.forEach(function (x) {
      var allowed = valid.has(x) || separatorSet.has(x);
      if (typeof x === "string" && allowed && pinned.indexOf(x) < 0 && pinned.length < C.MAX_PINNED + separators.length && x !== "system" && x !== "rail-toggle") pinned.push(x);
    });
    var sourceFooterPinned = Array.isArray(raw.footerPinned) ? raw.footerPinned : C.DEFAULTS.footerPinned;
    var footerPinned = [];
    sourceFooterPinned.forEach(function (x) {
      var allowed = valid.has(x) || separatorSet.has(x);
      if (typeof x === "string" && allowed && pinned.indexOf(x) < 0 && footerPinned.indexOf(x) < 0 && x !== "system" && x !== "rail-toggle") footerPinned.push(x);
    });
    var sourceOrder = Array.isArray(raw.order) && raw.order.length ? raw.order : C.DEFAULTS.order;
    var order = [];
    sourceOrder.concat(typeof R.configurableKeys === "function" ? R.configurableKeys() : R.pinEligibleKeys()).forEach(function (x) {
      var allowed = valid.has(x) || separatorSet.has(x);
      if (typeof x === "string" && allowed && order.indexOf(x) < 0 && x !== "system" && x !== "rail-toggle") order.push(x);
    });
    separators.forEach(function (x) { if (order.indexOf(x) < 0) order.push(x); });
    return {
      schemaVersion: C.SCHEMA_VERSION,
      expanded: raw.expanded === true,
      panelMode: raw.panelMode === "floating" ? "floating" : "docked",
      pinned: pinned,
      footerPinned: footerPinned,
      order: order,
      separators: separators,
      dismissedHints: Array.isArray(raw.dismissedHints) ? raw.dismissedHints.filter(function (x) { return typeof x === "string"; }) : []
    };
  }
  function api() {
    try { if (root.chrome && chrome.storage && chrome.storage.local) return chrome.storage.local; } catch (_) {}
    return null;
  }
  async function load() {
    var storage = api(), raw;
    if (storage) { var result = await storage.get(C.STORE_KEY); raw = result && result[C.STORE_KEY]; }
    else raw = memory[C.STORE_KEY];
    return normalize(raw || C.DEFAULTS);
  }
  async function save(next) {
    var value = normalize(next);
    var storage = api();
    if (storage) { var payload = {}; payload[C.STORE_KEY] = value; await storage.set(payload); }
    else memory[C.STORE_KEY] = clone(value);
    return clone(value);
  }
  async function patch(partial) { return save(Object.assign({}, await load(), partial || {})); }
  async function setExpanded(expanded) { return patch({ expanded: expanded === true }); }
  async function togglePin(key, force) {
    var current = await load();
    var item = R.get(key);
    if (!item || !item.pinEligible) return current;
    var pinned = current.pinned.slice();
    var order = current.order.slice();
    var index = pinned.indexOf(key);
    var shouldPin = typeof force === "boolean" ? force : index < 0;
    if (shouldPin && index < 0) {
      if (pinned.length >= C.MAX_PINNED) {
        var err = new Error("Limite de " + C.MAX_PINNED + " atalhos atingido."); err.code = "SIDEBAR_PIN_LIMIT"; throw err;
      }
      pinned.push(key);
      if (order.indexOf(key) < 0) order.push(key);
    } else if (!shouldPin && index >= 0) {
      pinned.splice(index, 1);
    }
    return save(Object.assign({}, current, { pinned: pinned, order: order }));
  }
  async function setOrder(keys) {
    var current = await load();
    var valid = validKeys();
    var order = [];
    (Array.isArray(keys) ? keys : []).concat(R.pinEligibleKeys()).forEach(function (key) {
      if (typeof key === "string" && valid.has(key) && order.indexOf(key) < 0) order.push(key);
    });
    return save(Object.assign({}, current, { order: order }));
  }
  async function moveOrder(key, delta) {
    var current = await load();
    var order = current.order.slice();
    var index = order.indexOf(key);
    var nextIndex = Math.max(0, Math.min(order.length - 1, index + (delta < 0 ? -1 : 1)));
    if (index < 0 || index === nextIndex) return current;
    order.splice(nextIndex, 0, order.splice(index, 1)[0]);
    return save(Object.assign({}, current, { order: order }));
  }
  async function move(key, delta) {
    var current = await load();
    var visible = R.orderedPinned(current);
    var index = visible.indexOf(key);
    var nextIndex = Math.max(0, Math.min(visible.length - 1, index + (delta < 0 ? -1 : 1)));
    if (index < 0 || index === nextIndex) return current;
    var other = visible[nextIndex];
    var order = current.order.slice();
    var a = order.indexOf(key), b = order.indexOf(other);
    if (a < 0 || b < 0) return current;
    var temp = order[a]; order[a] = order[b]; order[b] = temp;
    return save(Object.assign({}, current, { order: order }));
  }
  async function resetOrder() { return patch({ order: C.DEFAULTS.order.slice() }); }
  async function reset() { return save(C.DEFAULTS); }
  function subscribe(listener) {
    if (typeof listener !== "function") return function () {};
    try {
      if (root.chrome && chrome.storage && chrome.storage.onChanged) {
        var fn = function (changes, area) {
          if (area !== "local" || !changes[C.STORE_KEY]) return;
          listener(normalize(changes[C.STORE_KEY].newValue || C.DEFAULTS));
        };
        chrome.storage.onChanged.addListener(fn);
        return function () { try { chrome.storage.onChanged.removeListener(fn); } catch (_) {} };
      }
    } catch (_) {}
    return function () {};
  }
  root.ExtensionUI.sidebarStorage = Object.freeze({ load: load, save: save, patch: patch, normalize: normalize, setExpanded: setExpanded, togglePin: togglePin, setOrder: setOrder, moveOrder: moveOrder, move: move, resetOrder: resetOrder, reset: reset, subscribe: subscribe });
})(globalThis);
