(function (root) {
  "use strict";
  var R = root.ExtensionUI.sidebarRegistry;
  var hints = Object.freeze({
    flow: "Automação por gatilhos e palavras-chave",
    funnel: "Sequências automáticas com etapas e atrasos",
    followup: "Retomadas automáticas pelo CRM",
    "auto-service": "Regras para mensagens recebidas",
    orders: "Encomendas e rastreios do contato",
    webhooks: "Eventos e integrações externas",
    integrations: "Serviços e conexões da extensão",
    google: "Atalhos Google úteis para atendimento e CRM",
    export: "Exportar contatos para CSV ou vCard",
    system: "Ajustes e configurações operacionais"
  });
  function withHints(items) { return items.map(function (item) { return Object.assign({}, item, { hint: hints[item.key] || "" }); }); }
  root.ExtensionUI.sidebarTrays = Object.freeze({
    automations: withHints(R.tray("automations"))
  });
})(globalThis);
