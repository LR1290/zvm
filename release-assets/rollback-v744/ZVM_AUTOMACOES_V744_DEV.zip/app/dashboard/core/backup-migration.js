;
try{
(function(root){
  "use strict";
  if(root.__extBackupMigrationService)return;
  if(typeof root.__extCreateBackupMigrationService!=="function")throw new Error("Backup migration core unavailable");
  var api=root.__extCreateBackupMigrationService(root,{bulkLabel:"Disparos em Massa",aiTranscription:true,paidFeature:"backup",atomicImport:true});
  root.__extBackupMigrationService=api;root.ExtensionCore=root.ExtensionCore||{};
})(typeof window!=="undefined"?window:self);
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
