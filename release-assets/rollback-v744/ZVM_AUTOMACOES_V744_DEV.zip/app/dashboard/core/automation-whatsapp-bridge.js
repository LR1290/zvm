;
try{
(function () {
  "use strict";
  if (window.__extSendToWhatsAppTab) return;
  function sendToWhatsAppTab(type, payload) {
    return new Promise(function (resolve, reject) {
      var requestId = "automation-test-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      var settled = false;
      var timer = setTimeout(function () { if (!settled) { settled = true; reject(new Error("A integração demorou para responder. Recarregue o WhatsApp Web.")); } }, 20000);
      function finish(error, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (error) reject(error); else resolve(value);
      }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        var tab = (tabs || [])[0];
        if (!tab) { finish(new Error("Abra o WhatsApp Web antes de executar o teste.")); return; }
        chrome.tabs.sendMessage(tab.id, Object.assign({ type: type, requestId: requestId }, payload || {}), function (response) {
          if (chrome.runtime.lastError) { finish(new Error("Recarregue o WhatsApp Web e tente novamente.")); return; }
          if (!response || response.error || response.ok === false) { finish(new Error((response && response.error) || "A integração não respondeu.")); return; }
          finish(null, response.data || response);
        });
      });
    });
  }
  window.__extSendToWhatsAppTab = sendToWhatsAppTab;
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
