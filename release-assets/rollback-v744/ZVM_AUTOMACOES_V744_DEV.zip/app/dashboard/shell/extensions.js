;
try{
(function () {
  "use strict";

  var LIMIT_LABELS = {
    audio: "Áudio", media: "Imagens e vídeos", sticker: "Figurinha", document: "Documento", message: "Mensagem",
    funnel: "Funil", bulkMessages: "Mensagens em massa", scheduleItem: "Item agendado", flow: "Fluxo",
    zapsaver: "ZapSaver"
  };

                                                         
                                                                       

  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(key, function (result) {
          if (chrome.runtime && chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve(result ? result[key] : undefined);
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  function parsePersisted(raw) {
    if (!raw) return null;
    try {
      var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
      return parsed && parsed.state ? parsed.state : null;
    } catch (err) {
      return null;
    }
  }

  async function fetchQuotaState() {
                                                                                 
                                                                                         
    var raw = await storageGet("EXTUI:quotaStore");
    var state = parsePersisted(raw);
    if (!state || !state.quota) return {};
    return state.quota;
  }



                                                                             
                                                                          
                                                                            
                                                                          
                                                                        
                                                                    
                         
  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function renderLimitsCard(container, limits) {
    var keys = Object.keys(limits);
    if (keys.length === 0) return;
    var rows = [];
    keys.forEach(function (key) {
      var entry = limits[key];
      if (!entry || !entry.max) return;
      var sent = Number(entry.sent) || 0;
      var max = Number(entry.max) || 0;
      if (!max) return;
      var pct = Math.max(0, Math.min(100, Math.round((sent / max) * 100)));
      if (pct < 80) return;
      rows.push("<div class=\"extuiLimitItem\">" +
        "<div class=\"label\">" + escapeHtml(LIMIT_LABELS[key] || key) + "</div>" +
        "<div class=\"barTrack\"><div class=\"barFill\" style=\"width:" + pct + "%\"></div></div>" +
        "<div class=\"count\">" + sent + " / " + max + "</div>" +
        "</div>");
    });
    if (!rows.length) return;
    var card = document.createElement("div");
    card.className = "extuiCard extuiHomeAttentionLimits";
    card.innerHTML = "<h2>Limites que merecem atenção</h2><div class=\"extuiLimitsGrid\">" + rows.join("") + "</div>";
    container.appendChild(card);
  }


                                                                           
                                                                          
                                                                      
                                                                          
                                                                      
                                                                         
                                                         
                                                                           

  function parsePlain(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (err) { return null; }
  }

  async function fetchGreetingName() {
    var raw = await storageGet("EXTUI:license");
    return (raw && raw.username) || "";
  }

  async function fetchFlowsActive() {
    var raw = await storageGet("EXTUI:extappFlowStore");
    var parsed = parsePlain(raw);
    var list = (parsed && Array.isArray(parsed.flowList)) ? parsed.flowList : [];
    return { active: list.filter(function (f) { return !!f.isActive; }).length, total: list.length, list: list };
  }

  function fmtHomeBytes(n) {
    n = Number(n || 0);
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
    if (n < 1073741824) return (n / 1048576).toFixed(1) + " MB";
    return (n / 1073741824).toFixed(2) + " GB";
  }

  async function fetchHomeCoreSnapshot() {
    var values = await new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get([
          "EXTUI:wppStatus",
          "EXTUI:CrmStore",
          "EXTUI:extappFunnelStore",
          "EXTUI:extappFollowUpStore"
        ], function (result) {
          if (chrome.runtime && chrome.runtime.lastError) { reject(chrome.runtime.lastError); return; }
          resolve(result || {});
        });
      } catch (err) { reject(err); }
    });
    function stateOf(raw) {
      var parsed = parsePlain(raw);
      return parsed && parsed.state && typeof parsed.state === "object" ? parsed.state : (parsed || {});
    }
    var crm = stateOf(values["EXTUI:CrmStore"]), contacts = 0, crmList = Array.isArray(crm.crmList) ? crm.crmList : [];
    crmList.forEach(function (board) {
      var cols = board && Array.isArray(board.columns) ? board.columns : [];
      cols.forEach(function (col) { contacts += col && Array.isArray(col.items) ? col.items.length : 0; });
    });
    var funnelState = stateOf(values["EXTUI:extappFunnelStore"]);
    var funnelList = Array.isArray(funnelState.funnelList) ? funnelState.funnelList : [];
    var followState = stateOf(values["EXTUI:extappFollowUpStore"]);
    var followList = Array.isArray(followState.list) ? followState.list : (Array.isArray(followState.followUpList) ? followState.followUpList : []);
    var storage = { usage: 0, quota: 0 };
    try { if (navigator.storage && navigator.storage.estimate) storage = await navigator.storage.estimate() || storage; } catch (_) {}
    return {
      wpp: String(values["EXTUI:wppStatus"] || "initializing"),
      contacts: contacts,
      crmCount: crmList.length,
      funnels: funnelList.length,
      activeFunnels: funnelList.filter(function (x) { return x && x.isActive; }).length,
      activeFollowups: followList.filter(function (x) { return x && x.active; }).length,
      storage: storage
    };
  }

  async function fetchQueueCount() {
    var raw = await storageGet("ext:bulkQueue");
    var list = Array.isArray(raw) ? raw : [];
    return list.filter(function (e) { return e && (e.state === "queued" || e.state === "sending"); }).length;
  }

  async function fetchHomeWorkspaceSnapshot() {
    var raw = await storageGet("EXTUI:adaptiveWorkspaceStore");
    var parsed = parsePlain(raw);
    var state = parsed && parsed.state && typeof parsed.state === "object" ? parsed.state : (parsed || {});
    var activeModels = Array.isArray(state.activeModels) ? state.activeModels.filter(Boolean) : [];
    return {
      activeModels: activeModels,
      focusedMode: state.focusedMode === true,
      setupCompleted: state.setupCompleted === true
    };
  }

                                                                              
                                                                           
                                                                  
  var SCHEDULES_SHOWN = 8;
  var AUTOMATIONS_SHOWN = 8;

  async function fetchUpcomingSchedules() {
    var raw = await storageGet("EXTUI:extappScheduleStore");
    var parsed = parsePlain(raw);
    var list = (parsed && Array.isArray(parsed.list)) ? parsed.list : [];
    return list
      .filter(function (item) { return item.status === "scheduled"; })
      .sort(function (a, b) { return (a.scheduleAtMs || 0) - (b.scheduleAtMs || 0); })
      .slice(0, SCHEDULES_SHOWN);
  }

  async function fetchAutomationStatus(flowsSnapshot) {
    var rows = [];
    try {
      var flows = flowsSnapshot || await fetchFlowsActive();
      flows.list.slice(0, 4).forEach(function (f) {
        rows.push({ name: f.name || "Fluxo sem nome", active: !!f.isActive });
      });
    } catch (err) {                            }
    try {
      var followupRaw = parsePlain(await storageGet("EXTUI:extappFollowUpStore"));
      var followupList = (followupRaw && Array.isArray(followupRaw.list)) ? followupRaw.list : [];
      followupList.slice(0, 3).forEach(function (r) {
        rows.push({ name: (r.name || "Regra de FollowUp"), active: !!r.active });
      });
    } catch (err) {                            }
    try {
      var webhookRaw = parsePlain(await storageGet("EXTUI:extappWebhookStore"));
      var webhookList = (webhookRaw && Array.isArray(webhookRaw.list)) ? webhookRaw.list : [];
      webhookList.slice(0, 3).forEach(function (r) {
        rows.push({ name: "Webhook — " + (r.eventLabel || r.eventId || "evento"), active: !!r.active });
      });
    } catch (err) {                            }
    return rows.slice(0, AUTOMATIONS_SHOWN);
  }

                                                                            
                                                                        
                                                                         
                                                                        
                                                                        
  async function fetchAttentionItems() {
    var items = [];
    try {
      var raw = parsePlain(await storageGet("EXTUI:extappScheduleStore"));
      var list = (raw && Array.isArray(raw.list)) ? raw.list : [];
      var errored = list.filter(function (i) { return i.status === "error"; });
      if (errored.length) {
        items.push({
          text: errored.length === 1
            ? "1 agendamento falhou ao enviar."
            : errored.length + " agendamentos falharam ao enviar.",
          goto: "agenda"
        });
      }
    } catch (err) {                            }
    return items;
  }

                                                                      
                                                                        
                                                                         
                                                                         
                                                                     
                                                                        
                                                                          
                                                                      
  function extExpiresAtMs(raw) {
    if (raw == null) return null;
    if (typeof raw === "number") return isFinite(raw) ? raw : null;
    var parsed = new Date(raw).getTime();
    return isNaN(parsed) ? null : parsed;
  }
  function fmtHomeLicenseDate(ms) {
    var d = new Date(ms);
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" }) + " às " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  }
  function fmtHomeLicenseCountdown(ms) {
    var diff = ms - Date.now();
    if (diff <= 0) return null;
    var days = Math.floor(diff / 86400000), hours = Math.floor((diff % 86400000) / 3600000);
    var parts = [];
    if (days > 0) parts.push(days + (days === 1 ? " dia" : " dias"));
    parts.push(hours + (hours === 1 ? " hora" : " horas"));
    return parts.join(" e ") + " restantes";
  }
  async function fetchLicenseSummary() {
    var license = await storageGet("EXTUI:license");
    if (!license || !license.authenticated) return null;
    var expiresAtMs = extExpiresAtMs(license.expiresAt);
    var hasExpiry = expiresAtMs !== null;
    var expired = hasExpiry && expiresAtMs <= Date.now();
    var daysLeft = hasExpiry ? Math.floor((expiresAtMs - Date.now()) / 86400000) : null;
    var isCritical = hasExpiry && !expired && daysLeft <= 0;
    var isWarning = hasExpiry && !expired && !isCritical && (license.expiringSoon || daysLeft <= 3);
    var statusText = expired ? "Expirada" : isCritical || isWarning ? "Expira em breve" : hasExpiry ? "Ativa" : "Sem expiração";
    var tone = expired || isCritical ? "critical" : isWarning ? "warning" : "ok";
    return {
      planName: license.planName || "",
      statusText: statusText, tone: tone, hasExpiry: hasExpiry, expired: expired,
      dateLabel: hasExpiry ? fmtHomeLicenseDate(expiresAtMs) : "",
      countdown: hasExpiry && !expired ? fmtHomeLicenseCountdown(expiresAtMs) : null
    };
  }
  function fmtScheduleWhen(ms) {
    if (!ms) return "";
    var d = new Date(ms);
    var now = new Date();
    var sameDay = d.toDateString() === now.toDateString();
    var tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1);
    var isTomorrow = d.toDateString() === tomorrow.toDateString();
    var hhmm = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    if (sameDay) return "Hoje, " + hhmm;
    if (isTomorrow) return "Amanhã, " + hhmm;
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }) + ", " + hhmm;
  }

  function goto(section) {
    var shell = window.__extDashboardShell;
    if (!shell || typeof shell.showSection !== "function") return;
    if (section === "core") {
      var hub = document.querySelector("#extappContentArea .extuiHomeCoreHub");
      if (hub && shell.getCurrentSection && shell.getCurrentSection() === "home") { hub.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
      Promise.resolve(shell.showSection("home", { force: true })).then(function () { var next = document.querySelector("#extappContentArea .extuiHomeCoreHub"); if (next) next.scrollIntoView({ behavior: "smooth", block: "start" }); });
      return;
    }
    shell.showSection(section);
  }

  function createHomeMetricsContext() {
    var context = { operational: null, nerd: null };
    var operationalPromise = null;
    var nerdPromise = null;

    context.ensureOperational = async function () {
      if (context.operational) return context.operational;
      if (operationalPromise) return operationalPromise;
      operationalPromise = (async function () {
        var flowsPromise = safe(fetchFlowsActive, { active: 0, total: 0, list: [] }, "home metrics flows");
        var values = await Promise.all([
          flowsPromise,
          safe(fetchQueueCount, 0, "home metrics queue"),
          safe(fetchUpcomingSchedules, [], "home metrics schedules"),
          flowsPromise.then(function (flowsSnapshot) { return safe(function () { return fetchAutomationStatus(flowsSnapshot); }, [], "home metrics automations"); }),
          safe(fetchGreetingName, "", "home metrics greeting"),
          safe(fetchAttentionItems, [], "home metrics attention"),
          safe(fetchLicenseSummary, null, "home metrics license"),
          safe(fetchHomeCoreSnapshot, { wpp: "initializing", contacts: 0, crmCount: 0, funnels: 0, activeFunnels: 0, activeFollowups: 0, storage: { usage: 0, quota: 0 } }, "home metrics core")
        ]);
        var flows = values[0], queueCount = Number(values[1] || 0), schedules = values[2], automations = values[3], greetName = values[4], attention = values[5], license = values[6], core = values[7] || {};
        var scheduleCount = Array.isArray(schedules) ? schedules.length : 0;
        var attentionCount = Array.isArray(attention) ? attention.length : 0;
        var pausedAutomations = Array.isArray(automations) ? automations.filter(function (item) { return item && !item.active; }) : [];
        var pausedCount = pausedAutomations.length;
        var activeAutomations = Number(flows.active || 0) + Number(core.activeFunnels || 0) + Number(core.activeFollowups || 0);
        var licenseNeedsAttention = !!(license && license.tone && license.tone !== "ok");
        var priorityItems = [];
        if (licenseNeedsAttention) priorityItems.push({ label: "Licença", value: 1, caption: license.statusText + (license.countdown ? " · " + license.countdown : ""), goto: "ajustes", tone: license.tone === "critical" ? "danger" : "warning", rank: license.tone === "critical" ? 40 : 30, order: 0 });
        if (queueCount) priorityItems.push({ label: "Envios aguardando", value: queueCount, caption: "Há itens na fila de envio.", goto: "disparos", tone: "warning", rank: 30, order: 1 });
        if (attentionCount) priorityItems.push({ label: "Avisos operacionais", value: attentionCount, caption: "Há itens que merecem revisão.", goto: attention[0] && attention[0].goto ? attention[0].goto : "core", tone: "warning", rank: 30, order: 2 });
        if (pausedCount) priorityItems.push({ label: "Automações pausadas", value: pausedCount, caption: "Revise o que foi interrompido.", goto: "fluxos", tone: "neutral", rank: 20, order: 3 });
        priorityItems.sort(function (a, b) { return b.rank - a.rank || a.order - b.order; });
        var priorityTotal = queueCount + attentionCount + pausedCount + (licenseNeedsAttention ? 1 : 0);
        var currentPriority = priorityItems[0] || { label: "Operação em dia", value: 0, caption: "Nenhuma pendência operacional importante agora.", goto: "", tone: "active", rank: 0, order: 0 };
        context.operational = {
          greetName: greetName,
          flowsActive: Number(flows.active || 0),
          flowsTotal: Number(flows.total || 0),
          queueCount: queueCount,
          schedules: Array.isArray(schedules) ? schedules : [],
          scheduleCount: scheduleCount,
          automations: Array.isArray(automations) ? automations : [],
          pausedAutomations: pausedAutomations,
          pausedCount: pausedCount,
          attention: Array.isArray(attention) ? attention : [],
          attentionCount: attentionCount,
          license: license,
          core: core,
          activeAutomations: activeAutomations,
          contacts: Number(core.contacts || 0),
          crmCount: Number(core.crmCount || 0),
          priorityItems: priorityItems,
          priorityTotal: priorityTotal,
          currentPriority: currentPriority
        };
        return context.operational;
      })();
      try { return await operationalPromise; } catch (err) { operationalPromise = null; throw err; }
    };

    context.ensureNerd = async function () {
      if (context.nerd) return context.nerd;
      if (nerdPromise) return nerdPromise;
      nerdPromise = (async function () {
        var operational = await context.ensureOperational();
        var workspace = await safe(fetchHomeWorkspaceSnapshot, { activeModels: [], focusedMode: false, setupCompleted: false }, "home metrics workspace");
        var core = operational.core || {};
        var activeModels = Array.isArray(workspace.activeModels) ? workspace.activeModels : [];
        var workspaceLabel = activeModels.length ? activeModels.length + (activeModels.length === 1 ? " modelo ativo" : " modelos ativos") : (workspace.setupCompleted ? "Nenhum modelo selecionado" : "Extensão completa visível");
        var workspaceCaption = activeModels.length ? (workspace.focusedMode ? "Menu recomendado ativo" : "Todas as funcionalidades continuam visíveis") : "Abra Modelos para adaptar os atalhos ao seu negócio";
        var wppReady = core.wpp === "ready";
        var storageUsage = core.storage && typeof core.storage.usage === "number" ? fmtHomeBytes(core.storage.usage) : "0 B";
        var storageQuota = core.storage && typeof core.storage.quota === "number" && core.storage.quota > 0 ? fmtHomeBytes(core.storage.quota) : "indisponível";
        var manifestVersion = "";
        try { manifestVersion = chrome.runtime && chrome.runtime.getManifest ? (chrome.runtime.getManifest().version || "") : ""; } catch (_) {}
        context.nerd = {
          build: manifestVersion || "—",
          whatsapp: { value: wppReady ? "WhatsApp conectado" : core.wpp === "unavailable" ? "WhatsApp requer atenção" : "Verificando WhatsApp", paused: !wppReady },
          storage: { value: storageUsage + " de " + storageQuota, usage: storageUsage, quota: storageQuota },
          activeAutomations: operational.activeAutomations,
          workspace: { modelsValue: workspaceLabel, visibilityValue: workspaceCaption },
          crm: { value: operational.crmCount + " CRM(s) · " + operational.contacts + " contatos" },
          funnelsFollowups: { value: Number(core.activeFunnels || 0) + " ativos · " + Number(core.activeFollowups || 0) + " follow-ups" }
        };
        return context.nerd;
      })();
      try { return await nerdPromise; } catch (err) { nerdPromise = null; throw err; }
    };

    return context;
  }

  async function renderHomeNerdMetrics(target, homeMetricsContext) {
    while (target.firstChild) target.removeChild(target.firstChild);
    var context = homeMetricsContext && typeof homeMetricsContext.ensureNerd === "function" ? homeMetricsContext : createHomeMetricsContext();
    var nerd = await context.ensureNerd();

    function node(tag, className, text) {
      var out = document.createElement(tag);
      if (className) out.className = className;
      if (text != null) out.textContent = String(text);
      return out;
    }
    function buildRow(label, value, paused) {
      var row = node("div", "extuiHomeOpsListRow");
      row.appendChild(node("span", "extuiHomeOpsDot" + (paused ? " is-paused" : "")));
      row.appendChild(node("strong", "", label));
      row.appendChild(node("small", "", value));
      return row;
    }
    function buildPanel(title, actionLabel, tab, rows) {
      var panel = node("div", "extuiHomeOpsList");
      var head = node("div", "extuiHomeOpsListHead");
      head.appendChild(node("h3", "", title));
      var action = node("button", "", actionLabel);
      action.type = "button";
      action.setAttribute("data-core-tab", tab);
      head.appendChild(action);
      panel.appendChild(head);
      rows.forEach(function (row) { panel.appendChild(row); });
      return panel;
    }

    var section = node("section", "extuiHomeOpsDetails extuiHomeOpsDetails--nerd");
    section.appendChild(buildPanel("Saúde da extensão", "Abrir Central", "central", [
      buildRow("WhatsApp", nerd.whatsapp.value, nerd.whatsapp.paused),
      buildRow("Armazenamento", nerd.storage.value, false),
      buildRow("Build", nerd.build, false),
      buildRow("Automações ativas", String(nerd.activeAutomations), false)
    ]));
    section.appendChild(buildPanel("Minha extensão", "Personalizar", "workspace", [
      buildRow("Modelos de negócio", nerd.workspace.modelsValue, false),
      buildRow("Visibilidade", nerd.workspace.visibilityValue, false),
      buildRow("CRM", nerd.crm.value, false),
      buildRow("Funis / FollowUp", nerd.funnelsFollowups.value, false)
    ]));
    section.querySelectorAll("[data-core-tab]").forEach(function (button) {
      button.addEventListener("click", function () {
        var tab = button.getAttribute("data-core-tab");
        var targetTab = document.querySelector('#extappContentArea .extuiCoreTab[data-tab="' + tab + '"]');
        if (targetTab) { targetTab.click(); return; }
        if (tab === "workspace") goto("personalizacao");
      });
    });
    target.appendChild(section);
  }
  window.__extRenderHomeNerdMetrics = renderHomeNerdMetrics;

  function renderTopBlock(wrap, operational) {
    var el = document.createElement("div");
    el.className = "extuiHomeTop extuiHomeOps";
    el.setAttribute("data-extui-academy-target", "home-overview");
    var greet = operational && operational.greetName ? ("Olá, " + operational.greetName + ". ") : "";
    el.innerHTML =
      '<header class="extuiHomeOpsHeader">' +
      ' <div><span class="extuiHomeOpsEyebrow">OPERAÇÃO</span><h1>Início</h1><p>' + escapeHtml(greet + 'Resumo do que precisa de atenção e dos próximos passos da operação.') + '</p></div>' +
      '</header>';
    wrap.appendChild(el);
  }

  async function safe(promiseFn, fallback, label) {
    try { return await promiseFn(); }
    catch (err) { return fallback; }
  }

  async function renderHomeSection(container) {
    var wrap = document.createElement("div");
    wrap.className = "extuiHomeSection";
    container.appendChild(wrap);

    var homeMetricsContext = createHomeMetricsContext();
    window.__extHomeMetricsContext = homeMetricsContext;
    var operational = await homeMetricsContext.ensureOperational();
    renderTopBlock(wrap, operational);

    if (typeof window.__extRenderCoreHub === "function") {
      var coreHost = document.createElement("section");
      coreHost.className = "extuiHomeCoreHub";
      coreHost.setAttribute("aria-label", "Central da extensão");
      wrap.appendChild(coreHost);
      await window.__extRenderCoreHub(coreHost, homeMetricsContext);
    }

    try {
      var limits = await fetchQuotaState();
      renderLimitsCard(wrap, limits);
    } catch (err) {
    }

  }

  window.__extDashboardShell.registerSection("home", renderHomeSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
