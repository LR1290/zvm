;
try{
(function () {
  "use strict";

  var core = window.__extCrmAiCopilotCore;
  var assistantsCore = window.__extAiAssistantsCore;
  var agentsCore = window.__extAiAgentsCore;
  var agentRuntime = window.__extAiAgentRuntime;
  var memoryCore = window.__extAiMemoryCore;
  var knowledgeCore = window.__extKnowledgeCore;
  var toolsRegistry = window.__extAiToolsRegistry;
  var integrationCore = window.__extIntegrationCore;
  var crmProfessionalCore = window.__extCrmProfessionalCore;
  var activeMount = null;
  var session = null;

  function element(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      var value = attrs[key];
      if (value == null) return;
      if (key === "class") node.className = value;
      else if (key === "text") node.textContent = value;
      else node.setAttribute(key, value);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); });
    return node;
  }
  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      chrome.storage.local.get(key, function (result) {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(result && result[key]);
      });
    });
  }
  function storageSet(key, value) {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value);
    return new Promise(function (resolve, reject) {
      var payload = {}; payload[key] = value;
      chrome.storage.local.set(payload, function () {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    });
  }
  function runtimeMessage(type, payload) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (response) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response || response.ok !== true) {
          var error = new Error(response && response.userMessage || "Não foi possível concluir a operação de IA.");
          error.code = response && response.errorCode || "unknown_error";
          reject(error);
          return;
        }
        resolve(response.result);
      });
    });
  }
  function createId(prefix) {
    return prefix + "-" + (window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : Date.now() + "-" + Math.random().toString(36).slice(2, 10));
  }
  function providerIds() {
    return integrationCore.PROVIDERS.filter(function (provider) { return provider.kind === "ai"; }).map(function (provider) { return provider.id; });
  }
  function providerLabel(providerId) {
    var provider = integrationCore.providerById(providerId);
    return provider ? provider.label : "Serviço de IA";
  }
  function baseName(snapshot, assistant) {
    if (!assistant || !assistant.knowledge || assistant.knowledge.mode !== "base") return "";
    var base = knowledgeCore.findBase(snapshot.knowledge, assistant.knowledge.baseId);
    return base && base.name || "Base de Conhecimento";
  }
  function assistantFromStore(snapshot, assistantId) {
    return snapshot.assistants.assistants.find(function (entry) { return entry.id === assistantId; }) || null;
  }
  function validAssistants(snapshot) {
    return snapshot.assistants.assistants.filter(function (assistant) {
      return assistantsCore.healthFor(assistant, snapshot.integrations, providerIds(), snapshot.knowledge).state === "ready";
    });
  }
  function validAgents(snapshot) {
    return snapshot.agents.agents.filter(function (agent) {
      return agentsCore.healthFor(agent, snapshot.assistants, snapshot.integrations, providerIds(), snapshot.knowledge).state === "ready";
    });
  }
  async function loadSnapshot() {
    var values = await Promise.all([
      storageGet(assistantsCore.STORE_KEY),
      storageGet(agentsCore.STORE_KEY),
      runtimeMessage("EXTUI_INTEGRATION_GET_STATE"),
      runtimeMessage("EXTUI_KNOWLEDGE_GET_STATE"),
      storageGet(core.PREFERENCE_KEY)
    ]);
    return {
      assistantsRaw: values[0],
      assistants: assistantsCore.normalizeStore(values[0]),
      agentsRaw: values[1],
      agents: agentsCore.normalizeStore(values[1]),
      integrations: values[2],
      knowledge: knowledgeCore.normalizeStore(values[3]),
      preferences: core.normalizePreferences(values[4])
    };
  }
  function localDateTime() {
    var now = new Date();
    var offsetMinutes = -now.getTimezoneOffset();
    var sign = offsetMinutes >= 0 ? "+" : "-";
    var absolute = Math.abs(offsetMinutes);
    return new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().replace("Z", sign + String(Math.floor(absolute / 60)).padStart(2, "0") + ":" + String(absolute % 60).padStart(2, "0"));
  }
  function currentSession(contactId) {
    if (session && session.contactId === contactId) return session;
    if (session) {
      cancelRequests(session.activeRead);
      cancelRequests(session.activeAgent);
    }
    session = {
      contactId: contactId,
      actions: {},
      selectedAssistantId: null,
      selectedAgentId: null,
      activeRead: null,
      activeAgent: null,
      agentState: core.STATES.READY,
      agentResult: "",
      agentError: "",
      agentTrace: [],
      agentCancelledAfterWrites: false,
      snapshot: null,
      paint: null
    };
    [core.ACTIONS.SUMMARY, core.ACTIONS.NEXT_ACTION, core.ACTIONS.DRAFT].forEach(function (action) {
      session.actions[action] = core.state(action, core.STATES.READY);
    });
    return session;
  }
  function cancelRequests(record) {
    if (!record) return;
    record.cancelled = true;
    Array.from(record.requestIds || []).forEach(function (requestId) {
      runtimeMessage("EXTUI_AI_CANCEL", { requestId: requestId, executionId: record.executionId }).catch(function () {});
      runtimeMessage("EXTUI_KNOWLEDGE_RETRIEVAL_CANCEL", { requestId: requestId, executionId: record.executionId }).catch(function () {});
    });
  }
  function requestConversation(crmContactId, messageCount) {
    var requestId = createId("crm-context");
    return new Promise(function (resolve, reject) {
      var settled = false;
      function finish(error, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutId);
        if (error) reject(error); else resolve(value || []);
      }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        if (chrome.runtime.lastError || !tabs || !tabs.length) { finish(new Error("Abra o WhatsApp Web para carregar o contexto recente.")); return; }
        var tab = tabs.find(function (candidate) { return candidate.active; }) || tabs[0];
        chrome.tabs.sendMessage(tab.id, { type: "EXTUI_CRM_COPILOT_CONTEXT", requestId: requestId, crmContactId: crmContactId, messageCount: messageCount }, function (response) {
          if (chrome.runtime.lastError) { finish(new Error("Recarregue o WhatsApp Web para usar o contexto recente.")); return; }
          if (!response || response.requestId !== requestId || response.error) { finish(new Error(response && response.error || "Contexto recente indisponível.")); return; }
          finish(null, response.data);
        });
      });
      var timeoutId = setTimeout(function () { finish(new Error("O contexto recente excedeu o tempo limite.")); }, 20000);
    });
  }
  async function loadMemory(options, assistant) {
    if (!assistant.memory || assistant.memory.mode !== "customer") return [];
    var phone = options.resolvePhone();
    var subjectKey = await memoryCore.deriveSubjectKey(phone);
    if (!subjectKey) return [];
    return memoryCore.normalizeRuntimeMemory(memoryCore.listForSubject(await storageGet(memoryCore.STORE_KEY), subjectKey));
  }
  async function retrieveKnowledge(record, assistant, query) {
    if (!assistant.knowledge || assistant.knowledge.mode !== "base") return [];
    var requestId = createId("crm-knowledge");
    record.requestIds.add(requestId);
    try {
      var result = await runtimeMessage("EXTUI_KNOWLEDGE_RETRIEVE", { request: { requestId: requestId, executionId: record.executionId, baseId: assistant.knowledge.baseId, query: query } });
      return result && Array.isArray(result.knowledge) ? result.knowledge : [];
    } finally { record.requestIds.delete(requestId); }
  }
  async function loadResources(options, assistant, action, record) {
    var conversationPromise = assistant.context && assistant.context.mode === "recent"
      ? requestConversation(options.binding.crmContactId, assistant.context.messageCount)
      : Promise.resolve([]);
    var memoryPromise = loadMemory(options, assistant);
    var knowledgePromise = retrieveKnowledge(record, assistant, core.ACTION_COPY[action] ? core.ACTION_COPY[action].label + "\n" + core.publicContactText(options.publicContact) : action);
    var values = await Promise.all([conversationPromise, memoryPromise, knowledgePromise]);
    if (record.cancelled) { var cancelled = new Error("A operação foi cancelada."); cancelled.code = "ai_cancelled"; throw cancelled; }
    return { conversation: values[0], memory: values[1], knowledge: values[2] };
  }
  function friendlyError(error) {
    if (error && (error.code === "ai_cancelled" || error.code === agentsCore.ERRORS.CANCELLED)) return "Operação cancelada.";
    return error && error.message || "Não foi possível concluir a operação.";
  }
  function copyText(value, announce) {
    if (!value) return;
    navigator.clipboard.writeText(value).then(function () { announce("Texto copiado."); }, function () { announce("Não foi possível copiar o texto.", true); });
  }

  function mount(options) {
    if (!core || !assistantsCore || !agentsCore || !agentRuntime || !options || !core.validBinding(options.binding)) return null;
    if (activeMount) activeMount.dispose();
    var current = currentSession(options.binding.crmContactId);
    var disposed = false;
    var host = options.container;
    var details = element("details", { class: "extuiCrmCopilot", "data-extui-academy-target": "crm-ai-copilot" });
    if (options.open) details.open = true;
    var summary = element("summary", { class: "extuiCrmCopilot__summary" }, [
      element("span", { class: "extuiCrmCopilot__mark", text: "IA", "aria-hidden": "true" }),
      element("span", {}, [element("strong", { text: "Copiloto IA" }), element("small", { text: "Entenda o atendimento e decida os próximos passos." })]),
      element("span", { class: "extuiCrmCopilot__chevron", text: "⌄", "aria-hidden": "true" })
    ]);
    var surface = element("div", { class: "extuiCrmCopilot__surface" });
    details.appendChild(summary); details.appendChild(surface); host.appendChild(details);

    var live = element("div", { class: "extuiSrOnly", role: "status", "aria-live": "polite" });
    surface.appendChild(live);
    function announce(message, error) {
      live.textContent = message;
      if (options.toast) options.toast(message, error === true);
    }
    var header = element("header", { class: "extuiCrmCopilot__header" }, [
      element("div", {}, [element("span", { class: "extuiCrmCopilot__eyebrow", text: "COPILOTO IA" }), element("p", { text: "Use IA para entender o atendimento e decidir os próximos passos." })]),
      element("small", { text: "As ações usam o serviço configurado e podem gerar consumo na sua conta." })
    ]);
    surface.appendChild(header);
    var assistantField = element("label", { class: "extuiCrmCopilot__field" }, [element("span", { text: "Assistente" })]);
    var assistantSelect = element("select", { "aria-label": "Assistente do Copiloto IA" });
    assistantField.appendChild(assistantSelect);
    var assistantMeta = element("div", { class: "extuiCrmCopilot__meta" });
    var assistantEdit = element("button", { class: "extui-btn extui-btn--text", type: "button", text: "Editar Assistente ↗" });
    var configureIntegration = element("button", { class: "extui-btn extui-btn--text", type: "button", text: "Configurar integração ↗" }); configureIntegration.hidden = true;
    var assistantLinks = element("div", { class: "extuiCrmCopilot__selectionLinks" }, [configureIntegration, assistantEdit]);
    var assistantRow = element("div", { class: "extuiCrmCopilot__selection" }, [assistantField, element("div", { class: "extuiCrmCopilot__selectionFooter" }, [assistantMeta, assistantLinks])]);
    surface.appendChild(assistantRow);

    var actionGrid = element("div", { class: "extuiCrmCopilot__actions", "aria-label": "Ações de leitura do Copiloto" });
    var actionRail = element("div", { class: "extuiCrmCopilot__actionRail" });
    var actionResults = element("div", { class: "extuiCrmCopilot__results" });
    actionGrid.appendChild(actionRail); actionGrid.appendChild(actionResults);
    var actionViews = {};
    [core.ACTIONS.SUMMARY, core.ACTIONS.NEXT_ACTION, core.ACTIONS.DRAFT].forEach(function (action) {
      var labels = {};
      labels[core.ACTIONS.SUMMARY] = { title: "Resumir atendimento", copy: "Sintetize contexto, dúvidas e pendências." };
      labels[core.ACTIONS.NEXT_ACTION] = { title: "Sugerir próxima ação", copy: "Receba uma recomendação sem executar mudanças." };
      labels[core.ACTIONS.DRAFT] = { title: "Preparar resposta", copy: "Crie um rascunho editável para revisão." };
      var button = element("button", { class: "extuiCrmCopilot__action", type: "button" }, [element("strong", { text: labels[action].title }), element("span", { text: labels[action].copy }), element("span", { class: "extuiCrmCopilot__actionStatus", text: "Pronto" })]);
      var result = element("div", { class: "extuiCrmCopilot__result", "aria-live": "polite" });
      actionRail.appendChild(element("div", { class: "extuiCrmCopilot__actionWrap" }, [button]));
      actionResults.appendChild(result);
      actionViews[action] = { button: button, result: result };
      button.addEventListener("click", function () {
        if (current.activeRead && current.activeRead.action === action) cancelRead();
        else runRead(action);
      });
    });
    surface.appendChild(actionGrid);

    var agentSection = element("section", { class: "extuiCrmCopilot__agent", "aria-labelledby": "extui-crm-copilot-agent-title" });
    agentSection.appendChild(element("div", { class: "extuiCrmCopilot__agentHeading" }, [element("div", {}, [element("span", { class: "extuiCrmCopilot__eyebrow", text: "EXECUÇÃO EXPLÍCITA" }), element("h4", { id: "extui-crm-copilot-agent-title", text: "Agente" })]), element("p", { text: "Agentes podem usar as permissões do Assistente associado." })]));
    var agentSelect = element("select", { "aria-label": "Agente do CRM" });
    var agentField = element("label", { class: "extuiCrmCopilot__field" }, [element("span", { text: "Agente" }), agentSelect]);
    var agentCapabilities = element("div", { class: "extuiCrmCopilot__capabilities" });
    var taskInput = element("textarea", { rows: "3", maxlength: "6000", placeholder: "Ex.: Analise este contato e organize o CRM conforme o objetivo do Agente.", "aria-label": "Tarefa para o Agente" });
    var runAgentButton = element("button", { class: "extui-btn extui-btn--primary", type: "button", text: "Executar Agente" });
    var createAgentButton = element("button", { class: "extui-btn extui-btn--text", type: "button", text: "Criar Agente ↗" });
    var agentControls = element("div", { class: "extuiCrmCopilot__agentControls" }, [runAgentButton, createAgentButton]);
    var agentTrace = element("ol", { class: "extuiCrmCopilot__trace", "aria-label": "Progresso operacional do Agente" });
    var agentResult = element("div", { class: "extuiCrmCopilot__agentResult", "aria-live": "polite" });
    agentSection.appendChild(agentField); agentSection.appendChild(agentCapabilities); agentSection.appendChild(element("label", { class: "extuiCrmCopilot__field" }, [element("span", { text: "Tarefa" }), taskInput])); agentSection.appendChild(agentControls); agentSection.appendChild(agentTrace); agentSection.appendChild(agentResult);
    surface.appendChild(agentSection);

    function renderAction(action) {
      var view = actionViews[action];
      var state = current.actions[action];
      var busy = !!current.activeRead;
      view.button.disabled = busy && (!current.activeRead || current.activeRead.action !== action) || !current.selectedAssistantId;
      view.button.classList.toggle("is-running", state.status === core.STATES.GENERATING);
      view.button.querySelector("strong").textContent = state.status === core.STATES.GENERATING ? "Cancelar" : core.ACTION_COPY[action].label;
      view.button.querySelector(".extuiCrmCopilot__actionStatus").textContent = { ready: "Pronto", generating: "Gerando…", complete: "Concluído", error: "Erro", cancelled: "Cancelado" }[state.status] || "Pronto";
      view.result.innerHTML = "";
      if (state.status === core.STATES.READY) return;
      var statusText = { generating: "Gerando…", complete: "Concluído", error: "Erro", cancelled: "Cancelado" }[state.status] || "Pronto";
      view.result.appendChild(element("span", { class: "extuiCrmCopilot__state is-" + state.status, text: statusText }));
      if (state.status === core.STATES.ERROR) view.result.appendChild(element("p", { text: state.error }));
      if (state.status === core.STATES.CANCELLED) view.result.appendChild(element("p", { text: "A geração foi cancelada sem salvar resultados." }));
      if (state.status !== core.STATES.COMPLETE) return;
      if (action === core.ACTIONS.DRAFT) {
        var draft = element("textarea", { rows: "7", "aria-label": "Rascunho de resposta" }); draft.value = state.result;
        draft.addEventListener("input", function () { current.actions[action].result = draft.value; });
        view.result.appendChild(draft);
      } else view.result.appendChild(element("div", { class: "extuiCrmCopilot__output", text: state.result }));
      var controls = element("div", { class: "extuiCrmCopilot__resultActions" });
      var copy = element("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Copiar" }); copy.addEventListener("click", function () { copyText(current.actions[action].result, announce); }); controls.appendChild(copy);
      if (action === core.ACTIONS.SUMMARY) { var save = element("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Salvar como nota" }); save.addEventListener("click", function () { options.saveNote(current.actions[action].result); }); controls.appendChild(save); }
      if (action === core.ACTIONS.DRAFT) { var discard = element("button", { class: "extui-btn extui-btn--text", type: "button", text: "Descartar" }); discard.addEventListener("click", function () { current.actions[action] = core.state(action, core.STATES.READY); paint(); }); controls.appendChild(discard); var open = element("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Abrir conversa no WhatsApp" }); open.addEventListener("click", options.openWhatsApp); controls.appendChild(open); }
      view.result.appendChild(controls);
    }
    function renderAgent() {
      var running = !!current.activeAgent;
      runAgentButton.textContent = running ? "Cancelar execução" : "Executar Agente";
      agentSelect.disabled = running;
      taskInput.disabled = running;
      runAgentButton.disabled = !running && (!current.selectedAgentId || !taskInput.value.trim());
      agentTrace.innerHTML = "";
      current.agentTrace.forEach(function (entry) { agentTrace.appendChild(element("li", {}, [element("span", { text: entry.step ? "Etapa " + entry.step : "Execução" }), element("strong", { text: entry.label })])); });
      agentResult.innerHTML = "";
      if (current.agentState === core.STATES.GENERATING) agentResult.appendChild(element("span", { class: "extuiCrmCopilot__state is-generating", text: "Executando…" }));
      else if (current.agentState === core.STATES.ERROR) agentResult.appendChild(element("div", {}, [element("span", { class: "extuiCrmCopilot__state is-error", text: "Erro" }), element("p", { text: current.agentError })]));
      else if (current.agentState === core.STATES.CANCELLED) agentResult.appendChild(element("div", {}, [element("span", { class: "extuiCrmCopilot__state is-cancelled", text: "Cancelado" }), element("p", { text: current.agentCancelledAfterWrites ? "Execução cancelada. Ações já concluídas foram preservadas." : "A execução foi cancelada." })]));
      else if (current.agentState === core.STATES.COMPLETE && current.agentResult) {
        agentResult.appendChild(element("span", { class: "extuiCrmCopilot__state is-complete", text: "Concluído" }));
        agentResult.appendChild(element("div", { class: "extuiCrmCopilot__output", text: current.agentResult }));
        var controls = element("div", { class: "extuiCrmCopilot__resultActions" });
        var copy = element("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Copiar" }); copy.addEventListener("click", function () { copyText(current.agentResult, announce); });
        var open = element("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Abrir WhatsApp" }); open.addEventListener("click", options.openWhatsApp);
        var save = element("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Salvar como nota" }); save.addEventListener("click", function () { options.saveNote(current.agentResult); });
        controls.appendChild(copy); controls.appendChild(open); controls.appendChild(save); agentResult.appendChild(controls);
      }
    }
    function paint() {
      if (disposed) return;
      Object.keys(actionViews).forEach(renderAction);
      renderAgent();
    }
    current.paint = paint;

    async function runRead(action) {
      if (current.activeRead || !current.snapshot) return;
      try {
        var assistant = assistantsCore.resolveForExecution(current.snapshot.assistantsRaw, current.snapshot.integrations, current.selectedAssistantId, providerIds(), current.snapshot.knowledge);
        var record = { action: action, executionId: createId("crm-copilot"), requestIds: new Set(), cancelled: false, generation: createId("generation") };
        current.activeRead = record; current.actions[action] = core.state(action, core.STATES.GENERATING); paint();
        var resources = await loadResources(options, assistant, action, record);
        if (record.cancelled) return;
        var requestId = createId("crm-ai"); record.requestIds.add(requestId);
        var request = core.buildReadOnlyRequest({ action: action, binding: options.binding, assistant: assistant, contact: options.publicContact, conversation: resources.conversation, memory: resources.memory, knowledge: resources.knowledge, requestId: requestId, executionId: record.executionId });
        var result = await runtimeMessage("EXTUI_AI_GENERATE", { request: request });
        record.requestIds.delete(requestId);
        if (record.cancelled || current.activeRead !== record) return;
        current.actions[action] = core.state(action, core.STATES.COMPLETE, result && result.text);
        announce(core.ACTION_COPY[action].label + " concluído.");
      } catch (error) {
        if (!current.activeRead) return;
        current.actions[action] = error && error.code === "ai_cancelled" ? core.state(action, core.STATES.CANCELLED) : core.state(action, core.STATES.ERROR, friendlyError(error));
      } finally {
        if (current.activeRead && current.activeRead.action === action) current.activeRead = null;
        if (current.paint) current.paint();
      }
    }
    function cancelRead() {
      var record = current.activeRead;
      if (!record) return;
      cancelRequests(record);
      current.activeRead = null;
      current.actions[record.action] = core.state(record.action, core.STATES.CANCELLED);
      paint();
    }

    function renderAssistantSelection() {
      var snapshot = current.snapshot;
      var list = validAssistants(snapshot);
      assistantSelect.innerHTML = "";
      assistantSelect.appendChild(element("option", { value: "", text: list.length ? "Selecione um Assistente" : "Nenhum Assistente disponível" }));
      list.forEach(function (assistant) { assistantSelect.appendChild(element("option", { value: assistant.id, text: assistant.name })); });
      if (!list.some(function (assistant) { return assistant.id === current.selectedAssistantId; })) current.selectedAssistantId = null;
      assistantSelect.value = current.selectedAssistantId || "";
      var assistant = assistantFromStore(snapshot, current.selectedAssistantId);
      assistantMeta.textContent = assistant ? core.capabilitySummary(assistant, providerLabel(assistant.providerId), baseName(snapshot, assistant)) : "Selecione um Assistente para começar.";
      assistantEdit.textContent = assistant ? "Editar Assistente ↗" : "Criar Assistente ↗";
      configureIntegration.hidden = !!assistant || !snapshot.assistants.assistants.length;
      Object.keys(actionViews).forEach(renderAction);
    }
    function renderAgentSelection() {
      var snapshot = current.snapshot;
      var list = validAgents(snapshot);
      agentSelect.innerHTML = "";
      agentSelect.appendChild(element("option", { value: "", text: list.length ? "Selecione um Agente" : "Nenhum Agente criado" }));
      list.forEach(function (agent) { agentSelect.appendChild(element("option", { value: agent.id, text: agent.name })); });
      if (!list.some(function (agent) { return agent.id === current.selectedAgentId; })) current.selectedAgentId = null;
      agentSelect.value = current.selectedAgentId || "";
      agentCapabilities.innerHTML = "";
      if (!current.selectedAgentId) agentCapabilities.appendChild(element("p", { text: list.length ? "Selecione um Agente para visualizar as capacidades." : "Nenhum Agente criado." }));
      else {
        try {
          var resolved = agentsCore.resolveForExecution(snapshot.agentsRaw, snapshot.assistantsRaw, snapshot.integrations, current.selectedAgentId, providerIds(), snapshot.knowledge);
          var assistant = assistantFromStore(snapshot, resolved.assistant.assistantId);
          var definitions = toolsRegistry.definitionsFor(resolved.assistant.tools.enabled);
          var capabilities = core.agentCapabilitySummary(resolved, definitions, providerLabel(resolved.assistant.providerId), baseName(snapshot, assistant));
          var entries = ["Assistente: " + capabilities.assistant, "Tools: " + capabilities.tools.length, "Knowledge: " + capabilities.knowledge, "Memória: " + capabilities.memory, "Contexto: " + capabilities.context, "Max steps: " + capabilities.maxSteps];
          entries.forEach(function (value) { agentCapabilities.appendChild(element("span", { text: value })); });
        } catch (error) { agentCapabilities.appendChild(element("p", { text: "Este Agente requer atenção." })); }
      }
      renderAgent();
    }
    async function savePreferences() {
      await storageSet(core.PREFERENCE_KEY, core.serializePreferences({ assistantId: current.selectedAssistantId, agentId: current.selectedAgentId }));
    }
    assistantSelect.addEventListener("change", function () { current.selectedAssistantId = assistantSelect.value || null; savePreferences().catch(function () {}); renderAssistantSelection(); });
    agentSelect.addEventListener("change", function () { current.selectedAgentId = agentSelect.value || null; savePreferences().catch(function () {}); renderAgentSelection(); });
    taskInput.addEventListener("input", renderAgent);
    assistantEdit.addEventListener("click", function () { options.navigate("ai-assistants", current.selectedAssistantId); });
    configureIntegration.addEventListener("click", function () { options.navigate("ai-connect"); });
    createAgentButton.addEventListener("click", function () { options.navigate("ai-agents", current.selectedAgentId); });

    async function runAgent() {
      if (current.activeAgent) { cancelAgent(); return; }
      if (!current.snapshot || !current.selectedAgentId || !taskInput.value.trim()) { taskInput.focus(); return; }
      var resolved;
      try { resolved = agentsCore.resolveForExecution(current.snapshot.agentsRaw, current.snapshot.assistantsRaw, current.snapshot.integrations, current.selectedAgentId, providerIds(), current.snapshot.knowledge); }
      catch (error) { current.agentState = core.STATES.ERROR; current.agentError = friendlyError(error); paint(); return; }
      var definitions = toolsRegistry.definitionsFor(resolved.assistant.tools.enabled);
      var writeCapabilities = core.writeCapabilities(definitions.map(function (definition) { return definition.id; }));
      if (writeCapabilities.length) {
        var accepted = await options.confirm("Este Agente pode alterar dados deste contato usando as ferramentas permitidas no Assistente:\n\n- " + writeCapabilities.map(function (capability) { return capability.label; }).join("\n- ") + "\n\nDeseja executar o Agente?");
        if (!accepted) return;
      }
      var record = { executionId: createId("crm-copilot-agent"), requestIds: new Set(), cancelled: false, writesObserved: false };
      current.activeAgent = record; current.agentState = core.STATES.GENERATING; current.agentResult = ""; current.agentError = ""; current.agentTrace = []; paint();
      try {
        var result = await agentRuntime.execute({ data: { task: taskInput.value.trim(), source: "crm_copilot" } }, { id: record.executionId, source: "crm_copilot" }, resolved, {
          createRequestId: function () { return createId("crm-agent-ai"); },
          createRunId: function () { return createId("crm-agent-run"); },
          now: Date.now,
          resolveTemplate: function (value) { return value; },
          isCancelled: function () { return record.cancelled; },
          loadMemory: async function () { return { entries: await loadMemory(options, resolved.assistant), unavailable: false }; },
          loadConversation: function (config) { return requestConversation(options.binding.crmContactId, config && config.messageCount); },
          retrieveKnowledge: async function (request) { record.requestIds.add(request.requestId); try { return await runtimeMessage("EXTUI_KNOWLEDGE_RETRIEVE", { request: request }); } finally { record.requestIds.delete(request.requestId); } },
          resolveToolContext: async function () { var subjectKey = await memoryCore.deriveSubjectKey(options.resolvePhone()); return { crmContactId: options.binding.crmContactId, crmId: options.binding.crmId, memorySubjectKey: subjectKey || "", localDateTime: localDateTime(), source: "crm_copilot" }; },
          generate: async function (request) { record.requestIds.add(request.requestId); try { return await runtimeMessage("EXTUI_AI_GENERATE", { request: request }); } finally { record.requestIds.delete(request.requestId); } },
          onRequestStart: function (requestId) { record.requestIds.add(requestId); },
          onRequestEnd: function (requestId) { record.requestIds.delete(requestId); },
          onRunStart: function (info) { current.agentTrace = [{ step: null, label: "Agente iniciado: " + info.agentName, success: true }]; if (current.paint) current.paint(); },
          onStep: function (info) { if (Array.isArray(info.events) && info.events.length) { info.events.forEach(function (event) { if (event.risk === "write" && event.success) record.writesObserved = true; }); current.agentTrace = core.safeTrace(current.agentTrace.concat(info.events.map(function (event) { return { step: info.step, label: event.label, success: event.success }; }))); } else if (info.status === "running") current.agentTrace = core.safeTrace(current.agentTrace.concat([{ step: info.step, label: "Analisando contato", success: true }])); if (current.paint) current.paint(); },
          onToolsUsed: function (tools) { if (tools && Array.isArray(tools.events) && tools.events.some(function (event) { return event.risk === "write" && event.success; })) record.writesObserved = true; },
          onKnowledgeLoaded: function () {}, onMemoryLoaded: function () {}, onContextLoaded: function () {},
          endAgentRun: function (agentRunId, executionId) { runtimeMessage("EXTUI_AI_AGENT_END", { agentRunId: agentRunId, executionId: executionId }).catch(function () {}); }
        });
        if (record.cancelled || current.activeAgent !== record) return;
        current.agentState = core.STATES.COMPLETE; current.agentResult = result.text; current.agentTrace = core.safeTrace(result.metadata && result.metadata.trace || current.agentTrace); announce("Execução do Agente concluída.");
      } catch (error) {
        if (record.cancelled || agentRuntime.isCancellationError(error)) { current.agentState = core.STATES.CANCELLED; current.agentCancelledAfterWrites = record.writesObserved; }
        else { current.agentState = core.STATES.ERROR; current.agentError = friendlyError(error); }
      } finally {
        if (current.activeAgent === record) current.activeAgent = null;
        if (current.paint) current.paint();
      }
    }
    function cancelAgent() {
      var record = current.activeAgent;
      if (!record) return;
      cancelRequests(record);
      current.activeAgent = null;
      current.agentState = core.STATES.CANCELLED;
      current.agentCancelledAfterWrites = record.writesObserved;
      paint();
    }
    runAgentButton.addEventListener("click", runAgent);

    var watchedKeys = [assistantsCore.STORE_KEY, agentsCore.STORE_KEY, integrationCore.STORE_KEY, knowledgeCore.STORE_KEY];
    var writeKeys = ["EXTUI:CrmStore", crmProfessionalCore && crmProfessionalCore.STORE_KEY, memoryCore.STORE_KEY].filter(Boolean);
    function onStorage(changes, area) {
      if (area !== "local") return;
      if (current.activeAgent && writeKeys.some(function (key) { return changes[key]; })) current.activeAgent.writesObserved = true;
      if (!watchedKeys.some(function (key) { return changes[key]; })) return;
      loadSnapshot().then(applySnapshot).catch(function () {});
    }
    chrome.storage.onChanged.addListener(onStorage);
    function applySnapshot(snapshot) {
      if (disposed) return;
      current.snapshot = snapshot;
      if (!current.selectedAssistantId) current.selectedAssistantId = snapshot.preferences.assistantId;
      if (!current.selectedAgentId) current.selectedAgentId = snapshot.preferences.agentId;
      renderAssistantSelection(); renderAgentSelection(); paint();
    }
    loadSnapshot().then(applySnapshot).catch(function (error) { assistantMeta.textContent = friendlyError(error); });
    if (options.open) setTimeout(function () { if (!disposed) { details.open = true; summary.focus(); details.scrollIntoView({ block: "nearest" }); } }, 0);

    activeMount = {
      contactId: options.binding.crmContactId,
      dispose: function () { if (disposed) return; disposed = true; chrome.storage.onChanged.removeListener(onStorage); if (current.paint === paint) current.paint = null; }
    };
    return activeMount;
  }

  function clear(contactId) {
    if (activeMount) { activeMount.dispose(); activeMount = null; }
    if (!contactId || session && session.contactId === contactId) {
      if (session) { cancelRequests(session.activeRead); cancelRequests(session.activeAgent); }
      session = null;
    }
  }

  window.__extCrmAiCopilot = Object.freeze({ mount: mount, clear: clear });
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
