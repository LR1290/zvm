;
try{
(function () {
  "use strict";

  if (window.__extCrmModuleBooted) return;
  window.__extCrmModuleBooted = true;

  var STORAGE_KEY = "EXTUI:CrmStore";
  var professionalCore = window.__extCrmProfessionalCore;
  var professionalStore = professionalCore ? professionalCore.normalizeStore(null) : null;
                                                                           
                                                                            
                                                                          
                                                                           
                                                                           
                                                                        
                                                          
  function parseLocalDateTimeStrict(value){
    var m=String(value||"").match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/);
    if(!m)return NaN;
    var y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]),h=Number(m[4]),mi=Number(m[5]),sec=Number(m[6]||0);
    var dt=new Date(y,mo-1,d,h,mi,sec,0);
    return dt.getFullYear()===y&&dt.getMonth()===mo-1&&dt.getDate()===d&&dt.getHours()===h&&dt.getMinutes()===mi&&dt.getSeconds()===sec?dt.getTime():NaN;
  }
  function localDateInputValue(ms){var d=new Date(Number(ms));if(!Number.isFinite(d.getTime()))return"";return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");}
  var _pendingColumnEvents = [];
  var _columnEventFlushTimer = 0;
  var _columnEventFlushDelayMs = 1500;
  function columnEventId() {
    return "crm-event:" + (window.crypto && crypto.randomUUID ? crypto.randomUUID() : (Date.now().toString(36) + ":" + Math.random().toString(36).slice(2) + ":" + Math.random().toString(36).slice(2)));
  }
  function sendColumnEventToAuthority(event) {
    function request() {
      return new Promise(function (resolve, reject) {
        var settled = false, timer = setTimeout(function () { if (settled) return; settled = true; var timeout = new Error("A fila de automação do CRM demorou demais para responder."); timeout.code = "CRM_COLUMN_EVENT_QUEUE_TIMEOUT"; reject(timeout); }, 7000);
        try {
          chrome.runtime.sendMessage({ type: "EXTUI_COLUMN_EVENT_QUEUE", action: "enqueue", event: event }, function (response) {
            if (settled) return; settled = true; clearTimeout(timer);
            if (chrome.runtime.lastError) { var transport = new Error(chrome.runtime.lastError.message || "Não foi possível registrar a movimentação do CRM."); transport.code = "CRM_COLUMN_EVENT_QUEUE_TRANSPORT"; reject(transport); return; }
            if (!response || response.ok !== true) { var error = new Error(response && response.userMessage || "Não foi possível registrar a movimentação do CRM."); error.code = response && response.errorCode || "CRM_COLUMN_EVENT_QUEUE_FAILED"; reject(error); return; }
            resolve(response.result || null);
          });
        } catch (error) { if (!settled) { settled = true; clearTimeout(timer); reject(error); } }
      });
    }
    return request().catch(async function (error) {
      if (!error || ["CRM_COLUMN_EVENT_QUEUE_TIMEOUT", "CRM_COLUMN_EVENT_QUEUE_TRANSPORT"].indexOf(error.code) < 0) throw error;
      await new Promise(function (resolve) { setTimeout(resolve, 120); });
      return request();
    });
  }
  function pushColumnEvent(crmId, columnId, contactId) {
    _pendingColumnEvents.push({ id: columnEventId(), crmId: crmId, columnId: columnId, contactId: contactId, atMs: Date.now(), committed: false });
    return Promise.resolve();
  }
  function markCommittedColumnEvents(count) {
    var limit = Math.max(0, Math.min(Number(count) || 0, _pendingColumnEvents.length));
    for (var i = 0; i < limit; i++) _pendingColumnEvents[i].committed = true;
  }
  function scheduleCommittedColumnEventFlush() {
    if (_columnEventFlushTimer || !_pendingColumnEvents.some(function (event) { return event && event.committed === true; })) return;
    _columnEventFlushTimer = setTimeout(function () {
      _columnEventFlushTimer = 0;
      flushCommittedColumnEvents().catch(function (error) {
        if (window.__extReportRuntimeError) window.__extReportRuntimeError("CRM_COLUMN_EVENT_ENQUEUE_RETRY_FAILED", error);
      });
    }, _columnEventFlushDelayMs);
  }
  async function flushCommittedColumnEvents() {
    while (_pendingColumnEvents.length && _pendingColumnEvents[0] && _pendingColumnEvents[0].committed === true) {
      var event = _pendingColumnEvents[0];
      try { await sendColumnEventToAuthority(event); }
      catch (error) {
        if (window.__extReportRuntimeError) window.__extReportRuntimeError("CRM_COLUMN_EVENT_ENQUEUE_FAILED", error);
        scheduleCommittedColumnEventFlush();
        return false;
      }
      _pendingColumnEvents.shift();
    }
    return true;
  }
  var COLOR_PALETTE = ["#00be5f", "#f87171", "#fb923c", "#fbbf24", "#4ade80", "#22d3ee", "#818cf8", "#e879f9", "#f472b6"];

                                                                        
                                                                   
                                                                   
                                               
  var ICONS = {
    refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    chat: '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
    note: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h6"/>',
    play: '<polygon points="6 3 20 12 6 21 6 3"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
    more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
                                                
    calendar: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
    zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
    activity: '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
    layoutGrid: '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
    kanbanIcon: '<path d="M6 5v11"/><path d="M12 5v6"/><path d="M18 5v14"/>',
    funnel: '<path d="M3 4h18l-7 8v6l-4 2v-8z"/>',
    expand: '<path d="M15 3h6v6"/><path d="m21 3-7 7"/><path d="M9 21H3v-6"/><path d="m3 21 7-7"/>',
    arrowLeft: '<path d="m15 18-6-6 6-6"/><path d="M9 12h10"/>',
    plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    edit: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
    pin: '<path d="M12 17v5"/><path d="M5 17h14"/><path d="M6 3h12l-2 7 3 3H5l3-3z"/>',
    archive: '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
    restore: '<path d="M3 12a9 9 0 1 0 3-6.708L3 8"/><path d="M3 3v5h5"/>'
  };
  function icon(name, extraClass) {
    var span = document.createElement("span");
    span.className = "extui-svgicon" + (extraClass ? " " + extraClass : "");
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || "") + "</svg>";
    return span;
  }

                                                                         
  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
  }
  function hashColor(seed) {
    var s = String(seed || "x"), h = 0;
    for (var i = 0; i < s.length; i++) { h = (h << 5) - h + s.charCodeAt(i); h |= 0; }
    return COLOR_PALETTE[Math.abs(h) % COLOR_PALETTE.length];
  }
  function initials(name) {
    name = String(name || "").trim();
    if (!name) return "?";
    var parts = name.split(/\s+/);
    var s = parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : name.slice(0, 2);
    return s.toUpperCase();
  }
  function renderAvatarEl(contact, sizeClass) {
    var color = hashColor(contact.phoneNumber || contact.name);
    var wrap = el("div", { class: "extui-avatar " + sizeClass, style: "background:" + color + ";--extui-avatar-ring:" + color });
    if (contact.avatar) {
      var img = el("img", { src: contact.avatar, alt: "" });
      img.addEventListener("error", function () { img.remove(); wrap.textContent = initials(contact.name); });
      wrap.appendChild(img);
    } else {
      wrap.textContent = initials(contact.name);
    }
    return wrap;
  }
  function crmFiniteNumber(value) {
    var n = Number(value);
    return Number.isFinite(n) ? n : 0;
  }
  function crmCurrency(value) {
    try { return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 2 }).format(crmFiniteNumber(value)); }
    catch (_) { return "R$ " + crmFiniteNumber(value).toFixed(2).replace(".", ","); }
  }
  function crmNormalizeDealValue(value) {
    var raw = String(value == null ? "" : value).trim();
    if (!raw) return 0;
    raw = raw.replace(/\s+/g, "").replace(/R\$/gi, "");
    if (raw.indexOf(",") >= 0) raw = raw.replace(/\./g, "").replace(",", ".");
    var parsed = Number(raw);
    if (!Number.isFinite(parsed) || parsed < 0) return 0;
    return Math.round(parsed * 100) / 100;
  }
  function crmValueDefinitions(crm) {
    if (!crm || !professionalCore) return [];
    var store = professionalCore.normalizeStore(professionalStore);
    var board = store.boards && store.boards[crm.id];
    return (board && Array.isArray(board.fieldDefinitions) ? board.fieldDefinitions : []).filter(function (definition) {
      return definition && definition.type === "number" && /(valor|neg[oó]cio|receita|ticket|revenue|deal)/i.test(String(definition.label || definition.id || ""));
    });
  }
  function crmItemValue(crm, item) {
    if (!item) return 0;
    var hasDirect = ["valNegocio","dealValue","businessValue","valorNegocio","value"].some(function (key) { return Object.prototype.hasOwnProperty.call(item, key) && item[key] != null; });
    var direct = crmFiniteNumber(item.valNegocio != null ? item.valNegocio : (item.dealValue != null ? item.dealValue : (item.businessValue != null ? item.businessValue : (item.valorNegocio != null ? item.valorNegocio : item.value))));
    if (hasDirect) return Math.max(0, direct);
    if (!professionalCore || !crm) return 0;
    var store = professionalCore.normalizeStore(professionalStore);
    var profile = store.contacts && store.contacts[item.id];
    if (!profile || !profile.fieldValues) return 0;
    return crmValueDefinitions(crm).reduce(function (sum, definition) { return sum + crmFiniteNumber(profile.fieldValues[definition.id]); }, 0);
  }
  function crmContactSummary(item) {
    return professionalCore && item ? professionalCore.summarizeContact(professionalStore, item.id, { now: Date.now(), eventLimit: 1 }) : null;
  }
  function crmColumnMetrics(crm, col) {
    var metrics = { contacts: 0, value: 0, openTasks: 0, overdueTasks: 0 };
    (col && col.items || []).forEach(function (item) {
      metrics.contacts++;
      metrics.value += crmItemValue(crm, item);
      var summary = crmContactSummary(item);
      if (summary) { metrics.openTasks += summary.openTaskCount || 0; metrics.overdueTasks += summary.overdueTaskCount || 0; }
    });
    return metrics;
  }
  function crmBoardMetrics(crm) {
    var metrics = { contacts: 0, value: 0, openTasks: 0, overdueTasks: 0 };
    (crm && crm.columns || []).forEach(function (col) {
      var part = crmColumnMetrics(crm, col);
      metrics.contacts += part.contacts; metrics.value += part.value; metrics.openTasks += part.openTasks; metrics.overdueTasks += part.overdueTasks;
    });
    return metrics;
  }
  function renderKanbanOperationalSummary(crm) {
    var metrics = crmBoardMetrics(crm);
    var wrap = el("section", { class: "extuiCrmKanbanSummary", "aria-label": "Resumo operacional do CRM" });
    [["Contatos", String(metrics.contacts)], ["Pipeline", crmCurrency(metrics.value)], ["Tarefas pendentes", String(metrics.openTasks)], ["Tarefas atrasadas", String(metrics.overdueTasks)]].forEach(function (entry, index) {
      wrap.appendChild(el("div", { class: "extuiCrmKanbanSummary__item" + (index === 3 && metrics.overdueTasks ? " is-alert" : "") }, [el("span", { text: entry[0] }), el("strong", { text: entry[1] })]));
    });
    return wrap;
  }
  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }

                                                                         
                                                                           
                                                                            
                                                                     
                                                                            
                                                                      
                                                                      
                                                                            
                                                                            
                                                                            
  var DEFAULT_STATE = { revision: 0, crmList: [], selectedCrmId: "" };

  function normalizeLoadedState(state) {
    var input = state && typeof state === "object" && !Array.isArray(state) ? state : {};
    var out = Object.assign({}, DEFAULT_STATE, input);
    delete out.dummyTrigger;
    out.revision = Math.max(0, Number(out.revision) || 0);
    out.selectedCrmId = String(out.selectedCrmId || "");
    out.crmList = (Array.isArray(out.crmList) ? out.crmList : []).filter(function (crm) { return crm && typeof crm === "object"; }).map(function (crm) {
      var safeCrm = Object.assign({}, crm);
      safeCrm.columns = (Array.isArray(crm.columns) ? crm.columns : []).filter(function (col) { return col && typeof col === "object"; }).map(function (col) {
        var safeCol = Object.assign({}, col);
        safeCol.items = (Array.isArray(col.items) ? col.items : []).filter(function (item) { return item && typeof item === "object"; }).map(function (item) {
          var safeItem = Object.assign({}, item), contact = item.contact && typeof item.contact === "object" ? item.contact : {};
          safeItem.contact = Object.assign({}, contact, {
            name: String(contact.name || contact.pushname || contact.formattedName || ""),
            phoneNumber: contact.phoneNumber == null ? null : String(contact.phoneNumber)
          });
          return safeItem;
        });
        return safeCol;
      });
      return safeCrm;
    });
    return out;
  }
  function loadStore() {
    return new Promise(function (resolve, reject) {
      chrome.storage.local.get(STORAGE_KEY, function (res) {
        if (chrome.runtime && chrome.runtime.lastError) { var storageError = new Error(chrome.runtime.lastError.message || "Não foi possível carregar o CRM."); void chrome.runtime.lastError; reject(storageError); return; }
        var raw = res && res[STORAGE_KEY];
        if (!raw) return resolve(normalizeLoadedState(DEFAULT_STATE));
        try {
          var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
          if(!parsed||typeof parsed!=="object"||Array.isArray(parsed)){var invalid=new Error("Os dados do CRM estão inválidos e não serão sobrescritos.");invalid.code="CRM_STORE_CORRUPT";throw invalid;}
          var state = parsed.state != null ? parsed.state : parsed;
          if(!state||typeof state!=="object"||Array.isArray(state)){var invalidState=new Error("Os dados do CRM estão inválidos e não serão sobrescritos.");invalidState.code="CRM_STORE_CORRUPT";throw invalidState;}
          resolve(normalizeLoadedState(state));
        } catch (e) {
          e.code = e.code || "CRM_STORE_CORRUPT";
          reject(e);
        }
      });
    });
  }
  function saveStore(state) {
    state.revision = Math.max(0, Number(state.revision) || 0) + 1;
    delete state.dummyTrigger;
    var wrapped = JSON.stringify({ state: state, version: 0 });
    var payload = {}; payload[STORAGE_KEY] = wrapped;
    return window.__extDashboardShell.storageSet(payload);
  }

  function loadProfessionalStore() {
    if (!professionalCore) return Promise.resolve(null);
    return new Promise(function (resolve, reject) {
      chrome.storage.local.get(professionalCore.STORE_KEY, function (result) {
        if (chrome.runtime && chrome.runtime.lastError) { var storageError = new Error(chrome.runtime.lastError.message || "Não foi possível carregar os dados profissionais do CRM."); void chrome.runtime.lastError; reject(storageError); return; }
        resolve(professionalCore.normalizeStore(result && result[professionalCore.STORE_KEY]));
      });
    });
  }

  function runProfessionalOperation(operation) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ __extCrmProfessionalOperation: true, operation: operation }, function (response) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response || response.ok !== true) { reject(new Error(response && response.error ? response.error : "Não foi possível salvar os dados do CRM.")); return; }
        loadProfessionalStore().then(function (store) { professionalStore = store; resolve(response.result || null); }, reject);
      });
    });
  }

                                                                        
  var S = Object.assign({}, DEFAULT_STATE);
  var savingLock = false;
  var pendingSave = false;
  var identityUpgradeSaving = false;
  var crmRefreshTimer = 0;

                                                                            
                                                                         
                                                                             
                                                                           
                                                                        
                                                                       
                                                       
  async function mutate(fn) {
    fn(S);
    render();
    if (savingLock) { pendingSave = true; return; }
    savingLock = true;
    try {
      do {
        pendingSave = false;
        var committedEventCount = _pendingColumnEvents.length;
        await saveStore(S);
        if (committedEventCount) {
          markCommittedColumnEvents(committedEventCount);
          await flushCommittedColumnEvents();
        }
      } while (pendingSave);
    } finally {
      savingLock = false;
    }
  }

  function isCrmArchived(crm) { return !!(crm && Number(crm.archivedAtInMs || 0) > 0); }
  function getActiveCrms() { return S.crmList.filter(function (crm) { return !isCrmArchived(crm); }); }
  function getArchivedCrms() { return S.crmList.filter(isCrmArchived); }
  function getSelectedCrm() {
    var active = getActiveCrms();
    return active.find(function (c) { return c.id === S.selectedCrmId; }) || active[0] || null;
  }
  function touchCrm(crm) { if (crm) crm.updatedAtInMs = Date.now(); }
  var activeMoveUndoToast = null;
  function offerCrmMoveUndo(info) {
    if (!info || !info.crmId || !info.itemId || !info.fromColumnId || !info.toColumnId) return;
    if (activeMoveUndoToast) { activeMoveUndoToast.remove(); activeMoveUndoToast = null; }
    var bar = el("div", { class: "extuiCrmUndoToast", role: "status" });
    bar.appendChild(el("span", { text: "Contato movido para " + (info.toTitle || "outra etapa") + "." }));
    var undo = el("button", { type: "button", text: "Desfazer" });
    var timer = setTimeout(function(){ if(bar.isConnected)bar.remove(); if(activeMoveUndoToast===bar)activeMoveUndoToast=null; }, 6500);
    undo.addEventListener("click", async function () {
      clearTimeout(timer); undo.disabled = true;
      var reversed = false, contactId = info.itemId;
      await mutate(function (state) {
        var crm = state.crmList.find(function (candidate) { return candidate.id === info.crmId; }); if (!crm) return;
        var from = (crm.columns || []).find(function (column) { return column.id === info.toColumnId; });
        var to = (crm.columns || []).find(function (column) { return column.id === info.fromColumnId; });
        if (!from || !to) return;
        var index = (from.items || []).findIndex(function (item) { return item.id === info.itemId; }); if (index < 0) return;
        var item = from.items.splice(index, 1)[0];
        var insertAt = Math.max(0, Math.min(Number(info.fromIndex || 0), to.items.length)); to.items.splice(insertAt, 0, item); reversed = true;
        pushColumnEvent(crm.id, to.id, item.id);
      });
      if (reversed) {
        runProfessionalOperation({ type: "event.add", crmContactId: contactId, event: { type: "column_moved", title: "Movimentação desfeita", description: (info.toTitle || "Etapa") + " → " + (info.fromTitle || "Etapa"), metadata: { fromColumnId: info.toColumnId, toColumnId: info.fromColumnId, undo: true } } }).catch(function(){});
        toast("Movimentação desfeita.");
      }
      bar.remove(); if(activeMoveUndoToast===bar)activeMoveUndoToast=null;
    });
    bar.appendChild(undo); document.body.appendChild(bar); activeMoveUndoToast = bar;
  }

                                                                          
                                                                     
                                                                           
                                                                  
                                                                        
                                                                         
    
                                                                      
                                                                        
                                                                           
                                                                          

                                                                           
                                                                              
  function findPhoneMembershipInCrm(crm, phoneNumber, excludeItemId) {
    if (!crm || phoneNumber == null) return null;
    for (var ci = 0; ci < (crm.columns || []).length; ci++) {
      var column = crm.columns[ci];
      for (var ii = 0; ii < (column.items || []).length; ii++) {
        var item = column.items[ii];
        if (item && item.id !== excludeItemId && item.contact && item.contact.phoneNumber === phoneNumber) return { column: column, item: item, index: ii };
      }
    }
    return null;
  }

                                                                           
                                                                            
                                                                              
  function displayPhone(phoneNumber) {
    return phoneNumber || "Telefone não disponível";
  }
  function isCentralCustomer(contact) {
    try { return !!(window.ExtensionCustomerStore && window.ExtensionCustomerStore.isKnownSync(contact && contact.phoneNumber)); } catch (_) { return false; }
  }
  function contactNameNode(contact, className) {
    var node=el("div",{class:className||"",title:contact&&contact.name||""});
    node.appendChild(document.createTextNode(String(contact&&contact.name||"Contato")));
    if(isCentralCustomer(contact)) node.appendChild(el("span",{class:"extuiCrmCustomerBadge",title:"Cliente registrado no Painel de Clientes","aria-label":"Cliente registrado",text:"✓"}));
    return node;
  }

                                                                         
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }

                                                                        
  function openWhatsApp(phone) {
    var url = "https://web.whatsapp.com/send/?phone=" + encodeURIComponent(phone);
    try {
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        var tb = (tabs || []).find(function (t) { return t.active; }) || (tabs || [])[0];
        if (tb) {
          chrome.tabs.update(tb.id, { active: true, url: url });
          try { chrome.windows.update(tb.windowId, { focused: true }); } catch (e) {}
        } else {
          chrome.tabs.create({ url: url, active: true });
        }
      });
    } catch (e) {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  }

  function loadManualFlows() {
    return new Promise(function (resolve) {
      chrome.storage.local.get("EXTUI:extappFlowStore", function (res) {
        var raw = res && res["EXTUI:extappFlowStore"];
        var parsed = null;
        try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; } catch (e) { parsed = null; }
        var flows = (parsed && parsed.state && parsed.state.flowList) || [];
        resolve(flows.filter(function (f) { return f.isActive && f.trigger && f.trigger.type === "manual"; }));
      });
    });
  }
  function startFluxoManual(flowId, phoneNumber) {
    chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
      var tb = (tabs || [])[0];
      if (!tb) { toast("Abra o WhatsApp Web para iniciar um fluxo.", true); return; }
      chrome.tabs.sendMessage(tb.id, { type: "EXTUI_FLUXOS_START_MANUAL", flowId: flowId, phoneNumber: phoneNumber }, function (resp) {
        if (chrome.runtime.lastError || !resp || !resp.ok) {
          toast("Não foi possível iniciar o fluxo: " + (resp && resp.error || (chrome.runtime.lastError && chrome.runtime.lastError.message) || "erro desconhecido"), true);
        } else {
          toast("Fluxo iniciado.");
        }
      });
    });
  }
  async function openManualFlowPicker(phoneNumber) {
    var flows = await loadManualFlows();
    if (flows.length === 0) { toast("Nenhum fluxo com gatilho manual está ativo.", true); return; }
    openModal({
      title: "Iniciar fluxo",
      confirmLabel: "Iniciar",
      render: function (body, close, confirmBtn) {
        var select = el("select", {});
        flows.forEach(function (f) {
          select.appendChild(el("option", { value: f.id, text: f.name }));
        });
        body.appendChild(el("label", { text: "Escolha o fluxo" }));
        body.appendChild(select);
        confirmBtn.addEventListener("click", function () {
          startFluxoManual(select.value, phoneNumber);
          close();
        });
      }
    });
  }

                                                                        
                                                                         
                                                                 
                                                                    
                                                                    
                                                                      
                                       
    
                                                                      
                                                                  
                                                            
                                                                          
                                                                    
                                                                           
                                                                   
    
                                                                        
                                                                    
                                                                     
                                                                  
                      
  function fetchWhatsAppContacts() {
    return new Promise(function (resolve) {
      var requestId = "crm-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      var done = false;
      var timeoutId = null;
      function finish(result) {
        if (done) return;
        done = true;
        if (timeoutId) clearTimeout(timeoutId);
        resolve(result);
      }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        var tb = (tabs || [])[0];
        if (!tb) { finish(null); return; }
        chrome.tabs.sendMessage(tb.id, { type: "EXTUI_CRM_FETCH_CONTACTS_V2", requestId: requestId }, function (response) {
          if (chrome.runtime.lastError) { finish(null); return; }
          if (!response || response.requestId !== requestId) { finish(null); return; }
          if (response.error) { finish(null); return; }
          finish(response.data || []);
        });
        timeoutId = setTimeout(function () { finish(null); }, 25000);                                                              
      });
    });
  }

                                                                          
                                                                           
                                                                             
                                                                            
                                                                             
  function openExportContactsModal() {
    openModal({
      title: "Exportar Contatos",
      confirmLabel: "Exportar",
      render: function (body, close, confirmBtn) {
        body.innerHTML =
          '<label>Prefixo do nome (opcional)</label><input type="text" id="extuiCrmExportPrefix" placeholder="Ex: Cliente -">' +
          '<label>Limite (0 = sem limite)</label><input type="number" id="extuiCrmExportLimit" value="0" min="0">' +
          '<label>Formato</label><select id="extuiCrmExportFormat"><option value="csv">Planilha (.csv)</option><option value="vcf">Contatos (.vcf)</option></select>' +
        '<p style="font-size:var(--extui-text-caption-size,13.5px);line-height:var(--extui-line-normal,1.5);color:var(--extui-text-dim);margin-top:12px;">O WhatsApp Web precisa estar aberto em outra aba e totalmente carregado.</p>';
        confirmBtn.addEventListener("click", async function () {
          var prefix = document.getElementById("extuiCrmExportPrefix").value.trim();
          var limit = parseInt(document.getElementById("extuiCrmExportLimit").value, 10) || 0;
          var format = document.getElementById("extuiCrmExportFormat").value;
          confirmBtn.disabled = true;
          confirmBtn.textContent = "Exportando...";
          try {
            var result = await window.__extDashboardShell.sendToWhatsAppTab("EXTUI_EXPORT_CONTACTS", { prefix: prefix, limit: limit, format: format }, 25000);
            close();
            toast((result && result.count || 0) + " contato(s) exportado(s).");
          } catch (error) {
            close();
            toast("Falha ao exportar: " + (error && error.message ? error.message : String(error)), true);
          }
        });
      }
    });
  }

  function openModal(opts) {
    var previousFocus = document.activeElement;
    var overlay = el("div", { class: "extui-modal-overlay extuiCrmModalOverlay" });
    var modal = el("div", { class: "extui-modal extuiCrmModal", role: "dialog", "aria-modal": "true", tabindex: "-1" });
    var titleId = "extui-modal-title-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
    var title = el("h3", { id: titleId, text: opts.title });
    modal.setAttribute("aria-labelledby", titleId);
    modal.appendChild(title);
    var body = el("div", {});
    modal.appendChild(body);
    var actions = el("div", { class: "extui-modal__actions" });
    var cancelBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: opts.cancelLabel || "Cancelar" });
    var confirmBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: opts.confirmLabel || "Salvar" });
    actions.appendChild(cancelBtn);
    actions.appendChild(confirmBtn);
    modal.appendChild(actions);
    overlay.appendChild(modal);
    var closed = false;
    function close() {
      if (closed) return;
      closed = true;
      document.removeEventListener("keydown", onKeyDown, true);
      overlay.remove();
      if (previousFocus && previousFocus.isConnected && typeof previousFocus.focus === "function") {
        try { previousFocus.focus({ preventScroll: true }); } catch (_) { previousFocus.focus(); }
      }
    }
    function focusables() {
      return Array.from(modal.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')).filter(function (node) { return !node.hidden && node.getClientRects().length; });
    }
    function onKeyDown(event) {
      if (event.key === "Escape") { event.preventDefault(); close(); return; }
      if (event.key !== "Tab") return;
      var nodes = focusables();
      if (!nodes.length) { event.preventDefault(); modal.focus(); return; }
      var first = nodes[0], last = nodes[nodes.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    cancelBtn.addEventListener("click", close);
    overlay.addEventListener("click", function (event) { if (event.target === overlay) close(); });
    document.addEventListener("keydown", onKeyDown, true);
    document.body.appendChild(overlay);
    opts.render(body, close, confirmBtn);
    var firstInput = body.querySelector("input:not([disabled]),textarea:not([disabled]),select:not([disabled]),button:not([disabled])");
    if (firstInput) firstInput.focus(); else modal.focus();
    return overlay;
  }

                                                                        
  function renderColorPicker(initialColor, onChange) {
    var chosen = initialColor || COLOR_PALETTE[0];
    var wrap = el("div", { class: "extui-modal__colors extuiHybridColorPicker", role: "radiogroup", "aria-label": "Cor de identificação" });
    var presets = el("div", { class: "extuiHybridColorPickerPresets" });
    var controls = el("div", { class: "extuiHybridColorPickerControls" });
    var nativeInput = el("input", { type: "color", class: "extuiHybridColorNative", value: chosen, "aria-label": "Escolher outra cor" });
    var customBtn = el("button", { type: "button", class: "extuiHybridColorCustomBtn", "aria-label": "Escolher outra cor", title: "Escolher outra cor" });
    var customSwatch = el("span", { class: "extuiHybridColorCustomSwatch", "aria-hidden": "true" });
    customBtn.appendChild(customSwatch);
    customBtn.appendChild(el("span", { class: "extuiHybridColorCustomText", text: "Outra cor" }));
    customBtn.appendChild(el("span", { class: "extuiHybridColorCustomIcon", text: "⌾", "aria-hidden": "true" }));
    function syncCustomState(activePreset) {
      customSwatch.style.background = chosen;
      customBtn.style.setProperty("--extui-custom-color", chosen);
      var isPreset = COLOR_PALETTE.indexOf(chosen) >= 0;
      customBtn.classList.toggle("is-selected", !activePreset && !isPreset);
      customBtn.classList.toggle("is-preset", !!isPreset);
      nativeInput.value = chosen;
    }
    function activate(sw, c) {
      chosen = c;
      wrap.querySelectorAll(".extui-modal__color").forEach(function (x) { x.classList.remove("selected"); x.setAttribute("aria-checked", "false"); x.setAttribute("tabindex", "-1"); });
      if (sw) {
        sw.classList.add("selected");
        sw.setAttribute("aria-checked", "true");
        sw.setAttribute("tabindex", "0");
      }
      syncCustomState(sw);
      onChange(c);
    }
    COLOR_PALETTE.forEach(function (c) {
      var selected = c === chosen;
      var sw = el("div", { class: "extui-modal__color extuiHybridColorPreset" + (selected ? " selected" : ""), style: "background:" + c, role: "radio", "aria-label": "Cor " + c, "aria-checked": selected ? "true" : "false", tabindex: selected ? "0" : "-1" });
      sw.addEventListener("click", function () { activate(sw, c); });
      sw.addEventListener("keydown", function (event) {
        if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(sw, c); return; }
        if (event.key !== "ArrowLeft" && event.key !== "ArrowRight" && event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
        event.preventDefault();
        var items = Array.prototype.slice.call(presets.querySelectorAll(".extui-modal__color"));
        var current = items.indexOf(sw);
        var delta = event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 1;
        var next = items[(current + delta + items.length) % items.length];
        if (next) { next.focus(); next.click(); }
      });
      presets.appendChild(sw);
    });
    customBtn.addEventListener("click", function () { nativeInput.click(); });
    nativeInput.addEventListener("input", function () { activate(null, nativeInput.value); });
    nativeInput.addEventListener("change", function () { activate(null, nativeInput.value); });
    controls.appendChild(customBtn);
    controls.appendChild(nativeInput);
    wrap.appendChild(presets);
    wrap.appendChild(controls);
    syncCustomState(presets.querySelector('.selected'));
    return wrap;
  }


  function openEditCrmModal(crm) {
    if (!crm) return;
    var chosenColor = crm.hexColor || COLOR_PALETTE[0];
    openModal({
      title: "Editar CRM",
      confirmLabel: "Salvar alterações",
      render: function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", placeholder: "Nome do CRM", maxlength: "40" }); nameInput.value = crm.name || ""; body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Descrição" }));
        var descInput = el("textarea", { placeholder: "Explique a finalidade deste CRM", maxlength: "180", rows: "4" }); descInput.value = crm.description || ""; body.appendChild(descInput);
        body.appendChild(el("label", { text: "Cor de identificação" }));
        body.appendChild(renderColorPicker(chosenColor, function (c) { chosenColor = c; }));
        body.appendChild(el("p", { class: "extuiCrmModalHint", text: "A cor identifica este CRM nos cards e seletores. Listas e contatos não são alterados." }));
        confirmBtn.addEventListener("click", function () {
          var name = nameInput.value.trim(); if (!name) { nameInput.focus(); return; }
          mutate(function (state) {
            var target = state.crmList.find(function (item) { return item.id === crm.id; }); if (!target) return;
            target.name = name; target.description = descInput.value.trim(); target.hexColor = chosenColor; touchCrm(target);
          });
          toast("CRM atualizado com sucesso."); close();
        });
      }
    });
  }

  function buildCrmStructureDuplicate(crm, values) {
    if (!crm) return null;
    var now = Date.now();
    return {
      id: uid(),
      name: String(values && values.name || (crm.name || "CRM") + " — Cópia").trim(),
      description: String(values && values.description != null ? values.description : (crm.description || "")).trim(),
      hexColor: String(values && values.color || crm.hexColor || COLOR_PALETTE[0]),
      columns: (Array.isArray(crm.columns) ? crm.columns : []).map(function (column) {
        return Object.assign({}, column, { id: uid(), items: [] });
      }),
      createdAtInMs: now,
      updatedAtInMs: now,
      pinned: false,
      pinnedAtInMs: 0,
      archivedAtInMs: 0
    };
  }

  function openDuplicateCrmModal(crm) {
    if (!crm) return;
    var chosenColor = crm.hexColor || COLOR_PALETTE[0];
    openModal({
      title: "Duplicar CRM",
      confirmLabel: "Criar cópia",
      render: function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", placeholder: "Nome do novo CRM", maxlength: "40" });
        nameInput.value = (crm.name || "CRM") + " — Cópia";
        body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Descrição" }));
        var descInput = el("textarea", { placeholder: "Explique a finalidade deste CRM", maxlength: "180", rows: "4" });
        descInput.value = crm.description || "";
        body.appendChild(descInput);
        body.appendChild(el("label", { text: "Cor de identificação" }));
        body.appendChild(renderColorPicker(chosenColor, function (color) { chosenColor = color; }));
        body.appendChild(el("p", { class: "extuiCrmModalHint", text: "As listas e configurações visuais são copiadas. Os contatos permanecem somente no CRM original." }));
        confirmBtn.addEventListener("click", function () {
          var name = nameInput.value.trim();
          if (!name) { nameInput.focus(); return; }
          var duplicate = buildCrmStructureDuplicate(crm, { name: name, description: descInput.value.trim(), color: chosenColor });
          if (!duplicate) return;
          mutate(function (state) { state.crmList.push(duplicate); state.selectedCrmId = duplicate.id; });
          toast('CRM duplicado como "' + duplicate.name + '".');
          close();
        });
      }
    });
  }

  function setCrmArchived(crm, archived) {
    if (!crm) return Promise.resolve();
    return mutate(function (state) {
      var target = state.crmList.find(function (item) { return item.id === crm.id; }); if (!target) return;
      target.archivedAtInMs = archived ? Date.now() : 0;
      if (archived) { target.pinned = false; target.pinnedAtInMs = 0; }
      touchCrm(target);
      var active = state.crmList.filter(function (item) { return !Number(item.archivedAtInMs || 0); });
      if (archived && state.selectedCrmId === target.id) state.selectedCrmId = active[0] ? active[0].id : "";
      if (!archived) state.selectedCrmId = target.id;
    });
  }
  function toggleCrmPin(crm) {
    if (!crm || isCrmArchived(crm)) return;
    mutate(function (state) {
      var target = state.crmList.find(function (item) { return item.id === crm.id; }); if (!target) return;
      target.pinned = !target.pinned; target.pinnedAtInMs = target.pinned ? Date.now() : 0;
    });
  }
  function deleteCrmPermanently(crm) {
    return mutate(function (state) {
      state.crmList = state.crmList.filter(function (item) { return item.id !== crm.id; });
      var active = state.crmList.filter(function (item) { return !Number(item.archivedAtInMs || 0); });
      if (state.selectedCrmId === crm.id) state.selectedCrmId = active[0] ? active[0].id : "";
    });
  }
  function openCrmDeleteDialog(crm) {
    if (!crm) return;
    var previousFocus = document.activeElement;
    var overlay = el("div", { class: "extui-modal-overlay extuiCrmModalOverlay" });
    var modal = el("div", { class: "extui-modal extuiCrmDeleteModal", role: "dialog", "aria-modal": "true", tabindex: "-1" });
    var titleId = "extui-crm-delete-title-" + Date.now();
    modal.setAttribute("aria-labelledby", titleId);
    modal.appendChild(el("h3", { id: titleId, text: "Excluir CRM?" }));
    modal.appendChild(el("p", { class: "extuiCrmDeleteLead", text: 'Você está prestes a excluir definitivamente “' + (crm.name || "CRM") + '”. Listas, contatos e configurações deste CRM serão removidos.' }));
    var advice = el("div", { class: "extuiCrmDeleteAdvice" }, [
      icon("archive"),
      el("div", {}, [el("strong", { text: "Antes de excluir" }), el("span", { text: "Recomendamos arquivar o CRM se ele apenas não estiver mais em uso, ou criar uma cópia de segurança antes da exclusão definitiva." })])
    ]); modal.appendChild(advice);
    var actions = el("div", { class: "extuiCrmDeleteActions" });
    var cancel = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Cancelar" });
    var backup = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Criar cópia de segurança" });
    var archive = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: isCrmArchived(crm) ? "Manter arquivado" : "Arquivar em vez disso" });
    var trash = el("button", { class: "extui-btn extui-btn--primary", type: "button", text: "Enviar para a Lixeira" });
    var remove = el("button", { class: "extui-btn extui-btn--danger", type: "button", text: "Excluir definitivamente" });
    var closed = false;
    function close(){
      if (closed) return;
      closed = true;
      document.removeEventListener("keydown", onKeyDown, true);
      overlay.remove();
      if (previousFocus && previousFocus.isConnected && typeof previousFocus.focus === "function") {
        try { previousFocus.focus({ preventScroll: true }); } catch (_) { previousFocus.focus(); }
      }
    }
    function focusables(){
      return Array.from(modal.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')).filter(function(node){ return !node.hidden && node.getClientRects().length; });
    }
    function onKeyDown(event){
      if (event.key === "Escape") { event.preventDefault(); close(); return; }
      if (event.key !== "Tab") return;
      var nodes = focusables();
      if (!nodes.length) { event.preventDefault(); modal.focus(); return; }
      var first = nodes[0], last = nodes[nodes.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    cancel.addEventListener("click", close);
    backup.addEventListener("click", function(){ close(); if (window.__extDashboardShell) window.__extDashboardShell.showSection("backup"); });
    archive.addEventListener("click", async function(){ if (!isCrmArchived(crm)) { crmView = "hub"; await setCrmArchived(crm, true); toast("CRM arquivado. Você pode restaurá-lo quando quiser."); } close(); });
    trash.addEventListener("click", async function(){ if(!window.__extTrashService){toast("A Lixeira ainda está carregando. Tente novamente.",true);return;} trash.disabled=true;try{await window.__extTrashService.add({type:"crm",label:crm.name||"CRM",payload:{item:crm}});crmView="hub";await deleteCrmPermanently(crm);close();toast("CRM enviado para a Lixeira.");}catch(e){toast(e&&e.message?e.message:"Não foi possível enviar para a Lixeira.",true);trash.disabled=false;} });
    remove.addEventListener("click", async function(){ remove.disabled = true; crmView = "hub"; await deleteCrmPermanently(crm); close(); toast("CRM excluído definitivamente."); });
    actions.appendChild(cancel); actions.appendChild(backup); actions.appendChild(archive); actions.appendChild(trash); actions.appendChild(remove); modal.appendChild(actions);
    overlay.appendChild(modal);
    overlay.addEventListener("click", function(event){ if(event.target===overlay) close(); });
    document.addEventListener("keydown", onKeyDown, true);
    document.body.appendChild(overlay);
    cancel.focus();
  }

                                                                        
  function closeAllMenus() {
    document.querySelectorAll(".extui-col__menu.open, .extui-boardsel__menu.open").forEach(function (m) { m.classList.remove("open"); });
  }
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".extui-col__menu-wrap") && !e.target.closest(".extui-boardsel")) closeAllMenus();
  });

                                                                        
  function renderBoardSelector() {
    var sel = getSelectedCrm();
    var totalContacts = sel ? sel.columns.reduce(function (sum, c) { return sum + c.items.length; }, 0) : 0;
    var wrap = el("div", { class: "extui-boardsel" });
    var btn = el("button", { class: "extui-boardsel__btn", "aria-haspopup": "true" }, [
      el("span", { class: "extui-boardsel__dot", style: "background:" + (sel ? sel.hexColor : "#888") }),
      el("span", { class: "extui-boardsel__name", text: sel ? sel.name : "Nenhum CRM" }),
      sel ? el("span", { class: "extuiBadge", text: totalContacts + (totalContacts === 1 ? " contato" : " contatos") }) : null,
      icon("chevronDown", "extui-boardsel__caret")
    ]);
    var menu = el("div", { class: "extui-boardsel__menu" });
    menu.appendChild(el("div", { class: "extui-boardsel__label", text: "Seus CRMs" }));
    var activeCrms = getActiveCrms();
    if (activeCrms.length === 0) {
      menu.appendChild(el("div", { class: "extui-boardsel__label", text: "Nenhum CRM ativo." }));
    }
    activeCrms.forEach(function (c) {
      var item = el("div", { class: "extui-boardsel__item" + (c.id === S.selectedCrmId ? " active" : "") }, [
        el("span", { class: "extui-boardsel__dot", style: "background:" + c.hexColor }),
        el("span", { class: "name", text: c.name }),
        c.id === S.selectedCrmId ? icon("check", "extui-boardsel__check") : null,
        el("button", { class: "extui-icon-btn", title: "Editar CRM", "aria-label": "Editar CRM " + c.name, onclick: function (e) { e.stopPropagation(); closeAllMenus(); openEditCrmModal(c); } }, [icon("edit")]),
        el("button", { class: "extui-icon-btn", title: "Excluir CRM", "aria-label": "Excluir CRM " + c.name, onclick: function (e) { e.stopPropagation(); closeAllMenus(); openCrmDeleteDialog(c); } }, [icon("trash")])
      ]);
      item.addEventListener("click", function () {
        boardFilterTerm = "";                                                              
        if (crmView === "hub") crmView = "kanban";
        mutate(function (s) { s.selectedCrmId = c.id; });
        closeAllMenus();
      });
      menu.appendChild(item);
    });
    menu.appendChild(el("div", { class: "extui-boardsel__sep" }));
    var createRow = el("div", { class: "extui-boardsel__create", text: "+ Criar novo CRM" });
    createRow.addEventListener("click", function () {
      closeAllMenus();
      openCreateCrmModal();
    });
    menu.appendChild(createRow);

    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var willOpen = !menu.classList.contains("open");
      closeAllMenus();
      if (willOpen) menu.classList.add("open");
    });
    wrap.appendChild(btn);
    wrap.appendChild(menu);
    return wrap;
  }

  function openCreateCrmModal() {
    var chosenColor = COLOR_PALETTE[0];
    openModal({
      title: "Criar novo CRM",
      confirmLabel: "Criar",
      render: function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", placeholder: "Nome do CRM", maxlength: "40" });
        body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Descrição" }));
        var descInput = el("textarea", { placeholder: "Descrição (opcional)", maxlength: "120" });
        body.appendChild(descInput);
        body.appendChild(el("label", { text: "Cor" }));
        body.appendChild(renderColorPicker(chosenColor, function (c) { chosenColor = c; }));
        confirmBtn.addEventListener("click", function () {
          var name = nameInput.value.trim();
          if (!name) { nameInput.focus(); return; }
          var now = Date.now();
          var newCrm = { id: uid(), name: name, description: descInput.value.trim(), hexColor: chosenColor, columns: [], createdAtInMs: now, updatedAtInMs: now, pinned: false, pinnedAtInMs: 0, archivedAtInMs: 0 };
          mutate(function (s) { s.crmList.push(newCrm); s.selectedCrmId = newCrm.id; });
          toast('CRM "' + name + '" criado com sucesso.');
          close();
        });
      }
    });
  }

                                                                        
  var waContacts = null;                                                                       
  var waContactsLoading = false;
  var waContactsError = false;
  var waSearchTerm = "";
  var contactsPanelVisible = true;
  var draggedContact = null;                               
  var rootEl = null;
  var renderGeneration = 0;
  var kanbanResizeObserver = null;
  var activeProfile = null;
  var boardFilterTerm = "";
                                                                           
                                                                           
                                                                    
                                                               
  var crmView = "hub";
  var crmRouteIntentConsumed = false;
  function consumeCrmRouteIntent() {
    if (crmRouteIntentConsumed) return null;
    crmRouteIntentConsumed = true;
    var params = new URLSearchParams(location.search);
    var intent = {
      crmId: params.get("crmId") || "",
      crmView: params.get("crmView") || "",
      crmCreate: params.get("crmCreate") === "1",
      crmContactId: params.get("crmContactId") || "",
      crmCopilot: params.get("crmCopilot") === "1",
      crmProfileTab: params.get("crmProfileTab") || ""
    };
    params.delete("crmId");
    params.delete("crmView");
    params.delete("crmCreate");
    params.delete("crmContactId");
    params.delete("crmCopilot");
    params.delete("crmProfileTab");
    var cleaned = params.toString();
    try { history.replaceState(null, "", location.pathname + (cleaned ? "?" + cleaned : "") + location.hash); } catch (_) {}
    return intent;
  }
  var crmExpanded = false;
  var crmHubSort = "recent";
  var lastRenderedView = null;
  var lastRenderedCrmId = null;
  var crmFilters = { columnId: "", task: "all", followUp: "all", value: "all" };

  function loadWaContacts() {
    if (waContactsLoading) return;
    waContactsLoading = true;
                                                                         
                                                                        
                                                                       
                                                                        
                                                              
    var isRefresh = waContacts != null;
    if (!isRefresh) waContactsError = false;
    renderContactsPanelOnly();
    fetchWhatsAppContacts().then(function (contacts) {
      waContactsLoading = false;
      if (contacts == null) {
        waContactsError = true;
        if (!isRefresh) waContacts = null;
        else toast("Não foi possível atualizar os contatos. Mantendo a última lista carregada.", true);
      } else {
        waContacts = contacts;
        waContactsError = false;
      }
      renderContactsPanelOnly();
    });
  }

  function renderContactsPanelOnly() {
    if (!rootEl) return;
    var host = rootEl.querySelector("#extui-contacts-panel");
    if (!host) return;
    host.replaceWith(renderContactsPanel());
  }

                                                                          
                                                                           
                                                                     
                                                 
  function renderContactsList() {
    var listWrap = el("div", { class: "extui-contacts__list" });

                                                                            
                                                                          
                                                                       
                                                                                       
                                                                  
    if (waContactsLoading && waContacts == null) {
      listWrap.appendChild(renderContactsEmptyState("refresh", "Carregando contatos...", "Buscando sua lista direto do WhatsApp Web."));
    } else if (waContacts == null && waContactsError) {
      var errState = renderContactsEmptyState("users", "Não foi possível ler os contatos", "Abra o WhatsApp Web em outra aba (logado) e tente de novo.");
      var retryBtn = el("button", { class: "extui-btn extui-btn--primary extui-btn--block", text: "Tentar de novo" });
      retryBtn.addEventListener("click", function () { loadWaContacts(); });
      errState.appendChild(retryBtn);
      listWrap.appendChild(errState);
    } else if (waContacts == null) {
      var startState = renderContactsEmptyState("users", "Importar contatos", "Traga seus contatos do WhatsApp pra arrastar direto nas listas.");
      var startBtn = el("button", { class: "extui-btn extui-btn--primary extui-btn--block", text: "Importar contatos" });
      startBtn.addEventListener("click", function () { loadWaContacts(); });
      startState.appendChild(startBtn);
      listWrap.appendChild(startState);
    } else if (waContacts.length === 0) {
      listWrap.appendChild(renderContactsEmptyState("users", "Nenhum contato encontrado", ""));
    } else {
      var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
      var normalizeSearch = formHelpers ? formHelpers.normalizeSearch : function (value) { return String(value || "").trim().toLowerCase(); };
      var f = normalizeSearch(waSearchTerm);
      var filtered = waContacts.filter(function (c) {
        return !f || normalizeSearch(c && c.name).indexOf(f) >= 0 || normalizeSearch(c && c.phoneNumber).indexOf(f) >= 0;
      });
      if (filtered.length === 0) {
        listWrap.appendChild(renderContactsEmptyState("search", "Nenhum resultado", "Tente outro nome ou número."));
      }
      filtered.forEach(function (c) {
        var canDragContact = !!String(c && c.phoneNumber || "").replace(/\D/g, "");
        var row = el("div", { class: "extui-contacts__row", draggable: canDragContact ? "true" : "false", title: canDragContact ? "Arraste para uma lista do CRM" : "Telefone indisponível para este contato" });
        row.appendChild(renderAvatarEl(c, "extui-avatar--sm"));
        var info = el("div", { class: "extui-contacts__info" });
        info.appendChild(contactNameNode(c, "extui-contacts__name"));
        info.appendChild(el("div", { class: "extui-contacts__phone" + (c.phoneNumber ? "" : " extui-muted-null"), text: displayPhone(c.phoneNumber) }));
        row.appendChild(info);
        row.addEventListener("dragstart", function (e) {
          if (!canDragContact) { e.preventDefault(); return; }
          draggedContact = c;
          row.classList.add("dragging");
          e.dataTransfer.effectAllowed = "copy";
        });
        row.addEventListener("dragend", function () { row.classList.remove("dragging"); draggedContact = null; });
        listWrap.appendChild(row);
      });
    }
    return listWrap;
  }

                                                                          
                                                               
  function renderContactsEmptyState(iconName, title, hint) {
    return el("div", { class: "extui-contacts__empty" }, [
      icon(iconName, "extui-contacts__empty-icon"),
      el("div", { class: "extui-contacts__empty-title", text: title }),
      hint ? el("div", { class: "extui-contacts__empty-hint", text: hint }) : null
    ]);
  }

  function renderContactsPanel() {
    var panel = el("div", { id: "extui-contacts-panel", class: "extui-contacts" });
                                                                        
                                                                        
                                                                            
                                                          
    var refreshBtn = el("button", { class: "extui-icon-btn" + (waContactsLoading ? " extui-spinning" : ""), title: "Atualizar contatos", "aria-label": "Atualizar contatos do WhatsApp", onclick: function () { loadWaContacts(); } }, [icon("refresh")]);
    if (waContactsLoading) refreshBtn.disabled = true;
    var titleWrap = el("div", { class: "extui-contacts__titlewrap" }, [
      el("span", { class: "extui-contacts__title", text: "Contatos do WhatsApp" }),
      Array.isArray(waContacts) ? el("span", { class: "extuiBadge", text: String(waContacts.length) }) : null
    ]);
    var header = el("div", { class: "extui-contacts__header" }, [titleWrap, refreshBtn]);
    panel.appendChild(header);

                                                                           
                                                                        
                                                                       
    if (waContacts != null) {
      var searchWrap = el("div", { class: "extuiSearch extui-contacts__search" }, [icon("search")]);
      var searchInput = el("input", { type: "text", placeholder: "Buscar contato...", "aria-label": "Buscar contato do WhatsApp" });
      searchInput.value = waSearchTerm;
      searchInput.addEventListener("input", function () {
        waSearchTerm = searchInput.value;
        var oldList = panel.querySelector(".extui-contacts__list");
        var newList = renderContactsList();
        if (oldList) oldList.replaceWith(newList); else panel.appendChild(newList);
      });
      searchWrap.appendChild(searchInput);
      panel.appendChild(searchWrap);
    }

    panel.appendChild(renderContactsList());
    return panel;
  }

                                                                         
  var draggedCard = null;                      
  var draggedColumn = null;            

  function computeDropIndex(itemsWrap, clientY) {
    var cards = Array.prototype.slice.call(itemsWrap.querySelectorAll(".extui-card"));
    for (var i = 0; i < cards.length; i++) {
      var box = cards[i].getBoundingClientRect();
      if (clientY < box.top + box.height / 2) return i;
    }
    return cards.length;
  }

  function renderColumn(col) {
    var wrap = el("div", { class: "extui-col", "data-col-id": col.id });

                                                                                
                                                                  
    wrap.addEventListener("dragover", function (e) {
      if (draggedColumn && draggedColumn !== col.id) e.preventDefault();
    });
    wrap.addEventListener("drop", function (e) {
      if (!draggedColumn || draggedColumn === col.id) return;
      e.preventDefault();
      mutate(function (s) {
        var crm = getSelectedCrm(); if (!crm) return;
        var from = crm.columns.findIndex(function (c) { return c.id === draggedColumn; });
        var to = crm.columns.findIndex(function (c) { return c.id === col.id; });
        if (from < 0 || to < 0) return;
        var moved = crm.columns.splice(from, 1)[0];
        crm.columns.splice(to, 0, moved);
      });
      draggedColumn = null;
    });

    var colColor = col.color || hashColor(col.id);
    var header = el("div", { class: "extui-col__header", draggable: "true", style: "border-top-color:" + colColor });
    header.addEventListener("dragstart", function (e) {
      draggedColumn = col.id;
      e.dataTransfer.effectAllowed = "move";
    });
    header.appendChild(el("span", { class: "extui-col__dot", style: "background:" + colColor }));
    var crmForColumn = getSelectedCrm();
    var columnMetrics = crmColumnMetrics(crmForColumn, col);
    var columnIdentity = el("div", { class: "extui-col__identity" }, [el("span", { class: "extui-col__title", text: col.title, title: col.title }), el("span", { class: "extui-col__value", text: crmCurrency(columnMetrics.value) })]);
    header.appendChild(columnIdentity);
    var countWrap = el("div", { class: "extui-col__metrics" }, [el("span", { class: "extuiBadge extui-col__count", text: String(col.items.length), title: col.items.length + " contato(s)" })]);
    if (columnMetrics.overdueTasks) countWrap.appendChild(el("span", { class: "extui-col__risk", text: String(columnMetrics.overdueTasks), title: columnMetrics.overdueTasks + " tarefa(s) atrasada(s)" }));
    header.appendChild(countWrap);
    var menuWrap = el("div", { class: "extui-col__menu-wrap" });
    var menuBtn = el("button", { class: "extui-icon-btn", title: "Mais opções", "aria-label": "Mais opções da lista " + col.title, "aria-haspopup": "true" }, [icon("more")]);
    var menu = el("div", { class: "extui-col__menu" });
    var renameItem = el("div", { class: "extui-col__menu-item", text: "Editar" });
    renameItem.addEventListener("click", function () { closeAllMenus(); openEditColumnModal(col); });
    var delItem = el("div", { class: "extui-col__menu-item danger", text: "Remover lista" });
    delItem.addEventListener("click", async function () {
      closeAllMenus();
      if (!await extConfirm('Remover a lista "' + col.title + '" e todos os seus contatos?', { danger: true })) return;
      mutate(function (s) {
        var crm = getSelectedCrm(); if (!crm) return;
        crm.columns = crm.columns.filter(function (c) { return c.id !== col.id; });
      });
      toast("Lista removida com sucesso.");
    });
    menu.appendChild(renameItem);
    menu.appendChild(delItem);
    menuBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      var willOpen = !menu.classList.contains("open");
      closeAllMenus();
      if (willOpen) menu.classList.add("open");
    });
    menuWrap.appendChild(menuBtn);
    menuWrap.appendChild(menu);
    header.appendChild(menuWrap);
    wrap.appendChild(header);

    var itemsWrap = el("div", { class: "extui-col__items" });
    itemsWrap.addEventListener("dragover", function (e) { if (draggedCard || draggedContact) { e.preventDefault(); e.stopPropagation(); wrap.classList.add("dragover"); } });
    itemsWrap.addEventListener("dragleave", function () { wrap.classList.remove("dragover"); });
    itemsWrap.addEventListener("drop", function (e) {
      wrap.classList.remove("dragover");
      if (boardFilterTerm.trim() || crmFilters.columnId || crmFilters.task !== "all" || crmFilters.followUp !== "all" || crmFilters.value !== "all") { toast("Limpe a busca e os filtros antes de reorganizar os cards.", true); return; }
      if (draggedContact) {
        e.preventDefault();
        e.stopPropagation();
        var contact = draggedContact;
        draggedContact = null;
        if (!contact || !String(contact.phoneNumber || "").replace(/\D/g, "")) { toast("Não foi possível identificar o telefone deste contato no WhatsApp.", true); return; }
        var crmNow = getSelectedCrm();
        var toColNow = crmNow && crmNow.columns.find(function (c) { return c.id === col.id; });
        var existingNow = findPhoneMembershipInCrm(crmNow, contact.phoneNumber);
        if (existingNow && toColNow && existingNow.column.id === toColNow.id) {
          toast("Esse contato já está nessa etapa.", true);
          return;
        }
        var dropIndex2 = computeDropIndex(itemsWrap, e.clientY);
        var importedMoveEvent = null;
        var importedMoveMeta = null;
        mutate(function (s) {
          var crm = getSelectedCrm(); if (!crm) return;
          var toCol = crm.columns.find(function (c) { return c.id === col.id; });
          if (!toCol) return;
          var existing = findPhoneMembershipInCrm(crm, contact.phoneNumber);
          var item;
          if (existing) {
            if (existing.column.id === toCol.id) return;
            item = existing.column.items.splice(existing.index, 1)[0];
            if (item && item.contact) {
              if ((!item.contact.name || item.contact.name === item.contact.phoneNumber) && contact.name) item.contact.name = contact.name;
              if (contact.avatar) item.contact.avatar = contact.avatar;
            }
            importedMoveMeta = { fromTitle: existing.column.title, fromId: existing.column.id, toTitle: toCol.title, toId: toCol.id };
          } else {
            item = { id: uid(), contact: { name: contact.name, phoneNumber: contact.phoneNumber, avatar: contact.avatar || null }, createdBy: "whatsapp import", createdAtInMs: Date.now() };
          }
          var insertAt2 = dropIndex2;
          if (insertAt2 < 0) insertAt2 = 0;
          if (insertAt2 > toCol.items.length) insertAt2 = toCol.items.length;
          toCol.items.splice(insertAt2, 0, item);
          if (importedMoveMeta) {
            pushColumnEvent(crm.id, toCol.id, item.id);
            importedMoveEvent = { type: "event.add", crmContactId: item.id, event: { type: "column_moved", title: "Etapa alterada", description: importedMoveMeta.fromTitle + " → " + importedMoveMeta.toTitle, metadata: { fromColumnId: importedMoveMeta.fromId, toColumnId: importedMoveMeta.toId } } };
          }
        }).then(function () {
          if (importedMoveEvent) runProfessionalOperation(importedMoveEvent).catch(function (error) { });
          if (importedMoveMeta) toast("Contato movido para " + importedMoveMeta.toTitle + ".");
        });
        return;
      }
      if (!draggedCard) return;
      e.preventDefault();
      e.stopPropagation();
      var dropIndex = computeDropIndex(itemsWrap, e.clientY);
      var moveEvent = null, moveUndo = null;
      mutate(function (s) {
        var crm = getSelectedCrm(); if (!crm) return;
        var fromCol = crm.columns.find(function (c) { return c.id === draggedCard.columnId; });
        var toCol = crm.columns.find(function (c) { return c.id === col.id; });
        if (!fromCol || !toCol) return;
        var idx = fromCol.items.findIndex(function (it) { return it.id === draggedCard.itemId; });
        if (idx < 0) return;
        if (fromCol !== toCol && toCol.items.some(function (it) { return it.id === draggedCard.itemId; })) return;
        var item = fromCol.items.splice(idx, 1)[0];
        var insertAt = dropIndex;
        if (fromCol === toCol && idx < dropIndex) insertAt -= 1;
        if (insertAt < 0) insertAt = 0;
        if (insertAt > toCol.items.length) insertAt = toCol.items.length;
        toCol.items.splice(insertAt, 0, item);
        if (fromCol !== toCol) {
          pushColumnEvent(crm.id, toCol.id, item.id);
          moveEvent = { type: "event.add", crmContactId: item.id, event: { type: "column_moved", title: "Etapa alterada", description: fromCol.title + " → " + toCol.title, metadata: { fromColumnId: fromCol.id, toColumnId: toCol.id } } };
          moveUndo = { crmId: crm.id, itemId: item.id, fromColumnId: fromCol.id, toColumnId: toCol.id, fromTitle: fromCol.title, toTitle: toCol.title, fromIndex: idx };
        }
      }).then(function () { if (moveEvent) runProfessionalOperation(moveEvent).catch(function (error) { }); if (moveUndo) offerCrmMoveUndo(moveUndo); });
      draggedCard = null;
    });
    var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
    var normalizeSearch = formHelpers ? formHelpers.normalizeSearch : function (value) { return String(value || "").trim().toLowerCase(); };
    var term = normalizeSearch(boardFilterTerm);
    var visibleItems = col.items.filter(function (item) {
      var matchesTerm = !term || normalizeSearch(item && item.contact && item.contact.name).indexOf(term) >= 0 || normalizeSearch(item && item.contact && item.contact.phoneNumber).indexOf(term) >= 0;
      return matchesTerm && contactPassesFilters(col, item);
    });
    if (visibleItems.length === 0) {
      itemsWrap.appendChild(el("div", { class: "extui-col__empty", text: term ? "Nenhum contato bate com a busca." : "Arraste um contato até aqui." }));
    }
    visibleItems.forEach(function (item) { itemsWrap.appendChild(renderCard(col, item)); });
    wrap.appendChild(itemsWrap);

    wrap.appendChild(renderAddCardArea(col));
    return wrap;
  }

  function openDealValueEditor(col, item, trigger) {
    var membership = findContactMembership(item && item.id);
    if (!membership) return;
    var crm = membership.crm || getSelectedCrm();
    var currentValue = crmItemValue(crm, membership.item);
    openModal({
      title: "Valor da negociação",
      confirmLabel: "Salvar valor",
      render: function (body, close, confirmButton) {
        var hint = el("p", { class: "extui-modal__hint", text: "Defina o valor desta oportunidade. O Pipeline, Ticket Médio e análises usam este valor automaticamente." });
        var input = el("input", { type: "text", inputmode: "decimal", autocomplete: "off", "aria-label": "Valor da negociação", placeholder: "0,00" });
        input.value = currentValue ? String(currentValue.toFixed(2)).replace(".", ",") : "0,00";
        body.appendChild(hint);
        body.appendChild(el("label", { text: "Valor (R$)" }));
        body.appendChild(input);
        confirmButton.addEventListener("click", async function () {
          var current = findContactMembership(item && item.id);
          if (!current) { close(); return; }
          confirmButton.disabled = true;
          try {
            await mutate(function () { current.item.dealValue = crmNormalizeDealValue(input.value); });
            close();
            toast("Valor da negociação atualizado.");
            if (activeProfile && activeProfile.contactId === item.id) renderContactProfile(item.id, true);
          } catch (error) {
            confirmButton.disabled = false;
            toast(error && error.message ? error.message : "Não foi possível atualizar o valor.", true);
          }
        });
        input.addEventListener("keydown", function (event) {
          if (event.key === "Enter") { event.preventDefault(); confirmButton.click(); }
        });
        requestAnimationFrame(function () { input.select(); });
      }
    });
  }

  function renderCard(col, item) {
    var color = hashColor(item.contact.phoneNumber || item.contact.name);
    var card = el("div", { class: "extui-card", draggable: "true", tabindex: "0", "data-extui-academy-target": "crm-contact" });
    var _extuiDownX = 0, _extuiDownY = 0;
    card.addEventListener("mousedown", function (e) { _extuiDownX = e.clientX; _extuiDownY = e.clientY; });
    card.addEventListener("click", function (e) {
      if (e.target.closest(".extui-card__actions")) return;                                                     
      var dx = Math.abs(e.clientX - _extuiDownX), dy = Math.abs(e.clientY - _extuiDownY);
      if (dx < 5 && dy < 5) openContactDetailsModal(col, item);
    });
    card.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openContactDetailsModal(col, item); } });
    card.addEventListener("dragstart", function (e) {
      e.stopPropagation();
      draggedCard = { columnId: col.id, itemId: item.id };
      card.classList.add("dragging");
      e.dataTransfer.effectAllowed = "move";
    });
    card.addEventListener("dragend", function () { card.classList.remove("dragging"); });

    card.appendChild(el("div", { class: "extui-card__bar", style: "background:" + color }));
    var body = el("div", { class: "extui-card__body" });
    body.appendChild(renderAvatarEl(item.contact, "extui-avatar--card"));
    var info = el("div", { class: "extui-card__info" });
    info.appendChild(contactNameNode(item.contact, "extui-card__name"));
    info.appendChild(el("div", { class: "extui-card__phone" + (item.contact.phoneNumber ? "" : " extui-muted-null"), text: displayPhone(item.contact.phoneNumber) }));
    var crmForCard = getSelectedCrm();
    var cardValue = crmItemValue(crmForCard, item);
    var cardSummary = crmContactSummary(item);
    var valueButton = el("button", { type: "button", class: "extui-card__value", text: crmCurrency(cardValue), title: "Editar valor da negociação", "aria-label": "Editar valor da negociação de " + (item.contact.name || "contato") });
    valueButton.addEventListener("click", function (event) { event.preventDefault(); event.stopPropagation(); openDealValueEditor(col, item, valueButton); });
    valueButton.addEventListener("mousedown", function (event) { event.stopPropagation(); });
    valueButton.addEventListener("keydown", function (event) { event.stopPropagation(); });
    valueButton.addEventListener("dragstart", function (event) { event.preventDefault(); event.stopPropagation(); });
    info.appendChild(valueButton);
    if (cardSummary && cardSummary.nextTask) {
      var task = cardSummary.nextTask, taskOverdue = professionalCore && professionalCore.isTaskOverdue(task, Date.now());
      var taskText = (taskOverdue ? "Atrasada: " : "Tarefa: ") + String(task.title || "Próxima tarefa");
      info.appendChild(el("div", { class: "extui-card__task" + (taskOverdue ? " overdue" : ""), text: taskText, title: task.dueAtMs ? taskText + " · " + fmtOverviewWhen(task.dueAtMs) : taskText }));
    }
    if (cardSummary && cardSummary.noteCount) info.appendChild(el("div", { class: "extui-card__notes", text: cardSummary.noteCount + (cardSummary.noteCount === 1 ? " nota" : " notas") }));
    if (item.nextContactAtMs) {
      var isOverdue = item.nextContactAtMs < Date.now();
      var d2 = new Date(item.nextContactAtMs);
      var label = "Follow-up: " + String(d2.getDate()).padStart(2, "0") + "/" + String(d2.getMonth() + 1).padStart(2, "0");
      info.appendChild(el("div", { class: "extui-card__followup" + (isOverdue ? " overdue" : ""), text: label }));
    }
    body.appendChild(info);
    var actions = el("div", { class: "extui-card__actions" });
    var waBtn = el("button", { title: "Abrir no WhatsApp", "aria-label": "Abrir " + item.contact.name + " no WhatsApp" }, [icon("chat")]);
                                                                      
                                                                          
                                                                         
                                               
    waBtn.addEventListener("click", function () {
      if (!item.contact.phoneNumber) { toast("Este contato não tem um telefone resolvido. Edite o card e informe o número manualmente.", true); return; }
      openWhatsApp(item.contact.phoneNumber);
    });
    var fluxoBtn = el("button", { title: "Iniciar fluxo", "aria-label": "Iniciar fluxo com " + item.contact.name }, [icon("play")]);
    fluxoBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      if (!item.contact.phoneNumber) { toast("Este contato não tem um telefone resolvido. Edite o card e informe o número manualmente.", true); return; }
      openManualFlowPicker(item.contact.phoneNumber);
    });
    var taskBtn = el("button", { title: "Abrir tarefas", "aria-label": "Abrir tarefas de " + item.contact.name }, [icon("check")]);
    taskBtn.addEventListener("click", function (e) { e.stopPropagation(); renderContactProfile(item.id, false, false, "tasks"); });
    var delBtn = el("button", { class: "danger", title: "Remover", "aria-label": "Remover " + item.contact.name + " desta lista" }, [icon("trash")]);
                                                                            
                                                                      
                                         
    delBtn.addEventListener("click", async function () {
      if (!await extConfirm('Remover o contato "' + item.contact.name + '" desta lista?', { danger: true })) return;
      mutate(function (s) {
        var crm = getSelectedCrm(); if (!crm) return;
        var c = crm.columns.find(function (x) { return x.id === col.id; });
        if (c) c.items = c.items.filter(function (it) { return it.id !== item.id; });
      });
      toast("Contato removido.");
    });
    actions.appendChild(waBtn);
    actions.appendChild(fluxoBtn);
    actions.appendChild(taskBtn);
    var valueBtn = el("button", { title: "Editar valor", "aria-label": "Editar valor da negociação de " + item.contact.name }, [el("span", { text: "R$" })]);
    valueBtn.addEventListener("click", function (e) { e.stopPropagation(); openEditContactModal(item.id); });
    actions.appendChild(valueBtn);
    actions.appendChild(delBtn);
    info.appendChild(actions);
    card.appendChild(body);
    return card;
  }

  function renderAddCardArea(col) {
    var container = el("div", { class: "extui-col__footer" });
    var showForm = function () {
      container.innerHTML = "";
      var form = el("div", { class: "extui-addcard-form" });
      var hint = el("div", { class: "extui-addcard-form__or", text: "arraste um contato da lista à esquerda, ou digite manualmente" });
      var phoneInput = el("input", { type: "text", placeholder: "Número (com DDD)" });
      var nameInput = el("input", { type: "text", placeholder: "Nome (opcional)" });
      var row = el("div", { class: "extui-addcard-form__row" });
      var saveBtn = el("button", { class: "extui-btn extui-btn--primary", text: "Salvar" });
      var cancelBtn = el("button", { class: "extui-btn extui-btn--ghost", text: "Cancelar" });
      saveBtn.addEventListener("click", function () {
        var digits = phoneInput.value.replace(/\D/g, "");
        if (digits.length < 8) { toast("Número de telefone inválido", true); return; }
                                                                         
                                                                               
                                                                           
                                       
        var crmNow = getSelectedCrm();
        var colNow = crmNow && crmNow.columns.find(function (x) { return x.id === col.id; });
        var existingNow = findPhoneMembershipInCrm(crmNow, digits);
        if (existingNow && colNow && existingNow.column.id === colNow.id) { toast("Esse contato já está nessa etapa.", true); return; }
                                                                              
                                                                              
        var manualMoveMeta = null;
        mutate(function (s) {
          var crm = getSelectedCrm(); if (!crm) return;
          var c = crm.columns.find(function (x) { return x.id === col.id; });
          if (!c) return;
          var existing = findPhoneMembershipInCrm(crm, digits);
          var item;
          if (existing) {
            if (existing.column.id === c.id) return;
            item = existing.column.items.splice(existing.index, 1)[0];
            if (nameInput.value.trim()) item.contact.name = nameInput.value.trim();
            manualMoveMeta = { fromTitle: existing.column.title, fromId: existing.column.id, toTitle: c.title, toId: c.id, itemId: item.id, phone: digits };
          } else {
            item = { id: uid(), contact: { name: nameInput.value.trim() || digits, phoneNumber: digits }, createdBy: "manual entry", createdAtInMs: Date.now() };
          }
          c.items.push(item);
          if (manualMoveMeta) pushColumnEvent(crm.id, c.id, manualMoveMeta.itemId);
        }).then(function () {
          if (manualMoveMeta) {
            runProfessionalOperation({ type: "event.add", crmContactId: manualMoveMeta.itemId, event: { type: "column_moved", title: "Etapa alterada", description: manualMoveMeta.fromTitle + " → " + manualMoveMeta.toTitle, metadata: { fromColumnId: manualMoveMeta.fromId, toColumnId: manualMoveMeta.toId } } }).catch(function (error) { });
            toast("Contato movido para " + manualMoveMeta.toTitle + ".");
          }
        });
      });
      cancelBtn.addEventListener("click", function () { render(); });
      row.appendChild(saveBtn);
      row.appendChild(cancelBtn);
      form.appendChild(hint);
      form.appendChild(phoneInput);
      form.appendChild(nameInput);
      form.appendChild(row);
      container.appendChild(form);
    };
    var btn = el("button", { class: "extui-btn extui-btn--ghost extui-btn--block", text: "+ Adicionar" });
    btn.addEventListener("click", showForm);
    container.appendChild(btn);
    return container;
  }

  function openEditColumnModal(col) {
    var chosenColor = col.color || hashColor(col.id);
    openModal({
      title: "Editar lista",
      render: function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome da lista" }));
        var nameInput = el("input", { type: "text", value: col.title });
        nameInput.value = col.title;
        body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Descrição" }));
        var descInput = el("textarea", {});
        descInput.value = col.description || "";
        body.appendChild(descInput);
        body.appendChild(el("label", { text: "Cor" }));
        body.appendChild(renderColorPicker(chosenColor, function (c) { chosenColor = c; }));
        confirmBtn.addEventListener("click", function () {
          var name = nameInput.value.trim();
          if (!name) { nameInput.focus(); return; }
          mutate(function (s) {
            var crm = getSelectedCrm(); if (!crm) return;
            var c = crm.columns.find(function (x) { return x.id === col.id; });
            if (c) { c.title = name; c.description = descInput.value.trim(); c.color = chosenColor; }
          });
          close();
        });
      }
    });
  }

  function findContactMembership(contactId) {
    for (var i = 0; i < S.crmList.length; i++) {
      var crm = S.crmList[i];
      for (var j = 0; j < (crm.columns || []).length; j++) {
        var column = crm.columns[j];
        var found = (column.items || []).find(function (candidate) { return candidate.id === contactId; });
        if (found) return { crm: crm, column: column, item: found };
      }
    }
    return null;
  }

  function findPhoneMemberships(phoneNumber) {
    var phone = String(phoneNumber || "").replace(/\D/g, "");
    var out = [];
    if (!phone) return out;
    S.crmList.forEach(function (crm) {
      if (isCrmArchived(crm)) return;
      (crm.columns || []).forEach(function (column) {
        (column.items || []).forEach(function (item) {
          if (String(item && item.contact && item.contact.phoneNumber || "").replace(/\D/g, "") === phone) out.push({ crm: crm, column: column, item: item });
        });
      });
    });
    return out;
  }

  function localAuthor() { return "Usuário local"; }

  function closeContactProfile(preserveCopilotSession) {
    if (!activeProfile) return;
    var contactId = activeProfile.contactId;
    var previous = activeProfile.previousFocus;
    document.removeEventListener("keydown", activeProfile.keyHandler, true);
    activeProfile.layer.remove();
    activeProfile = null;
    if (!preserveCopilotSession && window.__extCrmAiCopilot) window.__extCrmAiCopilot.clear(contactId);
    if (previous && previous.isConnected) previous.focus();
  }

  async function saveProfileOperation(operation) {
    try {
      await runProfessionalOperation(operation);
      if (activeProfile) renderContactProfile(activeProfile.contactId, true, false, activeProfile.tab || "data");
      render();
    } catch (error) { toast(error.message || "Não foi possível salvar.", true); }
  }

  function profileSection(title, academyTarget) {
    return el("section", { class: "extuiCrmProfile__section", "data-extui-academy-target": academyTarget || "" }, [el("h3", { text: title })]);
  }

  function renderProfileField(definition, value, change) {
    var input;
    if (definition.type === "select") {
      input = el("select", { "aria-label": definition.label }, [el("option", { value: "", text: "Não informado" })]);
      definition.options.forEach(function (option) { input.appendChild(el("option", { value: option.id, text: option.label })); });
    } else if (definition.type === "boolean") {
      input = el("select", { "aria-label": definition.label }, [el("option", { value: "", text: "Não informado" }), el("option", { value: "true", text: "Sim" }), el("option", { value: "false", text: "Não" })]);
    } else input = el("input", { type: definition.type === "number" ? "number" : definition.type === "date" ? "date" : "text", "aria-label": definition.label });
    input.value = value == null ? "" : String(value);
    input.addEventListener("change", function () {
      var next = input.value;
      if (definition.type === "number") next = next === "" ? null : Number(next);
      else if (definition.type === "boolean") next = next === "" ? null : next === "true";
      else if (next === "") next = null;
      change(next);
    });
    return input;
  }

  function openEditContactModal(contactId) {
    var membership = findContactMembership(contactId); if (!membership) return;
    openModal({ title: "Editar contato", render: function (body, close, confirmButton) {
      var name = el("input", { type: "text", "aria-label": "Nome" }); name.value = membership.item.contact.name || "";
      var phone = el("input", { type: "text", "aria-label": "Telefone" }); phone.value = membership.item.contact.phoneNumber || "";
      var legacyNotes = el("textarea", { "aria-label": "Anotação anterior", placeholder: "Anotação anterior (opcional)" }); legacyNotes.value = membership.item.notes || "";
      var dealValue = el("input", { type: "number", min: "0", step: "0.01", inputmode: "decimal", "aria-label": "Valor da negociação" }); var initialDealValue = crmItemValue(getSelectedCrm(), membership.item); dealValue.value = initialDealValue > 0 ? String(initialDealValue) : "";
      var followUp = el("input", { type: "date", "aria-label": "Próximo contato" }); if (membership.item.nextContactAtMs) followUp.value = localDateInputValue(membership.item.nextContactAtMs);
      body.appendChild(el("label", { text: "Nome" })); body.appendChild(name); body.appendChild(el("label", { text: "Telefone" })); body.appendChild(phone); body.appendChild(el("label", { text: "Valor da negociação" })); body.appendChild(dealValue); body.appendChild(el("label", { text: "Anotação anterior" })); body.appendChild(legacyNotes); body.appendChild(el("label", { text: "Próximo contato" })); body.appendChild(followUp);
      confirmButton.addEventListener("click", async function () { var digits = phone.value.replace(/\D/g, ""); if (!name.value.trim()) { name.focus(); return; } if (digits.length < 8) { phone.focus(); return; } var current = findContactMembership(contactId); if (!current) return; var crmForEdit = getSelectedCrm(); var duplicateMembership = findPhoneMembershipInCrm(crmForEdit, digits, contactId); if (duplicateMembership) { toast("Esse número já pertence a outro contato deste CRM.", true); return; } await mutate(function () { current.item.contact.name = name.value.trim(); current.item.contact.phoneNumber = digits; current.item.dealValue = crmNormalizeDealValue(dealValue.value); current.item.notes = legacyNotes.value.trim(); current.item.nextContactAtMs = followUp.value ? new Date(followUp.value + "T00:00:00").getTime() : null; }); close(); if (activeProfile) renderContactProfile(contactId, true); });
    } });
  }

  async function fetchContactExternalTimeline(phoneNumber) {
    var phone = String(phoneNumber || "").replace(/\D/g, "");
    if (!phone) return [];
    var values = await Promise.all([storageGetOverview("EXTUI:extappScheduleStore"), storageGetOverview("EXTUI:extappFollowUpQueueStore"), storageGetOverview("EXTUI:extappActivityStore")]);
    var timeline = [];
    var agenda = parsePlainOverview(values[0]);
    ((agenda && agenda.list) || []).forEach(function (item) {
      if (String(item.targetChatId || "").replace(/\D/g, "") !== phone) return;
      timeline.push({ id: "agenda-" + item.id, title: "Agendamento " + (item.status === "sent" ? "enviado" : "criado"), description: item.targetChatName || "", atMs: item.sentAt || item.scheduleAtMs || item.createdAt || 0 });
    });
    var followUp = parsePlainOverview(values[1]);
    var queue = followUp && (followUp.queue || followUp.state && followUp.state.queue) || [];
    queue.forEach(function (item) {
      if (String(item.phoneNumber || "").replace(/\D/g, "") !== phone) return;
      timeline.push({ id: "followup-" + item.id, title: item.status === "fired" ? "Follow-up executado" : "Follow-up programado", atMs: item.firedAtMs || item.enqueuedAtMs || 0 });
    });
    (Array.isArray(values[2]) ? values[2] : []).forEach(function (item) {
      var related = String(item.chatId || item.targetLabel || "").replace(/\D/g, "");
      if (related !== phone) return;
      timeline.push({ id: "envio-" + item.id, title: item.title || "Envio", description: item.status || "", atMs: item.finishedAt || item.updatedAt || item.startedAt || 0 });
    });
    return timeline.filter(function (item) { return item.atMs; });
  }

  async function fetchContactNextOperations(phoneNumber) {
    var phone = String(phoneNumber || "").replace(/\D/g, "");
    if (!phone) return { schedule: null, followUp: null };
    var values = await Promise.all([storageGetOverview("EXTUI:extappScheduleStore"), storageGetOverview("EXTUI:extappFollowUpQueueStore"), storageGetOverview("EXTUI:extappFollowUpStore")]);
    var scheduleStore = parsePlainOverview(values[0]);
    var schedules = ((scheduleStore && scheduleStore.list) || []).filter(function (item) { return item.status === "scheduled" && String(item.targetChatId || "").replace(/\D/g, "") === phone; }).sort(function (a, b) { return a.scheduleAtMs - b.scheduleAtMs; });
    var queueStore = parsePlainOverview(values[1]); var ruleStore = parsePlainOverview(values[2]);
    var queue = queueStore && (queueStore.queue || queueStore.state && queueStore.state.queue) || [];
    var rules = ruleStore && (ruleStore.followUpList || ruleStore.state && ruleStore.state.followUpList) || [];
    var followUps = queue.filter(function (item) { return item.status === "pending" && String(item.phoneNumber || "").replace(/\D/g, "") === phone; }).map(function (item) { var rule = rules.find(function (candidate) { return candidate.id === item.followUpId; }); var timing = rule && rule.acionamento && rule.acionamento.timing || {}; return { label: rule && rule.nome || "Follow-up", atMs: (item.enqueuedAtMs || 0) + ((timing.days || 0) * 86400 + (timing.hours || 0) * 3600 + (timing.minutes || 0) * 60) * 1000 }; }).sort(function (a, b) { return a.atMs - b.atMs; });
    return { schedule: schedules[0] || null, followUp: followUps[0] || null };
  }

  function renderContactProfile(contactId, preserveFocus, openCopilot, initialTab) {
    var membership = findContactMembership(contactId);
    if (!membership || !professionalCore) { closeContactProfile(); return; }
    var previous = activeProfile ? activeProfile.previousFocus : document.activeElement;
    var copilotWasOpen = !!(activeProfile && activeProfile.contactId === contactId && activeProfile.layer.querySelector(".extuiCrmCopilot[open]"));
    var allowedProfileTabs = ["data", "crms", "notes", "tasks", "timeline"];
    var currentTab = allowedProfileTabs.indexOf(initialTab) !== -1 ? initialTab : (activeProfile && activeProfile.contactId === contactId && allowedProfileTabs.indexOf(activeProfile.tab) !== -1 ? activeProfile.tab : "data");
    closeContactProfile(true);
    var layer = el("div", { class: "extuiCrmDrawerLayer" });
    var backdrop = el("button", { class: "extuiCrmDrawerLayer__backdrop", type: "button", "aria-label": "Fechar perfil" });
    var drawer = el("aside", { class: "extuiCrmProfile", role: "dialog", "aria-modal": "true", "aria-labelledby": "extui-crm-profile-title", tabindex: "-1", "data-extui-academy-target": "crm-profile" });
    layer.appendChild(backdrop); layer.appendChild(drawer); document.body.appendChild(layer);
    var store = professionalCore.normalizeStore(professionalStore);
    var profile = store.contacts[contactId] || { notes: [], tasks: [], timeline: [], fieldValues: {} };
    var definitions = store.boards[membership.crm.id] && store.boards[membership.crm.id].fieldDefinitions || [];
    var closeButton = el("button", { class: "extui-icon-btn extuiCrmProfile__close", type: "button", "aria-label": "Fechar perfil", text: "×" });
    drawer.appendChild(el("header", { class: "extuiCrmProfile__header" }, [renderAvatarEl(membership.item.contact, "extui-avatar--profile"), el("div", { class: "extuiCrmProfile__identity" }, [el("h2", { id: "extui-crm-profile-title", text: membership.item.contact.name }), el("p", { text: displayPhone(membership.item.contact.phoneNumber) }), el("span", { text: membership.crm.name + " · " + membership.column.title })]), closeButton]));
    var actions = el("div", { class: "extuiCrmProfile__actions" });
    var waButton = el("button", { class: "extui-btn extui-btn--primary", type: "button", text: "Abrir WhatsApp" });
    waButton.disabled = !membership.item.contact.phoneNumber;
    waButton.addEventListener("click", function () { openWhatsApp(membership.item.contact.phoneNumber); });
    var agendaButton = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Abrir Agenda" });
    agendaButton.addEventListener("click", function () { closeContactProfile(); window.__extDashboardShell.showSection("agenda"); });
    var editButton = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Editar contato" }); editButton.addEventListener("click", function () { closeContactProfile(); openEditContactModal(contactId); });
    actions.appendChild(waButton); actions.appendChild(agendaButton); actions.appendChild(editButton); drawer.appendChild(actions);
    var tabs = el("div", { class: "extuiCrmProfile__tabs", role: "tablist", "aria-label": "Perfil do contato" });
    var body = el("div", { class: "extuiCrmProfile__body" });
    var panes = {};
    [["data","Dados do Contato"],["crms","CRMs"],["notes","Notas"],["tasks","Tarefas"],["timeline","Linha do Tempo"]].forEach(function (entry) {
      var key = entry[0], label = entry[1];
      var tab = el("button", { class: "extuiCrmProfile__tab", type: "button", role: "tab", text: label, "data-profile-tab": key, "aria-selected": "false" });
      var pane = el("div", { class: "extuiCrmProfile__pane", role: "tabpanel", "data-profile-pane": key });
      panes[key] = pane; tabs.appendChild(tab); body.appendChild(pane);
      tab.addEventListener("click", function () { setProfileTab(key); });
    });
    function setProfileTab(key) {
      if (!panes[key]) key = "data";
      currentTab = key;
      tabs.querySelectorAll(".extuiCrmProfile__tab").forEach(function (tab) { var active = tab.getAttribute("data-profile-tab") === key; tab.classList.toggle("is-active", active); tab.setAttribute("aria-selected", active ? "true" : "false"); });
      Object.keys(panes).forEach(function (name) { panes[name].hidden = name !== key; });
      if (activeProfile && activeProfile.contactId === contactId) activeProfile.tab = key;
      if (panes[key]) panes[key].scrollTop = 0;
    }
    drawer.appendChild(tabs); drawer.appendChild(body);
    var dataPane = panes.data, crmsPane = panes.crms, notesPane = panes.notes, tasksPane = panes.tasks, timelinePane = panes.timeline;

    var details = profileSection("Dados do contato");
    details.appendChild(el("dl", { class: "extuiCrmProfile__facts" }, [el("div", {}, [el("dt", { text: "Origem" }), el("dd", { text: membership.item.createdBy || "Não informada" })]), el("div", {}, [el("dt", { text: "Entrada no CRM" }), el("dd", { text: fmtOverviewWhen(membership.item.createdAtInMs) || "Não informada" })]), el("div", {}, [el("dt", { text: "Próximo contato" }), el("dd", { text: membership.item.nextContactAtMs ? fmtOverviewWhen(membership.item.nextContactAtMs) : "Não agendado" })])]));
    var factsList = details.querySelector(".extuiCrmProfile__facts");
    var nextScheduleValue = el("dd", { text: "Carregando…" }); var nextFollowUpValue = el("dd", { text: "Carregando…" });
    factsList.appendChild(el("div", {}, [el("dt", { text: "Próximo agendamento" }), nextScheduleValue])); factsList.appendChild(el("div", {}, [el("dt", { text: "Próximo follow-up" }), nextFollowUpValue]));
    fetchContactNextOperations(membership.item.contact.phoneNumber).then(function (result) { if (!activeProfile || activeProfile.contactId !== contactId) return; nextScheduleValue.textContent = result.schedule ? fmtOverviewWhen(result.schedule.scheduleAtMs) : "Não agendado"; nextFollowUpValue.textContent = result.followUp ? result.followUp.label + " · " + fmtOverviewWhen(result.followUp.atMs) : "Não programado"; });
    dataPane.appendChild(details);

    var crmsSection = profileSection("CRMs", "crm-profile-move");
    var memberships = findPhoneMemberships(membership.item.contact.phoneNumber);
    if (!memberships.length) memberships = [membership];
    memberships.forEach(function (crmMembership) {
      var card = el("article", { class: "extuiCrmProfile__crmMembership" });
      var heading = el("div", { class: "extuiCrmProfile__crmMembershipHead" }, [el("strong", { text: crmMembership.crm.name || "CRM" }), el("small", { text: crmMembership.column.title || "Etapa" })]);
      var field = el("label", { class: "extuiCrmProfile__field" }, [el("span", { text: "Etapa" })]);
      var select = el("select", { "aria-label": "Mover contato no CRM " + (crmMembership.crm.name || "CRM") });
      (crmMembership.crm.columns || []).forEach(function (column) { select.appendChild(el("option", { value: column.id, text: column.title })); });
      select.value = crmMembership.column.id;
      select.addEventListener("change", async function () {
        var destinationId = select.value, fromId = crmMembership.column.id, fromTitle = crmMembership.column.title, destinationTitle = "", moved = false, fromIndex = 0;
        await mutate(function (state) {
          var crm = state.crmList.find(function (candidate) { return candidate.id === crmMembership.crm.id; }); if (!crm) return;
          var source = (crm.columns || []).find(function (column) { return column.id === fromId && (column.items || []).some(function (item) { return item.id === crmMembership.item.id; }); });
          var destination = (crm.columns || []).find(function (column) { return column.id === destinationId; });
          if (!source || !destination || source.id === destination.id) return;
          var item = (source.items || []).find(function (candidate) { return candidate.id === crmMembership.item.id; }); if (!item) return;
          fromIndex = (source.items || []).findIndex(function(candidate){ return candidate.id === crmMembership.item.id; });
          source.items = source.items.filter(function (candidate) { return candidate.id !== crmMembership.item.id; }); destination.items.push(item); destinationTitle = destination.title; moved = true; pushColumnEvent(crm.id, destination.id, item.id);
        });
        if (moved) { saveProfileOperation({ type: "event.add", crmContactId: crmMembership.item.id, event: { type: "column_moved", title: "Etapa alterada", description: fromTitle + " → " + destinationTitle, metadata: { fromColumnId: fromId, toColumnId: destinationId } } }); offerCrmMoveUndo({crmId:crmMembership.crm.id,itemId:crmMembership.item.id,fromColumnId:fromId,toColumnId:destinationId,fromTitle:fromTitle,toTitle:destinationTitle,fromIndex:fromIndex}); }
      });
      field.appendChild(select); card.appendChild(heading); card.appendChild(field); crmsSection.appendChild(card);
    });
    crmsPane.appendChild(crmsSection);

    var fields = profileSection("Campos personalizados");
    if (!definitions.length) fields.appendChild(el("p", { class: "extuiCrmProfile__empty", text: "Nenhum campo configurado neste CRM." }));
    definitions.forEach(function (definition) { var field = el("label", { class: "extuiCrmProfile__field" }, [el("span", { text: definition.label })]); field.appendChild(renderProfileField(definition, profile.fieldValues[definition.id], function (value) { saveProfileOperation({ type: "fieldValue.set", boardId: membership.crm.id, crmContactId: contactId, fieldId: definition.id, value: value }); })); fields.appendChild(field); }); dataPane.appendChild(fields);

    var notes = profileSection("Notas", "crm-profile-note");
    var noteForm = el("form", { class: "extuiCrmProfile__composer extuiCrmProfile__composer--note" }); var noteTitle = el("input", { type: "text", maxlength: "120", placeholder: "Título da nota", "aria-label": "Título da nova nota" }); var noteInput = el("textarea", { rows: "3", placeholder: "Registre contexto importante sobre este contato", "aria-label": "Conteúdo da nova nota" }); var noteAdd = el("button", { class: "extui-btn extui-btn--primary", type: "submit", text: "Adicionar nota" }); noteForm.appendChild(noteTitle); noteForm.appendChild(noteInput); noteForm.appendChild(noteAdd);
    noteForm.addEventListener("submit", function (event) { event.preventDefault(); if (!noteInput.value.trim()) { noteInput.focus(); return; } saveProfileOperation({ type: "note.add", crmContactId: contactId, note: { title: noteTitle.value.trim(), text: noteInput.value.trim(), author: localAuthor() } }); }); notes.appendChild(noteForm);
    profile.notes.slice().sort(function (a, b) { return b.updatedAtMs - a.updatedAtMs; }).forEach(function (note) { var fallback=(String(note.text||"").trim().split(/\s+/).slice(0,6).join(" ")||"Nota"); var row = el("article", { class: "extuiCrmProfile__item" }, [el("strong", { text: note.title || fallback }), el("p", { text: note.text }), el("small", { text: (note.author || "Usuário local") + " · " + fmtOverviewAgo(note.updatedAtMs) })]); var edit = el("button", { class: "extui-btn extui-btn--text", type: "button", text: "Editar" }); edit.addEventListener("click", function () { row.innerHTML = ""; var titleInput=el("input",{type:"text",maxlength:"120","aria-label":"Título da nota"});titleInput.value=note.title||"";var input = el("textarea", { rows: "3", "aria-label": "Editar nota" }); input.value = note.text; var save = el("button", { class: "extui-btn extui-btn--primary", type: "button", text: "Salvar alteração" }); save.addEventListener("click", function () { if (input.value.trim()) saveProfileOperation({ type: "note.update", crmContactId: contactId, noteId: note.id, patch: { title:titleInput.value.trim(),text: input.value.trim(), author: localAuthor() } }); }); row.appendChild(titleInput);row.appendChild(input); row.appendChild(save); titleInput.focus(); }); var remove = el("button", { class: "extui-btn extui-btn--text danger", type: "button", text: "Excluir" }); remove.addEventListener("click", async function () { if (await extConfirm("Excluir esta nota?", { danger: true })) saveProfileOperation({ type: "note.remove", crmContactId: contactId, noteId: note.id }); }); row.appendChild(el("div", { class: "extuiCrmProfile__itemActions" }, [edit, remove])); notes.appendChild(row); }); notesPane.appendChild(notes);

    var tasks = profileSection("Tarefas", "crm-profile-task"); var taskForm = el("form", { class: "extuiCrmProfile__taskForm" }); var taskTitle = el("input", { type: "text", placeholder: "Título da tarefa", "aria-label": "Título da tarefa" }); var taskObjective=el("textarea",{rows:"2",placeholder:"Objetivo / o que precisa ser feito","aria-label":"Objetivo da tarefa"});var taskDue = el("input", { type: "datetime-local", "aria-label": "Prazo da tarefa" }); var taskAdd = el("button", { class: "extui-btn extui-btn--primary", type: "submit", text: "Criar tarefa" }); taskForm.appendChild(taskTitle);taskForm.appendChild(taskObjective); taskForm.appendChild(taskDue); taskForm.appendChild(taskAdd);
    taskForm.addEventListener("submit", function (event) { event.preventDefault(); if (!taskTitle.value.trim()) { taskTitle.focus(); return; } var dueAt=taskDue.value?parseLocalDateTimeStrict(taskDue.value):null;if(taskDue.value&&!Number.isFinite(dueAt)){toast("Prazo com data ou horário local inválido.",true);taskDue.focus();return;} saveProfileOperation({ type: "task.add", crmContactId: contactId, task: { title: taskTitle.value.trim(),description:taskObjective.value.trim(), dueAtMs: dueAt, priority: "normal", status: "open" } }); }); tasks.appendChild(taskForm);
    function profileTaskActionLabel(task){var a=task&&task.action||null;if(!a)return"";if(a.type==="flow")return"Fluxo programado";if(a.type==="funnel")return"Funil programado";if(a.type==="moveCRM")return"Movimentação no CRM";if(a.type==="saved")return"Envio programado";return"Ação programada";}
    profile.tasks.slice().sort(function (a, b) { return (a.status === "completed") - (b.status === "completed") || (a.dueAtMs || Infinity) - (b.dueAtMs || Infinity); }).forEach(function (task) { var overdue = professionalCore.isTaskOverdue(task, Date.now()); var toggle = el("input", { type: "checkbox", "aria-label": (task.status === "completed" ? "Reabrir " : "Concluir ") + task.title }); toggle.checked = task.status === "completed"; toggle.addEventListener("change", function () { saveProfileOperation({ type: "task.update", crmContactId: contactId, taskId: task.id, patch: { status: toggle.checked ? "completed" : "open" } }); });var info=el("div", {}, [el("strong", { text: task.title })]);if(task.description)info.appendChild(el("p",{class:"extuiCrmProfile__taskObjective",text:task.description}));var metaText=task.dueAtMs ? (overdue ? "Atrasada · " : "Prazo · ") + fmtOverviewWhen(task.dueAtMs) : "Sem prazo";var actionText=profileTaskActionLabel(task);if(actionText)metaText+=" · "+actionText;info.appendChild(el("small", { text: metaText }));tasks.appendChild(el("article", { class: "extuiCrmProfile__task" + (overdue ? " is-overdue" : "") }, [toggle,info])); }); tasksPane.appendChild(tasks);

    var timeline = profileSection("Linha do tempo");
    function paintTimeline(external) { timeline.innerHTML = ""; timeline.appendChild(el("h3", { text: "Linha do tempo" })); var events = profile.timeline.slice().concat(external || []); if (membership.item.createdAtInMs) events.push({ id: "entry-" + contactId, title: "Contato adicionado ao CRM", atMs: membership.item.createdAtInMs }); events.sort(function (a, b) { return b.atMs - a.atMs; }); events.forEach(function (event) { timeline.appendChild(el("div", { class: "extuiCrmProfile__timelineItem" }, [el("span", { class: "extuiCrmProfile__timelineDot" }), el("div", {}, [el("strong", { text: event.title || "Atividade no CRM" }), event.description ? el("p", { text: event.description }) : null, el("small", { text: fmtOverviewWhen(event.atMs) })]) ])); }); if (!events.length) timeline.appendChild(el("p", { class: "extuiCrmProfile__empty", text: "Nenhuma atividade registrada." })); }
    paintTimeline([]); timelinePane.appendChild(timeline); fetchContactExternalTimeline(membership.item.contact.phoneNumber).then(function (external) { if (activeProfile && activeProfile.contactId === contactId) paintTimeline(external); });

    if (window.__extCrmAiCopilot && window.__extCrmAiCopilotCore) {
      var publicContact = {
        name: membership.item.contact.name,
        stage: membership.column.title,
        source: membership.item.createdBy || null,
        nextContact: membership.item.nextContactAtMs ? fmtOverviewWhen(membership.item.nextContactAtMs) : null,
        nextSchedule: null,
        nextFollowUp: null,
        fields: definitions.map(function (definition) { return { label: definition.label, value: profile.fieldValues[definition.id] }; }),
        notes: profile.notes.map(function (note) { return { title: note.title || null, text: note.text }; }),
        tasks: profile.tasks.map(function (task) { return { title: task.title, objective: task.description || null, status: task.status, due: task.dueAtMs ? fmtOverviewWhen(task.dueAtMs) : null, action: profileTaskActionLabel(task) || null }; })
      };
      fetchContactNextOperations(membership.item.contact.phoneNumber).then(function (result) {
        publicContact.nextSchedule = result.schedule ? fmtOverviewWhen(result.schedule.scheduleAtMs) : null;
        publicContact.nextFollowUp = result.followUp ? result.followUp.label + " · " + fmtOverviewWhen(result.followUp.atMs) : null;
      });
      window.__extCrmAiCopilot.mount({
        container: dataPane,
        binding: window.__extCrmAiCopilotCore.createBinding(contactId, membership.crm.id),
        publicContact: publicContact,
        open: openCopilot === true || copilotWasOpen,
        resolvePhone: function () { var current = findContactMembership(contactId); return current && current.item.contact.phoneNumber || ""; },
        saveNote: function (text) { return saveProfileOperation({ type: "note.add", crmContactId: contactId, note: { text: text, author: localAuthor() } }); },
        openWhatsApp: function () { var current = findContactMembership(contactId); if (current && current.item.contact.phoneNumber) openWhatsApp(current.item.contact.phoneNumber); },
        confirm: function (message) { return extConfirm(message); },
        toast: toast,
        navigate: async function (section, entityId) {
          closeContactProfile();
          await window.__extDashboardShell.showSection(section);
          if (section === "ai-assistants" && window.__extAiAssistants) window.__extAiAssistants.openAssistant(entityId || null);
          if (section === "ai-agents" && window.__extAiAgents) window.__extAiAgents.openAgent(entityId || null);
        }
      });
    }

    function close() { closeContactProfile(); } backdrop.addEventListener("click", close); closeButton.addEventListener("click", close);
    var keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); close(); return; } if (event.key !== "Tab") return; var focusable = drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'); if (!focusable.length) return; var first = focusable[0], last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); } };
    document.addEventListener("keydown", keyHandler, true); activeProfile = { contactId: contactId, layer: layer, previousFocus: previous, keyHandler: keyHandler, tab: currentTab }; setProfileTab(currentTab); if (!preserveFocus) drawer.focus();
  }

  function openContactDetailsModal(col, item) {
    return renderContactProfile(item.id, false);
  }

  function renderAddColumn() {
    var wrap = el("div", { class: "extui-addcol" });
    var showForm = function () {
      wrap.innerHTML = "";
      var chosenColor = COLOR_PALETTE[0];
      var form = el("div", { class: "extui-addcol__form" });
      var nameInput = el("input", { type: "text", placeholder: "Nome da lista" });
      var colorsWrap = renderColorPicker(chosenColor, function (c) { chosenColor = c; });
      var row = el("div", { class: "extui-addcard-form__row" });
      var saveBtn = el("button", { class: "extui-btn extui-btn--primary", text: "Salvar" });
      var cancelBtn = el("button", { class: "extui-btn extui-btn--ghost", text: "Cancelar" });
      saveBtn.addEventListener("click", function () {
        var name = nameInput.value.trim();
        if (!name) { nameInput.focus(); return; }
        mutate(function (s) {
          var crm = getSelectedCrm(); if (!crm) return;
          crm.columns.push({ id: uid(), title: name, description: "", color: chosenColor, items: [] });
          touchCrm(crm);
        });
        toast('Lista "' + name + '" adicionada com sucesso.');
      });
      cancelBtn.addEventListener("click", function () { render(); });
      row.appendChild(saveBtn);
      row.appendChild(cancelBtn);
      form.appendChild(nameInput);
      form.appendChild(colorsWrap);
      form.appendChild(row);
      wrap.appendChild(form);
      nameInput.focus();
    };
    var btn = el("button", { class: "extui-addcol__btn", text: "+ Adicionar outra lista" });
    btn.addEventListener("click", showForm);
    wrap.appendChild(btn);
    return wrap;
  }

  function renderCrmQuickActions() {
    var crm = getSelectedCrm();
    var wrap = el("div", { class: "extuiCrmQuickActions" });
    var editBtn = el("button", { class: "extui-icon-btn", type: "button", title: "Editar CRM", "aria-label": "Editar CRM" }, [icon("edit")]);
    var archiveBtn = el("button", { class: "extui-icon-btn", type: "button", title: "Arquivar CRM", "aria-label": "Arquivar CRM" }, [icon("archive")]);
    var deleteBtn = el("button", { class: "extui-icon-btn extuiCrmQuickDelete", type: "button", title: "Excluir CRM", "aria-label": "Excluir CRM" }, [icon("trash")]);
    editBtn.disabled = archiveBtn.disabled = deleteBtn.disabled = !crm;
    editBtn.addEventListener("click", function(){ if(crm) openEditCrmModal(crm); });
    archiveBtn.addEventListener("click", async function(){ if(crm){ await setCrmArchived(crm,true); crmView="hub"; toast("CRM arquivado."); } });
    deleteBtn.addEventListener("click", function(){ if(crm) openCrmDeleteDialog(crm); });
    wrap.appendChild(editBtn); wrap.appendChild(archiveBtn); wrap.appendChild(deleteBtn); return wrap;
  }

                                                                         
                                                                         
                                                                          
                          
  function applyCrmExpandedMode() {
    document.body.classList.toggle("extuiCrmExpandedMode", !!crmExpanded);
  }
  function setCrmExpanded(next) {
    crmExpanded = !!next;
    applyCrmExpandedMode();
    render();
  }
  function renderExpandedBackButton() {
    if (!crmExpanded) return null;
    var btn = el("button", { class: "extuiCrmExpandedBack", type: "button", title: "Voltar", "aria-label": "Voltar" }, [icon("arrowLeft"), el("span", { text: "Voltar" })]);
    btn.addEventListener("click", function () { setCrmExpanded(false); });
    return btn;
  }
  function renderExpandButton() {
    var btn = el("button", { class: "extui-btn extui-btn--ghost extuiCrmExpandBtn", type: "button", title: crmExpanded ? "Sair da visualização expandida" : "Expandir Visualização" }, [icon(crmExpanded ? "arrowLeft" : "expand"), el("span", { text: crmExpanded ? "Sair do modo expandido" : "Expandir Visualização" })]);
    btn.addEventListener("click", function () { setCrmExpanded(!crmExpanded); });
    return btn;
  }
  var CRM_FUNNEL_PREF_KEY = "EXTUI:crmFunnelAnalyticsStore";
  async function openCrmAnalysis() {
    var crm = getSelectedCrm();
    if (!crm) return;
    try {
      var raw = await window.ExtensionStorage.get(CRM_FUNNEL_PREF_KEY);
      var stored = {};
      try { stored = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : {}; } catch (_) { stored = {}; }
      if (stored && stored.state) stored = stored.state;
      stored = Object.assign({ metric: "contacts", chart: "pyramid", sort: "original", legend: true, defaultChartV9: true }, stored || {}, { crmId: crm.id });
      await window.ExtensionStorage.set(CRM_FUNNEL_PREF_KEY, JSON.stringify(stored));
    } catch (_) {}
    window.__extCrmFunnelPendingCrmId = crm.id;
    var shell = window.__extDashboardShell;
    if (shell && typeof shell.showSection === "function") shell.showSection("crm-funnel");
  }
  var pendingCrmView = null;
  async function openCrmView(view, crmId) {
    if (["hub", "overview", "kanban", "notes"].indexOf(view) === -1) view = "hub";
    if (crmId && S && Array.isArray(S.crmList) && S.crmList.some(function (crm) { return crm.id === crmId && !isCrmArchived(crm); })) {
      S.selectedCrmId = crmId;
      try { await saveStore(S); } catch (_) {}
    }
    pendingCrmView = view;
    var shell = window.__extDashboardShell;
    if (shell && shell.getCurrentSection && shell.getCurrentSection() === "crm") {
      crmView = view; pendingCrmView = null; render(); return;
    }
    if (shell && typeof shell.showSection === "function") shell.showSection("crm");
  }
  window.__extCrmDashboardOpenView = openCrmView;
  window.__extCrmOpenContactProfile = function (contactId, tab) {
    if (!contactId) return false;
    var membership = findContactMembership(String(contactId));
    if (!membership) return false;
    renderContactProfile(String(contactId), false, false, tab || "timeline");
    return true;
  };

  function renderViewToggle() {
    var wrap = el("div", { class: "extui-viewtoggle", "data-extui-academy-target": "crm-view-tabs" });
    var hubBtn = el("button", { class: "extui-viewtoggle__btn" + (crmView === "hub" ? " active" : ""), type: "button", "data-extui-academy-target": "crm-tab-hub" }, [icon("layoutGrid"), el("span", { text: "CRMs" })]);
    var overviewBtn = el("button", { class: "extui-viewtoggle__btn" + (crmView === "overview" ? " active" : ""), type: "button", "data-extui-academy-target": "crm-tab-overview" }, [icon("activity"), el("span", { text: "Visão geral" })]);
    var kanbanBtn = el("button", { class: "extui-viewtoggle__btn" + (crmView === "kanban" ? " active" : ""), type: "button", "data-extui-academy-target": "crm-tab-kanban" }, [icon("kanbanIcon"), el("span", { text: "Kanban" })]);
    var notesBtn = el("button", { class: "extui-viewtoggle__btn" + (crmView === "notes" ? " active" : ""), type: "button", "data-extui-academy-target": "crm-tab-notes" }, [icon("note"), el("span", { text: "Notas" })]);
    var analysisBtn = el("button", { class: "extui-viewtoggle__btn extui-viewtoggle__btn--analysis", type: "button", title: "Análise do funil", "aria-label": "Abrir análise do funil", "data-extui-academy-target": "crm-tab-analysis" }, [icon("funnel"), el("span", { text: "Análise" })]);
    hubBtn.addEventListener("click", function () { if (crmView !== "hub") { crmView = "hub"; render(); } });
    overviewBtn.addEventListener("click", function () { if (getSelectedCrm() && crmView !== "overview") { crmView = "overview"; render(); } });
    kanbanBtn.addEventListener("click", function () { if (getSelectedCrm() && crmView !== "kanban") { crmView = "kanban"; render(); } });
    notesBtn.addEventListener("click", function () { if (getSelectedCrm() && crmView !== "notes") { crmView = "notes"; render(); } });
    analysisBtn.addEventListener("click", function () { if (getSelectedCrm()) openCrmAnalysis(); });
    if (!getSelectedCrm()) { overviewBtn.disabled = true; kanbanBtn.disabled = true; notesBtn.disabled = true; analysisBtn.disabled = true; analysisBtn.title = "Crie um CRM para visualizar a análise do funil."; }
    wrap.appendChild(hubBtn); wrap.appendChild(overviewBtn); wrap.appendChild(kanbanBtn); wrap.appendChild(notesBtn); wrap.appendChild(analysisBtn);
    return wrap;
  }

  function openFieldManager(editingField) {
    var crm = getSelectedCrm();
    if (!crm || !professionalCore) return;
    openModal({
      title: "Configurar campos",
      confirmLabel: "Fechar",
      render: function (body, close, confirmButton) {
        var store = professionalCore.normalizeStore(professionalStore);
        var definitions = store.boards[crm.id] && store.boards[crm.id].fieldDefinitions || [];
        var list = el("div", { class: "extuiCrmFields" });
        if (!definitions.length) list.appendChild(el("p", { class: "extuiCrmProfile__empty", text: "Nenhum campo personalizado configurado." }));
        definitions.forEach(function (definition, definitionIndex) {
          var row = el("div", { class: "extuiCrmFields__row" }, [el("div", {}, [el("strong", { text: definition.label }), el("small", { text: ({ text: "Texto", number: "Número", date: "Data", select: "Lista", boolean: "Sim/Não" })[definition.type] })])]);
          var actions = el("div", { class: "extuiCrmFields__actions" });
          var up = el("button", { class: "extui-btn extui-btn--text", type: "button", text: "↑", "aria-label": "Mover campo para cima" }); up.disabled = definitionIndex === 0;
          var down = el("button", { class: "extui-btn extui-btn--text", type: "button", text: "↓", "aria-label": "Mover campo para baixo" }); down.disabled = definitionIndex === definitions.length - 1;
          up.addEventListener("click", async function () { await runProfessionalOperation({ type: "field.reorder", boardId: crm.id, fieldId: definition.id, toIndex: definitionIndex - 1 }); close(); openFieldManager(); });
          down.addEventListener("click", async function () { await runProfessionalOperation({ type: "field.reorder", boardId: crm.id, fieldId: definition.id, toIndex: definitionIndex + 1 }); close(); openFieldManager(); });
          var edit = el("button", { class: "extui-btn extui-btn--text", type: "button", text: "Editar" }); edit.addEventListener("click", function () { close(); openFieldManager(definition); });
          var remove = el("button", { class: "extui-btn extui-btn--text danger", type: "button", text: "Remover" });
          remove.addEventListener("click", async function () {
            if (!await extConfirm('Remover o campo "' + definition.label + '"? Os valores já preenchidos serão preservados.', { danger: true })) return;
            await runProfessionalOperation({ type: "field.remove", boardId: crm.id, fieldId: definition.id, purgeValues: false }); close(); openFieldManager();
          });
          actions.appendChild(up); actions.appendChild(down); actions.appendChild(edit); actions.appendChild(remove); row.appendChild(actions); list.appendChild(row);
        });
        body.appendChild(list);
        var form = el("form", { class: "extuiCrmFields__form" });
        var name = el("input", { type: "text", placeholder: "Nome do novo campo", "aria-label": "Nome do novo campo" });
        var type = el("select", { "aria-label": "Tipo do campo" }, [el("option", { value: "text", text: "Texto" }), el("option", { value: "number", text: "Número" }), el("option", { value: "date", text: "Data" }), el("option", { value: "select", text: "Lista" }), el("option", { value: "boolean", text: "Sim/Não" })]);
        var options = el("input", { type: "text", placeholder: "Opções separadas por vírgula", "aria-label": "Opções da lista" }); options.hidden = true;
        if (editingField) { name.value = editingField.label; type.value = editingField.type; options.value = (editingField.options || []).map(function (option) { return option.label; }).join(", "); options.hidden = editingField.type !== "select"; }
        type.addEventListener("change", function () { options.hidden = type.value !== "select"; });
        var add = el("button", { class: "extui-btn extui-btn--primary", type: "submit", text: editingField ? "Salvar campo" : "Adicionar campo" }); form.appendChild(name); form.appendChild(type); form.appendChild(options); form.appendChild(add);
        form.addEventListener("submit", async function (event) {
          event.preventDefault(); if (!name.value.trim()) { name.focus(); return; }
          var fieldOptions = type.value === "select" ? options.value.split(",").map(function (value) { return value.trim(); }).filter(Boolean).map(function (label) { return { id: label, label: label }; }) : [];
          if (type.value === "select" && !fieldOptions.length) { options.focus(); return; }
          try { await runProfessionalOperation({ type: "field.upsert", boardId: crm.id, field: { id: editingField && editingField.id, label: name.value.trim(), type: type.value, options: fieldOptions } }); close(); openFieldManager(); } catch (error) { toast(error.message, true); }
        }); body.appendChild(form);
        confirmButton.addEventListener("click", close);
      }
    });
  }

  function renderProfessionalFilters(crm) {
    var wrap = el("div", { class: "extuiCrmFilters", "aria-label": "Filtros do CRM" });
    var column = el("select", { "aria-label": "Filtrar por lista" }, [el("option", { value: "", text: "Todas as listas" })]);
    (crm && crm.columns || []).forEach(function (item) { column.appendChild(el("option", { value: item.id, text: item.title })); }); column.value = crmFilters.columnId;
    var task = el("select", { "aria-label": "Filtrar por tarefa" }, [el("option", { value: "all", text: "Todas as tarefas" }), el("option", { value: "pending", text: "Tarefa pendente" }), el("option", { value: "overdue", text: "Tarefa atrasada" })]); task.value = crmFilters.task;
    var followUp = el("select", { "aria-label": "Filtrar por follow-up" }, [el("option", { value: "all", text: "Todos os follow-ups" }), el("option", { value: "with", text: "Com follow-up" })]); followUp.value = crmFilters.followUp;
    var value = el("select", { "aria-label": "Filtrar por valor" }, [el("option", { value: "all", text: "Todos os valores" }), el("option", { value: "with", text: "Com valor" }), el("option", { value: "without", text: "Sem valor" })]); value.value = crmFilters.value;
    function update() { crmFilters = { columnId: column.value, task: task.value, followUp: followUp.value, value: value.value }; render(); }
    column.addEventListener("change", update); task.addEventListener("change", update); followUp.addEventListener("change", update); value.addEventListener("change", update);
    wrap.appendChild(column); wrap.appendChild(task); wrap.appendChild(followUp); wrap.appendChild(value); return wrap;
  }

  function contactPassesFilters(column, item) {
    if (crmFilters.columnId && column.id !== crmFilters.columnId) return false;
    var summary = professionalCore && professionalCore.summarizeContact(professionalStore, item.id, { now: Date.now() });
    if (crmFilters.task === "pending" && !(summary && summary.openTaskCount)) return false;
    if (crmFilters.task === "overdue" && !(summary && summary.overdueTaskCount)) return false;
    if (crmFilters.followUp === "with" && !item.nextContactAtMs) return false;
    var value = crmItemValue(getSelectedCrm(), item);
    if (crmFilters.value === "with" && !(value > 0)) return false;
    if (crmFilters.value === "without" && value > 0) return false;
    return true;
  }

  function renderCrmNotesBody(app) {
    var crm = getSelectedCrm();
    var searchWrap = el("div", { class: "extuiSearch extuiCrmNotesSearch" }, [icon("search")]);
    var searchInput = el("input", { type: "search", placeholder: "Buscar por contato, etapa ou conteúdo da nota...", "aria-label": "Buscar notas do CRM" });
    searchWrap.appendChild(searchInput);
    var topbar = el("div", { class: "extui-topbar" }, [
      renderExpandedBackButton(),
      el("div", { class: "extui-topbar__title", text: "CRM" }),
      renderBoardSelector(),
      renderViewToggle(),
      el("div", { class: "extui-topbar__spacer" }),
      renderExpandButton(),
      renderCrmQuickActions()
    ].filter(Boolean));
    app.appendChild(topbar);
    var wrap = el("section", { class: "extuiCrmNotesWorkspace" }); app.appendChild(wrap);
    if (!crm) {
      wrap.appendChild(el("div", { class: "extui-empty" }, [icon("users", "extui-empty__icon"), el("h2", { text: "Crie um CRM para registrar notas" }), el("p", { text: "As notas ficam associadas aos contatos e ao histórico comercial." })]));
      return;
    }
    var store = professionalCore ? professionalCore.normalizeStore(professionalStore) : { contacts: {} };
    var rows = [], members = [], contactIds = {}, memberIds = {};
    (crm.columns || []).forEach(function (col) {
      (col.items || []).forEach(function (item) {
        if (!memberIds[item.id]) { members.push({ item: item, col: col }); memberIds[item.id] = true; }
        var profile = store.contacts[item.id] || { notes: [] };
        (profile.notes || []).forEach(function (note) {
          rows.push({ note: note, item: item, col: col, contactId: item.id }); contactIds[item.id] = true;
        });
      });
    });
    rows.sort(function (a, b) { return Number(b.note.updatedAtMs || b.note.createdAtMs || 0) - Number(a.note.updatedAtMs || a.note.createdAtMs || 0); });
    members.sort(function (a, b) { return String(a.item.contact && a.item.contact.name || "").localeCompare(String(b.item.contact && b.item.contact.name || ""), "pt-BR", { sensitivity: "base" }); });
    var recentCut = Date.now() - 7 * 86400000;
    var newNoteBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "+ Nova nota" });
    var notesToolbar = el("div", { class: "extuiCrmNotesToolbar" }, [
      el("div", { class: "extuiCrmNotesKpisCompact" }, [
        el("span", {}, [el("strong", { text: String(rows.length) }), document.createTextNode(" notas")]),
        el("span", {}, [el("strong", { text: String(Object.keys(contactIds).length) }), document.createTextNode(" contatos")]),
        el("span", {}, [el("strong", { text: String(rows.filter(function (r) { return Number(r.note.updatedAtMs || r.note.createdAtMs || 0) >= recentCut; }).length) }), document.createTextNode(" recentes")])
      ]),
      searchWrap,
      newNoteBtn
    ]);
    wrap.appendChild(notesToolbar);

    var composer = el("form", { class: "extuiCrmNotesComposer" });
    composer.hidden = true;
    var composerHead = el("div", { class: "extuiCrmNotesComposerHead" }, [el("div", {}, [el("strong", { text: "Nova nota" }), el("span", { text: "Registre uma informação sem precisar abrir o perfil do contato." })])]);
    var contactSelect = el("select", { "aria-label": "Contato da nota" }, [el("option", { value: "", text: "Selecione o contato" })]);
    members.forEach(function (member) {
      var contact = member.item.contact || {};
      contactSelect.appendChild(el("option", { value: member.item.id, text: (contact.name || displayPhone(contact.phoneNumber) || "Contato") + " · " + (member.col.title || "Etapa") }));
    });
    var titleInput = el("input", { type: "text", maxlength: "120", placeholder: "Título opcional", "aria-label": "Título da nota" });
    var noteInput = el("textarea", { rows: "4", maxlength: "4000", placeholder: "Escreva a nota...", "aria-label": "Conteúdo da nota" });
    var cancelBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" });
    var saveBtn = el("button", { type: "submit", class: "extui-btn extui-btn--primary", text: "Salvar nota" });
    var composerActions = el("div", { class: "extuiCrmNotesComposerActions" }, [cancelBtn, saveBtn]);
    composer.appendChild(composerHead); composer.appendChild(contactSelect); composer.appendChild(titleInput); composer.appendChild(noteInput); composer.appendChild(composerActions);
    wrap.appendChild(composer);
    var editingNote = null;
    function closeComposer() { composer.hidden = true; editingNote = null; contactSelect.disabled = false; contactSelect.value = ""; titleInput.value = ""; noteInput.value = ""; composerHead.querySelector("strong").textContent = "Nova nota"; saveBtn.textContent = "Salvar nota"; }
    function openComposer(contactId, note) {
      editingNote = note ? { contactId: contactId, noteId: note.id } : null;
      composer.hidden = false;
      contactSelect.disabled = !!editingNote;
      contactSelect.value = contactId || "";
      titleInput.value = note && note.title || "";
      noteInput.value = note && note.text || "";
      composerHead.querySelector("strong").textContent = editingNote ? "Editar nota" : "Nova nota";
      saveBtn.textContent = editingNote ? "Salvar alteração" : "Salvar nota";
      requestAnimationFrame(function () { if (!contactSelect.value && !editingNote) contactSelect.focus(); else noteInput.focus(); composer.scrollIntoView({ block: "nearest", behavior: "smooth" }); });
    }
    newNoteBtn.addEventListener("click", function () { openComposer("", null); });
    cancelBtn.addEventListener("click", closeComposer);
    composer.addEventListener("submit", async function (event) {
      event.preventDefault();
      var contactId = editingNote ? editingNote.contactId : contactSelect.value;
      var text = noteInput.value.trim();
      if (!contactId) { contactSelect.focus(); toast("Selecione o contato da nota.", true); return; }
      if (!text) { noteInput.focus(); toast("Escreva o conteúdo da nota.", true); return; }
      saveBtn.disabled = true;
      try {
        if (editingNote) await saveProfileOperation({ type: "note.update", crmContactId: contactId, noteId: editingNote.noteId, patch: { title: titleInput.value.trim(), text: text, author: localAuthor() } });
        else await saveProfileOperation({ type: "note.add", crmContactId: contactId, note: { title: titleInput.value.trim(), text: text, author: localAuthor() } });
      } finally { saveBtn.disabled = false; }
    });

    var list = el("div", { class: "extuiCrmNotesList" }); wrap.appendChild(list);
    function paint() {
      var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
      var normalizeSearch = formHelpers ? formHelpers.normalizeSearch : function (value) { return String(value || "").trim().toLowerCase(); };
      list.innerHTML = ""; var q = normalizeSearch(searchInput.value);
      var filtered = rows.filter(function (r) {
        var hay = normalizeSearch([r.item.contact && r.item.contact.name, r.item.contact && r.item.contact.phoneNumber, r.col.title, r.note.title, r.note.text, r.note.author].join(" "));
        return !q || hay.indexOf(q) !== -1;
      });
      if (!filtered.length) {
        list.appendChild(el("div", { class: "extuiCrmNotesEmpty" }, [el("strong", { text: q ? "Nenhuma nota encontrada" : "Nenhuma nota neste CRM" }), el("p", { text: q ? "Tente outro termo de busca." : "Use + Nova nota para registrar a primeira anotação deste CRM." })])); return;
      }
      filtered.forEach(function (r) {
        var card = el("article", { class: "extuiCrmNoteCard" });
        var head = el("div", { class: "extuiCrmNoteCardHead" }, [
          renderAvatarEl(r.item.contact, "extui-avatar--card"),
          el("div", { class: "extuiCrmNoteCardIdentity" }, [el("strong", { text: r.item.contact.name || "Contato" }), el("span", { text: (r.col.title || "Etapa") + " · " + displayPhone(r.item.contact.phoneNumber) })]),
          el("time", { text: fmtOverviewAgo(r.note.updatedAtMs || r.note.createdAtMs) || "" })
        ]);
        card.appendChild(head);
        if (r.note.title) card.appendChild(el("strong", { class: "extuiCrmNoteCardTitle", text: r.note.title }));
        card.appendChild(el("p", { class: "extuiCrmNoteCardText", text: r.note.text || "" }));
        var foot = el("div", { class: "extuiCrmNoteCardFoot" }, [el("span", { text: r.note.author || "Usuário local" })]);
        var edit = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Editar" });
        edit.addEventListener("click", function () { openComposer(r.contactId, r.note); });
        var remove = el("button", { type: "button", class: "extui-btn extui-btn--danger", text: "Excluir" });
        remove.addEventListener("click", async function () { if (await extConfirm("Excluir esta nota?", { danger: true })) await saveProfileOperation({ type: "note.remove", crmContactId: r.contactId, noteId: r.note.id }); });
        var open = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Abrir perfil" });
        open.addEventListener("click", function () { renderContactProfile(r.contactId, false, false, "notes"); });
        foot.appendChild(edit); foot.appendChild(remove); foot.appendChild(open); card.appendChild(foot); list.appendChild(card);
      });
    }
    searchInput.addEventListener("input", paint); paint();
  }

  function disposeKanbanNavigation() {
    if (kanbanResizeObserver) {
      try { kanbanResizeObserver.disconnect(); } catch (_) {}
      kanbanResizeObserver = null;
    }
  }

  function render() {
    disposeKanbanNavigation();
    if (!rootEl) return;
    var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
    var currentCrmId = S && S.selectedCrmId ? String(S.selectedCrmId) : "";
    var preserve = lastRenderedView === crmView && lastRenderedCrmId === currentCrmId;
    var viewState = preserve && formHelpers ? formHelpers.captureView(rootEl) : null;
    applyCrmExpandedMode();
    Array.prototype.slice.call(rootEl.children).forEach(function (child) {
      if (child.classList && child.classList.contains("extuiCrmSection")) child.remove();
    });
    var app = el("div", { class: "extuiCrmSection" + (crmExpanded ? " extuiCrmSection--expanded" : ""), "data-extui-academy-target": "crm-overview" });
    rootEl.appendChild(app);
    if (crmView === "hub") renderCrmHub(app);
    else if (crmView === "kanban") renderKanbanBody(app);
    else if (crmView === "notes") renderCrmNotesBody(app);
    else renderOverviewBody(app);
    lastRenderedView = crmView;
    lastRenderedCrmId = currentCrmId;
    if (viewState && formHelpers) requestAnimationFrame(function () { if (rootEl && rootEl.isConnected) formHelpers.restoreView(rootEl, viewState); });
  }

  function crmContactCount(crm) {
    return (crm && crm.columns || []).reduce(function (sum, c) { return sum + (c.items || []).length; }, 0);
  }
  function sortCrmCards(list) {
    var rows = list.slice();
    if (crmHubSort === "alphabetical") rows.sort(function (a,b) { return String(a.name||"").localeCompare(String(b.name||""), "pt-BR", { sensitivity:"base" }); });
    else if (crmHubSort === "oldest") rows.sort(function (a,b) { return Number(a.createdAtInMs||0)-Number(b.createdAtInMs||0); });
    else if (crmHubSort === "contacts") rows.sort(function (a,b) { return crmContactCount(b)-crmContactCount(a) || String(a.name||"").localeCompare(String(b.name||""),"pt-BR"); });
    else rows.sort(function (a,b) { return Number(b.createdAtInMs||0)-Number(a.createdAtInMs||0); });
    return rows;
  }
  function renderCrmCard(crm, archived) {
    var total = crmContactCount(crm);
    var card = el("article", { class: "extuiCrmHubCard" + (crm.id === S.selectedCrmId && !archived ? " selected" : "") + (archived ? " archived" : ""), tabindex: archived ? "-1" : "0", role: archived ? "group" : "button", "aria-label": (archived ? "CRM arquivado " : "Abrir CRM ") + crm.name, style: "--extui-crm-accent:" + (crm.hexColor || "#eab308") });
    card.appendChild(el("div", { class: "extuiCrmHubCardAccent" }));
    var head = el("div", { class: "extuiCrmHubCardHead" });
    head.appendChild(el("span", { class: "extuiCrmHubCardDot" }));
    head.appendChild(el("span", { class: "extuiCrmHubCardState", text: archived ? "Arquivado" : (crm.pinned ? "Fixado" : (crm.id === S.selectedCrmId ? "Selecionado" : "CRM")) }));
    if (!archived) {
      var pinBtn = el("button", { class: "extuiCrmCardIconBtn" + (crm.pinned ? " active" : ""), type: "button", title: crm.pinned ? "Desafixar CRM" : "Fixar CRM", "aria-label": (crm.pinned ? "Desafixar " : "Fixar ") + crm.name }, [icon("pin")]);
      pinBtn.addEventListener("click", function(event){ event.stopPropagation(); toggleCrmPin(crm); }); head.appendChild(pinBtn);
    }
    card.appendChild(head);
    card.appendChild(el("h3", { text: crm.name || "CRM" }));
    card.appendChild(el("p", { text: crm.description || "Sem descrição." }));
    card.appendChild(el("div", { class: "extuiCrmHubCardStats" }, [el("span", { text: String((crm.columns || []).length) + ((crm.columns || []).length === 1 ? " lista" : " listas") }), el("span", { text: String(total) + (total === 1 ? " contato" : " contatos") })]));
    var actions = el("div", { class: "extuiCrmHubCardButtons" });
    if (archived) {
      var restore = el("button", { class: "extui-btn extui-btn--ghost", type: "button", title: "Desarquivar CRM" }, [icon("restore"), el("span", { text: "Desarquivar" })]);
      restore.addEventListener("click", async function(event){ event.stopPropagation(); await setCrmArchived(crm,false); toast("CRM restaurado."); }); actions.appendChild(restore);
    } else {
      var archiveBtn = el("button", { class: "extuiCrmCardIconBtn", type: "button", title: "Arquivar CRM", "aria-label": "Arquivar CRM " + crm.name }, [icon("archive")]);
      archiveBtn.addEventListener("click", async function(event){ event.stopPropagation(); await setCrmArchived(crm,true); toast("CRM arquivado."); }); actions.appendChild(archiveBtn);
    }
    var editBtn = el("button", { class: "extuiCrmCardIconBtn", type: "button", title: "Editar CRM", "aria-label": "Editar CRM " + crm.name }, [icon("edit")]); editBtn.addEventListener("click", function(event){ event.stopPropagation(); openEditCrmModal(crm); }); actions.appendChild(editBtn);
    var duplicateBtn = el("button", { class: "extuiCrmCardIconBtn", type: "button", title: "Duplicar CRM", "aria-label": "Duplicar CRM " + crm.name }, [icon("copy")]); duplicateBtn.addEventListener("click", function(event){ event.stopPropagation(); openDuplicateCrmModal(crm); }); actions.appendChild(duplicateBtn);
    var deleteBtn = el("button", { class: "extuiCrmCardIconBtn danger", type: "button", title: "Excluir CRM", "aria-label": "Excluir CRM " + crm.name }, [icon("trash")]); deleteBtn.addEventListener("click", function(event){ event.stopPropagation(); openCrmDeleteDialog(crm); }); actions.appendChild(deleteBtn);
    card.appendChild(actions);
    if (!archived) card.appendChild(el("div", { class: "extuiCrmHubCardAction" }, [el("span", { text: "Abrir CRM" }), icon("arrowLeft", "extuiCrmHubCardArrow") ]));
    var openCard = function () { if (archived) return; boardFilterTerm = ""; crmView = "kanban"; if (S.selectedCrmId === crm.id) render(); else mutate(function (state) { state.selectedCrmId = crm.id; }); };
    card.addEventListener("click", openCard); card.addEventListener("keydown", function(event){ if ((event.key === "Enter" || event.key === " ") && event.target === card) { event.preventDefault(); openCard(); } });
    return card;
  }
  function renderCrmHub(app) {
    var selected = getSelectedCrm(), activeCrms = getActiveCrms(), archivedCrms = getArchivedCrms();
    var editTop = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Editar CRM" }); editTop.disabled=!selected; editTop.addEventListener("click", function(){ if(selected) openEditCrmModal(selected); });
    var archiveTop = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Arquivar" }); archiveTop.disabled=!selected; archiveTop.addEventListener("click", async function(){ if(selected){ await setCrmArchived(selected,true); toast("CRM arquivado."); } });
    var deleteTop = el("button", { class: "extui-btn extui-btn--ghost extuiCrmHubDelete", type: "button", text: "Excluir CRM" }); deleteTop.disabled=!selected; deleteTop.addEventListener("click", function(){ if(selected) openCrmDeleteDialog(selected); });
    var createBtn = el("button", { class: "extui-btn extui-btn--primary", type: "button" }, [icon("plus"), el("span", { text: "Criar novo CRM" })]); createBtn.addEventListener("click", openCreateCrmModal);
    app.appendChild(el("div", { class: "extui-topbar extuiCrmHubTopbar" }, [renderExpandedBackButton(), el("div", { class: "extui-topbar__title", text: "CRM" }), renderBoardSelector(), renderViewToggle(), el("div", { class: "extui-topbar__spacer" }), renderExpandButton(), editTop, archiveTop, deleteTop, (activeCrms.length || archivedCrms.length) ? createBtn : null].filter(Boolean)));

    var hub = el("section", { class: "extuiCrmHub", "aria-label": "Seus CRMs" });
    var sort = el("select", { class: "extuiCrmHubSort", "aria-label": "Ordenar CRMs" }, [
      el("option", { value:"recent", text:"Mais recentes" }), el("option", { value:"oldest", text:"Mais antigos" }), el("option", { value:"alphabetical", text:"Ordem alfabética" }), el("option", { value:"contacts", text:"Mais contatos" })
    ]); sort.value=crmHubSort; sort.addEventListener("change", function(){ crmHubSort=sort.value; paintHubCards(); });
    hub.appendChild(el("div", { class: "extuiCrmHubControls" }, [
      el("div", { class: "extuiCrmHubCount", text: String(activeCrms.length) + (activeCrms.length === 1 ? " CRM ativo" : " CRMs ativos") }),
      el("div", { class: "extuiCrmHubControlsActions" }, [sort])
    ]));
    if (!activeCrms.length && !archivedCrms.length) {
      var empty = el("div", { class: "extuiCrmHubEmpty" }, [icon("layoutGrid", "extuiCrmHubEmptyIcon"), el("h3", { text: "Nenhum CRM criado ainda" }), el("p", { text: "Crie seu primeiro CRM e organize os contatos em etapas do seu processo comercial." })]); var first=el("button",{class:"extui-btn extui-btn--primary",type:"button",text:"+ Criar meu primeiro CRM"}); first.addEventListener("click",openCreateCrmModal); empty.appendChild(first); hub.appendChild(empty); app.appendChild(hub); return;
    }
    var cardsHost = el("div", { class: "extuiCrmHubCardsHost" });
    hub.appendChild(cardsHost);
    function paintHubCards() {
      cardsHost.innerHTML = "";
      var pinned=sortCrmCards(activeCrms.filter(function(c){return !!c.pinned;})), others=sortCrmCards(activeCrms.filter(function(c){return !c.pinned;}));
      function addGroup(title,list,klass){ if(!list.length)return; var group=el("div",{class:"extuiCrmHubGroup "+klass}); if(title) group.appendChild(el("div",{class:"extuiCrmHubGroupTitle",text:title})); var grid=el("div",{class:"extuiCrmHubGrid"}); list.forEach(function(crm){grid.appendChild(renderCrmCard(crm,false));}); group.appendChild(grid); cardsHost.appendChild(group); }
      if(pinned.length){ addGroup("Fixados",pinned,"extuiCrmHubGroup--pinned"); if(others.length) cardsHost.appendChild(el("div",{class:"extuiCrmHubDivider"},[el("span",{text:"Outros CRMs"})])); }
      addGroup(pinned.length?"":null,others,"extuiCrmHubGroup--others");
      if(archivedCrms.length){ var archivedSection=el("section",{class:"extuiCrmArchivedSection"}); archivedSection.appendChild(el("div",{class:"extuiCrmArchivedHeader"},[el("div",{},[el("span",{class:"extuiCrmHubEyebrow",text:"ARQUIVO"}),el("h3",{text:"CRMs arquivados"}),el("p",{text:"Ficam fora dos seletores e indicadores até serem restaurados."})]),el("span",{class:"extuiCrmHubCount",text:String(archivedCrms.length)})])); var archivedGrid=el("div",{class:"extuiCrmHubGrid"}); sortCrmCards(archivedCrms).forEach(function(crm){archivedGrid.appendChild(renderCrmCard(crm,true));}); archivedSection.appendChild(archivedGrid); cardsHost.appendChild(archivedSection); }
    }
    paintHubCards();
    app.appendChild(hub);
  }

                                                                           
                                                                          
                                      
  function renderKanbanBody(app) {
                                                                           
                                                                           
                                                                             
                                                  
    var toggleBtn = el("button", {
      class: "extui-icon-btn", title: contactsPanelVisible ? "Ocultar contatos do WhatsApp" : "Mostrar contatos do WhatsApp",
      "aria-label": contactsPanelVisible ? "Ocultar contatos do WhatsApp" : "Mostrar contatos do WhatsApp"
    }, [icon(contactsPanelVisible ? "eyeOff" : "eye")]);
    toggleBtn.addEventListener("click", function () { contactsPanelVisible = !contactsPanelVisible; render(); });

    var exportBtn = el("button", { class: "extui-icon-btn", title: "Exportar Contatos", "aria-label": "Exportar Contatos" }, [icon("download")]);
    exportBtn.addEventListener("click", openExportContactsModal);
    var fieldsBtn = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Configurar campos" });
    fieldsBtn.addEventListener("click", openFieldManager);

    var searchWrap = el("div", { class: "extuiSearch extui-boardsearch" }, [icon("search")]);
    var searchInput = el("input", { type: "text", placeholder: "Buscar contato no quadro...", "aria-label": "Buscar contato no quadro" });
    searchInput.value = boardFilterTerm;
    searchInput.addEventListener("input", function () {
                                                                          
                                                                         
                                                                          
                                                                   
      boardFilterTerm = searchInput.value;
      render();
      var freshInput = document.querySelector(".extui-boardsearch input");
      if (freshInput) { freshInput.value = boardFilterTerm; freshInput.focus(); freshInput.setSelectionRange(freshInput.value.length, freshInput.value.length); }
    });
    searchWrap.appendChild(searchInput);

    var topbar = el("div", { class: "extui-topbar" }, [
      renderExpandedBackButton(),
      el("div", { class: "extui-topbar__title", text: "CRM" }),
      renderBoardSelector(),
      renderViewToggle(),
      renderProfessionalFilters(getSelectedCrm()),
      searchWrap,
      el("div", { class: "extui-topbar__spacer" }),
      renderExpandButton(),
      renderCrmQuickActions(),
      el("div", { class: "extui-topbar__utils" }, [fieldsBtn, exportBtn, toggleBtn])
    ].filter(Boolean));
    app.appendChild(topbar);
    var selectedCrmForSummary = getSelectedCrm();
    if (selectedCrmForSummary) app.appendChild(renderKanbanOperationalSummary(selectedCrmForSummary));

    var main = el("div", { class: "extui-main" });
    if (contactsPanelVisible) main.appendChild(renderContactsPanel());

    var crm = getSelectedCrm();
    var boardShell = el("div", { class: "extui-board-shell" });
    var board = el("div", { class: "extui-board extui-board--docked" });

    if (!crm) {
      board.appendChild(el("div", { class: "extui-empty" }, [
        icon("users", "extui-empty__icon"),
        el("h2", { text: "Nenhum CRM criado ainda" }),
        el("p", { text: "Crie seu primeiro quadro de CRM para organizar seus contatos em listas, tipo um funil de vendas." }),
      ]));
      var createBtn = el("button", { class: "extui-btn extui-btn--primary", text: "+ Criar meu primeiro CRM" });
      createBtn.addEventListener("click", openCreateCrmModal);
      board.querySelector(".extui-empty").appendChild(createBtn);
    } else {
      crm.columns.forEach(function (col) { board.appendChild(renderColumn(col)); });
      board.appendChild(renderAddColumn());
    }
    boardShell.appendChild(board);
    var scrollDock=el("div",{class:"extui-board-scroll-dock","aria-label":"Rolagem horizontal do Kanban"}),scrollDockInner=el("div",{class:"extui-board-scroll-dock__inner"});scrollDock.appendChild(scrollDockInner);boardShell.appendChild(scrollDock);main.appendChild(boardShell);app.appendChild(main);
    (function setupKanbanHorizontalNavigation(){var syncing=false,grabbing=false,startX=0,startScroll=0,pointerId=null;function syncSize(){if(!board.isConnected)return;scrollDockInner.style.width=Math.max(board.scrollWidth,board.clientWidth)+"px";scrollDock.classList.toggle("is-active",board.scrollWidth>board.clientWidth+2);if(!syncing){syncing=true;scrollDock.scrollLeft=board.scrollLeft;syncing=false;}}board.addEventListener("scroll",function(){if(syncing)return;syncing=true;scrollDock.scrollLeft=board.scrollLeft;syncing=false;},{passive:true});scrollDock.addEventListener("scroll",function(){if(syncing)return;syncing=true;board.scrollLeft=scrollDock.scrollLeft;syncing=false;},{passive:true});board.addEventListener("pointerdown",function(ev){if(ev.button!==1)return;ev.preventDefault();grabbing=true;pointerId=ev.pointerId;startX=ev.clientX;startScroll=board.scrollLeft;board.classList.add("is-middle-grabbing");try{board.setPointerCapture(ev.pointerId);}catch(_){};});board.addEventListener("pointermove",function(ev){if(!grabbing||ev.pointerId!==pointerId)return;ev.preventDefault();board.scrollLeft=startScroll-(ev.clientX-startX);});function release(ev){if(!grabbing||(ev&&pointerId!==null&&ev.pointerId!==pointerId))return;grabbing=false;pointerId=null;board.classList.remove("is-middle-grabbing");}board.addEventListener("pointerup",release);board.addEventListener("pointercancel",release);board.addEventListener("auxclick",function(ev){if(ev.button===1)ev.preventDefault();});requestAnimationFrame(syncSize);if(window.ResizeObserver){if(kanbanResizeObserver){try{kanbanResizeObserver.disconnect();}catch(_){}}kanbanResizeObserver=new ResizeObserver(syncSize);kanbanResizeObserver.observe(board);kanbanResizeObserver.observe(boardShell);}})();
  }

                                                                           
                                                        
                                                                           
                                                                          
                                                                         
                                                              
                                                                            
                                                                         
                                                                        
                                                                    
                                                                      
  function parsePlainOverview(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (err) { return null; }
  }
  function storageGetOverview(key) {
    return new Promise(function (resolve) { chrome.storage.local.get(key, function (res) { resolve(res && res[key]); }); });
  }
  function fmtOverviewWhen(ms) {
    if (!ms) return "";
    var d = new Date(ms), now = new Date();
    var hm = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
    if (d.toDateString() === now.toDateString()) return "Hoje, " + hm;
    return String(d.getDate()).padStart(2, "0") + "/" + String(d.getMonth() + 1).padStart(2, "0") + ", " + hm;
  }
  function fmtOverviewAgo(ms) {
    if (!ms) return "";
    var diff = Date.now() - ms;
    if (diff < 60000) return "agora";
    if (diff < 3600000) return "há " + Math.round(diff / 60000) + " min";
    if (diff < 86400000) return "há " + Math.round(diff / 3600000) + "h";
    return "há " + Math.round(diff / 86400000) + "d";
  }

  async function fetchOverviewAgenda() {
    var parsed = parsePlainOverview(await storageGetOverview("EXTUI:extappScheduleStore"));
    var list = (parsed && Array.isArray(parsed.list)) ? parsed.list : [];
    var now = new Date();
    var todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    var todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
    var scheduled = list.filter(function (i) { return i.status === "scheduled"; });
    var todayCount = scheduled.filter(function (i) { return i.scheduleAtMs >= todayStart && i.scheduleAtMs < todayEnd; }).length;
    var upcoming = scheduled.sort(function (a, b) { return (a.scheduleAtMs || 0) - (b.scheduleAtMs || 0); }).slice(0, 5);
    return { todayCount: todayCount, upcoming: upcoming };
  }

  async function fetchOverviewAutomations() {
    var rows = [], activeCount = 0;
    try {
      var flowsRaw = parsePlainOverview(await storageGetOverview("EXTUI:extappFlowStore"));
      var flowList = (flowsRaw && (flowsRaw.flowList || (flowsRaw.state && flowsRaw.state.flowList))) || [];
      flowList.forEach(function (f) { if (f.isActive) activeCount++; });
      flowList.slice(0, 4).forEach(function (f) { rows.push({ name: f.name || "Fluxo", active: !!f.isActive, type: "Fluxo" }); });
    } catch (err) {                            }
    try {
      var funnelsRaw = parsePlainOverview(await storageGetOverview("EXTUI:extappFunnelStore"));
      var funnelList = (funnelsRaw && (funnelsRaw.funnelList || (funnelsRaw.state && funnelsRaw.state.funnelList))) || [];
      funnelList.forEach(function (f) { if (f.isActive) activeCount++; });
    } catch (err) {                            }
    try {
      var followupRaw = parsePlainOverview(await storageGetOverview("EXTUI:extappFollowUpStore"));
      var followupList = (followupRaw && (followupRaw.list || (followupRaw.state && followupRaw.state.list))) || [];
      followupList.forEach(function (r) { if (r.active) activeCount++; });
                                                                            
                   
      followupList.slice(0, 3).forEach(function (r) { rows.push({ name: r.nome || "Regra de FollowUp", active: !!r.active, type: "FollowUp" }); });
    } catch (err) {                            }
    return { activeCount: activeCount, rows: rows.slice(0, 6) };
  }

  async function fetchOverviewActivity() {
    try {
      var raw = await storageGetOverview("EXTUI:extappActivityStore");
      return Array.isArray(raw) ? raw.slice(0, 6) : [];
    } catch (err) { return []; }
  }

  function renderOverviewKpiCard(iconName, value, label) {
    return el("div", { class: "extuiOvKpi" }, [
      el("div", { class: "extuiOvKpi__icon" }, [icon(iconName)]),
      el("div", { class: "extuiOvKpi__text" }, [
        el("div", { class: "extuiOvKpi__value", text: String(value) }),
        el("div", { class: "extuiOvKpi__label", text: label })
      ])
    ]);
  }

  function renderOverviewPanel(titleText, iconName, bodyEl) {
    return el("div", { class: "extuiOvPanel" }, [
      el("div", { class: "extuiOvPanel__head" }, [icon(iconName, "extuiOvPanel__headIcon"), el("h3", { text: titleText })]),
      bodyEl
    ]);
  }

  function renderOverviewBody(app) {
    var crm = getSelectedCrm();
    var fieldsBtn = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Configurar campos" });
    fieldsBtn.addEventListener("click", openFieldManager);

    var searchWrap = el("div", { class: "extuiSearch extui-boardsearch" }, [icon("search")]);
    var searchInput = el("input", { type: "text", placeholder: "Buscar contato...", "aria-label": "Buscar contato" });
    searchInput.value = boardFilterTerm;
    searchInput.addEventListener("input", function () {
      boardFilterTerm = searchInput.value;
      render();
      var freshInput = document.querySelector(".extuiOverview .extui-boardsearch input");
      if (freshInput) { freshInput.value = boardFilterTerm; freshInput.focus(); freshInput.setSelectionRange(freshInput.value.length, freshInput.value.length); }
    });
    searchWrap.appendChild(searchInput);

    var topbar = el("div", { class: "extui-topbar" }, [
      renderExpandedBackButton(),
      el("div", { class: "extui-topbar__title", text: "CRM" }),
      renderBoardSelector(),
      renderViewToggle(),
      renderProfessionalFilters(crm),
      fieldsBtn,
      el("div", { class: "extui-topbar__spacer" }),
      renderExpandButton(),
      renderCrmQuickActions()
    ].filter(Boolean));
    app.appendChild(topbar);

    var wrap = el("div", { class: "extuiOverview" });
    app.appendChild(wrap);

    if (!crm) {
      wrap.appendChild(el("div", { class: "extui-empty" }, [
        icon("users", "extui-empty__icon"),
        el("h2", { text: "Nenhum CRM criado ainda" }),
        el("p", { text: "Crie seu primeiro quadro de CRM para organizar seus contatos em listas, tipo um funil de vendas." }),
      ]));
      var createBtn2 = el("button", { class: "extui-btn extui-btn--primary", text: "+ Criar meu primeiro CRM" });
      createBtn2.addEventListener("click", openCreateCrmModal);
      wrap.querySelector(".extui-empty").appendChild(createBtn2);
      return;
    }

    var contactCount = crm.columns.reduce(function (sum, c) { return sum + c.items.length; }, 0);
    var boardSummary = professionalCore ? professionalCore.createDashboardSummary(S, professionalStore, { boardId: crm.id, now: Date.now() }) : { openTaskCount: 0, overdueTaskCount: 0 };
    var kpiRow = el("div", { class: "extuiOvKpiRow" }, [
      renderOverviewKpiCard("users", contactCount, contactCount === 1 ? "Contato no CRM" : "Contatos no CRM"),
      renderOverviewKpiCard("layoutGrid", crm.columns.length, crm.columns.length === 1 ? "Lista" : "Listas"),
      renderOverviewKpiCard("check", boardSummary.openTaskCount, "Tarefas pendentes"),
      renderOverviewKpiCard("activity", boardSummary.overdueTaskCount, "Tarefas atrasadas"),
      renderOverviewKpiCard("calendar", "…", "Agendamentos hoje"),
      renderOverviewKpiCard("zap", "…", "Automações ativas")
    ]);
    wrap.appendChild(kpiRow);

    var grid = el("div", { class: "extuiOvGrid" });
    wrap.appendChild(grid);

                                                                           
    var tableCard = el("div", { class: "extuiOvTableCard" });
    var tableHead = el("div", { class: "extuiOvTableCard__head" }, [el("h3", { text: "Base de contatos" }), searchWrap]);
    tableCard.appendChild(tableHead);

    var rowsData = [];
    crm.columns.forEach(function (col) {
      col.items.forEach(function (item) { if (contactPassesFilters(col, item)) rowsData.push({ col: col, item: item }); });
    });
    var formHelpers = window.ExtensionCore && window.ExtensionCore.FormHelpers;
    var normalizeSearch = formHelpers ? formHelpers.normalizeSearch : function (value) { return String(value || "").trim().toLowerCase(); };
    var q = normalizeSearch(boardFilterTerm);
    if (q) {
      rowsData = rowsData.filter(function (r) {
        return normalizeSearch(r && r.item && r.item.contact && r.item.contact.name).indexOf(q) !== -1 ||
          normalizeSearch(r && r.item && r.item.contact && r.item.contact.phoneNumber).indexOf(q) !== -1;
      });
    }

    if (rowsData.length === 0) {
      tableCard.appendChild(el("div", { class: "extuiOvTableEmpty", text: q ? "Nenhum contato encontrado." : "Nenhum contato nas listas deste CRM ainda." }));
    } else {
      var table = el("table", { class: "extuiOvTable" });
      var thead = el("thead", {}, [el("tr", {}, [
        el("th", { text: "Contato" }), el("th", { text: "WhatsApp" }), el("th", { text: "Lista" }), el("th", { text: "Follow-up" }), el("th", { text: "" })
      ])]);
      table.appendChild(thead);
      var tbody = el("tbody");
      rowsData.forEach(function (r) {
        var item = r.item, col = r.col;
        var tr = el("tr", { tabindex: "0", "data-extui-academy-target": "crm-contact" });
        var nameCell = el("td", { class: "extuiOvTable__contact" }, [
          renderAvatarEl(item.contact, "extui-avatar--card"),
          contactNameNode(item.contact, "extuiOvContactName")
        ]);
        tr.appendChild(nameCell);
        tr.appendChild(el("td", { text: displayPhone(item.contact.phoneNumber), class: item.contact.phoneNumber ? "" : "extui-muted-null" }));
        tr.appendChild(el("td", {}, [el("span", { class: "extuiOvListPill", style: "--extui-pill-c:" + col.color, text: col.title })]));
        tr.appendChild(el("td", { text: item.nextContactAtMs ? fmtOverviewWhen(item.nextContactAtMs) : "—", class: item.nextContactAtMs && item.nextContactAtMs < Date.now() ? "extuiOvOverdue" : "" }));
        var actionsCell = el("td", { class: "extuiOvTable__actions" });
        var waBtn = el("button", { class: "extui-icon-btn", title: "Abrir no WhatsApp", "aria-label": "Abrir " + item.contact.name + " no WhatsApp" }, [icon("chat")]);
        waBtn.addEventListener("click", function () {
          if (!item.contact.phoneNumber) { toast("Este contato não tem um telefone resolvido.", true); return; }
          openWhatsApp(item.contact.phoneNumber);
        });
        actionsCell.appendChild(waBtn);
        tr.appendChild(actionsCell);
        tr.addEventListener("click", function (e) { if (!e.target.closest(".extuiOvTable__actions")) openContactDetailsModal(col, item); });
        tr.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openContactDetailsModal(col, item); } });
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      var tableScroll = el("div", { class: "extuiOvTableScroll" }, [table]);
      tableCard.appendChild(tableScroll);
    }
    grid.appendChild(tableCard);

                                                                           
    var sidebar = el("div", { class: "extuiOvSidebar" });

    var agendaBody = el("div", { class: "extuiOvPanelList", text: "Carregando..." });
    sidebar.appendChild(renderOverviewPanel("Agenda de hoje", "calendar", agendaBody));

    var automationsBody = el("div", { class: "extuiOvPanelList", text: "Carregando..." });
    sidebar.appendChild(renderOverviewPanel("Automações", "zap", automationsBody));

    var activityBody = el("div", { class: "extuiOvPanelList", text: "Carregando..." });
    sidebar.appendChild(renderOverviewPanel("Atividade recente", "activity", activityBody));

    grid.appendChild(sidebar);

                                                                           
    var maxItems = crm.columns.reduce(function (max, c) { return Math.max(max, c.items.length); }, 0) || 1;
    var firstStageCount = crm.columns[0] && crm.columns[0].items ? crm.columns[0].items.length : 0;
    var lastStage = crm.columns.length ? crm.columns[crm.columns.length - 1] : null;
    var lastStageCount = lastStage && lastStage.items ? lastStage.items.length : 0;
    var conversionRate = firstStageCount ? (lastStageCount / firstStageCount) * 100 : 0;
    var funnelCard = el("div", { class: "extuiOvFunnelCard" });
    var funnelAction = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuiOvFunnelAction" }, [icon("funnel"), el("span", { text: "Ver análise completa" })]);
    funnelAction.addEventListener("click", openCrmAnalysis);
    funnelCard.appendChild(el("div", { class: "extuiOvFunnelHead" }, [
      el("div", {}, [el("h3", { text: "Desempenho do funil" }), el("p", { text: "Acompanhe a distribuição das etapas e descubra onde a conversão está acontecendo." })]),
      funnelAction
    ]));
    funnelCard.appendChild(el("div", { class: "extuiOvFunnelSummary" }, [
      el("div", {}, [el("strong", { text: String(contactCount) }), el("span", { text: "contatos" })]),
      el("div", {}, [el("strong", { text: String(crm.columns.length) }), el("span", { text: crm.columns.length === 1 ? "etapa" : "etapas" })]),
      el("div", {}, [el("strong", { text: conversionRate.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) + "%" }), el("span", { text: "conversão" })])
    ]));
    var funnelRows = el("div", { class: "extuiOvFunnelRows" });
    crm.columns.forEach(function (col) {
      var pct = Math.round((col.items.length / maxItems) * 100);
      funnelRows.appendChild(el("div", { class: "extuiOvFunnelRow" }, [
        el("div", { class: "extuiOvFunnelRow__label" }, [el("span", { text: col.title }), el("span", { class: "extuiOvFunnelRow__count", text: String(col.items.length) })]),
        el("div", { class: "extuiOvFunnelRow__track" }, [el("div", { class: "extuiOvFunnelRow__fill", style: "width:" + pct + "%;background:" + col.color })])
      ]));
    });
    funnelCard.appendChild(funnelRows);
    wrap.appendChild(funnelCard);

                                                                           
    fetchOverviewAgenda().then(function (data) {
      var kpi = kpiRow.children[4].querySelector(".extuiOvKpi__value");
      if (kpi) kpi.textContent = String(data.todayCount);
      agendaBody.textContent = "";
      if (data.upcoming.length === 0) { agendaBody.appendChild(el("div", { class: "extuiOvPanelEmpty", text: "Nenhum agendamento próximo." })); return; }
      data.upcoming.forEach(function (i) {
        agendaBody.appendChild(el("div", { class: "extuiOvPanelRow" }, [
          el("span", { class: "extuiOvPanelRow__title", text: i.itemName || "Item agendado" }),
          el("span", { class: "extuiOvPanelRow__meta", text: fmtOverviewWhen(i.scheduleAtMs) })
        ]));
      });
    }).catch(function (err) { agendaBody.textContent = "Não foi possível carregar."; });

    fetchOverviewAutomations().then(function (data) {
      var kpi = kpiRow.children[5].querySelector(".extuiOvKpi__value");
      if (kpi) kpi.textContent = String(data.activeCount);
      automationsBody.textContent = "";
      if (data.rows.length === 0) { automationsBody.appendChild(el("div", { class: "extuiOvPanelEmpty", text: "Nenhuma automação configurada ainda." })); return; }
      data.rows.forEach(function (r) {
        automationsBody.appendChild(el("div", { class: "extuiOvPanelRow" }, [
          el("span", { class: "extuiOvPanelRow__title", text: r.name }),
          el("span", { class: "extuiOvBadgeDot" + (r.active ? " on" : "") })
        ]));
      });
    }).catch(function (err) { automationsBody.textContent = "Não foi possível carregar."; });

    fetchOverviewActivity().then(function (list) {
      activityBody.textContent = "";
      if (list.length === 0) { activityBody.appendChild(el("div", { class: "extuiOvPanelEmpty", text: "Nenhuma atividade ainda." })); return; }
      list.forEach(function (a) {
        activityBody.appendChild(el("div", { class: "extuiOvPanelRow" }, [
          el("span", { class: "extuiOvPanelRow__title", text: a.title || "Operação" }),
          el("span", { class: "extuiOvPanelRow__meta", text: fmtOverviewAgo(a.updatedAt || a.startedAt) })
        ]));
      });
    }).catch(function (err) { activityBody.textContent = "Não foi possível carregar."; });
  }

                                                                         
  async function boot(expectedRoot, generation, options) {
    options = options || {};
    var loaded = await Promise.all([loadStore(), loadProfessionalStore()]);
    var nextState = loaded[0];
    var upgraded = professionalCore ? professionalCore.upgradeLegacyContactIds(nextState) : { state: nextState, changed: false };
    nextState = upgraded.state;
    var shell = window.__extDashboardShell;
    if (generation !== renderGeneration || rootEl !== expectedRoot || !expectedRoot || !expectedRoot.isConnected || !shell || shell.getCurrentSection() !== "crm") return false;
    S = nextState;
    professionalStore = loaded[1];
    if (upgraded.changed) {
      identityUpgradeSaving = true;
      await saveStore(S);
      identityUpgradeSaving = false;
    }
    var activeOnBoot = getActiveCrms();
    if (!S.selectedCrmId || !activeOnBoot.some(function (crm) { return crm.id === S.selectedCrmId; })) S.selectedCrmId = activeOnBoot[0] ? activeOnBoot[0].id : "";
    var routeIntent = null;
    if (!options.refresh) routeIntent = consumeCrmRouteIntent();
    if (routeIntent) {
      var requestedCrmId = routeIntent.crmId;
      var requestedCrmView = routeIntent.crmView;
      if (requestedCrmId && activeOnBoot.some(function (crm) { return crm.id === requestedCrmId; })) {
        S.selectedCrmId = requestedCrmId;
        crmView = ["hub", "overview", "kanban", "notes"].indexOf(requestedCrmView) !== -1 ? requestedCrmView : "kanban";
      } else if (["hub", "overview", "kanban", "notes"].indexOf(requestedCrmView) !== -1) {
        crmView = requestedCrmView;
      }
    }
    if (crmView !== "hub" && (!S.selectedCrmId || !activeOnBoot.some(function (crm) { return crm.id === S.selectedCrmId; }))) crmView = "hub";
    render();
    if (routeIntent && routeIntent.crmCreate) {
      if (crmView !== "hub") { crmView = "hub"; render(); }
      openCreateCrmModal();
    }
    var requestedContactId = routeIntent && routeIntent.crmContactId;
    if (requestedContactId && findContactMembership(requestedContactId)) renderContactProfile(requestedContactId, false, routeIntent.crmCopilot, routeIntent.crmProfileTab || "data");
    return true;
  }

  function renderCrmSection(container) {
    rootEl = container;
    var generation = ++renderGeneration;
    boardFilterTerm = "";
    crmView = pendingCrmView || "hub";
    pendingCrmView = null;
    crmExpanded = false;
    applyCrmExpandedMode();
    var ready = boot(container, generation);
                                                                        
                                                                          
                                                                             
                                                             
    if (waContacts == null && !waContactsLoading) loadWaContacts();
    return ready;
  }

  function handleCrmStorageChange(nextValue, previousValue, key, meta) {
    if (savingLock || identityUpgradeSaving || !rootEl || !rootEl.isConnected) return;
    if (key === STORAGE_KEY && meta && meta.local === true) return;
    clearTimeout(crmRefreshTimer);
    crmRefreshTimer = setTimeout(function () {
      crmRefreshTimer = 0;
      if (!rootEl || !rootEl.isConnected) return;
      var generation = ++renderGeneration;
      var activeContactId = activeProfile && activeProfile.contactId;
      boot(rootEl, generation, { refresh: true }).then(function (ready) {
        if (ready && activeContactId && activeProfile && activeProfile.contactId === activeContactId && findContactMembership(activeContactId)) renderContactProfile(activeContactId, true);
      });
    }, 50);
  }
  if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
    window.ExtensionStorage.subscribe(STORAGE_KEY, handleCrmStorageChange);
    if (professionalCore && professionalCore.STORE_KEY && professionalCore.STORE_KEY !== STORAGE_KEY) window.ExtensionStorage.subscribe(professionalCore.STORE_KEY, handleCrmStorageChange);
  }
  window.addEventListener("extui:customers-changed", handleCrmStorageChange);

  document.addEventListener("ext:dashboard-section-change", function (event) {
    if (!event.detail || event.detail.section !== "crm") {
      clearTimeout(crmRefreshTimer); crmRefreshTimer = 0;
      disposeKanbanNavigation();
      crmExpanded = false;
      applyCrmExpandedMode();
    }
  });

  document.addEventListener("ext:dashboard-section-ready", function (event) {
  });

  window.__extDashboardShell.registerSection("crm", renderCrmSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
