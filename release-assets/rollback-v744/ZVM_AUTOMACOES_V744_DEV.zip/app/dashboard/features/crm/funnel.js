;
try{
(function(){
  "use strict";
  if(window.__extCrmFunnelDashboardBooted)return;
  window.__extCrmFunnelDashboardBooted=true;
  var CRM_KEY="EXTUI:CrmStore",PRO_KEY="EXTUI:crmProfessionalStore",PROFILE_KEY="EXTUI:profileStore",PREF_KEY="EXTUI:crmFunnelAnalyticsStore";
  var containerEl=null;
  var funnelView="hub";
  var funnelExpanded=false;
  var prefs={crmId:"",metric:"contacts",chart:"pyramid",sort:"original",legend:true,defaultChartV9:true};
  function applyFunnelExpandedMode(){document.body.classList.toggle("extuiCrmFunnelExpandedMode",!!funnelExpanded);}
  function setFunnelExpanded(next){funnelExpanded=!!next;applyFunnelExpandedMode();if(containerEl&&containerEl.isConnected)render();}
  function isFunnelSectionActive(){return !!(window.__extDashboardShell&&window.__extDashboardShell.getCurrentSection&&window.__extDashboardShell.getCurrentSection()==="crm-funnel");}
  function el(tag,attrs,children){var e=document.createElement(tag);attrs=attrs||{};Object.keys(attrs).forEach(function(k){var v=attrs[k];if(k==="class")e.className=v;else if(k==="text")e.textContent=v;else if(k.indexOf("on")===0&&typeof v==="function")e.addEventListener(k.slice(2).toLowerCase(),v);else if(v!==undefined&&v!==null)e.setAttribute(k,v);});(children||[]).forEach(function(c){if(c)e.appendChild(c);});return e;}
  function parse(raw,fallback){if(raw==null)return fallback;try{var p=typeof raw==="string"?JSON.parse(raw):raw;return p&&p.state?p.state:p;}catch(_){return fallback;}}
  function digits(v){return String(v||"").replace(/\D/g,"");}
  function number(v){var n=Number(v);return Number.isFinite(n)?n:0;}
  function currency(v){try{return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(number(v));}catch(_){return "R$ "+number(v).toFixed(2).replace(".",",");}}
  function percent(v){return (Number.isFinite(v)?v:0).toLocaleString("pt-BR",{maximumFractionDigits:1})+"%";}
  function get(key){return window.ExtensionStorage.get(key);}
  function set(key,val){return window.ExtensionStorage.set(key,JSON.stringify(val));}
  function colorAt(i){return["#10b981","#38bdf8","#8b5cf6","#f59e0b","#f43f5e","#14b8a6","#eab308","#6366f1"][i%8];}
  function profileArray(raw){var p=parse(raw,[]);if(Array.isArray(p))return p;if(p&&Array.isArray(p.perfil))return p.perfil;if(p&&Array.isArray(p.list))return p.list;return[];}
  function legacyValueIndex(raw){var out={};profileArray(raw).forEach(function(p){if(!p||typeof p!=="object")return;var phone=digits(p.userID||p.phoneNumber||p.phone||p.number||p.id);if(phone.length<8)return;var v=number(p.valNegocio!=null?p.valNegocio:(p.dealValue!=null?p.dealValue:(p.valorNegocio!=null?p.valorNegocio:p.value)));if(v)out[phone]=v;});return out;}
  function professionalValue(proStore,crm,item){if(!proStore||!crm||!item)return 0;var boards=proStore.boards||{},board=boards[crm.id]||{},defs=Array.isArray(board.fieldDefinitions)?board.fieldDefinitions:[];var valueFields=defs.filter(function(d){return d&&d.type==="number"&&/(valor|neg[oó]cio|receita|ticket|revenue|deal)/i.test(String(d.label||d.id||""));});if(!valueFields.length)return 0;var prof=proStore.contacts&&proStore.contacts[item.id];if(!prof||!prof.fieldValues)return 0;return valueFields.reduce(function(sum,d){return sum+number(prof.fieldValues[d.id]);},0);}
  function itemValue(item,legacy,proStore,crm){var hasDirect=!!item&&["valNegocio","dealValue","businessValue","valorNegocio","value"].some(function(key){return Object.prototype.hasOwnProperty.call(item,key)&&item[key]!=null;});var direct=number(item&&(item.valNegocio!=null?item.valNegocio:(item.dealValue!=null?item.dealValue:(item.businessValue!=null?item.businessValue:(item.valorNegocio!=null?item.valorNegocio:item.value)))));if(hasDirect)return Math.max(0,direct);var pv=professionalValue(proStore,crm,item);if(pv)return pv;var phone=digits(item&&item.contact&&item.contact.phoneNumber);return legacy[phone]||0;}
  function stagesFor(crm,legacy,proStore){return(crm.columns||[]).map(function(c,i){var contacts=(c.items||[]).length;var value=(c.items||[]).reduce(function(sum,item){return sum+itemValue(item,legacy,proStore,crm);},0);return{id:c.id,label:c.title||("Etapa "+(i+1)),contacts:contacts,value:value,color:c.color||c.hexColor||colorAt(i),index:i};});}
  function applySort(stages){var a=stages.slice();if(prefs.sort==="asc")a.sort(function(x,y){return metricValue(x)-metricValue(y);});else if(prefs.sort==="desc")a.sort(function(x,y){return metricValue(y)-metricValue(x);});else if(prefs.sort==="inverted")a.reverse();return a;}
  function metricValue(s){return prefs.metric==="value"?s.value:s.contacts;}
  function metricText(s){return prefs.metric==="value"?currency(s.value):String(s.contacts);}
  async function savePrefs(){await set(PREF_KEY,prefs);}
  function select(label,options,value,onChange){var w=el("label",{class:"extuiCrmFunnelControl"},[el("span",{text:label})]);var s=el("select");options.forEach(function(o){s.appendChild(el("option",{value:o[0],text:o[1]}));});s.value=value;s.onchange=function(){onChange(s.value);};w.appendChild(s);return w;}
  function csvSafeCell(value){var text=String(value==null?"":value),probe=text.replace(/^[ \t\r\n]+/,"");if(/^[=+\-@]/.test(probe))text="'"+text;return '"'+text.replace(/"/g,'""')+'"';}
  function downloadCsv(crm,stages){var rows=[["Etapa","Contatos","Receita"]].concat(stages.map(function(s){return[s.label,s.contacts,s.value.toFixed(2).replace(".",",")];}));var csv=rows.map(function(r){return r.map(csvSafeCell).join(";");}).join("\r\n");var blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"});var a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="extapp-funil-crm-"+String(crm.name||"crm").replace(/[^a-z0-9_-]+/gi,"-").toLowerCase()+".csv";a.click();setTimeout(function(){URL.revokeObjectURL(a.href);},1000);}
  function renderFunnel(stages){var max=Math.max.apply(Math,stages.map(metricValue).concat([1]));var wrap=el("div",{class:"extuiCrmFunnelChart"});stages.forEach(function(s,i){var ratio=Math.max(8,(metricValue(s)/max)*100);var row=el("div",{class:"extuiCrmFunnelStage"});var bar=el("div",{class:"extuiCrmFunnelBar"});bar.style.width=ratio+"%";bar.style.setProperty("--stage-color",s.color||colorAt(i));bar.appendChild(el("strong",{text:s.label,title:s.label}));bar.appendChild(el("span",{text:metricText(s)}));row.appendChild(bar);wrap.appendChild(row);});return wrap;}
  function renderPie(stages){var total=stages.reduce(function(sum,s){return sum+metricValue(s);},0)||1;var pos=0,parts=[];stages.forEach(function(s,i){var pct=metricValue(s)/total*100;parts.push((s.color||colorAt(i))+" "+pos+"% "+(pos+pct)+"%");pos+=pct;});var wrap=el("div",{class:"extuiCrmPieWrap"});var pie=el("div",{class:"extuiCrmPie"});pie.style.background="conic-gradient("+parts.join(",")+")";var center=el("div",{class:"extuiCrmPieCenter"},[el("strong",{text:prefs.metric==="value"?currency(stages.reduce(function(a,s){return a+s.value;},0)):String(stages.reduce(function(a,s){return a+s.contacts;},0))}),el("span",{text:prefs.metric==="value"?"Receita":"Contatos"})]);pie.appendChild(center);wrap.appendChild(pie);return wrap;}
  function renderPyramid(stages){var max=Math.max.apply(Math,stages.map(metricValue).concat([1]));var wrap=el("div",{class:"extuiCrmPyramidChart"});stages.forEach(function(s,i){var ratio=Math.max(38,(metricValue(s)/max)*100);var segment=el("div",{class:"extuiCrmPyramidSegment",title:s.label});segment.style.width=ratio+"%";segment.style.setProperty("--stage-color",s.color||colorAt(i));segment.appendChild(el("strong",{text:s.label,title:s.label}));segment.appendChild(el("span",{text:metricText(s)}));wrap.appendChild(segment);});return wrap;}
  function renderVertical(stages){var max=Math.max.apply(Math,stages.map(metricValue).concat([1]));var wrap=el("div",{class:"extuiCrmVerticalChart"});stages.forEach(function(s,i){var pct=Math.max(4,(metricValue(s)/max)*100);var col=el("div",{class:"extuiCrmVerticalCol"});var value=el("strong",{text:metricText(s)});var track=el("div",{class:"extuiCrmVerticalTrack"});var bar=el("div",{class:"extuiCrmVerticalBar"});bar.style.height=pct+"%";bar.style.setProperty("--stage-color",s.color||colorAt(i));track.appendChild(bar);col.appendChild(value);col.appendChild(track);col.appendChild(el("span",{text:s.label,title:s.label}));wrap.appendChild(col);});return wrap;}
  function renderLine(stages){var wrap=el("div",{class:"extuiCrmLineChart"});if(!stages.length)return wrap;var width=900,height=280,padX=58,padY=32,max=Math.max.apply(Math,stages.map(metricValue).concat([1]));var ns="http://www.w3.org/2000/svg";var svg=document.createElementNS(ns,"svg");svg.setAttribute("viewBox","0 0 "+width+" "+height);svg.setAttribute("role","img");svg.setAttribute("aria-label","Linha de conversão do CRM");for(var g=0;g<5;g++){var y=padY+(height-padY*2)*(g/4);var line=document.createElementNS(ns,"line");line.setAttribute("x1",padX);line.setAttribute("x2",width-padX);line.setAttribute("y1",y);line.setAttribute("y2",y);line.setAttribute("class","extuiCrmLineGrid");svg.appendChild(line);}var points=[];stages.forEach(function(s,i){var x=stages.length===1?width/2:padX+(width-padX*2)*(i/(stages.length-1));var y=height-padY-(metricValue(s)/max)*(height-padY*2);points.push(x+","+y);});var poly=document.createElementNS(ns,"polyline");poly.setAttribute("points",points.join(" "));poly.setAttribute("class","extuiCrmLinePath");svg.appendChild(poly);stages.forEach(function(s,i){var x=stages.length===1?width/2:padX+(width-padX*2)*(i/(stages.length-1));var y=height-padY-(metricValue(s)/max)*(height-padY*2);var c=document.createElementNS(ns,"circle");c.setAttribute("cx",x);c.setAttribute("cy",y);c.setAttribute("r","6");c.setAttribute("class","extuiCrmLinePoint");c.style.setProperty("--stage-color",s.color||colorAt(i));svg.appendChild(c);});wrap.appendChild(svg);var labels=el("div",{class:"extuiCrmLineLabels"});stages.forEach(function(s){labels.appendChild(el("div",{},[el("span",{text:s.label,title:s.label}),el("strong",{text:metricText(s)})]));});wrap.appendChild(labels);return wrap;}
  function renderChart(stages){if(prefs.chart==="pie")return renderPie(stages);if(prefs.chart==="pyramid")return renderPyramid(stages);if(prefs.chart==="vertical")return renderVertical(stages);if(prefs.chart==="line")return renderLine(stages);return renderFunnel(stages);}
  function crmContactCount(crm){return(crm&&crm.columns||[]).reduce(function(sum,column){return sum+(column.items||[]).length;},0);}
  function crmNavIcon(path){var span=el("span",{class:"extui-svgicon"});span.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+path+'</svg>';return span;}
  function renderCrmAnalysisTabs(hasCrm){
    var tabs=el("div",{class:"extui-viewtoggle",role:"tablist","aria-label":"Visões do CRM","data-extui-academy-target":"crm-analysis-tabs"});
    var entries=[
      ["hub","CRMs",'<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>'],
      ["overview","Visão geral",'<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>'],
      ["kanban","Kanban",'<path d="M6 5v11"/><path d="M12 5v6"/><path d="M18 5v14"/>'],
      ["notes","Notas",'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h6"/>'],
      ["analysis","Análise",'<path d="M3 4h18l-7 8v6l-4 2v-8z"/>']
    ];
    entries.forEach(function(entry){
      var active=entry[0]==="analysis";
      var btn=el("button",{type:"button",class:"extui-viewtoggle__btn"+(entry[0]==="analysis"?" extui-viewtoggle__btn--analysis":"")+(active?" active":""),role:"tab","aria-selected":String(active),title:entry[0]==="analysis"?"Análise do funil":entry[1]});
      btn.appendChild(crmNavIcon(entry[2]));btn.appendChild(el("span",{text:entry[1]}));
      if(entry[0]!=="hub"&&!hasCrm&&entry[0]!=="analysis")btn.disabled=true;
      if(entry[0]!=="analysis")btn.onclick=function(){if(window.__extCrmDashboardOpenView)window.__extCrmDashboardOpenView(entry[0],prefs.crmId||"");else if(window.__extDashboardShell)window.__extDashboardShell.showSection("crm");};
      tabs.appendChild(btn);
    });
    return tabs;
  }
  function renderCrmAnalysisBoardSelector(crmList,crm){
    var wrap=el("div",{class:"extui-boardsel extuiCrmAnalysisBoardSelector"});
    var btn=el("button",{class:"extui-boardsel__btn",type:"button","aria-haspopup":"true","aria-expanded":"false"},[
      el("span",{class:"extui-boardsel__dot",style:"background:"+(crm&&crm.hexColor||"#888")}),
      el("span",{class:"extui-boardsel__name",text:crm?crm.name:"Nenhum CRM"}),
      crm?el("span",{class:"extuiBadge",text:String(crmContactCount(crm))+(crmContactCount(crm)===1?" contato":" contatos")}):null,
      crmNavIcon('<path d="m9 18 6-6-6-6"/>')
    ].filter(Boolean));
    btn.lastChild.classList.add("extui-boardsel__caret");
    var menu=el("div",{class:"extui-boardsel__menu"});
    menu.appendChild(el("div",{class:"extui-boardsel__label",text:"Seus CRMs"}));
    crmList.forEach(function(item){
      var row=el("div",{class:"extui-boardsel__item"+(crm&&item.id===crm.id?" active":""),role:"button",tabindex:"0"},[
        el("span",{class:"extui-boardsel__dot",style:"background:"+(item.hexColor||"#888")}),
        el("span",{class:"name",text:item.name||"CRM"}),
        crm&&item.id===crm.id?el("span",{class:"extui-boardsel__check",text:"✓","aria-hidden":"true"}):null
      ].filter(Boolean));
      function choose(){prefs.crmId=item.id;funnelView="analytics";menu.classList.remove("open");btn.setAttribute("aria-expanded","false");savePrefs().then(render);}
      row.onclick=choose;row.onkeydown=function(event){if(event.key==="Enter"||event.key===" "){event.preventDefault();choose();}};
      menu.appendChild(row);
    });
    btn.onclick=function(event){event.stopPropagation();var open=!menu.classList.contains("open");document.querySelectorAll(".extui-boardsel__menu.open").forEach(function(node){node.classList.remove("open");});menu.classList.toggle("open",open);btn.setAttribute("aria-expanded",String(open));};
    wrap.appendChild(btn);wrap.appendChild(menu);return wrap;
  }
  function renderCrmAnalysisToolbar(crmList,crm){
    var bar=el("div",{class:"extui-topbar extuiCrmHubTopbar extuiCrmAnalysisUnifiedTopbar"});
    bar.appendChild(renderCrmAnalysisBoardSelector(crmList,crm));
    bar.appendChild(renderCrmAnalysisTabs(!!crmList.length));
    bar.appendChild(el("div",{class:"extui-topbar__spacer"}));
    var actions=el("div",{class:"extuiCrmAnalysisToolbarActions"});
    if(funnelView==="analytics"&&crm){
      var expand=el("button",{type:"button",class:"extui-btn extui-btn--ghost extuiCrmFunnelExpandBtn",text:funnelExpanded?"← Voltar":"Expandir Visualização"});expand.onclick=function(){setFunnelExpanded(!funnelExpanded);};actions.appendChild(expand);
    }
    var exp=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Exportar dados"});exp.disabled=!crm||funnelView!=="analytics";exp.onclick=function(){if(crm){Promise.all([get(PROFILE_KEY),get(PRO_KEY)]).then(function(values){downloadCsv(crm,stagesFor(crm,legacyValueIndex(values[0]),window.__extCrmProfessionalCore?window.__extCrmProfessionalCore.normalizeStore(values[1]):parse(values[1],{})));});}};actions.appendChild(exp);
    bar.appendChild(actions);return bar;
  }
  function renderCrmChooser(root,crmList){
    var chooser=el("section",{class:"extuiCrmFunnelChooser","aria-label":"Escolher CRM para analisar"});
    chooser.appendChild(el("div",{class:"extuiCrmFunnelChooserIntro"},[el("div",{},[el("span",{class:"extuiCrmFunnelEyebrow",text:"SELEÇÃO"}),el("h2",{text:"Qual CRM você quer analisar?"}),el("p",{text:"Escolha um CRM para abrir os indicadores. CRMs arquivados não aparecem enquanto estiverem fora de uso."})]),el("span",{class:"extuiCrmFunnelChooserCount",text:String(crmList.length)+(crmList.length===1?" CRM ativo":" CRMs ativos")})]));
    var grid=el("div",{class:"extuiCrmFunnelChooserGrid"});
    crmList.slice().sort(function(a,b){return Number(b.createdAtInMs||0)-Number(a.createdAtInMs||0);}).forEach(function(crm){
      var card=el("button",{type:"button",class:"extuiCrmFunnelChooserCard",style:"--stage-color:"+(crm.hexColor||"#10b981"),"aria-label":"Analisar CRM "+(crm.name||"CRM")});
      card.appendChild(el("span",{class:"extuiCrmFunnelChooserAccent"}));
      card.appendChild(el("div",{class:"extuiCrmFunnelChooserHead"},[el("i",{class:"extuiCrmFunnelChooserDot"}),el("span",{text:String((crm.columns||[]).length)+((crm.columns||[]).length===1?" etapa":" etapas")})]));
      card.appendChild(el("strong",{text:crm.name||"CRM"}));
      card.appendChild(el("p",{text:crm.description||"Sem descrição."}));
      card.appendChild(el("div",{class:"extuiCrmFunnelChooserMeta"},[el("span",{text:String(crmContactCount(crm))+(crmContactCount(crm)===1?" contato":" contatos")}),el("b",{text:"Ver indicadores →"})]));
      card.onclick=function(){prefs.crmId=crm.id;funnelView="analytics";funnelExpanded=false;applyFunnelExpandedMode();savePrefs().then(render);}; grid.appendChild(card);
    });
    chooser.appendChild(grid); root.appendChild(chooser);
  }
  async function render(){
    if(!containerEl||!isFunnelSectionActive())return;
    var renderTarget=containerEl;
    var values=await Promise.all([get(CRM_KEY),get(PRO_KEY),get(PROFILE_KEY),get(PREF_KEY)]);
    if(!isFunnelSectionActive()||containerEl!==renderTarget)return;
    Array.prototype.slice.call(containerEl.children).forEach(function(child){if(child.classList&&child.classList.contains("extuiCrmFunnelSection"))child.remove();});
    var crmState=parse(values[0],{crmList:[]}),crmList=(Array.isArray(crmState.crmList)?crmState.crmList:[]).filter(function(c){return !Number(c&&c.archivedAtInMs||0);});
    var core=window.__extCrmProfessionalCore,proStore=core?core.normalizeStore(values[1]):parse(values[1],{}),legacy=legacyValueIndex(values[2]);
    var stored=parse(values[3],null);
    if(stored){prefs=Object.assign(prefs,stored);if(!stored.defaultChartV9){prefs.chart="pyramid";prefs.defaultChartV9=true;savePrefs();}}
    else {prefs.chart="pyramid";prefs.defaultChartV9=true;}
    if(prefs.crmId&&!crmList.some(function(c){return c.id===prefs.crmId;}))prefs.crmId="";
    var crm=crmList.find(function(c){return c.id===prefs.crmId;})||null;
    var root=el("section",{class:"extuiCrmFunnelSection extuiCrmFunnelSection--integrated"+(funnelExpanded?" extuiCrmFunnelSection--expanded":"")});
    root.appendChild(renderCrmAnalysisToolbar(crmList,crm));
    var body=el("div",{class:"extuiCrmFunnelBody"});
    if(!crmList.length){body.appendChild(el("div",{class:"extuiCrmFunnelEmpty"},[el("h3",{text:"Crie um CRM primeiro"}),el("p",{text:"A análise usa as etapas e contatos do CRM para montar os indicadores."})]));root.appendChild(body);containerEl.appendChild(root);return;}
    if(funnelView!=="analytics"||!crm){renderCrmChooser(body,crmList);root.appendChild(body);containerEl.appendChild(root);return;}
    var controls=el("div",{class:"extuiCrmFunnelControls"});var crmOpts=crmList.map(function(c){return[c.id,c.name||"CRM"];});controls.appendChild(select("CRM",crmOpts,prefs.crmId,function(v){prefs.crmId=v;savePrefs().then(render);}));controls.appendChild(select("Métrica",[["contacts","Contatos"],["value","Valores / Receita"]],prefs.metric,function(v){prefs.metric=v;savePrefs().then(render);}));controls.appendChild(select("Visualização",[["funnel","Barras horizontais"],["pyramid","Pirâmide invertida"],["pie","Pizza"],["vertical","Barras verticais"],["line","Linha de conversão"]],prefs.chart,function(v){prefs.chart=v;savePrefs().then(render);}));controls.appendChild(select("Ordenação",[["original","Original"],["asc","Crescente"],["desc","Decrescente"],["inverted","Invertida"]],prefs.sort,function(v){prefs.sort=v;savePrefs().then(render);}));body.appendChild(controls);
    var baseStages=stagesFor(crm,legacy,proStore),stages=applySort(baseStages);var totalContacts=baseStages.reduce(function(a,s){return a+s.contacts;},0),totalValue=baseStages.reduce(function(a,s){return a+s.value;},0),first=baseStages[0]&&baseStages[0].contacts||0,last=baseStages[baseStages.length-1]&&baseStages[baseStages.length-1].contacts||0,conversion=first?last/first*100:0,ticket=totalContacts?totalValue/totalContacts:0;
    var kpis=el("div",{class:"extuiCrmFunnelKpis"});[[totalContacts,"Contatos"],[percent(conversion),"Conversão"],[currency(ticket),"Ticket médio"],[currency(totalValue),"Receita total"]].forEach(function(x){kpis.appendChild(el("div",{class:"extuiCrmFunnelKpi"},[el("strong",{text:String(x[0])}),el("span",{text:x[1]})]));});body.appendChild(kpis);
    var card=el("div",{class:"extuiCrmFunnelCard"});card.appendChild(el("div",{class:"extuiCrmFunnelCardHeader"},[el("h2",{text:crm.name||"Funil"}),el("span",{text:prefs.metric==="value"?"Distribuição por valor":"Distribuição por contatos"})]));card.appendChild(renderChart(stages));
    var legend=el("div",{class:"extuiCrmFunnelLegend"});stages.forEach(function(s){var r=el("div",{class:"extuiCrmFunnelLegendRow"});var dot=el("i");dot.style.background=s.color;r.appendChild(dot);r.appendChild(el("span",{text:s.label}));r.appendChild(el("strong",{text:s.contacts+" · "+currency(s.value)}));legend.appendChild(r);});card.appendChild(legend);body.appendChild(card);
    body.appendChild(el("p",{class:"extuiCrmFunnelNote",text:"Valores são lidos de valNegocio importado ou de campos numéricos do perfil com nomes como Valor, Negócio, Receita ou Ticket. Se nenhum campo de valor existir, as métricas financeiras ficam em R$ 0,00 sem inventar dados."}));root.appendChild(body);containerEl.appendChild(root);
  }

  window.__extDashboardShell.registerSection("crm-funnel",function(target){containerEl=target;var qp=new URLSearchParams(location.search),requested=window.__extCrmFunnelPendingCrmId||qp.get("crmId");window.__extCrmFunnelPendingCrmId="";funnelExpanded=false;applyFunnelExpandedMode();if(requested){prefs.crmId=requested;funnelView="analytics";return savePrefs().then(render);}funnelView="hub";return render();});
  document.addEventListener("ext:dashboard-section-change",function(event){if(!event.detail||event.detail.section!=="crm-funnel"){funnelExpanded=false;applyFunnelExpandedMode();}});
  [CRM_KEY,PRO_KEY,PROFILE_KEY].forEach(function(k){try{window.ExtensionStorage.subscribe(k,function(_next,_previous,_key,meta){if(meta&&meta.local===true)return;if(containerEl&&containerEl.isConnected&&isFunnelSectionActive())render();});}catch(_){}});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
