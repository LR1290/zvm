;
try{
(function () {
  "use strict";

                                                                         
                                                                    
  var STORAGE_KEY = "EXTUI:extappOptionsStore";
  var SEND_SUPPRESSION_KEY = "EXTUI:sendSafetySuppressionStore";
  var SEND_POLICY_REVISION = 2;
                                                                               
  var AI_MEMORY_STORE_KEY = "EXTUI:aiMemoryStore";
  var KNOWLEDGE_STORE_KEY = "EXTUI:knowledgeBasesStore";

                                                                        
                                                                         
                                                                        
                                                                           
                                                                          
                                                                       
                                                                          
                                                                          
                                                                     
                                               
  var DEFAULTS = {
    appearanceDefinition: "default",
    themeStateVersion: 7,
    mode: "auto",
    visualTheme: "padrao",
    customColors: null,
    fontFamily: "system",
    motion: "auto",
    radiusPreset: "default",
    iconTheme: "monochrome",
    icon3dColor: "olive",
    sidebarPlacement: "left-native",
    hideItemsBar: false,
    showOnlyFavoritesOnItemsBar: false,
    hideQuickShelf: false,
    askToSendSingleItem: true,
    askToSendFlows: true,
    askToSendFunnels: true,
    shouldAvoidWhatsappAutoScroll: false,
    keepAwakeLevel: "off",
    sendSafetyEnabled: true,
    sendSafetyGlobalPause: false,
    sendSafetyPolicyRevision: SEND_POLICY_REVISION,
    sendSafetyMinGapSeconds: 8,
    sendSafetyMaxPerMinute: 6,
    sendSafetyMaxPerHour: 60,
    sendSafetyMaxPerDay: 250,
    sendSafetyMaxCampaignRecipients: 100,
    sendSafetyFailureThreshold: 4,
    sendSafetyCircuitPauseSeconds: 120,
    sendSafetyBackoffBaseSeconds: 4,
    sendSafetyBackoffMaxSeconds: 60,
    sendSafetyQuietHoursEnabled: false,
    sendSafetyQuietStart: "08:00",
    sendSafetyQuietEnd: "20:00",
    sendSafetyAllowedDays: [0,1,2,3,4,5,6],
    sendSafetyRecipientCooldownMinutes: 1440
  };

  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(key, function (result) {
          if (chrome.runtime && chrome.runtime.lastError) { reject(chrome.runtime.lastError); return; }
          resolve(result ? result[key] : undefined);
        });
      } catch (err) { reject(err); }
    });
  }

  function storageSet(key, value) {
    if(key===STORAGE_KEY&&typeof chrome!=="undefined"&&chrome.runtime&&chrome.runtime.sendMessage){return new Promise(function(resolve,reject){chrome.runtime.sendMessage({type:"EXTUI_OPTIONS_COMMIT",scope:"operational",patch:value||{}},function(r){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message));return;}if(!r||r.ok!==true){reject(new Error(r&&r.error||"Falha ao salvar as opções."));return;}resolve(r.value);});});}
    if(window.ExtensionStorage&&typeof window.ExtensionStorage.set==="function")return window.ExtensionStorage.set(key,value);
    return new Promise(function(resolve,reject){try{var obj={};obj[key]=value;chrome.storage.local.set(obj,function(){if(chrome.runtime&&chrome.runtime.lastError){reject(chrome.runtime.lastError);return;}resolve();});}catch(err){reject(err);}});
  }

    async function loadOptions() {
    var raw = await storageGet(STORAGE_KEY);
    if (raw == null) return Object.assign({}, DEFAULTS);
    if (typeof raw !== "object" || Array.isArray(raw)) {
      var invalid = new Error("As preferências da extensão estão inválidas e não serão sobrescritas.");
      invalid.code = "OPTIONS_STORE_CORRUPT";
      throw invalid;
    }
    var out = Object.assign({}, DEFAULTS, raw);
    function clamp(value,fallback,min,max){var n=Number(value);if(!isFinite(n))n=fallback;return Math.max(min,Math.min(max,n));}
    out.sendSafetyEnabled = out.sendSafetyEnabled !== false;
    out.sendSafetyGlobalPause = out.sendSafetyGlobalPause === true;
    out.sendSafetyPolicyRevision = SEND_POLICY_REVISION;
    out.sendSafetyMinGapSeconds = clamp(out.sendSafetyMinGapSeconds,DEFAULTS.sendSafetyMinGapSeconds,1,300);
    out.sendSafetyMaxPerMinute = Math.round(clamp(out.sendSafetyMaxPerMinute,DEFAULTS.sendSafetyMaxPerMinute,1,60));
    out.sendSafetyMaxPerHour = Math.round(clamp(out.sendSafetyMaxPerHour,DEFAULTS.sendSafetyMaxPerHour,1,1000));
    out.sendSafetyMaxPerDay = Math.round(clamp(out.sendSafetyMaxPerDay,DEFAULTS.sendSafetyMaxPerDay,1,2000));
    out.sendSafetyMaxCampaignRecipients = Math.round(clamp(out.sendSafetyMaxCampaignRecipients,DEFAULTS.sendSafetyMaxCampaignRecipients,1,1000));
    out.sendSafetyRecipientCooldownMinutes = Math.round(clamp(out.sendSafetyRecipientCooldownMinutes,DEFAULTS.sendSafetyRecipientCooldownMinutes,0,10080));
    return out;
  }

  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }

  function flashSaved(container) {
    var note = container.querySelector(".extuiAjustesSavedNote");
    if (!note) return;
    note.classList.add("extuiShow");
    clearTimeout(note._extuiTimer);
    note._extuiTimer = setTimeout(function () { note.classList.remove("extuiShow"); }, 1200);
  }

  function renderToggleRow(container, opts, key, title, desc) {
    var row = document.createElement("div");
    row.className = "extuiAjustesRow";
    row.innerHTML =
      '<div class="extuiAjustesRowText"><div class="title">' + title + '</div><div class="desc">' + desc + '</div></div>' +
      '<label class="extuiSwitch"><input type="checkbox" ' + (opts[key] ? "checked" : "") + '><span class="track"></span></label>';
    row.querySelector("input").addEventListener("change", async function (ev) {
      opts[key] = ev.target.checked;
      try {
        await storageSet(STORAGE_KEY, opts);
        flashSaved(container);
      } catch (err) {
        ev.target.checked = !ev.target.checked;
        opts[key] = ev.target.checked;
        toast(err&&err.message||"Não foi possível salvar esta preferência.", true);
      }
    });
    container.appendChild(row);
  }

  function renderConfirmCard(wrap, opts) {
    var card = document.createElement("div");
    card.className = "extuiCard extuiAjustesAutomationCardV3";
    var h2 = document.createElement("h2");
    h2.innerHTML = 'Automação <span class="extuiAjustesSavedNote">salvo</span>';
    card.appendChild(h2);
    renderToggleRow(card, opts, "askToSendSingleItem", "Perguntar ao enviar item único", "Confirma antes de enviar mensagem/áudio/imagem/vídeo/figurinha/documento pelo botão ▷ da barra de itens.");
    renderToggleRow(card, opts, "askToSendFlows", "Perguntar ao enviar fluxos", "Confirma antes de iniciar um fluxo manualmente pelo botão ▷.");
    renderToggleRow(card, opts, "askToSendFunnels", "Perguntar ao enviar funis", "Confirma antes de iniciar um funil manualmente pelo botão ▷.");
    wrap.appendChild(card);
  }

  function renderWhatsappCard(wrap, opts) {
    var card = document.createElement("div");
    card.className = "extuiCard extuiAjustesWhatsappCardV3";
    var h2 = document.createElement("h2");
    h2.innerHTML = 'WhatsApp <span class="extuiAjustesSavedNote">salvo</span>';
    card.appendChild(h2);
    renderToggleRow(card, opts, "shouldAvoidWhatsappAutoScroll", "Evitar auto-scroll da lista de chats ao enviar", "Preserva a posição atual da lista de conversas durante os envios para evitar saltos inesperados para o topo.");
    wrap.appendChild(card);
  }

  function sendToWhatsappSafety(type) {
    return new Promise(function (resolve) {
      try {
        chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
          var tab = (tabs || [])[0];
          if (!tab || tab.id == null) { resolve(null); return; }
          chrome.tabs.sendMessage(tab.id, { type:type }, function (response) {
            if (chrome.runtime && chrome.runtime.lastError) { resolve(null); return; }
            resolve(response || null);
          });
        });
      } catch (_) { resolve(null); }
    });
  }

  function renderSafetyNumber(card, opts, key, title, desc, min, max, step, suffix) {
    var row = document.createElement("div");
    row.className = "extuiAjustesRow extuiSafetyFieldRow";
    var text = document.createElement("div"); text.className = "extuiAjustesRowText";
    var t = document.createElement("div"); t.className = "title"; t.textContent = title;
    var d = document.createElement("div"); d.className = "desc"; d.textContent = desc;
    text.appendChild(t); text.appendChild(d);
    var field = document.createElement("label"); field.className = "extuiSafetyNumberWrap";
    var input = document.createElement("input"); input.type = "number"; input.className = "extuiSafetyNumber";
    input.min = String(min); input.max = String(max); input.step = String(step || 1); input.value = String(opts[key]);
    var unit = document.createElement("span"); unit.textContent = suffix || "";
    field.appendChild(input); if (suffix) field.appendChild(unit);
    input.addEventListener("change", async function () {
      var previous = Number(opts[key]);
      var n = Number(input.value); if (!isFinite(n)) n = Number(opts[key]) || min;
      n = Math.max(min, Math.min(max, n)); input.value = String(n); opts[key] = n;
      try { await storageSet(STORAGE_KEY, opts); flashSaved(card); } catch (err) { opts[key] = previous; input.value = String(previous); toast(err&&err.message||"Não foi possível salvar esta preferência.", true); }
    });
    row.appendChild(text); row.appendChild(field); card.appendChild(row);
  }

  function healthLabel(health) {
    var readiness = health && health.readiness || {};
    var state = readiness.state || health && health.state || "unknown";
    if (state === "ready") return { label:"Pronto para enviar", cls:"ok" };
    if (state === "waiting_connection") return { label:"Aguardando conexão", cls:"muted" };
    if (state === "initializing") return { label:"Inicializando", cls:"warn" };
    if (state === "unstable") return { label:"Operação instável", cls:"warn" };
    if (state === "paused") return { label:"Envios pausados", cls:"danger" };
    if (state === "compatibility_reduced") return { label:"Compatibilidade reduzida", cls:"danger" };
    if (state === "whatsapp_unavailable") return { label:"WhatsApp indisponível", cls:"danger" };
    return { label:"Teste necessário", cls:"muted" };
  }

  function lastReadinessTestAt(snapshot) {
    var values = [
      snapshot && snapshot.compatibility && snapshot.compatibility.checkedAt,
      snapshot && snapshot.session && snapshot.session.checkedAt,
      snapshot && snapshot.readiness && snapshot.readiness.checkedAt
    ].map(Number).filter(function(v){return isFinite(v)&&v>0;});
    return values.length ? Math.max.apply(Math, values) : 0;
  }

  function normalizeSuppressionNumber(value){var digits=String(value||"").replace(/\D/g,"");if(digits.length<8||digits.length>20)throw new Error("Informe o número com DDI e DDD, usando entre 8 e 20 dígitos.");return digits;}
  async function suppressionDigest(number){var bytes=new TextEncoder().encode("optout|"+number),digest=await crypto.subtle.digest("SHA-256",bytes);return Array.from(new Uint8Array(digest)).map(function(b){return b.toString(16).padStart(2,"0");}).join("");}
  function parseSuppressionStore(raw){if(raw==null)return{version:1,entries:{}};if(typeof raw==="string"){try{raw=JSON.parse(raw);}catch(_){throw new Error("A lista Não contatar está corrompida. Os envios automáticos permanecem bloqueados até corrigir ou redefinir a lista.");}}if(!raw||typeof raw!=="object"||Array.isArray(raw)||Number(raw.version)!==1||!raw.entries||typeof raw.entries!=="object"||Array.isArray(raw.entries))throw new Error("A lista Não contatar está corrompida. Os envios automáticos permanecem bloqueados até corrigir ou redefinir a lista.");var out={};Object.keys(raw.entries).forEach(function(digest){if(!/^[a-f0-9]{64}$/.test(digest))throw new Error("A lista Não contatar contém um identificador inválido.");var row=raw.entries[digest];if(!row||typeof row!=="object"||Array.isArray(row))throw new Error("A lista Não contatar contém um registro inválido.");out[digest]={last4:String(row.last4||"").replace(/\D/g,"").slice(-4),createdAt:Number(row.createdAt)||0};});return{version:1,entries:out};}
  async function readSuppressionStore(){return parseSuppressionStore(await storageGet(SEND_SUPPRESSION_KEY));}
  async function writeSuppressionStore(store){await storageSet(SEND_SUPPRESSION_KEY,store);return store;}

  function renderSuppressionManager(card){
    var section=document.createElement("details");section.className="extuiSafetySuppression extuiSafetySuppressionDisclosure";
    var summary=document.createElement("summary");summary.className="extuiSafetySuppressionSummary";summary.innerHTML='<div class="extuiSafetySuppressionSummaryCopy"><div class="extuiSafetySuppressionTitleRow"><strong>Não contatar</strong><span class="extuiSafetySuppressionCount" aria-label="0 destinatários protegidos">0</span></div><small>Bloqueia automações para destinatários que pediram para não receber mensagens. Abra somente quando precisar gerenciar a lista.</small></div>';section.appendChild(summary);
    var body=document.createElement("div");body.className="extuiSafetySuppressionBody";section.appendChild(body);
    var form=document.createElement("form");form.className="extuiSafetySuppressionForm";form.innerHTML='<input class="extuiAjustesInput" type="tel" inputmode="numeric" autocomplete="off" placeholder="Ex.: 5511999999999" aria-label="Número para Não contatar"><button type="submit" class="extui-btn secondary">Adicionar</button>';body.appendChild(form);
    var status=document.createElement("small");status.className="extuiSafetySuppressionStatus";body.appendChild(status);
    var list=document.createElement("div");list.className="extuiSafetySuppressionList";body.appendChild(list);
    async function paint(){list.innerHTML="";status.textContent="Carregando...";try{var store=await readSuppressionStore(),rows=Object.keys(store.entries).map(function(d){return{digest:d,row:store.entries[d]};}).sort(function(a,b){return(Number(b.row.createdAt)||0)-(Number(a.row.createdAt)||0);});var countBadge=summary.querySelector('.extuiSafetySuppressionCount');countBadge.textContent=String(rows.length);countBadge.setAttribute('aria-label',rows.length+' destinatário(s) protegido(s)');status.textContent=rows.length?rows.length+" destinatário(s) protegido(s) · somente hash SHA-256 + últimos 4 dígitos":"Nenhum destinatário na lista.";rows.forEach(function(entry){var row=document.createElement("div");row.className="extuiSafetySuppressionRow";var copy=document.createElement("div");var last4Strong=document.createElement("strong");last4Strong.textContent="•••• "+String(entry.row.last4||"—");var createdSmall=document.createElement("small");createdSmall.textContent="Adicionado em "+new Date(entry.row.createdAt).toLocaleString("pt-BR");copy.appendChild(last4Strong);copy.appendChild(createdSmall);var remove=document.createElement("button");remove.type="button";remove.className="extui-btn secondary";remove.textContent="Remover";remove.addEventListener("click",async function(){var latest=await readSuppressionStore();delete latest.entries[entry.digest];await writeSuppressionStore(latest);flashSaved(card);paint();});row.appendChild(copy);row.appendChild(remove);list.appendChild(row);});}catch(err){var countBadge=summary.querySelector('.extuiSafetySuppressionCount');countBadge.textContent='!';countBadge.setAttribute('aria-label','Não foi possível contar os destinatários protegidos');status.textContent=err&&err.message||"Não foi possível ler a lista Não contatar.";var reset=document.createElement("button");reset.type="button";reset.className="extui-btn secondary";reset.textContent="Redefinir lista local";reset.addEventListener("click",async function(){if(window.extConfirm&&!(await window.extConfirm("Redefinir a lista Não contatar local?",{danger:true})))return;await writeSuppressionStore({version:1,entries:{}});paint();});list.appendChild(reset);}}
    form.addEventListener("submit",async function(ev){ev.preventDefault();var input=form.querySelector("input");try{var number=normalizeSuppressionNumber(input.value),digest=await suppressionDigest(number),store=await readSuppressionStore();store.entries[digest]={last4:number.slice(-4),createdAt:Date.now()};await writeSuppressionStore(store);input.value="";flashSaved(card);paint();}catch(err){toast(err&&err.message||"Não foi possível adicionar o destinatário.",true);}});
    paint();card.appendChild(section);
  }

  function renderSendSafetyCard(wrap, opts) {
    if (window.__extSendSafetySettingsCleanup) {
      try { window.__extSendSafetySettingsCleanup(); } catch (_) {}
      window.__extSendSafetySettingsCleanup = null;
    }
    var dayDefs = [{d:1,l:"Seg"},{d:2,l:"Ter"},{d:3,l:"Qua"},{d:4,l:"Qui"},{d:5,l:"Sex"},{d:6,l:"Sáb"},{d:0,l:"Dom"}];
    var fieldDefs = [
      {key:"sendSafetyMinGapSeconds", title:"Intervalo mínimo global", desc:"Espaçamento mínimo entre novos envios automatizados da extensão.", min:1, max:300, step:1, suffix:"s"},
      {key:"sendSafetyMaxPerMinute", title:"Guardrail por minuto", desc:"Referência interna de ritmo para automações desta instalação.", min:1, max:60, step:1, suffix:"/min"},
      {key:"sendSafetyMaxPerHour", title:"Guardrail por hora", desc:"Soma de automações entre abas e superfícies desta instalação.", min:1, max:1000, step:1, suffix:"/h"},
      {key:"sendSafetyMaxPerDay", title:"Guardrail em 24 horas", desc:"Janela móvel global de 24 horas para envios automatizados.", min:1, max:4000, step:1, suffix:"/24h"},
      {key:"sendSafetyMaxCampaignRecipients", title:"Máximo por campanha", desc:"Bloqueia campanhas acima deste total antes de montar a fila.", min:1, max:5000, step:1, suffix:"contatos"},
      {key:"sendSafetyRecipientCooldownMinutes", title:"Proteção contra reenvio", desc:"Evita novo envio automatizado ao mesmo destinatário durante a janela configurada.", min:0, max:10080, step:1, suffix:"min"},
      {key:"sendSafetyFailureThreshold", title:"Falhas para pausar", desc:"Falhas operacionais consecutivas antes de a proteção pausar a automação.", min:1, max:20, step:1, suffix:"falhas"},
      {key:"sendSafetyCircuitPauseSeconds", title:"Pausa após falhas", desc:"Tempo de pausa aplicado quando a proteção entra em circuito de segurança.", min:10, max:3600, step:10, suffix:"s"},
      {key:"sendSafetyBackoffBaseSeconds", title:"Espera inicial após falha", desc:"Primeira espera progressiva antes de tentar novamente.", min:0, max:120, step:1, suffix:"s"},
      {key:"sendSafetyBackoffMaxSeconds", title:"Espera máxima após falha", desc:"Limite da espera progressiva entre novas tentativas.", min:1, max:1800, step:1, suffix:"s"}
    ];
    function builtinProfiles(){
      return [
        {id:"conservador", name:"Conservador", builtin:true, blurb:"Mais cauteloso, prioriza espaçamento alto e janelas maiores.", values:{sendSafetyMinGapSeconds:8,sendSafetyMaxPerMinute:6,sendSafetyMaxPerHour:60,sendSafetyMaxPerDay:250,sendSafetyMaxCampaignRecipients:100,sendSafetyRecipientCooldownMinutes:1440,sendSafetyQuietHoursEnabled:true,sendSafetyQuietStart:"08:00",sendSafetyQuietEnd:"20:00",sendSafetyAllowedDays:[0,1,2,3,4,5,6],sendSafetyFailureThreshold:3,sendSafetyCircuitPauseSeconds:180,sendSafetyBackoffBaseSeconds:5,sendSafetyBackoffMaxSeconds:90,sendSafetyPolicyRevision:SEND_POLICY_REVISION}},
        {id:"moderado", name:"Moderado", builtin:true, blurb:"Equilíbrio entre segurança e volume, inspirado em ritmos graduais e pacing oficial do ecossistema WhatsApp Business.", values:{sendSafetyMinGapSeconds:6,sendSafetyMaxPerMinute:10,sendSafetyMaxPerHour:100,sendSafetyMaxPerDay:500,sendSafetyMaxCampaignRecipients:200,sendSafetyRecipientCooldownMinutes:720,sendSafetyQuietHoursEnabled:true,sendSafetyQuietStart:"08:00",sendSafetyQuietEnd:"21:00",sendSafetyAllowedDays:[0,1,2,3,4,5,6],sendSafetyFailureThreshold:4,sendSafetyCircuitPauseSeconds:120,sendSafetyBackoffBaseSeconds:4,sendSafetyBackoffMaxSeconds:60,sendSafetyPolicyRevision:SEND_POLICY_REVISION}},
        {id:"ambicioso", name:"Ambicioso", builtin:true, blurb:"Mais agressivo, para operações maduras que ainda desejam manter guardrails internos.", values:{sendSafetyMinGapSeconds:4,sendSafetyMaxPerMinute:15,sendSafetyMaxPerHour:180,sendSafetyMaxPerDay:1000,sendSafetyMaxCampaignRecipients:350,sendSafetyRecipientCooldownMinutes:240,sendSafetyQuietHoursEnabled:true,sendSafetyQuietStart:"07:00",sendSafetyQuietEnd:"22:00",sendSafetyAllowedDays:[0,1,2,3,4,5,6],sendSafetyFailureThreshold:5,sendSafetyCircuitPauseSeconds:90,sendSafetyBackoffBaseSeconds:3,sendSafetyBackoffMaxSeconds:45,sendSafetyPolicyRevision:SEND_POLICY_REVISION}}
      ];
    }
    function cloneValue(v){return JSON.parse(JSON.stringify(v));}
    function ensureTime(value,fallback){return /^\d{2}:\d{2}$/.test(String(value||""))?String(value):fallback;}
    function sameArray(a,b){a=Array.isArray(a)?a.slice():[];b=Array.isArray(b)?b.slice():[];if(a.length!==b.length)return false;a.sort();b.sort();for(var i=0;i<a.length;i++)if(Number(a[i])!==Number(b[i]))return false;return true;}
    function valuesEqual(a,b){
      a=a||{};b=b||{};
      for(var i=0;i<fieldDefs.length;i++){var key=fieldDefs[i].key;if(Number(a[key])!==Number(b[key]))return false;}
      if(!!a.sendSafetyQuietHoursEnabled!==!!b.sendSafetyQuietHoursEnabled)return false;
      if(ensureTime(a.sendSafetyQuietStart,"08:00")!==ensureTime(b.sendSafetyQuietStart,"08:00"))return false;
      if(ensureTime(a.sendSafetyQuietEnd,"20:00")!==ensureTime(b.sendSafetyQuietEnd,"20:00"))return false;
      if(!sameArray(a.sendSafetyAllowedDays,b.sendSafetyAllowedDays))return false;
      return true;
    }
    function defaultProfileById(id){var row=builtinProfiles().find(function(entry){return entry.id===id;});return row?cloneValue(row):null;}
    function sanitizeValues(values, fallback){
      values = values && typeof values === "object" ? cloneValue(values) : {};
      fallback = fallback || (defaultProfileById("conservador")||{}).values || {};
      var out = { sendSafetyQuietHoursEnabled: values.sendSafetyQuietHoursEnabled !== false, sendSafetyQuietStart: ensureTime(values.sendSafetyQuietStart || fallback.sendSafetyQuietStart, "08:00"), sendSafetyQuietEnd: ensureTime(values.sendSafetyQuietEnd || fallback.sendSafetyQuietEnd, "20:00"), sendSafetyAllowedDays: Array.isArray(values.sendSafetyAllowedDays) && values.sendSafetyAllowedDays.length ? values.sendSafetyAllowedDays.map(function(n){return Number(n);}).filter(function(n){return !isNaN(n) && n>=0 && n<=6;}) : cloneValue(fallback.sendSafetyAllowedDays || [0,1,2,3,4,5,6]), sendSafetyPolicyRevision: SEND_POLICY_REVISION };
      fieldDefs.forEach(function(def){ var n = Number(values[def.key]); if(!isFinite(n)) n = Number(fallback[def.key]); if(!isFinite(n)) n = def.min; n = Math.max(def.min, Math.min(def.max, n)); if(def.step>=1) n = Math.round(n / def.step) * def.step; out[def.key] = n; });
      if(!out.sendSafetyAllowedDays.length) out.sendSafetyAllowedDays = [0,1,2,3,4,5,6];
      return out;
    }
    function extractCurrentValues(source){
      return sanitizeValues({
        sendSafetyQuietHoursEnabled: source.sendSafetyQuietHoursEnabled,
        sendSafetyQuietStart: source.sendSafetyQuietStart,
        sendSafetyQuietEnd: source.sendSafetyQuietEnd,
        sendSafetyAllowedDays: source.sendSafetyAllowedDays,
        sendSafetyMinGapSeconds: source.sendSafetyMinGapSeconds,
        sendSafetyMaxPerMinute: source.sendSafetyMaxPerMinute,
        sendSafetyMaxPerHour: source.sendSafetyMaxPerHour,
        sendSafetyMaxPerDay: source.sendSafetyMaxPerDay,
        sendSafetyMaxCampaignRecipients: source.sendSafetyMaxCampaignRecipients,
        sendSafetyRecipientCooldownMinutes: source.sendSafetyRecipientCooldownMinutes,
        sendSafetyFailureThreshold: source.sendSafetyFailureThreshold,
        sendSafetyCircuitPauseSeconds: source.sendSafetyCircuitPauseSeconds,
        sendSafetyBackoffBaseSeconds: source.sendSafetyBackoffBaseSeconds,
        sendSafetyBackoffMaxSeconds: source.sendSafetyBackoffMaxSeconds
      }, (defaultProfileById("conservador")||{}).values || {});
    }
    function buildStore(source){
      var defaults = builtinProfiles();
      var saved = Array.isArray(source.sendSafetyProfiles) ? source.sendSafetyProfiles.slice() : null;
      var profiles = [];
      if(saved && saved.length){
        defaults.forEach(function(base){
          var found = saved.find(function(entry){ return entry && entry.id===base.id; });
          profiles.push({id:base.id,name:base.name,builtin:true,blurb:base.blurb,values:sanitizeValues(found&&found.values,base.values)});
        });
        saved.forEach(function(entry){ if(!entry||!entry.id||defaults.some(function(base){return base.id===entry.id;})) return; profiles.push({id:String(entry.id),name:String(entry.name||"Perfil personalizado"),builtin:false,blurb:String(entry.blurb||"Perfil personalizado salvo pelo usuário."),values:sanitizeValues(entry.values,extractCurrentValues(source))}); });
      } else {
        defaults.forEach(function(base){ profiles.push({id:base.id,name:base.name,builtin:true,blurb:base.blurb,values:sanitizeValues(base.values,base.values)}); });
        var migrated = extractCurrentValues(source);
        if(!valuesEqual(migrated, profiles[0].values)) profiles[0].values = sanitizeValues(migrated, profiles[0].values);
      }
      var activeId = String(source.sendSafetyActiveProfileId || "conservador");
      if(!profiles.some(function(profile){return profile.id===activeId;})) activeId = profiles[0].id;
      return { activeProfileId: activeId, profiles: profiles };
    }
    function commitStoreIntoOptions(store){
      opts.sendSafetyProfiles = cloneValue(store.profiles);
      opts.sendSafetyActiveProfileId = store.activeProfileId;
      opts.sendSafetyPolicyRevision = SEND_POLICY_REVISION;
      var active = store.profiles.find(function(profile){ return profile.id === store.activeProfileId; }) || store.profiles[0];
      if(active) Object.assign(opts, sanitizeValues(active.values, active.values));
    }
    var store = buildStore(opts), selectedProfileId = store.activeProfileId, unlockBuiltins = {}, dirty = false;
    var card = document.createElement("div"); card.className = "extuiCard extuiSafetyCard extuiSafetyProfilesCard"; card.id = "extuiSendSafetyCard";
    var h2 = document.createElement("h2"); h2.innerHTML = 'Proteção de envio <span class="extuiAjustesSavedNote">salvo</span>'; card.appendChild(h2);
    var intro = document.createElement("p"); intro.className = "extuiSafetyIntro";
    intro.textContent = "Perfis de proteção para graduar ritmo, pausas e reenvios. Os valores servem como guardrails internos da extensão; eles não são limites oficiais do WhatsApp e não substituem consentimento, opt-out e boas práticas operacionais.";
    card.appendChild(intro);
    var health = document.createElement("div"); health.className = "extuiSafetyHealth extuiSafetyHealth--muted";
    health.innerHTML = '<span class="extuiSafetyHealthDot"></span><div class="extuiSafetyHealthCopy"><span class="extuiSafetyHealthEyebrow">Prontidão para envio</span><strong>Teste necessário</strong><small>Execute Testar tudo para verificar compatibilidade, sessão e estabilidade.</small><em class="extuiSafetyHealthTestAt">Último teste: ainda não executado</em></div><div class="extuiSafetyHealthActions"><button type="button" class="extui-btn secondary extuiSafetyTestAll" title="Executa compatibilidade, sessão e estabilidade em sequência. Não envia mensagens.">Testar tudo</button><button type="button" class="extui-btn extui-btn--ghost extuiSafetyOpenDiagnostics" title="Abre o Diagnóstico detalhado no Início.">Abrir Diagnóstico</button><button type="button" class="extui-btn extui-btn--ghost extuiSafetyCircuitReset" title="Limpa a pausa automática acionada por falhas consecutivas e zera o contador de falhas. Não altera o perfil, a pausa manual, a lista Não contatar nem os demais limites.">Liberar pausa automática</button></div>';
    card.appendChild(health);
    function updateCircuitReset(snapshot) {
      var resetButton=health.querySelector(".extuiSafetyCircuitReset"),hasCircuit=!!(snapshot&&((Number(snapshot.circuitOpenUntil)||0)>Date.now()||(Number(snapshot.consecutiveFailures)||0)>0||snapshot.lastError));
      if(resetButton){resetButton.disabled=!hasCircuit;resetButton.setAttribute("aria-disabled",hasCircuit?"false":"true");}
    }
    function paintHealth(snapshot) {
      var info = healthLabel(snapshot);
      health.className = "extuiSafetyHealth extuiSafetyHealth--" + info.cls;
      health.querySelector("strong").textContent = info.label;
      var details = [];
      var compatibility = snapshot && snapshot.compatibility;
      var session = snapshot && snapshot.session;
      var stability = snapshot && snapshot.stability;
      if (compatibility) details.push(compatibility.ok ? "Compatibilidade aprovada" : (compatibility.state === "unavailable" ? "Compatibilidade indisponível" : "Compatibilidade reduzida"));
      else details.push("Compatibilidade não testada");
      if (session) details.push(session.ready ? "Sessão pronta" : (session.state === "waiting_connection" ? "Sessão aguardando conexão" : "Sessão inicializando"));
      else details.push("Sessão não testada");
      if (stability) details.push(stability.label || "Estabilidade não avaliada");
      var readiness = snapshot && snapshot.readiness;
      if (readiness && readiness.detail) details.push(readiness.detail);
      health.querySelector("small").textContent = details.join(" · ");
      var at=lastReadinessTestAt(snapshot),atNode=health.querySelector(".extuiSafetyHealthTestAt");
      if(atNode)atNode.textContent=at?"Último teste: "+new Date(at).toLocaleString("pt-BR"):"Último teste: ainda não executado";
      updateCircuitReset(snapshot);
    }
    async function refreshHealth(type) {
      var button=type&&type!=="EXTUI_SEND_SAFETY_GET_HEALTH"?health.querySelector(".extuiSafetyTestAll"):null;
      if(button){button.disabled=true;button.textContent="Testando...";}
      try {
        var response = await sendToWhatsappSafety(type || "EXTUI_SEND_SAFETY_GET_HEALTH");
        var snap = response && (response.health || response.result) || null;
        paintHealth(snap);
      } finally {
        if(button){button.disabled=false;button.textContent="Testar tudo";}
      }
    }
    health.querySelector(".extuiSafetyTestAll").addEventListener("click", function () { refreshHealth("EXTUI_SEND_SAFETY_TEST_ALL"); });
    health.querySelector(".extuiSafetyOpenDiagnostics").addEventListener("click", function () {
      try {
        window.__extCorePendingTab = "diagnostics";
        if (window.__extDashboardShell && typeof window.__extDashboardShell.showSection === "function") window.__extDashboardShell.showSection("home");
      } catch (_) {}
    });
    health.querySelector(".extuiSafetyCircuitReset").addEventListener("click", async function () { var btn=this;btn.disabled=true;try{var r=await sendToWhatsappSafety("EXTUI_SEND_SAFETY_RESET_CIRCUIT"),snap=r&&(r.result||r.health)||null;paintHealth(snap);}finally{updateCircuitReset(null);} });
    refreshHealth("EXTUI_SEND_SAFETY_GET_HEALTH");
    var globalControls = document.createElement("div"); globalControls.className = "extuiSafetyGlobalControls"; globalControls.setAttribute("aria-label","Controles globais da Proteção de envio"); card.appendChild(globalControls);
    var statusBar = document.createElement("div"); statusBar.className = "extuiSafetyProfileBar"; statusBar.setAttribute("aria-live","polite"); card.appendChild(statusBar);
    var body = document.createElement("div"); body.className = "extuiSafetyProfilesLayout"; card.appendChild(body);
    var profileList = document.createElement("div"); profileList.className = "extuiSafetyProfileList"; body.appendChild(profileList);
    var editor = document.createElement("div"); editor.className = "extuiSafetyProfileEditor"; body.appendChild(editor);
    renderSuppressionManager(card);
    var policy=document.createElement("div");policy.className="extuiSafetyPolicyNote";policy.innerHTML='<strong>Consentimento e opt-out são responsabilidade de quem envia.</strong><span>A extensão pode impor guardrails e bloquear destinatários, mas não transforma automação não autorizada em uso permitido. Consulte sempre as regras atuais.</span><div><a href="https://faq.whatsapp.com/5957850900902049/?locale=pt_BR" target="_blank" rel="noopener noreferrer">Regras sobre mensagens automáticas/em massa</a><a href="https://business.whatsapp.com/policy/preview?lang=pt_BR" target="_blank" rel="noopener noreferrer">Política WhatsApp Business</a></div>';card.appendChild(policy);
    wrap.appendChild(card);
    function findSelected(){ return store.profiles.find(function(profile){ return profile.id===selectedProfileId; }) || store.profiles[0]; }
    function updateSavedNote(){ var note=h2.querySelector('.extuiAjustesSavedNote'); if(note) note.textContent = dirty ? 'alterações pendentes' : 'salvo'; }
    function setDirty(flag){ dirty = !!flag; updateSavedNote(); card.dataset.dirty = dirty ? 'true' : 'false'; }
    async function saveStore(){
      commitStoreIntoOptions(store);
      await storageSet(STORAGE_KEY, opts);
      setDirty(false);
      flashSaved(card);
      if(window.__extSendSafetyAfterSave) try{ window.__extSendSafetyAfterSave(cloneValue(store)); }catch(_){ }
    }
    async function maybeResolveUnsaved(){
      if(!dirty) return true;
      if(!window.extModalPrompt) return false;
      var shouldSave = await window.extModalPrompt('Existem alterações não salvas na Proteção de envio.', { title:'Deseja salvar antes de sair?', okLabel:'Salvar', cancelLabel:'Descartar', cancel:true });
      if(shouldSave===true){ try{ await saveStore(); return true; } catch(err){ toast(err&&err.message||'Não foi possível salvar o perfil.', true); return false; } }
      if(shouldSave===false){ setDirty(false); store = buildStore(opts); selectedProfileId = store.activeProfileId; renderProfileEditor(); return true; }
      return false;
    }
    function beforeUnload(event){ if(!dirty) return; event.preventDefault(); event.returnValue = ''; }
    window.addEventListener('beforeunload', beforeUnload);
    window.__extSendSafetyHandleLeave = maybeResolveUnsaved;
    window.__extSendSafetySettingsCleanup = function(){ window.removeEventListener('beforeunload', beforeUnload); if(window.__extDashboardShell&&typeof window.__extDashboardShell.setNavigationGuard==='function') window.__extDashboardShell.setNavigationGuard(null); if(window.__extSendSafetyHandleLeave===maybeResolveUnsaved) window.__extSendSafetyHandleLeave=null; };
    if(window.__extDashboardShell&&typeof window.__extDashboardShell.setNavigationGuard==='function') window.__extDashboardShell.setNavigationGuard(function(){ return maybeResolveUnsaved(); });
    async function persistGlobalFlag(key, nextValue){
      var previous=opts[key]; opts[key]=nextValue; renderGlobalControls(); renderStatusBar();
      try{var committed=await storageSet(STORAGE_KEY,opts);if(committed&&typeof committed==='object')Object.assign(opts,committed);renderGlobalControls();renderStatusBar();flashSaved(card);}
      catch(err){opts[key]=previous;renderGlobalControls();renderStatusBar();toast(err&&err.message||'Não foi possível atualizar a Proteção de envio.',true);}
    }
    function renderGlobalControls(){
      globalControls.innerHTML='';
      var enabled=document.createElement('label'); enabled.className='extuiSafetyGlobalControl extuiSafetyGlobalEnable'; enabled.innerHTML='<div class="extuiSafetyGlobalCopy"><strong>Ativar proteção de envio</strong><span>Controle global da instalação. O perfil ativo define os valores; este switch liga ou desliga os guardrails.</span></div><span class="extuiSwitch"><input type="checkbox"><span class="track"></span></span>';
      var enabledInput=enabled.querySelector('input'); enabledInput.checked=opts.sendSafetyEnabled!==false; enabledInput.addEventListener('change',async function(){var next=!!enabledInput.checked;if(!next){enabledInput.disabled=true;var sure=window.extConfirm?await window.extConfirm('Desligar a Proteção de Envio desativa os guardrails globais para novos envios automáticos. O perfil selecionado e a lista Não contatar serão preservados.',{title:'Desligar proteção de envio',okLabel:'Desligar',cancelLabel:'Cancelar',danger:true}):window.confirm('Desligar a Proteção de Envio?');if(!sure){enabledInput.checked=true;enabledInput.disabled=false;return;}}enabledInput.disabled=true;await persistGlobalFlag('sendSafetyEnabled',next);});
      var pauseWrap=document.createElement('div');pauseWrap.className='extuiSafetyGlobalPauseWrap';
      var pauseCopy=document.createElement('div');pauseCopy.className='extuiSafetyGlobalCopy';pauseCopy.innerHTML='<strong>Pausa global</strong><span>Kill Switch da instalação: bloqueia novos envios automáticos sem alterar o perfil selecionado.</span>';
      var pause=document.createElement('button');pause.type='button';pause.className='extui-btn '+(opts.sendSafetyGlobalPause===true?'extui-btn--primary':'extui-btn--ghost');pause.textContent=opts.sendSafetyGlobalPause===true?'Retomar novos envios':'Pausar novos envios';pause.title=opts.sendSafetyGlobalPause===true?'Retoma novos envios automáticos em toda a extensão.':'Pausa novos envios automáticos em toda a extensão, independentemente do perfil ativo.';pause.addEventListener('click',function(){pause.disabled=true;persistGlobalFlag('sendSafetyGlobalPause',opts.sendSafetyGlobalPause!==true);});
      pauseWrap.appendChild(pauseCopy);pauseWrap.appendChild(pause);globalControls.appendChild(enabled);globalControls.appendChild(pauseWrap);
    }
    function renderProfileList(){
      profileList.innerHTML = '';
      var head = document.createElement('div'); head.className = 'extuiSafetyProfileListHead'; head.innerHTML = '<strong>Perfis</strong>';
      var add = document.createElement('button'); add.type='button'; add.className='extui-btn extui-btn--secondary'; add.textContent='Novo perfil';
      add.addEventListener('click', async function(){ var base=findSelected(); var name = window.extPrompt ? await window.extPrompt('Nome do novo perfil', base && base.name ? 'Cópia de '+base.name : 'Novo perfil') : null; name = String(name||'').trim(); if(!name) return; var slug='perfil-'+Date.now().toString(36); store.profiles.push({id:slug,name:name,builtin:false,blurb:'Perfil personalizado salvo pelo usuário.',values:sanitizeValues(base&&base.values, extractCurrentValues(opts))}); selectedProfileId = slug; setDirty(true); renderProfileList(); renderProfileEditor(); });
      head.appendChild(add); profileList.appendChild(head);
      store.profiles.forEach(function(profile){ var btn=document.createElement('button'); btn.type='button'; btn.className='extuiSafetyProfileItem'+(profile.id===selectedProfileId?' is-active':'')+(profile.id===store.activeProfileId?' is-current':''); btn.innerHTML='<strong></strong><small></small>'; btn.querySelector('strong').textContent=profile.name; btn.querySelector('small').textContent=profile.blurb||''; btn.setAttribute('aria-current',profile.id===store.activeProfileId?'true':'false'); btn.addEventListener('click', async function(){ if(profile.id===selectedProfileId) return; var ok = await maybeResolveUnsaved(); if(!ok) return; store = buildStore(opts); selectedProfileId = profile.id; renderProfileList(); renderProfileEditor(); }); profileList.appendChild(btn); });
    }
    function renderProfileEditor(){
      editor.innerHTML='';
      var selected=findSelected(); if(!selected) return;
      var builtin=!!selected.builtin, builtinDefault = builtin ? defaultProfileById(selected.id) : null, editable=!builtin || unlockBuiltins[selected.id]===true;
      var header=document.createElement('div'); header.className='extuiSafetyEditorHeader';
      var copy=document.createElement('div'); copy.innerHTML='<div class="extuiSafetyEditorEyebrow">PROTEÇÃO DE ENVIO</div><h3></h3><p></p>';
      copy.querySelector('h3').textContent=selected.name; copy.querySelector('p').textContent=selected.blurb || (builtin ? 'Perfil padrão da extensão.' : 'Perfil personalizado.');
      var isActiveProfile=selected.id===store.activeProfileId;
      var tags=document.createElement('div'); tags.className='extuiSafetyEditorTags'; tags.appendChild(elTag(isActiveProfile?'Ativo':'Inativo', isActiveProfile?'is-ok':'is-inactive')); header.appendChild(copy); header.appendChild(tags); editor.appendChild(header);
      var actions=document.createElement('div'); actions.className='extuiSafetyProfileActions';
      var save=document.createElement('button'); save.type='button'; save.className='extui-btn extui-btn--primary'; save.textContent=builtin?'Salvar alterações':'Salvar perfil'; save.addEventListener('click', async function(){ try{ await saveStore(); renderStatusBar(); renderProfileList(); renderProfileEditor(); }catch(err){ toast(err&&err.message||'Não foi possível salvar o perfil.', true); } }); actions.appendChild(save);
      if(builtin){ var reset=document.createElement('button'); reset.type='button'; reset.className='extui-btn extui-btn--ghost'; reset.textContent='Resetar padrão'; reset.disabled = !builtinDefault || valuesEqual(selected.values, builtinDefault.values); reset.addEventListener('click', function(){ if(!builtinDefault) return; selected.values = sanitizeValues(builtinDefault.values, builtinDefault.values); unlockBuiltins[selected.id]=false; setDirty(true); renderProfileList(); renderProfileEditor(); }); actions.appendChild(reset); }
      var apply=document.createElement('button'); apply.type='button'; apply.className='extui-btn extui-btn--secondary'; apply.textContent=isActiveProfile?'Perfil ativo':'Ativar este perfil'; apply.disabled=isActiveProfile; apply.title=isActiveProfile?'Este já é o perfil ativo.':'Salva a configuração atual e torna este o perfil usado pelos guardrails.'; apply.addEventListener('click', async function(){ try{ store.activeProfileId = selectedProfileId; await saveStore(); renderStatusBar(); renderProfileList(); renderProfileEditor(); toast('Perfil '+selected.name+' ativado.'); }catch(err){ toast(err&&err.message||'Não foi possível ativar o perfil.', true); } }); actions.appendChild(apply); editor.appendChild(actions);
      if(builtin){ var unlock=document.createElement('label'); unlock.className='extuiSafetyUnlock'; unlock.innerHTML='<input type="checkbox"><span>Permitir editar este perfil padrão</span>'; unlock.querySelector('input').checked = editable; unlock.querySelector('input').addEventListener('change', function(){ unlockBuiltins[selected.id] = !!this.checked; renderProfileEditor(); }); editor.appendChild(unlock); }
      var grid=document.createElement('div'); grid.className='extuiSafetyProfileGrid';
      fieldDefs.forEach(function(def){ var field=document.createElement('label'); field.className='extuiSafetyProfileField'; field.innerHTML='<span class="title"></span><small class="desc"></small><div class="inputRow"><input type="number"><em></em></div>'; field.querySelector('.title').textContent=def.title; field.querySelector('.desc').textContent=def.desc; var input=field.querySelector('input'); input.min=String(def.min); input.max=String(def.max); input.step=String(def.step||1); input.value=String(selected.values[def.key]); input.disabled = builtin && !editable; field.querySelector('em').textContent=def.suffix||''; input.addEventListener('input', function(){ var n = Number(input.value); if(!isFinite(n)) n = def.min; n=Math.max(def.min, Math.min(def.max, n)); if(def.step>=1) n=Math.round(n/def.step)*def.step; selected.values[def.key]=n; setDirty(true); }); grid.appendChild(field); });
      editor.appendChild(grid);
      var quiet=document.createElement('div'); quiet.className='extuiSafetyTimingCard';
      quiet.innerHTML='<div class="extuiSafetyTimingHead"><strong>Janela de automação</strong><span>Defina dias e horário para reduzir envios fora do expediente esperado.</span></div><div class="extuiSafetyTimingBody"><label class="extuiAjustesRow extuiSafetyInlineToggle"><div class="extuiAjustesRowText"><div class="title">Restringir horário das automações</div><div class="desc">Ações manuais continuam possíveis; o bloqueio vale para automações e campanhas.</div></div><span class="extuiSwitch"><input type="checkbox"><span class="track"></span></span></label><div class="extuiSafetyTimeInputs"><label><span>Início</span><input type="time"></label><label><span>Fim</span><input type="time"></label></div><div class="extuiSafetyDays"></div></div>';
      var quietToggle=quiet.querySelector('.extuiSwitch input'); quietToggle.checked = selected.values.sendSafetyQuietHoursEnabled !== false; quietToggle.disabled = builtin && !editable; quietToggle.addEventListener('change', function(){ selected.values.sendSafetyQuietHoursEnabled = !!quietToggle.checked; setDirty(true); });
      var timeInputs=quiet.querySelectorAll('.extuiSafetyTimeInputs input'); timeInputs[0].value = ensureTime(selected.values.sendSafetyQuietStart,'08:00'); timeInputs[1].value = ensureTime(selected.values.sendSafetyQuietEnd,'20:00'); Array.prototype.forEach.call(timeInputs, function(input, index){ input.disabled = builtin && !editable; input.addEventListener('change', function(){ if(index===0) selected.values.sendSafetyQuietStart = input.value || '08:00'; else selected.values.sendSafetyQuietEnd = input.value || '20:00'; setDirty(true); }); });
      var daysWrap = quiet.querySelector('.extuiSafetyDays'); dayDefs.forEach(function(def){ var label=document.createElement('label'); label.className='extuiSafetyDayChip'; var inp=document.createElement('input'); inp.type='checkbox'; inp.checked = (selected.values.sendSafetyAllowedDays||[]).indexOf(def.d)>=0; inp.disabled = builtin && !editable; var span=document.createElement('span'); span.textContent=def.l; inp.addEventListener('change', function(){ var next=[]; Array.prototype.forEach.call(daysWrap.querySelectorAll('input'), function(node, idx){ if(node.checked) next.push(dayDefs[idx].d); }); if(!next.length){ inp.checked=true; next=[def.d]; } selected.values.sendSafetyAllowedDays = next; setDirty(true); }); label.appendChild(inp); label.appendChild(span); daysWrap.appendChild(label); }); editor.appendChild(quiet);
      if(!builtin){ var footer=document.createElement('div'); footer.className='extuiSafetyEditorFooter extuiSafetyEditorFooter--secondary'; var rename=document.createElement('button'); rename.type='button'; rename.className='extui-btn extui-btn--ghost'; rename.textContent='Renomear'; rename.addEventListener('click', async function(){ var name = window.extPrompt ? await window.extPrompt('Nome do perfil', selected.name) : null; name=String(name||'').trim(); if(!name) return; selected.name=name; setDirty(true); renderProfileList(); renderProfileEditor(); }); var remove=document.createElement('button'); remove.type='button'; remove.className='extui-btn extui-btn--danger'; remove.textContent='Excluir perfil'; remove.addEventListener('click', async function(){ if(window.extConfirm&&!(await window.extConfirm('Excluir este perfil personalizado?',{danger:true}))) return; var removedWasActive=store.activeProfileId===selected.id; store.profiles = store.profiles.filter(function(profile){ return profile.id!==selected.id; }); selectedProfileId = store.profiles[0] ? store.profiles[0].id : 'conservador'; if(removedWasActive) store.activeProfileId = selectedProfileId; setDirty(true); renderProfileList(); renderProfileEditor(); }); footer.appendChild(rename); footer.appendChild(remove); editor.appendChild(footer); }
    }
    function renderStatusBar(){
      var active = store.profiles.find(function(profile){ return profile.id===store.activeProfileId; }) || store.profiles[0], disabled=opts.sendSafetyEnabled===false, paused=opts.sendSafetyGlobalPause===true;
      statusBar.innerHTML=''; statusBar.className='extuiSafetyProfileBar '+(disabled?'is-disabled':'is-enabled');
      var activeName = document.createElement('div'); activeName.className='extuiSafetyActiveProfile'; activeName.innerHTML='<strong>Perfil ativo</strong><span></span>'; activeName.querySelector('span').textContent = active ? active.name : 'Conservador';
      var hint = document.createElement('div'); hint.className='extuiSafetyStatusHint'; hint.textContent = disabled ? 'A Proteção de envio está desligada globalmente; este perfil permanece selecionado para quando ela for reativada.' : paused ? 'Novos envios automáticos estão pausados globalmente; o perfil ativo não foi alterado.' : 'Este é o perfil aplicado atualmente aos guardrails de envio.';
      statusBar.appendChild(activeName); statusBar.appendChild(hint);
    }
    function elTag(text, cls){ var tag=document.createElement('span'); tag.className='extuiSafetyEditorTag '+cls; tag.textContent=text; return tag; }
    function rerenderAll(){ updateSavedNote(); renderGlobalControls(); renderStatusBar(); renderProfileList(); renderProfileEditor(); }
    rerenderAll();
  }


  function sendKeepAwake(level) {
    try { chrome.runtime.sendMessage({ __extSetKeepAwake: true, level: level }); } catch (err) { }
  }

  function renderSistemaCard(wrap, opts) {
    var card = document.createElement("div");
    card.className = "extuiCard extuiAjustesSystemCardV3";
    var h2 = document.createElement("h2");
    h2.innerHTML = 'Sistema <span class="extuiAjustesSavedNote">salvo</span>';
    card.appendChild(h2);

    function radioRow(title, desc, level) {
      var row = document.createElement("div");
      row.className = "extuiAjustesRow";
      row.innerHTML =
        '<div class="extuiAjustesRowText"><div class="title">' + title + '</div><div class="desc">' + desc + '</div></div>' +
        '<label class="extuiSwitch"><input type="checkbox" ' + (opts.keepAwakeLevel === level ? "checked" : "") + '><span class="track"></span></label>';
      row.querySelector("input").addEventListener("change", async function (ev) {
        var previousLevel=opts.keepAwakeLevel,newLevel = ev.target.checked ? level : "off";
        opts.keepAwakeLevel = newLevel;
        sendKeepAwake(newLevel);
                                                                         
                                                                      
                                                   
        Array.prototype.forEach.call(card.querySelectorAll(".extuiSwitch input"), function (inp) { inp.checked = false; });
        if (newLevel !== "off") ev.target.checked = true;
        try { await storageSet(STORAGE_KEY, opts); flashSaved(card); }
        catch (err) { opts.keepAwakeLevel=previousLevel;sendKeepAwake(previousLevel);Array.prototype.forEach.call(card.querySelectorAll(".extuiSwitch input"),function(inp){inp.checked=false;});var previousIndex=previousLevel==="system"?0:previousLevel==="display"?1:-1;if(previousIndex>=0){var inputs=card.querySelectorAll(".extuiSwitch input");if(inputs[previousIndex])inputs[previousIndex].checked=true;}toast(err&&err.message||"Não foi possível salvar a preferência de energia.",true); }
      });
      card.appendChild(row);
    }
    radioRow("Manter computador ligado", "Impede o computador de suspender/dormir enquanto a extensão estiver instalada. A tela ainda pode apagar.", "system");
    radioRow("Manter tela ligada", "Impede o computador de suspender E a tela de apagar - mais forte, gasta mais energia.", "display");
    wrap.appendChild(card);
  }

                                                                            
                                                                          
                                                                      
                                                                            
                      
                                                                          
    
                                                                                  
                                                                        
                                                                          
                                                                     
                                                                        
                                                                       
                                                                          
                                                                       
                                                                     
                                                                     
                                                                         
                                                                         
                                                                        
                                                                          
                                                                        

  var LIST_STORE_SPECS = [
    { key: "EXTUI:textMessageStore", listField: "textMessageList", label: "Mensagens" },
    { key: "EXTUI:audioStore", listField: "audioList", label: "Áudios" },
    { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagens e vídeos" },
    { key: "EXTUI:stickerStore", listField: "stickerList", label: "Figurinhas" },
    { key: "EXTUI:documentStore", listField: "documentList", label: "Documentos" },
    { key: "EXTUI:extappFlowStore", listField: "flowList", label: "Fluxos" },
    { key: "EXTUI:extappFunnelStore", listField: "funnelList", label: "Funis" },
    { key: "EXTUI:CrmStore", listField: "crmList", label: "CRM" }
  ];
  var SCHEDULE_STORE_KEY = "EXTUI:extappScheduleStore";
  var EXTERNAL_TRIGGER_STORE_KEY = "EXTUI:triggerStore";
                                                                        
                                                                    
                                                                          
                                                                     
                                                                
                                                                   
                                                                   
                                                                       
                                                          
    
                                                                        
                                                                         
                                                                           
                                                                           
                                                                        
                                                                        
                                                                       
                                                                          

  function extBackupUid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
  }

                                                                              
                                                                            
                                                                            
                                                                           
                                                                          
                                                                           
                                                                              
                                                                 
  var EXTUI_UNSAFE_KEYS = ["__proto__", "constructor", "prototype"];
  function extIsUnsafeKey(k) {
    return EXTUI_UNSAFE_KEYS.indexOf(String(k)) !== -1;
  }
  function extSafeCopy(src) {
    var out = {};
    Object.keys(src).forEach(function (k) {
      if (extIsUnsafeKey(k)) return;
      out[k] = src[k];
    });
    return out;
  }

  function extLooksLikeStorageDump(obj) {
    return !!(obj && typeof obj === "object" && !Array.isArray(obj) &&
      Object.keys(obj).some(function (k) { return k.indexOf("EXTUI:") === 0; }));
  }
  function extLegacyNamespaceKey(key) {
    key = String(key || "");
    var schema = window.__extStorageSchema, byKey = schema && schema.byKey || null;
    if (byKey && byKey[key] || key === "ext:bulkQueue") return key;
    var colon = key.indexOf(":"), tail = colon > 0 && colon <= 16 ? key.slice(colon + 1) : "";
    if (!tail) return key;
    var exact = "EXTUI:" + tail;
    if (byKey && byKey[exact]) return exact;
    var m = /^([a-z]{2,12})([A-Z][A-Za-z0-9_]*)$/.exec(tail);
    if (m) { var candidate = "EXTUI:extapp" + m[2]; if (byKey && byKey[candidate]) return candidate; }
    return key;
  }
  function extLegacyNamespaceValue(value) {
    function normalizeText(text) { return String(text).replace(/(^|[^A-Za-z0-9_-])([a-z]{2,12})-media:([A-Za-z0-9_-]{8,96})/g, function (all, before, owner, id) { return owner === "extapp" ? all : before + "extapp-media:" + id; }); }
    if (typeof value === "string") return normalizeText(value);
    if (Array.isArray(value)) return value.map(extLegacyNamespaceValue);
    if (value && typeof value === "object") { var out = {}; Object.keys(value).forEach(function (k) { if (!extIsUnsafeKey(k)) out[k] = extLegacyNamespaceValue(value[k]); }); return out; }
    return value;
  }
  function extNormalizeLegacyStorageDump(obj) {
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return obj;
    var out = {}, changed = false;
    Object.keys(obj).forEach(function (key) {
      if (extIsUnsafeKey(key)) return;
      var next = extLegacyNamespaceKey(key);
      out[next] = extLegacyNamespaceValue(obj[key]);
      if (next !== key) changed = true;
    });
    return changed ? out : obj;
  }



                                                                         
                                                                       
                                                                         
                                                                          
                                                                         
                                                                        
                                                                          
                                                                      
function extShowBackupProgress(text) {
    extHideBackupProgress();
    var overlay = document.createElement("div");
    overlay.className = "extui-modal-overlay";
    overlay.id = "extuiBackupProgressOverlay";
    overlay.setAttribute("aria-busy", "true");
    var modal = document.createElement("div");
    modal.className = "extui-modal";
    modal.style.width = "300px";
    modal.style.textAlign = "center";
    modal.setAttribute("role", "status");
    modal.setAttribute("aria-live", "polite");
    modal.setAttribute("aria-atomic", "true");
    var spinner = document.createElement("div");
    spinner.className = "extuiSpinner";
    spinner.setAttribute("aria-hidden", "true");
    var progressText = document.createElement("p");
    progressText.id = "extuiBackupProgressText";
    progressText.className = "extuiBackupProgressText";
    modal.appendChild(spinner);
    modal.appendChild(progressText);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    extSetBackupProgress(text);
    return overlay;
  }
  function extSetBackupProgress(text) {
    var el = document.getElementById("extuiBackupProgressText");
    if (el) el.textContent = text;
  }
    function extHideBackupProgress() {
    var el = document.getElementById("extuiBackupProgressOverlay");
    if (el) el.remove();
  }
  function extNextFrame() {
    return new Promise(function (resolve) { setTimeout(resolve, 0); });
  }

                                                                       
                                                                         
                                                                     
                                                                         
                                                                      
                                                                         
                                                                           
                                
  function extBackupFsFolderName(raw){return String(raw||"ZVM-BACKUPs").replace(/[\\\/:*?"<>|]+/g,"-").replace(/^\.+$/g,"-").trim().slice(0,80)||"ZVM-BACKUPs";}
  function extBackupFsPrefix(raw){var value=String(raw||"zvm_backup").trim();try{value=value.normalize("NFKD").replace(/[\u0300-\u036f]/g,"");}catch(_){}value=value.replace(/\s+/g,"_").replace(/[^A-Za-z0-9_-]+/g,"_").replace(/_+/g,"_").replace(/^[_-]+|[_-]+$/g,"").slice(0,48);return value||"zvm_backup";}
  function extBackupNormalizeFormat(raw){raw=String(raw||"zip").toLowerCase();return raw==="json"?"json":raw==="secure"?"secure":"zip";}
  function extBackupSafeZipPath(raw){var name=String(raw||"");if(!name||name.length>320||name.indexOf("\\")>=0||name[0]==="/"||/^[A-Za-z]:/.test(name))return false;var parts=name.split("/");return !parts.some(function(part){return !part||part==="."||part==="..";});}
  function extBackupZipAssetToken(value){var m=/^extapp-zip-asset:([A-Za-z0-9_-]{1,96})$/.exec(String(value||""));return m?m[1]:"";}
  function extBackupReadJsonValue(raw){var backup,nested=raw&&raw.data&&typeof raw.data==="object"&&!Array.isArray(raw.data)?extNormalizeLegacyStorageDump(raw.data):null;if(raw&&raw.format==="EXTAPP_BACKUP"&&nested){backup=Object.assign({},raw,{format:"EXTAPP_BACKUP",data:nested});}else if(nested&&extLooksLikeStorageDump(nested)){backup=Object.assign({},raw,{format:"EXTAPP_BACKUP",data:nested});}else{var compat=window.__extBackupCompatibility&&typeof window.__extBackupCompatibility.detect==="function"?window.__extBackupCompatibility.detect(raw):null;if(compat&&compat.source&&compat.source!=="unknown")return raw;var repaired=extRepairBackupData(raw);if(!repaired.recognized)throw new Error("Formato não reconhecido. Use uma cópia compatível com esta versão da extensão.");backup={format:"EXTAPP_BACKUP",version:5,createdAt:new Date().toISOString(),mode:"extapp-storage-import",sourceFormat:"extapp-storage-dump",compatibilityReport:Array.isArray(repaired.fixes)?repaired.fixes.slice():[],data:repaired.data,keys:Object.keys(repaired.data),security:{secretsIncluded:false}};}return backup;}
  function extBackupReadJsonText(text){return extBackupReadJsonValue(JSON.parse(String(text||"")));}
  var EXTUI_BACKUP_ZIP_CRC_TABLE=(function(){var t=new Uint32Array(256);for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);t[n]=c>>>0;}return t;})();
  function extBackupZipU16(view,off){return view.getUint16(off,true);}
  function extBackupZipU32(view,off){return view.getUint32(off,true);}
  function extBackupZipCrcUpdate(crc,bytes){crc=crc>>>0;for(var i=0;i<bytes.length;i++)crc=EXTUI_BACKUP_ZIP_CRC_TABLE[(crc^bytes[i])&255]^(crc>>>8);return crc>>>0;}
  async function extBackupZipCrcBlob(blob){var crc=0xFFFFFFFF,reader=blob.stream().getReader();try{while(true){var r=await reader.read();if(r.done)break;crc=extBackupZipCrcUpdate(crc,r.value);}}finally{try{reader.releaseLock();}catch(_){}}return(crc^0xFFFFFFFF)>>>0;}
  async function extBackupZipFindEocd(file){var tailSize=Math.min(Number(file.size)||0,65557),start=Math.max(0,file.size-tailSize),buf=await file.slice(start).arrayBuffer(),v=new DataView(buf);for(var i=v.byteLength-22;i>=0;i--){if(extBackupZipU32(v,i)!==0x06054b50)continue;var comment=extBackupZipU16(v,i+20);if(i+22+comment!==v.byteLength)continue;return{absolute:start+i,view:v,offset:i,commentLength:comment};}throw new Error("A cópia ZIP não possui um diretório central válido.");}
  async function extBackupZipLocalEntry(file,entry){if(entry.localOffset+30>file.size)throw new Error("Entrada ZIP aponta para uma posição inválida: "+entry.name);var headBuf=await file.slice(entry.localOffset,entry.localOffset+30).arrayBuffer(),v=new DataView(headBuf);if(extBackupZipU32(v,0)!==0x04034b50)throw new Error("Cabeçalho local ZIP inválido: "+entry.name);var flags=extBackupZipU16(v,6),method=extBackupZipU16(v,8),nameLen=extBackupZipU16(v,26),extraLen=extBackupZipU16(v,28);if(flags&1)throw new Error("Cópias ZIP criptografadas não são suportadas.");if((method!==0&&method!==8)||method!==entry.method)throw new Error("Esta cópia usa um método ZIP não suportado pela extensão.");if(flags!==entry.flags)throw new Error("Flags ZIP divergentes para "+entry.name);var nameStart=entry.localOffset+30,nameEnd=nameStart+nameLen,dataStart=nameEnd+extraLen;if(dataStart>file.size)throw new Error("Entrada ZIP truncada: "+entry.name);var localName=new TextDecoder("utf-8",{fatal:false}).decode(new Uint8Array(await file.slice(nameStart,nameEnd).arrayBuffer()));if(localName!==entry.name)throw new Error("Nome local e central divergentes no ZIP.");var dataEnd=dataStart+entry.compressedSize;if(dataEnd>file.size)throw new Error("Conteúdo ZIP truncado: "+entry.name);var endOffset=dataEnd;if(flags&0x0008){if(dataEnd+16>file.size)throw new Error("Descritor ZIP ausente: "+entry.name);var dBuf=await file.slice(dataEnd,dataEnd+16).arrayBuffer(),d=new DataView(dBuf);if(extBackupZipU32(d,0)!==0x08074b50||extBackupZipU32(d,4)!==entry.crc32||extBackupZipU32(d,8)!==entry.compressedSize||extBackupZipU32(d,12)!==entry.uncompressedSize)throw new Error("Descritor ZIP inválido: "+entry.name);endOffset=dataEnd+16;}return Object.assign(entry,{dataStart:dataStart,dataEnd:dataEnd,endOffset:endOffset});}
  async function extBackupZipReadEntryBlob(file,entry,maxBytes,mimeType){maxBytes=Math.max(1,Number(maxBytes)||1);if(entry.uncompressedSize>maxBytes)throw new Error("Entrada ZIP excede o limite seguro: "+entry.name);var packed=file.slice(entry.dataStart,entry.dataEnd,"application/octet-stream"),blob;if(entry.method===0){if(entry.compressedSize!==entry.uncompressedSize)throw new Error("Entrada ZIP STORE possui tamanhos divergentes: "+entry.name);blob=file.slice(entry.dataStart,entry.dataEnd,mimeType||"application/octet-stream");}else if(entry.method===8){if(typeof DecompressionStream!=="function")throw new Error("Este navegador não oferece descompressão ZIP compatível.");var reader=packed.stream().pipeThrough(new DecompressionStream("deflate-raw")).getReader(),parts=[],total=0;try{while(true){var r=await reader.read();if(r.done)break;total+=r.value.byteLength;if(total>maxBytes||total>entry.uncompressedSize)throw new Error("Entrada ZIP expandiu além do tamanho declarado: "+entry.name);parts.push(r.value);}}finally{try{reader.releaseLock();}catch(_){}}if(total!==entry.uncompressedSize)throw new Error("Tamanho descompactado divergente: "+entry.name);blob=new Blob(parts,{type:mimeType||"application/octet-stream"});}else throw new Error("Método ZIP não suportado: "+entry.method);var crc=await extBackupZipCrcBlob(blob);if(crc!==entry.crc32)throw new Error("A entrada ZIP falhou na verificação CRC32: "+entry.name);return blob;}
  async function extBackupLoadZipModel(file){
    if(Number(file&&file.size||0)>2200*1024*1024)throw new Error("A cópia ZIP excede o limite seguro atual de 2,2 GB.");
    var eocd=await extBackupZipFindEocd(file),v=eocd.view,o=eocd.offset,disk=extBackupZipU16(v,o+4),centralDisk=extBackupZipU16(v,o+6),diskEntries=extBackupZipU16(v,o+8),totalEntries=extBackupZipU16(v,o+10),centralSize=extBackupZipU32(v,o+12),centralOffset=extBackupZipU32(v,o+16);
    if(disk!==0||centralDisk!==0||diskEntries!==totalEntries)throw new Error("Cópias ZIP multipart não são suportadas.");
    if(totalEntries<1||totalEntries>5001)throw new Error("A cópia contém uma quantidade inválida de arquivos.");
    if(centralOffset===0xFFFFFFFF||centralSize===0xFFFFFFFF)throw new Error("ZIP64 ainda não é aceito pelo importador desta versão.");
    if(centralOffset+centralSize>eocd.absolute||centralOffset+centralSize>file.size)throw new Error("Diretório central ZIP fora dos limites do arquivo.");
    var cbuf=await file.slice(centralOffset,centralOffset+centralSize).arrayBuffer(),cv=new DataView(cbuf),pos=0,decoder=new TextDecoder("utf-8",{fatal:false}),entries=[],seen=new Set();
    for(var idx=0;idx<totalEntries;idx++){
      if(pos+46>cv.byteLength||extBackupZipU32(cv,pos)!==0x02014b50)throw new Error("Diretório central ZIP corrompido.");
      var flags=extBackupZipU16(cv,pos+8),method=extBackupZipU16(cv,pos+10),crc=extBackupZipU32(cv,pos+16),comp=extBackupZipU32(cv,pos+20),uncomp=extBackupZipU32(cv,pos+24),nameLen=extBackupZipU16(cv,pos+28),extraLen=extBackupZipU16(cv,pos+30),commentLen=extBackupZipU16(cv,pos+32),diskStart=extBackupZipU16(cv,pos+34),localOffset=extBackupZipU32(cv,pos+42),end=pos+46+nameLen+extraLen+commentLen;
      if(end>cv.byteLength)throw new Error("Entrada central ZIP truncada.");
      if(flags&1)throw new Error("Cópias ZIP criptografadas não são suportadas.");
      if(method!==0&&method!==8)throw new Error("Esta cópia usa um método ZIP não suportado pela extensão.");
      if(comp===0xFFFFFFFF||uncomp===0xFFFFFFFF||localOffset===0xFFFFFFFF)throw new Error("ZIP64 ainda não é aceito pelo importador desta versão.");
      if(method===0&&comp!==uncomp)throw new Error("Entrada ZIP STORE possui tamanhos divergentes.");
      if(method===8&&uncomp>1024*1024&&comp>0&&uncomp/comp>250)throw new Error("A cópia contém uma entrada com taxa de expansão ZIP insegura.");
      if(diskStart!==0)throw new Error("Cópias ZIP multipart não são suportadas.");
      var name=decoder.decode(new Uint8Array(cbuf,pos+46,nameLen));
      if(!extBackupSafeZipPath(name)||seen.has(name))throw new Error("A cópia contém caminho inválido ou duplicado: "+name);
      seen.add(name);entries.push({name:name,flags:flags,method:method,crc32:crc,compressedSize:comp,uncompressedSize:uncomp,localOffset:localOffset});pos=end;
    }
    if(pos!==cv.byteLength)throw new Error("Diretório central ZIP contém dados inesperados.");
    for(var i=0;i<entries.length;i++)entries[i]=await extBackupZipLocalEntry(file,entries[i]);
    var ranges=entries.map(function(e){return{start:e.localOffset,end:e.endOffset,name:e.name};}).sort(function(a,b){return a.start-b.start;});
    for(var r=0;r<ranges.length;r++){if(ranges[r].end>centralOffset)throw new Error("Uma entrada ZIP invade o diretório central.");if(r>0&&ranges[r].start<ranges[r-1].end)throw new Error("A cópia contém entradas ZIP sobrepostas.");}
    var totalExpanded=0;entries.forEach(function(e){totalExpanded+=Number(e.uncompressedSize)||0;if(totalExpanded>2100*1024*1024)throw new Error("O conteúdo descompactado da cópia excede o limite seguro atual.");});
    var byName=new Map();entries.forEach(function(e){byName.set(e.name,e);});var backupEntry=byName.get("backup.json");if(!backupEntry)throw new Error("A cópia ZIP não contém backup.json.");if(backupEntry.uncompressedSize>32*1024*1024)throw new Error("O backup.json excede o limite seguro de 32 MB.");
    var backupBlob=await extBackupZipReadEntryBlob(file,backupEntry,32*1024*1024,"application/json");
    var backup=extBackupReadJsonText(await backupBlob.text()),manifest=Array.isArray(backup.binaryAssets)?backup.binaryAssets:[],byToken=new Map(),declaredPaths=new Set(),declaredTotal=0;
    if(manifest.length>5000)throw new Error("A cópia contém assets demais para ser processada com segurança.");
    manifest.forEach(function(meta){if(!meta||typeof meta!=="object")throw new Error("Manifesto de assets inválido.");var token=String(meta.id||""),path=String(meta.path||""),size=Math.max(0,Number(meta.sizeBytes)||0);if(!/^[A-Za-z0-9_-]{1,96}$/.test(token)||!extBackupSafeZipPath(path)||path.indexOf("assets/")!==0)throw new Error("Manifesto de assets contém uma referência inválida.");if(byToken.has(token)||declaredPaths.has(path))throw new Error("Manifesto de assets contém identificadores duplicados.");var entry=byName.get(path);if(!entry)throw new Error("Asset declarado não encontrado: "+path);if(size>200*1024*1024||entry.uncompressedSize>200*1024*1024)throw new Error("Um asset da cópia excede o limite de 200 MB suportado pelo cofre de mídia.");if(size&&Math.abs(size-entry.uncompressedSize)>1024)throw new Error("O tamanho declarado de um asset não corresponde ao ZIP: "+path);declaredTotal+=Math.max(size,entry.uncompressedSize);if(declaredTotal>2*1024*1024*1024)throw new Error("Os assets da cópia excedem o limite seguro atual de 2 GB.");byToken.set(token,Object.assign({},meta,{entry:entry}));declaredPaths.add(path);});
    entries.forEach(function(entry){if(entry.name==="backup.json")return;if(entry.name.indexOf("assets/")!==0)throw new Error("A cópia contém um arquivo inesperado: "+entry.name);if(!declaredPaths.has(entry.name))throw new Error("A cópia contém um asset não declarado no manifesto: "+entry.name);});
    return{file:file,backup:backup,manifest:byToken,entries:byName};
  }
  function extBackupCollectZipTokens(value,set,depth){if(depth>28)throw new Error("Estrutura da cópia é profunda demais.");if(typeof value==="string"){var token=extBackupZipAssetToken(value);if(token){set.add(token);return;}var t=value.trim();if(value.length<32*1024*1024&&((t[0]==="{"&&t[t.length-1]==="}")||(t[0]==="["&&t[t.length-1]==="]"))){try{extBackupCollectZipTokens(JSON.parse(value),set,depth+1);}catch(err){if(err&&/profunda demais/.test(String(err.message||"")))throw err;}}return;}if(Array.isArray(value)){value.forEach(function(v){extBackupCollectZipTokens(v,set,depth+1);});return;}if(value&&typeof value==="object")Object.keys(value).forEach(function(k){if(k!=="binaryAssets")extBackupCollectZipTokens(value[k],set,depth+1);});}
  async function extBackupPreflightZipAssets(value,ctx){var tokens=new Set();extBackupCollectZipTokens(value,tokens,0);var total=0;ctx.extracted=ctx.extracted||new Map();for(var token of tokens){var meta=ctx.manifest.get(token);if(!meta)throw new Error("Referência de asset ausente no manifesto: "+token);var entry=meta.entry,blob=await extBackupZipReadEntryBlob(ctx.file,entry,200*1024*1024,String(meta.mimeType||"application/octet-stream"));total+=blob.size;if(total>2*1024*1024*1024)throw new Error("Os assets selecionados excedem o limite seguro atual de 2 GB.");ctx.extracted.set(token,blob);}return{tokens:tokens,totalBytes:total};}
  async function extBackupResolveZipAssets(value,ctx,depth){
    if(depth>28)throw new Error("Estrutura da cópia é profunda demais.");
    if(typeof value==="string"){
      var token=extBackupZipAssetToken(value);if(token){if(ctx.refs.has(token))return ctx.refs.get(token);var meta=ctx.manifest.get(token);if(!meta)throw new Error("Referência de asset ausente no manifesto: "+token);var entry=meta.entry,blob=ctx.extracted&&ctx.extracted.get(token);if(!blob)blob=await extBackupZipReadEntryBlob(ctx.file,entry,200*1024*1024,String(meta.mimeType||"application/octet-stream"));if(blob.size>200*1024*1024)throw new Error("Asset excede 200 MB: "+String(meta.fileName||meta.path));var file=new File([blob],String(meta.fileName||"arquivo"),{type:String(meta.mimeType||blob.type||"application/octet-stream")});var ref=await window.ExtensionMediaStore.putFile(file);ctx.refs.set(token,ref);return ref;}
      var t=value.trim();if(value.length<32*1024*1024&&((t[0]==="{"&&t[t.length-1]==="}")||(t[0]==="["&&t[t.length-1]==="]"))){var parsed;try{parsed=JSON.parse(value);}catch(_parseErr){return value;}var resolved=await extBackupResolveZipAssets(parsed,ctx,depth+1);return JSON.stringify(resolved);}return value;
    }
    if(Array.isArray(value)){var arr=[];for(var i=0;i<value.length;i++)arr.push(await extBackupResolveZipAssets(value[i],ctx,depth+1));return arr;}
    if(value&&typeof value==="object"){var out={};for(var k of Object.keys(value)){if(k==="binaryAssets")continue;out[k]=await extBackupResolveZipAssets(value[k],ctx,depth+1);}return out;}return value;
  }

  function renderBackupCard(wrap) {
    var service = window.__extBackupMigrationService;
    var card = document.createElement("div");
    card.className = "extuiCard";
    card.id = "extuiBackupCard";
    if (!service) {
      card.innerHTML = '<div class="extuiAjustesKeyLabel">O recurso de cópia de segurança não foi carregado. Recarregue o Painel de Controle.</div>';
      wrap.appendChild(card); return;
    }
    var preferredCategoryOrder = ["flows","funnels","agenda","followups","crm","customers","orders","items","quickResponses","bulk","contacts","transcriptions","automation","ai","integrations","webhooks","personalization","settings","status","experience"];
    var categoryIds = preferredCategoryOrder.filter(function(id){ return service.defaultCategories.indexOf(id) >= 0 && id!=="trash"; }).concat(service.defaultCategories.filter(function(id){ return preferredCategoryOrder.indexOf(id) < 0 && id!=="trash"; }));
    var importCategoryIds=categoryIds.concat(service.categories.trash?["trash"]:[]);
    var selected = {};
    categoryIds.forEach(function(id){ selected[id] = true; });
    var backupFootnotes=[];
    var categoryRows = categoryIds.map(function(id){
      var meta=service.categories[id];
      var desc=meta.description||(meta.safeWithoutSecrets?"Chaves de acesso e dados protegidos não são incluídos.":"");
      var row='<label class="extuiBackupToggleRow"><span class="extuiBackupToggleCopy"><strong>'+escHtmlAjustes(meta.label)+'</strong>'+(desc?'<small>'+escHtmlAjustes(desc)+'</small>':'')+'</span><span class="extuiSwitch"><input type="checkbox" data-backup-category="'+id+'" checked><span class="track"></span></span></label>';
      if(id==="experience"){row+='<label class="extuiBackupToggleRow extuiBackupTrashToggle"><span class="extuiBackupToggleCopy"><strong>Lixeira</strong></span><span class="extuiSwitch"><input type="checkbox" id="extuiBackupIncludeTrash" checked><span class="track"></span></span></label>';}
      return row;
    }).join("");
    if(categoryIds.indexOf("ai")>=0)backupFootnotes.push('<li><strong>IA:</strong> Inclui Assistentes, Agentes, Bases de Conhecimento e preferências de Tradução/Transcrição; credenciais e chaves de API não entram na cópia.</li>');
    if(categoryIds.indexOf("integrations")>=0)backupFootnotes.push('<li><strong>Integrações:</strong> Configurações portáveis entram na cópia; tokens, segredos e outras credenciais protegidas permanecem fora.</li>');
    if(categoryIds.indexOf("webhooks")>=0)backupFootnotes.push('<li><strong>Webhooks:</strong> Configurações podem ser copiadas, mas segredos de assinatura e tokens não são exportados; a cópia é cancelada se uma credencial for detectada.</li>');
    if(categoryIds.indexOf("bulk")>=0)backupFootnotes.push('<li><strong>Disparos em Massa:</strong> Inclui histórico, campanhas/jornadas, grupos e preferências; a fila de envio em andamento nunca é copiada nem restaurada.</li>');
    if(categoryIds.indexOf("transcriptions")>=0)backupFootnotes.push('<li><strong>Transcrições de Áudio:</strong> Inclui o histórico local já gerado; as preferências de Transcrição ficam dentro de IA.</li>');
    if(categoryIds.indexOf("experience")>=0)backupFootnotes.push('<li><strong>Lixeira:</strong> Quando ativo, inclui itens da Lixeira no backup.</li>');
    var backupFootnotesHtml=backupFootnotes.length?'<div class="extuiBackupFootnotes"><ul>'+backupFootnotes.join("")+'</ul></div>':"";
    var backupAutoHtml='<section class="extuiBackupAutoSection">'+backupFootnotesHtml+
      '<div class="extuiAjustesGroupLabel extuiBackupAutoTitle">Cópia Automática</div>'+
      '<div class="extuiAjustesKeyLabel extuiBackupAutoDescription">Cada cópia inclui os dados selecionados e, no formato ZIP, também os arquivos associados aos itens e demais assets suportados.</div>'+ 
      '<div class="extuiBackupAutoGrid">'+ 
        '<label class="extuiBackupToggleRow"><span class="extuiBackupToggleCopy"><strong>Ativar Cópia Automática</strong><small>Salva apenas as categorias selecionadas acima.</small></span><span class="extuiSwitch"><input type="checkbox" id="extuiBackupAutoEnabled"><span class="track"></span></span></label>'+ 
        '<label class="extuiAjustesFieldRow"><span class="extuiAjustesFieldLabel">Frequência</span><select class="extuiAjustesSelect" id="extuiBackupAutoInterval"><option value="15">A cada 15 minutos</option><option value="30">A cada 30 minutos</option><option value="60">A cada 1 hora</option><option value="120">A cada 2 horas</option><option value="240">A cada 4 horas</option><option value="360">A cada 6 horas</option><option value="480">A cada 8 horas</option><option value="720">A cada 12 horas</option><option value="1440">Diário</option><option value="10080">Semanal</option><option value="43200">Mensal</option></select></label>'+ 
        '<label class="extuiAjustesFieldRow"><span class="extuiAjustesFieldLabel">Histórico</span><select class="extuiAjustesSelect" id="extuiBackupRetention">'+Array.from({length:20},function(_,i){return '<option value="'+(i+1)+'">Manter '+(i+1)+' cópia'+(i?'s':'')+'</option>';}).join("")+'</select></label>'+ 
        '<div class="extuiBackupDestinationCard"><div class="extuiBackupFixedDestination"><span class="extuiBackupDestinationIcon" aria-hidden="true">⇩</span><div><span class="extuiAjustesFieldLabel">Diretório Principal</span><strong>Downloads</strong><small>Os arquivos são salvos na subpasta escolhida, com nome previsível em UTC.</small></div></div><div class="extuiBackupNamingRow"><label class="extuiBackupNamingField"><span class="extuiAjustesFieldLabel">Prefixo do arquivo</span><input class="extuiAjustesInput" id="extuiBackupPrefix" maxlength="48" placeholder="zvm_backup"></label><label class="extuiBackupNamingField"><span class="extuiAjustesFieldLabel">Subpasta do Backup</span><input class="extuiAjustesInput" id="extuiBackupFolder" maxlength="80" placeholder="ZVM-BACKUPs"></label><small class="extuiBackupDestinationPreview">Destino: Downloads / <span id="extuiBackupFolderPreview">ZVM-BACKUPs</span>.</small></div></div>'+ 
      '</div>'+ 
      '<button type="button" class="extui-btn extui-btn--ghost" id="extuiBackupCreateNow">Criar Cópia Agora</button>'+ 
      '<div class="extuiBackupFutureIntegrations"><div class="extuiAjustesGroupLabel">Integrações de Backup</div><div class="extuiBackupDriveDisabled"><strong>Google Drive</strong><span>Ainda não disponível: o Google Drive exige um login adicional e permissões extras. A extensão poderá receber essa opção futuramente sem alterar suas cópias atuais.</span></div></div>'+
      '</section>';
    card.innerHTML =
      '<div class="extuiAjustesKeyLabel">Selecione abaixo o que deseja exportar:</div>'+ 
      '<div class="extuiBackupManualLayout">'+ 
        '<section class="extuiBackupManualCategories">'+ 
          '<div class="extuiBackupCategoryList">'+ 
            '<label class="extuiBackupToggleRow extuiBackupToggleRow--all"><span class="extuiBackupToggleCopy"><strong>Selecionar Todos</strong><small>Ativa ou desativa todas as categorias.</small></span><span class="extuiSwitch"><input type="checkbox" id="extuiBackupSelectAll" checked><span class="track"></span></span></label>'+categoryRows+
          '</div>'+backupAutoHtml+
        '</section>'+ 
        '<aside class="extuiBackupManualSidebar">'+ 
          '<div class="extuiBackupModePanel">'+ 
            '<div class="extuiAjustesGroupLabel extuiBackupModeTitle">Modo de Importação</div>'+ 
            '<div class="extuiThemeRadioRow" id="extuiBackupModeRow"><button type="button" class="extuiThemeRadioBtn extuiActive" data-import-mode="merge">Mesclar (Recomendado)</button><button type="button" class="extuiThemeRadioBtn" data-import-mode="replace">Sobrescrever</button></div>'+ 
            '<div class="extuiAjustesKeyLabel" id="extuiBackupModeHint">Mesclar mantém os dados atuais e adiciona/atualiza o conteúdo selecionado.</div>'+ 
          '</div>'+ 
          '<div class="extuiBackupModePanel extuiBackupFormatPanel">'+
            '<div class="extuiAjustesGroupLabel extuiBackupModeTitle">Formato da Cópia</div>'+ 
            '<div class="extuiThemeRadioRow" id="extuiBackupFormatRow"><button type="button" class="extuiThemeRadioBtn extuiActive" data-backup-format="zip">ZIP</button><button type="button" class="extuiThemeRadioBtn" data-backup-format="secure">Protegido</button><button type="button" class="extuiThemeRadioBtn" data-backup-format="json">JSON</button></div>'+ 
            '<div class="extuiAjustesKeyLabel" id="extuiBackupFormatHint">ZIP inclui os arquivos da Biblioteca e demais assets como arquivos reais, com melhor eficiência e portabilidade.</div>'+ 
            '<div class="extuiBackupSecurePanel" id="extuiBackupSecurePanel" hidden>'+ 
              '<div class="extuiBackupSecureHeader"><strong>Proteção AES-256-GCM</strong><span id="extuiBackupSecureStatus">Senha automática não configurada</span></div>'+ 
              '<label class="extuiAjustesFieldRow"><span class="extuiAjustesFieldLabel">Senha desta cópia</span><span class="extuiBackupPasswordField"><input class="extuiAjustesInput" type="password" id="extuiBackupSecurePassword" maxlength="256" autocomplete="new-password" placeholder="Mínimo de 12 caracteres"><button type="button" class="extuiBackupPasswordEye" data-backup-password-toggle="extuiBackupSecurePassword" aria-label="Mostrar senha" title="Mostrar senha"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle></svg></button></span></label>'+ 
              '<label class="extuiAjustesFieldRow"><span class="extuiAjustesFieldLabel">Confirmar senha</span><span class="extuiBackupPasswordField"><input class="extuiAjustesInput" type="password" id="extuiBackupSecurePasswordConfirm" maxlength="256" autocomplete="new-password" placeholder="Digite novamente"><button type="button" class="extuiBackupPasswordEye" data-backup-password-toggle="extuiBackupSecurePasswordConfirm" aria-label="Mostrar confirmação" title="Mostrar confirmação"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle></svg></button></span></label>'+ 
              '<div class="extuiBackupSecureActions"><button type="button" class="extui-btn extui-btn--ghost" id="extuiBackupSecureSavePassword">Salvar para cópias automáticas</button><button type="button" class="extui-btn extui-btn--ghost" id="extuiBackupSecureRemovePassword">Remover senha salva</button></div>'+ 
              '<small>Senhas, tokens e chaves de API não entram no arquivo. A senha de proteção só é salva se você escolher e fica cifrada no cofre local desta instalação.</small>'+ 
            '</div>'+ 
          '</div>'+ 
          '<div class="extuiAjustesActionsRow extuiBackupMainActions"><button type="button" class="extui-btn extui-btn--ghost" id="extuiAjustesExportBackupBtn">⬇ Exportar Cópia</button><button type="button" class="extui-btn extui-btn--ghost" id="extuiAjustesImportBackupBtn">⬆ Importar Cópia</button><input type="file" id="extuiAjustesImportBackupFile" accept=".extbackup,.zip,.json,application/x-extension-backup,application/zip,application/json" hidden></div>'+ 
        '</aside>'+ 
      '</div>';

    function currentCategories(){return categoryIds.filter(function(id){return selected[id]!==false;});}
    card.querySelectorAll("[data-backup-password-toggle]").forEach(function(btn){btn.addEventListener("click",function(){var input=card.querySelector("#"+btn.dataset.backupPasswordToggle);if(!input)return;var showing=input.type==="text";input.type=showing?"password":"text";btn.classList.toggle("is-visible",!showing);btn.setAttribute("aria-label",showing?"Mostrar senha":"Ocultar senha");btn.title=showing?"Mostrar senha":"Ocultar senha";input.focus();});});
    function syncSelectAll(){var all=currentCategories().length===categoryIds.length;var box=card.querySelector("#extuiBackupSelectAll");box.checked=all;box.indeterminate=false;}
    function bindCategories(){
      card.querySelector("#extuiBackupSelectAll").addEventListener("change",function(e){categoryIds.forEach(function(id){selected[id]=e.target.checked;var b=card.querySelector('[data-backup-category="'+id+'"]');if(b)b.checked=e.target.checked;});saveAutoSettings(false);});
      card.querySelectorAll("[data-backup-category]").forEach(function(box){box.addEventListener("change",function(){selected[box.dataset.backupCategory]=box.checked;syncSelectAll();saveAutoSettings(false);});});
    }
    var backupProtectionStatus={configured:false};
    function backupProtectionMessage(type,password){return new Promise(function(resolve,reject){try{var msg={type:type};if(typeof password==="string")msg.password=password;chrome.runtime.sendMessage(msg,function(response){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message||"Não foi possível acessar a proteção das cópias."));return;}if(!response||response.ok!==true){var e=new Error(response&&response.error||"Não foi possível acessar a proteção das cópias.");e.code=response&&response.code||"BACKUP_PROTECTION_FAILED";reject(e);return;}resolve(response.result||{});});}catch(err){reject(err);}});}
    function secureFields(){return{password:card.querySelector("#extuiBackupSecurePassword"),confirm:card.querySelector("#extuiBackupSecurePasswordConfirm")};}
    function currentSecurePassword(allowStored){var f=secureFields(),a=String(f.password.value||""),b=String(f.confirm.value||"");if(!a&&!b&&allowStored&&backupProtectionStatus.configured)return"";if(a!==b)throw new Error("As senhas da cópia protegida não coincidem.");if(a.length<12)throw new Error("Use uma senha com pelo menos 12 caracteres para proteger a cópia.");return a;}
    function clearSecureFields(){var f=secureFields();f.password.value="";f.confirm.value="";}
    function paintProtectionStatus(){var el=card.querySelector("#extuiBackupSecureStatus"),remove=card.querySelector("#extuiBackupSecureRemovePassword");if(el)el.textContent=backupProtectionStatus.configured?"Senha automática protegida no cofre local":"Senha automática não configurada";if(remove)remove.disabled=!backupProtectionStatus.configured;}
    async function refreshProtectionStatus(){try{backupProtectionStatus=await backupProtectionMessage("EXTUI_BACKUP_PROTECTION_STATUS")||{configured:false};}catch(_){backupProtectionStatus={configured:false};}paintProtectionStatus();return backupProtectionStatus;}
    async function saveProtectionPassword(){var password=currentSecurePassword(false);backupProtectionStatus=await backupProtectionMessage("EXTUI_BACKUP_PROTECTION_SET",password)||{configured:true};clearSecureFields();paintProtectionStatus();toast("Senha das cópias automáticas salva no cofre local.");}
    async function removeProtectionPassword(){backupProtectionStatus=await backupProtectionMessage("EXTUI_BACKUP_PROTECTION_REMOVE")||{configured:false};clearSecureFields();paintProtectionStatus();if(card.querySelector("#extuiBackupAutoEnabled").checked&&backupFormat==="secure"){card.querySelector("#extuiBackupAutoEnabled").checked=false;await saveAutoSettings(false);}toast("Senha automática removida.");}
    var importMode="merge", backupFormat="zip";
    card.querySelectorAll("#extuiBackupModeRow [data-import-mode]").forEach(function(btn){btn.addEventListener("click",function(){importMode=btn.dataset.importMode;card.querySelectorAll("#extuiBackupModeRow [data-import-mode]").forEach(function(b){b.classList.toggle("extuiActive",b===btn);});card.querySelector("#extuiBackupModeHint").textContent=importMode==="merge"?"Mesclar mantém os dados atuais e adiciona/atualiza o conteúdo selecionado.":"Sobrescrever substitui as categorias selecionadas pelo conteúdo do arquivo.";});});
    function paintFormat(){card.querySelectorAll("#extuiBackupFormatRow [data-backup-format]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.backupFormat===backupFormat);});var hint=card.querySelector("#extuiBackupFormatHint"),secure=card.querySelector("#extuiBackupSecurePanel");if(backupFormat==="secure")hint.textContent="Protegido cria um .extbackup autenticado com AES-256-GCM e senha. Internamente usa ZIP para manter os assets eficientes.";else if(backupFormat==="zip")hint.textContent="ZIP inclui os arquivos da Biblioteca e demais assets como arquivos reais, com melhor eficiência e portabilidade.";else hint.textContent="JSON mantém tudo em um único arquivo serializado. Pode ficar significativamente maior e é limitado a 128 MB de assets para evitar uso excessivo de memória.";if(secure)secure.hidden=backupFormat!=="secure";paintProtectionStatus();}
    card.querySelectorAll("#extuiBackupFormatRow [data-backup-format]").forEach(function(btn){btn.addEventListener("click",function(){backupFormat=extBackupNormalizeFormat(btn.dataset.backupFormat);paintFormat();saveAutoSettings(false);});});
    card.querySelector("#extuiBackupSecureSavePassword").addEventListener("click",function(){saveProtectionPassword().catch(function(e){toast(e&&e.message?e.message:"Não foi possível salvar a senha.",true);});});
    card.querySelector("#extuiBackupSecureRemovePassword").addEventListener("click",function(){removeProtectionPassword().catch(function(e){toast(e&&e.message?e.message:"Não foi possível remover a senha.",true);});});
    async function saveAutoSettings(showToast){try{var cats=currentCategories(),enabled=card.querySelector("#extuiBackupAutoEnabled").checked;if(enabled&&!cats.length){card.querySelector("#extuiBackupAutoEnabled").checked=false;enabled=false;if(showToast!==false)toast("Selecione pelo menos uma categoria antes de ativar a cópia automática.",true);}if(enabled&&backupFormat==="secure"&&!backupProtectionStatus.configured){card.querySelector("#extuiBackupAutoEnabled").checked=false;enabled=false;if(showToast!==false)toast("Para usar cópias automáticas protegidas, salve uma senha no cofre local primeiro.",true);}var prefix=extBackupFsPrefix(card.querySelector("#extuiBackupPrefix").value||"zvm_backup"),folder=extBackupFsFolderName(card.querySelector("#extuiBackupFolder").value||"ZVM-BACKUPs");await service.configure({enabled:enabled,includeTrash:card.querySelector("#extuiBackupIncludeTrash").checked,intervalMinutes:Number(card.querySelector("#extuiBackupAutoInterval").value),retention:Number(card.querySelector("#extuiBackupRetention").value),filePrefix:prefix,downloadFolder:folder,categories:cats,backupFormat:backupFormat});card.querySelector("#extuiBackupPrefix").value=prefix;card.querySelector("#extuiBackupFolder").value=folder;updateNamingPreview();syncAutoDisclosure();if(showToast!==false&&cats.length)toast("Cópia automática atualizada.");}catch(e){toast(e&&e.message?e.message:"Não foi possível salvar a cópia automática.",true);}}
    function updateNamingPreview(){var folder=extBackupFsFolderName(card.querySelector("#extuiBackupFolder").value||"ZVM-BACKUPs");card.querySelector("#extuiBackupFolderPreview").textContent=folder;}
    function updateFolderPreview(){updateNamingPreview();}
    function syncAutoDisclosure(){var grid=card.querySelector(".extuiBackupAutoGrid"),enabled=card.querySelector("#extuiBackupAutoEnabled").checked;if(grid)grid.classList.toggle("is-disabled",!enabled);}
    ["#extuiBackupAutoEnabled","#extuiBackupIncludeTrash","#extuiBackupAutoInterval","#extuiBackupRetention","#extuiBackupPrefix","#extuiBackupFolder"].forEach(function(sel){card.querySelector(sel).addEventListener("change",function(){syncAutoDisclosure();saveAutoSettings(true);});});
    card.querySelector("#extuiBackupPrefix").addEventListener("input",updateNamingPreview);
    card.querySelector("#extuiBackupFolder").addEventListener("input",updateNamingPreview);

    function createBackupFile(reason,categories,format,protectionPassword){return new Promise(function(resolve,reject){try{chrome.runtime.sendMessage({type:"EXTUI_BACKUP_CREATE_FILE",reason:reason,categories:Array.isArray(categories)?categories:[],format:extBackupNormalizeFormat(format||backupFormat),protectionPassword:typeof protectionPassword==="string"?protectionPassword:""},function(response){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message||"Não foi possível acionar o serviço de cópia."));return;}if(!response||response.ok!==true){var err=new Error(response&&response.error||"Não foi possível criar a cópia.");err.code=response&&response.code||"BACKUP_CREATE_FAILED";reject(err);return;}resolve(response.result||{});});}catch(err){reject(err);}});}
    card.querySelector("#extuiAjustesExportBackupBtn").addEventListener("click",async function(){if(!currentCategories().length){toast("Selecione pelo menos uma categoria.",true);return;}var progress=null;try{progress=extShowBackupProgress("Preparando a cópia completa…");await extNextFrame();await saveAutoSettings(false);var protectionPassword=backupFormat==="secure"?currentSecurePassword(true):"";var result=await createBackupFile("export",currentCategories(),backupFormat,protectionPassword);if(backupFormat==="secure")clearSecureFields();toast(result&&result.fileName?"Cópia exportada para "+result.fileName+".":"Cópia exportada com sucesso.");}catch(e){toast(e&&e.message?e.message:"Não foi possível exportar a cópia.",true);}finally{if(progress)extHideBackupProgress();}});

    function showImportSelection(backup){
      return new Promise(function(resolve){
        var declared=Array.isArray(backup&&backup.categories)?backup.categories:[];
        var available=importCategoryIds.filter(function(id){return declared.indexOf(id)>=0||service.categories[id].keys.some(function(k){return backup.data&&Object.prototype.hasOwnProperty.call(backup.data,k);});});
        var overlay=document.createElement("div");
        overlay.className="extuiDialogOverlay";
        var dialog=document.createElement("div");
        dialog.className="extuiDialog extuiBackupImportDialog";
        var titleId="extuiBackupImportDialogTitle-"+Date.now();
        dialog.setAttribute("role","dialog");
        dialog.setAttribute("aria-modal","true");
        dialog.setAttribute("aria-labelledby",titleId);
        dialog.setAttribute("tabindex","-1");
        var compatibility=Array.isArray(backup&&backup.compatibilityReport)&&backup.compatibilityReport.length?backup.compatibilityReport[0]:null;
        var isExternal=compatibility&&compatibility.source==="external";
        var importIntro=isExternal?"Formato externo compatível reconhecido. Escolha tudo ou apenas algumas categorias para importar.":"Cópia compatível reconhecida. Escolha tudo ou apenas algumas categorias para importar.";
        var title=document.createElement("h3");
        title.id=titleId;
        title.textContent="O que deseja importar?";
        var intro=document.createElement("p");
        intro.textContent=importIntro;
        dialog.appendChild(title);
        dialog.appendChild(intro);
        if(compatibility){
          var summary=document.createElement("div");summary.className="extuiBackupCompatibilitySummary";
          var stats=compatibility.stats&&typeof compatibility.stats==="object"?compatibility.stats:{};
          var statParts=[];[["messages","mensagens"],["audios","áudios"],["medias","imagens/vídeos"],["documents","documentos"],["flows","Fluxos"],["funnels","Funis"],["labels","etiquetas"],["assets","assets"]].forEach(function(pair){var n=Number(stats[pair[0]]||0);if(n>0)statParts.push(n+" "+pair[1]);});
          var repairs=Array.isArray(compatibility.repairs)?compatibility.repairs:[],warnings=Array.isArray(compatibility.warnings)?compatibility.warnings:[],unsupported=Array.isArray(compatibility.unsupported)?compatibility.unsupported:[];
          summary.textContent=(statParts.length?"Encontrado: "+statParts.join(" · ")+". ":"")+(repairs.length?repairs.length+" ajuste(s) seguro(s). ":"")+(warnings.length?warnings.length+" aviso(s). ":"")+(unsupported.length?unsupported.length+" recurso(s) sem equivalente direto.":"");
          dialog.appendChild(summary);
        }
        function toggleRow(labelText,attrs){
          var label=document.createElement("label");
          label.className="extuiBackupToggleRow"+(attrs&&attrs.all?" extuiBackupToggleRow--all":"");
          var copy=document.createElement("span");
          copy.className="extuiBackupToggleCopy";
          var strong=document.createElement("strong");
          strong.textContent=labelText;
          copy.appendChild(strong);
          var sw=document.createElement("span");
          sw.className="extuiSwitch";
          var input=document.createElement("input");
          input.type="checkbox";
          input.checked=true;
          if(attrs&&attrs.all)input.setAttribute("data-import-all","");
          if(attrs&&attrs.category)input.setAttribute("data-import-category",attrs.category);
          var track=document.createElement("span");
          track.className="track";
          sw.appendChild(input);
          sw.appendChild(track);
          label.appendChild(copy);
          label.appendChild(sw);
          return label;
        }
        dialog.appendChild(toggleRow("Selecionar Tudo",{all:true}));
        var choices=document.createElement("div");
        choices.className="extuiBackupImportChoices";
        available.forEach(function(id){choices.appendChild(toggleRow(service.categories[id].label,{category:id}));});
        dialog.appendChild(choices);
        var actions=document.createElement("div");
        actions.className="extuiDialogActions";
        var cancel=document.createElement("button");
        cancel.type="button";cancel.className="extui-btn extui-btn--ghost";cancel.textContent="Cancelar";cancel.setAttribute("data-cancel","");
        var ok=document.createElement("button");
        ok.type="button";ok.className="extui-btn extui-btn--primary";ok.textContent="Importar";ok.setAttribute("data-ok","");
        actions.appendChild(cancel);actions.appendChild(ok);dialog.appendChild(actions);overlay.appendChild(dialog);document.body.appendChild(overlay);
        var all=dialog.querySelector("[data-import-all]");
        function sync(){var boxes=Array.from(dialog.querySelectorAll("[data-import-category]")),on=boxes.filter(function(b){return b.checked;}).length;all.checked=on===boxes.length;all.indeterminate=on>0&&on<boxes.length;}
        all.addEventListener("change",function(){dialog.querySelectorAll("[data-import-category]").forEach(function(b){b.checked=all.checked;});sync();});
        dialog.querySelectorAll("[data-import-category]").forEach(function(b){b.addEventListener("change",sync);});
        var settled=false;
        var lifecycle=null;
        function close(v){if(settled)return;settled=true;if(lifecycle)lifecycle.close(v?"confirm":"cancel");else overlay.remove();resolve(v);}
        cancel.onclick=function(){close(null);};
        ok.onclick=function(){var ids=Array.from(dialog.querySelectorAll("[data-import-category]:checked")).map(function(b){return b.dataset.importCategory;});if(!ids.length){toast("Selecione pelo menos uma categoria.",true);return;}close(ids);};
        lifecycle=window.__extDialogLifecycle?window.__extDialogLifecycle(overlay,dialog,{initialFocus:all,onClose:function(reason){if(!settled&&(reason==="escape"||reason==="backdrop")){settled=true;resolve(null);}}}):null;
        if(!lifecycle)all.focus();
      });
    }

    function promptSecureImportPassword(header){return new Promise(function(resolve){var overlay=document.createElement("div");overlay.className="extuiDialogOverlay";var dialog=document.createElement("div");dialog.className="extuiDialog extuiBackupSecureImportDialog";dialog.setAttribute("role","dialog");dialog.setAttribute("aria-modal","true");dialog.setAttribute("tabindex","-1");var h=document.createElement("h3");h.textContent="Abrir cópia protegida";var p=document.createElement("p");var when=header&&header.createdAt?" · criada em "+new Date(header.createdAt).toLocaleString("pt-BR"):"";p.textContent="Informe a senha do arquivo .extbackup"+when+". A senha é usada somente localmente para abrir esta cópia.";var fieldWrap=document.createElement("span");fieldWrap.className="extuiBackupPasswordField";var field=document.createElement("input");field.type="password";field.autocomplete="current-password";field.className="extuiAjustesInput";field.placeholder="Senha da cópia";field.maxLength=256;var eye=document.createElement("button");eye.type="button";eye.className="extuiBackupPasswordEye";eye.setAttribute("aria-label","Mostrar senha");eye.title="Mostrar senha";eye.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle></svg>';eye.addEventListener("click",function(){var showing=field.type==="text";field.type=showing?"password":"text";eye.classList.toggle("is-visible",!showing);eye.setAttribute("aria-label",showing?"Mostrar senha":"Ocultar senha");eye.title=showing?"Mostrar senha":"Ocultar senha";field.focus();});fieldWrap.appendChild(field);fieldWrap.appendChild(eye);var actions=document.createElement("div");actions.className="extuiDialogActions";var cancel=document.createElement("button");cancel.type="button";cancel.className="extui-btn extui-btn--ghost";cancel.textContent="Cancelar";var ok=document.createElement("button");ok.type="button";ok.className="extui-btn extui-btn--primary";ok.textContent="Abrir";actions.appendChild(cancel);actions.appendChild(ok);dialog.appendChild(h);dialog.appendChild(p);dialog.appendChild(fieldWrap);dialog.appendChild(actions);overlay.appendChild(dialog);document.body.appendChild(overlay);var settled=false,lifecycle=null;function close(value,reason){if(settled)return;settled=true;var copy=value?String(value):"";field.value="";field.type="password";if(lifecycle)lifecycle.close(reason||"confirm");else overlay.remove();resolve(copy||null);}cancel.onclick=function(){close(null,"cancel");};ok.onclick=function(){if(!field.value){toast("Informe a senha da cópia protegida.",true);field.focus();return;}close(field.value,"confirm");};field.addEventListener("keydown",function(ev){if(ev.key==="Enter"){ev.preventDefault();ok.click();}});lifecycle=window.__extDialogLifecycle?window.__extDialogLifecycle(overlay,dialog,{initialFocus:field,onClose:function(reason){if(!settled&&(reason==="escape"||reason==="backdrop")){settled=true;field.value="";field.type="password";resolve(null);}}}):null;if(!lifecycle)field.focus();});}
    var fileInput=card.querySelector("#extuiAjustesImportBackupFile");card.querySelector("#extuiAjustesImportBackupBtn").addEventListener("click",function(){fileInput.click();});fileInput.addEventListener("change",async function(){
      var file=fileInput.files&&fileInput.files[0];fileInput.value="";if(!file)return;var progress=null,zipCtx=null,largeJsonTouchedMedia=false,importCommitted=false;
      try{
        var secureApi=window.__extBackupSecureEnvelope,secureByName=/\.extbackup$/i.test(file.name)||String(file.type||"").toLowerCase()==="application/x-extension-backup";if(secureByName&&!secureApi)throw new Error("O mecanismo para abrir cópias protegidas não foi carregado. Recarregue a extensão e tente novamente.");var secureFile=!!(secureApi&&await secureApi.isSecureFile(file));if(secureByName&&!secureFile)throw new Error("O arquivo .extbackup não possui um envelope válido ou foi corrompido.");var decryptedTemp=null,sourceFile=file,isZip=/\.zip$/i.test(file.name)||/zip/i.test(file.type||"");
        if(secureFile){var parsedSecure=await secureApi.parseHeader(file),securePassword=await promptSecureImportPassword(parsedSecure.header);if(!securePassword)return;extSetBackupProgress("Abrindo a cópia protegida…");await extNextFrame();decryptedTemp=await secureApi.decryptFileToOpfs(file,securePassword,{outputName:"extapp-import-decrypted-"+Date.now()+".tmp"});securePassword="";sourceFile=decryptedTemp.file;isZip=decryptedTemp.innerExtension==="zip";}
        extSetBackupProgress(isZip?"Validando a cópia ZIP…":"Lendo a cópia JSON…");await extNextFrame();
        var backup;if(isZip){zipCtx=await extBackupLoadZipModel(sourceFile);backup=service.normalizeIncomingBackupAsync?await service.normalizeIncomingBackupAsync(zipCtx.backup):service.normalizeIncomingBackup(zipCtx.backup);}else{var largeApi=window.__extLargeBackupJson,parsedInput;if(largeApi&&Number(sourceFile.size)>=Number(largeApi.streamThresholdBytes||0)){var streamed=await largeApi.parseFile(sourceFile,{onProgress:function(info){if(info&&info.done){extSetBackupProgress("Cópia JSON validada em fluxo.");return;}if(info&&info.offloaded)extSetBackupProgress("Lendo a cópia JSON em fluxo · "+info.offloaded+" arquivo(s) grande(s) preparados…");else extSetBackupProgress("Lendo a cópia JSON em fluxo…");}});largeJsonTouchedMedia=Number(streamed&&streamed.offloadedCount||0)>0;parsedInput=extBackupReadJsonValue(streamed.value);}else{if(largeApi&&Number(sourceFile.size)>Number(largeApi.maxFileBytes||0))throw new Error("A cópia JSON excede o limite seguro atual de 2,2 GB.");parsedInput=extBackupReadJsonText(await sourceFile.text());}backup=service.normalizeIncomingBackupAsync?await service.normalizeIncomingBackupAsync(parsedInput):service.normalizeIncomingBackup(parsedInput);}
        var chosen=await showImportSelection(backup);if(!chosen){if(largeJsonTouchedMedia&&window.ExtensionMediaStore&&window.ExtensionMediaStore.gc)await window.ExtensionMediaStore.gc();return;}
        var ok=await extConfirm((importMode==="replace"?"Sobrescrever":"Mesclar")+" as categorias selecionadas?",{danger:importMode==="replace",okLabel:importMode==="replace"?"Sobrescrever":"Importar"});if(!ok){if(largeJsonTouchedMedia&&window.ExtensionMediaStore&&window.ExtensionMediaStore.gc)await window.ExtensionMediaStore.gc();return;}
        if(isZip){extSetBackupProgress("Validando os arquivos selecionados…");await extNextFrame();var filtered=service.filterBackup(backup,chosen);await extBackupPreflightZipAssets(filtered,zipCtx);extSetBackupProgress("Restaurando arquivos da cópia…");await extNextFrame();backup=await extBackupResolveZipAssets(filtered,{file:zipCtx.file,manifest:zipCtx.manifest,refs:new Map(),extracted:zipCtx.extracted||new Map()},0);backup.assetEncoding="vault";backup.binaryAssets=[];}
        extSetBackupProgress("Restaurando conteúdos e configurações…");await extNextFrame();
        var result=await service.importData(backup,{mode:importMode,categories:chosen});importCommitted=true;
        var warning=result&&result.warnings&&result.warnings.length?" "+result.warnings.map(function(w){return w.message;}).join(" "):"";
        toast("Cópia importada."+warning+(warning?"":" Recarregando…"),!!warning);
        setTimeout(function(){location.reload();},warning?2200:900);
      }catch(e){try{if(window.ExtensionMediaStore&&window.ExtensionMediaStore.gc)await window.ExtensionMediaStore.gc();}catch(_){}toast(e&&e.message?e.message:"O arquivo da cópia é inválido ou incompatível.",true);}finally{try{if(!importCommitted&&largeJsonTouchedMedia&&window.ExtensionMediaStore&&window.ExtensionMediaStore.gc)await window.ExtensionMediaStore.gc();}catch(_){}try{if(typeof decryptedTemp!=="undefined"&&decryptedTemp&&window.__extBackupSecureEnvelope)await window.__extBackupSecureEnvelope.removeOpfs(decryptedTemp.opfsName);}catch(_){}if(progress)extHideBackupProgress();}
    });

    card.querySelector("#extuiBackupCreateNow").addEventListener("click",async function(){if(!currentCategories().length){toast("Selecione pelo menos uma categoria.",true);return;}var progress=null;try{progress=extShowBackupProgress("Criando e salvando a cópia em Downloads / "+extBackupFsFolderName(card.querySelector("#extuiBackupFolder").value||"ZVM-BACKUPs")+"…");await extNextFrame();await saveAutoSettings(false);var protectionPassword=backupFormat==="secure"?currentSecurePassword(true):"";var result=await createBackupFile("manual",currentCategories(),backupFormat,protectionPassword);if(backupFormat==="secure")clearSecureFields();toast(result&&result.fileName?"Cópia criada em "+result.fileName+".":"Cópia criada com sucesso.");}catch(e){toast(e&&e.message?e.message:"Não foi possível criar a cópia.",true);}finally{if(progress)extHideBackupProgress();}});

    bindCategories();
    wrap.appendChild(card);
    service.settings().then(async function(cfg){await refreshProtectionStatus();categoryIds.forEach(function(id){selected[id]=cfg.categories.indexOf(id)>=0;var b=card.querySelector('[data-backup-category="'+id+'"]');if(b)b.checked=selected[id];});backupFormat=extBackupNormalizeFormat(cfg.backupFormat);paintFormat();syncSelectAll();card.querySelector("#extuiBackupAutoEnabled").checked=cfg.enabled;card.querySelector("#extuiBackupIncludeTrash").checked=cfg.includeTrash!==false;card.querySelector("#extuiBackupAutoInterval").value=String(cfg.intervalMinutes);card.querySelector("#extuiBackupRetention").value=String(cfg.retention);card.querySelector("#extuiBackupPrefix").value=extBackupFsPrefix(cfg.filePrefix||"zvm_backup");card.querySelector("#extuiBackupFolder").value=extBackupFsFolderName(cfg.downloadFolder||"ZVM-BACKUPs");updateNamingPreview();syncAutoDisclosure();}).catch(function(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("BACKUP_SETTINGS_UI_LOAD_FAILED",err);paintFormat();updateNamingPreview();syncAutoDisclosure();});
    try{if(new URLSearchParams(location.search).get("focus")==="cópia de segurança")setTimeout(function(){card.scrollIntoView({behavior:"smooth",block:"start"});},50);}catch(_){}
  }


  var ITEM_STORE_DEFS = [
    { key: "EXTUI:textMessageStore", field: "textMessageList" },
    { key: "EXTUI:audioStore", field: "audioList" },
    { key: "EXTUI:mediaStore", field: "mediaList" },
    { key: "EXTUI:stickerStore", field: "stickerList" },
    { key: "EXTUI:documentStore", field: "documentList" },
    { key: "EXTUI:pixStore", field: "pixList" },
    { key: "EXTUI:interactiveListStore", field: "interactiveListList" },
    { key: "EXTUI:contactCardStore", field: "contactList" }
  ];
  var ITEM_STORE_KEYS = ITEM_STORE_DEFS.map(function(def){ return def.key; }).concat([
    "EXTUI:extappQuickResponseStore", "EXTUI:quickAssetsStore", "EXTUI:quickItemsRecents", "EXTUI:greetingMessagesStore",
    "EXTUI:extappFlowStore", "EXTUI:flowFilesStore", "EXTUI:extappFlowRunningStore",
    "EXTUI:extappFunnelStore", "EXTUI:extappFunnelRunningStore", "EXTUI:extappTemplateInstallations"
  ]);
  function extAjustesState(raw){
    try { if (typeof raw === "string") raw = JSON.parse(raw); } catch (_) { raw = {}; }
    if (raw && raw.state && typeof raw.state === "object") raw = raw.state;
    return raw && typeof raw === "object" ? raw : {};
  }
  function extAjustesCollectDynamicItemKeys(snapshot){
    var ids = [];
    ITEM_STORE_DEFS.forEach(function(def){
      var state = extAjustesState(snapshot && snapshot[def.key]);
      var list = Array.isArray(state[def.field]) ? state[def.field] : [];
      list.forEach(function(item){ var id = item && String(item.id || ""); if (id && ids.indexOf(id) < 0) ids.push(id); });
    });
    return ids;
  }
  function extAjustesChromeGet(keys){return new Promise(function(resolve,reject){chrome.storage.local.get(keys,function(value){if(chrome.runtime&&chrome.runtime.lastError)reject(chrome.runtime.lastError);else resolve(value||{});});});}
  function extAjustesChromeRemove(keys){if(window.ExtensionStorage&&typeof window.ExtensionStorage.removeMany==="function")return window.ExtensionStorage.removeMany(Array.isArray(keys)?keys:[keys]);return new Promise(function(resolve,reject){chrome.storage.local.remove(keys,function(){if(chrome.runtime&&chrome.runtime.lastError)reject(chrome.runtime.lastError);else resolve();});});}
  async function extAjustesClearSavedItems(){
    var snapshot = await extAjustesChromeGet(ITEM_STORE_KEYS.concat(["EXTUI:adaptiveWorkspaceStore","EXTUI:dashboardMenuVisibilityStore"]));
    var dynamicKeys = extAjustesCollectDynamicItemKeys(snapshot);
    await extAjustesChromeRemove(ITEM_STORE_KEYS.concat(dynamicKeys));
    var workspace = extAjustesState(snapshot["EXTUI:adaptiveWorkspaceStore"]);
    if (workspace && Object.keys(workspace).length) {
      workspace.activeModels = [];
      workspace.focusedMode = false;
      workspace.materializedModels = [];
      workspace.updatedAt = Date.now();
      if(window.ExtensionStorage&&typeof window.ExtensionStorage.set==="function")await window.ExtensionStorage.set("EXTUI:adaptiveWorkspaceStore",workspace);else await new Promise(function(resolve,reject){var payload={"EXTUI:adaptiveWorkspaceStore":workspace};chrome.storage.local.set(payload,function(){if(chrome.runtime&&chrome.runtime.lastError)reject(chrome.runtime.lastError);else resolve();});});
    }
    try { await new Promise(function(resolve){ chrome.runtime.sendMessage({type:"EXTUI_MEDIA_VAULT_GC"},function(){ void chrome.runtime.lastError; resolve(); }); }); } catch (_) {}
    var verify = await extAjustesChromeGet(ITEM_STORE_KEYS.concat(dynamicKeys));
    var remaining = ITEM_STORE_KEYS.concat(dynamicKeys).filter(function(key){ return Object.prototype.hasOwnProperty.call(verify,key); });
    if (remaining.length) throw new Error("Alguns itens ainda permaneceram no armazenamento: "+remaining.slice(0,5).join(", "));
    return { removedStores: ITEM_STORE_KEYS.length, removedPayloads: dynamicKeys.length };
  }
  async function extAjustesClearOriginCaches(){
    if (typeof caches !== "undefined" && caches.keys) {
      var names=await caches.keys(),deleted=await Promise.all(names.map(function(name){return caches.delete(name);}));
      if(deleted.some(function(ok){return ok!==true;}))throw new Error("Não foi possível apagar todo o cache interno da extensão.");
      var remainingCaches=await caches.keys();if(remainingCaches.length)throw new Error("O cache interno ainda contém dados depois da formatação.");
    }
    if (navigator.storage && typeof navigator.storage.getDirectory === "function") {
      var opfs=await navigator.storage.getDirectory();
      for await (var pair of opfs.entries()) await opfs.removeEntry(pair[0], {recursive:true});
      for await (var leftover of opfs.entries()) throw new Error("O armazenamento temporário ainda contém dados depois da formatação: "+String(leftover[0]||"arquivo"));
    }
  }
  async function extAjustesFactoryReset(){
    await new Promise(function(resolve,reject){
      chrome.runtime.sendMessage({type:"EXTUI_FACTORY_RESET_OWNED_DATA"},function(response){
        if(chrome.runtime&&chrome.runtime.lastError){var e=new Error(chrome.runtime.lastError.message||"Falha ao iniciar a formatação segura.");void chrome.runtime.lastError;reject(e);return;}
        if(!response||response.ok!==true){reject(new Error(response&&response.error||"A formatação segura não foi concluída."));return;}
        resolve(response);
      });
    });
    if (typeof localStorage !== "undefined") { localStorage.clear(); if(localStorage.length)throw new Error("O armazenamento local da interface não foi apagado por completo."); }
    if (typeof sessionStorage !== "undefined") { sessionStorage.clear(); if(sessionStorage.length)throw new Error("O armazenamento temporário da interface não foi apagado por completo."); }
    await extAjustesClearOriginCaches();
    var verify=await extAjustesChromeGet(null);
    if (Object.keys(verify).length) throw new Error("O armazenamento da extensão ainda contém dados depois da formatação.");
  }

                                                                          
                                                                              
                                                                          
                                                                            
                                                                      
                                                                              
                                                                            
  function escHtmlAjustes(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
                                                                        
                                                                  
                                                                         
                                                                           
                                                                          
                                                                          
                                                                      
                                                                        
                                                                          
  function extExpiresAtMs(raw) {
    if (raw == null) return null;
    if (typeof raw === "number") return isFinite(raw) ? raw : null;
    var parsed = new Date(raw).getTime();
    return isNaN(parsed) ? null : parsed;
  }
  function extFormatLicenseDate(ms) {
    var d = new Date(ms);
    var dateStr = d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
    var timeStr = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    return { dateStr: dateStr, timeStr: timeStr };
  }
  function extFormatLicenseCountdown(ms) {
    var diff = ms - Date.now();
    if (diff <= 0) return null;
    var days = Math.floor(diff / 86400000);
    var hours = Math.floor((diff % 86400000) / 3600000);
    var parts = [];
    if (days > 0) parts.push(days + (days === 1 ? " dia" : " dias"));
    parts.push(hours + (hours === 1 ? " hora" : " horas"));
    return parts.join(" e ") + " restantes";
  }
                                                                     
                                                                     
  function renderLicenseCard(wrap) {
    var card = document.createElement("div");
    card.className = "extuiCard";
    card.innerHTML = '<h2>Licença</h2><div id="extuiLicenseBody" class="extuiLicenseBody"></div>';
    wrap.appendChild(card);
    var body = card.querySelector("#extuiLicenseBody");

    storageGet("EXTUI:license").then(function (license) {
      if (!license || !license.authenticated) { body.innerHTML = '<div class="extuiAjustesKeyLabel">Nenhuma licença ativa nesta sessão.</div>'; return; }

      var planLabel = license.planName ? license.planName : "";
                                                                       
                                                                          
                                                                         
      var expiresAtMs = extExpiresAtMs(license.expiresAt);
      var hasExpiry = expiresAtMs !== null;
      var expired = hasExpiry && expiresAtMs <= Date.now();
      var countdown = hasExpiry ? extFormatLicenseCountdown(expiresAtMs) : null;
      var daysLeft = hasExpiry ? Math.floor((expiresAtMs - Date.now()) / 86400000) : null;
                                                                            
                                                                        
                                                                      
      var isCritical = hasExpiry && !expired && daysLeft <= 0;
      var isWarning = hasExpiry && !expired && !isCritical && (license.expiringSoon || daysLeft <= 3);

      var dotClass = "extuiLicenseDot--ok", statusText = "Ativa";
      if (expired) { dotClass = "extuiLicenseDot--error"; statusText = "Expirada"; }
      else if (isCritical) { dotClass = "extuiLicenseDot--error"; statusText = "Expira em breve"; }
      else if (isWarning) { dotClass = "extuiLicenseDot--warning"; statusText = "Expira em breve"; }
      else if (!hasExpiry) { statusText = "Sem expiração"; }

      var html = '<div class="extuiLicenseStatusRow"><span class="extuiLicenseDot ' + dotClass + '"></span>' +
        '<span class="extuiLicenseStatusText">Licença' + (planLabel ? " " + escHtmlAjustes(planLabel) : "") + " · " + statusText + '</span></div>';

      if (hasExpiry) {
        var fmt = extFormatLicenseDate(expiresAtMs);
        html += '<div class="extuiLicenseDetail">' + (expired ? "Expirou em " : "Válida até ") + "<strong>" + fmt.dateStr + "</strong> às <strong>" + fmt.timeStr + "</strong></div>";
        if (!expired && countdown) html += '<div class="extuiLicenseCountdown extuiLicenseCountdown--' + (isCritical ? "critical" : isWarning ? "warning" : "ok") + '">' + countdown + "</div>";
      } else {
        html += '<div class="extuiLicenseDetail">Esta licença não possui data de expiração.</div>';
      }

      body.innerHTML = html;
    }).catch(function (err) {
      body.innerHTML = '<div class="extuiAjustesKeyLabel">Não foi possível carregar os dados da licença.</div>';
    });
  }

  function renderContaCard(wrap) {
    var card = document.createElement("div");
    card.className = "extuiCard";
                                                                        
                                                                      
                                                                           
                                                                            
                                                                     
                       
    card.innerHTML =
      '<h2>Conta</h2>' +
      '<div class="extuiAjustesKeyLabel">Sair da conta atual e voltar pra tela de login pra inserir outra chave de acesso.</div>' +
      '<button type="button" class="extui-btn extui-btn--ghost" id="extuiAjustesLogoutBtn">Deslogar e inserir outra chave</button>' +
      '<div class="extuiAjustesKeyLabel" style="margin-top:22px;">Apaga os itens salvos (mensagens, áudios, imagens, vídeos, documentos, PIX, contatos, respostas rápidas, Fluxos e Funis). CRM, agenda e login não são afetados. A seleção de Modelos é desmarcada para impedir que os modelos recriem os itens logo após a limpeza.</div>' +
      '<button type="button" class="extuiAjustesLogoutBtn" id="extuiAjustesClearItemsBtn">Limpar itens salvos</button>' +
      '<div class="extuiAjustesKeyLabel" style="margin-top:22px;">Apaga TUDO (itens, fluxos, funis, CRM, agenda, opções e a chave de login) e volta a extensão para o estado de fábrica. Recomendamos exportar uma cópia de segurança antes.</div>' +
      '<button type="button" class="extuiAjustesLogoutBtn extuiAjustesLogoutBtn--severe" id="extuiAjustesResetAllBtn">Formatar extensão por completo</button>';
    card.querySelector("#extuiAjustesLogoutBtn").addEventListener("click", async function () {
      if (!await extConfirm("Tem certeza que quer sair? Você vai precisar inserir sua chave de novo.")) return;
      try {
        var licenseService = window.__extS0;
        if (!licenseService || typeof licenseService._i !== "function") throw new Error("Serviço seguro de sessão indisponível.");
        await licenseService._i();
                                                                          
                                                                        
      } catch (err) {
        await extAlert("Não foi possível deslogar agora. Tente novamente.");
      }
    });
    card.querySelector("#extuiAjustesResetAllBtn").addEventListener("click", async function () {
      if (!await extConfirm("ISSO APAGA TUDO (itens, fluxos, funis, CRM, agenda, opções e login) sem volta. Você criou uma cópia de segurança antes? Continuar mesmo assim?", { danger: true })) return;
      if (!await extConfirm("Confirmando de novo: formatar a extensão por completo agora?", { danger: true })) return;
      try {
        await extAjustesFactoryReset();
        toast("Extensão formatada. Reiniciando...");
        setTimeout(function () { try { chrome.runtime.reload(); } catch (_) { window.location.reload(); } }, 350);
      } catch (err) {
        await extAlert("Não foi possível formatar agora. Tente novamente.");
      }
    });
    card.querySelector("#extuiAjustesClearItemsBtn").addEventListener("click", async function () {
      if (!await extConfirm("Isso apaga TODOS os itens salvos, incluindo Respostas Rápidas, arquivos, Fluxos e Funis. CRM, agenda e login continuam intactos. A seleção de Modelos será desmarcada para os modelos não recriarem o conteúdo automaticamente. Continuar?", { danger: true })) return;
      try {
        var cleared = await extAjustesClearSavedItems();
        toast("Itens apagados: "+cleared.removedStores+" áreas e "+cleared.removedPayloads+" conteúdos. Recarregando...");
        setTimeout(function () { window.location.reload(); }, 650);
      } catch (err) {
        await extAlert("Não foi possível apagar os itens agora. Tente novamente.");
      }
    });
    wrap.appendChild(card);
  }

  window.__extRenderSendSafetyCard = async function (wrap) {
    if (!wrap) throw new Error("Área da Proteção de Envio indisponível.");
    var opts = await loadOptions();
    renderSendSafetyCard(wrap, opts);
    return true;
  };

  async function renderAjustesSection(container) {
    container.innerHTML = "";
    var page = document.createElement("div"); page.className = "extuiSectionWrap extuiAjustesPageV3 extuiAdminSurfaceV3"; container.appendChild(page);
    var head = document.createElement("div"); head.className = "extuiPageHeading";
    var availability = window.ExtensionCore && window.ExtensionCore.FeatureAvailability;
    var guideVisible = false;
    try { guideVisible = !!(availability && typeof availability.isSurfaceVisible === "function" && availability.isSurfaceVisible("tutorials", "shellGuideActions", { requireRegistered: true }) === true); } catch (_) { guideVisible = false; }
    head.innerHTML = '<div><h1>Ajustes</h1><p>Encontre e altere preferências operacionais sem percorrer uma página longa.</p></div>' + (guideVisible ? '<button type="button" class="extui-btn extui-btn--ghost" data-ajustes-guide>Ver guias</button>' : '');
    page.appendChild(head);
    var guide = head.querySelector('[data-ajustes-guide]');
    if (guide) guide.addEventListener('click', function(){ window.__extDashboardShell.showSection('academy'); });
    var toolbar = document.createElement("div"); toolbar.className = "extuiAjustesToolbarV3";
    toolbar.innerHTML = '<label class="extuiAjustesSearchV3"><input type="search" placeholder="Buscar configuração..." aria-label="Buscar configuração"></label><div class="extuiAjustesTabsV3" role="tablist" aria-label="Categorias de ajustes"></div>';
    page.appendChild(toolbar);
    var devUi = window.ExtensionCore && window.ExtensionCore.DevFeatureOverridesUI;
    var devAvailable = !!(devUi && typeof devUi.ready === "function" && await devUi.ready());
    var tabs = [
      ["geral","Geral"],["conta","Conta"]
    ];
    if (devAvailable) tabs.push(["development","Desenvolvimento"]);
    container.setAttribute("data-extui-ajustes-tab", "Geral");
    var tabsHost = toolbar.querySelector('.extuiAjustesTabsV3');
    var panels = document.createElement('div'); panels.className = 'extuiAjustesPanelsV3'; page.appendChild(panels);
    var panelMap = {};
    tabs.forEach(function(def, index){
      var b=document.createElement('button');b.type='button';b.className='extuiAjustesTabV3'+(index===0?' is-active':'');b.textContent=def[1];b.setAttribute('role','tab');b.setAttribute('aria-selected',index===0?'true':'false');b.dataset.tab=def[0];tabsHost.appendChild(b);
      var panel=document.createElement('section');panel.className='extuiAjustesPanelV3';panel.dataset.panel=def[0];panel.hidden=index!==0;panels.appendChild(panel);panelMap[def[0]]=panel;
      b.addEventListener('click',async function(){
        tabsHost.querySelectorAll('[role="tab"]').forEach(function(x){var active=x===b;x.classList.toggle('is-active',active);x.setAttribute('aria-selected',String(active));});
        panels.querySelectorAll('.extuiAjustesPanelV3').forEach(function(x){x.hidden=x!==panel;});
        container.setAttribute("data-extui-ajustes-tab", def[1]);
      });
    });
    var opts = await loadOptions();
    var generalLeft = document.createElement("div"); generalLeft.className = "extuiAjustesGeneralColV3 extuiAjustesGeneralColV3--left";
    var generalRight = document.createElement("div"); generalRight.className = "extuiAjustesGeneralColV3 extuiAjustesGeneralColV3--right";
    panelMap.geral.appendChild(generalLeft); panelMap.geral.appendChild(generalRight);
    renderWhatsappCard(generalLeft, opts); renderConfirmCard(generalLeft, opts); renderSistemaCard(generalRight, opts);
    var menuCard=document.createElement("div");menuCard.className="extuiCard extuiShellMenuSettingsCard";menuCard.innerHTML='<div class="extuiShellMenuSettingsHost"><div class="extuiShellMenuSettingsLoading">Carregando opções do menu...</div></div>';generalRight.appendChild(menuCard);(function mountMenuSettings(attempt){var host=menuCard.querySelector('.extuiShellMenuSettingsHost');if(!host||!host.isConnected)return;if(typeof window.__extRenderShellMenuSettings==='function'){Promise.resolve(window.__extRenderShellMenuSettings(host)).then(decorateCards).catch(function(){host.innerHTML='<div class="extuiShellMenuSettingsLoading">Não foi possível carregar estas opções agora.</div>';});return;}if((attempt||0)<30)setTimeout(function(){mountMenuSettings((attempt||0)+1);},80);})(0);
    renderLicenseCard(panelMap.conta); renderContaCard(panelMap.conta);
    if (devAvailable && panelMap.development && devUi && typeof devUi.mount === "function") await devUi.mount(panelMap.development);
    var searchResults=document.createElement('section');searchResults.className='extuiAjustesSearchResultsV3';searchResults.hidden=true;page.appendChild(searchResults);
    var tabLabels={geral:'Geral',conta:'Conta',development:'Desenvolvimento'};
    function decorateCards(){ panels.querySelectorAll('.extuiAjustesPanelV3').forEach(function(panel){panel.querySelectorAll('.extuiCard').forEach(function(card){card.dataset.searchText=(card.textContent||'').toLowerCase().replace(/\s+/g,' ');card.dataset.settingsPanel=panel.dataset.panel||'geral';});}); }
    function activateSettingsTab(id){var button=tabsHost.querySelector('[data-tab="'+id+'"]');if(button)button.click();}
    decorateCards();
    tabsHost.addEventListener('keydown',function(event){var buttons=Array.prototype.slice.call(tabsHost.querySelectorAll('[role="tab"]'));var current=buttons.indexOf(document.activeElement);if(current<0||['ArrowLeft','ArrowRight','Home','End'].indexOf(event.key)<0)return;event.preventDefault();var next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(current+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;buttons[next].focus();buttons[next].click();});
    var search=toolbar.querySelector('input');
    search.addEventListener('input',function(){
      var q=search.value.trim().toLowerCase();
      if(!q){searchResults.hidden=true;panels.hidden=false;tabsHost.hidden=false;return;}
      panels.hidden=true;tabsHost.hidden=true;searchResults.hidden=false;searchResults.innerHTML='';
      var matches=Array.prototype.filter.call(panels.querySelectorAll('.extuiCard'),function(card){return (card.dataset.searchText||'').indexOf(q)>=0;});
      if(!matches.length){searchResults.innerHTML='<div class="extEmptyState extuiAjustesSearchEmptyV3"><strong>Nenhuma configuração encontrada</strong><span>Tente outro termo ou escolha uma categoria.</span></div>';return;}
      matches.forEach(function(card){
        var panelId=card.dataset.settingsPanel||'geral';
        var h=card.querySelector('h2,h3,.extuiAjustesCardTitle,.title,strong');
        var title=(h&&h.textContent||'Configuração').trim();
        var text=(card.textContent||'').replace(/\s+/g,' ').trim();
        var summary=text.replace(title,'').trim().slice(0,190);
        var result=document.createElement('article');result.className='extuiAjustesSearchResultV3';
        var copy=document.createElement('div');copy.innerHTML='<span>'+tabLabels[panelId]+'</span><strong></strong><p></p>';copy.querySelector('strong').textContent=title;copy.querySelector('p').textContent=summary;
        var open=document.createElement('button');open.type='button';open.className='extui-btn extui-btn--secondary';open.textContent='Abrir em '+tabLabels[panelId];
        open.addEventListener('click',function(){search.value='';searchResults.hidden=true;panels.hidden=false;tabsHost.hidden=false;activateSettingsTab(panelId);requestAnimationFrame(function(){card.scrollIntoView({behavior:'smooth',block:'start'});var focusable=card.querySelector('input,select,button,textarea');if(focusable)focusable.focus({preventScroll:true});});});
        result.appendChild(copy);result.appendChild(open);searchResults.appendChild(result);
      });
    });
  }

  async function renderBackupSection(container) {
    container.innerHTML="";
    var wrap=document.createElement("div");wrap.className="extuiSectionWrap extuiBackupPage extuiAdminSurfaceV3";container.appendChild(wrap);
    var head=document.createElement("div");head.className="extuiPageHeading";head.innerHTML='<div><h1>Cópia de Segurança</h1><p>Exporte, importe e automatize cópias dos dados da extensão em um espaço dedicado.</p></div>';wrap.appendChild(head);
    var body=document.createElement("div");body.className="extuiBackupPageBody";wrap.appendChild(body);renderBackupCard(body);
  }

  window.__extDashboardShell.registerSection("ajustes", renderAjustesSection);
  window.__extDashboardShell.registerSection("backup", renderBackupSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
