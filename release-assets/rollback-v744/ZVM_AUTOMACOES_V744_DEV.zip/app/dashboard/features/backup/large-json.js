;(function(root){
  "use strict";
  if(root.__extLargeBackupJson)return;

  var MAX_FILE_BYTES=2200*1024*1024;
  var STREAM_THRESHOLD_BYTES=64*1024*1024;
  var MAX_STRING_CHARS=380*1024*1024;
  var MAX_DEPTH=120;
  var MAX_NODES=2000000;
  var UNSAFE=new Set(["__proto__","prototype","constructor"]);

  function coded(code,message,cause){var e=new Error(message||code);e.code=code;if(cause)try{e.cause=cause;}catch(_){}return e;}
  function isWs(ch){return ch===" "||ch==="\n"||ch==="\r"||ch==="\t";}
  function isDataUrl(value){return typeof value==="string"&&/^data:[^;,]+(?:;[^,]*)?;base64,/i.test(value);}
  function safeMeta(value){return{mimeType:String(value&&value.mimeType||""),fileName:String(value&&value.fileName||value&&value.name||"arquivo"),sizeBytes:Number(value&&value.sizeBytes||0)};}

  function StreamReader(file){
    if(!file||typeof file.stream!=="function")throw coded("BACKUP_JSON_FILE_INVALID","O arquivo JSON é inválido.");
    this.file=file;this.reader=null;this.buffer="";this.index=0;this.done=false;this.decoder=null;this.byteReader=null;this.byteOffset=0;this.charCount=0;
    if(typeof TextDecoderStream==="function"){
      this.reader=file.stream().pipeThrough(new TextDecoderStream("utf-8",{fatal:true,ignoreBOM:true})).getReader();
    }else{
      this.decoder=new TextDecoder("utf-8",{fatal:true,ignoreBOM:true});
      this.byteReader=file.stream().getReader();
    }
  }
  StreamReader.prototype.fill=async function(){
    while(this.index>=this.buffer.length&&!this.done){
      var r;
      try{r=await (this.reader?this.reader.read():this.byteReader.read());}catch(e){throw coded("BACKUP_JSON_UTF8_INVALID","O arquivo JSON contém texto UTF-8 inválido.",e);}
      if(r.done){this.done=true;if(this.decoder){try{this.buffer=this.decoder.decode();this.index=0;}catch(e){throw coded("BACKUP_JSON_UTF8_INVALID","O arquivo JSON contém texto UTF-8 inválido.",e);}}else{this.buffer="";this.index=0;}break;}
      if(this.reader){this.buffer=String(r.value||"");this.index=0;}
      else{try{this.buffer=this.decoder.decode(r.value,{stream:true});this.index=0;}catch(e){throw coded("BACKUP_JSON_UTF8_INVALID","O arquivo JSON contém texto UTF-8 inválido.",e);}}
      if(this.buffer.length===0)continue;
    }
    return this.index<this.buffer.length;
  };
  StreamReader.prototype.peek=async function(){return await this.fill()?this.buffer[this.index]:"";};
  StreamReader.prototype.take=async function(){if(!await this.fill())return"";var ch=this.buffer[this.index++];this.charCount++;return ch;};
  StreamReader.prototype.skipWs=async function(){var ch;while((ch=await this.peek())&&isWs(ch)){this.index++;this.charCount++;}return ch;};
  StreamReader.prototype.expect=async function(expected){var ch=await this.take();if(ch!==expected)throw coded("BACKUP_JSON_SYNTAX","JSON inválido: era esperado '"+expected+"'.");};
  StreamReader.prototype.readString=async function(){
    await this.expect('"');var parts=[],total=0;
    while(true){
      if(!await this.fill())throw coded("BACKUP_JSON_SYNTAX","JSON inválido: texto não finalizado.");
      var start=this.index,q=this.buffer.indexOf('"',start),b=this.buffer.indexOf('\\',start),next;
      if(q<0)next=b;else if(b<0)next=q;else next=Math.min(q,b);
      if(next<0){var tail=this.buffer.slice(start);if(/[\u0000-\u001f]/.test(tail))throw coded("BACKUP_JSON_SYNTAX","JSON inválido: caractere de controle em texto.");parts.push(tail);total+=tail.length;this.charCount+=tail.length;this.index=this.buffer.length;if(total>MAX_STRING_CHARS)throw coded("BACKUP_JSON_STRING_TOO_LARGE","Um campo de texto do backup excede o limite seguro individual.");continue;}
      var segment=this.buffer.slice(start,next);if(/[\u0000-\u001f]/.test(segment))throw coded("BACKUP_JSON_SYNTAX","JSON inválido: caractere de controle em texto.");if(segment){parts.push(segment);total+=segment.length;this.charCount+=segment.length;}
      this.index=next;
      if(this.buffer[next]==='"'){this.index++;this.charCount++;if(total>MAX_STRING_CHARS)throw coded("BACKUP_JSON_STRING_TOO_LARGE","Um campo de texto do backup excede o limite seguro individual.");return parts.join("");}
      this.index++;this.charCount++;var esc=await this.take();if(!esc)throw coded("BACKUP_JSON_SYNTAX","JSON inválido: escape incompleto.");
      if(esc==='"'||esc==='\\'||esc==='/')parts.push(esc);
      else if(esc==='b')parts.push("\b");else if(esc==='f')parts.push("\f");else if(esc==='n')parts.push("\n");else if(esc==='r')parts.push("\r");else if(esc==='t')parts.push("\t");
      else if(esc==='u'){var hex="";for(var i=0;i<4;i++){var h=await this.take();if(!/[0-9a-f]/i.test(h||""))throw coded("BACKUP_JSON_SYNTAX","JSON inválido: escape Unicode incorreto.");hex+=h;}parts.push(String.fromCharCode(parseInt(hex,16)));}
      else throw coded("BACKUP_JSON_SYNTAX","JSON inválido: sequência de escape desconhecida.");
      total++;if(total>MAX_STRING_CHARS)throw coded("BACKUP_JSON_STRING_TOO_LARGE","Um campo de texto do backup excede o limite seguro individual.");
    }
  };
  StreamReader.prototype.readPrimitive=async function(){
    var out="",ch;while((ch=await this.peek())&&!isWs(ch)&&ch!==','&&ch!==']'&&ch!=='}'){out+=ch;this.index++;this.charCount++;if(out.length>128)throw coded("BACKUP_JSON_SYNTAX","JSON inválido: valor primitivo excessivo.");}
    if(out==="true")return true;if(out==="false")return false;if(out==="null")return null;
    if(!/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(out))throw coded("BACKUP_JSON_SYNTAX","JSON inválido: número ou literal incorreto.");var n=Number(out);if(!Number.isFinite(n))throw coded("BACKUP_JSON_NUMBER_INVALID","O backup contém um número fora do intervalo suportado.");return n;
  };
  StreamReader.prototype.close=async function(){try{if(this.reader)await this.reader.cancel();else if(this.byteReader)await this.byteReader.cancel();}catch(_){}};

  async function maybeOffload(value,ctx){
    if(!value||typeof value!=="object"||Array.isArray(value)||!root.ExtensionMediaStore||typeof root.ExtensionMediaStore.maybeStore!=="function")return value;
    if(typeof value.data!=="string"||!isDataUrl(value.data))return value;
    var before=value.data,stored=await root.ExtensionMediaStore.maybeStore(before,safeMeta(value));
    if(stored!==before){value.data=stored;ctx.offloadedCount++;ctx.offloadedRefs.push(stored);}
    return value;
  }

  async function parseFile(file,options){
    options=options||{};var size=Number(file&&file.size||0);if(!Number.isFinite(size)||size<1)throw coded("BACKUP_JSON_FILE_INVALID","O arquivo JSON está vazio ou é inválido.");if(size>MAX_FILE_BYTES)throw coded("BACKUP_JSON_FILE_TOO_LARGE","A cópia JSON excede o limite seguro atual de 2,2 GB.");
    var reader=new StreamReader(file),ctx={nodes:0,offloadedCount:0,offloadedRefs:[],lastProgressAt:0},onProgress=typeof options.onProgress==="function"?options.onProgress:null;
    async function progress(){if(!onProgress)return;var now=Date.now();if(now-ctx.lastProgressAt<250)return;ctx.lastProgressAt=now;try{onProgress({chars:reader.charCount,sizeBytes:size,nodes:ctx.nodes,offloaded:ctx.offloadedCount});}catch(_){}}
    async function parseValue(path,depth){
      if(depth>MAX_DEPTH)throw coded("BACKUP_JSON_TOO_DEEP","A estrutura JSON excede o limite seguro de profundidade.");if(++ctx.nodes>MAX_NODES)throw coded("BACKUP_JSON_TOO_COMPLEX","A estrutura JSON excede o limite seguro de complexidade.");await progress();var ch=await reader.skipWs(),value;
      if(ch==='{')value=await parseObject(path,depth+1);else if(ch==='[')value=await parseArray(path,depth+1);else if(ch==='"')value=await reader.readString();else if(ch)value=await reader.readPrimitive();else throw coded("BACKUP_JSON_SYNTAX","JSON inválido: fim inesperado do arquivo.");
      return maybeOffload(value,ctx);
    }
    async function parseObject(path,depth){
      await reader.expect('{');var out={},first=true;while(true){var ch=await reader.skipWs();if(ch==='}'){await reader.take();return out;}if(!first){if(ch!==',')throw coded("BACKUP_JSON_SYNTAX","JSON inválido: era esperada uma vírgula no objeto.");await reader.take();await reader.skipWs();}first=false;if(await reader.peek()!=='"')throw coded("BACKUP_JSON_SYNTAX","JSON inválido: chave de objeto ausente.");var key=await reader.readString();await reader.skipWs();await reader.expect(':');var value=await parseValue(path.concat(key),depth);if(!UNSAFE.has(key))out[key]=value;}
    }
    async function parseArray(path,depth){
      await reader.expect('[');var out=[],first=true,index=0;while(true){var ch=await reader.skipWs();if(ch===']'){await reader.take();return out;}if(!first){if(ch!==',')throw coded("BACKUP_JSON_SYNTAX","JSON inválido: era esperada uma vírgula na lista.");await reader.take();await reader.skipWs();}first=false;out.push(await parseValue(path.concat(index++),depth));if(index>MAX_NODES)throw coded("BACKUP_JSON_TOO_COMPLEX","Uma lista do backup excede o limite seguro de itens.");}
    }
    try{
      var value=await parseValue([],0);await reader.skipWs();if(await reader.peek())throw coded("BACKUP_JSON_TRAILING_DATA","O arquivo JSON possui dados extras após o objeto principal.");if(!value||typeof value!=="object"||Array.isArray(value))throw coded("BACKUP_JSON_ROOT_INVALID","O backup JSON precisa ter um objeto na raiz.");if(onProgress)try{onProgress({chars:reader.charCount,sizeBytes:size,nodes:ctx.nodes,offloaded:ctx.offloadedCount,done:true});}catch(_){}return{value:value,offloadedCount:ctx.offloadedCount,offloadedRefs:ctx.offloadedRefs.slice(),streamed:true};
    }finally{await reader.close();}
  }

  root.__extLargeBackupJson=Object.freeze({version:"1.0.0",maxFileBytes:MAX_FILE_BYTES,streamThresholdBytes:STREAM_THRESHOLD_BYTES,maxStringChars:MAX_STRING_CHARS,parseFile:parseFile});
})(typeof window!=="undefined"?window:self);
