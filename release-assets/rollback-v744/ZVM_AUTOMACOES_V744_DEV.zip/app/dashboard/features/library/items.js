;
try{
(function () {
  "use strict";

  if (window.__extItensModuleBooted) return;
  window.__extItensModuleBooted = true;

                                                                        
                                                                    
                                                                        
                                                                          
                                                                       
  var MAX_VIDEO_BYTES = 180 * 1024 * 1024;

                                                                     
                                                                        
                                                     
  function extItemDisplayName(item) {
    return (item && item.name && String(item.name).trim()) || "(sem nome)";
  }

  var LIST_STORE = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList" },
    audio: { key: "EXTUI:audioStore", listField: "audioList" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList" },
    image: { key: "EXTUI:mediaStore", listField: "mediaList", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", listField: "mediaList", virtualMediaKind: "video" },
    sticker: { key: "EXTUI:stickerStore", listField: "stickerList" },
    document: { key: "EXTUI:documentStore", listField: "documentList" },
                                                                                                         
                                                                           
                                                                  
    pix: { key: "EXTUI:pixStore", listField: "pixList" },
    "interactive-list": { key: "EXTUI:interactiveListStore", listField: "interactiveListList" },
    contact: { key: "EXTUI:contactCardStore", listField: "contactList" },
    signature: { key: "EXTUI:signaturesStore", listField: "list", plainList: true }
  };

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
  }
  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
                                                                             
                                                                      
                                                                        
                                                                           
                                                             
  var ICONS = {
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    audio: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    media: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    video: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m10 9 5 3-5 3z"/>',
    sticker: '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>',
    document: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
    edit: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
    star: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14 2 9.27l6.91-1.01Z"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    mic: '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>',
    square: '<rect width="14" height="14" x="5" y="5" rx="1"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    send: '<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
                                                                            
                                                                          
                                                                        
                                             
    pix: '<path d="m12 3 3 3-3 3-3-3z"/><path d="m12 15 3 3-3 3-3-3z"/><path d="m3 12 3-3 3 3-3 3z"/><path d="m15 12 3-3 3 3-3 3z"/>',
    interactiveList: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3" cy="6" r="1"/><circle cx="3" cy="12" r="1"/><circle cx="3" cy="18" r="1"/>',
    contact: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    signature: '<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h5M8 16h8"/>',
    plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M20 20a8 8 0 0 0-8-8H4"/>',
    redo: '<path d="m15 14 5-5-5-5"/><path d="M4 20a8 8 0 0 1 8-8h8"/>'
  };
  function icon(nameOrEmoji, extraClass) {
    var span = document.createElement("span");
    span.className = "extui-svgicon" + (extraClass ? " " + extraClass : "");
    if (ICONS[nameOrEmoji]) {
      span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[nameOrEmoji] + "</svg>";
    } else {
      span.textContent = nameOrEmoji;
    }
    return span;
  }

  function extConfigStudioDecorate(body, options) {
    options = options || {};
    var nodes = Array.prototype.slice.call(body.childNodes);
    body.innerHTML = "";
    body.classList.add("extuiConfigStudioBody", "extuiConfigStudioBody--" + (options.kind || "generic"));

    var shell = el("div", { class: "extuiConfigStudioShell" });
    var main = el("div", { class: "extuiConfigStudioMain" });
    var aside = el("aside", { class: "extuiConfigStudioAside" });
    var asideHead = el("div", { class: "extuiConfigStudioAsideHead" }, [
      el("div", { class: "extuiConfigStudioAsideIcon" }, [icon(options.icon || "message")]),
      el("div", {}, [
        el("strong", { text: "Prévia" }),
        el("span", { text: "Veja como este item ficará na conversa antes de salvar." })
      ])
    ]);
    var preview = el("div", { class: "extConfigStudioPreview" });
    aside.appendChild(asideHead);
    aside.appendChild(preview);

    for (var i = 0; i < nodes.length; i += 1) {
      var node = nodes[i];
      if (!node || node.nodeType !== 1) { if (node) main.appendChild(node); continue; }
      if (node.tagName === "LABEL" && !node.querySelector("input,select,textarea") && !node.classList.contains("extuiItensCheckRow")) {
        var fieldWrap = el("div", { class: "extuiConfigStudioField" });
        fieldWrap.appendChild(node);
        var next = nodes[i + 1];
        if (next && next.nodeType === 1 && (next.matches("input,select,textarea") || next.classList.contains("extuiItensFilePicker") || next.classList.contains("extuiItensAudioPreview") || next.classList.contains("extuiItensAudioModeRow") || next.classList.contains("extuiConfigStudioFileHint"))) {
          fieldWrap.appendChild(next); i += 1;
        }
        main.appendChild(fieldWrap);
      } else if (node.tagName === "LABEL" && (node.querySelector("input") || node.classList.contains("extuiItensCheckRow"))) {
        node.classList.add("extuiConfigStudioOption"); main.appendChild(node);
      } else {
        node.classList.add("extuiConfigStudioStandalone"); main.appendChild(node);
      }
    }
    if (options.previewSelector) {
      var previewNode = main.querySelector(options.previewSelector);
      if (previewNode) previewNode.classList.add("extuiConfigStudioPreviewNode");
    }
    shell.appendChild(main); shell.appendChild(aside); body.appendChild(shell);
    return { shell: shell, main: main, aside: aside, preview: preview, kind: options.kind || "generic", previewObjectUrl: "" };
  }

  function extConfigStudioSetMediaSource(node, source) {
    if (!node || !source) return;
    if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(source)) {
      window.ExtensionMediaStore.previewUrl(source).then(function (url) { if (node.isConnected) node.src = url; }).catch(function () {});
    } else node.src = source;
  }

  function extConfigStudioPreview(studio, title, lines, media) {
    if (!studio || !studio.preview) return;
    if (studio.previewObjectUrl) { try { URL.revokeObjectURL(studio.previewObjectUrl); } catch (_) {} studio.previewObjectUrl = ""; }
    studio.preview.innerHTML = "";
    studio.preview.appendChild(el("span", { class: "extuiConfigStudioPreviewLabel", text: "Prévia no WhatsApp" }));
    var chat = el("div", { class: "extuiConfigStudioWhatsapp" });
    var bubble = el("div", { class: "extuiConfigStudioWhatsappBubble extuiConfigStudioWhatsappBubble--" + (studio.kind || "generic") });
    media = media || {};
    var kind = media.kind || studio.kind;
    var source = media.src || "";
    if (media.file && typeof URL !== "undefined" && URL.createObjectURL) { try { source = URL.createObjectURL(media.file); studio.previewObjectUrl = source; } catch (_) {} }
    if ((kind === "image" || kind === "sticker") && source) {
      var img = el("img", { class: "extuiConfigStudioWhatsappMedia", alt: "Prévia de " + (kind === "sticker" ? "figurinha" : "imagem") }); extConfigStudioSetMediaSource(img, source); bubble.appendChild(img);
    } else if (kind === "video" && source) {
      var video = el("video", { class: "extuiConfigStudioWhatsappMedia", controls: "controls", muted: "muted", playsinline: "playsinline" }); extConfigStudioSetMediaSource(video, source); bubble.appendChild(video);
    } else if (kind === "audio" && source) {
      var audio = el("audio", { class: "extuiConfigStudioWhatsappAudio", controls: "controls" }); extConfigStudioSetMediaSource(audio, source); bubble.appendChild(audio);
    } else if (kind === "document") {
      bubble.appendChild(el("div", { class: "extuiConfigStudioWhatsappFile" }, [icon("document"), el("div", {}, [el("strong", { text: (lines && lines[0]) || "Documento" }), el("span", { text: (lines && lines[1]) || "Arquivo para download" })]) ]));
    } else if (kind === "contact") {
      bubble.appendChild(el("div", { class: "extuiConfigStudioWhatsappContact" }, [icon("contact"), el("div", {}, [el("strong", { text: title || "Contato" }), el("span", { text: (lines && lines[0]) || "Cartão de contato" })]) ]));
    } else if (kind === "pix") {
      bubble.appendChild(el("div", { class: "extuiConfigStudioWhatsappFile" }, [icon("pix"), el("div", {}, [el("strong", { text: title || "PIX" }), el("span", { text: (lines && lines[0]) || "Chave PIX" })]) ]));
    }
    if (kind !== "contact" && kind !== "pix") bubble.appendChild(el("strong", { class: "extuiConfigStudioPreviewTitle", text: title || "Ainda não configurado" }));
    (lines || []).forEach(function (line, index) {
      if (!line || ((kind === "document" && index < 2) || (kind === "contact" && index === 0) || (kind === "pix" && index === 0))) return;
      bubble.appendChild(el("span", { class: "extuiConfigStudioPreviewLine", text: line }));
    });
    bubble.appendChild(el("span", { class: "extuiConfigStudioWhatsappTime", text: "10:30 ✓✓" }));
    chat.appendChild(bubble); studio.preview.appendChild(chat);
  }

  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function snapshotLibraryModalState(root) {
    var nodes = root ? Array.prototype.slice.call(root.querySelectorAll('input,select,textarea,[contenteditable="true"]')) : [];
    return JSON.stringify(nodes.map(function (node, index) {
      var tag = String(node.tagName || "").toLowerCase();
      var type = String(node.type || "").toLowerCase();
      var state = { index: index, tag: tag, type: type, id: node.id || "", name: node.name || "" };
      if (type === "checkbox" || type === "radio") state.checked = !!node.checked;
      else if (type === "file") {
        state.files = Array.prototype.slice.call(node.files || []).map(function (file) {
          return [String(file.name || ""), Number(file.size || 0), String(file.type || ""), Number(file.lastModified || 0)];
        });
      } else if (tag === "select" && node.multiple) {
        state.value = Array.prototype.filter.call(node.options || [], function (option) { return option.selected; }).map(function (option) { return String(option.value); });
      } else if (node.isContentEditable) state.value = String(node.textContent || "");
      else state.value = String(node.value == null ? "" : node.value);
      return state;
    }));
  }
  function openModal(opts) {
    var previousFocus = document.activeElement;
    var titleId = "extuif-modal-title-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
    var overlay = el("div", { class: "extuifModalOverlay" });
    var modal = el("div", { class: "extuifModal extuiLibraryModal" + (opts.className ? " " + opts.className : ""), role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, tabindex: "-1" });
    modal.appendChild(el("h3", { id: titleId, text: opts.title }));
    var body = el("div", {});
    modal.appendChild(body);
    var actions = el("div", { class: "extuifModalActions" });
    var cancelBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" });
    var confirmBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: opts.confirmLabel || "Salvar" });
    var closed = false, initialState = null, dirtyOverride = false;
    function focusables() {
      return Array.prototype.slice.call(modal.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[href],[tabindex]:not([tabindex="-1"])')).filter(function (node) { return !node.hidden && node.offsetParent !== null; });
    }
    function isDirty() {
      if (!opts.protectUnsaved) return false;
      if (dirtyOverride) return true;
      if (initialState == null) return false;
      return snapshotLibraryModalState(modal) !== initialState;
    }
    function close(reason) {
      if (closed) return;
      closed = true;
      document.removeEventListener("keydown", onKeyDown, true);
      overlay.remove();
      if (typeof opts.onClose === "function") { try { opts.onClose(reason || "close"); } catch (_) {} }
      if (previousFocus && previousFocus.focus && document.contains(previousFocus)) previousFocus.focus();
    }
    function requestDismiss(reason) {
      if (isDirty()) return false;
      close(reason || "dismiss");
      return true;
    }
    var modalState = {
      markDirty: function () { dirtyOverride = true; },
      isDirty: isDirty,
      reset: function () { dirtyOverride = false; initialState = snapshotLibraryModalState(modal); }
    };
    function onKeyDown(event) {
      if (event.key === "Escape") { event.preventDefault(); requestDismiss("escape"); return; }
      if (event.key !== "Tab") return;
      var items = focusables();
      if (!items.length) { event.preventDefault(); modal.focus(); return; }
      var first = items[0], last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    cancelBtn.addEventListener("click", function () { close("cancel"); });
    actions.appendChild(cancelBtn);
    actions.appendChild(confirmBtn);
    modal.appendChild(actions);
    overlay.appendChild(modal);
    overlay.addEventListener("click", function (e) { if (e.target === overlay) requestDismiss("backdrop"); });
    document.body.appendChild(overlay);
    document.addEventListener("keydown", onKeyDown, true);
    Promise.resolve(opts.render(body, close, confirmBtn, modalState)).then(function () {
      if (closed) return;
      modalState.reset();
      requestAnimationFrame(function () {
        if (closed) return;
        var items = focusables();
        (items[0] || modal).focus();
      });
    }).catch(function () {
      confirmBtn.disabled = true;
      body.innerHTML = "";
      body.appendChild(el("div", { class: "extuifModalLoadError", role: "alert", text: "Não foi possível carregar este editor. Feche a janela e tente novamente." }));
      toast("Não foi possível carregar os dados deste item.", true);
      modal.focus();
    });
  }

  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(key, function (res) {
          if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message || "Falha ao ler o armazenamento.")); return; }
          resolve(res ? res[key] : undefined);
        });
      } catch (err) { reject(err); }
    });
  }
  function storageSet(key, value) {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value);
    return new Promise(function (resolve, reject) {
      var obj = {}; obj[key] = value;
      try {
        chrome.storage.local.set(obj, function () {
          if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message || "Falha ao salvar no armazenamento.")); return; }
          resolve(true);
        });
      } catch (err) { reject(err); }
    });
  }
  function parsePersisted(raw) {
    if (raw == null || raw === "") return null;
    var parsed;
    try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (e) { e.code = e.code || "LIBRARY_STORE_CORRUPT"; throw e; }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state)) {
      var invalid = new Error("Os dados da Biblioteca estão inválidos e não serão sobrescritos.");
      invalid.code = "LIBRARY_STORE_CORRUPT";
      throw invalid;
    }
    return parsed.state;
  }

                                                                             
                                                                     
                                                                          
                                                               
                                                                         
                                                                     
                                                                          
                                                                         
                                                                  
  function sendToWhatsAppTab(type, payload) {
    return new Promise(function (resolve,reject) {
      var requestId = "itens-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      var done = false, timeoutId = null;
      function finish(result,error) { if (done) return; done = true; if (timeoutId) clearTimeout(timeoutId); if(error)reject(error);else resolve(result); }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        if(chrome.runtime.lastError){finish(null,new Error(chrome.runtime.lastError.message||"Não foi possível localizar o WhatsApp Web."));return;}
        var tb = (tabs || [])[0];
        if (!tb) { finish(null,new Error("Abra o WhatsApp Web para continuar.")); return; }
        var msg = Object.assign({ type: type, requestId: requestId }, payload || {});
        chrome.tabs.sendMessage(tb.id, msg, function (response) {
          if (chrome.runtime.lastError) { finish(null,new Error(chrome.runtime.lastError.message||"Falha ao comunicar com o WhatsApp Web.")); return; }
          if (!response || response.requestId !== requestId) { finish(null,new Error("O WhatsApp Web retornou uma resposta inválida.")); return; }
          if(response.error){finish(null,new Error(String(response.error)));return;}
          finish(response.data || []);
        });
        timeoutId = setTimeout(function () { finish(null,new Error("O WhatsApp Web demorou para responder.")); }, 20000);
      });
    });
  }
  function searchContactsForSend(query) { return sendToWhatsAppTab("EXTUI_DISPAROS_SEARCH_CONTACTS", { query: query }); }
  function fetchGroupsForSend() { return sendToWhatsAppTab("EXTUI_SALVAR_FETCH_GROUPS"); }

  var SEND_ITEM_TIMEOUT_MS = 25000;
  function requestSendItem(payload) {
    return window.__extDashboardShell.sendToWhatsAppTab("EXTUI_ITEMS_SEND_NOW", payload, SEND_ITEM_TIMEOUT_MS);
  }
                                                                           
                                                                              
                                                                         
                                      
  var SENDABLE_KINDS = { message: true, audio: true, media: true, image: true, video: true, sticker: true, document: true, pix: true, "interactive-list": true };

  function openSendPicker(kind, item) {
    var displayName = extItemDisplayName(item);
    var mode = "contact";
    var selected = null;                     
    openModal({
      title: "Enviar \"" + displayName + "\"",
      confirmLabel: "Enviar",
      render: function (body, close, confirmBtn) {
        confirmBtn.disabled = true;
        var tabRow = el("div", { class: "extuiItensSendTabRow" });
        var contactTabBtn = el("button", { type: "button", class: "extuiItensSendTabBtn extuiActive", text: "Contato" });
        var groupTabBtn = el("button", { type: "button", class: "extuiItensSendTabBtn", text: "Grupo" });
        tabRow.appendChild(contactTabBtn);
        tabRow.appendChild(groupTabBtn);
        body.appendChild(tabRow);

        var contactPane = el("div", { class: "extuiItensSendPane" });
        var contactInput = el("input", { type: "text", placeholder: "Digite um nome..." });
        var contactResults = el("div", { class: "extuiItensSendResults" });
        contactPane.appendChild(contactInput);
        contactPane.appendChild(contactResults);

        var groupPane = el("div", { class: "extuiItensSendPane", hidden: "hidden" });
        var groupSelect = el("select", {}, [el("option", { value: "", text: "Carregando grupos..." })]);
        groupPane.appendChild(groupSelect);
        var groupsLoaded = false;

        body.appendChild(contactPane);
        body.appendChild(groupPane);

        function selectTarget(chatId, label) {
          selected = { chatId: chatId, label: label };
          confirmBtn.disabled = false;
        }
        var _searchDebounce = null;
        contactInput.addEventListener("input", function () {
          clearTimeout(_searchDebounce);
          selected = null; confirmBtn.disabled = true;
          contactResults.innerHTML = '<div class="extuiItensSendEmpty">Buscando...</div>';
          _searchDebounce = setTimeout(async function () {
            try {
              var results = (await searchContactsForSend(contactInput.value)) || [];
              if (!results.length) { contactResults.innerHTML = '<div class="extuiItensSendEmpty">Nenhum contato encontrado</div>'; return; }
              contactResults.innerHTML = "";
              results.forEach(function (r) {
                var row = el("div", { class: "extuiItensSendResultRow", text: r.label + (r.displayNumber ? " (" + r.displayNumber + ")" : "") });
                row.addEventListener("click", function () {
                  contactResults.querySelectorAll(".extuiItensSendResultRow").forEach(function (x) { x.classList.remove("extuiSelected"); });
                  row.classList.add("extuiSelected");
                  selectTarget(r.value, r.label);
                });
                contactResults.appendChild(row);
              });
            } catch(err) { contactResults.innerHTML="";contactResults.appendChild(el("div",{class:"extuiItensSendEmpty",text:err&&err.message||"Falha ao buscar contatos"})); }
          }, 250);
        });

        function switchMode(next) {
          mode = next;
          selected = null; confirmBtn.disabled = true;
          contactPane.hidden = next !== "contact";
          groupPane.hidden = next !== "group";
          contactTabBtn.classList.toggle("extuiActive", next === "contact");
          groupTabBtn.classList.toggle("extuiActive", next === "group");
          if (next === "group" && !groupsLoaded) {
            groupsLoaded = true;
            fetchGroupsForSend().then(function (groups) {
              groupSelect.innerHTML = "";
              if (!groups || !groups.length) { groupSelect.appendChild(el("option", { value: "", text: "Nenhum grupo encontrado" })); return; }
              groupSelect.appendChild(el("option", { value: "", text: "Selecione um grupo..." }));
              groups.forEach(function (g) { groupSelect.appendChild(el("option", { value: g.value, text: g.label })); });
            }).catch(function () { groupSelect.innerHTML = ""; groupSelect.appendChild(el("option", { value: "", text: "Falha ao carregar grupos" })); });
          }
        }
        groupSelect.addEventListener("change", function () {
          if (!groupSelect.value) { selected = null; confirmBtn.disabled = true; return; }
          selectTarget(groupSelect.value, groupSelect.selectedOptions[0].textContent);
        });
        contactTabBtn.addEventListener("click", function () { switchMode("contact"); });
        groupTabBtn.addEventListener("click", function () { switchMode("group"); });

        confirmBtn.addEventListener("click", async function () {
          if (!selected) return;
          confirmBtn.disabled = true;
          confirmBtn.textContent = "Enviando...";
          try {
            var result = await requestSendItem({ type: storageKind(kind), itemId: item.id, targetChatId: selected.chatId, targetLabel: selected.label });
            if (result.cancelled) { toast("Envio cancelado."); }
            else { toast("Enviado para " + selected.label + "!"); }
            close();
          } catch (err) {
            toast(err && err.message ? err.message : "Falha ao enviar.", true);
            confirmBtn.disabled = false;
            confirmBtn.textContent = "Enviar";
          }
        });
      }
    });
  }
  function storageKind(kind) { return kind === "image" || kind === "video" ? "media" : kind; }
  async function readRawList(kind) {
    var config = LIST_STORE[storageKind(kind)];
    if (!config) return [];
    if (config.plainList) return window.ExtensionSignatureStore ? window.ExtensionSignatureStore.list() : [];
    var raw = await storageGet(config.key);
    var state = parsePersisted(raw);
    return (state && Array.isArray(state[config.listField])) ? state[config.listField] : [];
  }
  async function resolveMediaSubtype(item) {
    if (item && (item.mediaKind === "image" || item.mediaKind === "video")) return item.mediaKind;
    if (!item || !item.id) return "unknown";
    try {
      var content = activeKind === "signature" ? { data: item.text || "" } : await loadContent(item.id);
      if (!content) return "unknown";
      if (content.mediaKind === "image" || content.mediaKind === "video") return content.mediaKind;
      if (/^data:video\//i.test(String(content.data || ""))) return "video";
      if (/^data:image\//i.test(String(content.data || ""))) return "image";
      return extLibraryMediaKind(content.fileName || "", content.mimeType || "");
    } catch (_) { return "unknown"; }
  }
  async function loadList(kind) {
    var list = await readRawList(kind);
    if (kind !== "image" && kind !== "video") return list;
    var matches = [];
    for (var i = 0; i < list.length; i++) {
      if (await resolveMediaSubtype(list[i]) === kind) matches.push(list[i]);
    }
    return matches;
  }
  async function saveList(kind, list) {
    var baseKind = storageKind(kind);
    var config = LIST_STORE[baseKind];
    if (!config) throw new Error("Categoria de biblioteca inválida.");
    var output = list;
    if (kind === "image" || kind === "video") {
      var rawList = await readRawList("media");
      var preserved = [];
      for (var i = 0; i < rawList.length; i++) {
        if (await resolveMediaSubtype(rawList[i]) !== kind) preserved.push(rawList[i]);
      }
      output = preserved.concat((list || []).map(function (item) { return Object.assign({}, item, { mediaKind: kind }); }));
    }
    if (config.plainList) { if (!window.ExtensionSignatureStore) throw new Error("O armazenamento de assinaturas não está disponível."); await window.ExtensionSignatureStore.replaceAll(output); return; }
    await storageSet(config.key, JSON.stringify({ state: (function () { var o = {}; o[config.listField] = output; return o; })(), version: 0 }));
  }
  async function loadContent(itemId) {
    var raw = await storageGet(itemId);
    if (raw == null || raw === "") return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (e) { e.code = e.code || "LIBRARY_CONTENT_CORRUPT"; throw e; }
  }
  async function saveContent(itemId, content) {
    if (content && content.data && window.ExtensionMediaStore) {
      content = Object.assign({}, content);
      content.data = await window.ExtensionMediaStore.maybeStore(content.data, { mimeType: content.mimeType || "", fileName: content.fileName || "arquivo", sizeBytes: Number(content.sizeBytes || 0) });
    }
    await storageSet(itemId, JSON.stringify(content));
  }
  async function deleteContent(itemId) {
    return new Promise(function (resolve, reject) {
      try {
        if (window.ExtensionStorage && typeof window.ExtensionStorage.remove === "function") { window.ExtensionStorage.remove(itemId).then(function(){ resolve(true); }, reject); return; }
      chrome.storage.local.remove(itemId, function () {
          if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message || "Falha ao remover o conteúdo.")); return; }
          if (window.ExtensionMediaStore && typeof window.ExtensionMediaStore.gc === "function") window.ExtensionMediaStore.gc().catch(function () {});
          resolve(true);
        });
      } catch (err) { reject(err); }
    });
  }
  function readFileAsDataUrl(file) {
    if (file && window.ExtensionMediaStore && Number(file.size || 0) >= window.ExtensionMediaStore.thresholdBytes) return window.ExtensionMediaStore.putFile(file);
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = function () { reject(reader.error); };
      reader.readAsDataURL(file);
    });
  }

  function extLibraryExt(name) { var m = String(name || "").toLowerCase().match(/\.([a-z0-9]+)$/); return m ? m[1] : ""; }
  function extLibraryIsVideo(name, mime) { return /^video\//i.test(String(mime || "")) || /^(?:mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(extLibraryExt(name)); }
  function extLibraryIsImage(name, mime) { return /^image\//i.test(String(mime || "")) || /^(?:jpg|jpeg|png|gif|webp|bmp)$/.test(extLibraryExt(name)); }
  function extLibraryMediaKind(name, mime) { return extLibraryIsVideo(name, mime) ? "video" : (extLibraryIsImage(name, mime) ? "image" : "document"); }
  function extStickerInputSupported(file) {
    var type=String(file&&file.type||"").toLowerCase(),ext=extLibraryExt(file&&file.name);
    return /^(?:image\/png|image\/jpeg|image\/webp)$/.test(type) || /^(?:png|jpg|jpeg|webp)$/.test(ext);
  }
  function extBlobDataUrl(blob) {
    return new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(r.result);};r.onerror=function(){reject(r.error||new Error("Falha ao ler imagem."));};r.readAsDataURL(blob);});
  }
  async function extPrepareStickerFile(file) {
    if(!file||!extStickerInputSupported(file))throw new Error("Use PNG, JPG/JPEG ou WebP.");
    var type=String(file.type||"").toLowerCase();
    if(type==="image/webp"||/\.webp$/i.test(file.name||""))return {data:await readFileAsDataUrl(file),fileName:String(file.name||"figurinha.webp").replace(/\.[^.]+$/,"")+".webp",mimeType:"image/webp",sizeBytes:Number(file.size||0),sourceMimeType:type||"image/webp",sourceFileName:file.name||"figurinha.webp",converted:false};
    var bitmap=null;
    try { bitmap=await createImageBitmap(file); } catch (_) { throw new Error("Não foi possível abrir esta imagem para conversão."); }
    var canvas=document.createElement("canvas"),size=512;canvas.width=size;canvas.height=size;var ctx=canvas.getContext("2d",{alpha:true});ctx.clearRect(0,0,size,size);
    var scale=Math.min(size/bitmap.width,size/bitmap.height,1),w=Math.max(1,Math.round(bitmap.width*scale)),h=Math.max(1,Math.round(bitmap.height*scale)),x=Math.round((size-w)/2),y=Math.round((size-h)/2);ctx.drawImage(bitmap,x,y,w,h);if(bitmap.close)bitmap.close();
    var blob=await new Promise(function(resolve){canvas.toBlob(resolve,"image/webp",0.92);});if(!blob)throw new Error("O navegador não conseguiu converter esta imagem para WebP.");
    return {data:await extBlobDataUrl(blob),fileName:String(file.name||"figurinha").replace(/\.[^.]+$/,"")+".webp",mimeType:"image/webp",sizeBytes:Number(blob.size||0),sourceMimeType:type||"image/jpeg",sourceFileName:file.name||"imagem",converted:true};
  }

  var audioCodecLoadPromise = null;
  function ensureAudioCodec() {
    if (window.ExtensionAudioCodec && typeof window.ExtensionAudioCodec.normalizeBlob === "function") return Promise.resolve(window.ExtensionAudioCodec);
    if (audioCodecLoadPromise) return audioCodecLoadPromise;
    audioCodecLoadPromise = new Promise(function (resolve, reject) {
      var script = document.createElement("script");
      script.src = chrome.runtime.getURL("app/shared/audio/codec.js");
      script.async = true;
      script.dataset.extappLazyModule = "audio-codec";
      script.onload = function () {
        script.remove();
        if (window.ExtensionAudioCodec && typeof window.ExtensionAudioCodec.normalizeBlob === "function") resolve(window.ExtensionAudioCodec);
        else reject(new Error("Motor de compatibilidade de áudio não carregado."));
      };
      script.onerror = function () { script.remove(); reject(new Error("Não foi possível carregar o motor de compatibilidade de áudio.")); };
      (document.head || document.documentElement).appendChild(script);
    }).catch(function (error) { audioCodecLoadPromise = null; throw error; });
    return audioCodecLoadPromise;
  }
  function getAudioCodec() {
    if (!window.ExtensionAudioCodec || typeof window.ExtensionAudioCodec.normalizeBlob !== "function") throw new Error("Motor de compatibilidade de áudio não carregado.");
    return window.ExtensionAudioCodec;
  }

  function createMicRecorder() {
    var recorder = null, chunks = [], micStream = null, mimeType = "";
    function cleanup() {
      if (micStream) { try { micStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} }
      micStream = null;
    }
    return {
      start: async function () {
        if (typeof MediaRecorder === "undefined") throw new Error("Gravação de áudio não suportada neste navegador.");
        getAudioCodec();
        micStream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
        mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : (MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "");
        recorder = new MediaRecorder(micStream, mimeType ? { mimeType: mimeType, audioBitsPerSecond: 64000 } : { audioBitsPerSecond: 64000 });
        chunks = [];
        recorder.addEventListener("dataavailable", function (e) { if (e.data && e.data.size) chunks.push(e.data); });
        await new Promise(function (resolve, reject) {
          recorder.addEventListener("start", resolve, { once: true });
          recorder.addEventListener("error", function (e) { reject(new Error(e && e.message ? e.message : "erro ao iniciar gravação")); }, { once: true });
          recorder.start(250);
        });
      },
      stop: function () {
        return new Promise(function (resolve, reject) {
          if (!recorder || recorder.state === "inactive") { cleanup(); reject(new Error("gravação não iniciada")); return; }
          recorder.addEventListener("stop", async function () {
            try {
              var blob = new Blob(chunks, { type: recorder.mimeType || mimeType || "audio/webm" });
              var normalized = await getAudioCodec().normalizeBlob(blob, { fileName: "gravacao.webm", bitrate: 32000 });
              resolve(normalized);
            } catch (err) { reject(err); }
            finally { cleanup(); recorder = null; chunks = []; }
          }, { once: true });
          recorder.stop();
        });
      },
      cancel: function () { try { if (recorder && recorder.state !== "inactive") recorder.stop(); } catch (e) {} cleanup(); }
    };
  }

  var TABS = [
    { kind: "message", label: "Mensagens", icon: "message", colorKey: "message" },
    { kind: "audio", label: "Áudios", icon: "audio", colorKey: "audio" },
    { kind: "image", label: "Imagens", icon: "image", colorKey: "image" },
    { kind: "video", label: "Vídeos", icon: "video", colorKey: "video" },
    { kind: "sticker", label: "Figurinhas", icon: "sticker", colorKey: "sticker" },
    { kind: "document", label: "Documentos", icon: "document", colorKey: "document" },
                                                                        
                                                               
    { kind: "pix", label: "PIX", icon: "pix", colorKey: "pix" },
    { kind: "interactive-list", label: "Listas", icon: "interactiveList", colorKey: "interactiveList" },
    { kind: "contact", label: "Contatos", icon: "contact", colorKey: "contact" },
    { kind: "signature", label: "Assinaturas", icon: "signature", colorKey: "signature" }
  ];
  var CATEGORY_META = Object.freeze({
    message: { eyebrow: "Comunicação inteligente", title: "Mensagens", desc: "Crie textos reutilizáveis, combine variáveis e envie respostas consistentes sem perder o tom humano.", action: "Nova mensagem" },
    audio: { eyebrow: "Biblioteca de voz", title: "Áudios", desc: "Organize notas de voz e arquivos de áudio prontos para uso, preservando o envio como nota de voz quando necessário.", action: "Novo áudio" },
    image: { eyebrow: "Conteúdo visual", title: "Imagens", desc: "Organize imagens e GIFs reutilizáveis com legenda, prévia rápida e envio direto para conversas e automações.", action: "Nova imagem" },
    video: { eyebrow: "Conteúdo em movimento", title: "Vídeos", desc: "Centralize vídeos reutilizáveis, com legenda, visualização única e modo de vídeo recado quando compatível.", action: "Novo vídeo" },
    sticker: { eyebrow: "Expressão visual", title: "Figurinhas", desc: "Salve figurinhas WebP para reutilizar em atendimentos e automações com envio nativo de sticker.", action: "Nova figurinha" },
    document: { eyebrow: "Arquivos", title: "Documentos", desc: "Mantenha PDFs, propostas e outros documentos organizados para envio rápido nas conversas.", action: "Novo documento" },
    pix: { eyebrow: "Cobrança rápida", title: "PIX", desc: "Salve chaves PIX por contexto e envie os dados de pagamento sem redigitar informações.", action: "Novo PIX" },
    "interactive-list": { eyebrow: "Escolhas interativas", title: "Listas Interativas", desc: "Crie menus selecionáveis nativos do WhatsApp para serviços, setores, produtos e outras escolhas.", action: "Nova lista" },
    contact: { eyebrow: "Relacionamento", title: "Contatos", desc: "Crie cartões de contato reutilizáveis e compartilhe dados de forma consistente no WhatsApp.", action: "Novo contato" },
    signature: { eyebrow: "Comunicação pessoal", title: "Assinaturas", desc: "Crie assinaturas reutilizáveis e escolha quais ficam disponíveis no Menu Rápido.", action: "Nova assinatura" }
  });

  var activeKind = "message";
  var searchTerm = "";
  var selectedItemId = null;
  var splitDetailEl = null;
  var splitListEl = null;
  var sectionCountEl = null;
  var pageRootEl = null;

  function iconForKind(kind) { return (TABS.find(function (t) { return t.kind === kind; }) || {}).icon || "📎"; }
  function colorKeyForKind(kind) { return (TABS.find(function (t) { return t.kind === kind; }) || {}).colorKey || "message"; }
  function labelForKind(kind) { return (TABS.find(function (t) { return t.kind === kind; }) || {}).label || ""; }

  async function toggleFavorite(kind, id) {
    if (kind === "signature") {
      var signature = window.ExtensionSignatureStore && await window.ExtensionSignatureStore.get(id);
      if (!signature) return;
      await window.ExtensionSignatureStore.save({ id: signature.id, title: extItemDisplayName(signature), text: signature.text, favorite: !signature.favorite, showInQuickMenu: signature.showInQuickMenu !== false, createdAt: signature.createdAt });
      return;
    }
    var list = await loadList(kind);
    var item = list.find(function (it) { return it.id === id; });
    if (!item) return;
    item.favorite = !item.favorite;
    await saveList(kind, list);
  }

  async function duplicateItem(kind, id) {
    if (kind === "signature") { var original = window.ExtensionSignatureStore && await window.ExtensionSignatureStore.get(id); if (!original) return null; var copy = await window.ExtensionSignatureStore.save({ title: extItemDisplayName(original) + " (cópia)", text: original.text, favorite: false, showInQuickMenu: original.showInQuickMenu !== false }); return copy.id; }
    var list = await loadList(kind);
    var item = list.find(function (it) { return it.id === id; });
    if (!item) return null;
    var content = await loadContent(id);
    if (!content) throw new Error("O item original está sem conteúdo e não pode ser duplicado.");
    var newId = uid();
    var nextList = list.concat([{ id: newId, name: extItemDisplayName(item) + " (cópia)", favorite: false }]);
                                                                            
                                                                             
    await saveContent(newId, content);
    try { await saveList(kind, nextList); }
    catch (err) { try { await deleteContent(newId); } catch (_) {} throw err; }
    return newId;
  }

  async function removeItemTransactional(kind, id) {
    if (kind === "signature") return window.ExtensionSignatureStore ? window.ExtensionSignatureStore.remove(id) : false;
    var list = await loadList(kind);
    var item = list.find(function (it) { return it.id === id; });
    if (!item) return false;
    var nextList = list.filter(function (it) { return it.id !== id; });
    await saveList(kind, nextList);
    try { await deleteContent(id); }
    catch (err) {
      try { await saveList(kind, list); } catch (_) {}
      throw err;
    }
    return true;
  }

  async function renderGrid(container) {
    container.innerHTML = "";
    var list = await loadList(activeKind);
    if (sectionCountEl) sectionCountEl.textContent = list.length + (list.length === 1 ? " item salvo" : " itens salvos");
    var filtered = list.filter(function (it) { return !searchTerm || (it.name || "").toLowerCase().indexOf(searchTerm.toLowerCase()) >= 0; });
    if (pageRootEl) {
      pageRootEl.classList.toggle("extuiItensPage--library-empty", list.length === 0);
      pageRootEl.classList.toggle("extuiItensPage--search-empty", list.length > 0 && filtered.length === 0);
    }
                                                                       
    filtered.sort(function (a, b) { return (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0); });
    if (filtered.length === 0) {
      var emptyTitle = list.length === 0 ? "Sua biblioteca começa aqui" : "Nenhum resultado encontrado";
      var emptyDesc = list.length === 0 ? "Crie o primeiro item desta categoria para reutilizá-lo no WhatsApp, em automações e nas respostas rápidas." : "Tente outro termo de busca ou limpe o filtro atual.";
      var empty = el("div", { class: "extuiItensEmpty" }, [
        el("div", { class: "extuiItensEmptyIcon" }, [icon(iconForKind(activeKind))]),
        el("strong", { class: "extuiItensEmptyTitle", text: emptyTitle }),
        el("span", { class: "extuiItensEmptyDesc", text: emptyDesc })
      ]);
      container.appendChild(empty);
      if (splitDetailEl) { selectedItemId = null; await renderDetailPanel(); }
      return;
    }
    if (selectedItemId && !filtered.some(function (it) { return it.id === selectedItemId; })) selectedItemId = null;
    var listEl = el("div", { class: "extuiItensList" });
    for (var i = 0; i < filtered.length; i++) {
      listEl.appendChild(renderCard(filtered[i], container));
    }
    container.appendChild(listEl);
    if (!selectedItemId && filtered.length > 0) selectedItemId = filtered[0].id;
    await renderDetailPanel();
  }

  function renderCard(item, gridContainer) {
    var colorKey = colorKeyForKind(activeKind);
    var isSelected = item.id === selectedItemId;
    var row = el("div", { class: "extuiItensRow extuiItensRow--" + colorKey + (isSelected ? " extuiItensRow--selected" : "") });
    row.addEventListener("click", function () { selectedItemId = item.id; renderGrid(gridContainer); });
    var iconWrap = el("div", { class: "extuiItensRowIcon extuiItensRowIcon--" + colorKey }, [icon(iconForKind(activeKind))]);
    row.appendChild(iconWrap);
    var displayName = extItemDisplayName(item);
    var nameCol = el("div", { class: "extuiItensRowMain" });
    nameCol.appendChild(el("div", { class: "extuiItensRowName", text: displayName }));
    if (activeKind === "image" || activeKind === "video") {
      nameCol.appendChild(el("div", { class: "extuiItensRowPreview", text: activeKind === "video" ? "Vídeo reutilizável" : "Imagem reutilizável" }));
    }
    row.appendChild(nameCol);
    var actions = el("div", { class: "extuiItensRowActions" });
    var editBtn = el("button", { class: "extuiItensIconBtn", title: "Editar", "aria-label": "Editar " + displayName }, [icon("edit")]);
    editBtn.addEventListener("click", function (e) { e.stopPropagation(); openItemForm(activeKind, item); });
    var favBtn = el("button", { class: "extuiItensIconBtn" + (item.favorite ? " extuiItensIconBtn--fav" : ""), title: item.favorite ? "Remover dos favoritos" : "Favoritar", "aria-label": (item.favorite ? "Remover dos favoritos: " : "Favoritar: ") + displayName }, [icon("star")]);
    favBtn.addEventListener("click", async function (e) {
      e.stopPropagation();
      await toggleFavorite(activeKind, item.id);
      renderGrid(gridContainer);
    });
    actions.appendChild(editBtn);
    actions.appendChild(favBtn);
    row.appendChild(actions);
    return row;
  }

  async function renderDetailPanel() {
    if (!splitDetailEl) return;
    splitDetailEl.innerHTML = "";
    if (!selectedItemId) {
      splitDetailEl.appendChild(el("div", { class: "extuiItensDetailEmpty" }, [
        el("div", { class: "extuiItensDetailEmptyIcon" }, [icon(iconForKind(activeKind))]),
        el("div", { class: "extuiItensDetailEmptyText", text: "Selecione um item para visualizar ou clique em \"+ Adicionar\" para criar um novo." })
      ]));
      return;
    }
    var list = await loadList(activeKind);
    var item = list.find(function (it) { return it.id === selectedItemId; });
    if (!item) { selectedItemId = null; return renderDetailPanel(); }
    var content = await loadContent(item.id);
    var displayData = content && content.data;
    if (displayData && window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(displayData)) {
      try { displayData = await window.ExtensionMediaStore.previewUrl(displayData); } catch (_) { displayData = null; }
    }
    var itemDisplayName = extItemDisplayName(item);
    var card = el("div", { class: "extuiItensDetailCard" });
    var header = el("div", { class: "extuiItensDetailHeader" });
    var detailIdentity = el("div", { class: "extuiItensDetailIdentity" }, [el("div", { class: "extuiItensDetailName", text: itemDisplayName })]);
    if (activeKind === "image" || activeKind === "video" || activeKind === "sticker") detailIdentity.appendChild(el("span", { class: "extuiItensDetailTypeChip", text: activeKind === "video" ? "Vídeo" : (activeKind === "sticker" ? "Figurinha" : "Imagem") }));
    header.appendChild(detailIdentity);
    var toolbarEl = el("div", { class: "extuiItensDetailActions" });
    var delBtn = el("button", { class: "extuiItensDetailBtn extuiItensDetailBtn--danger", title: "Excluir", "aria-label": "Excluir " + itemDisplayName }, [icon("trash")]);
    delBtn.addEventListener("click", async function () {
      var action=window.__extTrashConfirm?await window.__extTrashConfirm({title:'Excluir item da Biblioteca?',message:'Você pode enviar "'+itemDisplayName+'" para a Lixeira, criar um backup ou excluir definitivamente.'}):(await extConfirm('Excluir "' + itemDisplayName + '"?', { danger: true })?'permanent':null);if(!action)return;
      try {
        if(action==='trash'&&window.__extTrashService){var contentTrash=await loadContent(item.id);await window.__extTrashService.add({type:'library',label:itemDisplayName,payload:{kind:activeKind,item:item,content:contentTrash}});if(activeKind==='signature')await removeItemTransactional(activeKind,item.id);else{var currentList=await loadList(activeKind);await saveList(activeKind,currentList.filter(function(it){return it.id!==item.id;}));}}
        else await removeItemTransactional(activeKind, item.id);
        selectedItemId = null;
        toast(action==='trash'?"Item enviado para a Lixeira.":"Item excluído definitivamente.");
        await renderGrid(splitListEl);
      } catch (err) {
        toast("Não foi possível excluir o item: " + (err && err.message ? err.message : "erro de armazenamento"), true);
      }
    });
    var dupBtn = el("button", { class: "extuiItensDetailBtn", title: "Duplicar", "aria-label": "Duplicar " + itemDisplayName }, [icon("copy")]);
    dupBtn.addEventListener("click", async function () {
      try {
        var newId = await duplicateItem(activeKind, item.id);
        if (newId) { selectedItemId = newId; toast("Item duplicado."); await renderGrid(splitListEl); }
      } catch (err) {
        toast("Não foi possível duplicar o item: " + (err && err.message ? err.message : "erro de armazenamento"), true);
      }
    });
    var editBtn2 = el("button", { class: "extuiItensDetailBtn", title: "Editar", "aria-label": "Editar " + itemDisplayName }, [icon("edit")]);
    editBtn2.addEventListener("click", function () { openItemForm(activeKind, item); });
    var favBtn2 = el("button", { class: "extuiItensDetailBtn" + (item.favorite ? " extuiItensIconBtn--fav" : ""), title: item.favorite ? "Remover dos favoritos" : "Favoritar", "aria-label": (item.favorite ? "Remover dos favoritos: " : "Favoritar: ") + itemDisplayName }, [icon("star")]);
    favBtn2.addEventListener("click", async function () { await toggleFavorite(activeKind, item.id); renderGrid(splitListEl); });
    toolbarEl.appendChild(delBtn);
    toolbarEl.appendChild(dupBtn);
    toolbarEl.appendChild(editBtn2);
    toolbarEl.appendChild(favBtn2);
                                                                            
                                                                          
                                                                            
    if (SENDABLE_KINDS[activeKind]) {
      var sendBtn = el("button", { class: "extuiItensDetailBtn extuiItensDetailBtn--primary", title: "Enviar", "aria-label": "Enviar " + itemDisplayName }, [icon("send")]);
      sendBtn.addEventListener("click", function () { openSendPicker(activeKind, item); });
      toolbarEl.appendChild(sendBtn);
    }
    header.appendChild(toolbarEl);
    card.appendChild(header);

    if (activeKind === "signature") {
      card.appendChild(el("div", { class: "extuiItensDetailLabel", text: "Assinatura:" }));
      card.appendChild(el("div", { class: "extuiItensDetailText", text: item.text || "" }));
      card.appendChild(el("div", { class: "extuiItensDetailNote", text: item.showInQuickMenu !== false ? "Disponível no Menu Rápido" : "Oculta do Menu Rápido" }));
    } else if (activeKind === "message") {
      card.appendChild(el("div", { class: "extuiItensDetailLabel", text: "Texto da mensagem:" }));
      card.appendChild(el("div", { class: "extuiItensDetailText", text: (content && content.data) || "" }));
    } else if (activeKind === "audio") {
      card.appendChild(el("div", { class: "extuiItensDetailNote", text: (content && content.isPtt !== false) ? "🎙 Enviando como nota de voz" : "🎵 Enviando como arquivo de áudio" }));
      if (displayData) card.appendChild(el("audio", { class: "extuiItensDetailAudio", controls: "controls", src: displayData }));
    } else if (activeKind === "image" || activeKind === "video" || activeKind === "media") {
      if (content && content.isPtv) {
        card.appendChild(el("div", { class: "extuiItensDetailNote", text: "🎬 Enviando como vídeo recado (nota de vídeo)" }));
      }
      var detailMime = String(content && content.mimeType || "").toLowerCase();
      if (displayData && (detailMime.indexOf("image/") === 0 || /^blob:/.test(displayData) && detailMime.indexOf("image/") === 0 || /^data:image\//.test(displayData))) {
        card.appendChild(el("img", { class: "extuiItensDetailMedia", src: displayData }));
      } else if (displayData) {
        card.appendChild(el("video", { class: "extuiItensDetailMedia", controls: "controls", src: displayData }));
      }
      if (content && content.caption) {
        card.appendChild(el("div", { class: "extuiItensDetailLabel", text: "Legenda:" }));
        card.appendChild(el("div", { class: "extuiItensDetailText", text: content.caption }));
      }
    } else if (activeKind === "sticker") {
      if (displayData) card.appendChild(el("div", { class: "extuiItensDetailStickerStage" }, [el("img", { class: "extuiItensDetailSticker", src: displayData, alt: "Prévia da figurinha" })]));
      card.appendChild(el("div", { class: "extuiItensDetailNote", text: "Figurinha pronta para envio no WhatsApp" }));
    } else if (activeKind === "document") {
      card.appendChild(el("div", { class: "extuiItensDetailNote", text: "📄 " + ((content && content.fileName) || "arquivo") }));
    } else if (activeKind === "pix") {
      var pixTypeLabel = (PIX_KEY_TYPES.find(function (t) { return t[0] === (content && content.keyType); }) || [, "?"])[1];
      card.appendChild(el("div", { class: "extuiItensDetailNote", text: "💠 " + pixTypeLabel + ": " + ((content && content.key) || "") }));
      if (content && content.merchantName) card.appendChild(el("div", { class: "extuiItensDetailText", text: "Beneficiário: " + content.merchantName }));
    } else if (activeKind === "interactive-list") {
      var listApi = window.__extInteractiveList;
      var listValue = listApi ? listApi.normalize(content || {}) : (content || {});
      card.appendChild(buildInteractiveListPreview(listValue, { className: "extuiInteractiveListSavedPreview" }));
      var listSummary = el("div", { class: "extuiInteractiveListDetail" });
      (listValue.sections || []).forEach(function (section) {
        var sectionEl = el("div", { class: "extuiInteractiveListDetailSection" }, [el("strong", { text: section.title || "Opções" })]);
        (section.rows || []).forEach(function (row) {
          sectionEl.appendChild(el("div", { class: "extuiInteractiveListDetailRow" }, [
            el("span", { text: row.title || "Opção" }),
            row.description ? el("small", { text: row.description }) : null
          ]));
        });
        listSummary.appendChild(sectionEl);
      });
      card.appendChild(listSummary);
    } else if (activeKind === "contact") {
      card.appendChild(el("div", { class: "extuiItensDetailNote", text: "👤 " + ((content && content.contactName) || "") }));
      if (content && content.contactPhone) card.appendChild(el("div", { class: "extuiItensDetailText", text: content.contactPhone }));
    }
    splitDetailEl.appendChild(card);
  }

                                                                      
                                                                        
                                                                           
                                                                           
                             
  async function renderCategoryLibrary(kind, container, embedded, fastSwitch) {
    var previousPageRoot = pageRootEl;
    activeKind = kind;
    searchTerm = "";
    selectedItemId = null;
    var meta = CATEGORY_META[kind] || { eyebrow: "Comunicação", title: labelForKind(kind), desc: "Organize seus itens reutilizáveis.", action: "Adicionar" };

    var page = el("div", { class: "extuiItensPage extuiItensPage--" + colorKeyForKind(kind) });
    pageRootEl = page;
    var pageHead = el("div", { class: "extuiPageHeading extuiItensPageHeading" });
    var pageHeadMain = el("div", { class: "extuiPageHeadingMain" }, [
      el("div", { class: "extuiPageHeadingIcon" }, [icon(iconForKind(kind))]),
      el("div", { class: "extuiPageHeadingCopy" }, [
        el("div", { class: "extuiPageHeadingEyebrow", text: meta.eyebrow }),
        el("h1", { text: meta.title }),
        el("p", { text: meta.desc })
      ])
    ]);
    sectionCountEl = el("span", { class: "extuiPageHeadingMeta", text: "Carregando biblioteca..." });
    pageHead.appendChild(pageHeadMain);
    pageHead.appendChild(sectionCountEl);
    if (!embedded) page.appendChild(pageHead);


    var split = el("div", { class: "extuiItensSplit" + (embedded ? " extuiItensSplit--embedded" : ""), "data-extui-academy-target": "items-library" });
    var listCol = el("div", { class: "extuiItensSplitList" });
    var toolbar = el("div", { class: "extuiItensToolbar" });
    var searchWrap = el("div", { class: "extuiSearch extuiItensSearch" }, [icon("search")]);
    var searchInput = el("input", { type: "text", placeholder: "Buscar em " + meta.title.toLowerCase() + "...", "aria-label": "Buscar " + labelForKind(activeKind).toLowerCase() });
    var gridContainer = el("div", {});
    searchInput.value = searchTerm;
    searchInput.addEventListener("input", function () { searchTerm = searchInput.value; renderGrid(gridContainer); });
    searchWrap.appendChild(searchInput);
    var addBtn = el("button", { class: "extui-btn extui-btn--primary extuiItensAddBtn", "data-extui-academy-target": "items-new-message" }, [icon("plus"), el("span", { text: meta.action })]);
    addBtn.addEventListener("click", function () { openItemForm(activeKind, null); });
    toolbar.appendChild(searchWrap);
    toolbar.appendChild(addBtn);
    listCol.appendChild(toolbar);
    listCol.appendChild(gridContainer);

    var detailCol = el("div", { class: "extuiItensSplitDetail" });

    split.appendChild(listCol);
    split.appendChild(detailCol);
    page.appendChild(split);
    if (!(fastSwitch && previousPageRoot && previousPageRoot.isConnected && previousPageRoot.parentNode === container)) { container.innerHTML = ""; container.appendChild(page); }

    splitListEl = gridContainer;
    splitDetailEl = detailCol;
    if (fastSwitch && previousPageRoot && previousPageRoot.isConnected && previousPageRoot.parentNode === container) {
      await renderGrid(gridContainer);
      if (previousPageRoot.isConnected && previousPageRoot.parentNode === container) previousPageRoot.replaceWith(page);
      else if (!page.isConnected) { container.innerHTML = ""; container.appendChild(page); }
      return;
    }
    return renderGrid(gridContainer);
  }

  function extHubParse(raw) { if(raw==null||raw==="")return{};try{return typeof raw === "string" ? JSON.parse(raw) : raw;}catch(err){err.code=err.code||"DASHBOARD_STORE_CORRUPT";throw err;} }
  function extQrDashUid(prefix) { return String(prefix || "qr") + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9); }
  function extQrDashCopy(value) { try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; } }
  var EXTUI_QR_DASH_ACTION_LABELS = Object.freeze({ txt:"Mensagem", respostaRapida:"Item salvo", sticker:"Figurinha", groupInvite:"Convite para grupo", linkPreview:"Link com prévia", list:"Lista de botões", timer:"Esperar", composing:"Digitando", recording:"Gravando áudio", addCRM:"Adicionar ao CRM", removeCRM:"Remover do CRM", removeAllCRM:"Remover de todos os CRMs", arquivar:"Arquivar contato", desarquivar:"Desarquivar contato", fixarChat:"Fixar conversa", desfixarChat:"Desfixar conversa", marcarLido:"Marcar como lida", marcarNaoLido:"Marcar como não lida", bloquear:"Bloquear contato", desbloquear:"Desbloquear contato" });
  function extQrDashActionLabel(action) {
    return EXTUI_QR_DASH_ACTION_LABELS[String(action && action.type || "")] || String(action && action.type || "Ação");
  }
  function extQrDashActionSummary(action) {
    var p = action && action.properties || {}, type = String(action && action.type || "");
    if (action && action.uiLabel) return String(action.uiLabel);
    if (type === "txt") return String(p.mensagem || "").replace(/\s+/g, " ").slice(0, 1200) || "Mensagem vazia";
    if (type === "timer" || type === "composing" || type === "recording") return String(p.segundos || 0) + " s";
    if (type === "linkPreview") return String(p.link || p.url || "Link");
    if (type === "groupInvite") return String(p.groupID || p.groupId || "Grupo");
    if (type === "addCRM") return "CRM " + String(p.crmID || "") + " · etapa " + String(p.abaID || "");
    if (type === "removeCRM") return "CRM " + String(p.crmID || "");
    return "Executada para o contato selecionado";
  }
  async function extQrDashLoadNativeCatalog() {
    var defs = [
      {type:"message",key:"EXTUI:textMessageStore",field:"textMessageList",label:"Mensagem"},
      {type:"audio",key:"EXTUI:audioStore",field:"audioList",label:"Áudio"},
      {type:"media",key:"EXTUI:mediaStore",field:"mediaList",label:"Arquivo visual"},
      {type:"sticker",key:"EXTUI:stickerStore",field:"stickerList",label:"Figurinha"},
      {type:"document",key:"EXTUI:documentStore",field:"documentList",label:"Documento"},
      {type:"pix",key:"EXTUI:pixStore",field:"pixList",label:"PIX"},
      {type:"interactive-list",key:"EXTUI:interactiveListStore",field:"interactiveListList",label:"Lista interativa"},
      {type:"contact",key:"EXTUI:contactCardStore",field:"contactList",label:"Contato"}
    ], out = [], raws = await Promise.all(defs.map(function (d) { return storageGet(d.key); }));
    defs.forEach(function (d, i) {
      var raw = extHubParse(raws[i]), state = raw && raw.state || raw || {}, list = Array.isArray(state[d.field]) ? state[d.field] : [];
      list.forEach(function (item) {
        if (!item || !item.id) return;
        var catalogKind = d.type === "media" ? (item.mediaKind === "video" ? "video" : "image") : d.type;
        var displayKind = d.type === "media" ? (catalogKind === "video" ? "Vídeo" : "Imagem") : d.label;
        out.push({type:d.type,catalogKind:catalogKind,id:String(item.id),name:String(item.name || item.title || item.fileName || item.merchantName || item.contactName || item.id),kind:displayKind});
      });
    });
    return out;
  }
  async function extQrDashLoadCrmCatalog() {
    var raw = extHubParse(await storageGet("EXTUI:CrmStore")), state = raw && raw.state || raw || {}, list = Array.isArray(state.crmList) ? state.crmList : [];
    return list.map(function (crm) { return { id:String(crm.id || ""), name:String(crm.name || crm.id || "CRM"), columns:(Array.isArray(crm.columns) ? crm.columns : []).map(function (col) { return {id:String(col.id || ""),name:String(col.title || col.name || col.id || "Etapa")}; }) }; });
  }
  async function renderMessageQuickResponses(target) {
    var parsed = extHubParse(await storageGet("EXTUI:extappQuickResponseStore")), source = parsed && parsed.state || parsed || {};
    var canonicalQrTypes = new Set(["txt","respostaRapida","sticker","groupInvite","linkPreview","list","timer","composing","recording","addCRM","removeCRM","removeAllCRM","arquivar","desarquivar","fixarChat","desfixarChat","marcarLido","marcarNaoLido","bloquear","desbloquear"]);
    function canonicalQrActions(actions){return Array.isArray(actions)?actions.filter(function(action){return action&&canonicalQrTypes.has(String(action.type||""));}):[];}
    var state = { schemaVersion:Number(source.schemaVersion || 2), categories:Array.isArray(source.categories) ? source.categories.slice() : [], items:Array.isArray(source.items) ? source.items.slice().filter(Boolean).map(function(item){var next=Object.assign({},item);next.actions=canonicalQrActions(item.actions);return next;}) : [] };
    var view = "library", editId = null, query = "", categoryFilter = "all", renderSeq = 0;
    target.innerHTML = "";
    var app = el("div", { class:"extuiQrDashApp" }), tabs = el("div", { class:"extuiQrDashTabs", role:"tablist", "aria-label":"Respostas Rápidas" }), content = el("div", { class:"extuiQrDashContent" });
    app.appendChild(tabs); app.appendChild(content); target.appendChild(app);
    var tabDefs = [["library","Respostas"],["builder","Criar / Editar"],["categories","Categorias"]];
    tabDefs.forEach(function (pair) { var b = el("button", {type:"button",class:"extuiQrDashTab",text:pair[1],role:"tab"}); b.dataset.view = pair[0]; b.addEventListener("click", function () { if (view === pair[0]) return; view = pair[0]; if (view === "builder") editId = null; render(); }); tabs.appendChild(b); });
    function applyExternalRaw(raw) {
      var parsedExternal = extHubParse(raw), sourceExternal = parsedExternal && parsedExternal.state || parsedExternal || {};
      state.schemaVersion = Number(sourceExternal.schemaVersion || 2);
      state.categories = Array.isArray(sourceExternal.categories) ? sourceExternal.categories.slice() : [];
      state.items = Array.isArray(sourceExternal.items) ? sourceExternal.items.slice().filter(Boolean).map(function(item){ var next = Object.assign({}, item); next.actions = canonicalQrActions(item.actions); return next; }) : [];
    }
    async function persist() { state.schemaVersion = Math.max(2, Number(state.schemaVersion || 2)); await storageSet("EXTUI:extappQuickResponseStore", JSON.stringify(state)); }
    if (target._extuiQrDashStorageUnsubscribe) { try { target._extuiQrDashStorageUnsubscribe(); } catch (_) {} target._extuiQrDashStorageUnsubscribe = null; }
    if (target._extuiQrDashStorageListener && globalThis.chrome && chrome.storage && chrome.storage.onChanged) { try { chrome.storage.onChanged.removeListener(target._extuiQrDashStorageListener); } catch (_) {} target._extuiQrDashStorageListener = null; }
    if (target._extuiQrDashSectionCleanup) { try { document.removeEventListener("ext:dashboard-section-change", target._extuiQrDashSectionCleanup); } catch (_) {} target._extuiQrDashSectionCleanup = null; }
    function applyQuickResponseExternalChange(newValue, meta) {
      if (meta && meta.local === true) return;
      try{applyExternalRaw(newValue);}catch(err){if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_RESPONSE_EXTERNAL_STORE_CORRUPT",err);return;}
      if (target.isConnected) render().catch(function(err){ if(window.__extReportRuntimeError)window.__extReportRuntimeError("QUICK_RESPONSE_EXTERNAL_RENDER_FAILED",err); });
    }
    if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
      target._extuiQrDashStorageUnsubscribe = window.ExtensionStorage.subscribe("EXTUI:extappQuickResponseStore", function(newValue, _oldValue, _key, meta) { applyQuickResponseExternalChange(newValue, meta); });
    } else if (globalThis.chrome && chrome.storage && chrome.storage.onChanged) {
      target._extuiQrDashStorageListener = function(changes, area) {
        if (area !== "local" || !changes || !changes["EXTUI:extappQuickResponseStore"]) return;
        applyQuickResponseExternalChange(changes["EXTUI:extappQuickResponseStore"].newValue, { local:false, area:area });
      };
      chrome.storage.onChanged.addListener(target._extuiQrDashStorageListener);
    }
    function cleanupQuickResponseWatch() {
      if (target._extuiQrDashStorageUnsubscribe) { try { target._extuiQrDashStorageUnsubscribe(); } catch (_) {} target._extuiQrDashStorageUnsubscribe = null; }
      if (target._extuiQrDashStorageListener && globalThis.chrome && chrome.storage && chrome.storage.onChanged) { try { chrome.storage.onChanged.removeListener(target._extuiQrDashStorageListener); } catch (_) {} target._extuiQrDashStorageListener = null; }
      if (target._extuiQrDashSectionCleanup) { try { document.removeEventListener("ext:dashboard-section-change", target._extuiQrDashSectionCleanup); } catch (_) {} target._extuiQrDashSectionCleanup = null; }
    }
    target._extuiQrDashSectionCleanup = function(event) { if (!event.detail || event.detail.section !== "quick-responses") cleanupQuickResponseWatch(); };
    document.addEventListener("ext:dashboard-section-change", target._extuiQrDashSectionCleanup);
    function updateTabs() { Array.from(tabs.children).forEach(function (b) { var on = b.dataset.view === view; b.classList.toggle("is-active", on); b.setAttribute("aria-selected", String(on)); }); }
    function stats() { return el("div", {class:"extuiQuickResponsesStatsBar"}, [el("span",{},[el("strong",{text:String(state.items.length)}),document.createTextNode(" respostas")]),el("span",{},[el("strong",{text:String(state.categories.length)}),document.createTextNode(" categorias")]),el("span",{},[el("strong",{text:String(state.items.filter(function(x){return !!x.favorite;}).length)}),document.createTextNode(" favoritas")])]); }
    function field(label, node, help) { var wrap = el("label", {class:"extuiQrDashField"}); wrap.appendChild(el("span",{text:label})); wrap.appendChild(node); if (help) wrap.appendChild(el("small",{text:help})); return wrap; }
    function input(type, placeholder, value) { var n = el("input", {type:type || "text",placeholder:placeholder || ""}); if (value != null) n.value = value; return n; }
    function textarea(placeholder, value) { var n = el("textarea", {placeholder:placeholder || ""}); if (value != null) n.value = value; return n; }
    function categoryName(id) { var c = state.categories.find(function (x) { return String(x.id) === String(id || ""); }); return c ? c.name : "Sem categoria"; }
    function normalizeCategory(input, existing) { existing = existing || {}; var now = new Date().toISOString(); return {id:String(input.id || existing.id || extQrDashUid("qrcat")),name:String(input.name != null ? input.name : existing.name || "Categoria").trim() || "Categoria",position:Number.isFinite(Number(input.position)) ? Number(input.position) : Number(existing.position || 0),hidden:input.hidden != null ? !!input.hidden : !!existing.hidden,createdAt:existing.createdAt || now,updatedAt:now}; }
    function normalizeItem(input, existing) { existing = existing || {}; var now = new Date().toISOString(); return {id:String(input.id || existing.id || extQrDashUid("qr")),name:String(input.name != null ? input.name : existing.name || "Resposta rápida").trim() || "Resposta rápida",categoryId:input.categoryId != null ? String(input.categoryId || "") : String(existing.categoryId || ""),shortcut:input.shortcut != null ? String(input.shortcut || "") : String(existing.shortcut || ""),actions:canonicalQrActions(input.actions != null ? input.actions : existing.actions),favorite:input.favorite != null ? !!input.favorite : !!existing.favorite,createdAt:existing.createdAt || now,updatedAt:now}; }
    async function renderLibrary() {
      content.innerHTML = ""; content.appendChild(stats());
      var toolbar = el("div", {class:"extuiQrDashToolbar"}), search = input("search","Buscar por nome ou atalho...",query), create = el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"+ Nova resposta"}), manage = el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Gerenciar categorias"});
      toolbar.appendChild(search); toolbar.appendChild(manage); toolbar.appendChild(create); content.appendChild(toolbar);
      var filters = el("div", {class:"extuiQrDashFilters"});
      [["all","Todas"],["favorites","Favoritas"],["none","Sem categoria"]].concat(state.categories.filter(function(c){return !c.hidden;}).sort(function(a,b){return Number(a.position||0)-Number(b.position||0);}).map(function(c){return [String(c.id),c.name];})).forEach(function(pair){var b=el("button",{type:"button",class:"extuiQrDashFilter",text:pair[1]});b.dataset.filter=pair[0];b.classList.toggle("is-active",categoryFilter===pair[0]);b.addEventListener("click",function(){categoryFilter=pair[0];paintList();});if(pair[0]!=="all"&&pair[0]!=="favorites"){b.addEventListener("dragover",function(ev){ev.preventDefault();b.classList.add("is-drop");});b.addEventListener("dragleave",function(){b.classList.remove("is-drop");});b.addEventListener("drop",async function(ev){ev.preventDefault();b.classList.remove("is-drop");var itemId=ev.dataTransfer&&ev.dataTransfer.getData("text/ext-quick-response"),item=state.items.find(function(x){return x.id===itemId;});if(!item)return;item.categoryId=pair[0]==="none"?"":pair[0];item.updatedAt=new Date().toISOString();await persist();categoryFilter=pair[0];paintList();});}filters.appendChild(b);});
      content.appendChild(filters);
      var split = el("div", {class:"extuiQrDashSplit"}), listPane = el("section",{class:"extuiQrDashList"}), detail = el("aside",{class:"extuiQrDashDetail"}); split.appendChild(listPane); split.appendChild(detail); content.appendChild(split);
      var selectedId = null;
      function filteredItems() { var q = String(query || "").trim().toLowerCase(); return state.items.filter(function(item){if(categoryFilter==="favorites"&&!item.favorite)return false;if(categoryFilter==="none"&&item.categoryId)return false;if(categoryFilter!=="all"&&categoryFilter!=="favorites"&&categoryFilter!=="none"&&String(item.categoryId||"")!==categoryFilter)return false;return !q||String(item.name||"").toLowerCase().indexOf(q)>=0||String(item.shortcut||"").toLowerCase().indexOf(q)>=0;}).sort(function(a,b){return Number(!!b.favorite)-Number(!!a.favorite)||String(a.name||"").localeCompare(String(b.name||""));}); }
      function showDetail(item) { detail.innerHTML = ""; if (!item) { detail.appendChild(el("div",{class:"extuiQrDashEmpty"},[el("strong",{text:"Selecione uma resposta"}),el("span",{text:"Veja a sequência, edite a resposta pronta ou execute para um contato/grupo pelo WhatsApp Web."})])); return; } selectedId = item.id; var head=el("div",{class:"extuiQrDashDetailHead"},[el("span",{text:categoryName(item.categoryId)}),el("h3",{text:item.name||"Resposta rápida"}),el("p",{text:(item.shortcut?"Atalho: "+item.shortcut+" · ":"")+String((item.actions||[]).length)+" etapa(s)"})]); detail.appendChild(head); var steps=el("div",{class:"extuiQrDashSteps"}); (item.actions||[]).forEach(function(action,index){steps.appendChild(el("div",{class:"extuiQrDashStep"},[el("span",{class:"extuiQrDashStepIndex",text:String(index+1).padStart(2,"0")}),el("div",{},[el("strong",{text:extQrDashActionLabel(action)}),el("small",{text:extQrDashActionSummary(action)})]) ]));}); if(!steps.children.length)steps.appendChild(el("div",{class:"extuiQrDashEmpty",text:"Resposta sem etapas."})); detail.appendChild(steps); var acts=el("div",{class:"extuiQrDashDetailActions"}); var fav=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:item.favorite?"★ Favorita":"☆ Favoritar"}), edit=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Editar"}), send=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Executar"}), del=el("button",{type:"button",class:"extui-btn extui-btn--danger",text:"Excluir"});
        fav.addEventListener("click",async function(){item.favorite=!item.favorite;item.updatedAt=new Date().toISOString();await persist();renderLibrary();}); edit.addEventListener("click",function(){editId=item.id;view="builder";render();}); send.addEventListener("click",function(){openSendPicker("quick-response", item);}); del.addEventListener("click",async function(){var action=window.__extTrashConfirm?await window.__extTrashConfirm({title:"Excluir resposta rápida?",message:"Você pode enviar \""+item.name+"\" para a Lixeira, criar um backup ou excluir definitivamente."}):(await window.extConfirm('Excluir a resposta rápida "'+item.name+'"?',{danger:true})?"permanent":null);if(!action)return;if(action==="trash"&&window.__extTrashService)await window.__extTrashService.add({type:"quickResponse",label:item.name,payload:{item:item}});state.items=state.items.filter(function(x){return x.id!==item.id;});await persist();renderLibrary();}); [fav,edit,send,del].forEach(function(b){acts.appendChild(b);}); detail.appendChild(acts); }
      function paintList(){query=search.value;Array.from(filters.children).forEach(function(b){b.classList.toggle("is-active",b.dataset.filter===categoryFilter);});listPane.innerHTML="";var rows=filteredItems();split.classList.toggle("is-empty",!rows.length);detail.hidden=!rows.length;if(!rows.length){listPane.appendChild(el("div",{class:"extuiQrDashEmpty extuiQrDashEmpty--compact"},[el("strong",{text:"Nenhuma resposta rápida encontrada"}),el("span",{text:query?"Ajuste a busca ou o filtro.":"Crie sua primeira resposta quando precisar dela."})]));return;}rows.forEach(function(item){var row=el("button",{type:"button",class:"extuiQrDashRow"+(selectedId===item.id?" is-active":"")},[el("div",{class:"extuiQrDashRowIcon",text:"↯"}),el("div",{class:"extuiQrDashRowCopy"},[el("strong",{text:item.name||"Resposta rápida"}),el("span",{text:categoryName(item.categoryId)+" · "+String((item.actions||[]).length)+" etapa(s)"+(item.shortcut?" · "+item.shortcut:"")})]),el("span",{class:"extuiQrDashRowStar",text:item.favorite?"★":""})]);row.draggable=true;row.addEventListener("dragstart",function(ev){if(ev.dataTransfer){ev.dataTransfer.effectAllowed="move";ev.dataTransfer.setData("text/ext-quick-response",item.id);}});row.addEventListener("click",function(){selectedId=item.id;Array.from(listPane.children).forEach(function(r){r.classList.toggle("is-active",r===row);});showDetail(item);});listPane.appendChild(row);});var sel=rows.find(function(x){return x.id===selectedId;})||rows[0];showDetail(sel);}
      search.addEventListener("input",paintList); create.addEventListener("click",function(){editId=null;view="builder";render();}); manage.addEventListener("click",function(){view="categories";render();}); paintList();
    }
    async function renderCategories() {
      content.innerHTML=""; content.appendChild(stats()); var wrap=el("div",{class:"extuiQrDashCategoryPage"}), top=el("div",{class:"extuiQrDashCategoryCreate"}), name=input("text","Nova categoria..."), add=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Criar categoria"}), back=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Voltar às respostas"});top.appendChild(name);top.appendChild(add);top.appendChild(back);wrap.appendChild(top);var list=el("div",{class:"extuiQrDashCategoryList"});wrap.appendChild(list);content.appendChild(wrap);
      function paint(){list.innerHTML="";var rows=state.categories.slice().sort(function(a,b){return Number(a.position||0)-Number(b.position||0);});if(!rows.length){list.appendChild(el("div",{class:"extuiQrDashEmpty"},[el("strong",{text:"Nenhuma categoria personalizada"}),el("span",{text:"As respostas podem continuar em Sem categoria ou você pode criar grupos próprios."})]));return;}rows.forEach(function(cat){var count=state.items.filter(function(x){return String(x.categoryId||"")===String(cat.id);}).length,row=el("div",{class:"extuiQrDashCategoryRow"}),copy=el("div",{class:"extuiQrDashCategoryCopy"},[el("strong",{text:cat.name}),el("span",{text:count+" resposta(s) · "+(cat.hidden?"oculta":"visível")})]),acts=el("div",{class:"extuiQrDashCategoryActions"}),rename=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Renomear"}),hide=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:cat.hidden?"Mostrar":"Ocultar"}),del=el("button",{type:"button",class:"extui-btn extui-btn--danger",text:"Excluir"}),delAll=el("button",{type:"button",class:"extui-btn extui-btn--danger",text:"Excluir + respostas"});rename.addEventListener("click",function(){var edit=input("text","Nome",cat.name),save=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Salvar"}),cancel=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Cancelar"});row.innerHTML="";row.appendChild(field("Nome da categoria",edit));var x=el("div",{class:"extuiQrDashCategoryActions"},[cancel,save]);row.appendChild(x);cancel.addEventListener("click",paint);save.addEventListener("click",async function(){var next=edit.value.trim();if(!next){toast("Informe um nome.",true);return;}if(state.categories.some(function(c){return c.id!==cat.id&&String(c.name||"").trim().toLowerCase()===next.toLowerCase();})){toast("Já existe uma categoria com esse nome.",true);return;}Object.assign(cat,normalizeCategory({id:cat.id,name:next,hidden:cat.hidden,position:cat.position},cat));await persist();paint();});requestAnimationFrame(function(){edit.focus();edit.select();});});hide.addEventListener("click",async function(){Object.assign(cat,normalizeCategory({id:cat.id,name:cat.name,hidden:!cat.hidden,position:cat.position},cat));await persist();paint();});del.addEventListener("click",async function(){if(!await window.extConfirm('Excluir a categoria "'+cat.name+'"? As respostas serão preservadas em Sem categoria.',{danger:true}))return;state.categories=state.categories.filter(function(c){return c.id!==cat.id;});state.items=state.items.map(function(item){if(String(item.categoryId||"")!==String(cat.id))return item;var clone=Object.assign({},item,{categoryId:"",updatedAt:new Date().toISOString()});return clone;});await persist();paint();});delAll.addEventListener("click",async function(){if(!await window.extConfirm('Excluir a categoria "'+cat.name+'" e todas as '+count+' resposta(s) nela?',{danger:true}))return;state.categories=state.categories.filter(function(c){return c.id!==cat.id;});state.items=state.items.filter(function(item){return String(item.categoryId||"")!==String(cat.id);});await persist();paint();});[rename,hide,del,delAll].forEach(function(b){acts.appendChild(b);});row.appendChild(copy);row.appendChild(acts);list.appendChild(row);});}
      add.addEventListener("click",async function(){var n=name.value.trim();if(!n){toast("Informe o nome da categoria.",true);return;}if(state.categories.some(function(c){return String(c.name||"").trim().toLowerCase()===n.toLowerCase();})){toast("Já existe uma categoria com esse nome.",true);return;}state.categories.push(normalizeCategory({name:n,position:state.categories.length,hidden:false}));await persist();name.value="";paint();});name.addEventListener("keydown",function(ev){if(ev.key==="Enter"){ev.preventDefault();add.click();}});back.addEventListener("click",function(){view="library";render();});paint();
    }
    async function renderBuilder() {
      var existing=editId?state.items.find(function(x){return x.id===editId;})||null:null;
      var catalogs=await Promise.all([extQrDashLoadNativeCatalog(),extQrDashLoadCrmCatalog()]);
      if (view !== "builder") return;
      content.innerHTML="";
      var native=catalogs[0], crms=catalogs[1], draft=existing&&Array.isArray(existing.actions)?extQrDashCopy(existing.actions):[];
      var wizardStep=1, form=el("form",{class:"extuiQrDashBuilder"});content.appendChild(form);
      var head=el("div",{class:"extuiQrDashBuilderHead"},[el("div",{},[el("strong",{text:existing?"Editar resposta":"Nova resposta"}),el("span",{text:"Siga os 3 passos abaixo: identifique a resposta, monte a sequência e revise antes de salvar."})]),el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Voltar"})]);
      head.lastChild.addEventListener("click",function(){view="library";render();});form.appendChild(head);
      var wizard=el("div",{class:"extuiQrDashWizard",role:"tablist","aria-label":"Etapas de configuração"});form.appendChild(wizard);
      var wizardDefs=[[1,"Identificação","Nome, categoria e atalho"],[2,"Sequência","Conteúdo e ações"],[3,"Revisar","Conferir e salvar"]],wizardButtons=[];
      wizardDefs.forEach(function(def){var b=el("button",{type:"button",class:"extuiQrDashWizardStep"},[el("span",{class:"extuiQrDashWizardNumber",text:String(def[0])}),el("span",{class:"extuiQrDashWizardCopy"},[el("strong",{text:def[1]}),el("small",{text:def[2]})])]);b.dataset.step=String(def[0]);b.addEventListener("click",function(){goWizard(def[0]);});wizardButtons.push(b);wizard.appendChild(b);});
      var name=input("text","Ex.: Boas-vindas + CRM",existing&&existing.name||""),category=el("select",{}),shortcut=input("text","Ex.: /boasvindas",existing&&existing.shortcut||"");
      category.appendChild(new Option("Sem categoria",""));state.categories.slice().sort(function(a,b){return Number(a.position||0)-Number(b.position||0);}).forEach(function(c){category.appendChild(new Option(c.name+(c.hidden?" (oculta)":""),c.id));});category.value=existing&&existing.categoryId||"";
      var phaseMeta=el("section",{class:"extuiQrDashWizardPanel"}),metaTitle=el("div",{class:"extuiQrDashWizardPanelHead"},[el("span",{class:"extuiQrDashWizardKicker",text:"PASSO 1 DE 3"}),el("strong",{text:"Identifique esta resposta"}),el("p",{text:"Dê um nome claro. Categoria e atalho são opcionais, mas ajudam a encontrar a resposta durante o atendimento."})]),meta=el("div",{class:"extuiQrDashMetaGrid"});
      meta.appendChild(field("Nome da resposta",name,"Obrigatório. Use algo que descreva quando esta resposta deve ser usada."));meta.appendChild(field("Categoria",category,"Agrupa respostas semelhantes."));meta.appendChild(field("Atalho",shortcut,"Opcional. Ex.: /boasvindas."));phaseMeta.appendChild(metaTitle);phaseMeta.appendChild(meta);
      var metaActions=el("div",{class:"extuiQrDashWizardActions"}),cancelAll=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Cancelar"}),nextSequence=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Continuar: montar sequência →"});cancelAll.addEventListener("click",function(){view="library";render();});nextSequence.addEventListener("click",function(){goWizard(2);});metaActions.appendChild(cancelAll);metaActions.appendChild(nextSequence);phaseMeta.appendChild(metaActions);form.appendChild(phaseMeta);
      var phaseSequence=el("section",{class:"extuiQrDashWizardPanel"}),sequenceHead=el("div",{class:"extuiQrDashWizardPanelHead"},[el("span",{class:"extuiQrDashWizardKicker",text:"PASSO 2 DE 3"}),el("strong",{text:"Monte a sequência de execução"}),el("p",{text:"Cada etapa é executada de cima para baixo. Você pode combinar mensagens, itens da Biblioteca, CRM, esperas e ações de gestão."})]);phaseSequence.appendChild(sequenceHead);
      var stepArea=el("section",{class:"extuiQrDashStepArea"});phaseSequence.appendChild(stepArea);
      var composer=el("section",{class:"extuiQrDashComposer"}),composerVisible=draft.length===0,guide=el("div",{class:"extuiQrDashComposerGuide"},[el("strong",{text:"Adicionar uma etapa"}),el("span",{text:"1. Escolha um grupo  →  2. Escolha o tipo de ação  →  3. Preencha os campos  →  4. Clique em Adicionar etapa"})]);composer.appendChild(guide);
      var groups=[{id:"message",label:"Mensagem",actions:[["txt","Nova mensagem de texto"],["saved","Item da biblioteca (mensagem, áudio, imagem, vídeo...)"],["groupInvite","Convite para grupo"],["linkPreview","Link com prévia"],["list","Lista de botões"]]},{id:"crm",label:"CRM",actions:[["addCRM","Adicionar a um CRM"],["removeCRM","Remover de um CRM"],["removeAllCRM","Remover de todos os CRMs"]]},{id:"timers",label:"Temporizadores",actions:[["timer","Esperar em segundos"],["composing","Exibir que está digitando"],["recording","Exibir que está gravando áudio"]]},{id:"management",label:"Gestão",actions:[["arquivar","Arquivar contato"],["desarquivar","Desarquivar contato"],["fixarChat","Fixar conversa"],["desfixarChat","Desfixar conversa"],["marcarLido","Marcar como lida"],["marcarNaoLido","Marcar como não lida"],["bloquear","Bloquear contato"],["desbloquear","Desbloquear contato"]]}],activeGroup="message",type=el("select",{}),groupRow=el("div",{class:"extuiQrDashActionGroups"}),config=el("div",{class:"extuiQrDashComposerConfig"}),composerActions=el("div",{class:"extuiQrDashComposerActions"}),cancel=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Fechar editor"}),add=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Adicionar etapa"}),controls={};
      composer.appendChild(el("div",{class:"extuiQrDashComposerLabel",text:"1 · Grupo da ação"}));composer.appendChild(groupRow);composer.appendChild(el("div",{class:"extuiQrDashComposerLabel",text:"2 · Tipo de ação"}));composer.appendChild(type);composer.appendChild(el("div",{class:"extuiQrDashComposerLabel",text:"3 · Configuração"}));composer.appendChild(config);composerActions.appendChild(cancel);composerActions.appendChild(add);composer.appendChild(composerActions);phaseSequence.appendChild(composer);
      var seqActions=el("div",{class:"extuiQrDashWizardActions"}),backMeta=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"← Voltar à identificação"}),nextReview=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Revisar resposta →"});backMeta.addEventListener("click",function(){goWizard(1,true);});nextReview.addEventListener("click",function(){goWizard(3);});seqActions.appendChild(backMeta);seqActions.appendChild(nextReview);phaseSequence.appendChild(seqActions);form.appendChild(phaseSequence);
      var phaseReview=el("section",{class:"extuiQrDashWizardPanel"}),reviewHead=el("div",{class:"extuiQrDashWizardPanelHead"},[el("span",{class:"extuiQrDashWizardKicker",text:"PASSO 3 DE 3"}),el("strong",{text:"Revise antes de salvar"}),el("p",{text:"Confira a identificação e a ordem das ações. Depois de salvar, a resposta ficará disponível no Painel de Controle e no painel do WhatsApp."})]),reviewBody=el("div",{class:"extuiQrDashReview"});phaseReview.appendChild(reviewHead);phaseReview.appendChild(reviewBody);
      var reviewActions=el("div",{class:"extuiQrDashWizardActions"}),backSequence=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"← Ajustar sequência"}),save=el("button",{type:"submit",class:"extui-btn extui-btn--primary",text:existing?"Salvar alterações":"Salvar resposta"});backSequence.addEventListener("click",function(){goWizard(2,true);});reviewActions.appendChild(backSequence);if(existing){var del=el("button",{type:"button",class:"extui-btn extui-btn--danger",text:"Excluir resposta"});del.addEventListener("click",async function(){var action=window.__extTrashConfirm?await window.__extTrashConfirm({title:"Excluir resposta rápida?",message:"Você pode enviar \""+existing.name+"\" para a Lixeira, criar um backup ou excluir definitivamente."}):(await window.extConfirm('Excluir a resposta rápida "'+existing.name+'"?',{danger:true})?"permanent":null);if(!action)return;if(action==="trash"&&window.__extTrashService)await window.__extTrashService.add({type:"quickResponse",label:existing.name,payload:{item:existing}});state.items=state.items.filter(function(x){return x.id!==existing.id;});await persist();editId=null;view="library";render();});reviewActions.appendChild(del);}reviewActions.appendChild(save);phaseReview.appendChild(reviewActions);form.appendChild(phaseReview);
      function validateMeta(){if(!name.value.trim()){toast("Informe um nome para continuar.",true);name.focus();return false;}return true;}
      function paintWizard(){wizardButtons.forEach(function(b){var n=Number(b.dataset.step),active=n===wizardStep,complete=n<wizardStep;b.classList.toggle("is-active",active);b.classList.toggle("is-complete",complete);b.setAttribute("aria-selected",String(active));});phaseMeta.hidden=wizardStep!==1;phaseSequence.hidden=wizardStep!==2;phaseReview.hidden=wizardStep!==3;}
      function goWizard(step,force){step=Math.max(1,Math.min(3,Number(step)||1));if(!force&&step>=2&&!validateMeta())return;if(!force&&step===3&&!draft.length){toast("Adicione pelo menos uma etapa antes de revisar.",true);return;}wizardStep=step;if(step===3)paintReview();paintWizard();requestAnimationFrame(function(){var panel=step===1?phaseMeta:step===2?phaseSequence:phaseReview;panel.scrollIntoView({block:"start",behavior:"smooth"});});}
      function paintSteps(){stepArea.innerHTML="";stepArea.appendChild(el("div",{class:"extuiQrDashSectionTitle"},[el("div",{},[el("strong",{text:"Sequência atual"}),el("span",{text:"Arraste não é necessário: use as setas para reorganizar."})]),el("span",{class:"extuiQrDashStepCount",text:String(draft.length)+" etapa(s)"})]));if(!draft.length){stepArea.appendChild(el("div",{class:"extuiQrDashEmpty extuiQrDashEmpty--guided"},[el("strong",{text:"Comece pela primeira etapa"}),el("span",{text:"Uma resposta pode ter uma única mensagem ou uma sequência completa. Use o editor abaixo para adicionar a primeira ação."})]));}else{var rows=el("div",{class:"extuiQrDashStepRows"});draft.forEach(function(action,index){var row=el("div",{class:"extuiQrDashActionRow"},[el("span",{class:"extuiQrDashStepIndex",text:String(index+1)}),el("div",{class:"extuiQrDashActionCopy"},[el("strong",{text:extQrDashActionLabel(action)}),el("span",{text:extQrDashActionSummary(action)})])]),buttons=el("div",{class:"extuiQrDashActionControls"}),up=el("button",{type:"button",class:"extuiQrDashIconBtn",text:"↑",title:"Mover para cima"}),down=el("button",{type:"button",class:"extuiQrDashIconBtn",text:"↓",title:"Mover para baixo"}),remove=el("button",{type:"button",class:"extuiQrDashIconBtn is-danger",text:"×",title:"Remover etapa"});up.disabled=index===0;down.disabled=index===draft.length-1;up.addEventListener("click",function(){var tmp=draft[index-1];draft[index-1]=draft[index];draft[index]=tmp;paintSteps();});down.addEventListener("click",function(){var tmp=draft[index+1];draft[index+1]=draft[index];draft[index]=tmp;paintSteps();});remove.addEventListener("click",function(){draft.splice(index,1);paintSteps();if(!draft.length){composerVisible=true;composer.hidden=false;}});[up,down,remove].forEach(function(b){buttons.appendChild(b);});row.appendChild(buttons);rows.appendChild(row);});stepArea.appendChild(rows);}var addStep=el("button",{type:"button",class:"extui-btn extui-btn--ghost extuiQrDashAddStep",text:"+ Adicionar outra etapa"});addStep.addEventListener("click",function(){composerVisible=true;composer.hidden=false;composer.classList.add("is-open");requestAnimationFrame(function(){composer.scrollIntoView({block:"nearest",behavior:"smooth"});});});stepArea.appendChild(addStep);}
      function paintGroups(){groupRow.innerHTML="";groups.forEach(function(g){var b=el("button",{type:"button",class:"extuiQrDashActionGroup"+(g.id===activeGroup?" is-active":""),text:g.label});b.setAttribute("aria-pressed",String(g.id===activeGroup));b.addEventListener("click",function(){activeGroup=g.id;selectGroup();});groupRow.appendChild(b);});}
      function selectGroup(){var g=groups.find(function(x){return x.id===activeGroup;})||groups[0];type.innerHTML="";g.actions.forEach(function(p){type.appendChild(new Option(p[1],p[0]));});paintGroups();paintConfig();}
      function addField(key,label,node,help){controls[key]=node;config.appendChild(field(label,node,help));}
      function paintConfig(){controls={};config.innerHTML="";var t=type.value;if(t==="txt"){addField("text","Mensagem",textarea("Digite a mensagem. Você pode usar variáveis como #nome, #primeiroNome, #numero e #email."));return;}if(t==="saved"){var kind=el("select",{}),sel=el("select",{}),kinds=[["message","Mensagens"],["audio","Áudios"],["image","Imagens"],["video","Vídeos"],["sticker","Figurinhas"],["document","Documentos"],["pix","PIX"],["interactive-list","Listas interativas"],["contact","Contatos"]];kinds.forEach(function(k){kind.appendChild(new Option(k[1],k[0]));});function populate(){sel.innerHTML="";var rows=native.filter(function(x){return (x.catalogKind||x.type)===kind.value;});if(!rows.length)sel.appendChild(new Option("Nenhum item salvo",""));rows.forEach(function(x){sel.appendChild(new Option(x.name,x.type+"|"+x.id));});}kind.addEventListener("change",populate);populate();addField("savedKind","Tipo de item",kind);addField("saved","Item salvo",sel);return;}if(t==="sticker"){var ss=el("select",{}),rows=native.filter(function(x){return x.type==="sticker"||x.type==="media";});if(!rows.length)ss.appendChild(new Option("Nenhuma figurinha, imagem ou vídeo salvo",""));rows.forEach(function(x){ss.appendChild(new Option(x.name,x.type+"|"+x.id));});addField("saved","Figurinha, imagem ou vídeo",ss);return;}if(t==="groupInvite"){addField("groupId","ID do grupo",input("text","5511999999999-0000000000@g.us"));return;}if(t==="linkPreview"){addField("url","Link",input("url","https://..."));addField("title","Título",input("text","Título da prévia"));addField("description","Descrição",textarea("Descrição opcional"));return;}if(t==="list"){addField("title","Título",input("text","Escolha uma opção"));addField("description","Descrição",textarea("Mensagem da lista"));addField("buttonText","Texto do botão",input("text","Ver opções"));addField("sections","Seções (JSON)",textarea('[{"title":"Opções","rows":[{"rowId":"1","title":"Opção 1","description":""}]}]'));return;}if(t==="timer"||t==="composing"||t==="recording"){var secs=input("number","",t==="timer"?"5":"4");secs.min="0";secs.step="1";addField("seconds",t==="timer"?"Esperar por (segundos)":(t==="composing"?"Mostrar digitando por":"Mostrar gravando por"),secs);return;}if(t==="addCRM"||t==="removeCRM"){var crm=el("select",{}),col=el("select",{});if(!crms.length)crm.appendChild(new Option("Nenhum CRM disponível",""));crms.forEach(function(c){crm.appendChild(new Option(c.name,c.id));});function cols(){col.innerHTML="";var c=crms.find(function(x){return x.id===crm.value;});(c&&c.columns||[]).forEach(function(x){col.appendChild(new Option(x.name,x.id));});if(!col.options.length)col.appendChild(new Option("Nenhuma etapa",""));}crm.addEventListener("change",cols);addField("crm","CRM",crm);if(t==="addCRM"){cols();addField("column","Etapa",col);}return;}config.appendChild(el("div",{class:"extuiQrDashNoConfig",text:"Esta ação não precisa de parâmetros. Clique em Adicionar etapa para incluí-la na sequência."}));}
      type.addEventListener("change",paintConfig);cancel.addEventListener("click",function(){composerVisible=false;composer.hidden=true;composer.classList.remove("is-open");});add.addEventListener("click",function(){try{var t=type.value,a={id:extQrDashUid("step"),type:t,properties:{}};if(t==="txt"){var msg=controls.text.value.trim();if(!msg)throw new Error("Digite a mensagem.");a.properties={mensagem:msg,aguarde:0,composing:0};}else if(t==="saved"){var parts=String(controls.saved.value||"").split("|");if(parts.length<2||!parts[1])throw new Error("Selecione um item salvo.");var id=parts.slice(1).join("|"),it=native.find(function(x){return x.type===parts[0]&&x.id===id;});a.type="respostaRapida";a.properties={respostaRapidaID:"extapp-item:"+parts[0]+":"+id};a.uiLabel=it?(it.kind+" · "+it.name):"Item salvo";}else if(t==="sticker"){var sp=String(controls.saved.value||"").split("|");if(sp.length<2||!sp[1])throw new Error("Selecione uma figurinha ou mídia.");var sid=sp.slice(1).join("|"),sit=native.find(function(x){return x.type===sp[0]&&x.id===sid;});a.properties={mediaId:sid};a.uiLabel=sit?"Figurinha · "+sit.name:"Figurinha";}else if(t==="groupInvite"){if(!controls.groupId.value.trim())throw new Error("Informe o ID do grupo.");a.properties={groupID:controls.groupId.value.trim()};}else if(t==="linkPreview"){if(!controls.url.value.trim())throw new Error("Informe o link.");a.properties={link:controls.url.value.trim(),title:controls.title.value.trim(),description:controls.description.value.trim()};}else if(t==="list"){var sections;try{sections=JSON.parse(controls.sections.value||"[]");}catch(_){throw new Error("O JSON das seções é inválido.");}a.properties={title:controls.title.value.trim(),description:controls.description.value.trim(),buttonText:controls.buttonText.value.trim(),sections:Array.isArray(sections)?sections:[]};}else if(t==="timer"||t==="composing"||t==="recording"){a.properties={segundos:Math.max(0,Number(controls.seconds.value)||0)};}else if(t==="addCRM"){if(!controls.crm.value||!controls.column.value)throw new Error("Selecione CRM e etapa.");a.properties={crmID:controls.crm.value,abaID:controls.column.value};}else if(t==="removeCRM"){if(!controls.crm.value)throw new Error("Selecione o CRM.");a.properties={crmID:controls.crm.value};}else if(t==="removeAllCRM"){a.properties={};}draft.push(a);composerVisible=false;composer.hidden=true;composer.classList.remove("is-open");paintSteps();stepArea.classList.add("is-updated");setTimeout(function(){stepArea.classList.remove("is-updated");},650);toast("Etapa adicionada à sequência.");}catch(err){toast(err.message||"Não foi possível adicionar a etapa.",true);}});
      function paintReview(){reviewBody.innerHTML="";var summary=el("div",{class:"extuiQrDashReviewMeta"},[el("div",{},[el("small",{text:"Nome"}),el("strong",{text:name.value.trim()||"—"})]),el("div",{},[el("small",{text:"Categoria"}),el("strong",{text:categoryName(category.value)})]),el("div",{},[el("small",{text:"Atalho"}),el("strong",{text:shortcut.value.trim()||"Sem atalho"})])]);reviewBody.appendChild(summary);var ordered=el("div",{class:"extuiQrDashReviewSteps"});draft.forEach(function(action,index){ordered.appendChild(el("div",{class:"extuiQrDashReviewStep"},[el("span",{text:String(index+1)}),el("div",{},[el("strong",{text:extQrDashActionLabel(action)}),el("small",{text:extQrDashActionSummary(action)})]) ]));});reviewBody.appendChild(ordered);}
      selectGroup();composer.hidden=!composerVisible;paintSteps();paintWizard();
      form.addEventListener("submit",async function(ev){ev.preventDefault();if(!validateMeta())return;if(!draft.length){toast("Adicione pelo menos uma etapa.",true);goWizard(2,true);return;}save.disabled=true;save.textContent="Salvando...";try{var idx=existing?state.items.findIndex(function(x){return x.id===existing.id;}):-1,next=normalizeItem({id:existing&&existing.id||undefined,name:name.value.trim(),categoryId:category.value,shortcut:shortcut.value.trim(),actions:draft,favorite:existing&&existing.favorite||false},existing);if(idx>=0)state.items[idx]=next;else state.items.push(next);await persist();toast("Resposta rápida salva.");editId=null;view="library";render();}catch(err){save.disabled=false;save.textContent=existing?"Salvar alterações":"Salvar resposta";toast(err&&err.message||"Não foi possível salvar a resposta.",true);}});
    }
    async function render() { var seq=++renderSeq; updateTabs(); content.setAttribute("aria-busy","true"); var busyTimer=setTimeout(function(){if(seq===renderSeq)content.classList.add("is-loading");},450); try { if(view==="builder") await renderBuilder(); else if(view==="categories") await renderCategories(); else await renderLibrary(); } catch(err) { if(seq!==renderSeq)return; content.innerHTML=""; content.appendChild(el("div",{class:"extuiQrDashEmpty"},[el("strong",{text:"Respostas Rápidas indisponíveis"}),el("span",{text:err&&err.message||"Abra outra área e tente novamente."})])); } finally { clearTimeout(busyTimer); if(seq===renderSeq){content.classList.remove("is-loading");content.removeAttribute("aria-busy");} } }
    await render();
  }
  async function renderQuickResponsesSection(container) {
    container.innerHTML = "";
    var page = el("div", { class: "extuiQuickResponsesDashboard" });
    var body = el("div", { class: "extuiQuickResponsesBody" });
    page.appendChild(body); container.appendChild(page);
    await renderMessageQuickResponses(body);
    return true;
  }
  function renderCategorySection(kind, container) {
    return renderCategoryLibrary(kind, container, false);
  }
  window.__extLibraryFastSwitch = async function (sectionName) {
    var sectionToKind = {
      "itens-message": "message", "itens-audio": "audio", "itens-image": "image", "itens-video": "video", "itens-media": "image", "itens-sticker": "sticker",
      "itens-document": "document", "itens-pix": "pix", "itens-interactive-list": "interactive-list", "itens-contact": "contact", "itens-signature": "signature"
    };
    var kind = sectionToKind[String(sectionName || "")];
    if (!kind || !pageRootEl || !pageRootEl.isConnected || !pageRootEl.parentNode) return false;
    var host = pageRootEl.parentNode;
    await renderCategoryLibrary(kind, host, false, true);
    return true;
  };
  window.__extDashboardShell.registerSection("quick-responses", renderQuickResponsesSection);

  function openItemForm(kind, existingItem) {
    if (kind === "message") return openMessageForm(existingItem);
    if (kind === "media") return openMediaForm(existingItem, "image");
    if (kind === "image" || kind === "video") return openMediaForm(existingItem, kind);
    if (kind === "sticker") return openStickerForm(existingItem);
    if (kind === "document") return openDocumentForm(existingItem);
    if (kind === "audio") return openAudioForm(existingItem);
    if (kind === "pix") return openPixForm(existingItem);
    if (kind === "interactive-list") return openInteractiveListForm(existingItem);
    if (kind === "contact") return openContactForm(existingItem);
    if (kind === "signature") return openSignatureForm(existingItem);
    toast("Tipo não suportado.", true);
  }

  function openSignatureForm(existingItem) {
    openModal({ protectUnsaved: true, title: existingItem ? "Editar assinatura" : "Nova assinatura", className: "extuiAssetComposerModal extuiAssetComposerModal--signature", render: async function(body, close, confirmBtn) {
      var titleInput=el("input",{type:"text",maxlength:"120",placeholder:"Ex.: Comercial"}),textInput=el("textarea",{rows:"6",maxlength:"5000",placeholder:"Texto da assinatura"}),quickCheckbox=el("input",{type:"checkbox",class:"extuiItensCheckbox"});
      titleInput.value=existingItem?extItemDisplayName(existingItem):"";textInput.value=existingItem&&existingItem.text||"";quickCheckbox.checked=existingItem?existingItem.showInQuickMenu!==false:true;
      body.appendChild(el("label",{text:"Título"}));body.appendChild(titleInput);body.appendChild(el("label",{text:"Assinatura"}));body.appendChild(textInput);
      body.appendChild(el("label",{class:"extuiItensCheckRow"},[quickCheckbox,el("span",{class:"extuiItensCheckTitle",text:"Mostrar no Menu Rápido"}),el("small",{class:"extuiConfigStudioOptionHint",text:"Ao ativar, esta assinatura fica disponível em Itens Rápidos do Menu Rápido."})]));
      var signatureStudio=extConfigStudioDecorate(body,{kind:"signature",icon:"signature",title:"Prévia",description:"Veja como a assinatura ficará na conversa."});
      function paintSignaturePreview(){extConfigStudioPreview(signatureStudio,titleInput.value.trim()||"Assinatura",[textInput.value.trim()||"Texto da assinatura"]);}
      titleInput.addEventListener("input",paintSignaturePreview);textInput.addEventListener("input",paintSignaturePreview);paintSignaturePreview();
      confirmBtn.addEventListener("click",async function(){var title=titleInput.value.trim(),text=textInput.value.trim();if(!title){toast("Digite um título.",true);return;}if(!text){toast("Digite a assinatura.",true);return;}confirmBtn.disabled=true;try{var saved=await window.ExtensionSignatureStore.save({id:existingItem&&existingItem.id,title:title,text:text,favorite:!!(existingItem&&existingItem.favorite),showInQuickMenu:quickCheckbox.checked});selectedItemId=saved.id;close();toast("Assinatura salva.");if(splitListEl)await renderGrid(splitListEl);}catch(err){toast(err&&err.message||"Não foi possível salvar a assinatura.",true);}finally{confirmBtn.disabled=false;}});
    }});
  }

  var PIX_KEY_TYPES = [
    ["CPF", "CPF"], ["CNPJ", "CNPJ"], ["PHONE", "Telefone"], ["EMAIL", "E-mail"], ["EVP", "Chave aleatória"]
  ];
  function openPixForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar PIX" : "Novo PIX",
      className: "extuiAssetComposerModal extuiAssetComposerModal--pix",
      render: async function (body, close, confirmBtn) {
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", value: existingItem ? existingItem.name : "" });
        body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Tipo de chave" }));
        var keyTypeSelect = el("select", {});
        PIX_KEY_TYPES.forEach(function (t) {
          var opt = el("option", { value: t[0], text: t[1] });
          if (existingContent && existingContent.keyType === t[0]) opt.setAttribute("selected", "selected");
          keyTypeSelect.appendChild(opt);
        });
        body.appendChild(keyTypeSelect);
        body.appendChild(el("label", { text: "Chave PIX" }));
        var keyInput = el("input", { type: "text" }); keyInput.value = (existingContent && existingContent.key) || "";
        body.appendChild(keyInput);
        body.appendChild(el("label", { text: "Nome do beneficiário (opcional)" }));
        var merchantInput = el("input", { type: "text" }); merchantInput.value = (existingContent && existingContent.merchantName) || "";
        body.appendChild(merchantInput);
        body.appendChild(el("div", { class: "extuifPropNote", text: "Envia um cartão de chave PIX nativo do WhatsApp, igual ao botão de PIX dentro de uma conversa." }));
        var pixStudio = extConfigStudioDecorate(body, { kind: "pix", icon: "pix", title: "Prévia", description: "Veja como o PIX ficará na conversa." });
        function paintPixPreview() { extConfigStudioPreview(pixStudio, merchantInput.value.trim() || nameInput.value.trim() || "Pagamento PIX", [keyTypeSelect.options[keyTypeSelect.selectedIndex] ? keyTypeSelect.options[keyTypeSelect.selectedIndex].text : "PIX", keyInput.value.trim() || "Chave ainda não informada"]); }
        [nameInput, keyInput, merchantInput].forEach(function (input) { input.addEventListener("input", paintPixPreview); });
        keyTypeSelect.addEventListener("change", paintPixPreview); paintPixPreview();
        confirmBtn.addEventListener("click", async function () {
          var name = nameInput.value.trim();
          if (!name) { toast("Digite um nome.", true); return; }
          var key = keyInput.value.trim();
          if (!key) { toast("Digite a chave PIX.", true); return; }
          var id = existingItem ? existingItem.id : uid();
          await commitItem("pix", id, name, { keyType: keyTypeSelect.value, key: key, merchantName: merchantInput.value.trim() }, confirmBtn, close);
        });
      }
    });
  }


  function buildInteractiveListPreview(value, options) {
    options = options && typeof options === "object" ? options : {};
    var api = window.__extInteractiveList;
    var listValue = api ? api.normalize(value || {}) : (value || {});
    var root = el("div", { class: "extuiInteractiveListPreviewBlock" + (options.className ? " " + options.className : "") });
    var visual = el("div", { class: "extuiInteractiveListPreviewVisual" });
    var stage = el("div", { class: "extuiInteractiveListPreview" });
    var bubble = el("div", { class: "extuiInteractiveListBubble" });
    if (listValue.title) bubble.appendChild(el("strong", { class: "extuiInteractiveListBubbleTitle", text: listValue.title }));
    bubble.appendChild(el("div", { class: "extuiInteractiveListBubbleBody", text: listValue.description || options.emptyDescription || "Sua mensagem aparecerá aqui." }));
    if (listValue.footer) bubble.appendChild(el("small", { class: "extuiInteractiveListBubbleFooter", text: listValue.footer }));
    bubble.appendChild(el("div", { class: "extuiInteractiveListBubbleButton" }, [icon("interactiveList"), el("span", { text: listValue.buttonText || "Ver opções" })]));
    stage.appendChild(bubble);
    visual.appendChild(stage);

    var sheet = el("div", { class: "extuiInteractiveListPreviewSheet", "aria-label": "Prévia da lista aberta" });
    sheet.appendChild(el("div", { class: "extuiInteractiveListPreviewSheetHead" }, [
      el("div", {}, [
        el("strong", { text: listValue.buttonText || "Ver opções" }),
        el("span", { text: "Escolha uma opção" })
      ]),
      icon("interactiveList")
    ]));
    var sheetBody = el("div", { class: "extuiInteractiveListPreviewSheetBody" });
    var sections = Array.isArray(listValue.sections) ? listValue.sections : [];
    sections.forEach(function (section, sectionIndex) {
      var sectionNode = el("section", { class: "extuiInteractiveListPreviewSection" });
      sectionNode.appendChild(el("strong", { class: "extuiInteractiveListPreviewSectionTitle", text: section && section.title ? section.title : "Opções" }));
      var rows = section && Array.isArray(section.rows) ? section.rows : [];
      rows.forEach(function (row, rowIndex) {
        var title = row && String(row.title || "").trim();
        var description = row && String(row.description || "").trim();
        var copy = el("div", { class: "extuiInteractiveListPreviewRowCopy" }, [
          el("strong", { text: title || ("Opção " + (rowIndex + 1)) }),
          description ? el("small", { text: description }) : null
        ]);
        sectionNode.appendChild(el("div", { class: "extuiInteractiveListPreviewRow" }, [
          el("span", { class: "extuiInteractiveListPreviewRowIndex", text: String(rowIndex + 1) }),
          copy,
          el("span", { class: "extuiInteractiveListPreviewRowArrow", text: "›", "aria-hidden": "true" })
        ]));
      });
      if (!rows.length) sectionNode.appendChild(el("div", { class: "extuiInteractiveListPreviewEmpty", text: "Adicione uma opção para visualizar esta seção." }));
      sheetBody.appendChild(sectionNode);
    });
    if (!sections.length) sheetBody.appendChild(el("div", { class: "extuiInteractiveListPreviewEmpty", text: "As opções da lista aparecerão aqui." }));
    sheet.appendChild(sheetBody);
    visual.appendChild(sheet);
    root.appendChild(visual);

    if (options.showInfo !== false) {
      var total = api ? api.countRows(listValue) : sections.reduce(function (count, section) { return count + (section && Array.isArray(section.rows) ? section.rows.length : 0); }, 0);
      var sectionCount = sections.length;
      var info = el("div", { class: "extuiInteractiveListPreviewInfo" });
      info.appendChild(el("strong", { text: total + (total === 1 ? " opção" : " opções") + " · " + sectionCount + (sectionCount === 1 ? " seção" : " seções") }));
      info.appendChild(el("span", { text: options.infoText || "A prévia mostra a mensagem e a lista aberta que o destinatário verá ao tocar no botão." }));
      root.appendChild(info);
    }
    return root;
  }

  function openInteractiveListForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar lista interativa" : "Nova lista interativa",
      className: "extuiInteractiveListComposerModal",
      confirmLabel: "Salvar lista",
      render: async function (body, close, confirmBtn) {
        var api = window.__extInteractiveList;
        if (!api) {
          toast("O editor de listas interativas não foi carregado.", true);
          confirmBtn.disabled = true;
          return;
        }
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        var draft = api.normalize(existingContent || {
          title: "",
          description: "",
          footer: "",
          buttonText: "Ver opções",
          sections: [{ title: "Opções", rows: [{ title: "", description: "" }] }]
        });
        if (!draft.sections.length) draft.sections = [api.newSection({ title: "Opções", rows: [api.newRow({})] })];
        draft.sections.forEach(function (section) { if (!section.rows.length) section.rows.push(api.newRow({})); });

        body.classList.add("extuiInteractiveListComposerBody");
        var composer = el("div", { class: "extuiInteractiveListComposer" });
        var main = el("div", { class: "extuiInteractiveListMain" });
        var aside = el("aside", { class: "extuiInteractiveListAside" });
        var basics = el("section", { class: "extuiInteractiveListCard" });
        basics.appendChild(el("div", { class: "extuiInteractiveListSectionHead" }, [
          el("div", {}, [el("strong", { text: "Mensagem" }), el("small", { text: "O botão abre a lista nativa de escolhas no WhatsApp." })])
        ]));

        function field(label, control, hint) {
          var wrap = el("label", { class: "extuiInteractiveListField" });
          wrap.appendChild(el("span", { text: label }));
          wrap.appendChild(control);
          if (hint) wrap.appendChild(el("small", { text: hint }));
          return wrap;
        }
        var nameInput = el("input", { type: "text", maxlength: "80", placeholder: "Ex.: Cardápio do almoço", value: existingItem ? existingItem.name : "" });
        var titleInput = el("input", { type: "text", maxlength: String(api.limits.title), placeholder: "Opcional", value: draft.title });
        var descriptionInput = el("textarea", { maxlength: String(api.limits.description), rows: "4", placeholder: "Ex.: Escolha uma das opções abaixo." });
        descriptionInput.value = draft.description;
        var buttonInput = el("input", { type: "text", maxlength: String(api.limits.buttonText), placeholder: "Ver opções", value: draft.buttonText || "Ver opções" });
        var footerInput = el("input", { type: "text", maxlength: String(api.limits.footer), placeholder: "Opcional", value: draft.footer });
        basics.appendChild(field("Nome interno", nameInput, "Só aparece para você na Biblioteca."));
        basics.appendChild(field("Título da mensagem", titleInput, "Opcional · até " + api.limits.title + " caracteres."));
        basics.appendChild(field("Mensagem", descriptionInput, "Obrigatória · até " + api.limits.description + " caracteres."));
        basics.appendChild(field("Texto do botão", buttonInput, "Obrigatório · até " + api.limits.buttonText + " caracteres."));
        basics.appendChild(field("Rodapé", footerInput, "Opcional · até " + api.limits.footer + " caracteres."));
        main.appendChild(basics);

        var builderCard = el("section", { class: "extuiInteractiveListCard extuiInteractiveListBuilderCard" });
        var builderTitle = el("div", { class: "extuiInteractiveListSectionHead" });
        var builderCopy = el("div", {}, [el("strong", { text: "Opções da lista" }), el("small", { text: "Organize até 10 opções em uma ou mais seções." })]);
        var rowCount = el("span", { class: "extuiInteractiveListCounter" });
        builderTitle.appendChild(builderCopy);
        builderTitle.appendChild(rowCount);
        var sectionList = el("div", { class: "extuiInteractiveListSections" });
        var addSectionBtn = el("button", { type: "button", class: "extui-btn extui-btn--secondary extuiInteractiveListAddSection" }, [icon("plus"), el("span", { text: "Adicionar seção" })]);
        builderCard.appendChild(builderTitle);
        builderCard.appendChild(sectionList);
        builderCard.appendChild(addSectionBtn);
        main.appendChild(builderCard);

        var previewHead = el("div", { class: "extuiInteractiveListAsideHead" }, [
          el("div", { class: "extuiInteractiveListAsideIcon" }, [icon("interactiveList")]),
          el("div", {}, [el("strong", { text: "Prévia" }), el("small", { text: "Visual aproximado da mensagem no WhatsApp." })])
        ]);
        var preview = el("div", { class: "extuiInteractiveListPreviewMount" });
        aside.appendChild(previewHead);
        aside.appendChild(preview);
        composer.appendChild(main);
        composer.appendChild(aside);
        body.appendChild(composer);

        function syncDraftFromBasics() {
          draft.title = titleInput.value.trim();
          draft.description = descriptionInput.value.trim();
          draft.buttonText = buttonInput.value.trim();
          draft.footer = footerInput.value.trim();
        }
        function move(array, from, to) {
          if (to < 0 || to >= array.length || from === to) return;
          var item = array.splice(from, 1)[0];
          array.splice(to, 0, item);
        }
        function paintPreview() {
          syncDraftFromBasics();
          preview.innerHTML = "";
          preview.appendChild(buildInteractiveListPreview(draft, { emptyDescription: "Sua mensagem aparecerá aqui." }));
          var total = api.countRows(draft);
          rowCount.textContent = total + "/" + api.limits.maxRows + " opções";
          rowCount.classList.toggle("is-full", total >= api.limits.maxRows);
          addSectionBtn.disabled = total >= api.limits.maxRows;
        }
        function makeIconButton(svgName, label, disabled) {
          var btn = el("button", { type: "button", class: "extuiInteractiveListIconBtn", title: label, "aria-label": label }, [icon(svgName)]);
          btn.disabled = !!disabled;
          return btn;
        }
        function renderBuilder() {
          sectionList.innerHTML = "";
          var total = api.countRows(draft);
          draft.sections.forEach(function (section, sectionIndex) {
            var sectionCard = el("div", { class: "extuiInteractiveListSection" });
            var sectionTop = el("div", { class: "extuiInteractiveListSectionTop" });
            var sectionName = el("input", { type: "text", maxlength: String(api.limits.sectionTitle), value: section.title, placeholder: "Título da seção", "aria-label": "Título da seção " + (sectionIndex + 1) });
            sectionName.addEventListener("input", function () { section.title = sectionName.value; paintPreview(); });
            var sectionActions = el("div", { class: "extuiInteractiveListInlineActions" });
            var sectionUp = makeIconButton("undo", "Mover seção para cima", sectionIndex === 0);
            var sectionDown = makeIconButton("redo", "Mover seção para baixo", sectionIndex === draft.sections.length - 1);
            var sectionDelete = makeIconButton("trash", "Excluir seção", draft.sections.length === 1);
            sectionUp.addEventListener("click", function () { move(draft.sections, sectionIndex, sectionIndex - 1); renderBuilder(); });
            sectionDown.addEventListener("click", function () { move(draft.sections, sectionIndex, sectionIndex + 1); renderBuilder(); });
            sectionDelete.addEventListener("click", function () { if (draft.sections.length > 1) { draft.sections.splice(sectionIndex, 1); renderBuilder(); } });
            sectionActions.appendChild(sectionUp); sectionActions.appendChild(sectionDown); sectionActions.appendChild(sectionDelete);
            sectionTop.appendChild(sectionName); sectionTop.appendChild(sectionActions);
            sectionCard.appendChild(sectionTop);

            var rows = el("div", { class: "extuiInteractiveListRows" });
            section.rows.forEach(function (row, rowIndex) {
              var rowCard = el("div", { class: "extuiInteractiveListRow" });
              var rowFields = el("div", { class: "extuiInteractiveListRowFields" });
              var rowTitle = el("input", { type: "text", maxlength: String(api.limits.rowTitle), value: row.title, placeholder: "Nome da opção", "aria-label": "Nome da opção " + (rowIndex + 1) });
              var rowDescription = el("input", { type: "text", maxlength: String(api.limits.rowDescription), value: row.description, placeholder: "Descrição opcional", "aria-label": "Descrição da opção " + (rowIndex + 1) });
              rowTitle.addEventListener("input", function () { row.title = rowTitle.value; paintPreview(); });
              rowDescription.addEventListener("input", function () { row.description = rowDescription.value; paintPreview(); });
              rowFields.appendChild(rowTitle); rowFields.appendChild(rowDescription);
              var rowActions = el("div", { class: "extuiInteractiveListInlineActions" });
              var rowUp = makeIconButton("undo", "Mover opção para cima", rowIndex === 0);
              var rowDown = makeIconButton("redo", "Mover opção para baixo", rowIndex === section.rows.length - 1);
              var rowDelete = makeIconButton("trash", "Excluir opção", section.rows.length === 1);
              rowUp.addEventListener("click", function () { move(section.rows, rowIndex, rowIndex - 1); renderBuilder(); });
              rowDown.addEventListener("click", function () { move(section.rows, rowIndex, rowIndex + 1); renderBuilder(); });
              rowDelete.addEventListener("click", function () { if (section.rows.length > 1) { section.rows.splice(rowIndex, 1); renderBuilder(); } });
              rowActions.appendChild(rowUp); rowActions.appendChild(rowDown); rowActions.appendChild(rowDelete);
              rowCard.appendChild(el("span", { class: "extuiInteractiveListRowNumber", text: String(rowIndex + 1) }));
              rowCard.appendChild(rowFields); rowCard.appendChild(rowActions);
              rows.appendChild(rowCard);
            });
            sectionCard.appendChild(rows);
            var addRow = el("button", { type: "button", class: "extuiInteractiveListAddRow" }, [icon("plus"), el("span", { text: "Adicionar opção" })]);
            if (total >= api.limits.maxRows) addRow.disabled = true;
            addRow.addEventListener("click", function () {
              if (api.countRows(draft) >= api.limits.maxRows) return;
              section.rows.push(api.newRow({})); renderBuilder();
            });
            sectionCard.appendChild(addRow);
            sectionList.appendChild(sectionCard);
          });
          paintPreview();
        }

        [titleInput, descriptionInput, buttonInput, footerInput].forEach(function (control) { control.addEventListener("input", paintPreview); });
        addSectionBtn.addEventListener("click", function () {
          if (api.countRows(draft) >= api.limits.maxRows) return;
          draft.sections.push(api.newSection({ title: "Seção " + (draft.sections.length + 1), rows: [api.newRow({})] }));
          renderBuilder();
        });
        renderBuilder();

        confirmBtn.addEventListener("click", async function () {
          var name = nameInput.value.trim();
          if (!name) { toast("Digite um nome para a lista.", true); nameInput.focus(); return; }
          syncDraftFromBasics();
          var result = api.validate(draft);
          if (!result.ok) { toast(result.errors[0], true); return; }
          var id = existingItem ? existingItem.id : uid();
          await commitItem("interactive-list", id, name, result.value, confirmBtn, close);
        });
      }
    });
  }

  function openContactForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar contato" : "Novo contato",
      className: "extuiAssetComposerModal extuiAssetComposerModal--contact",
      render: async function (body, close, confirmBtn) {
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        body.appendChild(el("label", { text: "Nome do contato" }));
        var contactNameInput = el("input", { type: "text" }); contactNameInput.value = (existingContent && existingContent.contactName) || (existingItem && existingItem.name) || "";
        body.appendChild(contactNameInput);
        body.appendChild(el("label", { text: "Telefone (DDI+DDD+número)" }));
        var phoneInput = el("input", { type: "text", placeholder: "5511987654321" }); phoneInput.value = (existingContent && existingContent.contactPhone) || "";
        body.appendChild(phoneInput);
        body.appendChild(el("div", { class: "extuifPropNote", text: "Envia esse contato como um cartão de contato (vCard) nativo do WhatsApp." }));
        var contactStudio = extConfigStudioDecorate(body, { kind: "contact", icon: "contact", title: "Prévia", description: "Veja como o contato ficará na conversa." });
        function paintContactPreview() { extConfigStudioPreview(contactStudio, contactNameInput.value.trim() || "Novo contato", [phoneInput.value.trim() || "Telefone ainda não informado", "Cartão vCard para WhatsApp"]); }
        [contactNameInput, phoneInput].forEach(function (input) { input.addEventListener("input", paintContactPreview); }); paintContactPreview();
        confirmBtn.addEventListener("click", async function () {
          var name = contactNameInput.value.trim();
          if (!name) { toast("Digite o nome do contato.", true); contactNameInput.focus(); return; }
          var phoneDigits = phoneInput.value.replace(/\D/g, "");
          if (!phoneDigits) { toast("Digite o telefone.", true); return; }
          var id = existingItem ? existingItem.id : uid();
          await commitItem("contact", id, name, { contactName: name, contactPhone: phoneDigits }, confirmBtn, close);
        });
      }
    });
  }

  async function persistItem(kind, id, name, content) {
    var list = await loadList(kind);
    var idx = list.findIndex(function (it) { return it.id === id; });
    var previousContent = idx >= 0 ? await loadContent(id) : null;
    var subtype = kind === "image" || kind === "video" ? kind : null;
    if (idx === -1) list.push(Object.assign({ id: id, name: name, favorite: false }, subtype ? { mediaKind: subtype } : {}));
    else list[idx] = Object.assign({}, list[idx], { id: id, name: name }, subtype ? { mediaKind: subtype } : {});
    if (subtype && content && typeof content === "object") content = Object.assign({}, content, { mediaKind: subtype });

                                                                         
                                                                          
                                                                            
                                                                            
                                                                  
    await saveContent(id, content);
    try {
      await saveList(kind, list);
    } catch (err) {
      try {
        if (previousContent != null) await saveContent(id, previousContent);
        else await deleteContent(id);
      } catch (_) {}
      throw err;
    }
  }

  async function commitItem(kind, id, name, content, confirmBtn, close) {
    if (confirmBtn) confirmBtn.disabled = true;
    try {
      await persistItem(kind, id, name, content);
      close("save");
      selectedItemId = id;
      await renderGrid(splitListEl);
      return true;
    } catch (err) {
      toast("Não foi possível salvar o item: " + (err && err.message ? err.message : "erro de armazenamento"), true);
      return false;
    } finally {
      if (confirmBtn && document.contains(confirmBtn)) confirmBtn.disabled = false;
    }
  }

  function openMessageForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar mensagem" : "Nova mensagem",
      className: "extuiMessageComposerModal",
      render: async function (body, close, confirmBtn) {
        body.classList.add("extuiMessageComposerModalBody");
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        var shell = el("div", { class: "extuiMessageComposer" });
        var main = el("main", { class: "extuiMessageComposerMain" });
        var side = el("aside", { class: "extuiMessageVariablePanel" });

        var identityCard = el("section", { class: "extuiMessageComposerCard extuiMessageComposerCard--identity" });
        var identityHead = el("div", { class: "extuiMessageComposerSectionHead" }, [
          el("div", { class: "extuiMessageComposerSectionIcon" }, [icon("message")]),
          el("div", {}, [el("strong", { text: "Identificação" }), el("span", { text: "Nome interno para localizar esta mensagem depois." })])
        ]);
        var nameInput = el("input", { type: "text", placeholder: "Ex.: Boas-vindas, retorno de orçamento, cobrança..." });
        nameInput.value = existingItem ? existingItem.name : "";
        identityCard.appendChild(identityHead);
        identityCard.appendChild(nameInput);
        main.appendChild(identityCard);

        var contentCard = el("section", { class: "extuiMessageComposerCard extuiMessageComposerCard--content" });
        var count = el("span", { class: "extuiMessageComposerCount", text: "0 caracteres" });
        var variableTools = el("div", { class: "extuiMessageVariableTools extuiMessageComposerHistoryTools", role: "group", "aria-label": "Histórico da mensagem" });
        var undoVariableBtn = el("button", { type: "button", class: "extuiMessageVariableToolBtn", title: "Desfazer (Ctrl+Z)", "aria-label": "Desfazer" }, [icon("undo")]);
        var redoVariableBtn = el("button", { type: "button", class: "extuiMessageVariableToolBtn", title: "Refazer (Ctrl+Y)", "aria-label": "Refazer" }, [icon("redo")]);
        variableTools.appendChild(undoVariableBtn);
        variableTools.appendChild(redoVariableBtn);
        var contentHeadActions = el("div", { class: "extuiMessageComposerHeadActions" }, [variableTools, count]);
        var contentHead = el("div", { class: "extuiMessageComposerSectionHead extuiMessageComposerSectionHead--between" }, [
          el("div", {}, [el("strong", { text: "Mensagem" }), el("span", { text: "Escreva o conteúdo reutilizável e insira variáveis quando precisar." })]),
          contentHeadActions
        ]);
        var textArea = el("textarea", { class: "extuiMessageComposerTextarea", placeholder: "Ex.: Olá {primeiro_nome}, tudo bem? Posso te ajudar com..." });
        textArea.value = existingContent && existingContent.data || "";
        var helper = el("div", { class: "extuiMessageComposerHelper" }, [
          el("span", { text: "As variáveis são resolvidas somente no momento do envio." }),
          el("code", { text: '{{primeiro_nome|padrao:"cliente"}}' })
        ]);
        contentCard.appendChild(contentHead);
        contentCard.appendChild(textArea);
        contentCard.appendChild(helper);
        main.appendChild(contentCard);

        var previewCard = el("section", { class: "extuiMessagePreviewCard" });
        var previewHead = el("div", { class: "extuiMessagePreviewHead" }, [
          el("div", {}, [el("strong", { text: "Prévia no WhatsApp" }), el("span", { text: "Simulação com dados de exemplo" })]),
          el("span", { class: "extuiMessagePreviewStatus", text: "Prévia" })
        ]);
        var preview = el("div", { class: "extuiMessagePreview" });
        var bubble = el("div", { class: "extuiMessagePreviewBubble" });
        var previewTime = el("span", { class: "extuiMessagePreviewTime", text: "10:30 ✓✓" });
        preview.appendChild(bubble);
        preview.appendChild(previewTime);
        previewCard.appendChild(previewHead);
        previewCard.appendChild(preview);
        main.appendChild(previewCard);

        var variableDefinitions = [
          { id: "contact", title: "Contato", desc: "Identidade disponível na conversa", items: [
            ["{primeiro_nome}", "Primeiro nome", "Primeiro nome do contato"],
            ["{nome}", "Nome completo", "Nome completo resolvido"],
            ["{nome_extapp}", "Nome Extensão", "Alias local configurado na extensão"],
            ["{nome_whatsapp}", "Nome WhatsApp", "Nome informado pelo WhatsApp"],
            ["{numero}", "Número", "Telefone do contato"]
          ]},
          { id: "profile", title: "Perfil", desc: "Dados cadastrados no perfil do cliente", items: [
            ["{email}", "E-mail", "E-mail do cliente"],
            ["{empresa}", "Empresa", "Empresa ou organização"],
            ["{origem_lead}", "Origem do lead", "Canal de aquisição"],
            ["{cidade}", "Cidade", "Cidade cadastrada"],
            ["{estado}", "Estado", "Estado ou região"],
            ["{endereco}", "Endereço", "Endereço cadastrado"],
            ["{cep}", "CEP", "Código postal"],
            ["{idioma}", "Idioma", "Idioma do perfil"]
          ]},
          { id: "time", title: "Tempo", desc: "Valores calculados no envio", items: [
            ["{saudacao}", "Saudação", "Bom dia, boa tarde ou boa noite"],
            ["{periodo_dia}", "Período do dia", "manhã, tarde ou noite"],
            ["{dia_semana}", "Dia da semana", "Dia atual por extenso"],
            ["{data}", "Data", "Data do envio"],
            ["{hora}", "Hora", "Hora do envio"]
          ]}
        ];
        var variableHeader = el("div", { class: "extuiMessageVariableHeader" }, [
          el("div", {}, [el("strong", { text: "Variáveis" }), el("span", { text: "Clique para inserir na posição do cursor." })])
        ]);
        var variableSearch = el("input", { class: "extuiMessageVariableSearch", type: "search", placeholder: "Buscar variável...", "aria-label": "Buscar variável" });
        var variableTabs = el("div", { class: "extuiMessageVariableTabs", role: "tablist" });
        var variableList = el("div", { class: "extuiMessageVariableList" });
        var activeGroup = "contact";
        side.appendChild(variableHeader);
        side.appendChild(variableSearch);
        side.appendChild(variableTabs);
        side.appendChild(variableList);

        var messageHistory = [];
        var messageHistoryIndex = -1;
        var suppressMessageHistory = false;
        function pushMessageHistory(value, start, end) {
          if (suppressMessageHistory) return;
          var snapshot = { value: String(value || ""), start: Number.isFinite(start) ? start : null, end: Number.isFinite(end) ? end : null };
          var current = messageHistory[messageHistoryIndex];
          if (current && current.value === snapshot.value && current.start === snapshot.start && current.end === snapshot.end) return;
          messageHistory = messageHistory.slice(0, messageHistoryIndex + 1);
          messageHistory.push(snapshot);
          if (messageHistory.length > 80) messageHistory.shift();
          messageHistoryIndex = messageHistory.length - 1;
          syncVariableHistoryButtons();
        }
        function applyMessageHistory(index) {
          var snapshot = messageHistory[index];
          if (!snapshot) return;
          messageHistoryIndex = index;
          suppressMessageHistory = true;
          textArea.value = snapshot.value;
          textArea.focus();
          var start = snapshot.start == null ? snapshot.value.length : snapshot.start;
          var end = snapshot.end == null ? start : snapshot.end;
          textArea.setSelectionRange(start, end);
          suppressMessageHistory = false;
          syncVariableHistoryButtons();
          paintPreview();
        }
        function undoMessageHistory() { if (messageHistoryIndex > 0) applyMessageHistory(messageHistoryIndex - 1); }
        function redoMessageHistory() { if (messageHistoryIndex < messageHistory.length - 1) applyMessageHistory(messageHistoryIndex + 1); }
        function syncVariableHistoryButtons() {
          undoVariableBtn.disabled = messageHistoryIndex <= 0;
          redoVariableBtn.disabled = messageHistoryIndex >= messageHistory.length - 1;
        }
        undoVariableBtn.addEventListener("click", undoMessageHistory);
        redoVariableBtn.addEventListener("click", redoMessageHistory);

        function insertToken(token) {
          var s = textArea.selectionStart == null ? textArea.value.length : textArea.selectionStart;
          var e = textArea.selectionEnd == null ? s : textArea.selectionEnd;
          textArea.value = textArea.value.slice(0, s) + token + textArea.value.slice(e);
          var n = s + token.length;
          textArea.focus();
          textArea.setSelectionRange(n, n);
          pushMessageHistory(textArea.value, n, n);
          paintPreview();
        }

        function renderVariables() {
          variableTabs.innerHTML = "";
          variableDefinitions.forEach(function (group) {
            var tab = el("button", { type: "button", class: "extuiMessageVariableTab" + (activeGroup === group.id ? " is-active" : ""), text: group.title });
            tab.addEventListener("click", function () { activeGroup = group.id; renderVariables(); });
            variableTabs.appendChild(tab);
          });
          variableList.innerHTML = "";
          var q = variableSearch.value.trim().toLowerCase();
          var group = variableDefinitions.find(function (item) { return item.id === activeGroup; }) || variableDefinitions[0];
          var section = el("section", { class: "extuiMessageVariableGroup" });
          section.appendChild(el("div", { class: "extuiMessageVariableGroupIntro" }, [el("strong", { text: group.title }), el("span", { text: group.desc })]));
          var grid = el("div", { class: "extuiMessageVariableGrid" });
          group.items.filter(function (v) { return !q || (v[0] + " " + v[1] + " " + v[2]).toLowerCase().indexOf(q) !== -1; }).forEach(function (v) {
            var b = el("button", { type: "button", class: "extuiMessageVariableChip", title: "Inserir " + v[0] }, [
              el("div", {}, [el("strong", { text: v[1] }), el("span", { text: v[2] })]),
              el("code", { text: v[0] })
            ]);
            b.addEventListener("click", function () { insertToken(v[0]); });
            grid.appendChild(b);
          });
          if (!grid.children.length) grid.appendChild(el("div", { class: "extuiMessageVariableEmpty", text: "Nenhuma variável encontrada nesta categoria." }));
          section.appendChild(grid);
          variableList.appendChild(section);
        }
        variableSearch.addEventListener("input", renderVariables);
        renderVariables();
        side.appendChild(el("div", { class: "extuiMessageVariableHint" }, [
          el("strong", { text: "Valor alternativo (opcional)" }),
          el("span", { text: "Use um valor alternativo quando o dado puder estar vazio." }),
          el("code", { text: '{{primeiro_nome|padrao:"cliente"}}' })
        ]));

        function previewResolve(input) {
          var sample = {
            primeiro_nome: "Lucas", nome: "Lucas Silva", nome_extapp: "Lucas Silva", nome_ext: "Lucas Silva", nome_whatsapp: "Lucas WhatsApp", numero: "+55 (11) 99999-9999",
            email: "lucas@empresa.com", empresa: "Empresa", origem_lead: "Instagram", cidade: "São Paulo", estado: "SP", endereco: "Av. Exemplo, 100", cep: "01000-000", idioma: "pt-BR",
            saudacao: "Bom dia", periodo_dia: "manhã", dia_semana: "terça-feira", data: "25/08/2026", hora: "10:30"
          };
          var val = String(input || "");
          val = val.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\|\s*(?:fallback|default|padrao|padrão)\s*:\s*["']([^"']*)["']\s*\}\}/gi, function (_, key, fallback) { return sample[key] || fallback || ""; });
          val = val.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, function (_, key) { return sample[key] || ""; });
          val = val.replace(/(^|[^\{])\{([a-zA-Z0-9_]+)\}(?!\})/g, function (_, prefix, key) { return prefix + (sample[key] || ""); });
          return val;
        }
        textArea.addEventListener("keydown", function (event) {
          var key = String(event.key || "").toLowerCase();
          var ctrl = event.ctrlKey || event.metaKey;
          if (!ctrl) return;
          if (key === "z" && !event.shiftKey) { event.preventDefault(); undoMessageHistory(); }
          else if (key === "y" || (key === "z" && event.shiftKey)) { event.preventDefault(); redoMessageHistory(); }
        });
        textArea.addEventListener("input", function () {
          pushMessageHistory(textArea.value, textArea.selectionStart, textArea.selectionEnd);
        });
        pushMessageHistory(textArea.value, textArea.selectionStart, textArea.selectionEnd);

        function paintPreview() {
          var raw = textArea.value || "";
          count.textContent = raw.length + (raw.length === 1 ? " caractere" : " caracteres");
          var value = previewResolve(raw);
          bubble.textContent = value || "Sua mensagem aparecerá aqui.";
          preview.classList.toggle("is-empty", !value);
        }
        textArea.addEventListener("input", paintPreview);
        textArea.addEventListener("keydown", function (event) {
          if ((event.ctrlKey || event.metaKey) && event.key === "Enter") { event.preventDefault(); confirmBtn.click(); }
        });
        paintPreview();

        shell.appendChild(main);
        shell.appendChild(side);
        body.appendChild(shell);
        confirmBtn.addEventListener("click", async function () {
          var name = nameInput.value.trim();
          if (!name) { toast("Digite um nome.", true); nameInput.focus(); return; }
          var id = existingItem ? existingItem.id : uid();
          await commitItem("message", id, name, { data: textArea.value }, confirmBtn, close);
        });
      }
    });
  }

  function openMediaForm(existingItem, requestedKind) {
    requestedKind = requestedKind === "video" ? "video" : "image";
    var mediaLabel = requestedKind === "video" ? "vídeo" : "imagem";
    var mediaTitle = requestedKind === "video" ? "Vídeo" : "Imagem";
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar " + mediaLabel : "Nova " + mediaLabel,
      className: "extuiAssetComposerModal extuiAssetComposerModal--media",
      render: async function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", value: existingItem ? existingItem.name : "" });
        body.appendChild(nameInput);
        body.appendChild(el("label", { text: requestedKind === "video" ? "Arquivo de vídeo" : "Arquivo de imagem" }));
        var mediaAccept = requestedKind === "video" ? "video/*,.mp4,.mov,.mkv,.avi,.3gp,.flv,.webm,.m4v" : "image/*,.jpg,.jpeg,.png,.gif,.webp,.bmp";
        var fileInput = el("input", { type: "file", accept: mediaAccept });
        var filePickerText = el("span", { class: "extuiItensFilePicker__text", text: existingItem ? "Trocar arquivo" : "Escolher arquivo" });
        var filePickerWrap = el("div", { class: "extuiItensFilePicker" }, [fileInput, icon(requestedKind, "extuiItensFilePicker__icon"), filePickerText]);
        body.appendChild(filePickerWrap);
        body.appendChild(el("small", { class: "extuiConfigStudioFileHint", text: requestedKind === "video" ? "Formatos reconhecidos: MP4, MOV, MKV, AVI, 3GP, FLV, WebM e M4V · até 180 MB." : "Formatos reconhecidos: JPG/JPEG, PNG, GIF, WebP e BMP." }));
        body.appendChild(el("label", { text: "Legenda (opcional)" }));
        var captionInput = el("input", { type: "text" });
        var existingContent = null;
        if (existingItem) {
          existingContent = await loadContent(existingItem.id);
          captionInput.value = (existingContent && existingContent.caption) || "";
        }
        body.appendChild(captionInput);
                                                                              
                                                                            
                                                                              
                                                                          
        var ptvCheckbox = el("input", { type: "checkbox", class: "extuiItensCheckbox" });
        var ptvRow = el("label", { class: "extuiItensCheckRow", style: "display:none" }, [
          ptvCheckbox,
          el("span", { class: "extuiItensCheckTitle", text: "Enviar como vídeo recado (nota de vídeo)" })
        ]);
        function updatePtvVisibility(isVideo) {
          ptvRow.style.display = isVideo ? "" : "none";
          if (!isVideo) ptvCheckbox.checked = false;
        }
        updatePtvVisibility(requestedKind === "video");
        if (existingContent) ptvCheckbox.checked = requestedKind === "video" && !!existingContent.isPtv;
                                                                           
                                                               
                                                                     
                                                                        
                                                                  
                                                                         
                                                                     
                                                                        
                                                                   
        var pendingFile = null;
        fileInput.addEventListener("change", function () {
          if (fileInput.files && fileInput.files[0]) {
            var file = fileInput.files[0];
            var isVideoFile = extLibraryIsVideo(file.name, file.type);
            var isImageFile = extLibraryIsImage(file.name, file.type);
            if ((requestedKind === "video" && !isVideoFile) || (requestedKind === "image" && !isImageFile)) {
              toast("Selecione um arquivo de " + mediaLabel + ".", true);
              fileInput.value = ""; pendingFile = null; filePickerWrap.classList.remove("extuiHasFile");
              return;
            }
            if (isVideoFile && file.size > MAX_VIDEO_BYTES) {
              toast("Este vídeo excede o limite de 180 MB. Arquivo: " + (file.size / (1024 * 1024)).toFixed(0) + " MB. Limite: 180 MB.", true);
              fileInput.value = "";
              filePickerText.textContent = existingItem ? "Trocar arquivo" : "Escolher arquivo";
              filePickerWrap.classList.remove("extuiHasFile");
              pendingFile = null;
              return;
            }
            pendingFile = file;
            filePickerText.textContent = file.name;
            filePickerWrap.classList.add("extuiHasFile");
            updatePtvVisibility(requestedKind === "video");
          }
        });
        body.appendChild(ptvRow);
        var viewOnceCheckbox = el("input", { type: "checkbox", class: "extuiItensCheckbox" });
        viewOnceCheckbox.checked = !!(existingContent && existingContent.asViewOnce);
        var viewOnceRow = el("label", { class: "extuiItensCheckRow" }, [
          viewOnceCheckbox,
          el("span", { class: "extuiItensCheckTitle", text: "Visualização única" }),
          el("small", { class: "extuiConfigStudioOptionHint", text: "A mídia some após ser aberta pelo destinatário." })
        ]);
        body.appendChild(viewOnceRow);
        var mediaStudio = extConfigStudioDecorate(body, { kind: requestedKind, icon: requestedKind, title: "Prévia", description: "Veja como a mídia ficará na conversa." });
        function paintMediaPreview() { var f = pendingFile || (existingContent && { name: existingContent.fileName, type: existingContent.mimeType, size: existingContent.sizeBytes }); extConfigStudioPreview(mediaStudio, nameInput.value.trim() || (requestedKind === "video" ? "Novo vídeo" : "Nova imagem"), [captionInput.value.trim() || (f && f.name ? f.name : "Nenhum arquivo selecionado"), ptvCheckbox.checked ? "Vídeo recado" : (viewOnceCheckbox.checked ? "Visualização única" : "Envio padrão")], {kind:requestedKind,file:pendingFile||null,src:pendingFile?"":(existingContent&&existingContent.data||""),caption:captionInput.value.trim()}); }
        [nameInput, captionInput].forEach(function (input) { input.addEventListener("input", paintMediaPreview); });
        ptvCheckbox.addEventListener("change", function(){ if(ptvCheckbox.checked) viewOnceCheckbox.checked=false; viewOnceCheckbox.disabled=ptvCheckbox.checked; paintMediaPreview(); });
        viewOnceCheckbox.addEventListener("change", paintMediaPreview); fileInput.addEventListener("change", paintMediaPreview); paintMediaPreview();
        confirmBtn.addEventListener("click", async function () {
          var name = nameInput.value.trim();
          if (!name) { toast("Digite um nome.", true); return; }
          var dataUrl = pendingFile ? await readFileAsDataUrl(pendingFile) : (existingContent && existingContent.data);
          if (!dataUrl) { toast("Escolha um arquivo.", true); return; }
          var id = existingItem ? existingItem.id : uid();
          var mediaFileName = pendingFile ? pendingFile.name : (existingContent && existingContent.fileName || "");
          var mediaMimeType = pendingFile ? (pendingFile.type || "") : (existingContent && existingContent.mimeType || "");
          var mediaKind = requestedKind;
          await commitItem(requestedKind, id, name, { data: dataUrl, caption: captionInput.value, asViewOnce: viewOnceCheckbox.checked, isPtv: mediaKind === "video" && ptvCheckbox.checked, sendAsDocument: false, mediaKind: mediaKind, mimeType: mediaMimeType, fileName: mediaFileName, sizeBytes: pendingFile ? pendingFile.size : (existingContent && existingContent.sizeBytes || 0) }, confirmBtn, close);
        });
      }
    });
  }

  function openAudioForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar áudio" : "Novo áudio",
      className: "extuiAssetComposerModal extuiAssetComposerModal--audio",
      confirmLabel: "Salvar",
      render: async function (body, close, confirmBtn, modalState) {
        await ensureAudioCodec();
        var pendingDataUrl = null;
        var pendingMimeType = "";
        var pendingFileName = "";
        var pendingSizeBytes = 0;
        var pendingDurationMs = 0;
        var pendingSourceMimeType = "";
        var pendingSourceFileName = "";
        var pendingNormalized = false;
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        if (existingContent) {
          pendingDataUrl = existingContent.data;
          pendingMimeType = existingContent.mimeType || "";
          pendingFileName = existingContent.fileName || "";
          pendingSizeBytes = Number(existingContent.sizeBytes || 0);
          pendingDurationMs = Number(existingContent.durationMs || 0);
          pendingSourceMimeType = existingContent.sourceMimeType || existingContent.mimeType || "";
          pendingSourceFileName = existingContent.sourceFileName || existingContent.fileName || "";
          pendingNormalized = existingContent.normalizedForWhatsApp === true || getAudioCodec().isCompatibleDataUrl(pendingDataUrl || "");
        }

        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", value: existingItem ? existingItem.name : "" });
        body.appendChild(nameInput);

                                                                          
                                                                          
                                                                           
                                                     
        var audioStudio = null;
        var previewWrap = el("div", { class: "extuiItensAudioPreview" });
        function renderPreview() {
          previewWrap.innerHTML = "";
          previewWrap.classList.toggle("extuiItensAudioPreview--empty", !pendingDataUrl);
          if (pendingDataUrl) {
            var audioPreview = el("audio", { controls: "controls" });
            previewWrap.appendChild(audioPreview);
            if (window.ExtensionMediaStore && window.ExtensionMediaStore.isRef(pendingDataUrl)) window.ExtensionMediaStore.previewUrl(pendingDataUrl).then(function (url) { if (audioPreview.isConnected) audioPreview.src = url; }).catch(function () {});
            else audioPreview.src = pendingDataUrl;
          } else {
            previewWrap.appendChild(icon("audio", "extuiItensAudioPreviewIcon"));
            previewWrap.appendChild(el("span", { class: "extuiItensAudioPreviewText", text: "Nenhum áudio ainda" }));
          }
          if (audioStudio) paintAudioStudio();
        }
        renderPreview();
        body.appendChild(previewWrap);

        var modeRow = el("div", { class: "extuiItensAudioModeRow" });
        var uploadBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost" }, [icon("upload"), el("span", { text: " Enviar arquivo" })]);
        var recordBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost" }, [icon("mic"), el("span", { text: " Gravar" })]);
        function setRecordBtnState(isRecording) {
          recordBtn.innerHTML = "";
          recordBtn.appendChild(icon(isRecording ? "square" : "mic"));
          recordBtn.appendChild(el("span", { text: isRecording ? " Parar" : " Gravar" }));
        }
        modeRow.appendChild(uploadBtn);
        modeRow.appendChild(recordBtn);
        body.appendChild(modeRow);
        body.appendChild(el("small", { class: "extuiConfigStudioFileHint", text: "Aceita MP3, WAV, M4A, AAC, OGG, OPUS, FLAC, WEBA, WebM e AMR. Nota de voz é normalizada para OGG/Opus quando necessário." }));

        var fileInput = el("input", { type: "file", accept: "audio/*,.mp3,.wav,.m4a,.aac,.amr,.ogg,.opus,.flac,.weba,.webm" });
        fileInput.style.display = "none";
        body.appendChild(fileInput);
        uploadBtn.addEventListener("click", function () { fileInput.click(); });
        fileInput.addEventListener("change", async function () {
          if (!fileInput.files || !fileInput.files[0]) return;
          var selectedFile = fileInput.files[0];
          uploadBtn.disabled = true;
          recordBtn.disabled = true;
          confirmBtn.disabled = true;
          var uploadText = uploadBtn.querySelector("span");
          if (uploadText) uploadText.textContent = " Convertendo...";
          try {
            var normalized = await getAudioCodec().normalizeFile(selectedFile, { bitrate: 32000 });
            pendingDataUrl = normalized.dataUrl;
            pendingMimeType = "audio/ogg";
            pendingFileName = normalized.fileName;
            pendingSizeBytes = normalized.sizeBytes;
            pendingDurationMs = normalized.durationMs || 0;
            pendingSourceMimeType = normalized.sourceMimeType || selectedFile.type || "";
            pendingSourceFileName = selectedFile.name || "audio";
            pendingNormalized = true;
            renderPreview();
            toast(normalized.converted ? "Áudio preparado para funcionar corretamente no WhatsApp." : "Áudio pronto para usar no WhatsApp.");
          } catch (err) {
            var isAmr = /\.amr$/i.test(selectedFile.name || "") || /^audio\/(?:amr|3gpp)$/i.test(selectedFile.type || "");
            if (isAmr) {
              try {
                pendingDataUrl = await readFileAsDataUrl(selectedFile);
                pendingMimeType = selectedFile.type || "audio/amr";
                pendingFileName = selectedFile.name || "audio.amr";
                pendingSizeBytes = Number(selectedFile.size || 0);
                pendingDurationMs = 0;
                pendingSourceMimeType = pendingMimeType;
                pendingSourceFileName = pendingFileName;
                pendingNormalized = false;
                if (pttCheckbox) pttCheckbox.checked = false;
                renderPreview();
                toast("AMR preservado no formato original. Ele será enviado como áudio comum; nota de voz exige conversão para OGG/Opus.");
              } catch (fallbackErr) {
                pendingDataUrl = null; pendingMimeType = ""; pendingFileName = ""; pendingSizeBytes = 0; pendingDurationMs = 0; pendingSourceMimeType = ""; pendingSourceFileName = ""; pendingNormalized = false;
                toast("Não foi possível importar este áudio AMR: " + (fallbackErr && fallbackErr.message ? fallbackErr.message : String(fallbackErr)), true);
              }
            } else {
              pendingDataUrl = null; pendingMimeType = ""; pendingFileName = ""; pendingSizeBytes = 0; pendingDurationMs = 0; pendingSourceMimeType = ""; pendingSourceFileName = ""; pendingNormalized = false;
              toast("Não foi possível converter este áudio: " + (err && err.message ? err.message : String(err)), true);
            }
          } finally {
            uploadBtn.disabled = false;
            recordBtn.disabled = false;
            confirmBtn.disabled = false;
            if (uploadText) uploadText.textContent = " Enviar arquivo";
          }
        });

        var micRecorder = createMicRecorder();
        var recording = false;
        recordBtn.addEventListener("click", async function () {
          if (!recording) {
            try {
              await micRecorder.start();
              recording = true;
              modalState.markDirty();
              setRecordBtnState(true);
            } catch (err) {
              toast("Não foi possível acessar o microfone: " + (err && err.message ? err.message : String(err)), true);
            }
            return;
          }
          recordBtn.disabled = true;
          try {
            var normalizedRecording = await micRecorder.stop();
            pendingDataUrl = normalizedRecording.dataUrl;
            pendingMimeType = "audio/ogg";
            pendingFileName = normalizedRecording.fileName || "gravacao.ogg";
            pendingSizeBytes = normalizedRecording.sizeBytes || 0;
            pendingDurationMs = normalizedRecording.durationMs || 0;
            pendingSourceMimeType = normalizedRecording.sourceMimeType || "audio/webm";
            pendingSourceFileName = "gravacao";
            pendingNormalized = true;
            renderPreview();
            toast("Gravação preparada para funcionar no WhatsApp.");
          } catch (err) {
            toast("Erro ao gravar: " + (err && err.message ? err.message : String(err)), true);
          } finally {
            recording = false;
            recordBtn.disabled = false;
            setRecordBtnState(false);
          }
        });

        var pttCheckbox = el("input", { type: "checkbox", class: "extuiItensCheckbox" });
        pttCheckbox.checked = existingContent ? existingContent.isPtt !== false : true;
        var pttLabel = el("label", { class: "extuiItensCheckRow" }, [
          pttCheckbox,
          el("span", { class: "extuiItensCheckTitle", text: "Enviar como nota de voz" })
        ]);
        body.appendChild(pttLabel);
        var audioViewOnceCheckbox = el("input", { type: "checkbox", class: "extuiItensCheckbox" });
        audioViewOnceCheckbox.checked = !!(existingContent && existingContent.asViewOnce);
        var audioViewOnceRow = el("label", { class: "extuiItensCheckRow" }, [
          audioViewOnceCheckbox,
          el("span", { class: "extuiItensCheckTitle", text: "Áudio de reprodução única" }),
          el("small", { class: "extuiConfigStudioOptionHint", text: "Usa o modo de visualização única suportado pelo WhatsApp." })
        ]);
        body.appendChild(audioViewOnceRow);
        audioStudio = extConfigStudioDecorate(body, { kind: "audio", icon: "audio", title: "Prévia", description: "Veja como o áudio ficará registrado na Biblioteca." });
        function paintAudioStudio(){ extConfigStudioPreview(audioStudio, nameInput.value.trim() || (existingItem ? existingItem.name : "Novo áudio"), [pttCheckbox.checked ? "Nota de voz" : "Áudio comum", audioViewOnceCheckbox.checked ? "Reprodução única" : "Reprodução normal"], {kind:"audio",src:pendingDataUrl||""}); }
        paintAudioStudio();
        nameInput.addEventListener("input", paintAudioStudio); pttCheckbox.addEventListener("change", paintAudioStudio); audioViewOnceCheckbox.addEventListener("change", paintAudioStudio);

        confirmBtn.addEventListener("click", async function () {
          var name = nameInput.value.trim();
          if (!name) { toast("Digite um nome.", true); return; }
          if (!pendingDataUrl) { toast("Envie um arquivo ou grave um áudio.", true); return; }
          confirmBtn.disabled = true;
          try {
            if (pttCheckbox.checked && (!pendingNormalized || !getAudioCodec().isCompatibleDataUrl(pendingDataUrl))) {
              toast("Preparando áudio para nota de voz no WhatsApp...");
              var normalizedLegacy = await getAudioCodec().normalizeDataUrl(pendingDataUrl, { fileName: pendingFileName || "audio", bitrate: 32000 });
              pendingDataUrl = normalizedLegacy.dataUrl;
              pendingMimeType = "audio/ogg";
              pendingFileName = normalizedLegacy.fileName;
              pendingSizeBytes = normalizedLegacy.sizeBytes;
              pendingDurationMs = normalizedLegacy.durationMs || pendingDurationMs;
              pendingSourceMimeType = normalizedLegacy.sourceMimeType || pendingSourceMimeType;
              pendingSourceFileName = pendingSourceFileName || (existingContent && existingContent.fileName) || "audio";
              pendingNormalized = true;
              renderPreview();
            }
            var id = existingItem ? existingItem.id : uid();
            var savedAsPtt = !!pttCheckbox.checked;
            var savedMime = savedAsPtt ? "audio/ogg" : (pendingMimeType || "audio/ogg");
            var savedName = pendingFileName || (savedAsPtt ? "audio.ogg" : "audio");
            await commitItem("audio", id, name, { data: pendingDataUrl, isPtt: savedAsPtt, asViewOnce: audioViewOnceCheckbox.checked, mimeType: savedMime, fileName: savedName, sizeBytes: pendingSizeBytes || 0, durationMs: pendingDurationMs || 0, normalizedForWhatsApp: pendingNormalized === true, audioCodec: pendingNormalized ? "opus" : "", audioContainer: pendingNormalized ? "ogg" : "", codecVersion: pendingNormalized ? 2 : 0, sourceMimeType: pendingSourceMimeType || savedMime, sourceFileName: pendingSourceFileName || savedName }, confirmBtn, close);
          } catch (err) {
            confirmBtn.disabled = false;
            toast("Não foi possível salvar o áudio: " + (err && err.message ? err.message : String(err)), true);
          }
        });
      }
    });
  }

  function openStickerForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar figurinha" : "Nova figurinha",
      className: "extuiAssetComposerModal extuiAssetComposerModal--sticker",
      render: async function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", value: existingItem ? existingItem.name : "" }); body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Arquivo de imagem" }));
        var fileInput = el("input", { type: "file", accept: "image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp" });
        var filePickerText = el("span", { class: "extuiItensFilePicker__text", text: existingItem ? "Trocar figurinha" : "Escolher imagem" });
        var filePickerWrap = el("div", { class: "extuiItensFilePicker" }, [fileInput, icon("sticker", "extuiItensFilePicker__icon"), filePickerText]); body.appendChild(filePickerWrap);
        body.appendChild(el("small", { class: "extuiConfigStudioFileHint", text: "PNG, JPG/JPEG e WebP. PNG/JPG são convertidos automaticamente para WebP, preservando a proporção em uma tela 512×512." }));
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        if (existingContent && existingContent.fileName) { filePickerText.textContent = existingContent.fileName; filePickerWrap.classList.add("extuiHasFile"); }
        var prepared = null, converting = false;
        var studio = extConfigStudioDecorate(body, { kind: "sticker", icon: "sticker", title: "Prévia", description: "Veja a figurinha antes de salvar." });
        function paint(){var current=prepared||existingContent||{};extConfigStudioPreview(studio,nameInput.value.trim()||"Nova figurinha",[current.fileName||"Nenhum arquivo selecionado",prepared&&prepared.converted?"Convertida automaticamente para WebP":"Pronta para enviar como figurinha"],{kind:"sticker",src:current.data||""});}
        fileInput.addEventListener("change",async function(){
          var file=fileInput.files&&fileInput.files[0];if(!file)return;
          if(!extStickerInputSupported(file)){toast("Use PNG, JPG/JPEG ou WebP.",true);fileInput.value="";prepared=null;return;}
          converting=true;confirmBtn.disabled=true;filePickerText.textContent="Preparando "+file.name+"...";
          try{prepared=await extPrepareStickerFile(file);filePickerText.textContent=prepared.fileName;filePickerWrap.classList.add("extuiHasFile");paint();toast(prepared.converted?"Imagem convertida para WebP e pronta como figurinha.":"Figurinha WebP pronta.");}
          catch(err){prepared=null;fileInput.value="";filePickerWrap.classList.remove("extuiHasFile");filePickerText.textContent=existingItem?"Trocar figurinha":"Escolher imagem";toast(err&&err.message||"Não foi possível preparar a figurinha.",true);}
          finally{converting=false;confirmBtn.disabled=false;}
        });
        nameInput.addEventListener("input",paint);paint();
        confirmBtn.addEventListener("click",async function(){
          if(converting)return;var name=nameInput.value.trim();if(!name){toast("Digite um nome.",true);return;}
          var content=prepared||existingContent;if(!content||!content.data){toast("Escolha uma imagem para a figurinha.",true);return;}
          var id=existingItem?existingItem.id:uid();
          await commitItem("sticker",id,name,{data:content.data,fileName:content.fileName||"figurinha.webp",mimeType:"image/webp",sizeBytes:Number(content.sizeBytes||0),sourceMimeType:content.sourceMimeType||content.mimeType||"image/webp",sourceFileName:content.sourceFileName||content.fileName||"figurinha.webp",convertedForSticker:prepared?prepared.converted===true:existingContent&&existingContent.convertedForSticker===true,stickerCanvas:512},confirmBtn,close);
        });
      }
    });
  }

  function openDocumentForm(existingItem) {
    openModal({
      protectUnsaved: true,
      title: existingItem ? "Editar documento" : "Novo documento",
      className: "extuiAssetComposerModal extuiAssetComposerModal--document",
      render: async function (body, close, confirmBtn) {
        body.appendChild(el("label", { text: "Nome" }));
        var nameInput = el("input", { type: "text", value: existingItem ? existingItem.name : "" });
        body.appendChild(nameInput);
        body.appendChild(el("label", { text: "Arquivo" }));
        var fileInput = el("input", { type: "file" });
        var filePickerText = el("span", { class: "extuiItensFilePicker__text", text: "Escolher arquivo" });
        var filePickerWrap = el("div", { class: "extuiItensFilePicker" }, [fileInput, icon("document", "extuiItensFilePicker__icon"), filePickerText]);
        body.appendChild(filePickerWrap);
        var existingContent = existingItem ? await loadContent(existingItem.id) : null;
        if (existingContent && existingContent.fileName) {
          filePickerText.textContent = existingContent.fileName;
          filePickerWrap.classList.add("extuiHasFile");
        }
        fileInput.addEventListener("change", function () {
          if (fileInput.files && fileInput.files[0]) {
            filePickerText.textContent = fileInput.files[0].name;
            filePickerWrap.classList.add("extuiHasFile");
          }
        });
        body.appendChild(el("small", { class: "extuiConfigStudioFileHint", text: "O modo Documento preserva o arquivo e seu tipo MIME; a compatibilidade final depende do WhatsApp Web." }));
        var documentStudio = extConfigStudioDecorate(body, { kind: "document", icon: "document", title: "Prévia", description: "Veja como o documento ficará na conversa." });
        function paintDocumentPreview() { var f = fileInput.files && fileInput.files[0]; extConfigStudioPreview(documentStudio, nameInput.value.trim() || "Novo documento", [f ? f.name : (existingContent && existingContent.fileName || "Nenhum arquivo selecionado"), f ? ((f.type || "Arquivo") + " · " + Math.max(1, Math.round(f.size / 1024)) + " KB") : (existingContent && existingContent.mimeType || "Selecione um arquivo")]); }
        nameInput.addEventListener("input", paintDocumentPreview); fileInput.addEventListener("change", paintDocumentPreview); paintDocumentPreview();
        confirmBtn.addEventListener("click", async function () {
          var name = nameInput.value.trim();
          if (!name) { toast("Digite um nome.", true); return; }
          var dataUrl = existingContent && existingContent.data;
          var fileName = existingContent && existingContent.fileName;
          if (fileInput.files && fileInput.files[0]) {
            dataUrl = await readFileAsDataUrl(fileInput.files[0]);
            fileName = fileInput.files[0].name;
          }
          if (!dataUrl) { toast("Escolha um arquivo.", true); return; }
          var id = existingItem ? existingItem.id : uid();
          await commitItem("document", id, name, { data: dataUrl, fileName: fileName, mimeType: fileInput.files&&fileInput.files[0]?(fileInput.files[0].type||""):(existingContent&&existingContent.mimeType||""), sizeBytes: fileInput.files&&fileInput.files[0]?fileInput.files[0].size:(existingContent&&existingContent.sizeBytes||0) }, confirmBtn, close);
        });
      }
    });
  }

  window.__extDashboardShell.registerSection("itens-message", function (c) { return renderCategorySection("message", c); });
  window.__extDashboardShell.registerSection("itens-audio", function (c) { return renderCategorySection("audio", c); });
  window.__extDashboardShell.registerSection("itens-image", function (c) { return renderCategorySection("image", c); });
  window.__extDashboardShell.registerSection("itens-video", function (c) { return renderCategorySection("video", c); });
  window.__extDashboardShell.registerSection("itens-media", function (c) { return renderCategorySection("image", c); });
  window.__extDashboardShell.registerSection("itens-sticker", function (c) { return renderCategorySection("sticker", c); });
  window.__extDashboardShell.registerSection("itens-document", function (c) { return renderCategorySection("document", c); });
  window.__extDashboardShell.registerSection("itens-pix", function (c) { return renderCategorySection("pix", c); });
  window.__extDashboardShell.registerSection("itens-interactive-list", function (c) { return renderCategorySection("interactive-list", c); });
  window.__extDashboardShell.registerSection("itens-contact", function (c) { return renderCategorySection("contact", c); });
  window.__extDashboardShell.registerSection("itens-signature", function (c) { return renderCategorySection("signature", c); });
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
