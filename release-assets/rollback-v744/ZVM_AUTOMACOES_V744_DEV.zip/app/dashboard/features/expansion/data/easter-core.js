;(function(root){
  "use strict";
  var D=root.__extExpansionStaticData||(root.__extExpansionStaticData={});
  D.EASTER_HINTS=[
    {id:"search",title:"Comece pela Busca Universal",icon:"⌕",base:"A maioria dos sinais responde melhor a uma ideia curta do que a tentativas aleatórias.",steps:["Pense no que o efeito, brinquedo ou jogo representa: chuva, luz, café, calma, falha, velocidade, gato, neve ou rede.","Os dossiês abaixo têm pistas próprias para cada descoberta. Use a categoria certa e avance uma pista por vez."]},
    {id:"brand",title:"A própria marca também participa",icon:"Z",base:"Nem toda descoberta nasce de uma palavra digitada.",steps:["Existe uma interação escondida na identidade da extensão que depende de insistência em pouco tempo.","Se estiver testando a marca, faça a sequência sem longas pausas entre uma interação e outra."]},
    {id:"classic",title:"Memória gamer é recompensada",icon:"↑",base:"Alguns rituais clássicos da história dos jogos funcionam como caminhos alternativos.",steps:["Há sequências de direções e referências famosas de invencibilidade, arsenal e riqueza.","Esses rituais só são reconhecidos fora de input, textarea, select e áreas editáveis para nunca atrapalhar sua digitação."]},
    {id:"combos",title:"Alguns sinais exigem duas camadas",icon:"✦",base:"Combinações aparecem quando um efeito já descoberto encontra o contexto sazonal correto.",steps:["Natal, Halloween e Ano Novo são os três cenários que participam das sinergias secretas.","O arquivo de Combinações abaixo traz um dossiê para cada uma das 12 sinergias sem publicar o par exato enquanto estiver bloqueado."]}
  ];
  D.EASTER_PREF_DEFAULTS={effectsEnabled:true,soundsEnabled:true,activeEffect:"",seasonMode:"auto",previousTheme:"",intensity:"normal",audioVolume:.72,syncTheme:false,interactivesEnabled:true,activeInteractive:"",interactiveQuiet:true,arcadeDifficulty:"normal"};
  D.EASTER_SEASONS=[
    {id:"auto",label:"Automático",icon:"◌",accent:"#00c875",desc:"Usa a data atual."},
    {id:"off",label:"Desativado",icon:"○",accent:"#7d8790",desc:"Sem decoração sazonal."},
    {id:"holiday",label:"Natal",icon:"✦",accent:"#ffd166",desc:"Neve, luzes e brilho dourado."},
    {id:"halloween",label:"Halloween",icon:"☾",accent:"#ff8c42",desc:"Lua, sombras e tons laranja/roxo."},
    {id:"newyear",label:"Ano Novo",icon:"✧",accent:"#70d6ff",desc:"Fogos, estrelas e energia azul."}
  ];
  D.EASTER_ALLOWED_REWARD_IDS=["goldenCat"];
  D.EASTER_SEASON_PALETTES={
    holiday:{"--extui-primary":"#2bc47d","--extui-primary-bright":"#7cf2b2","--extui-primary-dim":"#173d2c","--extui-bg":"#07110d","--extui-card":"#0c1913","--extui-card-2":"#12241b","--extui-card-3":"#183024","--extui-text":"#effff7","--extui-text-dim":"#a7c9b6","--extui-text-faint":"#789887","--extui-border":"#284a38","--extui-border-strong":"#3d674f","--extui-border-subtle":"#1d372a","--extui-surface-hover":"#14291f","--extui-surface-active":"#1b3528","--extui-warning":"#ffd166"},
    halloween:{"--extui-primary":"#ff8c42","--extui-primary-bright":"#c77dff","--extui-primary-dim":"#4a2615","--extui-bg":"#0d0710","--extui-card":"#160c1a","--extui-card-2":"#211129","--extui-card-3":"#2c1738","--extui-text":"#fff5ea","--extui-text-dim":"#c9adc7","--extui-text-faint":"#937991","--extui-border":"#493052","--extui-border-strong":"#64406f","--extui-border-subtle":"#321f3b","--extui-surface-hover":"#25132d","--extui-surface-active":"#32183d","--extui-warning":"#ffb36b"},
    newyear:{"--extui-primary":"#70d6ff","--extui-primary-bright":"#ffd166","--extui-primary-dim":"#17394a","--extui-bg":"#050b14","--extui-card":"#0a1320","--extui-card-2":"#101e30","--extui-card-3":"#172a41","--extui-text":"#f4fbff","--extui-text-dim":"#a9c2d3","--extui-text-faint":"#7893a6","--extui-border":"#29445a","--extui-border-strong":"#3c607a","--extui-border-subtle":"#1b3346","--extui-surface-hover":"#12263a","--extui-surface-active":"#183149","--extui-warning":"#ffd166"}
  };
  D.EASTER_SEASON_LIGHT_PALETTES={
    holiday:{"--extui-primary":"#1d8d5a","--extui-primary-bright":"#28734d","--extui-primary-dim":"#dff5e8","--extui-bg":"#f1f7f3","--extui-card":"#ffffff","--extui-card-2":"#eaf4ed","--extui-card-3":"#dfece3","--extui-text":"#203127","--extui-text-dim":"#60766a","--extui-text-faint":"#829489","--extui-border":"#cfdfd4","--extui-border-strong":"#b3caba","--extui-border-subtle":"#e2ece5","--extui-surface-hover":"#eaf3ed","--extui-surface-active":"#dfebe3","--extui-warning":"#9a6c14"},
    halloween:{"--extui-primary":"#b95d1d","--extui-primary-bright":"#7b45a7","--extui-primary-dim":"#fde9d9","--extui-bg":"#f8f3f8","--extui-card":"#ffffff","--extui-card-2":"#f4eaf5","--extui-card-3":"#eaddec","--extui-text":"#352737","--extui-text-dim":"#756579","--extui-text-faint":"#96869a","--extui-border":"#dfd1e1","--extui-border-strong":"#c6b3ca","--extui-border-subtle":"#eee5ef","--extui-surface-hover":"#f2e9f3","--extui-surface-active":"#e8ddea","--extui-warning":"#a55b19"},
    newyear:{"--extui-primary":"#257ea2","--extui-primary-bright":"#9a741d","--extui-primary-dim":"#dff2fa","--extui-bg":"#f0f6fa","--extui-card":"#ffffff","--extui-card-2":"#e7f1f7","--extui-card-3":"#dbe8f0","--extui-text":"#1f303b","--extui-text-dim":"#5d7482","--extui-text-faint":"#8094a0","--extui-border":"#cedee7","--extui-border-strong":"#b1c7d4","--extui-border-subtle":"#e2ebf0","--extui-surface-hover":"#e8f1f6","--extui-surface-active":"#dce8ef","--extui-warning":"#95701c"}
  };
  D.SECRET_THEME_BY_CHEAT={godmode:"aureus",rain:"signalrain",party:"festivalpop",retro:"retrowave",coffee:"espresso",overdrive:"velocityred","42":"cosmos42",glitch:"glitchcore",neon:"neoncore",zen:"zenith",xyzzy:"portalvoid",brasa:"brasaviva",oceano:"oceanoazul",pixel:"pixelpop"};
  D.CHEAT_EGGS=[
    {id:"matrix",code:"MATRIX",label:"MATRIX",desc:"Tema secreto verde digital, inspirado em terminal e código."},
    {id:"godmode",code:"MODO DEUS",label:"MODO DEUS",desc:"HUD dourado e aura de invencibilidade visual."},
    {id:"rain",code:"CHUVA",label:"CHUVA",desc:"Chuva de código verde/ciano sobre a interface."},
    {id:"party",code:"FESTA",label:"FESTA",desc:"Confetes, brilho multicolorido e clima de comemoração."},
    {id:"retro",code:"RETRO",label:"RETRO",desc:"CRT âmbar, scanlines e som 8-bit."},
    {id:"coffee",code:"CAFE",label:"CAFÉ",desc:"Modo café quente, vapor e um acorde relaxado."},
    {id:"overdrive",code:"SOBRECARGA",label:"SOBRECARGA",desc:"Núcleo vermelho elétrico, velocidade e sobrecarga visual."},
    {id:"42",code:"42",label:"42",desc:"Modo cósmico. A resposta existe; a pergunta continua aberta."},
    {id:"glitch",code:"FALHA",label:"FALHA",desc:"Aberração cromática, cortes digitais e áudio quebrado."},
    {id:"neon",code:"NEON",label:"NEON",desc:"Synthwave roxo/ciano com horizonte neon."},
    {id:"zen",code:"ZEN",label:"ZEN",desc:"Pulso suave, baixa distração e campainhas calmas."},
    {id:"xyzzy",code:"XYZZY",label:"XYZZY",desc:"Portal giratório azul/roxo inspirado em adventures de texto."},
    {id:"brasa",code:"BRASA",label:"BRASA",desc:"Faíscas quentes, brilho alaranjado e clima de fornalha elegante."},
    {id:"oceano",code:"OCEANO",label:"OCEANO",desc:"Ondas suaves, bolhas leves e reflexos azuis refrescantes."},
    {id:"pixel",code:"PIXEL",label:"PIXEL",desc:"Blocos coloridos, brilho arcade e energia 8-bit sobre a interface."}
  ];
  D.CHEAT_ROOT_CLASSES=["extuiCheatGodMode","extuiCheatRetro","extuiCheatOverdrive","extuiCheatCoffee","extuiCheatAnswer","extuiCheatGlitch","extuiCheatNeon","extuiCheatZen","extuiCheatPartyMode","extuiCheatRainMode","extuiCheatXyzzy","extuiCheatBrasa","extuiCheatOceano","extuiCheatPixel"];
})(window);
