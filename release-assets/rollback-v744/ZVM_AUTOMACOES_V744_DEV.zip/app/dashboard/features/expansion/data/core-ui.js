;(function(root){
  "use strict";
  var D=root.__extExpansionStaticData||(root.__extExpansionStaticData={});
  D.KEYS={
    favorites:"EXTUI:extappGlobalFavorites",achievements:"EXTUI:extappAchievements",eggs:"EXTUI:extappEasterEggs",templates:"EXTUI:extappTemplateInstallations",
    crm:"EXTUI:CrmStore",pro:"EXTUI:crmProfessionalStore",flows:"EXTUI:extappFlowStore",funnels:"EXTUI:extappFunnelStore",followup:"EXTUI:extappFollowUpStore",followupQueue:"EXTUI:extappFollowUpQueueStore",
    agenda:"EXTUI:extappScheduleStore",activity:"EXTUI:extappActivityStore",webhooks:"EXTUI:extappWebhookStore",backupIndex:"EXTUI:autoBackupFileIndex",wpp:"EXTUI:wppStatus",
    messages:"EXTUI:textMessageStore",quickResponses:"EXTUI:extappQuickResponseStore",interactiveLists:"EXTUI:interactiveListStore",integrations:"EXTUI:integrationsStore",integrationSecrets:"EXTUI:integrationSecrets",
    externalActions:"EXTUI:externalActionsStore",externalActionSecrets:"EXTUI:externalActionSecrets",webhookSecrets:"EXTUI:webhookSecrets"
  };
  D.ICONS={
    core:'<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3"/><path d="m4.2 4.2 2.1 2.1M17.7 17.7l2.1 2.1M19.8 4.2l-2.1 2.1M6.3 17.7l-2.1 2.1"/>',
    heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/>',
    box:'<path d="m21 8-9-5-9 5 9 5 9-5Z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
    shield:'<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3Z"/><path d="m9 12 2 2 4-4"/>',
    activity:'<path d="M3 12h4l2-7 4 14 2-7h6"/>',
    spark:'<path d="M12 3l1.8 4.2L18 9l-4.2 1.8L12 15l-1.8-4.2L6 9l4.2-1.8Z"/><path d="M19 14l.9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9Z"/>',
    calendar:'<path d="M8 2v3M16 2v3"/><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 10h18"/>',
    link:'<path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7.1 7.1l1.1-1.1"/>',
    trophy:'<path d="M8 21h8M12 17v4"/><path d="M7 4h10v4a5 5 0 0 1-10 0Z"/><path d="M7 6H4a2 2 0 0 0 2 4h1M17 6h3a2 2 0 0 1-2 4h-1"/>',
    star:'<path d="m12 2.8 2.72 5.51 6.08.88-4.4 4.29 1.04 6.06L12 16.68l-5.44 2.86 1.04-6.06-4.4-4.29 6.08-.88Z"/>',
    download:'<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
    lock:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    alert:'<path d="M12 3 2.5 20h19Z"/><path d="M12 9v4M12 17h.01"/>',
    search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15M10 11v6M14 11v6"/>',
    refresh:'<path d="M20 7h-5V2"/><path d="M20 7a8 8 0 1 0 2 5"/>'
  };
  D.ACHIEVEMENTS=[
    {id:"first-crm",title:"Primeiro CRM",desc:"Criou o primeiro CRM.",rarity:"Comum",test:function(s){return s.crmCount>=1;}},
    {id:"first-flow",title:"Automação iniciada",desc:"Criou o primeiro Fluxo.",rarity:"Comum",test:function(s){return s.flows>=1;}},
    {id:"first-funnel",title:"Sequência montada",desc:"Criou o primeiro Funil.",rarity:"Comum",test:function(s){return s.funnels>=1;}},
    {id:"operator",title:"Operador Extensão",desc:"Chegou a 100 operações registradas.",rarity:"Incomum",test:function(s){return s.operations>=100;}},
    {id:"automation-master",title:"Maestro da Automação",desc:"Manteve pelo menos 5 automações ativas ao mesmo tempo.",rarity:"Rara",test:function(s){return s.activeAuto>=5;}},
    {id:"integrator",title:"Conectado ao ecossistema",desc:"Ativou um Webhook.",rarity:"Incomum",test:function(s){return s.activeWebhooks>=1;}},
    {id:"collector",title:"Colecionador",desc:"Salvou 5 favoritos globais.",rarity:"Comum",test:function(s){return s.favorites>=5;}},
    {id:"architect",title:"Arquiteto",desc:"Instalou 2 modelos da Central.",rarity:"Incomum",test:function(s){return s.templates>=2;}},
    {id:"secret-signal",title:"O Núcleo Respondeu",desc:"Encontrou o primeiro segredo da extensão.",hint:"Há coisas na extensão que não aparecem em menus comuns.",hidden:true,rarity:"Rara",test:function(s){return s.secretDiscoveries>=1;}},
    {id:"secret-curator",title:"Curador do Núcleo",desc:"Registrou 5 descobertas secretas. Recompensa: Gato Dourado.",hint:"Uma coleção secreta começa a reconhecer quem insiste em explorá-la.",hidden:true,reward:"golden-cat",rarity:"Épica",test:function(s){return s.secretDiscoveries>=5;}},
    {id:"arcade-winner",title:"Ficha Premiada",desc:"Venceu a primeira partida da extensão Arcade.",hint:"Algumas descobertas não terminam quando são encontradas.",hidden:true,rarity:"Rara",test:function(s){return s.arcadeWins>=1;}},
    {id:"final-boss",title:"FINAL BOSS",desc:"10.000 operações registradas. Você claramente não veio aqui para brincar.",hint:"Existe um marco para quem transforma a extensão em rotina de verdade.",hidden:true,rarity:"Lendária",test:function(s){return s.operations>=10000;}},
    {id:"platinum",title:"Platina extensão",desc:"Desbloqueou todas as outras conquistas da coleção.",hint:"A última conquista só existe quando nenhuma outra permanece bloqueada.",hidden:true,platinum:true,rarity:"Platina",test:function(){return false;}}
  ];
})(window);
