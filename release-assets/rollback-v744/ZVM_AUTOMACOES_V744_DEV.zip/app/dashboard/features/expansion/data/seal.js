;(function(root){
  "use strict";
  if(!root.__extExpansionStaticData) throw new Error("Dados estáticos ausentes.");
  Object.freeze(root.__extExpansionStaticData);
})(window);
