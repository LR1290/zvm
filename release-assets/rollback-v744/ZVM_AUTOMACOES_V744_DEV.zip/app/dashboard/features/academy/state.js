;
try{
(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extAcademyStateCore = api;
})(typeof window !== "undefined" ? window : null, function () {
  "use strict";

  var PHASES = Object.freeze({
    IDLE: "IDLE",
    NAVIGATING: "NAVIGATING",
    ACTIVE: "ACTIVE",
    SUSPENDED: "SUSPENDED",
    RECOVERY: "RECOVERY",
    LOCKED: "LOCKED",
    COMPLETED: "COMPLETED",
    EXITED: "EXITED"
  });

  function clone(value) {
    if (value == null) return value;
    return JSON.parse(JSON.stringify(value));
  }

  function indexLessons(lessons, defaultContext) {
    var byId = {};
    (Array.isArray(lessons) ? lessons : []).forEach(function (lesson) {
      if (!lesson || typeof lesson.id !== "string" || !lesson.id) return;
      var sourceSteps = Array.isArray(lesson.steps) && lesson.steps.length
        ? lesson.steps
        : [{ id: "welcome", context: lesson.context || defaultContext }];
      var steps = sourceSteps.filter(function (step) {
        return step && typeof step.id === "string" && step.id;
      }).map(function (step) {
        return Object.assign({}, step, {
          context: step.context || lesson.context || defaultContext
        });
      });
      if (!steps.length) return;
      byId[lesson.id] = Object.assign({}, lesson, { steps: steps });
    });
    return byId;
  }

  function normalizeState(raw, lessonIndex, version) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); }
      catch (err) { raw = null; }
    }
    raw = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
    var lessons = {};
    Object.keys(lessonIndex).forEach(function (lessonId) {
      lessons[lessonId] = !!(raw.lessons && raw.lessons[lessonId]);
    });
    return Object.assign({}, raw, {
      academyVersion: Number.isFinite(Number(raw.academyVersion)) ? Number(raw.academyVersion) : version,
      lessons: lessons,
      currentLessonId: typeof raw.currentLessonId === "string" ? raw.currentLessonId : null,
      currentStepId: typeof raw.currentStepId === "string" ? raw.currentStepId : null,
      currentContext: typeof raw.currentContext === "string" ? raw.currentContext : null,
      pendingTransition: raw.pendingTransition && typeof raw.pendingTransition === "object" ? raw.pendingTransition : null,
      lastCompletedTransitionId: typeof raw.lastCompletedTransitionId === "string" ? raw.lastCompletedTransitionId : null
    });
  }

  function resolvePosition(state, lessonIndex, requestedLessonId) {
    var lessonId = requestedLessonId || state.currentLessonId;
    var lesson = lessonIndex[lessonId];
    if (!lesson) return null;
    var step = null;
    if (state.currentLessonId === lessonId) {
      step = lesson.steps.find(function (candidate) {
        return candidate.id === state.currentStepId && candidate.context === state.currentContext;
      }) || null;
    }
    if (!step) step = lesson.steps[0];
    return {
      lesson: lesson,
      lessonId: lesson.id,
      step: step,
      stepId: step.id,
      context: step.context,
      index: lesson.steps.indexOf(step)
    };
  }

  function isActivePosition(state, lessonIndex, requestedLessonId) {
    var lessonId = requestedLessonId || state.currentLessonId;
    var lesson = lessonIndex[lessonId];
    if (!lesson || state.currentLessonId !== lessonId) return false;
    return lesson.steps.some(function (step) {
      return step.id === state.currentStepId && step.context === state.currentContext;
    });
  }

  function createMachine(options) {
    options = options || {};
    var adapter = options.adapter || {};
    if (typeof adapter.readState !== "function" || typeof adapter.writeState !== "function" || typeof adapter.navigate !== "function") {
      throw new TypeError("Academy requires readState, writeState and navigate adapters");
    }
    var machineContext = options.context || "dashboard";
    var version = Number(options.version) || 1;
    var lessons = indexLessons(options.lessons, machineContext);
    var idFactory = typeof options.idFactory === "function"
      ? options.idFactory
      : function () { return "extuia-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8); };
    var generation = 0;
    var snapshot = Object.freeze({ phase: PHASES.IDLE, reason: "boot", position: null, recovery: null, generation: generation });

    function publish(phase, reason, position, recovery) {
      snapshot = Object.freeze({
        phase: phase,
        reason: reason || "",
        position: position ? clone({ lessonId: position.lessonId, stepId: position.stepId, context: position.context, index: position.index }) : null,
        recovery: recovery || null,
        generation: generation
      });
      if (typeof adapter.onStateChange === "function") {
        try { adapter.onStateChange(snapshot); }
        catch (err) { if (typeof globalThis !== "undefined" && globalThis.__extReportRuntimeError) globalThis.__extReportRuntimeError("ACADEMY_STATE_CALLBACK_FAILED", err); }
      }
      return snapshot;
    }

    async function authorized() {
      if (typeof adapter.isAuthorized !== "function") return true;
      try { return (await adapter.isAuthorized()) === true; }
      catch (err) { return false; }
    }

    async function read() {
      return normalizeState(await adapter.readState(), lessons, version);
    }

    async function write(state) {
      await adapter.writeState(clone(state));
      return state;
    }

    function transitionFor(position) {
      var id = idFactory();
      return {
        id: id,
        transitionId: id,
        lessonId: position.lessonId,
        stepId: position.stepId,
        destinationContext: position.context,
        destinationRoute: position.step.section || null,
        panel: position.step.panel || null,
        requestedAt: Date.now()
      };
    }

    function withPosition(state, position, transition) {
      return Object.assign({}, state, {
        academyVersion: version,
        academyEntryMode: "manual",
        currentLessonId: position.lessonId,
        currentStepId: position.stepId,
        currentContext: position.context,
        pendingTransition: transition || null
      });
    }

    async function navigatePosition(position, state, reason) {
      if (!(await authorized())) {
        publish(PHASES.LOCKED, "access-locked", position, null);
        return { ok: false, locked: true, reason: "access-locked", state: state, position: position };
      }
      var requestGeneration = ++generation;
      var crossContext = position.context !== machineContext;
      var transition = crossContext ? transitionFor(position) : null;
      var nextState = withPosition(state, position, transition);
      await write(nextState);
      if (requestGeneration !== generation) return { ok: false, stale: true, reason: "superseded" };
      publish(PHASES.NAVIGATING, reason || "navigate", position, null);
      try {
        var result = await adapter.navigate(position, transition);
        if (requestGeneration !== generation) return { ok: false, stale: true, reason: "superseded" };
        if (!(await authorized())) {
          ++generation;
          publish(PHASES.LOCKED, "access-locked", position, null);
          return { ok: false, locked: true, reason: "access-locked", state: nextState, position: position };
        }
        if (!result || result.ok !== true || result.targetReady !== true) {
          throw new Error(result && result.error ? result.error : "A etapa não ficou pronta.");
        }
        if (transition) {
          var fresh = await read();
          if (fresh.pendingTransition && (fresh.pendingTransition.id === transition.id || fresh.pendingTransition.transitionId === transition.id)) {
            fresh.pendingTransition = null;
            fresh.lastCompletedTransitionId = transition.id;
            await write(fresh);
          }
          nextState = fresh;
        }
        publish(PHASES.ACTIVE, "ready", position, null);
        return { ok: true, state: nextState, position: position, transitionId: transition && transition.id, result: result };
      } catch (error) {
        if (requestGeneration !== generation) return { ok: false, stale: true, reason: "superseded" };
        var recovery = Object.freeze({ retry: true, skipStep: true, exit: true, message: error && error.message ? error.message : String(error) });
        publish(PHASES.RECOVERY, "navigation-failed", position, recovery);
        return { ok: false, recoverable: true, error: error, state: nextState, position: position, recovery: recovery };
      }
    }

    async function run(mode, lessonId) {
      var state = await read();
      var lesson = lessons[lessonId];
      if (!lesson) {
        publish(PHASES.IDLE, "lesson-not-found", null, null);
        return { ok: false, reason: "lesson-not-found", state: state };
      }
      if (!(await authorized())) {
        publish(PHASES.LOCKED, "access-locked", resolvePosition(state, lessons, lessonId), null);
        return { ok: false, locked: true, reason: "access-locked", state: state };
      }
      if (mode === "restart") {
        state.lessons = Object.assign({}, state.lessons);
        state.lessons[lessonId] = false;
        state.pendingTransition = null;
      }
      var position = mode === "resume"
        ? resolvePosition(state, lessons, lessonId)
        : { lesson: lesson, lessonId: lesson.id, step: lesson.steps[0], stepId: lesson.steps[0].id, context: lesson.steps[0].context, index: 0 };
      return navigatePosition(position, state, mode);
    }

    async function currentPosition() {
      var state = await read();
      return { state: state, position: resolvePosition(state, lessons) };
    }

    async function retry() {
      var current = await currentPosition();
      if (!current.position) return { ok: false, reason: "no-active-step" };
      return navigatePosition(current.position, current.state, "retry");
    }

    async function advance(reason) {
      var current = await currentPosition();
      var position = current.position;
      if (!position || !isActivePosition(current.state, lessons)) return { ok: false, reason: "no-active-step" };
      if (!(await authorized())) {
        publish(PHASES.LOCKED, "access-locked", position, null);
        return { ok: false, locked: true, reason: "access-locked", state: current.state, position: position };
      }
      var nextStep = position.lesson.steps[position.index + 1];
      if (nextStep) {
        return navigatePosition({
          lesson: position.lesson,
          lessonId: position.lessonId,
          step: nextStep,
          stepId: nextStep.id,
          context: nextStep.context,
          index: position.index + 1
        }, current.state, reason || "next");
      }
      var completed = Object.assign({}, current.state, {
        lessons: Object.assign({}, current.state.lessons),
        currentLessonId: null,
        currentStepId: null,
        currentContext: null,
        pendingTransition: null
      });
      completed.lessons[position.lessonId] = true;
      if (Object.keys(lessons).every(function (lessonId) { return completed.lessons[lessonId]; })) {
        completed.completedVersion = version;
      }
      await write(completed);
      ++generation;
      publish(PHASES.COMPLETED, "lesson-complete", position, null);
      return { ok: true, completed: true, state: completed, position: position };
    }

    async function previous() {
      var current = await currentPosition();
      var position = current.position;
      if (!position || !isActivePosition(current.state, lessons)) return { ok: false, reason: "no-active-step" };
      var previousStep = position.lesson.steps[position.index - 1];
      if (!previousStep) return { ok: false, reason: "first-step", state: current.state, position: position };
      return navigatePosition({
        lesson: position.lesson,
        lessonId: position.lessonId,
        step: previousStep,
        stepId: previousStep.id,
        context: previousStep.context,
        index: position.index - 1
      }, current.state, "previous");
    }

    function suspend(reason) {
      ++generation;
      publish(PHASES.SUSPENDED, reason || "manual-navigation", snapshot.position, null);
      return snapshot;
    }

    function exit(reason) {
      ++generation;
      publish(PHASES.EXITED, reason || "exit", snapshot.position, null);
      return snapshot;
    }

    function lock(reason) {
      ++generation;
      publish(PHASES.LOCKED, reason || "access-locked", snapshot.position, null);
      return snapshot;
    }

    async function skipLesson() {
      var state = await read();
      if (!(await authorized())) {
        publish(PHASES.LOCKED, "access-locked", resolvePosition(state, lessons), null);
        return { ok: false, locked: true, reason: "access-locked", state: state };
      }
      state.currentLessonId = null;
      state.currentStepId = null;
      state.currentContext = null;
      state.pendingTransition = null;
      await write(state);
      ++generation;
      publish(PHASES.EXITED, "lesson-skipped", null, null);
      return { ok: true, skipped: true, state: state };
    }

    return Object.freeze({
      startLesson: function (lessonId) { return run("start", lessonId); },
      resumeLesson: function (lessonId) { return run("resume", lessonId); },
      restartLesson: function (lessonId) { return run("restart", lessonId); },
      next: function () { return advance("next"); },
      previous: previous,
      retry: retry,
      skipStep: function () { return advance("skip-step"); },
      skipLesson: skipLesson,
      exit: exit,
      lock: lock,
      suspend: suspend,
      returnToStep: retry,
      getSnapshot: function () { return snapshot; },
      readState: read
    });
  }

  function createCommandCoordinator(handler) {
    if (typeof handler !== "function") throw new TypeError("Command coordinator requires a handler");
    var pending = Object.create(null);
    var completed = Object.create(null);
    var order = [];
    function execute(command) {
      var id = command && (command.transitionId || command.id);
      if (typeof id !== "string" || !id) return Promise.reject(new Error("academyNavigate requires transitionId"));
      if (Object.prototype.hasOwnProperty.call(completed, id)) return Promise.resolve(completed[id]);
      if (pending[id]) return pending[id];
      pending[id] = Promise.resolve().then(function () { return handler(command); }).then(function (result) {
                                                                            
                                                                           
        if (result && result.ok === true) {
          completed[id] = result;
          order.push(id);
          if (order.length > 64) delete completed[order.shift()];
        }
        return result;
      }).finally(function () { delete pending[id]; });
      return pending[id];
    }
    return Object.freeze({ execute: execute });
  }

  return Object.freeze({
    PHASES: PHASES,
    normalizeState: normalizeState,
    isActivePosition: isActivePosition,
    createMachine: createMachine,
    createCommandCoordinator: createCommandCoordinator
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
