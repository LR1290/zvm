;
try{
(function () {
  "use strict";

  var ts = window.__extThemeSystem;
  if (!ts) {
    return;
  }

  var FONT_OPTIONS = [
    { id: "system", label: "Sistema" },
    { id: "segoe", label: "Segoe UI" },
    { id: "arial", label: "Arial / Helvetica" },
    { id: "aureus", label: "Aureus (serif clássica)" },
    { id: "retro", label: "CRT Âmbar / Retrowave" },
    { id: "matrix", label: "Matrix / Signal Rain" },
    { id: "espresso", label: "Expresso (serif suave)" }
  ];
  var MOTION_OPTIONS = [
    { id: "auto", label: "Automático (segue o sistema)" },
    { id: "normal", label: "Normal" },
    { id: "reduced", label: "Reduzido" },
    { id: "off", label: "Desativado" }
  ];
  var RADIUS_OPTIONS = [
    { id: "compact", label: "Discreto" },
    { id: "default", label: "Padrão" },
    { id: "rounded", label: "Arredondado" }
  ];

  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function flashSaved(card) { var el=card.querySelector(".extuiAjustesSavedNote"); if(!el)return;el.classList.add("extuiShow");clearTimeout(el._extuiTimer);el._extuiTimer=setTimeout(function(){el.classList.remove("extuiShow");},1200); }
  function optionHtml(list) { return list.map(function(x){return '<option value="'+x.id+'">'+x.label+'</option>';}).join(""); }
  function clamp(v,min,max,fallback){v=Number(v);return Number.isFinite(v)?Math.max(min,Math.min(max,v)):fallback;}
  function extMiniRecordTime(ms){ms=Math.max(0,Math.floor(Number(ms)||0));var total=Math.floor(ms/1000),h=Math.floor(total/3600),m=Math.floor((total%3600)/60),sec=total%60;return h?String(h)+":"+String(m).padStart(2,"0")+":"+String(sec).padStart(2,"0"):String(m).padStart(2,"0")+":"+String(sec).padStart(2,"0");}
  function syncRangeVisual(input){if(!input||input.type!=="range")return;var min=Number(input.min||0),max=Number(input.max||100),value=Number(input.value||min),span=max-min,pct=span>0?((value-min)/span)*100:0;input.style.setProperty("--extui-range-progress",Math.max(0,Math.min(100,pct)).toFixed(2)+"%");}

  function renderAparenciaCard(wrap, opts) {
    var card=document.createElement("div");card.className="extuiCard extuiPersonalizacaoAppearanceCard";
    var secretUnlockRaw=null;
    function secretThemeUnlocked(t){
      if(!t||!t.secret)return true;
      if(secretUnlockRaw){var codes=secretUnlockRaw.cheatcodes&&typeof secretUnlockRaw.cheatcodes==="object"&&!Array.isArray(secretUnlockRaw.cheatcodes)?secretUnlockRaw.cheatcodes:{};if(t.id==="matrix")return !!secretUnlockRaw.matrix;return !!codes[t.secretKey||t.id];}
      if(t.id==="matrix")return window.__extSecretThemeUnlocked===true;
      var unlocked=window.__extSecretThemeUnlocks||{};return !!unlocked[t.secretKey||t.id];
    }
    var THEME_ORDER=["extapp","padrao"];
    function secretThemes(){return Object.keys(ts.themes).map(function(id){return ts.themes[id];}).filter(function(t){return !!(t&&t.secret);});}
    function regularThemes(){var regular=Object.keys(ts.themes).map(function(id){return ts.themes[id];}).filter(function(t){return !!(t&&!t.secret);}),rank={};THEME_ORDER.forEach(function(id,index){rank[id]=index;});return regular.sort(function(a,b){var ar=Object.prototype.hasOwnProperty.call(rank,a.id)?rank[a.id]:100+Object.keys(ts.themes).indexOf(a.id),br=Object.prototype.hasOwnProperty.call(rank,b.id)?rank[b.id]:100+Object.keys(ts.themes).indexOf(b.id);return ar-br;});}
    function secretThemeSignature(){return secretThemes().map(function(t){return t.id+":"+(secretThemeUnlocked(t)?"1":"0");}).join("|")+"|selected:"+String(opts&&opts.visualTheme||"");}
    function buildThemeButtons(){return regularThemes().map(function(t){var hint=t.id==="extapp"?"Identidade ZVM: superfície nativa do WhatsApp com ícones em verde ZVM.":t.id==="padrao"?"Padrão: preserva a superfície nativa do WhatsApp e usa o acento verde padrão da extensão.":"";return '<button type="button" class="extuiThemeTile" data-visual-theme="'+t.id+'"'+(hint?' title="'+hint+'"':'')+'><span class="extuiThemeTilePreview" data-preview-theme="'+t.id+'"></span><span>'+t.label+'</span></button>';}).join("");}
    function unlockedSecretCount(){return secretThemes().filter(secretThemeUnlocked).length;}
    var themeButtons=buildThemeButtons();
    var colorButtons=Object.keys(ts.icon3dColors).map(function(id){var c=ts.icon3dColors[id];return '<button type="button" class="extuiIconColorChoice" data-icon-color="'+id+'" title="'+c.label+'"><span style="background:'+c.bg+'"></span>'+c.label+'</button>';}).join("");
    card.innerHTML =
      '<div class="extuiPersonalizacaoCardGrid">'+
      '<div class="extuiPersonalizacaoColLeft">'+
        '<div class="extuiAjustesGroupLabel">Definições</div>'+
        '<div class="extuiThemeRadioRow" id="extuiDefinitionRow">'+
          '<button type="button" class="extuiThemeRadioBtn" data-definition="default">Padrão</button>'+
          '<button type="button" class="extuiThemeRadioBtn" data-definition="custom">Personalizado</button>'+
        '</div>'+
        '<div class="extuiAjustesKeyLabel">Padrão usa as definições de fábrica. Ao alterar qualquer opção, o estado muda automaticamente para Personalizado.</div>'+

        '<div class="extuiAjustesGroupLabel">Modo</div>'+
        '<div class="extuiThemeRadioRow" id="extuiModeRow">'+
          '<button type="button" class="extuiThemeRadioBtn" data-mode="auto">Automático</button>'+
          '<button type="button" class="extuiThemeRadioBtn" data-mode="dark">Escuro</button>'+
          '<button type="button" class="extuiThemeRadioBtn" data-mode="light">Claro</button>'+
        '</div>'+
        '<div class="extuiAjustesKeyLabel">Automático acompanha o WhatsApp Web na Sidebar e o sistema no Painel de Controle.</div>'+

        '<div class="extuiAjustesGroupLabel">Temas principais</div>'+
        '<div class="extuiThemeTileGrid" id="extuiVisualThemeGrid">'+themeButtons+'</div><div class="extuiThemeNativeExplain"><span><b>ZVM</b> mantém a superfície nativa do WhatsApp e aplica a identidade verde ZVM aos ícones.</span><span><b>Padrão</b> mantém a superfície nativa e usa o acento verde padrão da extensão.</span></div>'+

        '<div class="extuiAjustesGroupLabel">Tipografia</div>'+
        '<div class="extuiAjustesFieldRow"><label class="extuiAjustesFieldLabel" for="extuiFontSelect">Fonte da interface</label><select class="extuiAjustesSelect" id="extuiFontSelect">'+optionHtml(FONT_OPTIONS)+'</select></div>'+
        '<div class="extuiAjustesGroupLabel">Acessibilidade</div>'+
        '<div class="extuiRangeSetting extuiA11yTextScaleSetting"><div><span>Tamanho do texto</span><strong id="extuiA11yTextScaleValue"></strong></div><div class="extuiRangeControlRow"><input type="range" id="extuiA11yTextScale" min="100" max="200" step="10" aria-describedby="extuiA11yTextScaleHelp"><button type="button" class="extuiRangeResetBtn" id="extuiA11yTextScaleReset" title="Restaurar tamanho confortável" aria-label="Restaurar tamanho confortável"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.708"/><path d="M3 4v6h6"/></svg></button></div><div class="extuiAjustesKeyLabel" id="extuiA11yTextScaleHelp">Ajusta a tipografia da extensão de 100% a 200%. O padrão confortável é 110%.</div></div>'+
        '<label class="extuiPersonalizacaoCheck extuiA11yCheck"><input type="checkbox" id="extuiA11yContrast"> <span><strong>Contraste reforçado</strong><small>Torna textos secundários menos apagados e reforça foco e contornos importantes.</small></span></label>'+
        '<label class="extuiPersonalizacaoCheck extuiA11yCheck"><input type="checkbox" id="extuiA11yColorAssist"> <span><strong>Não depender apenas de cor</strong><small>Acrescenta formas e contornos diferentes aos estados selecionado, sucesso, atenção e erro.</small></span></label>'+
        '<div class="extuiA11yInfo" role="note"><strong>Compatível com zoom do navegador</strong><span>A interface continua preparada para Ctrl + / Ctrl −; Movimento abaixo também permite reduzir animações.</span></div>'+
        '<div class="extuiAjustesGroupLabel">Movimento</div>'+
        '<div class="extuiAjustesFieldRow"><label class="extuiAjustesFieldLabel" for="extuiMotionSelect">Animações</label><select class="extuiAjustesSelect" id="extuiMotionSelect">'+optionHtml(MOTION_OPTIONS)+'</select></div>'+
        '<div class="extuiAjustesGroupLabel">Arredondamento</div>'+
        '<div class="extuiThemeRadioRow" id="extuiRadiusRow">'+RADIUS_OPTIONS.map(function(x){return '<button type="button" class="extuiThemeRadioBtn" data-radius="'+x.id+'">'+x.label+'</button>';}).join("")+'</div>'+

        '<div class="extuiAjustesGroupLabel">Tema dos ícones</div>'+
        '<div class="extuiThemeRadioRow" id="extuiIconThemeRow">'+
          '<button type="button" class="extuiThemeRadioBtn" data-icon-theme="monochrome">Monocromático</button>'+
          '<button type="button" class="extuiThemeRadioBtn" data-icon-theme="color">Colorido</button>'+
          '<button type="button" class="extuiThemeRadioBtn" data-icon-theme="3d">3D</button>'+
        '</div>'+
        '<label class="extuiPersonalizacaoCheck"><input type="checkbox" id="extuiQuickShelfUseIconTheme"> Aplicar tema de ícones ao Menu Rápido</label>'+
        '<div class="extuiAjustesKeyLabel">Desativado por padrão para preservar as cores atuais do Menu Rápido. No tema Colorido, a aparência permanece igual com ou sem esta opção.</div>'+
        '<div id="extuiIcon3dColorBlock">'+
          '<div class="extuiAjustesGroupLabel extuiAjustesGroupLabel--nested">Cor dos ícones 3D</div>'+
          '<div class="extuiIconColorGrid" id="extuiIcon3dColorGrid">'+colorButtons+'</div>'+
        '</div>'+

        '<div class="extuiAjustesGroupLabel">Tamanho dos ícones do menu</div>'+
        '<div class="extuiRangeSetting"><div><span>Sidebar</span><strong id="extuiSidebarIconSizeValue"></strong></div><div class="extuiRangeControlRow"><input type="range" id="extuiSidebarIconSize" min="24" max="52" step="1"><button type="button" class="extuiRangeResetBtn" id="extuiSidebarIconSizeReset" title="Restaurar tamanho padrão" aria-label="Restaurar tamanho padrão"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.708"/><path d="M3 4v6h6"/></svg></button></div></div>'+
        '<label class="extuiPersonalizacaoCheck"><input type="checkbox" id="extuiDashboardUseSidebarIconSize"> Usar o mesmo tamanho no Painel de Controle</label>'+
        '<div class="extuiRangeSetting" id="extuiDashboardIconSizeRow"><div><span>Dashboard</span><strong id="extuiDashboardIconSizeValue"></strong></div><div class="extuiRangeControlRow"><input type="range" id="extuiDashboardIconSize" min="20" max="46" step="1"><button type="button" class="extuiRangeResetBtn" id="extuiDashboardIconSizeReset" title="Restaurar tamanho padrão" aria-label="Restaurar tamanho padrão"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.708"/><path d="M3 4v6h6"/></svg></button></div></div>'+
      '</div>'+

      '<div class="extuiPersonalizacaoColRight">'+
        '<div class="extuiAjustesGroupLabel">Ações</div>'+
        '<div class="extuiAjustesActionsRow"><button type="button" class="extui-btn extui-btn--ghost" id="extuiRestoreDefaults">Restaurar padrão</button><button type="button" class="extui-btn extui-btn--ghost" id="extuiThemeExport">⬇ Exportar tema</button><button type="button" class="extui-btn extui-btn--ghost" id="extuiThemeImport">⬆ Importar tema</button><input type="file" id="extuiThemeImportFile" accept="application/json" hidden></div>'+
        '<div class="extuiPersonalizacaoReloadNotice" id="extuiSidebarReloadNotice" hidden>Personalização aplicada também à Sidebar em tempo real.</div>'+
        '<div class="extuiArtLivePreview" aria-label="Prévia visual da interface">'+
          '<div class="extuiArtLivePreviewTop"><span>PRÉVIA AO VIVO</span><b></b><b></b><b></b></div>'+
          '<div class="extuiArtLivePreviewShell"><aside><i></i><i></i><i></i><i></i><i></i></aside><div class="extuiArtLivePreviewCanvas"><div class="extuiArtLivePreviewHero"><span></span><strong>Aparência</strong><small>Interface em tempo real</small></div><div class="extuiArtLivePreviewStats"><i></i><i></i><i></i></div><div class="extuiArtLivePreviewRows"><span></span><span></span><span></span><span></span></div></div></div>'+
          '<p>Esta miniatura usa as mesmas cores, contraste e arredondamento escolhidos para a interface.</p>'+
        '</div>'+
      '</div></div>';

    (function setupAdvancedAppearanceDisclosure(){
      var left=card.querySelector('.extuiPersonalizacaoColLeft');if(!left)return;
      var nodes=Array.prototype.slice.call(left.children),start=-1;
      nodes.forEach(function(node,index){if(start<0&&node.classList.contains('extuiAjustesGroupLabel')&&(node.textContent||'').trim()==='Tipografia')start=index;});
      if(start<0)return;
      for(var i=start;i<nodes.length;i++)nodes[i].classList.add('extuiAppearanceAdvancedItem');
      var toggle=document.createElement('button');toggle.type='button';toggle.className='extuiAppearanceAdvancedToggle';toggle.setAttribute('aria-expanded','false');toggle.innerHTML='<span><strong>Mais opções visuais</strong><small>Tipografia, movimento, ícones e tamanhos</small></span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
      left.insertBefore(toggle,nodes[start]);
      toggle.addEventListener('click',function(){var expanded=left.classList.toggle('extuiAppearanceAdvancedOpen');toggle.setAttribute('aria-expanded',String(expanded));});
    })();

    card.addEventListener("input",function(event){var target=event.target;if(target&&target.matches&&target.matches('input[type="range"]'))syncRangeVisual(target);});

    function updateUi() {
      var grid=card.querySelector("#extuiVisualThemeGrid"),secretSync=secretThemeSignature();
      if(grid&&grid.dataset.secretSync!==secretSync){grid.innerHTML=buildThemeButtons();grid.dataset.secretSync=secretSync;}
      bindThemeButtons();
      var progress=card.querySelector("#extuiSecretThemeProgress");if(progress)progress.textContent=unlockedSecretCount()+"/"+secretThemes().length;var activeSecret=ts.themes&&ts.themes[opts.visualTheme],activeSecretLabel=card.querySelector("#extuiSecretThemeActive");if(activeSecretLabel)activeSecretLabel.textContent=activeSecret&&activeSecret.secret?"Tema secreto ativo: "+activeSecret.label:"Nenhum tema secreto ativo no momento.";
      opts=ts.withDefinition(opts);ts.apply(opts);
      card.querySelectorAll("[data-definition]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.definition===opts.appearanceDefinition);});
      card.querySelectorAll("[data-mode]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.mode===opts.mode);});
      card.querySelectorAll("[data-visual-theme]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.visualTheme===opts.visualTheme);});
      card.querySelector("#extuiFontSelect").value=opts.fontFamily;
      var a11yScale=clamp(opts.accessibilityTextScale,100,200,110);card.querySelector("#extuiA11yTextScale").value=String(a11yScale);card.querySelector("#extuiA11yTextScaleValue").textContent=a11yScale+"%";card.querySelector("#extuiA11yContrast").checked=opts.accessibilityContrast!=="standard";card.querySelector("#extuiA11yColorAssist").checked=opts.accessibilityColorAssist!==false;
      card.querySelector("#extuiMotionSelect").value=opts.motion;
      card.querySelectorAll("[data-radius]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.radius===opts.radiusPreset);});
      card.querySelectorAll("[data-icon-theme]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.iconTheme===opts.iconTheme);});
      card.querySelector("#extuiIcon3dColorBlock").hidden=opts.iconTheme!=="3d";
      card.querySelector("#extuiQuickShelfUseIconTheme").checked=opts.quickShelfUseIconTheme===true;
      card.querySelector("#extuiQuickShelfUseIconTheme").disabled=opts.iconTheme==="color";
      card.querySelectorAll("[data-icon-color]").forEach(function(b){b.classList.toggle("extuiActive",b.dataset.iconColor===opts.icon3dColor);});
      var s=clamp(opts.sidebarMainIconSize,24,52,36),d=clamp(opts.dashboardMenuIconSize,20,46,28);
      card.querySelector("#extuiSidebarIconSize").value=String(s);card.querySelector("#extuiSidebarIconSizeValue").textContent=s+" px";
      card.querySelector("#extuiDashboardUseSidebarIconSize").checked=opts.dashboardUseSidebarIconSize===true;
      card.querySelector("#extuiDashboardIconSizeRow").hidden=opts.dashboardUseSidebarIconSize===true;
      card.querySelector("#extuiDashboardIconSize").value=String(d);card.querySelector("#extuiDashboardIconSizeValue").textContent=d+" px";
      var exp=card.querySelector("#extuiThemeExport");exp.disabled=opts.appearanceDefinition==="default";exp.title=exp.disabled?"Altere alguma definição antes de exportar um tema personalizado.":"Exportar personalização";
      card.querySelectorAll('input[type="range"]').forEach(syncRangeVisual);
    }
    function showReloadNotice(){var n=card.querySelector("#extuiSidebarReloadNotice");n.hidden=false;clearTimeout(n._timer);n._timer=setTimeout(function(){n.hidden=true;},2200);}
    async function persist(reloadNotice) { try { opts=await ts.save(opts);updateUi();flashSaved(card);if(reloadNotice)showReloadNotice(); } catch(err){toast("Falha ao salvar a personalização.",true);} }

    card.querySelectorAll("[data-definition]").forEach(function(btn){btn.addEventListener("click",async function(){if(btn.dataset.definition!=="default")return;try{if(window.__extEasterControl&&typeof window.__extEasterControl.deactivate==="function")await window.__extEasterControl.deactivate();}catch(_){}var keep={};Object.keys(opts).forEach(function(k){if(!(k in ts.defaults))keep[k]=opts[k];});opts=Object.assign({},opts,ts.factory(),keep);await persist(true);} );});
    card.querySelectorAll("[data-mode]").forEach(function(btn){btn.addEventListener("click",function(){opts.mode=btn.dataset.mode;persist(true);});});
    function bindThemeButtons(){card.querySelectorAll("[data-visual-theme]").forEach(function(btn){if(btn.dataset.boundVisualTheme==="1")return;btn.dataset.boundVisualTheme="1";btn.addEventListener("click",async function(){if(btn.dataset.visualTheme==="padrao"){try{if(window.__extEasterControl&&typeof window.__extEasterControl.deactivate==="function")await window.__extEasterControl.deactivate();}catch(_){}}opts=ts.selectTheme(opts,btn.dataset.visualTheme);await persist(true);});});}
    bindThemeButtons();
    var openSecretThemesBtn=card.querySelector("#extuiOpenSecretThemes");if(openSecretThemesBtn)openSecretThemesBtn.addEventListener("click",function(){window.__extCorePendingTab="secrets";window.__extCorePendingSecretTab="themes";if(window.__extDashboardShell&&window.__extDashboardShell.showSection)window.__extDashboardShell.showSection("home");});
    card.querySelector("#extuiFontSelect").addEventListener("change",function(e){opts.fontFamily=e.target.value;persist(true);});
    card.querySelector("#extuiA11yTextScale").addEventListener("input",function(e){opts.accessibilityTextScale=clamp(e.target.value,100,200,110);card.querySelector("#extuiA11yTextScaleValue").textContent=opts.accessibilityTextScale+"%";ts.apply(opts);});
    card.querySelector("#extuiA11yTextScale").addEventListener("change",function(){persist(true);});
    card.querySelector("#extuiA11yTextScaleReset").addEventListener("click",function(){opts.accessibilityTextScale=Number(ts.defaults.accessibilityTextScale)||110;persist(true);});
    card.querySelector("#extuiA11yContrast").addEventListener("change",function(e){opts.accessibilityContrast=e.target.checked?"enhanced":"standard";persist(true);});
    card.querySelector("#extuiA11yColorAssist").addEventListener("change",function(e){opts.accessibilityColorAssist=e.target.checked;persist(true);});
    card.querySelector("#extuiMotionSelect").addEventListener("change",function(e){opts.motion=e.target.value;persist(true);});
    card.querySelectorAll("[data-radius]").forEach(function(btn){btn.addEventListener("click",function(){opts.radiusPreset=btn.dataset.radius;persist(true);});});
    card.querySelectorAll("[data-icon-theme]").forEach(function(btn){btn.addEventListener("click",function(){opts.iconTheme=btn.dataset.iconTheme;persist(true);});});
    card.querySelectorAll("[data-icon-color]").forEach(function(btn){btn.addEventListener("click",function(){opts.icon3dColor=btn.dataset.iconColor;persist(true);});});
    card.querySelector("#extuiQuickShelfUseIconTheme").addEventListener("change",function(e){opts.quickShelfUseIconTheme=e.target.checked;persist(true);});
    card.querySelector("#extuiSidebarIconSize").addEventListener("input",function(e){opts.sidebarMainIconSize=Number(e.target.value);card.querySelector("#extuiSidebarIconSizeValue").textContent=e.target.value+" px";ts.apply(opts);});
    card.querySelector("#extuiSidebarIconSize").addEventListener("change",function(){persist(true);});
    card.querySelector("#extuiSidebarIconSizeReset").addEventListener("click",function(){opts.sidebarMainIconSize=Number(ts.defaults.sidebarMainIconSize)||36;persist(true);});
    card.querySelector("#extuiDashboardUseSidebarIconSize").addEventListener("change",function(e){opts.dashboardUseSidebarIconSize=e.target.checked;persist(true);});
    card.querySelector("#extuiDashboardIconSize").addEventListener("input",function(e){opts.dashboardMenuIconSize=Number(e.target.value);card.querySelector("#extuiDashboardIconSizeValue").textContent=e.target.value+" px";ts.apply(opts);});
    card.querySelector("#extuiDashboardIconSize").addEventListener("change",function(){persist(true);});
    card.querySelector("#extuiDashboardIconSizeReset").addEventListener("click",function(){opts.dashboardMenuIconSize=Number(ts.defaults.dashboardMenuIconSize)||28;persist(true);});
    card.querySelector("#extuiRestoreDefaults").addEventListener("click",function(){var preserve={};Object.keys(opts).forEach(function(k){if(!(k in ts.defaults))preserve[k]=opts[k];});opts=Object.assign({},opts,ts.factory(),preserve);persist(true);toast("Aparência restaurada ao padrão.");});

    card.querySelector("#extuiThemeExport").addEventListener("click",function(){if(ts.matchesFactory(opts))return;var payload={format:"EXTAPP_THEME",version:2,createdAt:new Date().toISOString(),appearance:{mode:opts.mode,visualTheme:opts.visualTheme,fontFamily:opts.fontFamily,motion:opts.motion,radiusPreset:opts.radiusPreset,iconTheme:opts.iconTheme,icon3dColor:opts.icon3dColor,quickShelfUseIconTheme:opts.quickShelfUseIconTheme,sidebarMainIconSize:opts.sidebarMainIconSize,dashboardUseSidebarIconSize:opts.dashboardUseSidebarIconSize,dashboardMenuIconSize:opts.dashboardMenuIconSize,accessibilityTextScale:opts.accessibilityTextScale,accessibilityContrast:opts.accessibilityContrast,accessibilityColorAssist:opts.accessibilityColorAssist}};var blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});var url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="extapp-tema-"+new Date().toISOString().slice(0,10)+".json";document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},1500);});
    var input=card.querySelector("#extuiThemeImportFile"),THEME_IMPORT_MAX_BYTES=1024*1024;card.querySelector("#extuiThemeImport").addEventListener("click",function(){input.click();});input.addEventListener("change",function(){var f=input.files&&input.files[0];input.value="";if(!f)return;if(f.size>THEME_IMPORT_MAX_BYTES){toast("O arquivo de tema excede o limite seguro de 1 MB.",true);return;}var r=new FileReader();r.onload=function(){try{var j=JSON.parse(r.result);if(!j||j.format!=="EXTAPP_THEME"||!j.appearance)throw new Error("formato");Object.keys(j.appearance).forEach(function(k){if(k in ts.defaults)opts[k]=j.appearance[k];});opts=ts.normalize(opts);var importedTheme=ts.themes[opts.visualTheme];if(importedTheme&&importedTheme.secret&&!secretThemeUnlocked(importedTheme)){opts=ts.selectTheme(opts,"padrao");persist(true);toast("Tema importado. O tema secreto foi ignorado porque ainda não foi desbloqueado nesta licença.");return;}persist(true);toast("Tema importado.");}catch(e){toast("Arquivo de tema inválido.",true);}};r.onerror=function(){toast("Não foi possível ler o arquivo de tema.",true);};r.readAsText(f);});

    function syncExternalAppearance(ev){if(!card.isConnected){document.removeEventListener("ext:appearance-updated",syncExternalAppearance);return;}if(!ev||!ev.detail)return;opts=ts.normalize(Object.assign({},opts,ev.detail));updateUi();}
    document.addEventListener("ext:appearance-updated",syncExternalAppearance);
    function applySecretUnlockRaw(raw){secretUnlockRaw=raw&&typeof raw==="object"&&!Array.isArray(raw)?raw:{};updateUi();}
    function hydrateSecretUnlocks(){
      var api=window.__extEasterControl;
      if(api&&typeof api.getState==="function"){api.getState().then(function(state){if(card.isConnected)applySecretUnlockRaw(state&&state.raw);}).catch(function(){});return;}
      try{chrome.storage.local.get(["EXTUI:extappEasterEggs"],function(result){if(card.isConnected)applySecretUnlockRaw(result&&result["EXTUI:extappEasterEggs"]);});}catch(_){}
    }
    document.addEventListener("ext:secret-theme-unlocked",function(){if(!card.isConnected)return;hydrateSecretUnlocks();ts.load().then(function(fresh){opts=fresh||opts;updateUi();}).catch(function(){});});
    updateUi();wrap.appendChild(card);hydrateSecretUnlocks();
  }

  async function renderEasterEggsCard(wrap) {
    var card=document.createElement("section");card.className="extuiCard extuiEasterSettingsCard";
    card.innerHTML='<div class="extuiEasterSettingsHead"><div><span class="extuiPageEyebrow">NÚCLEO</span><h2>EASTER EGGS</h2><p>Controle efeitos, temas secretos, combinações, eventos sazonais e brinquedos interativos sem alterar dados ou automações.</p></div><div class="extuiEasterHeadActions"><button type="button" class="extui-btn extui-btn--ghost" data-easter-surprise>Surpresa</button><button type="button" class="extui-btn extui-btn--ghost" data-easter-reset>Desativar efeitos</button></div></div><section class="extuiEasterCollection" data-easter-collection><div class="extuiEasterCollectionHead"><div><span class="extuiPageEyebrow">COLEÇÃO DO NÚCLEO</span><h3>Seu progresso secreto</h3><p>Descobertas e vitórias ficam vinculadas à sua licença e só são restauradas pelo proprietário.</p></div><strong data-easter-collection-level>Explorador</strong></div><div class="extuiEasterCollectionGrid" data-easter-collection-grid></div><div class="extuiEasterCollectionProgress"><i data-easter-collection-progress></i></div><nav class="extuiEasterQuickNav" aria-label="Atalhos dos Easter Eggs"><button type="button" data-easter-jump="controls">Controles</button><button type="button" data-easter-jump="effects">Efeitos</button><button type="button" data-easter-jump="combos">Combos</button><button type="button" data-easter-jump="interactives">Interativos</button><button type="button" data-easter-jump="seasonal">Sazonais</button></nav></section><div class="extuiEasterStatusStrip" data-easter-status></div><div class="extuiEasterMasterControls" data-easter-section="controls"><label class="extuiEasterToggle"><input type="checkbox" data-easter-effects><span><strong>Efeitos visuais</strong><small>Permite temas, overlays e animações dos Easter Eggs.</small></span></label><label class="extuiEasterToggle"><input type="checkbox" data-easter-sounds><span><strong>Sons</strong><small>Ativa os sons exclusivos de cada Easter Egg.</small></span></label><label class="extuiEasterToggle"><input type="checkbox" data-easter-interactives><span><strong>Interativos</strong><small>Libera mascotes e microjogos leves sobre a interface.</small></span></label><label class="extuiEasterToggle"><input type="checkbox" data-easter-interactive-quiet><span><strong>Pausar ao digitar</strong><small>Congela brinquedos quando você usa campos de texto ou a aba fica oculta.</small></span></label><label class="extuiEasterToggle"><input type="checkbox" data-easter-sync-theme><span><strong>Combinar com tema secreto</strong><small>Quando existir um tema completo, aplica junto do efeito manual e restaura o anterior ao desligar.</small></span></label><div class="extuiEasterVolume"><span><strong>Volume</strong><small data-easter-volume-label>72%</small></span><input type="range" min="0" max="100" step="1" value="72" data-easter-volume aria-label="Volume dos Easter Eggs"></div></div><div class="extuiEasterIntensity"><div><strong>Intensidade visual</strong><span>Controle a quantidade de partículas e a presença dos efeitos.</span></div><div class="extuiEasterIntensityButtons" role="group" aria-label="Intensidade dos Easter Eggs"><button type="button" data-easter-intensity="soft">Suave</button><button type="button" data-easter-intensity="normal">Normal</button><button type="button" data-easter-intensity="intense">Intenso</button></div></div><div class="extuiEasterThemeGrid" data-easter-grid data-easter-section="effects"></div><div class="extuiEasterBonusNote"><strong>Bônus clássicos</strong><span>Sequências e cheat codes famosos da história dos jogos também podem despertar o NÚCLEO fora de campos de texto. As Pistas do Núcleo dão a direção sem entregar a resposta completa.</span></div><div class="extuiEasterComboPanel" data-easter-section="combos"><div><span class="extuiPageEyebrow">COMBINAÇÕES SECRETAS</span><h3>Sinergias descobertas</h3><p>Combine certos efeitos manuais com eventos sazonais. Nenhum elemento extra pesado é criado; as combinações usam a própria camada visual já ativa e podem ser reativadas manualmente por aqui.</p></div><div class="extuiEasterComboGrid" data-combo-grid></div></div><div class="extuiEasterInteractivePanel" data-easter-section="interactives"><div class="extuiEasterInteractiveHead"><div><span class="extuiPageEyebrow">INTERATIVOS</span><h3>Pets, Microjogos & Arcade</h3><p>Brinquedos ambientais continuam leves sobre a interface; jogos maiores entram no modo Arcade com ESC para sair.</p></div><button type="button" class="extui-btn extui-btn--ghost" data-interactive-stop>Encerrar interativo</button></div><section class="extuiEasterInteractiveGroup"><div class="extuiEasterInteractiveGroupHead"><div><span>AMBIENTAIS</span><strong>Pets & Microjogos</strong></div><small>Interações leves que convivem com a interface.</small></div><div class="extuiEasterInteractiveGrid" data-interactive-ambient-grid></div></section><section class="extuiEasterInteractiveGroup extuiEasterInteractiveGroup--arcade"><div class="extuiEasterInteractiveGroupHead"><div><span>ARCADE</span><strong>Jogos imersivos</strong></div><small>Ocupa a área central. ESC encerra a sessão imediatamente.</small></div><div class="extuiArcadeHubEntry" data-arcade-hub-entry hidden><span class="extuiArcadeHubEntryIcon">▦</span><div><small>COLEÇÃO COMPLETA</small><strong>Fliperama desbloqueado</strong><p>Escolha qualquer Arcade em um seletor único e troque de jogo sem sair da tarefa atual.</p></div><button type="button" class="extui-btn extui-btn--primary" data-open-arcade-hub>Abrir Fliperama</button></div><div class="extuiEasterInteractiveGrid" data-interactive-arcade-grid></div></section></div><div class="extuiEasterSeasonSection" data-easter-section="seasonal"><div class="extuiEasterSeasonHead"><div><span class="extuiPageEyebrow">EVENTOS SAZONAIS</span><h3>Temas sazonais + prévia manual</h3><p>Cada evento aplica identidade visual própria, decoração e som. Teste em qualquer data; Automático respeita o calendário.</p></div></div><div class="extuiEasterSeasonGrid" data-season-grid></div></div>';
    wrap.appendChild(card);
    async function bind(){
      var api=window.__extEasterControl;
      if(!api){setTimeout(bind,80);return;}
      var state=await api.getState(),grid=card.querySelector('[data-easter-grid]'),seasonGrid=card.querySelector('[data-season-grid]'),comboGrid=card.querySelector('[data-combo-grid]'),ambientGrid=card.querySelector('[data-interactive-ambient-grid]'),arcadeGrid=card.querySelector('[data-interactive-arcade-grid]');
      function paint(){
        grid.innerHTML="";
        var rawCodes=state.raw&&state.raw.cheatcodes&&typeof state.raw.cheatcodes==='object'?state.raw.cheatcodes:{};
        api.effects.forEach(function(item){
          var active=state.preferences.activeEffect===item.id,codeFound=item.id==='matrix'?!!(state.raw&&state.raw.matrix):!!rawCodes[item.id];
          var row=document.createElement("article");row.className="extuiEasterThemeCard"+(active?" is-active":"")+(codeFound?" is-discovered":" is-locked");row.style.setProperty("--extui-easter-card-accent",item.accent);
          var unlockedTheme=codeFound&&item.themeId&&(item.id==="matrix"?window.__extSecretThemeUnlocked===true:!!((window.__extSecretThemeUnlocks||{})[item.id]));
          var themeBadge=item.themeId?'<em class="extuiEasterFullThemeBadge" data-unlocked="'+String(!!unlockedTheme)+'">'+(unlockedTheme?'Tema secreto · '+item.themeLabel+' desbloqueado em Aparência':'Tema secreto bloqueado')+'</em>':'';
          var discoveryRecord=item.id==='matrix'?(state.raw&&state.raw.matrix):rawCodes[item.id],discoverySource=String(discoveryRecord&&discoveryRecord.source||''),visibleCode=codeFound?(/^[A-Z0-9][A-Z0-9 _-]{1,23}$/.test(discoverySource.toUpperCase())?discoverySource.toUpperCase():'DESCOBERTO'):'CÓDIGO OCULTO',visibleLabel=codeFound?item.label:'Easter Egg bloqueado',visibleSubtitle=codeFound?item.subtitle:'Sinal não identificado',visibleDesc=codeFound?item.desc:(item.hints&&item.hints[0]||'Existe uma pista para esta descoberta.'),lockedHint=codeFound?'':'<div class="extuiEasterLockedHint" data-hint-effect="'+item.id+'" data-hint-level="0"><span>PISTA 1/'+Math.max(1,(item.hints||[]).length)+'</span><p>'+visibleDesc+'</p></div>',actions=codeFound?'<div class="extuiEasterThemeActions"><button type="button" class="extui-btn extui-btn--ghost" data-preview-effect="'+item.id+'">Prévia</button><button type="button" class="extui-btn '+(active?'extui-btn--danger':'extui-btn--primary')+'" data-toggle-effect="'+item.id+'">'+(active?'Desativar':'Ativar')+'</button></div>':'<div class="extuiEasterThemeActions extuiEasterThemeActions--locked"><button type="button" class="extui-btn extui-btn--ghost" data-easter-card-hint="'+item.id+'">Outra pista</button><button type="button" class="extui-btn extui-btn--ghost" data-open-easter-hints>Mais pistas</button></div>';
          row.innerHTML='<div class="extuiEasterThemePreview" data-preview="'+item.id+'"><span></span><i></i><b>'+visibleCode+'</b></div><div class="extuiEasterThemeCopy"><div><strong>'+visibleLabel+'</strong><small>'+visibleSubtitle+'</small></div>'+(codeFound?'<p>'+visibleDesc+'</p>':'')+themeBadge+lockedHint+'</div>'+actions;
          if(codeFound&&state.preferences.effectsEnabled===false)row.querySelectorAll(".extuiEasterThemeActions button").forEach(function(button){button.disabled=true;});
          grid.appendChild(row);
        });
        card.querySelector('[data-easter-effects]').checked=state.preferences.effectsEnabled!==false;
        card.querySelector('[data-easter-sounds]').checked=state.preferences.soundsEnabled!==false;
        card.querySelector('[data-easter-sync-theme]').checked=state.preferences.syncTheme===true;card.querySelector('[data-easter-interactives]').checked=state.preferences.interactivesEnabled!==false;card.querySelector('[data-easter-interactive-quiet]').checked=state.preferences.interactiveQuiet!==false;
        var volume=Math.round((Number(state.preferences.audioVolume)||0)*100);card.querySelector('[data-easter-volume]').value=String(volume);card.querySelector('[data-easter-volume-label]').textContent=volume+'%';
        card.querySelectorAll('[data-easter-intensity]').forEach(function(btn){btn.classList.toggle('is-active',btn.dataset.easterIntensity===state.preferences.intensity);});
        var activeDef=api.effects.find(function(item){return item.id===state.preferences.activeEffect;}),seasonDef=api.seasons.find(function(item){return item.id===state.preferences.seasonMode;}),combo=api.currentCombo?api.currentCombo():null;
        var interactiveDef=api.interactives&&api.interactives.find(function(item){return item.id===state.preferences.activeInteractive;});var status=card.querySelector('[data-easter-status]');status.innerHTML='<span><b>EFEITO</b><strong>'+(activeDef?activeDef.label:'Nenhum')+'</strong></span><span><b>INTENSIDADE</b><strong>'+({soft:'Suave',normal:'Normal',intense:'Intenso'}[state.preferences.intensity]||'Normal')+'</strong></span><span><b>SAZONAL</b><strong>'+(seasonDef?seasonDef.label:'Automático')+'</strong></span><span><b>INTERATIVO</b><strong>'+(interactiveDef?interactiveDef.label:'—')+'</strong></span><span><b>COMBO</b><strong>'+(combo?combo.label:'—')+'</strong></span>';
        seasonGrid.innerHTML="";
        api.seasons.forEach(function(item){var active=state.preferences.seasonMode===item.id;var btn=document.createElement("button");btn.type="button";btn.className="extuiEasterSeasonCard"+(active?" is-active":"");btn.dataset.seasonMode=item.id;btn.style.setProperty("--extui-season-accent",item.accent);btn.innerHTML='<span class="extuiEasterSeasonIcon">'+item.icon+'</span><span><strong>'+item.label+'</strong><small>'+item.desc+'</small></span>';seasonGrid.appendChild(btn);});
        comboGrid.innerHTML="";var found=state.raw&&state.raw.combos&&typeof state.raw.combos==='object'?state.raw.combos:{},activeCombo=api.currentCombo?api.currentCombo():null;api.combos.forEach(function(item){var unlocked=!!found[item.id],isActive=!!(activeCombo&&activeCombo.id===item.id),node=document.createElement('article');node.className='extuiEasterComboCard'+(unlocked?' is-unlocked':' is-locked')+(isActive?' is-active':'');var actions=unlocked?'<div class="extuiEasterComboActions"><button type="button" class="extui-btn '+(isActive?'extui-btn--danger':'extui-btn--primary')+'" data-toggle-combo="'+item.id+'">'+(isActive?'Desativar':'Ativar')+'</button></div>':'';node.innerHTML='<span>'+(unlocked?item.icon:'◇')+'</span><div><strong>'+(unlocked?item.label:'Combinação bloqueada')+'</strong><small>'+(unlocked?item.desc:'Pista: '+item.hint)+'</small></div>'+actions;comboGrid.appendChild(node);});
        ambientGrid.innerHTML="";arcadeGrid.innerHTML="";var foundInteractives=state.raw&&state.raw.interactives&&typeof state.raw.interactives==='object'?state.raw.interactives:{},interactiveStats=state.raw&&state.raw.interactiveStats&&typeof state.raw.interactiveStats==='object'?state.raw.interactiveStats:{};
        function paintInteractive(item,targetGrid){var active=state.preferences.activeInteractive===item.id,discovered=!!foundInteractives[item.id],stats=interactiveStats[item.id]||{},wins=Math.max(0,Number(stats.wins)||0),node=document.createElement('article');node.className='extuiEasterInteractiveCard'+(active?' is-active':'')+(item.arcade?' is-arcade':'')+(discovered?' is-discovered':' is-locked');node.style.setProperty('--extui-mini-accent',item.accent);var bestNormal=Math.max(0,Number(stats.bestNormalMs)||0),bestHard=Math.max(0,Number(stats.bestHardMs)||0),bestArcade=bestNormal&&bestHard?Math.min(bestNormal,bestHard):(bestNormal||bestHard),hardWins=Math.max(0,Number(stats.hardWins)||0),record=item.arcade&&discovered?'<span class="extuiEasterArcadeRecord" data-has-record="'+String(wins>0)+'">'+(wins>0?'Vitórias '+wins+(bestArcade?' · recorde '+extMiniRecordTime(bestArcade):'')+(hardWins?' · Difícil ×'+hardWins:''):'Ainda não concluído')+'</span>':'';var visibleLabel=discovered?item.label:(item.arcade?'Arcade bloqueado':'Interativo bloqueado'),visibleDesc=discovered?item.desc:('Pista: '+(item.hint||'Existe uma descoberta relacionada a este interativo.')+' Use a Busca Universal, os eventos sazonais e as pistas do Núcleo para chegar até ele.'),visibleMatch=discovered?item.match:'As pistas do Núcleo revelam a direção certa sem expor o código.';var unlockSource=String((foundInteractives[item.id]||{}).source||'').toUpperCase(),unlockBadge=discovered?(unlockSource&&unlockSource!=='SEARCH'&&/^[A-Z0-9][A-Z0-9 _-]{1,23}$/.test(unlockSource)?unlockSource:'DESCOBERTO'):'CÓDIGO OCULTO';var interactiveActions=discovered?'<div class="extuiEasterInteractiveActions"><button type="button" class="extui-btn extui-btn--ghost" data-preview-interactive="'+item.id+'">Prévia</button><button type="button" class="extui-btn '+(active?'extui-btn--danger':'extui-btn--primary')+'" data-toggle-interactive="'+item.id+'">'+(active?'Encerrar':'Ativar')+'</button></div>':'<div class="extuiEasterInteractiveActions extuiEasterThemeActions--locked"><button type="button" class="extui-btn extui-btn--ghost" data-open-easter-hints>Ver Pistas do Núcleo</button></div>';node.innerHTML='<div class="extuiEasterInteractivePreview" data-mini-preview="'+item.id+'"><span>'+(discovered?item.icon:'?')+'</span><i></i></div><div class="extuiEasterInteractiveCopy"><div><strong>'+visibleLabel+'</strong><small>'+unlockBadge+'</small></div><p>'+visibleDesc+'</p><em>'+visibleMatch+'</em>'+record+'</div>'+interactiveActions;if(discovered&&state.preferences.interactivesEnabled===false)node.querySelectorAll('button').forEach(function(button){button.disabled=true;});targetGrid.appendChild(node);}(api.interactives||[]).forEach(function(item){paintInteractive(item,item.arcade?arcadeGrid:ambientGrid);});
        var effectFound=api.effects.filter(function(item){return item.id==='matrix'?!!(state.raw&&state.raw.matrix):!!rawCodes[item.id];}).length,themeTotal=api.effects.filter(function(item){return !!item.themeId;}).length,themeFound=api.effects.filter(function(item){return !!item.themeId&&(item.id==='matrix'?!!(state.raw&&state.raw.matrix):!!rawCodes[item.id]);}).length,comboFound=api.combos.filter(function(item){return !!found[item.id];}).length,interactiveFound=(api.interactives||[]).filter(function(item){return !!foundInteractives[item.id];}).length,arcades=(api.interactives||[]).filter(function(item){return item.arcade===true;}),arcadeUnlocked=arcades.length>0&&arcades.every(function(item){return !!foundInteractives[item.id];}),arcadeWins=arcades.filter(function(item){return Number((interactiveStats[item.id]||{}).wins)>0;}).length,hubEntry=card.querySelector('[data-arcade-hub-entry]'),total=api.effects.length+themeTotal+api.combos.length+(api.interactives||[]).length+arcades.length,done=effectFound+themeFound+comboFound+interactiveFound+arcadeWins,pct=total?Math.round(done/total*100):0,level=pct>=100?'Núcleo completo':pct>=85?'Mestre do Núcleo':pct>=60?'Operador secreto':pct>=30?'Explorador':'Sinal detectado';if(hubEntry)hubEntry.hidden=!arcadeUnlocked;card.querySelector('[data-easter-collection-level]').textContent=level+' · '+pct+'%';card.querySelector('[data-easter-collection-progress]').style.width=pct+'%';card.querySelector('[data-easter-collection-grid]').innerHTML='<span><b>EFEITOS</b><strong>'+effectFound+'/'+api.effects.length+'</strong></span><span><b>TEMAS SECRETOS</b><strong>'+themeFound+'/'+themeTotal+'</strong></span><span><b>COMBOS</b><strong>'+comboFound+'/'+api.combos.length+'</strong></span><span><b>INTERATIVOS</b><strong>'+interactiveFound+'/'+(api.interactives||[]).length+'</strong></span><span><b>ARCADES VENCIDOS</b><strong>'+arcadeWins+'/'+arcades.length+'</strong></span>';
      }
      async function refresh(next){state=next||await api.getState();paint();}
      card.addEventListener("click",async function(ev){
        var localHint=ev.target.closest('[data-easter-card-hint]');if(localHint){var hintItem=api.effects.find(function(item){return item.id===localHint.dataset.easterCardHint;}),hintBox=localHint.closest('.extuiEasterThemeCard')&&localHint.closest('.extuiEasterThemeCard').querySelector('[data-hint-effect]');if(hintItem&&hintBox){var hints=Array.isArray(hintItem.hints)?hintItem.hints:[],level=(Number(hintBox.dataset.hintLevel)||0)+1;if(level>=hints.length)level=0;hintBox.dataset.hintLevel=String(level);var hintText=hintBox.querySelector('p'),hintMeta=hintBox.querySelector('span');if(hintText)hintText.textContent=hints[level]||'Continue explorando a Central.';if(hintMeta)hintMeta.textContent='PISTA '+(level+1)+'/'+Math.max(1,hints.length);localHint.textContent=level+1>=hints.length?'Voltar à primeira pista':'Outra pista';}return;}if(ev.target.closest('[data-open-easter-hints]')){window.__extCorePendingTab='secrets';if(window.__extDashboardShell&&window.__extDashboardShell.showSection)window.__extDashboardShell.showSection('home');return;}if(ev.target.closest('[data-open-arcade-hub]')){if(api.openArcadeHub)await api.openArcadeHub();return;}
        var preview=ev.target.closest('[data-preview-effect]');if(preview){await api.preview(preview.dataset.previewEffect);return;}
        var toggle=ev.target.closest('[data-toggle-effect]');if(toggle){var id=toggle.dataset.toggleEffect;var wasActive=state.preferences.activeEffect===id;await refresh(wasActive?await api.deactivate():await api.activate(id));toast(wasActive?"Easter Egg desativado.":"Easter Egg ativado manualmente.");return;}
        var comboToggle=ev.target.closest('[data-toggle-combo]');if(comboToggle&&api.activateCombo){var comboId=comboToggle.dataset.toggleCombo,currentCombo=api.currentCombo?api.currentCombo():null,comboActive=!!(currentCombo&&currentCombo.id===comboId);await refresh(comboActive?await api.deactivate():await api.activateCombo(comboId));toast(comboActive?"Combinação desativada.":"Combinação ativada manualmente.");return;}
        var season=ev.target.closest('[data-season-mode]');if(season){await refresh(await api.setSeason(season.dataset.seasonMode,true));toast("Evento sazonal atualizado.");return;}
        var intensity=ev.target.closest('[data-easter-intensity]');if(intensity){await refresh(await api.setIntensity(intensity.dataset.easterIntensity));return;}var miniPreview=ev.target.closest('[data-preview-interactive]');if(miniPreview){await api.previewInteractive(miniPreview.dataset.previewInteractive);return;}var miniToggle=ev.target.closest('[data-toggle-interactive]');if(miniToggle){var miniId=miniToggle.dataset.toggleInteractive,miniActive=state.preferences.activeInteractive===miniId;await refresh(miniActive?await api.deactivateInteractive():await api.activateInteractive(miniId));toast(miniActive?'Interativo encerrado.':'Interativo ativado.');return;}if(ev.target.closest('[data-interactive-stop]')){await refresh(await api.deactivateInteractive());return;}
        var jump=ev.target.closest('[data-easter-jump]');if(jump){var target=card.querySelector('[data-easter-section="'+jump.dataset.easterJump+'"]');if(target)target.scrollIntoView({behavior:'smooth',block:'start'});return;}
        if(ev.target.closest('[data-easter-surprise]')){await api.surprise();return;}
        if(ev.target.closest('[data-easter-reset]')){await refresh(await api.deactivate());toast("Efeitos manuais desativados.");}
      });
      card.querySelector('[data-easter-effects]').addEventListener("change",async function(ev){await refresh(await api.setEffectsEnabled(ev.target.checked));});
      card.querySelector('[data-easter-sounds]').addEventListener("change",async function(ev){await refresh(await api.setSoundsEnabled(ev.target.checked));});
      card.querySelector('[data-easter-sync-theme]').addEventListener("change",async function(ev){await refresh(await api.setSyncTheme(ev.target.checked));});card.querySelector('[data-easter-interactives]').addEventListener("change",async function(ev){await refresh(await api.setInteractivesEnabled(ev.target.checked));});card.querySelector('[data-easter-interactive-quiet]').addEventListener("change",async function(ev){await refresh(await api.setInteractiveQuiet(ev.target.checked));});
      card.querySelector('[data-easter-volume]').addEventListener("input",function(ev){card.querySelector('[data-easter-volume-label]').textContent=ev.target.value+'%';});
      card.querySelector('[data-easter-volume]').addEventListener("change",async function(ev){await refresh(await api.setAudioVolume(Number(ev.target.value)/100));if(api.testSound)api.testSound();});
      function syncUnlockedThemeBadges(){if(!card.isConnected){document.removeEventListener("ext:secret-theme-unlocked",syncUnlockedThemeBadges);document.removeEventListener("ext:easter-combo-discovered",syncUnlockedThemeBadges);document.removeEventListener("ext:easter-progress-updated",syncUnlockedThemeBadges);return;}api.getState().then(refresh).catch(function(){});}
      document.addEventListener("ext:secret-theme-unlocked",syncUnlockedThemeBadges);document.addEventListener("ext:easter-combo-discovered",syncUnlockedThemeBadges);document.addEventListener("ext:easter-progress-updated",syncUnlockedThemeBadges);
      paint();
    }
    bind();
  }

  window.__extRenderEasterSettings=renderEasterEggsCard;
  async function renderPersonalizacaoSection(container) {
    container.innerHTML="";
    var wrap=document.createElement("div");wrap.className="extuiSectionWrap extuiPersonalizacaoPageV3 extuiAdminSurfaceV3";container.appendChild(wrap);
    var head=document.createElement("div");head.className="extuiPageHeading";head.innerHTML='<div><h1>Personalização</h1><p>Personalize tema, tipografia, ícones e a aparência geral da extensão.</p></div>';wrap.appendChild(head);
    var opts=await ts.load();renderAparenciaCard(wrap,opts);
  }

  if(window.__extDashboardShell&&window.__extDashboardShell.registerSection)window.__extDashboardShell.registerSection("personalizacao",renderPersonalizacaoSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
