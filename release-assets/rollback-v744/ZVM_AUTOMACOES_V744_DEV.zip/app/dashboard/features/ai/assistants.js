;
try{
(function () {
  "use strict";
  if (window.__extAiAssistantsModuleBooted) return;
  window.__extAiAssistantsModuleBooted = true;

  var assistantsCore = window.__extAiAssistantsCore;
  var agentsCore = window.__extAiAgentsCore;
  var integrationCore = window.__extIntegrationCore;
  var modelPolicy = window.__extAiModelPolicy;
  var toolsRegistry = window.__extAiToolsRegistry;
  var rootEl = null;
  var snapshot = null;
  var activeDrawer = null;
  var searchTerm = "";

  function el(tag, attrs, children) {
    var node = document.createElement(tag); attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      if (key === "class") node.className = attrs[key];
      else if (key === "text") node.textContent = attrs[key];
      else if (key.slice(0, 2) === "on" && typeof attrs[key] === "function") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      else if (attrs[key] !== false && attrs[key] != null) node.setAttribute(key, attrs[key] === true ? "" : attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); });
    return node;
  }

  var ICONS = {
    bot: '<rect x="3" y="8" width="18" height="12" rx="3"/><path d="M12 4v4M8 13h.01M16 13h.01M8 17h8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v5M14 11v5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>'
  };
  function icon(name) { var span = el("span", { class: "extuiaIcon", "aria-hidden": "true" }); span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + ICONS[name] + '</svg>'; return span; }
  function storageGet(key) { return window.__extDashboardShell.storageGet(key).then(function (result) { return result && result[key]; }); }
  function storageSet(key, value) { if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value); return new Promise(function (resolve, reject) { var payload = {}; payload[key] = value; chrome.storage.local.set(payload, function () { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(); }); }); }
  function message(type, payload) { return new Promise(function (resolve, reject) { chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (response) { if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; } if (!response || response.ok !== true) { reject(new Error(response && response.userMessage || "Não foi possível concluir a operação.")); return; } resolve(response.result); }); }); }
  function createId() { return window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : "assistant-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10); }
  var repository = assistantsCore.createRepository({ read: function () { return storageGet(assistantsCore.STORE_KEY); }, write: function (value) { return storageSet(assistantsCore.STORE_KEY, value); }, createId: createId, now: Date.now });

  function parseFlows(raw) {
    if (raw == null || raw === "") return [];
    var parsed;
    try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { var invalid = new Error("Os dados de Fluxos estão corrompidos e não serão tratados como vazios."); invalid.code = "AI_FLOW_STORE_CORRUPT"; throw invalid; }
    if (!parsed || !parsed.state || !Array.isArray(parsed.state.flowList)) { var malformed = new Error("O armazenamento de Fluxos está em um formato inválido."); malformed.code = "AI_FLOW_STORE_INVALID"; throw malformed; }
    return parsed.state.flowList;
  }
  async function loadSnapshot() {
    var values = await Promise.all([repository.get(), message("EXTUI_INTEGRATION_GET_STATE"), storageGet("EXTUI:extappFlowStore"), message("EXTUI_KNOWLEDGE_GET_STATE"), message("EXTUI_EXTERNAL_ACTION_LIST"), storageGet(agentsCore.STORE_KEY)]);
    return { store: values[0], integrations: values[1], flows: parseFlows(values[2]), knowledge: window.__extKnowledgeCore.normalizeStore(values[3]), externalActions: Array.isArray(values[4]) ? values[4] : [], agents: agentsCore.normalizeStore(values[5]) };
  }
  function providers() { return integrationCore.PROVIDERS.filter(function (provider) { return provider.kind === "ai"; }); }
  function providerLabel(providerId) { var provider = integrationCore.providerById(providerId); return provider ? provider.label : "Serviço indisponível"; }
  function modelLabel(assistant) { return assistant.modelMode === assistantsCore.MODEL_MODES.DEFAULT ? "Modelo principal" : (assistant.model || "Modelo não selecionado"); }
  function relativeDate(value) { if (!value) return "Sem data"; var diff = Date.now() - value; if (diff < 60000) return "Editado agora"; if (diff < 3600000) return "Editado há " + Math.max(1, Math.round(diff / 60000)) + " min"; if (diff < 86400000) return "Editado há " + Math.round(diff / 3600000) + " h"; return "Editado em " + new Date(value).toLocaleDateString("pt-BR"); }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  async function validateProviderForEnabledAssistant(providerId, modelModeValue, modelValue) {
    var metadata = snapshot.integrations && snapshot.integrations.providers && snapshot.integrations.providers[providerId];
    if (!metadata || metadata.configured === false || metadata.enabled !== true || metadata.status !== "connected") throw new Error("Conecte e teste o serviço de IA antes de salvar um Perfil ativo.");
    try { await message("EXTUI_INTEGRATION_TEST", { provider: providerId }); }
    catch (error) { throw new Error("A conexão de IA não passou na verificação: " + (error && error.message ? error.message : String(error))); }
    snapshot.integrations = await message("EXTUI_INTEGRATION_GET_STATE");
    metadata = snapshot.integrations && snapshot.integrations.providers && snapshot.integrations.providers[providerId];
    var effectiveModel = modelModeValue === "specific" ? modelValue : metadata && metadata.model;
    if (!effectiveModel) throw new Error("Escolha um modelo válido para o serviço de IA antes de continuar.");
    if (modelModeValue === "specific" && Array.isArray(metadata.availableModels) && !metadata.availableModels.some(function (item) { return item && item.id === effectiveModel; })) throw new Error("O modelo escolhido não está disponível nesta conexão.");
    return true;
  }

  async function openIntegration(providerId) {
    closeDrawer();
    await window.__extDashboardShell.showSection("ai-connect");
    if (window.__extIntegrations && typeof window.__extIntegrations.openProvider === "function") window.__extIntegrations.openProvider(providerId, { onChange: async function () { if (window.__extIntegrations && window.__extIntegrations.refreshAiConnections) await window.__extIntegrations.refreshAiConnections(document.getElementById("extappContentArea")); } });
  }
  function closeDrawer() { if (!activeDrawer) return; document.removeEventListener("keydown", activeDrawer.keyHandler, true); var previous = activeDrawer.previous; activeDrawer.layer.remove(); activeDrawer = null; if (previous && previous.isConnected) previous.focus(); }

  function assistantRow(assistant) {
    var health = assistantsCore.healthFor(assistant, snapshot.integrations, integrationCore.PROVIDER_IDS, snapshot.knowledge);
    var article = el("article", { class: "extuiaAssistantRow", "data-health": health.state });
    var identity = el("div", { class: "extuiaAssistantIdentity" }, [icon("bot"), el("div", {}, [el("h2", { text: assistant.name }), assistant.description ? el("p", { text: assistant.description }) : el("p", { class: "is-muted", text: "Sem descrição interna" })])]);
    var knowledgeBase = assistant.knowledge && assistant.knowledge.mode === "base" ? window.__extKnowledgeCore.findBase(snapshot.knowledge, assistant.knowledge.baseId) : null;
    var toolCount = assistant.tools && Array.isArray(assistant.tools.enabled) ? assistant.tools.enabled.length : 0;
    var configuration = el("div", { class: "extuiaAssistantConfig", "aria-label": "Configuração" }, [el("strong", { text: providerLabel(assistant.providerId) }), el("span", { text: modelLabel(assistant) }), assistant.knowledge && assistant.knowledge.mode === "base" ? el("span", { text: "Base: " + (knowledgeBase ? knowledgeBase.name : "requer atenção") }) : null, el("span", { text: toolCount ? toolCount + " ferramenta" + (toolCount === 1 ? "" : "s") : "Sem ferramentas" })]);
    var status = el("div", { class: "extuiaAssistantStatus" }, [el("span", { class: "extuiaState", text: health.label }), el("small", { text: relativeDate(assistant.updatedAt) })]);
    var actions = el("div", { class: "extuiaAssistantActions" });
    var edit = el("button", { class: "extui-btn extui-btn--secondary", type: "button" }, [icon("edit"), el("span", { text: "Editar" })]); edit.addEventListener("click", function () { openDrawer(assistant.id); });
    var duplicate = el("button", { class: "extui-btn extui-btn--ghost", type: "button", "aria-label": "Duplicar " + assistant.name }, [icon("copy")]); duplicate.addEventListener("click", async function () { try { await repository.duplicate(assistant.id); toast("Assistente duplicado."); await refresh(); } catch (error) { toast(error.message, true); } });
    var remove = el("button", { class: "extui-btn extui-btn--ghost extuiaDangerAction", type: "button", "aria-label": "Excluir " + assistant.name }, [icon("trash")]); remove.addEventListener("click", function () { removeAssistant(assistant); });
    actions.appendChild(edit); actions.appendChild(duplicate); actions.appendChild(remove); article.appendChild(identity); article.appendChild(configuration); article.appendChild(status); article.appendChild(actions); return article;
  }

  async function removeAssistant(assistant) {
    var count = assistantsCore.countFlowReferences(snapshot.flows, assistant.id);
    var detail = count ? "Este assistente é utilizado por " + count + " Fluxo" + (count === 1 ? "" : "s") + ". Ao removê-lo, essas etapas ficarão com configuração incompleta." : "Esta ação remove o perfil reutilizável. Nenhuma etapa de Fluxo será apagada.";
    if (!await window.extConfirm("Excluir “" + assistant.name + "”?\n\n" + detail, { danger: true, okLabel: "Excluir assistente" })) return;
    try { await repository.remove(assistant.id); toast("Assistente excluído."); await refresh(); }
    catch (error) { toast(error.message, true); }
  }

                                                                       
                                                                        
                                                                        
                                                                 
                                                                  
                                                                          
                                                                          
                                                                      
                                                                    
                                               
  function aiHubNav(activeKey) {
    var items = [{ key: "ai-connect", label: "Conexões & Recursos" }, { key: "ai-assistants", label: "Perfis IA" }, { key: "ai-agents", label: "Agentes IA" }, { key: "ai-memory", label: "Memória IA" }, { key: "knowledge", label: "Base de Conhecimento" }];
    var nav = el("nav", { class: "extuiAiHubNav", "aria-label": "Navegação do Hub de IA" });
    items.forEach(function (item) {
      var btn = el("button", { type: "button", class: "extuiAiHubNavItem" + (item.key === activeKey ? " extuiActive" : ""), text: item.label });
      if (item.key === activeKey) btn.setAttribute("aria-current", "page");
      else btn.addEventListener("click", function () { window.__extDashboardShell.showSection(item.key); });
      nav.appendChild(btn);
    });
    return nav;
  }
                                                                      
                                                                   
                                                                      
                                                                           
                                                                       
                                                                 
                                                                  
                                 
  function hasConnectedProvider() { return integrationCore.PROVIDER_IDS.some(function (id) { var item = snapshot.integrations && snapshot.integrations.providers && snapshot.integrations.providers[id]; return !!(item && item.configured && item.enabled && item.status === integrationCore.STATUSES.CONNECTED); }); }
  function aiSetupPath(activeKey, hasAssistants, hasAgents) {
    var hasConnection = hasConnectedProvider();
    var path = el("div", { class: "extuiAiSetupPath", role: "group", "aria-label": "Ordem recomendada de configuração" });
    var steps = [
      { n: 1, key: "ai-connect", title: "Conexão IA", desc: "Conecte um serviço", status: hasConnection ? "Concluído" : "Comece aqui" },
      { n: 2, key: "ai-assistants", title: "Perfis IA", desc: "Defina o comportamento", status: hasAssistants ? "Concluído" : (hasConnection ? "Passo atual" : "Pendente") },
      { n: 3, key: "ai-agents", title: "Agentes IA", desc: "Use um perfil", status: hasAgents ? "Configurado" : "Pendente" },
      { n: 4, key: "ai-memory", title: "Memória IA", desc: "Enriqueça o contexto", status: "Opcional" },
      { n: 5, key: "knowledge", title: "Conhecimento", desc: "Ensine fatos específicos", status: "Opcional" }
    ];
    steps.forEach(function (step) {
      var stateName = step.key === activeKey ? "current" : ((step.key === "ai-connect" && hasConnection) || (step.key === "ai-assistants" && hasAssistants) || (step.key === "ai-agents" && hasAgents) ? "done" : "pending");
      var btn = el("button", { type: "button", class: "extuiAiSetupStep", "data-state": stateName });
      btn.appendChild(el("div", { class: "extuiAiSetupStepHead" }, [el("span", { class: "extuiAiSetupStepNumber", text: String(step.n) }), el("span", { class: "extuiAiSetupStepTitle", text: step.title })]));
      btn.appendChild(el("span", { class: "extuiAiSetupStepDesc", text: step.desc }));
      btn.appendChild(el("span", { class: "extuiAiSetupStepStatus", text: step.status }));
      if (step.key !== activeKey) btn.addEventListener("click", function () { window.__extDashboardShell.showSection(step.key); });
      path.appendChild(btn);
    });
    return path;
  }

  function renderPage() {
    rootEl.innerHTML = "";
    var page = el("div", { class: "extuiaPage" });
    page.appendChild(aiHubNav("ai-assistants"));
    page.appendChild(aiSetupPath("ai-assistants", snapshot.store.assistants.length > 0, snapshot.agents.agents.length > 0));
                                                                    
                                                                        
                                    
    var header = el("header", { class: "extuiaHeader", "data-extui-academy-target": "ai-assistants-header" }, [el("div", {}, [el("span", { class: "extuiaEyebrow", text: "AUTOMAÇÃO" }), el("h1", { text: "Perfis IA" }), el("p", { text: "Crie perfis de IA reutilizáveis nas automações da extensão." })])]);
    var canCreateProfile = hasConnectedProvider();
    var create = el("button", { class: "extui-btn extui-btn--primary", type: "button" }, [icon("plus"), el("span", { text: canCreateProfile ? "Novo perfil IA" : "Conectar IA primeiro" })]);
    create.addEventListener("click", function () { if (canCreateProfile) openDrawer(null); else window.__extDashboardShell.showSection("ai-connect"); }); header.appendChild(create); page.appendChild(header);
    var summary = assistantsCore.summarize(snapshot.store, snapshot.integrations, integrationCore.PROVIDER_IDS, snapshot.knowledge);
    page.appendChild(el("section", { class: "extuiaSummary", "aria-label": "Resumo dos assistentes" }, [
      el("div", {}, [el("strong", { text: String(summary.total) }), el("span", { text: "Total" })]),
      el("div", {}, [el("strong", { text: String(summary.active) }), el("span", { text: "Ativos" })]),
      el("div", {}, [el("strong", { text: String(summary.attention) }), el("span", { text: "Requerem atenção" })])
    ]));
    if (!snapshot.store.assistants.length) {
      var empty = el("section", { class: "extuiaEmpty" }, [icon("bot"), el("h2", { text: canCreateProfile ? "Crie seu primeiro Perfil IA" : "Primeiro conecte um serviço de IA" }), el("p", { text: canCreateProfile ? "Defina instruções e reutilize a mesma configuração em Fluxos e Agentes IA." : "A conexão agora é o passo 1 dentro de Assistentes IA. Depois de validar OpenAI, Gemini ou Grok, você cria o Perfil aqui." })]);
      var emptyCreate = el("button", { class: "extui-btn extui-btn--primary", type: "button", text: canCreateProfile ? "Criar Perfil IA" : "Ir para Conexões IA" }); emptyCreate.addEventListener("click", function () { if (canCreateProfile) openDrawer(null); else window.__extDashboardShell.showSection("ai-connect"); }); empty.appendChild(emptyCreate); page.appendChild(empty); rootEl.appendChild(page); return;
    }
    if (snapshot.store.assistants.length > 3) {
      var search = el("label", { class: "extuiaSearch" }, [icon("search"), el("span", { class: "extuiSrOnly", text: "Buscar assistentes" })]);
      var input = el("input", { type: "search", placeholder: "Buscar por nome, descrição ou serviço", value: searchTerm, autocomplete: "off" }); input.value = searchTerm; input.addEventListener("input", function () { searchTerm = input.value; renderList(list); }); search.appendChild(input); page.appendChild(search);
    }
    var list = el("section", { class: "extuiaList", "aria-label": "Assistentes de IA" }); page.appendChild(list); rootEl.appendChild(page); renderList(list);
  }
  function renderList(list) {
    var query = searchTerm.trim().toLocaleLowerCase("pt-BR");
    var filtered = snapshot.store.assistants.filter(function (assistant) { return !query || [assistant.name, assistant.description, providerLabel(assistant.providerId)].join(" ").toLocaleLowerCase("pt-BR").indexOf(query) >= 0; });
    list.innerHTML = ""; filtered.forEach(function (assistant) { list.appendChild(assistantRow(assistant)); });
    if (!filtered.length) list.appendChild(el("div", { class: "extuiaNoResults", text: "Nenhum assistente corresponde à busca." }));
  }


  function openDrawer(assistantId) {
    closeDrawer();
    var current = assistantId ? snapshot.store.assistants.find(function (assistant) { return assistant.id === assistantId; }) : null;
    if (assistantId && !current) { toast("Assistente não encontrado.", true); return; }
    var previous = document.activeElement;
    var layer = el("div", { class: "extuiaDrawerLayer" }); var backdrop = el("button", { class: "extuiaDrawerBackdrop", type: "button", "aria-label": "Fechar editor" }); var drawer = el("aside", { class: "extuiaDrawer", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuiaDrawerTitle", tabindex: "-1" }); layer.appendChild(backdrop); layer.appendChild(drawer); document.body.appendChild(layer);
    var close = el("button", { class: "extuiaClose", type: "button", "aria-label": "Fechar", text: "×" }); drawer.appendChild(el("header", { class: "extuiaDrawerHeader" }, [el("div", {}, [el("span", { class: "extuiaEyebrow", text: current ? "EDITAR PERFIL" : "NOVO PERFIL" }), el("h2", { id: "extuiaDrawerTitle", text: current ? current.name : "Novo assistente de IA" })]), close]));
    var form = el("form", { id: "extuiaAssistantForm", class: "extuiaForm" });
    function field(label, control, helper) { var wrap = el("label", { class: "extuiaField" }, [el("span", { text: label }), control]); if (helper) wrap.appendChild(el("small", { text: helper })); return wrap; }
    var name = el("input", { type: "text", required: true, maxlength: "80", autocomplete: "off", value: current && current.name || "" }); name.value = current && current.name || "";
    var description = el("input", { type: "text", maxlength: "160", autocomplete: "off", value: current && current.description || "", placeholder: "Ex.: Perfil usado nos Fluxos comerciais" }); description.value = current && current.description || "";
    var providerSelect = el("select", { required: true, "aria-label": "Serviço de IA" }); providers().forEach(function (provider) { providerSelect.appendChild(el("option", { value: provider.id, text: provider.label })); }); providerSelect.value = current && current.providerId || providers()[0].id;
    var modelMode = el("select", { "aria-label": "Modo do modelo" }, [el("option", { value: "default", text: "Usar o modelo escolhido na conexão" }), el("option", { value: "specific", text: "Escolher outro modelo" })]); modelMode.value = current && current.modelMode || "default";
    var modelSelect = el("select", { "aria-label": "Outro modelo" });
    var health = el("div", { class: "extuiaProviderHealth", role: "status" });
    var instructions = el("textarea", { rows: "9", placeholder: "Você é um atendente comercial cordial e objetivo…", "aria-label": "Instruções do assistente" }); instructions.value = current && current.instructions || "";
    var currentContext = current && current.context || { mode: "none", messageCount: 5 };
    var contextEnabled = el("input", { type: "checkbox", "aria-controls": "extuiaContextOptions" }); contextEnabled.checked = currentContext.mode === "recent";
    var contextToggle = el("label", { class: "extuiaToggle" }, [contextEnabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Usar mensagens recentes" }), el("small", { text: "Inclui apenas mensagens de texto da conversa atual nesta execução." })])]);
    var contextCount = el("select", { "aria-label": "Quantidade de mensagens recentes" }, [el("option", { value: "5", text: "5 mensagens" }), el("option", { value: "10", text: "10 mensagens" }), el("option", { value: "20", text: "20 mensagens" })]); contextCount.value = String(currentContext.messageCount || 5);
    var contextOptions = el("div", { id: "extuiaContextOptions", class: "extuiaContextOptions" }, [
      field("Mensagens incluídas", contextCount),
      el("p", { class: "extuiaContextNote", text: "As mensagens recentes da conversa atual serão enviadas ao provedor de IA escolhido somente durante a execução." }),
      el("p", { class: "extuiaContextNote", text: "O Extensão não salva uma cópia desse contexto." }),
      el("p", { class: "extuiaContextCost", role: "note", text: "Mais contexto pode aumentar o consumo do serviço de IA." })
    ]);
    var contextSection = el("fieldset", { class: "extuiaContextSection" }, [
      el("legend", { text: "Contexto da conversa" }),
      contextToggle,
      contextOptions
    ]);
    var currentMemory = current && current.memory || { mode: "none" };
    var memoryEnabled = el("input", { type: "checkbox" }); memoryEnabled.checked = currentMemory.mode === "customer";
    var memorySection = el("fieldset", { class: "extuiaContextSection extuiaMemorySection" }, [
      el("legend", { text: "Memória do cliente" }),
      el("label", { class: "extuiaToggle" }, [memoryEnabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Disponibilizar Memória IA para este Perfil" }), el("small", { text: "O Agente ainda precisa ativar o uso de memórias e cada memória define quais Agentes são autorizados." })])]),
      el("p", { class: "extuiaContextNote", text: "Criação, edição e autorização por Agente ficam centralizadas no passo 3 · Memória IA." })
    ]);
    var currentToolIds = toolsRegistry ? toolsRegistry.normalizeEnabledToolIds(current && current.tools) : [];
    var toolInputs = [];
    var writeAcknowledged = currentToolIds.some(function (id) { var definition = toolsRegistry.get(id); return definition && definition.risk === "write"; });
    var writeConfirmation = null;
    function selectedWriteInputs() { return toolInputs.filter(function (entry) { return entry.definition.risk === "write" && entry.input.checked; }); }
    function confirmWriteTools() {
      if (writeAcknowledged || !selectedWriteInputs().length) return Promise.resolve(true);
      if (writeConfirmation) return writeConfirmation;
      writeConfirmation = window.extConfirm("Este Assistente poderá alterar dados da extensão durante uma execução quando considerar necessário.", { okLabel: "Habilitar ações" }).then(function (confirmed) {
        writeAcknowledged = confirmed === true;
        if (!writeAcknowledged) selectedWriteInputs().forEach(function (entry) { entry.input.checked = false; });
        return writeAcknowledged;
      }).finally(function () { writeConfirmation = null; });
      return writeConfirmation;
    }
    function toolOption(definition) {
      var input = el("input", { type: "checkbox", value: definition.id });
      input.checked = currentToolIds.indexOf(definition.id) >= 0;
      toolInputs.push({ input: input, definition: definition });
      if (definition.risk === "write") input.addEventListener("change", async function () {
        if (!input.checked || writeAcknowledged) return;
        await confirmWriteTools();
      });
      return el("label", { class: "extuiaToolOption" }, [input, el("span", { class: "extuiaToolCheck", "aria-hidden": "true" }), el("span", { class: "extuiaToolCopy" }, [el("strong", { text: definition.label }), el("small", { text: definition.description })])]);
    }
    var readTools = el("div", { class: "extuiaToolGroup" }, [el("h3", { text: "Leitura" })]);
    var writeTools = el("div", { class: "extuiaToolGroup" }, [el("h3", { text: "Ações" })]);
                                                                            
                                                                  
    (toolsRegistry ? toolsRegistry.definitionsFor(toolsRegistry.ids()) : []).filter(function (definition) { return definition.id !== "external_action"; }).forEach(function (definition) {
      (definition.risk === "write" ? writeTools : readTools).appendChild(toolOption(definition));
    });
    var toolsSection = el("fieldset", { class: "extuiaContextSection extuiaToolsSection" }, [
      el("legend", { text: "Ferramentas" }),
      el("p", { class: "extuiaContextNote", text: "Permita que este Assistente consulte ou altere dados da extensão. Novos Assistentes começam sem permissões." }),
      readTools,
      writeTools
    ]);
                                                                           
                                                                        
                                                                         
                                                                           
                                                                              
    var currentExternalActionIds = assistantsCore.normalizeExternalActions(current && current.externalActions).enabled;
    var externalActionInputs = [];
    var externalWriteAcknowledged = currentExternalActionIds.some(function (id) {
      var action = snapshot.externalActions.find(function (entry) { return entry.id === id; });
      return action && action.method === "POST";
    });
    var externalWriteConfirmation = null;
    function selectedExternalWriteInputs() { return externalActionInputs.filter(function (entry) { return entry.action.method === "POST" && entry.input.checked; }); }
    function confirmExternalWriteActions() {
      if (externalWriteAcknowledged || !selectedExternalWriteInputs().length) return Promise.resolve(true);
      if (externalWriteConfirmation) return externalWriteConfirmation;
      externalWriteConfirmation = window.extConfirm("Este Assistente poderá enviar dados para um serviço externo (fora da extensão) durante uma execução, quando considerar necessário.", { okLabel: "Habilitar ações externas" }).then(function (confirmed) {
        externalWriteAcknowledged = confirmed === true;
        if (!externalWriteAcknowledged) selectedExternalWriteInputs().forEach(function (entry) { entry.input.checked = false; });
        return externalWriteAcknowledged;
      }).finally(function () { externalWriteConfirmation = null; });
      return externalWriteConfirmation;
    }
    function externalActionOption(action) {
      var input = el("input", { type: "checkbox", value: action.id });
      input.checked = currentExternalActionIds.indexOf(action.id) >= 0;
      externalActionInputs.push({ input: input, action: action });
      if (action.method === "POST") input.addEventListener("change", async function () {
        if (!input.checked || externalWriteAcknowledged) return;
        await confirmExternalWriteActions();
      });
      var fieldNames = (action.fields || []).map(function (field) { return field.name + (field.required ? "*" : ""); }).join(", ") || "nenhum";
      return el("label", { class: "extuiaToolOption" }, [input, el("span", { class: "extuiaToolCheck", "aria-hidden": "true" }), el("span", { class: "extuiaToolCopy" }, [el("strong", { text: action.name + (action.enabled ? "" : " · desativada") }), el("small", { text: action.description + " (campos: " + fieldNames + ")" })])]);
    }
    var readActions = el("div", { class: "extuiaToolGroup" }, [el("h3", { text: "Leitura" })]);
    var writeActions = el("div", { class: "extuiaToolGroup" }, [el("h3", { text: "Ação externa" })]);
    snapshot.externalActions.forEach(function (action) { (action.method === "POST" ? writeActions : readActions).appendChild(externalActionOption(action)); });
    var manageExternalActions = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Gerenciar Ações Externas" }); manageExternalActions.addEventListener("click", function () { closeDrawer(); window.__extDashboardShell.showSection("integracoes"); });
    var externalActionsSection = el("fieldset", { class: "extuiaContextSection extuiaToolsSection" }, [
      el("legend", { text: "Ações Externas" }),
      el("p", { class: "extuiaContextNote", text: "Autorize este Assistente a chamar integrações externas (n8n, Make, ERPs) já configuradas em Integrações. Novos Assistentes começam sem nenhuma ação autorizada." })
    ].concat(snapshot.externalActions.length ? [readActions, writeActions] : [el("p", { class: "extuiaContextNote", text: "Nenhuma ação externa configurada." })]).concat([manageExternalActions]));
    var currentKnowledge = current && current.knowledge || { mode: "none", baseId: null };
    var knowledgeEnabled = el("input", { type: "checkbox", "aria-controls": "extuiaKnowledgeOptions" }); knowledgeEnabled.checked = currentKnowledge.mode === "base";
    var knowledgeSelect = el("select", { "aria-label": "Base de Conhecimento" });
    snapshot.knowledge.bases.forEach(function (base) { knowledgeSelect.appendChild(el("option", { value: base.id, text: base.name + (window.__extKnowledgeCore.isBaseReady(base) ? "" : " · requer atenção") })); });
    if (currentKnowledge.baseId && !snapshot.knowledge.bases.some(function (base) { return base.id === currentKnowledge.baseId; })) knowledgeSelect.appendChild(el("option", { value: currentKnowledge.baseId, text: "Base removida · requer atenção" }));
    knowledgeSelect.value = currentKnowledge.baseId || snapshot.knowledge.bases[0] && snapshot.knowledge.bases[0].id || "";
    var knowledgeHealth = el("p", { class: "extuiaContextNote", role: "status" });
    var manageKnowledge = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Gerenciar Bases de Conhecimento" }); manageKnowledge.addEventListener("click", function () { closeDrawer(); window.__extDashboardShell.showSection("knowledge"); });
    var knowledgeOptions = el("div", { id: "extuiaKnowledgeOptions", class: "extuiaContextOptions" }, [field("Base", knowledgeSelect), knowledgeHealth, manageKnowledge]);
    var knowledgeSection = el("fieldset", { class: "extuiaContextSection extuiaKnowledgeSection" }, [
      el("legend", { text: "Base de Conhecimento" }),
      el("label", { class: "extuiaToggle" }, [knowledgeEnabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Usar Base de Conhecimento" }), el("small", { text: "Na execução, o Extensão busca localmente os trechos mais relevantes desta base." })])]),
      knowledgeOptions
    ]);
    var currentMultimodal = current && current.multimodal || { image: false, audio: false };
    var multimodalImageEnabled = el("input", { type: "checkbox" }); multimodalImageEnabled.checked = currentMultimodal.image === true;
    var multimodalAudioEnabled = el("input", { type: "checkbox" }); multimodalAudioEnabled.checked = currentMultimodal.audio === true;
    var multimodalStatus = el("p", { class: "extuiaContextNote", role: "status" });
    var multimodalSection = el("fieldset", { class: "extuiaContextSection extuiaMultimodalSection" }, [
      el("legend", { text: "Entradas multimodais" }),
      el("label", { class: "extuiaToggle" }, [multimodalImageEnabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Imagens" }), el("small", { text: "Permite compreender a imagem atual enviada pelo cliente." })])]),
      el("label", { class: "extuiaToggle" }, [multimodalAudioEnabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Áudios" }), el("small", { text: "Permite compreender o áudio atual enviado pelo cliente." })])]),
      multimodalStatus,
      el("p", { class: "extuiaContextNote", text: "Imagens, áudios e outros conteúdos compatíveis são enviados ao serviço de IA escolhido somente durante a execução." }),
      el("p", { class: "extuiaContextCost", role: "note", text: "Pode haver consumo adicional do serviço de IA." })
    ]);
    var enabled = el("input", { type: "checkbox" }); enabled.checked = current ? current.enabled : true;
    var enabledField = el("label", { class: "extuiaToggle" }, [enabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Ativo" }), el("small", { text: "Permite usar este perfil nas próximas execuções." })])]);
    form.appendChild(field("Nome", name)); form.appendChild(field("Descrição", description, "Somente para organização interna.")); form.appendChild(field("Serviço de IA", providerSelect)); form.appendChild(field("Modelo", modelMode)); var specificField = field("Outro modelo", modelSelect); form.appendChild(specificField); form.appendChild(health); form.appendChild(field("Instruções do assistente", instructions, "Estas instruções serão reutilizadas por referência em todos os Fluxos conectados.")); form.appendChild(knowledgeSection); form.appendChild(contextSection); form.appendChild(memorySection); form.appendChild(toolsSection); form.appendChild(externalActionsSection); form.appendChild(multimodalSection); form.appendChild(enabledField); drawer.appendChild(form);
                                                                     
                                                                         
                                                                      
                                                                               
    function updateMultimodalState() {
      var provider = integrationCore.providerById(providerSelect.value);
      var caps = (provider && provider.capabilities) || {};
      var lines = [];
      if (multimodalImageEnabled.checked) lines.push(caps.vision ? "Imagem — ✓ Compatível" : "Imagem — ⚠ Modelo atual não suporta entrada de imagem");
      if (multimodalAudioEnabled.checked) lines.push(caps.audioInput ? "Áudio — ✓ Compatível" : "Áudio — ⚠ Modelo atual não suporta entrada de áudio");
      multimodalStatus.textContent = lines.join(" · ");
      multimodalStatus.className = "extuiaContextNote" + (lines.some(function (line) { return line.indexOf("⚠") >= 0; }) ? " is-attention" : "");
    }
    multimodalImageEnabled.addEventListener("change", updateMultimodalState);
    multimodalAudioEnabled.addEventListener("change", updateMultimodalState);
    function updateProviderState() {
      var metadata = snapshot.integrations.providers && snapshot.integrations.providers[providerSelect.value] || {};
      var rawModels = Array.isArray(metadata.availableModels) ? metadata.availableModels : [];
      var models = modelPolicy ? modelPolicy.primary(providerSelect.value, rawModels, false) : rawModels.map(function (model) { return { id: model.id, label: model.label || model.id, agentCompatible: true, access: "unknown" }; });
      var selected = current && current.providerId === providerSelect.value ? current.model : null;
      modelSelect.innerHTML = ""; models.forEach(function (model) { modelSelect.appendChild(el("option", { value: model.id, text: modelPolicy ? modelPolicy.optionLabel(model) : model.label })); });
      if (selected && !models.some(function (model) { return model.id === selected; })) modelSelect.appendChild(el("option", { value: selected, text: selected + " (indisponível)" }));
      modelSelect.value = selected || (models[0] && models[0].id) || ""; modelSelect.disabled = !models.length;
      specificField.hidden = modelMode.value !== "specific";
      health.innerHTML = "";
      if (!metadata.configured || metadata.status !== integrationCore.STATUSES.CONNECTED) {
        health.className = "extuiaProviderHealth is-attention"; health.appendChild(el("span", { text: providerLabel(providerSelect.value) + " requer configuração." }));
        var configure = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Configurar " + providerLabel(providerSelect.value) }); configure.addEventListener("click", function () { openIntegration(providerSelect.value); }); health.appendChild(configure);
      } else {
        var activeInfo = modelPolicy && metadata.model ? modelPolicy.info(providerSelect.value, metadata.model) : null;
        health.className = "extuiaProviderHealth is-ready"; health.appendChild(el("span", { text: "Serviço conectado · modelo escolhido: " + (metadata.model || "não definido") + (activeInfo ? " · " + (activeInfo.access === "free" ? "nível gratuito" : activeInfo.access === "paid" ? "API paga" : "plano depende da conta") : "") }));
        if (activeInfo && !activeInfo.agentCompatible) { health.className = "extuiaProviderHealth is-attention"; health.appendChild(el("small", { text: "Este modelo pode gerar texto, mas não é recomendado para Agentes da extensão. Prefira um modelo marcado como Agentes." })); }
      }
      updateMultimodalState();
    }
    providerSelect.addEventListener("change", function () { current = null; updateProviderState(); }); modelMode.addEventListener("change", updateProviderState); updateProviderState();
    function updateContextState() { contextOptions.hidden = !contextEnabled.checked; }
    contextEnabled.addEventListener("change", updateContextState); updateContextState();
    function updateKnowledgeState() {
      knowledgeOptions.hidden = !knowledgeEnabled.checked; knowledgeHealth.textContent = ""; knowledgeHealth.className = "extuiaContextNote";
      if (!knowledgeEnabled.checked) return;
      var base = window.__extKnowledgeCore.findBase(snapshot.knowledge, knowledgeSelect.value);
      var embeddingProvider = base && base.activeIndex && snapshot.integrations.providers && snapshot.integrations.providers[base.activeIndex.embeddingProviderId];
      if (!base || !window.__extKnowledgeCore.isBaseReady(base) || !embeddingProvider || !embeddingProvider.configured || !embeddingProvider.enabled || embeddingProvider.status !== integrationCore.STATUSES.CONNECTED) { knowledgeHealth.textContent = "Base de Conhecimento requer atenção."; knowledgeHealth.className += " is-attention"; }
      else knowledgeHealth.textContent = "Base pronta · " + base.chunkCount + " trechos prontos para busca.";
    }
    knowledgeEnabled.addEventListener("change", updateKnowledgeState); knowledgeSelect.addEventListener("change", updateKnowledgeState); updateKnowledgeState();
    var footer = el("footer", { class: "extuiaDrawerFooter" }); var cancel = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Cancelar" }); var save = el("button", { class: "extui-btn extui-btn--primary", type: "submit", form: "extuiaAssistantForm", text: current ? "Salvar alterações" : "Criar assistente" }); footer.appendChild(cancel); footer.appendChild(save); drawer.appendChild(footer);
    form.addEventListener("submit", async function (event) { event.preventDefault(); save.disabled = true; try { if (enabled.checked) await validateProviderForEnabledAssistant(providerSelect.value, modelMode.value, modelMode.value === "specific" ? modelSelect.value : null); if (!await confirmWriteTools() || !await confirmExternalWriteActions()) { save.disabled = false; return; } var draft = { name: name.value, description: description.value, providerId: providerSelect.value, modelMode: modelMode.value, model: modelMode.value === "specific" ? modelSelect.value : null, instructions: instructions.value, knowledge: { mode: knowledgeEnabled.checked ? "base" : "none", baseId: knowledgeEnabled.checked ? knowledgeSelect.value : null }, context: { mode: contextEnabled.checked ? "recent" : "none", messageCount: Number(contextCount.value) }, memory: { mode: memoryEnabled.checked ? "customer" : "none" }, tools: { enabled: toolInputs.filter(function (entry) { return entry.input.checked; }).map(function (entry) { return entry.definition.id; }) }, externalActions: { enabled: externalActionInputs.filter(function (entry) { return entry.input.checked; }).map(function (entry) { return entry.action.id; }) }, multimodal: { image: multimodalImageEnabled.checked, audio: multimodalAudioEnabled.checked }, enabled: enabled.checked }; if (assistantId) await repository.update(assistantId, draft); else await repository.create(draft); toast(assistantId ? "Perfil atualizado e validado." : "Perfil criado e validado."); closeDrawer(); await refresh(); } catch (error) { toast(error.message, true); save.disabled = false; } });
    function dismiss() { closeDrawer(); } backdrop.addEventListener("click", dismiss); close.addEventListener("click", dismiss); cancel.addEventListener("click", dismiss);
    var keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); dismiss(); return; } if (event.key !== "Tab") return; var focusable = drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'); if (!focusable.length) return; var first = focusable[0], last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); } }; document.addEventListener("keydown", keyHandler, true); activeDrawer = { layer: layer, previous: previous, keyHandler: keyHandler }; drawer.focus(); name.focus();
  }

  async function refresh() { snapshot = await loadSnapshot(); renderPage(); }
  async function renderSection(container) { rootEl = container; await refresh(); }
  window.__extAiAssistants = { openAssistant: function (assistantId) { openDrawer(assistantId || null); }, refresh: refresh };
  document.addEventListener("ext:dashboard-section-change", function (event) { if (!event.detail || event.detail.section !== "ai-assistants") closeDrawer(); });
  window.addEventListener("pagehide", closeDrawer);
  window.__extDashboardShell.registerSection("ai-assistants", renderSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
