try{
(function(root){
  "use strict";
  if(typeof root.__extCreateAiAgentRuntime!=="function")throw new Error("AI agent runtime core unavailable");
  root.__extAiAgentRuntime=root.__extCreateAiAgentRuntime(root.__extAiAgentsCore,root.__extAiMemoryCore,{defaultMissingTask:false});
})(typeof window!=="undefined"?window:globalThis);
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
