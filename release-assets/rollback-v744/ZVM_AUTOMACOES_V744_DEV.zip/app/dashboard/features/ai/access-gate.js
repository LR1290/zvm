try{
(function (root, factory) {
  "use strict";
  var api = factory();
  if (root) root.__extG0 = api;
})(typeof window !== "undefined" ? window : null, function () {
  "use strict";

  var STATES = Object.freeze({
    CHECKING_AUTH: "CHECKING_AUTH",
    AUTHORIZED: "AUTHORIZED",
    LOCKED: "LOCKED"
  });

  function _g0(v) { return !!(v && typeof v === "object"); }

  function _g1(adapter) {
    adapter = adapter || {};
    if (typeof adapter.resolveAccess !== "function") {
      throw new TypeError("access gate requires adapter.resolveAccess");
    }

    var generation = 0;
    var snapshot = Object.freeze({
      state: STATES.CHECKING_AUTH,
      reason: "boot",
      generation: generation
    });

    function publish(state, reason) {
      snapshot = Object.freeze({
        state: state,
        reason: reason || "",
        generation: generation
      });
      if (typeof adapter.onStateChange === "function") {
        try { adapter.onStateChange(snapshot); }
        catch (err) {                                                              }
      }
      return snapshot;
    }

    function lockedResult(reason, stale) {
      return {
        authorized: false,
        stale: !!stale,
        state: snapshot.state,
        reason: reason || snapshot.reason,
        generation: snapshot.generation
      };
    }

    function check(license, reason) {
      var requestGeneration = ++generation;
      var checkReason = reason || "access-check";

      if (!_g0(license)) {
        publish(STATES.LOCKED, checkReason === "access-check" ? "missing-credentials" : checkReason);
        return Promise.resolve(lockedResult(snapshot.reason, false));
      }

      publish(STATES.CHECKING_AUTH, checkReason);

      return Promise.resolve()
        .then(function () {
          return adapter.resolveAccess(license, {
            reason: checkReason,
            generation: requestGeneration
          });
        })
        .then(function (decision) {
          if (requestGeneration !== generation) return lockedResult("stale-response", true);

          if (decision && decision.authorized === true) {
            publish(STATES.AUTHORIZED, decision.reason || "access-authorized");
            return {
              authorized: true,
              stale: false,
              state: snapshot.state,
              reason: snapshot.reason,
              generation: snapshot.generation
            };
          }

          publish(STATES.LOCKED, decision && decision.reason || "access-denied");
          return lockedResult(snapshot.reason, false);
        }, function () {
          if (requestGeneration !== generation) return lockedResult("stale-response", true);
          publish(STATES.LOCKED, "access-check-failed");
          return lockedResult(snapshot.reason, false);
        });
    }

    function applyLicense(license, reason) {
      if (_g0(license)) {
        return check(license, reason || "credentials-changed");
      }

      generation++;
      publish(STATES.LOCKED, reason || "credentials-removed");
      return Promise.resolve(lockedResult(snapshot.reason, false));
    }

    function lock(reason) {
      generation++;
      return publish(STATES.LOCKED, reason || "access-revoked");
    }

    return Object.freeze({
      check: check,
      applyLicense: applyLicense,
      lock: lock,
      getState: function () { return snapshot.state; },
      getSnapshot: function () { return snapshot; }
    });
  }

  return Object.freeze({
    STATES: STATES,
    _g0: _g0,
    _g1: _g1
  });
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
