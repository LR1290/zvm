;
try{
(function () {
  "use strict";
  if (window.__extAiAgentsModuleBooted) return;
  window.__extAiAgentsModuleBooted = true;

  var agentsCore = window.__extAiAgentsCore;
  var assistantsCore = window.__extAiAssistantsCore;
  var integrationCore = window.__extIntegrationCore;
  var toolsRegistry = window.__extAiToolsRegistry;
  var rootEl = null;
  var snapshot = null;
  var activeDrawer = null;
  var searchTerm = "";

  function el(tag, attrs, children) {
    var node = document.createElement(tag); attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      if (key === "class") node.className = attrs[key];
      else if (key === "text") node.textContent = attrs[key];
      else if (key.slice(0, 2) === "on" && typeof attrs[key] === "function") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      else if (attrs[key] !== false && attrs[key] != null) node.setAttribute(key, attrs[key] === true ? "" : attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); });
    return node;
  }

  var ICONS = {
    agent: '<path d="M9.5 3h5l1 3 3 1.7 3-.5 1.5 4.3-2.3 2.1.2 3.5 2.1 2.2-3.1 3.6-2.9-1-3 1.8-.8 3.2h-5l-.8-3.2-3-1.8-2.9 1L1 19.3l2.1-2.2.2-3.5L1 11.5l1.5-4.3 3 .5L8.5 6z"/><circle cx="12" cy="13" r="3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v5M14 11v5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/>'
  };
  function icon(name) { var span = el("span", { class: "extuigIcon", "aria-hidden": "true" }); span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + ICONS[name] + '</svg>'; return span; }
  function storageGet(key) { return window.__extDashboardShell.storageGet(key).then(function (result) { return result && result[key]; }); }
  function storageSet(key, value) { if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value); return new Promise(function (resolve, reject) { var payload = {}; payload[key] = value; chrome.storage.local.set(payload, function () { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(); }); }); }
  function message(type, payload) { return new Promise(function (resolve, reject) { chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (response) { if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; } if (!response || response.ok !== true) { reject(new Error(response && response.userMessage || "Não foi possível carregar a configuração.")); return; } resolve(response.result); }); }); }
  function createId() { return window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : "agent-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10); }
  var repository = agentsCore.createRepository({ read: function () { return storageGet(agentsCore.STORE_KEY); }, write: function (value) { return storageSet(agentsCore.STORE_KEY, value); }, createId: createId, now: Date.now });

  function parseFlows(raw) {
    if (raw == null || raw === "") return [];
    var parsed;
    try { parsed = typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (error) { var invalid = new Error("Os dados de Fluxos estão corrompidos e não serão tratados como vazios."); invalid.code = "AI_FLOW_STORE_CORRUPT"; throw invalid; }
    if (!parsed || !parsed.state || !Array.isArray(parsed.state.flowList)) { var malformed = new Error("O armazenamento de Fluxos está em um formato inválido."); malformed.code = "AI_FLOW_STORE_INVALID"; throw malformed; }
    return parsed.state.flowList;
  }
  async function loadSnapshot() {
    var values = await Promise.all([repository.get(), storageGet(assistantsCore.STORE_KEY), message("EXTUI_INTEGRATION_GET_STATE"), storageGet("EXTUI:extappFlowStore"), message("EXTUI_KNOWLEDGE_GET_STATE")]);
    return { store: values[0], assistants: assistantsCore.normalizeStore(values[1]), integrations: values[2], flows: parseFlows(values[3]), knowledge: window.__extKnowledgeCore.normalizeStore(values[4]) };
  }
  function assistantFor(agent) { return snapshot.assistants.assistants.find(function (assistant) { return assistant.id === agent.assistantId; }) || null; }
  function providerLabel(providerId) { var provider = integrationCore.providerById(providerId); return provider ? provider.label : "Serviço indisponível"; }
  function toolDefinitions(assistant) { return assistant && toolsRegistry ? toolsRegistry.definitionsFor(assistant.tools && assistant.tools.enabled || []) : []; }
  function knowledgeLabel(assistant) { if (!assistant || !assistant.knowledge || assistant.knowledge.mode !== "base") return "Desativada"; var base = window.__extKnowledgeCore.findBase(snapshot.knowledge, assistant.knowledge.baseId); return base ? base.name : "Requer atenção"; }
  function relativeDate(value) { if (!value) return "Sem data"; var diff = Date.now() - value; if (diff < 60000) return "Editado agora"; if (diff < 3600000) return "Editado há " + Math.max(1, Math.round(diff / 60000)) + " min"; if (diff < 86400000) return "Editado há " + Math.round(diff / 3600000) + " h"; return "Editado em " + new Date(value).toLocaleDateString("pt-BR"); }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function assistantHealth(assistant) { return assistant ? assistantsCore.healthFor(assistant, snapshot.integrations, integrationCore.PROVIDER_IDS, snapshot.knowledge) : { state: "attention", label: "Assistente não selecionado" }; }
  async function validateAssistantForActiveAgent(assistant) {
    if (!assistant) throw new Error("Selecione um Assistente antes de ativar o Agente.");
    var health = assistantHealth(assistant);
    if (health.state !== "ready") throw new Error("O Assistente selecionado ainda não está pronto: " + (health.label || "revise a configuração") + ".");
    try { await message("EXTUI_INTEGRATION_TEST", { provider: assistant.providerId }); }
    catch (error) { throw new Error("A conexão de IA não passou na verificação: " + (error && error.message ? error.message : String(error))); }
    snapshot.integrations = await message("EXTUI_INTEGRATION_GET_STATE");
    health = assistantHealth(assistant);
    if (health.state !== "ready") throw new Error("A conexão respondeu, mas o Assistente ainda requer atenção: " + (health.label || "revise a configuração") + ".");
    return true;
  }
  function closeDrawer() { if (!activeDrawer) return; document.removeEventListener("keydown", activeDrawer.keyHandler, true); var previous = activeDrawer.previous; activeDrawer.layer.remove(); activeDrawer = null; if (previous && previous.isConnected) previous.focus(); }
  async function openAssistant(assistantId) { closeDrawer(); await window.__extDashboardShell.showSection("ai-assistants"); if (window.__extAiAssistants && typeof window.__extAiAssistants.openAssistant === "function") window.__extAiAssistants.openAssistant(assistantId || null); }

  function agentRow(agent) {
    var assistant = assistantFor(agent);
    var definitions = toolDefinitions(assistant);
    var health = agentsCore.healthFor(agent, snapshot.assistants, snapshot.integrations, integrationCore.PROVIDER_IDS, snapshot.knowledge);
    var article = el("article", { class: "extuigAgentRow", "data-health": health.state });
    article.appendChild(el("div", { class: "extuigAgentIdentity" }, [icon("agent"), el("div", {}, [el("h2", { text: agent.name }), el("p", { class: agent.description ? "" : "is-muted", text: agent.description || "Sem descrição interna" })])]));
    article.appendChild(el("div", { class: "extuigAgentConfig" }, [el("strong", { text: assistant ? assistant.name : "Assistente não encontrado" }), el("span", { text: definitions.length ? definitions.length + " ferramenta" + (definitions.length === 1 ? "" : "s") + " herdada" + (definitions.length === 1 ? "" : "s") : "Sem ferramentas" }), el("span", { text: "Máx. " + agent.maxSteps + " etapas" })]));
    article.appendChild(el("div", { class: "extuigAgentStatus" }, [el("span", { class: "extuigState", text: health.label }), el("small", { text: relativeDate(agent.updatedAt) })]));
    var actions = el("div", { class: "extuigAgentActions" });
    var edit = el("button", { class: "extui-btn extui-btn--secondary", type: "button" }, [icon("edit"), el("span", { text: "Editar" })]); edit.addEventListener("click", function () { openDrawer(agent.id); });
    var duplicate = el("button", { class: "extui-btn extui-btn--ghost", type: "button", "aria-label": "Duplicar " + agent.name }, [icon("copy")]); duplicate.addEventListener("click", async function () { try { await repository.duplicate(agent.id); toast("Agente duplicado."); await refresh(); } catch (error) { toast(error.message, true); } });
    var remove = el("button", { class: "extui-btn extui-btn--ghost extuigDangerAction", type: "button", "aria-label": "Excluir " + agent.name }, [icon("trash")]); remove.addEventListener("click", function () { removeAgent(agent); });
    actions.appendChild(edit); actions.appendChild(duplicate); actions.appendChild(remove); article.appendChild(actions); return article;
  }

  async function removeAgent(agent) {
    var count = agentsCore.countFlowReferences(snapshot.flows, agent.id);
    var detail = count ? "Este agente é utilizado por " + count + " Fluxo" + (count === 1 ? "." : "s.") + " As etapas permanecerão no Fluxo como “Agente não encontrado”." : "Nenhuma etapa de Fluxo será apagada.";
    if (!await window.extConfirm("Excluir “" + agent.name + "”?\n\n" + detail, { danger: true, okLabel: "Excluir agente" })) return;
    try { await repository.remove(agent.id); toast("Agente excluído."); await refresh(); } catch (error) { toast(error.message, true); }
  }

                                                                        
                                                                       
                                                                     
                                                                
                                                                              
                                                      
  function aiHubNav(activeKey) {
    var items = [{ key: "ai-connect", label: "Conexões & Recursos" }, { key: "ai-assistants", label: "Perfis IA" }, { key: "ai-agents", label: "Agentes IA" }, { key: "ai-memory", label: "Memória IA" }, { key: "knowledge", label: "Base de Conhecimento" }];
    var nav = el("nav", { class: "extuiAiHubNav", "aria-label": "Navegação do Hub de IA" });
    items.forEach(function (item) {
      var btn = el("button", { type: "button", class: "extuiAiHubNavItem" + (item.key === activeKey ? " extuiActive" : ""), text: item.label });
      if (item.key === activeKey) btn.setAttribute("aria-current", "page");
      else btn.addEventListener("click", function () { window.__extDashboardShell.showSection(item.key); });
      nav.appendChild(btn);
    });
    return nav;
  }
                                                                         
                                                                          
                                                               
                                                                     
                                                                       
                                                              
  function hasConnectedProvider() { return integrationCore.PROVIDER_IDS.some(function (id) { var item = snapshot.integrations && snapshot.integrations.providers && snapshot.integrations.providers[id]; return !!(item && item.configured && item.enabled && item.status === integrationCore.STATUSES.CONNECTED); }); }
  function aiSetupPath(activeKey, hasAssistants, hasAgents) {
    var hasConnection = hasConnectedProvider();
    var path = el("div", { class: "extuiAiSetupPath", role: "group", "aria-label": "Ordem recomendada de configuração" });
    var steps = [
      { n: 1, key: "ai-connect", title: "Conexão IA", desc: "Conecte um serviço", status: hasConnection ? "Concluído" : "Pendente" },
      { n: 2, key: "ai-assistants", title: "Perfis IA", desc: "Defina o comportamento", status: hasAssistants ? "Concluído" : "Pendente" },
      { n: 3, key: "ai-agents", title: "Agentes IA", desc: "Use um perfil", status: hasAgents ? "Configurado" : (hasAssistants ? "Passo atual" : "Pendente") },
      { n: 4, key: "ai-memory", title: "Memória IA", desc: "Enriqueça o contexto", status: "Opcional" },
      { n: 5, key: "knowledge", title: "Conhecimento", desc: "Ensine fatos específicos", status: "Opcional" }
    ];
    steps.forEach(function (step) {
      var stateName = step.key === activeKey ? "current" : ((step.key === "ai-connect" && hasConnection) || (step.key === "ai-assistants" && hasAssistants) || (step.key === "ai-agents" && hasAgents) ? "done" : "pending");
      var btn = el("button", { type: "button", class: "extuiAiSetupStep", "data-state": stateName });
      btn.appendChild(el("div", { class: "extuiAiSetupStepHead" }, [el("span", { class: "extuiAiSetupStepNumber", text: String(step.n) }), el("span", { class: "extuiAiSetupStepTitle", text: step.title })]));
      btn.appendChild(el("span", { class: "extuiAiSetupStepDesc", text: step.desc }));
      btn.appendChild(el("span", { class: "extuiAiSetupStepStatus", text: step.status }));
      if (step.key !== activeKey) btn.addEventListener("click", function () { window.__extDashboardShell.showSection(step.key); });
      path.appendChild(btn);
    });
    return path;
  }
                                                                         
                                                                         
                                                             
  function aiPrereqNotice() {
    var notice = el("div", { class: "extuiAiPrereqNotice", role: "note" }, [el("p", { text: "Crie um Perfil IA antes de configurar um Agente." })]);
    var cta = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Criar Perfil IA" });
    cta.addEventListener("click", function () { openAssistant(null); });
    notice.appendChild(cta);
    return notice;
  }

  function renderPage() {
    rootEl.innerHTML = "";
    var page = el("div", { class: "extuiaPage extuigPage" });
    var agents = snapshot.store.agents;
    var hasAssistants = snapshot.assistants.assistants.length > 0;
    page.appendChild(aiHubNav("ai-agents"));
    page.appendChild(aiSetupPath("ai-agents", hasAssistants, agents.length > 0));
    var header = el("header", { class: "extuigHeader", "data-extui-academy-target": "ai-agents-header" }, [el("div", {}, [el("span", { class: "extuigEyebrow", text: "AUTOMAÇÃO" }), el("h1", { text: "Agentes IA" }), el("p", { text: "Crie automações inteligentes capazes de consultar dados e executar ações permitidas na extensão." })])]);
    if (hasAssistants && agents.length) { var create = el("button", { class: "extui-btn extui-btn--primary", type: "button", "data-extui-academy-target": "ai-agents-new" }, [icon("plus"), el("span", { text: "Novo agente" })]); create.addEventListener("click", function () { openDrawer(null); }); header.appendChild(create); }
    page.appendChild(header);
    if (!hasAssistants) page.appendChild(aiPrereqNotice());
    var active = agents.filter(function (agent) { return agentsCore.healthFor(agent, snapshot.assistants, snapshot.integrations, integrationCore.PROVIDER_IDS, snapshot.knowledge).state === "ready"; }).length;
    var attention = agents.filter(function (agent) { return agentsCore.healthFor(agent, snapshot.assistants, snapshot.integrations, integrationCore.PROVIDER_IDS, snapshot.knowledge).state === "attention"; }).length;
    page.appendChild(el("section", { class: "extuigSummary", "aria-label": "Resumo dos agentes" }, [el("div", {}, [el("strong", { text: String(agents.length) }), el("span", { text: "agentes" })]), el("div", {}, [el("strong", { text: String(active) }), el("span", { text: "ativos" })]), el("div", {}, [el("strong", { text: String(attention) }), el("span", { text: "requerem atenção" })])]));
    if (agents.length) {
      var search = el("div", { class: "extuigSearch" }, [icon("search")]); var input = el("input", { type: "search", value: searchTerm, placeholder: "Buscar agente", "aria-label": "Buscar agente" }); input.addEventListener("input", function () { searchTerm = input.value; renderList(list); }); search.appendChild(input); page.appendChild(search);
    }
    var list = el("section", { class: "extuigList", "aria-label": "Agentes de IA" }); page.appendChild(list); rootEl.appendChild(page); renderList(list);
  }

  function renderList(list) {
    list.innerHTML = ""; var agents = snapshot.store.agents; var term = searchTerm.trim().toLowerCase(); var filtered = agents.filter(function (agent) { var assistant = assistantFor(agent); return !term || [agent.name, agent.description, assistant && assistant.name].join(" ").toLowerCase().indexOf(term) >= 0; });
    if (!agents.length) {
      var emptyChildren=[icon("agent"), el("h2", { text: "Crie seu primeiro agente" }), el("p", { text: "Combine um Perfil IA existente com um objetivo e limites claros. A execução acontecerá somente quando um Fluxo chamar o agente." })];
      if (snapshot.assistants.assistants.length) emptyChildren.push(el("button", { class: "extui-btn extui-btn--primary", type: "button", text: "Criar primeiro agente", onclick: function () { openDrawer(null); } }));
      else emptyChildren.push(el("button", { class: "extui-btn extui-btn--primary", type: "button", text: "Criar Perfil IA", onclick: function () { window.__extDashboardShell.showSection("ai-assistants"); } }));
      list.appendChild(el("div", { class: "extuigEmpty" }, emptyChildren)); return;
    }
    if (!filtered.length) { list.appendChild(el("div", { class: "extuigNoResults", text: "Nenhum agente corresponde à busca." })); return; }
    filtered.forEach(function (agent) { list.appendChild(agentRow(agent)); });
  }

  function field(label, control, hint) { var children = [el("span", { text: label }), control]; if (hint) children.push(el("small", { text: hint })); return el("label", { class: "extuigField" }, children); }
  function capability(label, value) { return el("div", { class: "extuigCapability" }, [el("span", { text: label }), el("strong", { text: value })]); }

  function openDrawer(agentId) {
    closeDrawer();
    var current = snapshot.store.agents.find(function (agent) { return agent.id === agentId; }) || null;
    var previous = document.activeElement;
    var layer = el("div", { class: "extuigDrawerLayer" }); var backdrop = el("button", { class: "extuigDrawerBackdrop", type: "button", "aria-label": "Fechar editor" }); var drawer = el("aside", { class: "extuigDrawer", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuigDrawerTitle", tabindex: "-1" }); layer.appendChild(backdrop); layer.appendChild(drawer); document.body.appendChild(layer);
    var close = el("button", { class: "extuigClose", type: "button", "aria-label": "Fechar", text: "×" }); drawer.appendChild(el("header", { class: "extuigDrawerHeader" }, [el("div", {}, [el("span", { class: "extuigEyebrow", text: current ? "EDITAR AGENTE" : "NOVO AGENTE" }), el("h2", { id: "extuigDrawerTitle", text: current ? current.name : "Novo agente de IA" })]), close]));
    var form = el("form", { class: "extuigForm", id: "extuigAgentForm" }); var name = el("input", { type: "text", maxlength: "120", required: true, value: current && current.name || "" }); var description = el("textarea", { maxlength: "500", value: current && current.description || "", rows: "3" }); var assistantSelect = el("select", { required: true, "aria-label": "Assistente do agente" }); assistantSelect.appendChild(el("option", { value: "", text: "Selecione um Assistente pronto" })); snapshot.assistants.assistants.forEach(function (assistant) { var health = assistantHealth(assistant); var option = el("option", { value: assistant.id, text: assistant.name + (health.state === "ready" ? " · pronto" : " · " + (health.label || "requer atenção")) }); if (health.state !== "ready" && (!current || current.assistantId !== assistant.id)) option.disabled = true; assistantSelect.appendChild(option); }); if (current && current.assistantId && !snapshot.assistants.assistants.some(function (assistant) { return assistant.id === current.assistantId; })) assistantSelect.appendChild(el("option", { value: current.assistantId, text: "Assistente não encontrado" })); assistantSelect.value = current && current.assistantId || "";
    var objective = el("textarea", { maxlength: "6000", required: true, rows: "9", value: current && current.objective || "", placeholder: "Qualifique o cliente atual. Consulte o CRM quando necessário e conclua com uma resposta objetiva." });
    var maxSteps = current ? current.maxSteps : agentsCore.DEFAULT_MAX_STEPS; var stepSelector = el("div", { class: "extuigStepSelector", role: "radiogroup", "aria-label": "Limite de etapas" }); var stepInputs = [];
    agentsCore.MAX_STEPS_OPTIONS.forEach(function (value) { var input = el("input", { type: "radio", name: "maxSteps", value: String(value), id: "extuigSteps" + value }); input.checked = value === maxSteps; stepInputs.push(input); stepSelector.appendChild(el("label", { class: "extuigStepOption", for: input.id }, [input, el("span", { text: String(value) }), el("small", { text: value === 3 ? "curto" : value === 5 ? "equilibrado" : "amplo" })])); });
    var enabled = el("input", { type: "checkbox" }); enabled.checked = current ? current.enabled : true; var enabledField = el("label", { class: "extuigToggle" }, [enabled, el("span", { class: "extuigToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Ativo" }), el("small", { text: "Disponível para as próximas execuções de Fluxos." })])]);
                                                                           
                                                                         
                                                                           
                                                                            
                                                                      
    var useMemory = el("input", { type: "checkbox" }); useMemory.checked = current ? current.useMemory !== false : false;
    var useMemoryField = el("label", { class: "extuigToggle" }, [useMemory, el("span", { class: "extuigToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Ativar uso de memórias de clientes quando disponível" }), el("small", { text: "Só tem efeito se o Assistente selecionado também tiver Memória ativa." })])]);
    var useKnowledge = el("input", { type: "checkbox" }); useKnowledge.checked = current ? current.useKnowledge !== false : false;
    var useKnowledgeField = el("label", { class: "extuigToggle" }, [useKnowledge, el("span", { class: "extuigToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Ativar uso de bases de conhecimento quando disponíveis" }), el("small", { text: "Só tem efeito se o Assistente selecionado também tiver uma Base de Conhecimento ativa." })])]);
    var capabilities = el("section", { class: "extuigCapabilities", "aria-labelledby": "extuigCapabilitiesTitle", "data-extui-academy-target": "ai-agents-capabilities" }, [el("div", { class: "extuigCapabilitiesHeader" }, [icon("shield"), el("div", {}, [el("h3", { id: "extuigCapabilitiesTitle", text: "Capacidades herdadas" }), el("p", { text: "A extensão confere estas dependências antes de permitir um Agente ativo." })])]), el("div", { class: "extuigCapabilityGrid" })]); var capabilityGrid = capabilities.querySelector(".extuigCapabilityGrid");
    var validation = el("p", { class: "extuigWriteWarning", role: "status", "aria-live": "polite" }); var warning = el("p", { class: "extuigWriteWarning", role: "note" }); var editAssistant = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Editar Assistente ↗" });
    var verifyAssistant = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Verificar configuração" });
    function updateCapabilities() {
      capabilityGrid.innerHTML = ""; warning.hidden = true; validation.hidden = false; var assistant = snapshot.assistants.assistants.find(function (entry) { return entry.id === assistantSelect.value; });
      if (!assistant) { useMemory.checked = false; useMemory.disabled = true; useKnowledge.checked = false; useKnowledge.disabled = true; validation.textContent = "Selecione um Assistente pronto para continuar."; capabilityGrid.appendChild(el("p", { class: "extuigCapabilityEmpty", text: assistantSelect.value ? "Assistente não encontrado. Selecione outro perfil." : "Selecione um Assistente para visualizar as capacidades." })); editAssistant.textContent = "Criar Assistente ↗"; verifyAssistant.disabled = true; return; }
      var health = assistantHealth(assistant); var definitions = toolDefinitions(assistant); var memoryAvailable = !!(assistant.memory && assistant.memory.mode === "customer"); var knowledgeAvailable = !!(assistant.knowledge && assistant.knowledge.mode === "base" && knowledgeLabel(assistant) !== "Requer atenção");
      useMemory.disabled = !memoryAvailable; if (!memoryAvailable) useMemory.checked = false;
      useKnowledge.disabled = !knowledgeAvailable; if (!knowledgeAvailable) useKnowledge.checked = false;
      capabilityGrid.appendChild(capability("Estado", health.state === "ready" ? "Pronto" : (health.label || "Requer atenção"))); capabilityGrid.appendChild(capability("Serviço de IA", providerLabel(assistant.providerId))); capabilityGrid.appendChild(capability("Contexto", assistant.context && assistant.context.mode === "recent" ? assistant.context.messageCount + " mensagens" : "Desativado")); capabilityGrid.appendChild(capability("Memória", memoryAvailable ? "Disponível" : "Não configurada")); capabilityGrid.appendChild(capability("Base de Conhecimento", knowledgeLabel(assistant))); capabilityGrid.appendChild(capability("Ferramentas", definitions.length + " permitida" + (definitions.length === 1 ? "" : "s"))); editAssistant.textContent = "Editar Assistente ↗";
      validation.textContent = health.state === "ready" ? "✓ Estrutura pronta. Use Verificar configuração para confirmar a conexão agora." : "Antes de ativar o Agente: " + (health.label || "revise o Assistente") + "."; verifyAssistant.disabled = health.state !== "ready";
      warning.hidden = !definitions.some(function (definition) { return definition.risk === "write"; }); warning.textContent = "Este agente pode alterar dados da extensão usando as ferramentas permitidas no Assistente.";
    }
    assistantSelect.addEventListener("change", updateCapabilities); editAssistant.addEventListener("click", function () { var known = snapshot.assistants.assistants.some(function (entry) { return entry.id === assistantSelect.value; }); openAssistant(known ? assistantSelect.value : null); }); verifyAssistant.addEventListener("click", async function () { var assistant = snapshot.assistants.assistants.find(function (entry) { return entry.id === assistantSelect.value; }); verifyAssistant.disabled = true; validation.textContent = "Verificando conexão e modelo…"; try { await validateAssistantForActiveAgent(assistant); validation.textContent = "✓ Configuração verificada. Este Agente está pronto para ser ativado."; toast("Configuração do Agente verificada."); } catch (error) { validation.textContent = error.message; toast(error.message, true); } finally { updateCapabilities(); } });
    form.appendChild(field("Nome", name)); form.appendChild(field("Descrição", description, "Somente para organização interna.")); form.appendChild(field("Assistente", assistantSelect, "Escolha apenas um Assistente marcado como pronto. A extensão valida conexão, modelo e dependências antes de ativar o Agente.")); form.appendChild(el("p", { class: "extuigCostNote", role: "note", text: "Sem ferramentas, o Agente responde diretamente. Quando o Assistente possui ferramentas, a extensão usa execução controlada em etapas." })); form.appendChild(field("Objetivo do agente", objective, "Descreva o resultado esperado e as regras operacionais. A tarefa específica será definida e validada dentro do Fluxo.")); form.appendChild(el("fieldset", { class: "extuigStepField" }, [el("legend", { text: "Limite de etapas" }), stepSelector, el("small", { text: "O limite só é relevante quando a execução precisa de várias etapas. O recomendado é 5." })])); form.appendChild(enabledField); form.appendChild(useMemoryField); form.appendChild(useKnowledgeField); form.appendChild(capabilities); form.appendChild(validation); form.appendChild(verifyAssistant); form.appendChild(warning); form.appendChild(editAssistant); form.appendChild(el("p", { class: "extuigCostNote", text: "Um Agente ativo só é salvo depois que suas dependências essenciais passam na validação." })); drawer.appendChild(form); updateCapabilities();
    var footer = el("footer", { class: "extuigDrawerFooter" }); var cancel = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Cancelar" }); var save = el("button", { class: "extui-btn extui-btn--primary", type: "submit", form: "extuigAgentForm", text: current ? "Salvar alterações" : "Criar agente" }); footer.appendChild(cancel); footer.appendChild(save); drawer.appendChild(footer);
    form.addEventListener("submit", async function (event) { event.preventDefault(); save.disabled = true; try { var selectedStep = stepInputs.find(function (input) { return input.checked; }); var assistant = snapshot.assistants.assistants.find(function (entry) { return entry.id === assistantSelect.value; }); if (enabled.checked) await validateAssistantForActiveAgent(assistant); var memoryAllowed = !!(assistant && assistant.memory && assistant.memory.mode === "customer"); var knowledgeAllowed = !!(assistant && assistant.knowledge && assistant.knowledge.mode === "base" && knowledgeLabel(assistant) !== "Requer atenção"); var draft = { name: name.value, description: description.value, assistantId: assistantSelect.value, objective: objective.value, maxSteps: selectedStep ? Number(selectedStep.value) : agentsCore.DEFAULT_MAX_STEPS, useMemory: memoryAllowed && useMemory.checked, useKnowledge: knowledgeAllowed && useKnowledge.checked, enabled: enabled.checked }; if (agentId) await repository.update(agentId, draft); else await repository.create(draft); toast(agentId ? "Agente atualizado e validado." : "Agente criado e validado."); closeDrawer(); await refresh(); } catch (error) { toast(error.message, true); validation.hidden = false; validation.textContent = error.message; save.disabled = false; } });
    function dismiss() { closeDrawer(); } backdrop.addEventListener("click", dismiss); close.addEventListener("click", dismiss); cancel.addEventListener("click", dismiss);
    var keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); dismiss(); return; } if (event.key !== "Tab") return; var focusable = drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'); if (!focusable.length) return; var first = focusable[0], last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); } }; document.addEventListener("keydown", keyHandler, true); activeDrawer = { layer: layer, previous: previous, keyHandler: keyHandler }; drawer.focus(); name.focus();
  }

  async function refresh() { snapshot = await loadSnapshot(); renderPage(); }
  async function renderSection(container) { rootEl = container; await refresh(); }
  window.__extAiAgents = { openAgent: function (agentId) { openDrawer(agentId || null); }, refresh: refresh };
  document.addEventListener("ext:dashboard-section-change", function (event) { if (!event.detail || event.detail.section !== "ai-agents") closeDrawer(); });
  window.addEventListener("pagehide", closeDrawer);
  window.__extDashboardShell.registerSection("ai-agents", renderSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
