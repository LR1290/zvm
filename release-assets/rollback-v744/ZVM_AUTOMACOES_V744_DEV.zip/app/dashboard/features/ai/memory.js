;
try{
(function () {
  "use strict";
  if (window.__extAiMemoryModuleBooted) return;
  window.__extAiMemoryModuleBooted = true;

  var core = window.__extAiMemoryCore;
                                                                            
                                                                           
                                                                          
                                                                          
                                              
  var assistantsCore = window.__extAiAssistantsCore;
  var agentsCore = window.__extAiAgentsCore;
  var integrationCore = window.__extIntegrationCore;
  var setupPathFlags = { hasConnection: false, hasAssistants: false, hasAgents: false, agents: [] };
  var rootEl = null;
  var contactsPromise = null;
  var contactsPromiseAt = 0;
  var CONTACTS_CACHE_TTL_MS = 60000;
  var selectedContact = null;
  var selectedSubjectKey = null;
  var entries = [];
  var activeDialog = null;

  function el(tag, attrs, children) {
    var node = document.createElement(tag); attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      if (key === "class") node.className = attrs[key];
      else if (key === "text") node.textContent = attrs[key];
      else if (key.slice(0, 2) === "on" && typeof attrs[key] === "function") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      else if (attrs[key] !== false && attrs[key] != null) node.setAttribute(key, attrs[key] === true ? "" : attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); });
    return node;
  }
  function storageGet(key) { return window.__extDashboardShell.storageGet(key).then(function (result) { return result && result[key]; }); }
  function storageSet(key, value) { if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value); return new Promise(function (resolve, reject) { var payload = {}; payload[key] = value; chrome.storage.local.set(payload, function () { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(); }); }); }
  function createId() { return window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : "memory-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10); }
  var repository = core.createRepository({ read: function () { return storageGet(core.STORE_KEY); }, write: function (value) { return storageSet(core.STORE_KEY, value); }, createId: createId, now: Date.now });

  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
                                                                           
                                                                       
  function agentAclField(currentAllowedAgentIds, allAgents) {
    allAgents = Array.isArray(allAgents) ? allAgents : [];
    var wrap = el("div", { class: "extuiaAgentAcl" });
    if (!allAgents.length) {
      wrap.appendChild(el("p", { class: "extuiaAgentAclEmpty", text: "Crie um Agente IA para poder restringir esta memória. Enquanto não houver Agentes, ela permanece disponível para qualquer Agente elegível criado no futuro." }));
      return { el: wrap, getValue: function () { return null; } };
    }
    var restricted = Array.isArray(currentAllowedAgentIds);
    var selected = {}; (currentAllowedAgentIds || []).forEach(function (id) { selected[id] = true; });
    var groupName = "extappMemoryAcl" + Math.random().toString(36).slice(2, 8);
    var allRadio = el("input", { type: "radio", name: groupName }); allRadio.checked = !restricted;
    var restrictedRadio = el("input", { type: "radio", name: groupName }); restrictedRadio.checked = restricted;
    var modeRow = el("div", { class: "extuiaAgentAclMode", role: "radiogroup", "aria-label": "Agentes que podem usar esta memória" }, [
      el("label", {}, [allRadio, el("span", { text: "Todos os Agentes elegíveis" })]),
      el("label", {}, [restrictedRadio, el("span", { text: "Somente Agentes selecionados" })])
    ]);
    var search = el("input", { type: "search", placeholder: "Buscar agente...", "aria-label": "Buscar agente" });
    var toolbar = el("div", { class: "extuiaAgentAclToolbar" }, [search]);
    var selectAllBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extui-btn--sm", text: "Selecionar todos" });
    var clearBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extui-btn--sm", text: "Limpar seleção" });
    toolbar.appendChild(selectAllBtn); toolbar.appendChild(clearBtn);
    var list = el("div", { class: "extuiaAgentAclList", role: "group", "aria-label": "Agentes permitidos" });
    var checkboxes = allAgents.map(function (agent) {
      var checkbox = el("input", { type: "checkbox" }); checkbox.checked = !!selected[agent.id];
      var row = el("label", { class: "extuiaAgentAclRow" }, [checkbox, el("span", { text: agent.name || "(sem nome)" })]);
      list.appendChild(row); return { agent: agent, checkbox: checkbox, row: row };
    });
    var restrictedBlock = el("div", { class: "extuiaAgentAclRestricted" }, [toolbar, list]);
    function syncVisibility() { restrictedBlock.hidden = !restrictedRadio.checked; }
    allRadio.addEventListener("change", syncVisibility); restrictedRadio.addEventListener("change", syncVisibility); syncVisibility();
    search.addEventListener("input", function () {
      var query = search.value.trim().toLocaleLowerCase("pt-BR");
      checkboxes.forEach(function (entry) { entry.row.hidden = query && (entry.agent.name || "").toLocaleLowerCase("pt-BR").indexOf(query) < 0; });
    });
    selectAllBtn.addEventListener("click", function () { checkboxes.forEach(function (entry) { if (!entry.row.hidden) entry.checkbox.checked = true; }); });
    clearBtn.addEventListener("click", function () { checkboxes.forEach(function (entry) { entry.checkbox.checked = false; }); });
    wrap.appendChild(modeRow); wrap.appendChild(restrictedBlock);
    return { el: wrap, getValue: function () { return restrictedRadio.checked ? checkboxes.filter(function (entry) { return entry.checkbox.checked; }).map(function (entry) { return entry.agent.id; }) : null; } };
  }

  function fetchWhatsAppContacts() {
    if (contactsPromise && Date.now() - contactsPromiseAt < CONTACTS_CACHE_TTL_MS) return contactsPromise;
    contactsPromise = null;
    contactsPromiseAt = Date.now();
    contactsPromise = new Promise(function (resolve) {
      var requestId = "ai-memory-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      var finished = false; var timeoutId;
      function finish(value) { if (finished) return; finished = true; clearTimeout(timeoutId); resolve(Array.isArray(value) ? value : []); }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        var tab = (tabs || [])[0];
        if (!tab) { finish([]); return; }
        chrome.tabs.sendMessage(tab.id, { type: "EXTUI_CRM_FETCH_CONTACTS_V2", requestId: requestId }, function (response) {
          if (chrome.runtime.lastError || !response || response.requestId !== requestId || response.error) { finish([]); return; }
          finish(response.data || []);
        });
        timeoutId = setTimeout(function () { finish([]); }, 25000);
      });
    }).then(function (contacts) {
      if (!contacts.length) { contactsPromise = null; contactsPromiseAt = 0; }
      return contacts;
    }, function (error) { contactsPromise = null; contactsPromiseAt = 0; throw error; });
    return contactsPromise;
  }
  function relativeDate(value) {
    if (!value) return "Sem data"; var diff = Date.now() - value;
    if (diff < 60000) return "Agora";
    if (diff < 86400000) return "Hoje, " + new Date(value).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    if (diff < 172800000) return "Ontem";
    return "Editado em " + new Date(value).toLocaleDateString("pt-BR");
  }
  function currentRouteIsMemory() { return window.__extDashboardShell && window.__extDashboardShell.getCurrentSection() === "ai-memory"; }
  async function reloadSelectedEntries() {
    entries = selectedSubjectKey ? await repository.listForSubject(selectedSubjectKey) : [];
    if (currentRouteIsMemory()) renderCustomerArea();
  }
  function closeDialog() {
    if (!activeDialog) return; document.removeEventListener("keydown", activeDialog.keyHandler, true);
    var previous = activeDialog.previous; activeDialog.layer.remove(); activeDialog = null; if (previous && previous.isConnected) previous.focus();
  }
  function openEntryDialog(entry) {
    closeDialog(); var previous = document.activeElement;
    var layer = el("div", { class: "extappMemoryDialogLayer" }); var backdrop = el("button", { type: "button", class: "extappMemoryDialogBackdrop", "aria-label": "Fechar" });
    var dialog = el("section", { class: "extappMemoryDialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "extappMemoryDialogTitle", tabindex: "-1" });
    var type = el("select", { "aria-label": "Tipo de memória" }); core.CATEGORIES.forEach(function (category) { type.appendChild(el("option", { value: category, text: core.CATEGORY_LABELS[category] })); }); type.value = entry && entry.category || "preference";
    var text = el("textarea", { maxlength: String(core.MAX_ENTRY_CHARS), rows: "6", placeholder: "Prefere atendimento no período da tarde.", "aria-label": "Memória do cliente" }); text.value = entry && entry.text || "";
    var count = el("span", { class: "extappMemoryCharCount", text: text.value.length + "/" + core.MAX_ENTRY_CHARS }); text.addEventListener("input", function () { count.textContent = text.value.length + "/" + core.MAX_ENTRY_CHARS; });
    var memoryAcl = agentAclField(entry && entry.allowedAgentIds, setupPathFlags.agents);
    var cancel = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" }); var save = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Salvar memória" });
    dialog.appendChild(el("header", { class: "extappMemoryDialogHeader" }, [el("div", {}, [el("span", { class: "extappMemoryEyebrow", text: entry ? "EDITAR" : "NOVA MEMÓRIA" }), el("h2", { id: "extappMemoryDialogTitle", text: entry ? "Editar memória" : "Adicionar memória" })]), el("button", { type: "button", class: "extappMemoryDialogClose", "aria-label": "Fechar", text: "×", onclick: closeDialog })]));
    var dialogBody = el("div", { class: "extappMemoryDialogBody" }, [
      el("label", { class: "extappMemoryField" }, [el("span", { text: "Tipo" }), type]),
      el("label", { class: "extappMemoryField" }, [el("span", { text: "Memória" }), text, count]),
      el("fieldset", { class: "extappMemoryAclSection" }, [el("legend", { text: "Agentes autorizados" }), el("p", { class: "extappMemoryAclHint", text: "Escolha quais Agentes IA poderão receber esta memória quando o cliente atual estiver em atendimento. O Agente também precisa estar com o uso de memórias ativado." }), memoryAcl.el]),
      el("p", { class: "extappMemoryPrivacy", text: "Salve apenas informações úteis para o atendimento. Evite registrar senhas, documentos, dados financeiros ou informações sensíveis desnecessárias." })
    ]);
    dialog.appendChild(dialogBody);
    dialog.appendChild(el("footer", { class: "extappMemoryDialogFooter" }, [cancel, save])); layer.appendChild(backdrop); layer.appendChild(dialog); document.body.appendChild(layer);
    save.addEventListener("click", async function () {
      save.disabled = true;
      try {
        var draft = { category: type.value, text: text.value, allowedAgentIds: memoryAcl.getValue() };
        if (entry) await repository.update(selectedSubjectKey, entry.id, draft);
        else await repository.add(selectedSubjectKey, draft);
        closeDialog(); toast(entry ? "Memória atualizada." : "Memória adicionada."); await reloadSelectedEntries();
      } catch (error) { toast(error.message, true); save.disabled = false; }
    });
    cancel.addEventListener("click", closeDialog); backdrop.addEventListener("click", closeDialog);
    var keyHandler = function (event) {
      if (event.key === "Escape") { event.preventDefault(); closeDialog(); return; }
      if (event.key !== "Tab") return;
      var focusable = dialog.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled])'); if (!focusable.length) return;
      var first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", keyHandler, true); activeDialog = { layer: layer, previous: previous, keyHandler: keyHandler }; dialog.focus(); text.focus();
  }
  async function deleteEntry(entry) {
    if (!await window.extConfirm("Excluir esta memória do cliente?", { danger: true, okLabel: "Excluir memória" })) return;
    try { await repository.remove(selectedSubjectKey, entry.id); toast("Memória excluída."); await reloadSelectedEntries(); }
    catch (error) { toast(error.message, true); }
  }
  function renderCustomerArea() {
    if (!rootEl) return; var area = rootEl.querySelector("#extappMemoryCustomerArea"); if (!area) return; area.innerHTML = "";
    if (!selectedContact) {
      area.appendChild(el("section", { class: "extappMemoryEmpty" }, [el("div", { class: "extappMemoryEmptyIcon", "aria-hidden": "true", text: "◎" }), el("h2", { text: "Selecione um cliente" }), el("p", { text: "Busque um contato do WhatsApp para visualizar e administrar suas memórias." })])); return;
    }
    if (!selectedSubjectKey) {
      area.appendChild(el("section", { class: "extappMemoryUnavailable", role: "status" }, [el("h2", { text: selectedContact.name || "Contato" }), el("p", { text: "A identidade deste contato não pôde ser resolvida com segurança. Nenhuma memória pode ser criada para ele." })])); return;
    }
    var header = el("header", { class: "extappMemoryCustomerHeader" }, [el("div", {}, [el("span", { class: "extappMemoryEyebrow", text: "CLIENTE SELECIONADO" }), el("h2", { text: selectedContact.name || "Contato" }), el("p", { text: core.normalizePhone(selectedContact.phoneNumber) || "Telefone não disponível" })])]);
    var addButton = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Adicionar memória" }); addButton.disabled = entries.length >= core.MAX_ENTRIES_PER_SUBJECT; addButton.addEventListener("click", function () { openEntryDialog(null); }); header.appendChild(addButton); area.appendChild(header);
    area.appendChild(el("div", { class: "extappMemoryCount", role: "status", text: entries.length + " de " + core.MAX_ENTRIES_PER_SUBJECT + " memórias" }));
    if (!entries.length) area.appendChild(el("section", { class: "extappMemoryEmpty extappMemoryEmpty--compact" }, [el("h3", { text: "Nenhuma memória salva" }), el("p", { text: "Adicione fatos úteis que poderão ser utilizados pelos Assistentes autorizados." })]));
    else {
      var list = el("section", { class: "extappMemoryList", "aria-label": "Memórias do cliente" });
      entries.forEach(function (entry) {
        var edit = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Editar" }); edit.addEventListener("click", function () { openEntryDialog(entry); });
        var remove = el("button", { type: "button", class: "extui-btn extui-btn--ghost extappMemoryDanger", text: "Excluir" }); remove.addEventListener("click", function () { deleteEntry(entry); });
        var aclText = Array.isArray(entry.allowedAgentIds) ? (entry.allowedAgentIds.length + " Agente" + (entry.allowedAgentIds.length === 1 ? " autorizado" : "s autorizados")) : "Todos os Agentes elegíveis";
        list.appendChild(el("article", { class: "extappMemoryEntry" }, [el("div", { class: "extappMemoryEntryBody" }, [el("span", { class: "extappMemoryCategory", text: core.CATEGORY_LABELS[entry.category] }), el("p", { text: entry.text }), el("small", { text: relativeDate(entry.updatedAt) + " · " + aclText })]), el("div", { class: "extappMemoryEntryActions" }, [edit, remove])]));
      });
      area.appendChild(list);
    }
    var clearSubject = el("button", { type: "button", class: "extui-btn extui-btn--ghost extappMemoryDanger", text: "Apagar todas as memórias deste cliente" }); clearSubject.disabled = !entries.length;
    clearSubject.addEventListener("click", async function () {
      if (!await window.extConfirm("Apagar todas as memórias deste cliente? Esta ação não pode ser desfeita.", { danger: true, okLabel: "Apagar memórias" })) return;
      try { await repository.clearSubject(selectedSubjectKey); toast("Memórias do cliente apagadas."); await reloadSelectedEntries(); }
      catch (error) { toast(error.message, true); }
    });
    area.appendChild(el("div", { class: "extappMemoryCustomerDanger" }, [clearSubject]));
  }
  async function selectContact(contact) {
    selectedContact = contact; selectedSubjectKey = await core.deriveSubjectKey(contact && contact.phoneNumber); entries = selectedSubjectKey ? await repository.listForSubject(selectedSubjectKey) : []; renderCustomerArea();
  }
                                                                           
                                                                        
                                     
                                                                              
                                                      
  function aiHubNav(activeKey) {
    var items = [{ key: "ai-connect", label: "Conexões & Recursos" }, { key: "ai-assistants", label: "Perfis IA" }, { key: "ai-agents", label: "Agentes IA" }, { key: "ai-memory", label: "Memória IA" }, { key: "knowledge", label: "Base de Conhecimento" }];
    var nav = el("nav", { class: "extuiAiHubNav", "aria-label": "Navegação do Hub de IA" });
    items.forEach(function (item) {
      var btn = el("button", { type: "button", class: "extuiAiHubNavItem" + (item.key === activeKey ? " extuiActive" : ""), text: item.label });
      if (item.key === activeKey) btn.setAttribute("aria-current", "page");
      else btn.addEventListener("click", function () { window.__extDashboardShell.showSection(item.key); });
      nav.appendChild(btn);
    });
    return nav;
  }
                                                                       
                                                                         
  function aiSetupPath(activeKey, hasAssistants, hasAgents) {
    var hasConnection = setupPathFlags.hasConnection === true;
    var path = el("div", { class: "extuiAiSetupPath", role: "group", "aria-label": "Ordem recomendada de configuração" });
    var steps = [
      { n: 1, key: "ai-connect", title: "Conexão IA", desc: "Conecte um serviço", status: hasConnection ? "Concluído" : "Pendente" },
      { n: 2, key: "ai-assistants", title: "Perfis IA", desc: "Defina o comportamento", status: hasAssistants ? "Concluído" : "Pendente" },
      { n: 3, key: "ai-agents", title: "Agentes IA", desc: "Use um perfil", status: hasAgents ? "Configurado" : "Pendente" },
      { n: 4, key: "ai-memory", title: "Memória IA", desc: "Enriqueça o contexto", status: "Opcional" },
      { n: 5, key: "knowledge", title: "Conhecimento", desc: "Ensine fatos específicos", status: "Opcional" }
    ];
    steps.forEach(function (step) {
      var stateName = step.key === activeKey ? "current" : ((step.key === "ai-connect" && hasConnection) || (step.key === "ai-assistants" && hasAssistants) || (step.key === "ai-agents" && hasAgents) ? "done" : "pending");
      var btn = el("button", { type: "button", class: "extuiAiSetupStep", "data-state": stateName });
      btn.appendChild(el("div", { class: "extuiAiSetupStepHead" }, [el("span", { class: "extuiAiSetupStepNumber", text: String(step.n) }), el("span", { class: "extuiAiSetupStepTitle", text: step.title })]));
      btn.appendChild(el("span", { class: "extuiAiSetupStepDesc", text: step.desc }));
      btn.appendChild(el("span", { class: "extuiAiSetupStepStatus", text: step.status }));
      if (step.key !== activeKey) btn.addEventListener("click", function () { window.__extDashboardShell.showSection(step.key); });
      path.appendChild(btn);
    });
    return path;
  }

  function renderPage() {
    rootEl.innerHTML = "";
                                                                        
                                                                        
                                                                           
                                                                        
                                                                
    var page = el("div", { class: "extuiaPage" });
    page.appendChild(aiHubNav("ai-memory"));
    page.appendChild(aiSetupPath("ai-memory", setupPathFlags.hasAssistants, setupPathFlags.hasAgents));
                                                                        
                                                                        
                                                                         
                                                                           
                                                                        
                                                                        
                                   
    page.appendChild(el("header", { class: "extappMemoryHeader", "data-extui-academy-target": "ai-memory-header" }, [el("div", {}, [el("span", { class: "extappMemoryEyebrow", text: "AUTOMAÇÃO" }), el("h1", { text: "Memória IA" }), el("p", { text: "Gerencie informações que os Agentes IA podem lembrar sobre seus clientes." })])]));
    var searchInput = el("input", { type: "search", placeholder: "Buscar cliente por nome ou telefone", autocomplete: "off", "aria-label": "Buscar cliente" });
    var results = el("div", { class: "extappMemorySearchResults", role: "listbox", "aria-label": "Resultados da busca" });
    var search = el("section", { class: "extappMemorySearch" }, [el("label", { class: "extappMemorySearchLabel" }, [el("span", { text: "Buscar cliente" }), searchInput]), results]); page.appendChild(search);
    var area = el("div", { id: "extappMemoryCustomerArea" }); page.appendChild(area);
    var clearAll = el("button", { type: "button", class: "extui-btn extui-btn--ghost extappMemoryDanger", text: "Limpar todas as memórias IA" });
    clearAll.addEventListener("click", async function () {
      if (!await window.extConfirm("Apagar TODAS as memórias IA de todos os clientes? Esta ação é permanente.", { danger: true, okLabel: "Apagar tudo" })) return;
      if (!await window.extConfirm("Confirme novamente: limpar toda a Memory Store agora?", { danger: true, okLabel: "Limpar Memory Store" })) return;
      try { await repository.clearAll(); entries = []; toast("Todas as memórias IA foram apagadas."); renderCustomerArea(); }
      catch (error) { toast(error.message, true); }
    });
    page.appendChild(el("section", { class: "extappMemoryAdvanced" }, [el("div", {}, [el("h2", { text: "Privacidade e controle" }), el("p", { text: "As memórias não fazem parte da cópia de segurança comum. Use esta ação somente para apagar todas as memórias de IA." })]), clearAll]));
    rootEl.appendChild(page); renderCustomerArea();
    var debounce;
    searchInput.addEventListener("input", function () {
      clearTimeout(debounce); var query = searchInput.value.trim().toLocaleLowerCase("pt-BR"); results.innerHTML = "";
      if (query.length < 2) return;
      results.appendChild(el("div", { class: "extappMemorySearchState", text: "Buscando contatos…" }));
      debounce = setTimeout(async function () {
        var contacts = await fetchWhatsAppContacts(); if (!currentRouteIsMemory()) return;
        var filtered = contacts.filter(function (contact) { return [contact.name || "", contact.phoneNumber || ""].join(" ").toLocaleLowerCase("pt-BR").indexOf(query) >= 0; }).slice(0, 20);
        results.innerHTML = "";
        if (!filtered.length) { results.appendChild(el("div", { class: "extappMemorySearchState", text: "Nenhum contato encontrado." })); return; }
        filtered.forEach(function (contact) {
          var phone = core.normalizePhone(contact.phoneNumber); var button = el("button", { type: "button", class: "extappMemoryContactResult", role: "option" }, [el("strong", { text: contact.name || "Contato" }), el("span", { text: phone || "Identidade indisponível" })]);
          button.addEventListener("click", function () { results.innerHTML = ""; searchInput.value = contact.name || phone || "Contato"; selectContact(contact); }); results.appendChild(button);
        });
      }, 250);
    });
  }
  function integrationState() {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ type: "EXTUI_INTEGRATION_GET_STATE" }, function (response) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message || "Não foi possível consultar as conexões de IA.")); return; }
        if (!response || response.ok !== true) { var error = new Error(response && response.userMessage || "Não foi possível consultar as conexões de IA."); error.code = response && response.errorCode || "AI_PROVIDER_STATE_UNAVAILABLE"; reject(error); return; }
        resolve(response.result && response.result.providers ? response.result : { providers: {} });
      });
    });
  }
  async function loadSetupPathFlags() {
    try {
      var integrationSnapshot = await integrationState();
      var values = await Promise.all([storageGet(assistantsCore.STORE_KEY), storageGet(agentsCore.STORE_KEY)]);
      var agents = agentsCore.normalizeStore(values[1]).agents;
      var hasConnection = integrationCore.PROVIDER_IDS.some(function (id) { var item = integrationSnapshot.providers && integrationSnapshot.providers[id]; return !!(item && item.configured && item.enabled && item.status === integrationCore.STATUSES.CONNECTED); });
      return { hasConnection: hasConnection, hasAssistants: assistantsCore.normalizeStore(values[0]).assistants.length > 0, hasAgents: agents.length > 0, agents: agents };
    } catch (error) {
      if (currentRouteIsMemory()) toast(error && error.message || "Não foi possível atualizar o estado das conexões de IA.", true);
      return { hasConnection: false, hasAssistants: false, hasAgents: false, agents: [] };
    }
  }
  async function renderSection(container) { rootEl = container; setupPathFlags = await loadSetupPathFlags(); renderPage(); }
  function refreshAiMemorySetupPath() {
    if (!currentRouteIsMemory()) return;
    loadSetupPathFlags().then(function (nextFlags) {
      setupPathFlags = nextFlags;
      if (rootEl && currentRouteIsMemory()) renderPage();
    }).catch(function (error) { });
  }
  function onExternalMemoryChange(handler) { return function (_next, _previous, _key, meta) { if (meta && meta.local === true) return; handler(); }; }
  if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
    window.ExtensionStorage.subscribe(core.STORE_KEY, onExternalMemoryChange(function () { if (currentRouteIsMemory() && selectedSubjectKey) reloadSelectedEntries(); }));
    window.ExtensionStorage.subscribe(agentsCore.STORE_KEY, onExternalMemoryChange(refreshAiMemorySetupPath));
    window.ExtensionStorage.subscribe(assistantsCore.STORE_KEY, onExternalMemoryChange(refreshAiMemorySetupPath));
  }
  document.addEventListener("ext:dashboard-section-change", function (event) {
    if (!event.detail || event.detail.section !== "ai-memory") { closeDialog(); contactsPromise = null; contactsPromiseAt = 0; }
  });
  window.addEventListener("pagehide", function () { closeDialog(); contactsPromise = null; contactsPromiseAt = 0; });
  window.__extDashboardShell.registerSection("ai-memory", renderSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
