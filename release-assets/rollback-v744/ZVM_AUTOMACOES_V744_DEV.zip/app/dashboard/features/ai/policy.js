;
try{
(function(){
  "use strict";
  var UPDATED_AT="2026-09-02";
  var GEMINI_FREE=["gemini-3.5-flash","gemini-3.5-flash-lite","gemini-3.1-flash-lite","gemini-3-flash-preview","gemini-2.5-flash","gemini-2.5-flash-lite"];
  function clean(v){return typeof v==="string"?v.trim():"";}
  function startsAny(id,list){return list.some(function(base){return id===base||id.indexOf(base+"-")===0;});}
  function specialized(providerId,id){
    id=clean(id).toLowerCase();
    if(!id)return true;
    if(providerId==="openai")return /(embedding|moderation|whisper|tts|dall-e|image|transcri|realtime|audio|speech|voice|codex|computer-use|deep-research|search-preview|search-api|search$)/.test(id);
    if(providerId==="gemini")return /(embedding|imagen|image|tts|live|aqa|veo)/.test(id);
    return false;
  }
  function access(providerId,id){
    id=clean(id).toLowerCase();
    if(providerId==="gemini")return startsAny(id,GEMINI_FREE)?"free":"paid";
    if(providerId==="openai"||providerId==="xai")return "paid";
    return "unknown";
  }
  function agentCompatible(providerId,id){
    id=clean(id).toLowerCase();
    if(specialized(providerId,id))return false;
    if(providerId==="gemini")return !/(pro-vision|image|tts|live|embedding)/.test(id);
    if(providerId==="openai")return /^(gpt-|o[1-9])/.test(id)&&!/(embedding|moderation|whisper|tts|dall-e|image|transcri|realtime|audio|speech|voice|codex|computer-use|deep-research|search-preview|search-api|search$)/.test(id);
    return providerId==="xai";
  }
  function info(providerId,model){
    var id=clean(model&&model.id||model),label=clean(model&&model.label)||id,a=access(providerId,id),special=specialized(providerId,id),agent=agentCompatible(providerId,id);
    return {id:id,label:label,access:a,specialized:special,agentCompatible:agent,recommended:!special&&((a==="free"&&agent)||(providerId!=="gemini"&&agent))};
  }
  function annotate(providerId,models){
    var seen=Object.create(null),out=[];
    (Array.isArray(models)?models:[]).forEach(function(model){var item=info(providerId,model);if(!item.id||seen[item.id]||item.specialized)return;seen[item.id]=true;out.push(item);});
    out.sort(function(a,b){var ar=(a.recommended?0:a.access==="free"?1:a.access==="paid"?3:2),br=(b.recommended?0:b.access==="free"?1:b.access==="paid"?3:2);return ar-br||a.label.localeCompare(b.label);});
    return out;
  }
  function primary(providerId,models,showAll){
    var all=annotate(providerId,models);
    if(showAll)return all;
    if(providerId==="openai"){
      var stable=all.filter(function(item){
        var id=String(item.id||"").toLowerCase();
        if(!item.agentCompatible)return false;
        if(/-\d{4}-\d{2}-\d{2}$/.test(id))return false;
        if(/(?:^|-)preview(?:-|$)/.test(id))return false;
        return true;
      });
      var modern=stable.filter(function(item){var id=String(item.id||"").toLowerCase();return /^gpt-5(?:\.|-|$)/.test(id)||/^o[3-9](?:-|$)/.test(id);});
      modern.sort(function(a,b){function rank(item){var id=String(item.id||"").toLowerCase(),m=id.match(/^gpt-(\d+)(?:\.(\d+))?/);if(m)return Number(m[1])*100+Number(m[2]||0);var o=id.match(/^o(\d+)/);return o?Number(o[1])*10:0;}return rank(b)-rank(a)||String(a.id||"").localeCompare(String(b.id||""));});
      if(modern.length)return modern.slice(0,8);
      var fallback=stable.filter(function(item){var id=String(item.id||"").toLowerCase();return /^gpt-4(?:\.|o|-|$)/.test(id)||/^o[1-9](?:-|$)/.test(id);});
      if(fallback.length)return fallback.slice(0,8);
      if(stable.length)return stable.slice(0,8);
    }
    if(providerId==="gemini"){
      var free=all.filter(function(item){return item.access==="free"&&item.agentCompatible;});
      if(free.length)return free;
    }
    return all.filter(function(item){return item.agentCompatible;});
  }
  function optionLabel(item){
    var tags=[];
    if(item.access==="free")tags.push("Gratuito");
    else if(item.access==="paid")tags.push("API paga");
    else tags.push("Plano depende da conta");
    if(item.agentCompatible)tags.push("Agentes");
    else tags.push("Texto apenas");
    return item.label+" — "+tags.join(" · ");
  }
  function billing(providerId){
    if(providerId==="gemini")return {kind:"free",title:"Possui nível gratuito",text:"A extensão prioriza modelos Gemini com nível sem custo financeiro conhecido. As cotas e a disponibilidade podem mudar por projeto."};
    if(providerId==="openai")return {kind:"paid",title:"API cobrada separadamente",text:"ChatGPT Free, Go, Plus ou Pro não inclui uso da API. A chave pode listar modelos mesmo sem saldo suficiente para gerar respostas."};
    if(providerId==="xai")return {kind:"paid",title:"API cobrada por uso",text:"O plano gratuito do Grok não equivale a créditos da API xAI. O uso da API depende de créditos pré-pagos ou faturamento habilitado."};
    return {kind:"unknown",title:"Disponibilidade pela conta",text:"Os modelos disponíveis dependem do provedor e da conta conectada."};
  }
  window.__extAiModelPolicy=Object.freeze({UPDATED_AT:UPDATED_AT,GEMINI_FREE:Object.freeze(GEMINI_FREE.slice()),info:info,annotate:annotate,primary:primary,optionLabel:optionLabel,billing:billing});
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
