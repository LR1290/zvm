;
try{
(function () {
  "use strict";
  var core = window.__extIntegrationCore;
  var extCore = window.__extExternalActionsCore;
  var assistantsCore = window.__extAiAssistantsCore;
  var agentsCore = window.__extAiAgentsCore;
  var modelPolicy = window.__extAiModelPolicy;
  var quickDefaults = window.__extAiQuickDefaults;
  var state = null;
  var transient = Object.create(null);
  var activeDrawer = null;
                                                                          
                                                                            
                                                                          
                                                                   
  var externalActionsState = { actions: [], originAccess: {} };
  var metaOnboardingRuntime = { timer: 0, token: 0 };
  function stopMetaOnboardingPoll() { if (metaOnboardingRuntime.timer) { clearTimeout(metaOnboardingRuntime.timer); metaOnboardingRuntime.timer = 0; } metaOnboardingRuntime.token++; }
  window.addEventListener("pagehide", stopMetaOnboardingPoll);

  function el(tag, attrs, children) {
    var node = document.createElement(tag); attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) { if (key === "class") node.className = attrs[key]; else if (key === "text") node.textContent = attrs[key]; else if (key.slice(0, 2) === "on") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]); else node.setAttribute(key, attrs[key]); });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); }); return node;
  }
  function icon(paths) { var span = el("span", { class: "extuiiIcon", "aria-hidden": "true" }); span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + paths + '</svg>'; return span; }
  function externalIcon() { var span = el("span", { class: "extuiiExternalIcon", "aria-hidden": "true" }); span.innerHTML = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M11 4h5v5M9 11l7-7M16 11v4a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h4"/></svg>'; return span; }
  var EXTERNAL_SERVICE_PRESETS = [
    { id: "n8n", label: "n8n", icon: "assets/integrations/n8n.svg", description: "Executa uma automação criada no n8n." },
    { id: "make", label: "Make", icon: "assets/integrations/make.svg", description: "Aciona um cenário criado no Make." },
    { id: "zapier", label: "Zapier", icon: "assets/integrations/zapier.svg", description: "Envia dados para uma automação do Zapier." },
    { id: "pipedream", label: "Pipedream", icon: "assets/integrations/pipedream.svg", description: "Aciona um fluxo criado no Pipedream." },
    { id: "googlesheets", label: "Google Sheets", icon: "assets/integrations/googlesheets.svg", description: "Consulta ou envia dados para uma planilha por meio de uma automação." },
    { id: "hubspot", label: "HubSpot", icon: "assets/integrations/hubspot.svg", description: "Consulta ou envia dados para uma automação conectada ao HubSpot." },
    { id: "slack", label: "Slack", icon: "assets/integrations/slack.svg", description: "Envia informações para uma automação conectada ao Slack." },
    { id: "airtable", label: "Airtable", icon: "assets/integrations/airtable.svg", description: "Consulta ou atualiza uma automação conectada ao Airtable." }
  ];
  function externalServiceMark(service) {
    var mark = el("span", { class: "extuiiServiceMark", "aria-hidden": "true" });
    var img = document.createElement("img");
    img.src = chrome.runtime.getURL(service.icon);
    img.alt = "";
    mark.appendChild(img);
    return mark;
  }
  function externalServiceShowcase() {
    var wrap = el("div", { class: "extuiiServiceShowcase", "aria-label": "Serviços que podem ser conectados" });
    var intro = el("div", { class: "extuiiServiceShowcase__intro" }, [
      el("strong", { text: "Conecte às ferramentas que sua equipe já usa" }),
      el("span", { text: "Estes atalhos iniciam uma nova ação. Você continua no controle do endereço e das permissões." })
    ]);
    var grid = el("div", { class: "extuiiServiceShowcase__grid" });
    EXTERNAL_SERVICE_PRESETS.forEach(function (service) {
      var button = el("button", { class: "extuiiServiceChip", type: "button", "aria-label": "Criar ação para " + service.label }, [externalServiceMark(service), el("span", { text: service.label })]);
      button.addEventListener("click", function () { openActionDrawer(null, service); });
      grid.appendChild(button);
    });
    wrap.appendChild(intro); wrap.appendChild(grid); return wrap;
  }

  var ICONS = {
    openai: '<path d="M12 3a4 4 0 0 1 3.8 2.7A4 4 0 0 1 19 12a4 4 0 0 1-3.2 6.3A4 4 0 0 1 8.2 18 4 4 0 0 1 5 11.7 4 4 0 0 1 8.2 5.7 4 4 0 0 1 12 3Z"/><path d="m8 9 4-2.3L16 9v4.5L12 16l-4-2.5Z"/>',
    gemini: '<path d="M12 2c.7 5.8 4.2 9.3 10 10-5.8.7-9.3 4.2-10 10-.7-5.8-4.2-9.3-10-10 5.8-.7 9.3-4.2 10-10Z"/>',
    xai: '<path d="m5 5 14 14M19 5 5 19"/><circle cx="12" cy="12" r="9"/>',
    webhooks: '<path d="M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2"/><path d="m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06"/><path d="m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v5M14 11v5"/>',
    meta: '<circle cx="12" cy="12" r="9"/><path d="M7 14c2-6 4-6 5-2s3 4 5-2"/>',
  };
  function message(type, payload) { return new Promise(function (resolve, reject) { chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (response) { if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; } if (!response || response.ok !== true) { var error = new Error(response && response.userMessage || "Não foi possível concluir a operação."); error.code = response && response.errorCode; reject(error); return; } resolve(response.result); }); }); }
  function statusLabel(providerId, metadata) {
    if (transient[providerId] === "checking") return "Verificando";
    if (metadata.status === core.STATUSES.CONNECTED) return "Conectado";
    if (metadata.status === core.STATUSES.ATTENTION) return "Requer atenção";
    return "Não configurado";
  }
  function relativeDate(value) { if (!value) return "Nunca verificada"; var diff = Date.now() - value; if (diff < 60000) return "Agora"; if (diff < 3600000) return "Há " + Math.round(diff / 60000) + " min"; if (diff < 86400000) return "Há " + Math.round(diff / 3600000) + " h"; return new Date(value).toLocaleDateString("pt-BR"); }
  function closeDrawer() { if (!activeDrawer) return; document.removeEventListener("keydown", activeDrawer.keyHandler, true); var previous = activeDrawer.previous; activeDrawer.layer.remove(); activeDrawer = null; if (previous && previous.isConnected) previous.focus(); }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  async function openProviderHelp(providerId, linkType) {
    try { await message("EXTUI_OPEN_PROVIDER_HELP", { provider: providerId, linkType: linkType }); }
    catch (error) { toast(error.message, true); }
  }
  function helpButton(providerId, linkType, label, primary) {
    var button = el("button", { class: "extui-btn " + (primary ? "extui-btn--secondary extuiiOfficialCta" : "extui-btn--ghost extuiiHelpLink"), type: "button" }, [el("span", { text: label }), externalIcon()]);
    button.addEventListener("click", function () { openProviderHelp(providerId, linkType); });
    return button;
  }

  function storageGet(key) { return window.__extDashboardShell.storageGet(key).then(function (result) { return result && result[key]; }); }
                                                                        
                                                                        
                                                                     
                                                                     
                                                                       
                                                                       
  function storageSet(key, value) { if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value); return new Promise(function (resolve, reject) { var payload = {}; payload[key] = value; chrome.storage.local.set(payload, function () { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(); }); }); }
  var aiQuickSettings = quickDefaults ? quickDefaults.normalize(null) : { providerId: "auto", transcriptionModel: "gpt-4o-mini-transcribe" };
  async function readQuickAiDefaults() { aiQuickSettings = quickDefaults ? quickDefaults.normalize(await storageGet(quickDefaults.STORE_KEY)) : aiQuickSettings; return aiQuickSettings; }
  async function writeQuickAiDefaults(next) { if (!quickDefaults) return next; aiQuickSettings = quickDefaults.normalize(next); aiQuickSettings.updatedAt = Date.now(); await storageSet(quickDefaults.STORE_KEY, JSON.stringify(aiQuickSettings)); return aiQuickSettings; }
  async function applyQuickAiDefault(providerId, providers) {
    if (!quickDefaults || (providerId !== "openai" && providerId !== "gemini")) return aiQuickSettings;
    var current = await readQuickAiDefaults(), active = quickDefaults.chooseDefaultProvider(providers || {}, current.providerId);
    if (current.providerId === "auto" || active === "auto") current.providerId = providerId;
    if (providerId === "openai") { var meta = providers && providers.openai; current.transcriptionModel = quickDefaults.openAiTranscriptionModel(meta && meta.availableModels, current.transcriptionModel); }
    return writeQuickAiDefaults(current);
  }
  function recommendedMainModel(providerId, models, currentModel) {
    var rows = Array.isArray(models) ? models : [];
    if (currentModel && rows.some(function (m) { return m && m.id === currentModel; })) return currentModel;
    if (providerId === "openai") { var ids = rows.map(function (m) { return m && m.id; }).filter(Boolean); for (var i = 0; i < ["gpt-5.6-luna","gpt-5.6-terra","gpt-5.6-sol","gpt-5.6"].length; i++) if (ids.indexOf(["gpt-5.6-luna","gpt-5.6-terra","gpt-5.6-sol","gpt-5.6"][i]) >= 0) return ["gpt-5.6-luna","gpt-5.6-terra","gpt-5.6-sol","gpt-5.6"][i]; }
    var primary = modelPolicy && typeof modelPolicy.primary === "function" ? modelPolicy.primary(providerId, rows, false) : rows;
    return primary && primary[0] && primary[0].id || rows[0] && rows[0].id || null;
  }
                                                                    
                                                                            
                                                               
                                                                        
                                                                 
                                                               
  var WEBHOOK_EVENT_DEFS = [
    { id: "messages", title: "Mensagem recebida", desc: "Toda mensagem recebida (não enviada por você)." },
    { id: "labels", title: "Etiqueta alterada", desc: "Etiqueta adicionada, removida ou renomeada num chat." },
    { id: "newChat", title: "Nova conversa", desc: "Primeira mensagem de um contato novo." },
    { id: "agendamento", title: "Agendamento enviado", desc: "Um item da Agenda foi efetivamente enviado." },
    { id: "fluxo", title: "Fluxo disparado", desc: "Qualquer Fluxo foi acionado." },
    { id: "metaAds", title: "Origem Meta Ads", desc: "Mensagem com contexto CTWA/Meta Ads." },
    { id: "respostaRapida", title: "Resposta rápida enviada", desc: "Uma resposta rápida foi efetivamente executada." },
    { id: "crm", title: "Movimentação no CRM", desc: "Contato movido entre etapas/colunas do CRM." },
    { id: "autoAtendimento", title: "Autoatendimento disparado", desc: "Uma regra de Autoatendimento foi executada com sucesso." },
    { id: "followup", title: "FollowUp executado", desc: "Uma regra de FollowUp foi enviada ou terminou com erro." },
    { id: "orders", title: "Encomenda alterada", desc: "Uma encomenda foi criada, atualizada ou teve rastreio enviado." },
    { id: "scheduleFailed", title: "Falha de agendamento", desc: "Um item da Agenda atingiu erro definitivo de envio." },
    { id: "funnelCompleted", title: "Funil finalizado", desc: "Uma execução de Funil chegou ao fim normalmente." }
  ];
  var lastValidWebhookList = null;
  function decodeWebhookList(raw) {
    if (raw == null || raw === "") return [];
    var parsed = raw;
    if (typeof raw === "string") {
      try { parsed = JSON.parse(raw); }
      catch (_) { var malformed = new Error("A configuração dos avisos automáticos está corrompida."); malformed.code = "WEBHOOK_STORE_CORRUPT"; throw malformed; }
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || !parsed.state || typeof parsed.state !== "object" || Array.isArray(parsed.state) || !Array.isArray(parsed.state.webhookList)) { var invalidStore = new Error("A configuração dos avisos automáticos está corrompida."); invalidStore.code = "WEBHOOK_STORE_CORRUPT"; throw invalidStore; }
    if (parsed.state.webhookList.some(function (row) { return !row || typeof row !== "object" || Array.isArray(row); })) { var invalidRows = new Error("A configuração dos avisos automáticos contém registros inválidos."); invalidRows.code = "WEBHOOK_STORE_CORRUPT"; throw invalidRows; }
    return parsed.state.webhookList;
  }
  async function loadWebhookList() {
    var list = decodeWebhookList(await storageGet(core.WEBHOOKS_KEY));
    lastValidWebhookList = list.map(function (row) { return Object.assign({}, row); });
    var migrated = false;
    for (var i = 0; i < list.length; i++) {
      var cfg = list[i] && typeof list[i] === "object" ? list[i] : null;
      if (!cfg) continue;
      if (cfg.authHeaderValue) {
        await message("EXTUI_WEBHOOK_SECRET_SET", { eventId: String(cfg.id || ""), headerName: String(cfg.authHeaderName || "Authorization"), secretValue: String(cfg.authHeaderValue) });
        delete cfg.authHeaderValue; migrated = true;
      }
      if (cfg.headers) { delete cfg.headers; migrated = true; }
    }
    if (migrated) await saveWebhookList(list);
    return list;
  }
  function sanitizeWebhookCfg(cfg) {
    cfg = cfg && typeof cfg === "object" ? cfg : {};
    return {
      id: String(cfg.id || "").slice(0, 80), active: cfg.active === true, url: String(cfg.url || "").slice(0, 2000),
      authHeaderName: String(cfg.authHeaderName || "").slice(0, 64), param: Array.isArray(cfg.param) ? cfg.param.slice(0, 64) : [],
      retry: cfg.retry !== false, maxAttempts: Math.max(1, Math.min(5, Number(cfg.maxAttempts || cfg.retryAttempts) || 3)),
      retryDelayMs: Math.max(250, Math.min(30000, Number(cfg.retryDelayMs) || 1000)), sent: Array.isArray(cfg.sent) ? cfg.sent.slice(0, 50) : []
    };
  }
  async function saveWebhookList(list) {
    if (!Array.isArray(list)) { var invalidList = new Error("A lista de avisos automáticos é inválida."); invalidList.code = "WEBHOOK_STORE_CORRUPT"; throw invalidList; }
    var current = await storageGet(core.WEBHOOKS_KEY);
    if (current != null && current !== "") decodeWebhookList(current);
    var safeList = list.map(sanitizeWebhookCfg);
    await storageSet(core.WEBHOOKS_KEY, JSON.stringify({ state: { webhookList: safeList }, version: 0 }));
    lastValidWebhookList = safeList.map(function (row) { return Object.assign({}, row); });
  }
  function findOrCreateWebhookCfg(list, eventId) {
    var cfg = list.find(function (entry) { return entry.id === eventId; });
    if (!cfg) { cfg = { id: eventId, active: false, url: "", authHeaderName: "", param: [], retry: true, maxAttempts: 3, retryDelayMs: 1000, sent: [] }; list.push(cfg); }
    return cfg;
  }
                                                                           
                                                                             
                                                                        
  function requestOrigin(origin) {
    return new Promise(function (resolve) {
      var pattern; try { pattern = window.__extRuntimeConfig.permissionPattern(origin); } catch (_) { resolve(false); return; }
      chrome.permissions.request({ origins: [pattern] }, function (granted) {
        if (chrome.runtime && chrome.runtime.lastError) { var err=new Error(chrome.runtime.lastError.message||"Falha ao solicitar permissão"); if(window.__extReportRuntimeError)window.__extReportRuntimeError("INTEGRATION_PERMISSION_REQUEST_FAILED",err); resolve(false); return; }
        resolve(granted === true);
      });
    });
  }
  function containsOrigin(origin) {
    return new Promise(function (resolve) {
      var pattern; try { pattern = window.__extRuntimeConfig.permissionPattern(origin); } catch (_) { resolve(false); return; }
      chrome.permissions.contains({ origins: [pattern] }, function (granted) {
        if (chrome.runtime && chrome.runtime.lastError) { var err=new Error(chrome.runtime.lastError.message||"Falha ao verificar permissão"); if(window.__extReportRuntimeError)window.__extReportRuntimeError("INTEGRATION_PERMISSION_CHECK_FAILED",err); resolve(false); return; }
        resolve(granted === true);
      });
    });
  }
  async function countAssistantReferences(actionId) {
    if (!assistantsCore || !extCore) return 0;
    var raw = await storageGet(assistantsCore.STORE_KEY);
    return extCore.countAssistantReferences(assistantsCore.normalizeStore(raw).assistants, actionId);
  }
  async function refreshExternalActionPermissions() {
    var entries = await Promise.all(externalActionsState.actions.map(function (action) {
      return message("EXTUI_EXTERNAL_ACTION_CHECK_PERMISSION", { actionId: action.id }).catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("EXTERNAL_ACTION_PERMISSION_REFRESH_FAILED",err); return { actionId: action.id, granted: false, unavailable: true }; });
    }));
    var map = {}; entries.forEach(function (entry) { map[entry.actionId] = entry; });
    externalActionsState.originAccess = map;
  }
  async function refresh(container) {
    var results = await Promise.all([message("EXTUI_INTEGRATION_GET_STATE"), extCore ? message("EXTUI_EXTERNAL_ACTION_LIST") : Promise.resolve([])]);
    state = results[0];
    externalActionsState.actions = Array.isArray(results[1]) ? results[1] : [];
    await refreshExternalActionPermissions();
    render(container);
  }
  function providerCard(provider, metadata, drawerOptions) {
    var label = statusLabel(provider.id, metadata);
    var card = el("article", { class: "extuiiProvider", "data-status": transient[provider.id] || metadata.status });
    var head = el("div", { class: "extuiiProvider__head" }, [icon(ICONS[provider.id]), el("span", { class: "extuiiStatus", text: label })]);
    card.appendChild(head); card.appendChild(el("h2", { text: provider.label })); card.appendChild(el("p", { text: provider.description }));
    var details = el("dl", { class: "extuiiProvider__details" });
    if (provider.kind === "existing") {
      details.appendChild(el("div", {}, [el("dt", { text: "Ativos" }), el("dd", { text: String(metadata.activeCount || 0) })]));
                                                                           
                                                                        
                                                                     
                                                                         
                                             
      var open = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Gerenciar webhooks" }); open.addEventListener("click", function () { openWebhooksDrawer(); }); card.appendChild(details); card.appendChild(open); return card;
    }
    details.appendChild(el("div", {}, [el("dt", { text: provider.id === "openai" ? "Modelo para Perfis/Agentes" : "Modelo principal" }), el("dd", { text: metadata.model || "Não selecionado" })]));
    if (modelPolicy) { var billing = modelPolicy.billing(provider.id); details.appendChild(el("div", {}, [el("dt", { text: "Plano da API" }), el("dd", { text: billing.title })])); }
    details.appendChild(el("div", {}, [el("dt", { text: "Última verificação" }), el("dd", { text: relativeDate(metadata.lastTestedAt) })])); card.appendChild(details);
    var manage = el("button", { class: "extui-btn " + (metadata.configured ? "extui-btn--secondary" : "extui-btn--primary"), type: "button", text: metadata.configured ? "Gerenciar" : "Configurar" }); manage.addEventListener("click", function () { openProviderDrawer(provider.id, drawerOptions || null); });
    card.appendChild(manage);
    return card;
  }
  function connectedAiCount() {
    return core.PROVIDER_IDS.filter(function (id) { var item = state && state.providers && state.providers[id]; return !!(item && item.configured && item.enabled && item.status === core.STATUSES.CONNECTED); }).length;
  }
  function attentionAiCount() {
    return core.PROVIDER_IDS.filter(function (id) { var item = state && state.providers && state.providers[id]; return !!(item && item.status === core.STATUSES.ATTENTION); }).length;
  }
  function aiSetupPath(activeKey, hasConnection, hasAssistants, hasAgents) {
    var path = el("div", { class: "extuiAiSetupPath", role: "group", "aria-label": "Ordem recomendada de configuração" });
    var steps = [
      { n: 1, key: "ai-connect", title: "Conexão IA", desc: "Conecte um serviço", status: hasConnection ? "Concluído" : "Comece aqui" },
      { n: 2, key: "ai-assistants", title: "Perfis IA", desc: "Defina o comportamento", status: hasAssistants ? "Concluído" : (hasConnection ? "Próximo passo" : "Pendente") },
      { n: 3, key: "ai-agents", title: "Agentes IA", desc: "Use um perfil", status: hasAgents ? "Configurado" : "Pendente" },
      { n: 4, key: "ai-memory", title: "Memória IA", desc: "Enriqueça o contexto", status: "Opcional" },
      { n: 5, key: "knowledge", title: "Conhecimento", desc: "Ensine fatos específicos", status: "Opcional" }
    ];
    steps.forEach(function (step) {
      var stateName = step.key === activeKey ? "current" : ((step.key === "ai-connect" && hasConnection) || (step.key === "ai-assistants" && hasAssistants) || (step.key === "ai-agents" && hasAgents) ? "done" : "pending");
      var btn = el("button", { type: "button", class: "extuiAiSetupStep", "data-state": stateName });
      btn.appendChild(el("div", { class: "extuiAiSetupStepHead" }, [el("span", { class: "extuiAiSetupStepNumber", text: String(step.n) }), el("span", { class: "extuiAiSetupStepTitle", text: step.title })]));
      btn.appendChild(el("span", { class: "extuiAiSetupStepDesc", text: step.desc }));
      btn.appendChild(el("span", { class: "extuiAiSetupStepStatus", text: step.status }));
      if (step.key !== activeKey) btn.addEventListener("click", function () { window.__extDashboardShell.showSection(step.key); });
      path.appendChild(btn);
    });
    return path;
  }
  async function renderAiConnections(container, progress) {
    container.innerHTML = "";
    progress = progress || { hasAssistants: false, hasAgents: false };
    var connected = connectedAiCount(), attention = attentionAiCount();
    var page = el("div", { class: "extuiiPage extuiiPageV2 extuiiAiHubPage" });
    page.appendChild(aiSetupPath("ai-connect", connected > 0, progress.hasAssistants, progress.hasAgents));
    page.appendChild(el("header", { class: "extuiiHeader extuiiAiConnectHeader", "data-extui-academy-target": "ai-connect-header" }, [el("span", { class: "extuiiEyebrow", text: "ASSISTENTES IA · PASSO 1" }), el("h1", { text: "Conexões de IA" }), el("p", { text: "Conecte um serviço e siga para Perfis e Agentes." })]));
    page.appendChild(el("section", { class: "extuiiSummary", "aria-label": "Resumo das conexões de IA" }, [
      el("div", {}, [el("strong", { text: String(connected) }), el("span", { text: "Conectadas" })]),
      el("div", {}, [el("strong", { text: String(core.PROVIDER_IDS.length) }), el("span", { text: "Disponíveis" })]),
      el("div", {}, [el("strong", { text: String(attention) }), el("span", { text: "Requerem atenção" })])
    ]));
    var group = el("section", { class: "extuiFinalModuleGroup extuiiProviderGroup extuiiAiProviderGroup" });
    group.appendChild(el("div", { class: "extuiFinalModuleGroupHead" }, [el("div", {}, [el("strong", { text: "Escolha seu serviço de IA" })]) ]));
    var grid = el("div", { class: "extuiiGrid extuiiAiProviderGrid", "aria-label": "Serviços de IA disponíveis" });
    core.PROVIDERS.filter(function (provider) { return provider.kind === "ai"; }).forEach(function (provider) {
      var card = providerCard(provider, state.providers[provider.id], { onChange: async function () { await refreshAiConnections(container); } });
      card.dataset.provider = provider.id; card.dataset.kind = "ai"; grid.appendChild(card);
    });
    group.appendChild(grid); page.appendChild(group);
    var next = el("section", { class: "extuiiAiNextStep", "data-state": connected > 0 ? "ready" : "pending" });
    next.appendChild(el("div", {}, [el("span", { class: "extuiiEyebrow", text: connected > 0 ? "PASSO 1 CONCLUÍDO" : "PASSO 1" }), el("h2", { text: connected > 0 ? "Agora crie seu Perfil IA" : "Conecte pelo menos um serviço para continuar" }), el("p", { text: connected > 0 ? "O Perfil define instruções, modelo, contexto e ferramentas reutilizáveis. Depois dele você cria o Agente IA." : "Escolha OpenAI, Gemini ou Grok acima. A extensão só libera o próximo passo quando uma conexão for validada." })]));
    var nextButton = el("button", { class: "extui-btn extui-btn--primary", type: "button", text: connected > 0 ? "Continuar para Perfis IA" : "Escolher um serviço acima" });
    if (connected > 0) nextButton.addEventListener("click", function () { window.__extDashboardShell.showSection("ai-assistants"); }); else nextButton.disabled = true;
    next.appendChild(nextButton); page.appendChild(next); container.appendChild(page);
  }
  function webhooksSection() {
    var metadata = state && state.providers && state.providers.webhooks || {};
    var section = el("section", { class: "extuiiActionsSection", "aria-label": "Webhooks" });
    var head = el("div", { class: "extuiiActionsSection__head" }, [el("div", {}, [el("h2", { text: "Webhooks" }), el("p", { text: "Envie eventos da extensão para sistemas externos. " + String(metadata.activeCount || 0) + " webhook" + ((metadata.activeCount || 0) === 1 ? " ativo." : "s ativos.") })])]);
    var btn = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Gerenciar webhooks" }); btn.addEventListener("click", openWebhooksDrawer); head.appendChild(btn); section.appendChild(head); return section;
  }
  function render(container) {
    container.innerHTML = ""; var page = el("div", { class: "extuiiPage extuiiPageV2" });
    page.appendChild(el("header", { class: "extuiiHeader" }, [el("span", { class: "extuiiEyebrow", text: "ECOSSISTEMA" }), el("h1", { text: "Integrações" }), el("p", { text: "Conecte automações externas, webhooks, rastreamento e APIs operacionais. Serviços de IA agora ficam em Assistentes IA." })]));
    page.appendChild(el("section", { class: "extuiiSummary", "aria-label": "Resumo das integrações externas" }, [
      el("div", {}, [el("strong", { text: String(externalActionsState.actions.length) }), el("span", { text: "Ações externas" })]),
      el("div", {}, [el("strong", { text: String(state && state.providers && state.providers.webhooks && state.providers.webhooks.activeCount || 0) }), el("span", { text: "Webhooks ativos" })]),
      el("div", {}, [el("strong", { text: String(EXTERNAL_SERVICE_PRESETS.length) }), el("span", { text: "Atalhos de serviços" })])
    ]));
    if (extCore) { var automationGroup=el("section",{class:"extuiFinalModuleGroup extuiiAutomationGroup"}); automationGroup.appendChild(externalActionsSection()); page.appendChild(automationGroup); }
    var deliveryGroup=el("section",{class:"extuiFinalModuleGroup extuiiDeliveryGroup"});
    deliveryGroup.appendChild(el("div",{class:"extuiFinalModuleGroupHead"},[el("div",{},[el("strong",{text:"Eventos e APIs"}),el("span",{text:"Conectores operacionais para rastreamento, webhooks e serviços externos."})]) ]));
    var endpoints=el("div",{class:"extuiiEndpointGrid"}); endpoints.appendChild(webhooksSection()); endpoints.appendChild(trackingSection()); deliveryGroup.appendChild(endpoints); page.appendChild(deliveryGroup);
    container.appendChild(page);
  }
  async function refreshAiConnections(container) {
    var values = await Promise.all([message("EXTUI_INTEGRATION_GET_STATE"), storageGet(assistantsCore.STORE_KEY), storageGet(agentsCore.STORE_KEY)]);
    state = values[0];
    var progress = { hasAssistants: assistantsCore.normalizeStore(values[1]).assistants.length > 0, hasAgents: agentsCore.normalizeStore(values[2]).agents.length > 0 };
    await renderAiConnections(container, progress);
  }
  function trackingSection(){var section=el("section",{class:"extuiiActionsSection","aria-label":"Meta Pixel e envio de eventos"});var head=el("div",{class:"extuiiActionsSection__head"},[el("div",{},[el("h2",{text:"Meta Pixel e envio de eventos"}),el("p",{text:"Envie eventos de negócio para a Meta. A chave de acesso fica protegida e não entra na cópia de segurança."})])]);var btn=el("button",{class:"extui-btn extui-btn--secondary",type:"button",text:"Configurar"});btn.addEventListener("click",function(){openTrackingDrawer().catch(function(error){if(window.__extReportRuntimeError)window.__extReportRuntimeError("TRACKING_DRAWER_LOAD_FAILED",error);toast(error&&error.message||"Não foi possível carregar a configuração da Meta.",true);});});head.appendChild(btn);section.appendChild(head);return section;}
  async function openTrackingDrawer(){closeDrawer();var raw=await storageGet("EXTUI:trackingStore"),cfg={};if(raw!=null){try{cfg=typeof raw==="string"?JSON.parse(raw):raw;}catch(_){var corrupt=new Error("A configuração da Meta está corrompida.");corrupt.code="TRACKING_CONFIG_CORRUPT";throw corrupt;}if(!cfg||typeof cfg!=="object"||Array.isArray(cfg)){var invalid=new Error("A configuração da Meta está corrompida.");invalid.code="TRACKING_CONFIG_CORRUPT";throw invalid;}}var secret=await message("EXTUI_TRACKING_SECRET_STATUS");var previous=document.activeElement,layer=el("div",{class:"extuiiDrawerLayer"}),backdrop=el("button",{class:"extuiiDrawerBackdrop",type:"button","aria-label":"Fechar configuração"}),drawer=el("aside",{class:"extuiiDrawer",role:"dialog","aria-modal":"true",tabindex:"-1"});layer.appendChild(backdrop);layer.appendChild(drawer);document.body.appendChild(layer);var close=el("button",{class:"extuiiClose",type:"button","aria-label":"Fechar",text:"×"});drawer.appendChild(el("header",{class:"extuiiDrawer__header"},[icon(ICONS.meta),el("div",{},[el("span",{class:"extuiiEyebrow",text:"RASTREAMENTO"}),el("h2",{text:"Meta Pixel e envio de eventos"})]),close]));var body=el("div",{class:"extuiiDrawer__body"});drawer.appendChild(body);function field(label,input){body.appendChild(el("label",{text:label}));body.appendChild(input);}var enabled=el("input",{type:"checkbox"});enabled.checked=cfg.enabled===true;var enabledRow=el("label",{class:"extuiiMicrocopy"},[enabled,el("span",{text:" Ativar envio de eventos para a Meta"})]);body.appendChild(enabledRow);var pixel=el("input",{type:"text",inputmode:"numeric",placeholder:"Código do Pixel",value:String(cfg.pixelId||"")});field("Código do Pixel",pixel);var version=el("input",{type:"text",placeholder:"v23.0",value:String(cfg.apiVersion||"v23.0")});field("Versão do serviço da Meta",version);var testCode=el("input",{type:"text",placeholder:"Opcional",value:String(cfg.testEventCode||"")});field("Código de teste",testCode);var token=el("input",{type:"password",autocomplete:"new-password",placeholder:secret.configured?"Chave já salva — deixe vazio para manter":"Chave de acesso fornecida pela Meta"});field("Chave de acesso",token);body.appendChild(el("p",{class:"extuiiMicrocopy",text:secret.configured?"Chave salva: "+(secret.keyHint||"••••")+". Ela não é incluída em backups.":"A chave fica protegida neste navegador e não entra nas cópias de segurança."}));var actions=el("div",{class:"extuiiDrawer__actions"}),save=el("button",{class:"extui-btn extui-btn--primary",type:"button",text:"Salvar"}),remove=el("button",{class:"extui-btn extui-btn--ghost",type:"button",text:"Remover chave"});actions.appendChild(save);if(secret.configured)actions.appendChild(remove);body.appendChild(actions);save.addEventListener("click",async function(){try{var publicCfg={enabled:enabled.checked,pixelId:pixel.value,apiVersion:version.value,testEventCode:testCode.value,actionSource:"other"};await storageSet("EXTUI:trackingStore",JSON.stringify(publicCfg));if(token.value.trim())await message("EXTUI_TRACKING_SECRET_SET",{token:token.value.trim()});toast("Integração Meta salva.");closeDrawer();}catch(e){toast(e.message,true);}});remove.addEventListener("click",async function(){try{await message("EXTUI_TRACKING_SECRET_REMOVE");toast("Chave removida.");closeDrawer();}catch(e){toast(e.message,true);}});function done(){closeDrawer();}close.addEventListener("click",done);backdrop.addEventListener("click",done);var keyHandler=function(ev){if(ev.key==="Escape"){ev.preventDefault();done();return;}if(ev.key!=="Tab")return;var focusable=drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])');if(!focusable.length){ev.preventDefault();drawer.focus();return;}var first=focusable[0],last=focusable[focusable.length-1];if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}};document.addEventListener("keydown",keyHandler,true);activeDrawer={layer:layer,previous:previous,keyHandler:keyHandler};drawer.focus();}
  function endpointOrigin(rawUrl) { return extCore ? extCore.actionOrigin({ endpoint: rawUrl }) : null; }
  function endpointHostLabel(rawUrl) { var origin = endpointOrigin(rawUrl); if (origin) { try { return new URL(origin).hostname; } catch (error) { return origin; } } return rawUrl || "—"; }
  function actionStatus(action) {
    if (!action.enabled) return "disabled";
    if (action.auth && action.auth.mode !== "none" && !action.hasSecret) return "credential";
    var originAccess = externalActionsState.originAccess[action.id];
    if (!originAccess || originAccess.granted !== true) return "permission";
    return "ready";
  }
  var ACTION_STATUS_LABELS = { disabled: "Desativada", credential: "Requer credencial", permission: "Requer permissão", ready: "Pronta" };
  var ACTION_STATUS_VARIANTS = { disabled: "", credential: "extuiBadge--warning", permission: "extuiBadge--warning", ready: "extuiBadge--success" };
  function actionStatusBadge(action) { var status = actionStatus(action); return el("span", { class: "extuiBadge " + ACTION_STATUS_VARIANTS[status], text: ACTION_STATUS_LABELS[status] }); }
  function actionRow(action) {
    var article = el("article", { class: "extuiiActionRow", "data-status": actionStatus(action) });
    var title = el("div", { class: "extuiiActionRow__title" }, [el("h3", { text: action.name }), el("span", { class: "extuiBadge " + (action.method === "POST" ? "extuiBadge--warning" : "extuiBadge--info"), text: action.method })]);
    var identity = el("div", { class: "extuiiActionRow__identity" }, [title, el("p", { text: action.description || "Sem descrição." }), el("small", { text: endpointHostLabel(action.endpoint) })]);
    var actionsWrap = el("div", { class: "extuiiActionRow__actions" });
    var edit = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Editar" }); edit.addEventListener("click", function () { openActionDrawer(action.id); });
    var del = el("button", { class: "extui-btn extui-btn--ghost extuiiDangerAction", type: "button", "aria-label": "Excluir " + action.name }, [icon(ICONS.trash)]); del.addEventListener("click", function () { removeAction(action); });
    actionsWrap.appendChild(edit); actionsWrap.appendChild(del);
    article.appendChild(identity); article.appendChild(actionStatusBadge(action)); article.appendChild(actionsWrap);
    return article;
  }
  async function removeAction(action) {
    var count = await countAssistantReferences(action.id);
    var detail = count ? "Esta ação é utilizada por " + count + " Assistente" + (count === 1 ? "" : "s") + ". Ao excluí-la, essas referências ficarão com configuração incompleta." : "Nenhum Assistente referencia esta ação no momento.";
    if (!await window.extConfirm("Excluir “" + action.name + "”?\n\n" + detail, { danger: true, okLabel: "Excluir ação" })) return;
    try { await message("EXTUI_EXTERNAL_ACTION_DELETE", { actionId: action.id }); toast("Ação externa excluída."); await refresh(document.getElementById("extappContentArea")); }
    catch (error) { toast(error.message, true); }
  }
  function externalActionsSection() {
    var section = el("section", { class: "extuiiActionsSection", "aria-label": "Ações Externas" });
    var head = el("div", { class: "extuiiActionsSection__head" }, [el("div", {}, [el("h2", { text: "Ações Externas" }), el("p", { text: "Ligue a extensão a automações e serviços externos que sua equipe já usa." })])]);
    var create = el("button", { class: "extui-btn extui-btn--primary", type: "button" }, [icon(ICONS.plus), el("span", { text: "Nova ação externa" })]); create.addEventListener("click", function () { openActionDrawer(null, null); }); head.appendChild(create); section.appendChild(head);
    section.appendChild(externalServiceShowcase());
    if (!externalActionsState.actions.length) { section.appendChild(el("div", { class: "extuiiActionsEmpty" }, [el("p", { text: "Nenhuma ação externa configurada. Escolha um serviço acima ou crie uma ação para começar." })])); return section; }
    var list = el("div", { class: "extuiiActionList" }); externalActionsState.actions.forEach(function (action) { list.appendChild(actionRow(action)); }); section.appendChild(list); return section;
  }
  async function afterProviderMutation(drawerOptions) {
    if (drawerOptions && typeof drawerOptions.onChange === "function") { await drawerOptions.onChange(); return; }
    var content = document.getElementById("extappContentArea");
    var current = window.__extDashboardShell && window.__extDashboardShell.getCurrentSection ? window.__extDashboardShell.getCurrentSection() : "";
    if (current === "ai-connect" || current === "ai-transcription" || current === "ai-translation") await refreshAiConnections(content);
    else if (current === "integracoes") await refresh(content);
  }
  function openProviderDrawer(providerId, drawerOptions) {
    closeDrawer(); var provider = core.providerById(providerId); if (!provider || provider.kind !== "ai" || !provider.onboarding) return; var metadata = state.providers[providerId]; var previous = document.activeElement; var configuredAtOpen = metadata.configured === true;
    var layer = el("div", { class: "extuiiDrawerLayer" }); var backdrop = el("button", { class: "extuiiDrawerBackdrop", type: "button", "aria-label": "Fechar configuração" }); var drawer = el("aside", { class: "extuiiDrawer", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuiiDrawerTitle", tabindex: "-1" }); layer.appendChild(backdrop); layer.appendChild(drawer); document.body.appendChild(layer);
    var close = el("button", { class: "extuiiClose", type: "button", "aria-label": "Fechar", text: "×" }); drawer.appendChild(el("header", { class: "extuiiDrawer__header" }, [icon(ICONS[providerId]), el("div", {}, [el("span", { class: "extuiiEyebrow", text: configuredAtOpen ? "INTEGRAÇÃO CONECTADA" : "CONFIGURAÇÃO GUIADA" }), el("h2", { id: "extuiiDrawerTitle", text: configuredAtOpen ? "Gerenciar " + provider.label : provider.onboarding.title })]), close]));
    var body = el("div", { class: "extuiiDrawer__body" }); drawer.appendChild(body);
    function configSection(number, title, copy, compact) {
      var content = el("div", { class: "extuiiConfigSection__content" }, [el("h3", { text: title })]);
      if (copy) content.appendChild(el("p", { text: copy }));
      var children = compact ? [content] : [el("span", { class: "extuiiStep", text: String(number), "aria-hidden": "true" }), content];
      return el("section", { class: "extuiiConfigSection" + (compact ? " is-compact" : "") }, children);
    }
    if (!configuredAtOpen) {
      var official = configSection(1, "Crie sua chave de acesso", "Abra o site oficial do serviço e crie uma chave de acesso para a extensão.", false);
      official.children[1].appendChild(helpButton(providerId, "createKey", provider.onboarding.createKeyLabel, true));
      body.appendChild(official);
    }
    var credential = configSection(configuredAtOpen ? null : 2, configuredAtOpen ? "Credencial" : "Cole sua chave", configuredAtOpen ? "O Extensão não exibe novamente a credencial completa já salva." : "Cole somente a chave de acesso criada no site oficial. Nunca informe a senha da sua conta.", configuredAtOpen);
    var credentialBody = credential.lastChild;
    var keyEditor = el("div", { class: "extuiiKeyEditor" });
    var keyRow = el("div", { class: "extuiiKeyRow" }); var keyInput = el("input", { type: "password", autocomplete: "new-password", spellcheck: "false", placeholder: "Cole sua chave de acesso", "aria-label": "Chave de acesso de " + provider.label }); var reveal = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Mostrar" }); reveal.addEventListener("click", function () { var show = keyInput.type === "password"; keyInput.type = show ? "text" : "password"; reveal.textContent = show ? "Ocultar" : "Mostrar"; }); keyRow.appendChild(keyInput); keyRow.appendChild(reveal); keyEditor.appendChild(keyRow);
    keyEditor.appendChild(el("p", { class: "extuiiMicrocopy", text: "A chave fica protegida neste navegador, não entra nas cópias de segurança e não será exibida novamente." }));
    if(providerId==="openai" || providerId==="gemini"){
    }
    if (configuredAtOpen) {
      var saved = el("div", { class: "extuiiKeySaved" }, [el("div", {}, [el("span", { text: metadata.keyHint }), el("strong", { text: "Credencial salva" })])]);
      var replace = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Substituir chave" });
      replace.addEventListener("click", function () { keyEditor.hidden = false; replace.hidden = true; keyInput.focus(); updateTestState(); });
      saved.appendChild(replace); credentialBody.appendChild(saved); keyEditor.hidden = true;
    }
    credentialBody.appendChild(keyEditor); body.appendChild(credential);
    var connection = configSection(configuredAtOpen ? null : 3, configuredAtOpen ? "Validar conexão" : "Teste a conexão", configuredAtOpen ? "Confirme o acesso e atualize a lista de modelos disponíveis." : "A extensão usará essa chave apenas para confirmar se a conexão funciona.", configuredAtOpen);
    var connectionBody = connection.lastChild; var connectionMessage = el("p", { class: "extuiiConnectionMessage", "aria-live": "polite", text: configuredAtOpen ? "Última verificação: " + relativeDate(metadata.lastTestedAt) : "Cole uma chave para habilitar o teste." }); var testButton = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: configuredAtOpen ? "Revalidar" : "Testar conexão" }); connectionBody.appendChild(connectionMessage); connectionBody.appendChild(testButton); body.appendChild(connection);
    var modelSectionTitle = providerId === "openai" ? "Modelo para Perfis e Agentes" : "Modelo principal";
    var modelSectionHelp = configuredAtOpen ? "Escolha o modelo para Perfis e Agentes." : "Valide a conexão para listar os modelos.";
    var models = configSection(configuredAtOpen ? null : 4, modelSectionTitle, modelSectionHelp, configuredAtOpen); var modelsBody = models.lastChild; models.hidden = !configuredAtOpen; var select = el("select", { "aria-label": modelSectionTitle }); if (metadata.model) select.appendChild(el("option", { value: metadata.model, text: metadata.model })); else select.appendChild(el("option", { value: "", text: "Teste a conexão para listar modelos" })); select.value = metadata.model || ""; select.disabled = !configuredAtOpen; modelsBody.appendChild(select);
    var modelHint = el("p", { class: "extuiiMicrocopy extuiiModelAccessHint", role: "status" }); modelsBody.appendChild(modelHint);
    var showAllModels = false; var allModelItems = Array.isArray(metadata.availableModels) ? metadata.availableModels.slice() : [];
    var showAllInput = el("input", { type: "checkbox", "aria-label": "Mostrar versões históricas e alternativas" }); showAllInput.checked = showAllModels;
    var showAllRow = el("label", { class: "extuiiModelAdvancedToggle" }, [showAllInput, el("span", { text: "Mostrar versões históricas e alternativas" })]); showAllRow.hidden = true; modelsBody.appendChild(showAllRow); body.appendChild(models);
    if (configuredAtOpen) {
      var helpLinks = el("nav", { class: "extuiiHelpLinks", "aria-label": "Ajuda do serviço" }, [helpButton(providerId, "manageAccount", "Gerenciar conta", false), helpButton(providerId, "documentation", "Documentação", false)]);
      body.appendChild(helpLinks);
    }
    function renderModelOptions() {
      var annotated = modelPolicy ? modelPolicy.annotate(providerId, allModelItems) : allModelItems.map(function (model) { return { id: model.id, label: model.label || model.id, access: "unknown", agentCompatible: true }; });
      var visible = modelPolicy ? modelPolicy.primary(providerId, allModelItems, showAllModels) : annotated;
      select.innerHTML = ""; visible.forEach(function (item) { select.appendChild(el("option", { value: item.id, text: modelPolicy ? modelPolicy.optionLabel(item) : item.label })); });
      var selectedItem = metadata.model && annotated.find(function (item) { return item.id === metadata.model; });
      var selectedInfo = metadata.model && modelPolicy ? modelPolicy.info(providerId, { id: metadata.model, label: metadata.model }) : selectedItem;
      var selectedSpecialized = !!(selectedInfo && selectedInfo.specialized), selectedVisible = !!(metadata.model && visible.some(function (item) { return item.id === metadata.model; }));
      if (metadata.model && !selectedVisible && (selectedSpecialized || showAllModels)) select.appendChild(el("option", { value: metadata.model, text: (selectedItem && modelPolicy ? modelPolicy.optionLabel(selectedItem) : metadata.model) + (selectedSpecialized ? " — incompatível como modelo principal" : " (selecionado anteriormente)") }));
      select.value = selectedVisible || selectedSpecialized || showAllModels ? (metadata.model || (visible[0] && visible[0].id) || "") : ((visible[0] && visible[0].id) || ""); select.disabled = !select.options.length; if (typeof save !== "undefined" && save) save.disabled = !select.value || !!(modelPolicy && modelPolicy.info(providerId,{id:select.value,label:select.value}).specialized);
      var hiddenCount = Math.max(0, annotated.length - visible.length); showAllRow.hidden = !(modelPolicy && (providerId === "openai" || providerId === "gemini" || providerId === "xai") && hiddenCount > 0);
      if (selectedSpecialized) modelHint.textContent = "Esse modelo é especializado. Escolha um modelo de texto para Perfis e Agentes.";
      else if (metadata.model && !selectedVisible && !showAllModels) modelHint.textContent = "O modelo salvo está fora da lista recomendada.";
      else if (!annotated.length) modelHint.textContent = "Nenhum modelo de texto compatível foi encontrado.";
      else modelHint.textContent = "";
      modelHint.hidden = !modelHint.textContent;
    }
    function fillModels(items) { allModelItems = Array.isArray(items) ? items.slice() : []; renderModelOptions(); }
    showAllInput.addEventListener("change", function () { showAllModels = showAllInput.checked; renderModelOptions(); });
    select.addEventListener("change", function () { var currentInfo = modelPolicy && select.value ? modelPolicy.info(providerId, { id: select.value, label: select.value }) : null; if (typeof save !== "undefined" && save) save.disabled = !select.value || !!(currentInfo && currentInfo.specialized); });
    function updateTestState() { testButton.disabled = !metadata.configured && !keyInput.value.trim(); connectionMessage.textContent = testButton.disabled ? "Cole uma chave para habilitar o teste." : (metadata.configured ? "Pronto para revalidar a credencial." : "Pronto para validar a credencial."); }
    keyInput.addEventListener("input", updateTestState);
    testButton.addEventListener("click", async function () {
      testButton.disabled = true; testButton.textContent = "Testando conexão…"; connectionMessage.textContent = "Testando conexão…"; transient[providerId] = "checking";
      try {
        if (keyInput.value.trim()) { await message("EXTUI_INTEGRATION_CONFIGURE", { provider: providerId, apiKey: keyInput.value }); keyInput.value = ""; keyInput.type = "password"; reveal.textContent = "Mostrar"; }
        else if (!metadata.configured) throw new Error("Informe a chave de acesso para continuar.");
        var result = await message("EXTUI_INTEGRATION_TEST", { provider: providerId }); fillModels(result.models || []);
        if (!configuredAtOpen) {
          var automaticModel = recommendedMainModel(providerId, result.models || [], metadata.model);
          if (automaticModel) { select.value = automaticModel; await message("EXTUI_INTEGRATION_SET_MODEL", { provider: providerId, model: automaticModel }); }
          state = await message("EXTUI_INTEGRATION_GET_STATE"); metadata = state.providers[providerId] || metadata;
          if (providerId === "openai" || providerId === "gemini") await applyQuickAiDefault(providerId, state.providers || {});
          connectionMessage.textContent = "✓ Conexão pronta · padrão automático aplicado";
        } else connectionMessage.textContent = "✓ Conexão validada";
        connectionMessage.classList.add("is-success"); toast("Conexão com " + provider.label + " validada.");
        if (save) save.disabled = !select.value; remove.disabled = false;
      } catch (error) { connectionMessage.textContent = error.message; connectionMessage.classList.remove("is-success"); toast(error.message, true); }
      finally {
        delete transient[providerId];
        try { state = await message("EXTUI_INTEGRATION_GET_STATE"); metadata = state.providers[providerId] || metadata; }
        catch (refreshError) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("INTEGRATION_STATE_REFRESH_FAILED",refreshError); }
        testButton.disabled = !metadata.configured && !keyInput.value.trim();
        testButton.textContent = metadata.configured ? "Revalidar" : "Testar novamente";
      }
    });
    var footer = el("footer", { class: "extuiiDrawer__footer" }); var remove = el("button", { class: "extui-btn extui-btn--danger", type: "button", text: "Remover conexão" }); remove.disabled = !metadata.configured; remove.addEventListener("click", async function () { if (!await window.extConfirm("Remover a conexão com " + provider.label + " e apagar a credencial local?", { danger: true })) return; await message("EXTUI_INTEGRATION_REMOVE", { provider: providerId }); toast("Conexão removida."); closeDrawer(); await afterProviderMutation(drawerOptions); }); var save = el("button", { class: "extui-btn extui-btn--primary", type: "button", text: configuredAtOpen ? "Salvar alterações" : "Concluir configuração" }); save.disabled = !configuredAtOpen || !select.value; save.addEventListener("click", async function () { if (!select.value) { toast("Teste a conexão para continuar.", true); return; } try { await message("EXTUI_INTEGRATION_SET_MODEL", { provider: providerId, model: select.value }); state = await message("EXTUI_INTEGRATION_GET_STATE"); if (providerId === "openai" || providerId === "gemini") await applyQuickAiDefault(providerId, state.providers || {}); closeDrawer(); await afterProviderMutation(drawerOptions); } catch (error) { toast(error.message, true); } }); if (configuredAtOpen) footer.appendChild(remove); else footer.appendChild(el("span", { class: "extuiiFooterHint", text: "A configuração só termina após um teste válido." })); footer.appendChild(save); drawer.appendChild(footer); if (configuredAtOpen) fillModels(allModelItems); updateTestState();
    function dismiss() { closeDrawer(); } backdrop.addEventListener("click", dismiss); close.addEventListener("click", dismiss); var keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); dismiss(); return; } if (event.key !== "Tab") return; var focusable = drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])'); if (!focusable.length) return; var first = focusable[0], last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); } }; document.addEventListener("keydown", keyHandler, true); activeDrawer = { layer: layer, previous: previous, keyHandler: keyHandler }; drawer.focus();
  }
                                                                         
                                                                           
                                                                        
                                                                          
                                                                          
  function openWebhooksDrawer() {
    closeDrawer();
    var previous = document.activeElement;
    var layer = el("div", { class: "extuiiDrawerLayer" }); var backdrop = el("button", { class: "extuiiDrawerBackdrop", type: "button", "aria-label": "Fechar webhooks" }); var drawer = el("aside", { class: "extuiiDrawer", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuiiWebhooksDrawerTitle", tabindex: "-1" }); layer.appendChild(backdrop); layer.appendChild(drawer); document.body.appendChild(layer);
    var close = el("button", { class: "extuiiClose", type: "button", "aria-label": "Fechar", text: "×" }); drawer.appendChild(el("header", { class: "extuiiDrawer__header" }, [icon(ICONS.webhooks), el("div", {}, [el("span", { class: "extuiiEyebrow", text: "INTEGRAÇÃO EXISTENTE" }), el("h2", { id: "extuiiWebhooksDrawerTitle", text: "Webhooks" })]), close]));
    var body = el("div", { class: "extuiiDrawer__body" }); drawer.appendChild(body);
    body.appendChild(el("p", { class: "extuiiMicrocopy", text: "Envia dados automaticamente para um endereço seu sempre que o evento escolhido acontecer. Se o serviço exigir uma chave de acesso, configure-a abaixo." }));
    var listArea = el("div", { class: "extuiiWebhooksList" }); body.appendChild(listArea);
    function field(label, control, helper) { var wrap = el("label", { class: "extuiaField" }, [el("span", { text: label }), control]); if (helper) wrap.appendChild(el("small", { text: helper })); return wrap; }
    var list = [];
    async function renderRows() {
      listArea.innerHTML = "";
      try { list = await loadWebhookList(); } catch (error) { listArea.appendChild(el("p", { class: "extuiiMicrocopy", text: "Erro ao carregar." })); return; }
      WEBHOOK_EVENT_DEFS.forEach(function (def) {
        var cfg = findOrCreateWebhookCfg(list, def.id);
        var card = el("section", { class: "extuiiConfigSection is-compact" });
        var content = el("div", { class: "extuiiConfigSection__content" });
        var head = el("div", { class: "extuiiWebhookHead" }, [el("div", {}, [el("h3", { text: def.title }), el("p", { text: def.desc })])]);
        var active = el("input", { type: "checkbox" }); active.checked = !!cfg.active;
        var activeToggle = el("label", { class: "extuiaToggle" }, [active, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", { text: "Ativo" })]);
        active.addEventListener("change", async function () {
          if (active.disabled) return;
          var previous = !!cfg.active;
          var next = !!active.checked;
          active.disabled = true;
          active.setAttribute("aria-busy", "true");
          cfg.active = next;
          try {
            await saveWebhookList(list);
            toast(next ? "Evento ativado." : "Evento desativado.");
          } catch (error) {
            cfg.active = previous;
            active.checked = previous;
            toast(error && error.message ? error.message : "Não foi possível salvar o estado do evento.", true);
          } finally {
            active.disabled = false;
            active.removeAttribute("aria-busy");
          }
        });
        head.appendChild(activeToggle);
        content.appendChild(head);
        var urlInput = el("input", { type: "url", placeholder: "https://sua-url-de-integração...", "aria-label": "Endereço de destino para " + def.title }); urlInput.value = cfg.url || "";
        content.appendChild(field("Endereço de destino", urlInput, "Use um endereço seguro da internet que comece com https://. Endereços internos não são aceitos."));
        var authName = el("input", { type: "text", placeholder: "Ex: Authorization", "aria-label": "Cabeçalho de autenticação" }); authName.value = cfg.authHeaderName || "";
        var authValue = el("input", { type: "password", autocomplete: "new-password", placeholder: "Credencial opcional", "aria-label": "Valor do cabeçalho de autenticação" }); var authState={configured:false,headerName:null}; message("EXTUI_WEBHOOK_SECRET_STATUS",{eventId:def.id}).then(function(st){authState=st||authState;if(authState.configured)authValue.placeholder="Credencial salva "+(authState.keyHint||"••••")+" — deixe vazio para manter";}).catch(function(){});
        content.appendChild(field("Cabeçalho de autenticação (opcional)", authName, "Exemplo: Authorization"));
        content.appendChild(field("Chave de acesso", authValue, "Use os dados de acesso fornecidos pelo serviço. Se houver dúvida, consulte a ajuda do próprio serviço."));
        var fieldsInput = el("input", { type: "text", placeholder: "Ex: eventDetails.body,eventDetails.type", "aria-label": "Dados enviados" });
        fieldsInput.value = Array.isArray(cfg.param) ? cfg.param.map(function (item) { return typeof item === "string" ? item : (item && (item.key || item.id || item.name)) || ""; }).filter(Boolean).join(",") : "";
        content.appendChild(field("Dados enviados (opcional)", fieldsInput, "Separe os campos por vírgulas. Se deixar vazio, a extensão envia todos os dados necessários para identificar o evento e a conversa."));
        var attemptsInput = el("input", { type: "number", min: "1", max: "5", step: "1", "aria-label": "Tentativas de envio" }); attemptsInput.value = String(cfg.maxAttempts || cfg.retryAttempts || 3);
        content.appendChild(field("Tentativas", attemptsInput, "1 a 5 tentativas. Falhas de rede, 408, 429 e 5xx usam backoff exponencial."));
        var lastSent = (cfg.sent && cfg.sent[0]) || null;
        content.appendChild(el("p", { class: "extuiiMicrocopy", role: "status", text: lastSent ? ((lastSent.status ? "✓" : "✗") + " último envio: " + new Date(lastSent.atMs).toLocaleString("pt-BR") + (cfg.sent.length > 1 ? " · " + cfg.sent.length + " no histórico" : "")) : "Nenhum envio ainda." }));
        var saveBtn = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Salvar" });
        saveBtn.addEventListener("click", async function () {
          try {
            var parsedUrl = extCore.validateActionUrl(urlInput.value.trim()), origin = parsedUrl.origin;
            var headerName = authName.value.trim(), secretValue = authValue.value.trim();
            if (secretValue && !extCore.validateHeaderName(headerName)) throw new Error("Informe um nome de cabeçalho de autenticação válido.");
            if (authState.configured && headerName && authState.headerName && headerName !== authState.headerName && !secretValue) throw new Error("Ao alterar o cabeçalho, informe novamente a credencial.");
            if (!await requestOrigin(origin)) throw new Error("A permissão para acessar esse endereço foi recusada.");
            cfg.url = parsedUrl.toString(); cfg.authHeaderName = headerName;
            cfg.param = fieldsInput.value.split(",").map(function (v) { return v.trim(); }).filter(Boolean);
            cfg.retry = true; cfg.maxAttempts = Math.max(1, Math.min(5, parseInt(attemptsInput.value, 10) || 3));
            if (secretValue) await message("EXTUI_WEBHOOK_SECRET_SET", {eventId:def.id, headerName:headerName, secretValue:secretValue});
            else if (!headerName && authState.configured) await message("EXTUI_WEBHOOK_SECRET_REMOVE", {eventId:def.id});
            await saveWebhookList(list); toast("Aviso automático salvo com a chave protegida.");
          } catch (error) { toast(error.message, true); }
        });
        content.appendChild(saveBtn);
        card.appendChild(content); listArea.appendChild(card);
      });
    }
    renderRows();
    function dismiss() { closeDrawer(); } backdrop.addEventListener("click", dismiss); close.addEventListener("click", dismiss);
    var keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); dismiss(); return; } if (event.key !== "Tab") return; var focusable = drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),[tabindex]:not([tabindex="-1"])'); if (!focusable.length) return; var first = focusable[0], last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); } };
    document.addEventListener("keydown", keyHandler, true); activeDrawer = { layer: layer, previous: previous, keyHandler: keyHandler }; drawer.focus();
  }
  function openActionDrawer(actionId, preset) {
    closeDrawer();
    var current = actionId ? externalActionsState.actions.find(function (entry) { return entry.id === actionId; }) : null;
    if (actionId && !current) { toast("Ação externa não encontrada.", true); return; }
    var previous = document.activeElement;
    var layer = el("div", { class: "extuiiDrawerLayer" }); var backdrop = el("button", { class: "extuiiDrawerBackdrop", type: "button", "aria-label": "Fechar editor" }); var drawer = el("aside", { class: "extuiiDrawer", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuiiActionDrawerTitle", tabindex: "-1" }); layer.appendChild(backdrop); layer.appendChild(drawer); document.body.appendChild(layer);
    var close = el("button", { class: "extuiiClose", type: "button", "aria-label": "Fechar", text: "×" }); drawer.appendChild(el("header", { class: "extuiiDrawer__header" }, [icon(ICONS.webhooks), el("div", {}, [el("span", { class: "extuiiEyebrow", text: current ? "EDITAR AÇÃO EXTERNA" : "NOVA AÇÃO EXTERNA" }), el("h2", { id: "extuiiActionDrawerTitle", text: current ? current.name : (preset && preset.label ? "Conectar " + preset.label : "Nova ação externa") })]), close]));
    var body = el("form", { id: "extuiiActionForm", class: "extuiiDrawer__body" }); drawer.appendChild(body);
    function field(label, control, helper) { var wrap = el("label", { class: "extuiaField" }, [el("span", { text: label }), control]); if (helper) wrap.appendChild(el("small", { text: helper })); return wrap; }

    preset = !current && preset && typeof preset === "object" ? preset : null;
    var name = el("input", { type: "text", required: true, maxlength: "80", autocomplete: "off" }); name.value = current && current.name || preset && preset.label || "";
    var description = el("textarea", { rows: "3", maxlength: "600", required: true, placeholder: "Ex.: Consulta o estoque de um produto pelo código informado." }); description.value = current && current.description || preset && preset.description || "";
    var endpoint = el("input", { type: "url", required: true, maxlength: "2000", autocomplete: "off", placeholder: "https://exemplo.com/estoque" }); endpoint.value = current && current.endpoint || "";
    var endpointStatus = el("p", { class: "extuiaContextNote", role: "status" });
    var method = el("select", { "aria-label": "Método" }, extCore.METHODS.map(function (item) { return el("option", { value: item, text: item === "GET" ? "Consultar dados" : "Enviar dados" }); })); method.value = current && current.method || "GET";
    body.appendChild(field("Nome", name, "Curto e claro — aparece na lista de Ações Externas e nas permissões do Assistente."));
    body.appendChild(field("Descrição para a IA", description, "Explica à IA quando e por que usar esta ação. É enviada ao provedor de IA junto das demais ferramentas autorizadas."));
    body.appendChild(field("Endereço de destino", endpoint));
    body.appendChild(endpointStatus);
    body.appendChild(field("Método", method, "Escolha se a extensão deve apenas consultar o endereço ou enviar dados para ele."));

                                                                           
                                                                          
                                                                       
    var authMode = el("select", { "aria-label": "Autenticação" }, [el("option", { value: "none", text: "Nenhuma" }), el("option", { value: "bearer", text: "Chave de acesso" }), el("option", { value: "apiKeyHeader", text: "Chave em campo personalizado" })]); authMode.value = current && current.auth && current.auth.mode || "none";
    var headerName = el("input", { type: "text", maxlength: "64", autocomplete: "off", placeholder: "Ex.: nome fornecido pelo serviço" }); headerName.value = current && current.auth && current.auth.headerName || "";
    var headerNameField = field("Nome do campo de acesso", headerName);
    var secretInput = el("input", { type: "password", autocomplete: "new-password", spellcheck: "false", placeholder: "Cole a credencial" });
    var secretReveal = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Mostrar" }); secretReveal.addEventListener("click", function () { var show = secretInput.type === "password"; secretInput.type = show ? "text" : "password"; secretReveal.textContent = show ? "Ocultar" : "Mostrar"; });
    var secretRow = el("div", { class: "extuiiKeyRow" }, [secretInput, secretReveal]);
    var secretEditor = el("div", {}, [secretRow, el("p", { class: "extuiaContextNote", text: "A chave fica protegida neste navegador, não é enviada à IA e não entra nas cópias de segurança." })]);
    var secretWrap = secretEditor;
    if (current && current.hasSecret) {
      var savedRow = el("div", { class: "extuiiKeySaved" }, [el("div", {}, [el("span", { text: "••••••••" }), el("strong", { text: "Credencial salva" })])]);
      var replaceSecret = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Substituir credencial" });
      secretEditor.hidden = true;
      replaceSecret.addEventListener("click", function () { secretEditor.hidden = false; replaceSecret.hidden = true; secretInput.focus(); });
      savedRow.appendChild(replaceSecret);
      secretWrap = el("div", {}, [savedRow, secretEditor]);
    }
    var authSection = el("fieldset", { class: "extuiaContextSection" }, [el("legend", { text: "Autenticação" }), field("Tipo", authMode), headerNameField, secretWrap]);
    function updateAuthState() { var mode = authMode.value; headerNameField.hidden = mode !== "apiKeyHeader"; secretWrap.hidden = mode === "none"; }
    authMode.addEventListener("change", updateAuthState); updateAuthState();

                                                                        
                                                                         
                                                         
    var fieldRows = [];
    var fieldsList = el("div", { class: "extuiiFieldsEditor" });
    function addFieldRow(data) {
      data = data || { name: "", type: "text", description: "", required: false };
      var rowName = el("input", { type: "text", maxlength: "64", placeholder: "nome_do_campo" }); rowName.value = data.name;
      var rowType = el("select", {}, [el("option", { value: "text", text: "Texto" }), el("option", { value: "number", text: "Número" }), el("option", { value: "boolean", text: "Verdadeiro/Falso" })]); rowType.value = data.type;
      var rowDescription = el("input", { type: "text", maxlength: "300", placeholder: "Descrição para a IA" }); rowDescription.value = data.description;
      var rowRequired = el("input", { type: "checkbox" }); rowRequired.checked = data.required === true;
      var rowRemove = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuiiFieldRow__remove", "aria-label": "Remover campo", text: "×" });
      var row = el("div", { class: "extuiiFieldRow" }, [rowName, rowType, rowDescription, el("label", { class: "extuiiFieldRow__required" }, [rowRequired, el("span", { text: "Obrigatório" })]), rowRemove]);
      var entry = { row: row, nameInput: rowName, typeInput: rowType, descriptionInput: rowDescription, requiredInput: rowRequired };
      rowRemove.addEventListener("click", function () { fieldRows = fieldRows.filter(function (item) { return item !== entry; }); row.remove(); });
      fieldRows.push(entry); fieldsList.appendChild(row);
    }
    (current && current.fields || []).forEach(function (fieldData) { addFieldRow(fieldData); });
    var addField = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuiiAddRow", text: "+ Adicionar campo" }); addField.addEventListener("click", function () { addFieldRow(); });
    var fieldsSection = el("fieldset", { class: "extuiaContextSection" }, [el("legend", { text: "Campos de entrada" }), el("p", { class: "extuiaContextNote", text: "Os únicos valores que a IA pode enviar nesta ação — qualquer outra chave é recusada." }), fieldsList, addField]);

                                                                  
                                                                          
                                                             
    var responseMode = el("select", { "aria-label": "Resposta" }, [el("option", { value: "statusOnly", text: "Somente status (recomendado)" }), el("option", { value: "selectedFields", text: "Partes específicas da resposta" })]); responseMode.value = current && current.responsePolicy && current.responsePolicy.mode || "statusOnly";
    var pathRows = [];
    var pathsList = el("div", { class: "extuiiFieldsEditor" });
    function addPathRow(value) {
      var pathInput = el("input", { type: "text", maxlength: "200", placeholder: "ex.: data.estoque" }); pathInput.value = value || "";
      var pathRemove = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuiiFieldRow__remove", "aria-label": "Remover parte da resposta", text: "×" });
      var row = el("div", { class: "extuiiFieldRow extuiiPathRow" }, [pathInput, pathRemove]);
      var entry = { row: row, input: pathInput };
      pathRemove.addEventListener("click", function () { pathRows = pathRows.filter(function (item) { return item !== entry; }); row.remove(); });
      pathRows.push(entry); pathsList.appendChild(row);
    }
    (current && current.responsePolicy && current.responsePolicy.paths || []).forEach(function (path) { addPathRow(path); });
    var addPath = el("button", { type: "button", class: "extui-btn extui-btn--ghost extuiiAddRow", text: "+ Adicionar parte da resposta" }); addPath.addEventListener("click", function () { addPathRow(); });
    var pathsWrap = el("div", {}, [el("p", { class: "extuiaContextNote", text: "Caminhos separados por ponto (ex.: data.estoque). No máximo " + extCore.MAX_RESPONSE_PATHS + "." }), pathsList, addPath]);
    var responseSection = el("fieldset", { class: "extuiaContextSection" }, [el("legend", { text: "O que a IA pode ver na resposta" }), field("Modo", responseMode), pathsWrap]);
    function updateResponseState() { pathsWrap.hidden = responseMode.value !== "selectedFields"; }
    responseMode.addEventListener("change", updateResponseState); updateResponseState();

                                                                         
                                                                  
    var permissionStatus = el("p", { class: "extuiaContextNote", role: "status" });
    var permissionButton = el("button", { type: "button", class: "extui-btn extui-btn--secondary", text: "Permitir acesso" });
    var permissionSection = el("fieldset", { class: "extuiaContextSection" }, [el("legend", { text: "Permissão de rede" }), permissionStatus, permissionButton]);
    var permissionStateSeq = 0;
    async function updatePermissionState() {
      var seq = ++permissionStateSeq, origin = endpointOrigin(endpoint.value);
      if (!origin) { permissionStatus.textContent = "Informe um endereço seguro que comece com https:// para permitir o acesso."; permissionStatus.className = "extuiaContextNote"; permissionButton.hidden = true; return; }
      var granted = await containsOrigin(origin);
      if (seq !== permissionStateSeq || origin !== endpointOrigin(endpoint.value)) return;
      permissionButton.hidden = granted;
      permissionStatus.textContent = granted ? "✓ A extensão tem permissão para acessar " + origin + "." : "A extensão precisa de permissão para acessar " + origin + ".";
      permissionStatus.className = "extuiaContextNote" + (granted ? "" : " is-attention");
    }
    permissionButton.addEventListener("click", async function () {
      var origin = endpointOrigin(endpoint.value); if (!origin) return;
      permissionButton.disabled = true;
      try { await requestOrigin(origin); } finally { permissionButton.disabled = false; await updatePermissionState(); }
    });
    endpoint.addEventListener("input", function () {
      var origin = endpointOrigin(endpoint.value);
      endpointStatus.textContent = endpoint.value ? (origin ? "" : "Endereço inválido: use https:// e evite endereços internos.") : "";
      endpointStatus.className = "extuiaContextNote" + (endpoint.value && !origin ? " is-attention" : "");
      updatePermissionState();
    });
    updatePermissionState();

    var enabled = el("input", { type: "checkbox" }); enabled.checked = current ? current.enabled : true;
    var enabledField = el("label", { class: "extuiaToggle" }, [enabled, el("span", { class: "extuiaToggleControl", "aria-hidden": "true" }), el("span", {}, [el("strong", { text: "Ativa" }), el("small", { text: "Ações desativadas não podem ser executadas, mesmo se autorizadas em um Assistente." })])]);
    body.appendChild(authSection); body.appendChild(fieldsSection); body.appendChild(responseSection); body.appendChild(permissionSection); body.appendChild(enabledField);

                                                                            
                                                                        
    if (current) {
      var testStatus = el("p", { class: "extuiaContextNote", role: "status" });
      var testButton = el("button", { class: "extui-btn extui-btn--secondary", type: "button", text: "Testar ação" });
      var testValuesWrap = el("div", { class: "extuiiFieldsEditor" });
      var testInputs = (current.fields || []).map(function (fieldDef) {
        var input;
        if (fieldDef.type === "boolean") input = el("select", {}, [el("option", { value: "true", text: "Verdadeiro" }), el("option", { value: "false", text: "Falso" })]);
        else if (fieldDef.type === "number") input = el("input", { type: "number" });
        else if (fieldDef.enumValues) input = el("select", {}, fieldDef.enumValues.map(function (value) { return el("option", { value: value, text: value }); }));
        else input = el("input", { type: "text" });
        testValuesWrap.appendChild(el("label", { class: "extuiaField" }, [el("span", { text: fieldDef.name + (fieldDef.required ? " *" : "") }), input]));
        return { field: fieldDef, input: input };
      });
      var testSection = el("fieldset", { class: "extuiaContextSection" }, [el("legend", { text: "Testar ação" }), el("p", { class: "extuiaContextNote", text: "Envia uma chamada real usando os valores abaixo — os valores nunca são gerados pela IA neste teste." }), testValuesWrap, testStatus, testButton]);
      body.appendChild(testSection);
      testButton.addEventListener("click", async function () {
        var args = {}; var invalid = false;
        testInputs.forEach(function (entry) {
          var raw = entry.input.value;
          if (entry.field.type === "number") { if (!raw) { if (entry.field.required) invalid = true; return; } var num = Number(raw); if (!Number.isFinite(num)) { invalid = true; return; } args[entry.field.name] = num; }
          else if (entry.field.type === "boolean") { args[entry.field.name] = raw === "true"; }
          else { if (!raw) { if (entry.field.required) invalid = true; return; } args[entry.field.name] = raw; }
        });
        if (invalid) { testStatus.textContent = "Preencha os valores de teste corretamente."; testStatus.className = "extuiaContextNote is-attention"; return; }
        if (current.method === "POST" && !await window.extConfirm("Este teste enviará dados de verdade para " + endpointHostLabel(current.endpoint) + ". Deseja continuar?", { okLabel: "Enviar teste" })) return;
        testButton.disabled = true; testStatus.textContent = "Testando…"; testStatus.className = "extuiaContextNote";
        try { var result = await message("EXTUI_EXTERNAL_ACTION_TEST", { actionId: current.id, testArguments: args }); testStatus.textContent = "✓ Resposta: " + JSON.stringify(result); testStatus.className = "extuiaContextNote"; }
        catch (error) { testStatus.textContent = error.message; testStatus.className = "extuiaContextNote is-attention"; }
        finally { testButton.disabled = false; }
      });
    }

    var footer = el("footer", { class: "extuiiDrawer__footer" }); var cancel = el("button", { class: "extui-btn extui-btn--ghost", type: "button", text: "Cancelar" }); var save = el("button", { class: "extui-btn extui-btn--primary", type: "submit", form: "extuiiActionForm", text: current ? "Salvar alterações" : "Criar ação externa" }); footer.appendChild(cancel); footer.appendChild(save); drawer.appendChild(footer);
    body.addEventListener("submit", async function (event) {
      event.preventDefault(); save.disabled = true;
      try {
        var fields = fieldRows.map(function (entry) { return { name: entry.nameInput.value.trim(), type: entry.typeInput.value, description: entry.descriptionInput.value.trim(), required: entry.requiredInput.checked }; }).filter(function (item) { return item.name; });
        var paths = pathRows.map(function (entry) { return entry.input.value.trim(); }).filter(Boolean);
        var draft = {
          name: name.value.trim(), description: description.value.trim(), endpoint: endpoint.value.trim(), method: method.value,
          auth: authMode.value === "apiKeyHeader" ? { mode: "apiKeyHeader", headerName: headerName.value.trim() } : { mode: authMode.value },
          fields: fields,
          responsePolicy: responseMode.value === "selectedFields" ? { mode: "selectedFields", paths: paths } : { mode: "statusOnly" },
          enabled: enabled.checked
        };
        var saved = actionId ? await message("EXTUI_EXTERNAL_ACTION_UPDATE", { actionId: actionId, draft: draft }) : await message("EXTUI_EXTERNAL_ACTION_CREATE", { draft: draft });
        if (authMode.value === "none") { if (current && current.hasSecret) await message("EXTUI_EXTERNAL_ACTION_REMOVE_SECRET", { actionId: saved.id }); }
        else if (secretInput.value.trim()) await message("EXTUI_EXTERNAL_ACTION_SET_SECRET", { actionId: saved.id, secretValue: secretInput.value });
        toast(actionId ? "Ação externa atualizada." : "Ação externa criada.");
        closeDrawer(); await refresh(document.getElementById("extappContentArea"));
      } catch (error) { toast(error.message, true); save.disabled = false; }
    });
    function dismiss() { closeDrawer(); } backdrop.addEventListener("click", dismiss); close.addEventListener("click", dismiss); cancel.addEventListener("click", dismiss);
    var keyHandler = function (event) { if (event.key === "Escape") { event.preventDefault(); dismiss(); return; } if (event.key !== "Tab") return; var focusable = drawer.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'); if (!focusable.length) return; var first = focusable[0], last = focusable[focusable.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); } }; document.addEventListener("keydown", keyHandler, true); activeDrawer = { layer: layer, previous: previous, keyHandler: keyHandler }; drawer.focus(); name.focus();
  }
  var META_OFFICIAL_CFG_KEY="EXTUI:metaOfficialConfig",META_OFFICIAL_TOKEN_KEY="EXTUI:metaOfficialAccessToken";
  function metaSessionGet(key){return new Promise(function(resolve,reject){if(!chrome.storage||!chrome.storage.session){resolve(null);return;}chrome.storage.session.get([key],function(result){if(chrome.runtime&&chrome.runtime.lastError){var e=new Error(chrome.runtime.lastError.message||"Falha ao ler dados temporários.");void chrome.runtime.lastError;reject(e);return;}resolve(result&&result[key]||null);});});}
  function metaSessionSet(key,value){return new Promise(function(resolve,reject){if(!chrome.storage||!chrome.storage.session){reject(new Error("Armazenamento seguro da sessão indisponível."));return;}var payload={};payload[key]=value;chrome.storage.session.set(payload,function(){if(chrome.runtime.lastError)reject(new Error(chrome.runtime.lastError.message));else resolve();});});}
  function metaSessionRemove(key){return new Promise(function(resolve,reject){if(!chrome.storage||!chrome.storage.session){resolve();return;}chrome.storage.session.remove([key],function(){if(chrome.runtime&&chrome.runtime.lastError){var e=new Error(chrome.runtime.lastError.message||"Falha ao limpar dados temporários.");void chrome.runtime.lastError;reject(e);return;}resolve();});});}
  function metaCfgParse(raw){if(raw==null)return{};var parsed=raw;if(typeof raw==="string"){try{parsed=JSON.parse(raw);}catch(_){var err=new Error("A configuração da Meta Oficial está corrompida.");err.code="META_CONFIG_CORRUPT";throw err;}}if(!parsed||typeof parsed!=="object"||Array.isArray(parsed)){var invalid=new Error("A configuração da Meta Oficial está corrompida.");invalid.code="META_CONFIG_CORRUPT";throw invalid;}return parsed;}
  function metaGraphVersion(cfg){var value=String(cfg.apiVersion||"v23.0").trim();return /^v\d+\.\d+$/.test(value)?value:"v23.0";}
  function metaConnectionMode(cfg){return String(cfg&&cfg.connectionMode||"")==="embedded"?"embedded":"manual";}
  function metaConnected(cfg,token){return metaConnectionMode(cfg)==="embedded"?!!(cfg&&cfg.phoneNumberId&&cfg.wabaId):!!(token&&cfg&&cfg.phoneNumberId&&cfg.wabaId);}
  async function metaReadTextLimited(response,maxBytes){maxBytes=Math.max(1,Number(maxBytes)||1);var declared=Number(response&&response.headers&&response.headers.get?response.headers.get("content-length")||0:0);if(declared&&declared>maxBytes)throw new Error("A Meta retornou uma resposta maior que o limite seguro.");var reader=response&&response.body&&typeof response.body.getReader==="function"?response.body.getReader():null;if(!reader){var fallback=await response.text(),size=typeof TextEncoder!=="undefined"?new TextEncoder().encode(fallback).byteLength:fallback.length;if(size>maxBytes)throw new Error("A Meta retornou uma resposta maior que o limite seguro.");return fallback;}var received=0,chunks=[],decoder=new TextDecoder("utf-8"),text="";try{for(;;){var part=await reader.read();if(part.done)break;received+=part.value.byteLength;if(received>maxBytes){try{await reader.cancel();}catch(_){}throw new Error("A Meta retornou uma resposta maior que o limite seguro.");}chunks.push(part.value);}for(var i=0;i<chunks.length;i++)text+=decoder.decode(chunks[i],{stream:i<chunks.length-1});text+=decoder.decode();return text;}finally{try{reader.releaseLock&&reader.releaseLock();}catch(_){}}}
  async function metaRequest(cfg,token,path,options){if(!token)throw new Error("Cole um token de acesso da própria conta Meta para esta sessão.");options=options&&typeof options==="object"?options:{};var url="https://graph.facebook.com/"+metaGraphVersion(cfg)+"/"+String(path||"").replace(/^\//,"");var controller=typeof AbortController!=="undefined"?new AbortController():null;var timer=controller?setTimeout(function(){controller.abort();},20000):0;var headers=Object.assign({Authorization:"Bearer "+token,Accept:"application/json","Content-Type":"application/json"},options.headers||{});var requestOptions=Object.assign({},options,{headers:headers,credentials:"omit",cache:"no-store",redirect:"error"});if(controller)requestOptions.signal=controller.signal;try{var response=await fetch(url,requestOptions);var raw=await metaReadTextLimited(response,2*1024*1024);var data={};if(raw){try{data=JSON.parse(raw);}catch(_){data={};}}if(!response.ok){var msg=data&&data.error&&data.error.message||("Meta respondeu com HTTP "+response.status);var err=new Error(msg);err.code=data&&data.error&&data.error.code;throw err;}return data;}catch(err){if(err&&err.name==="AbortError")throw new Error("A Meta demorou demais para responder. Tente novamente.");throw err;}finally{if(timer)clearTimeout(timer);}}
  function metaOnboardingRequest(action,payload){return new Promise(function(resolve,reject){try{chrome.runtime.sendMessage({type:"EXTUI_META_ONBOARDING",action:String(action||""),payload:payload&&typeof payload==="object"?payload:{}},function(response){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message));return;}if(!response||response.ok!==true){var message=response&&response.userMessage||response&&response.error||"A conexão segura com o servidor da extensão não está disponível.";var error=new Error(message);error.code=response&&response.errorCode||"META_ONBOARDING_UNAVAILABLE";reject(error);return;}resolve(response.result||{});});}catch(err){reject(err);}});}
  function metaField(label,input,help){var wrap=el("label",{class:"extuiMetaOfficialField"},[el("span",{text:label}),input]);if(help)wrap.appendChild(el("small",{text:help}));return wrap;}
  function metaTimeMs(value,fallback){if(typeof value==="number"&&Number.isFinite(value)&&value>0)return value;var parsed=Date.parse(String(value||""));return Number.isFinite(parsed)?parsed:(fallback||Date.now());}
  function metaPublicCfg(base,connection){connection=connection&&typeof connection==="object"?connection:{};base=base&&typeof base==="object"?base:{};return{apiVersion:String(connection.graphVersion||connection.apiVersion||base.apiVersion||"v23.0"),wabaId:String(connection.wabaId||base.wabaId||""),phoneNumberId:String(connection.phoneNumberId||base.phoneNumberId||""),verifiedName:String(connection.verifiedName||base.verifiedName||""),displayPhoneNumber:String(connection.displayPhoneNumber||base.displayPhoneNumber||""),qualityRating:String(connection.qualityRating||base.qualityRating||""),connectionMode:"embedded",connectedAt:metaTimeMs(connection.connectedAt,metaTimeMs(base.connectedAt,Date.now())),lastValidatedAt:metaTimeMs(connection.lastValidatedAt,Date.now()),updatedAt:Date.now()};}
  function metaOpenAdvanced(details,options){if(!details)return;details.open=true;options=options||{};if(options.scroll===false)return;requestAnimationFrame(function(){try{details.scrollIntoView({behavior:"smooth",block:"nearest"});}catch(_){}});}
  async function renderMetaOfficial(container){
    var raw=await storageGet(META_OFFICIAL_CFG_KEY),cfg=metaCfgParse(raw),token=await metaSessionGet(META_OFFICIAL_TOKEN_KEY),mode=metaConnectionMode(cfg),connected=metaConnected(cfg,token),page=el("section",{class:"extuiMetaOfficialPage"});container.innerHTML="";
    var hero=el("header",{class:"extuiMetaOfficialHero"},[el("div",{class:"extuiMetaOfficialMark"},[icon(ICONS.meta)]),el("div",{class:"extuiMetaOfficialHeroCopy"},[el("span",{class:"extuiiEyebrow",text:"WHATSAPP BUSINESS PLATFORM"}),el("h1",{text:"Meta Oficial"}),el("p",{text:"Conecte a conta WhatsApp Business do próprio cliente à Extensão com o fluxo oficial da Meta. O modo WhatsApp Web continua disponível e independente."})])]);
    var badge=el("span",{class:"extuiMetaOfficialBadge "+(connected?"is-connected":""),text:connected?(mode==="embedded"?"META CONECTADA":"CONEXÃO MANUAL ATIVA"):"CONEXÃO OPCIONAL"});hero.appendChild(badge);page.appendChild(hero);
    var architecture=el("div",{class:"extuiMetaOfficialArchitecture"},[el("article",{},[el("strong",{text:"Modo Web"}),el("span",{text:"Continua usando o WhatsApp Web como hoje."})]),el("i",{text:"+"}),el("article",{},[el("strong",{text:"Meta Oficial"}),el("span",{text:"Templates, webhooks e operações pela Cloud API."})]),el("i",{text:"="}),el("article",{class:"is-highlight"},[el("strong",{text:"Modo Híbrido"}),el("span",{text:"O cliente usa o motor mais adequado para cada operação."})])]);page.appendChild(architecture);
    var connectCard=el("section",{class:"extuiMetaOfficialConnectCard"}),connectCopy=el("div",{class:"extuiMetaOfficialConnectCopy"},[el("span",{text:"RECOMENDADO"}),el("h2",{text:connected&&mode==="embedded"?"Conta conectada com a Meta":"Conectar com a Meta"}),el("p",{text:connected&&mode==="embedded"?"A autorização foi concluída pelo fluxo oficial. A extensão guarda apenas os identificadores públicos da conta; a credencial permanece no servidor da extensão.":"Entre na Meta, escolha a empresa e o número do WhatsApp Business e autorize a extensão. Sem copiar WABA ID, Phone Number ID ou token manualmente."})]);
    var connectActions=el("div",{class:"extuiMetaOfficialConnectActions"}),connectBtn=el("button",{type:"button",class:"extui-btn extui-btn--primary extuiMetaOfficialConnectBtn",text:connected&&mode==="embedded"?"Reconectar com a Meta":"Conectar com a Meta"}),advancedBtn=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Configuração manual"});connectActions.appendChild(connectBtn);connectActions.appendChild(advancedBtn);connectCard.appendChild(connectCopy);connectCard.appendChild(connectActions);page.appendChild(connectCard);
    var secureNote=el("div",{class:"extuiMetaOfficialNotice"},[el("strong",{text:"Credencial protegida"}),el("span",{text:mode==="embedded"?"No fluxo recomendado, o token não é entregue à extensão nem entra em backup. A extensão recebe apenas o estado da conexão e os IDs públicos necessários para exibir a conta.":"No modo manual, o token continua somente na sessão atual do navegador e é descartado ao encerrar a sessão."})]);page.appendChild(secureNote);
    var grid=el("div",{class:"extuiMetaOfficialGrid"}),status=el("section",{class:"extuiMetaOfficialCard"});
    status.appendChild(el("div",{class:"extuiMetaOfficialCardHead"},[el("div",{},[el("span",{text:"DIAGNÓSTICO"}),el("h2",{text:"Status da Cloud API"})]),el("small",{text:mode==="embedded"?"Embedded Signup":"Modo manual"})]));
    var statusTitle=connected?(cfg.verifiedName||"Conta Meta conectada"):"Ainda não conectado",statusDetail=connected?((cfg.displayPhoneNumber||cfg.phoneNumberId||"Número configurado")+(cfg.qualityRating?" · Qualidade: "+cfg.qualityRating:"")):"Use Conectar com a Meta ou abra a configuração manual.";
    var statusBox=el("div",{class:"extuiMetaOfficialStatus"+(connected?" is-ok":""),role:"status"},[el("strong",{text:statusTitle}),el("span",{text:statusDetail})]);status.appendChild(statusBox);
    var validate=el("button",{type:"button",class:"extui-btn extui-btn--secondary",text:"Validar conexão"}),disconnect=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Desconectar"});status.appendChild(el("div",{class:"extuiMetaOfficialActions"},[validate,disconnect]));
    var account=el("section",{class:"extuiMetaOfficialCard"});account.appendChild(el("div",{class:"extuiMetaOfficialCardHead"},[el("div",{},[el("span",{text:"CONTA"}),el("h2",{text:"Identificadores públicos"})]),el("small",{text:"Sem segredo"})]));
    var publicRows=el("div",{class:"extuiMetaOfficialPublicRows"});[["Empresa",cfg.verifiedName||"—"],["WhatsApp",cfg.displayPhoneNumber||"—"],["WABA ID",cfg.wabaId||"—"],["Phone Number ID",cfg.phoneNumberId||"—"]].forEach(function(pair){publicRows.appendChild(el("div",{},[el("span",{text:pair[0]}),el("strong",{text:String(pair[1])})]));});account.appendChild(publicRows);grid.appendChild(status);grid.appendChild(account);page.appendChild(grid);
    var advanced=el("details",{class:"extuiMetaOfficialAdvanced"});advanced.open=mode==="manual"&&!!(cfg.wabaId||token);var summary=el("summary",{},[el("div",{},[el("strong",{text:"Configuração manual"}),el("span",{text:"Avançado · use apenas se você já possui os IDs e um token da Meta."})]),el("em",{text:"AVANÇADO"})]);advanced.appendChild(summary);
    var setup=el("div",{class:"extuiMetaOfficialAdvancedBody"}),version=el("input",{type:"text",value:String(cfg.apiVersion||"v23.0"),placeholder:"v23.0"}),waba=el("input",{type:"text",inputmode:"numeric",value:String(cfg.wabaId||""),placeholder:"WABA ID"}),phone=el("input",{type:"text",inputmode:"numeric",value:String(cfg.phoneNumberId||""),placeholder:"Phone Number ID"}),tokenInput=el("input",{type:"password",autocomplete:"off",placeholder:token?"Token carregado nesta sessão":"Token de acesso da Meta"});
    setup.appendChild(metaField("Versão da Graph API",version,"Versão usada pelo app Meta da conta."));setup.appendChild(metaField("WhatsApp Business Account ID",waba,"WABA ID da conta comercial."));setup.appendChild(metaField("Phone Number ID",phone,"Identificador do número da Cloud API."));setup.appendChild(metaField("Token de acesso",tokenInput,"Nunca é salvo no armazenamento local nem incluído em backup."));
    var setupActions=el("div",{class:"extuiMetaOfficialActions"}),saveManual=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Salvar conexão manual"}),docs=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Documentação oficial"});setupActions.appendChild(saveManual);setupActions.appendChild(docs);setup.appendChild(setupActions);advanced.appendChild(setup);page.appendChild(advanced);
    var tools=el("section",{class:"extuiMetaOfficialTools"},[el("div",{class:"extuiMetaOfficialToolsHead"},[el("div",{},[el("span",{text:"RECURSOS OFICIAIS"}),el("h2",{text:"Ferramentas da conta conectada"})]),el("small",{text:mode==="embedded"?"Operações protegidas pelo servidor da extensão.":"Operações diretas pela Cloud API da conta."})])]);
    var templates=el("button",{type:"button",class:"extuiMetaOfficialTool",text:"Carregar templates"}),send=el("button",{type:"button",class:"extuiMetaOfficialTool",text:"Enviar mensagem de teste"}),templateOut=el("div",{class:"extuiMetaOfficialOutput",text:connected?"Conta pronta para consultar recursos.":"Conecte a conta para consultar templates."});tools.appendChild(el("div",{class:"extuiMetaOfficialToolActions"},[templates,send]));tools.appendChild(templateOut);page.appendChild(tools);container.appendChild(page);
    function currentManualCfg(){return{apiVersion:version.value.trim()||"v23.0",wabaId:waba.value.trim(),phoneNumberId:phone.value.trim(),connectionMode:"manual",updatedAt:Date.now()};}
    advancedBtn.addEventListener("click",function(){metaOpenAdvanced(advanced);});
    connectBtn.addEventListener("click", async function () {
      stopMetaOnboardingPoll();
      connectBtn.disabled = true;
      var original = connectBtn.textContent, pollStarted = false;
      connectBtn.textContent = "Preparando conexão…";
      try {
        var started = await metaOnboardingRequest("start", {}), authUrl = String(started.authUrl || started.url || ""), flowId = String(started.flowId || "");
        if (!authUrl || !flowId) throw new Error("O servidor ainda não disponibilizou o fluxo de conexão automática.");
        try {
          var authParsed = new URL(authUrl);
          if (authParsed.protocol !== "https:" || authParsed.origin !== window.__extRuntimeConfig.backendOrigin() || authParsed.username || authParsed.password || (authParsed.port && authParsed.port !== "443")) throw new Error("invalid");
          authUrl = authParsed.toString();
        } catch (_) { throw new Error("O servidor retornou um endereço de conexão inválido."); }
        if (chrome.windows && chrome.windows.create) chrome.windows.create({ url: authUrl, type: "popup", width: 780, height: 820, focused: true }, function () { void chrome.runtime.lastError; });
        else window.open(authUrl, "extappMetaConnect", "popup=yes,width=780,height=820,noopener,noreferrer");
        statusBox.classList.remove("is-error", "is-ok"); statusBox.classList.add("is-loading");
        statusBox.querySelector("strong").textContent = "Aguardando autorização da Meta…";
        statusBox.querySelector("span").textContent = "Conclua o login na janela aberta. Esta tela será atualizada automaticamente.";
        connectBtn.textContent = "Aguardando autorização…";
        var attempts = 0, maxAttempts = 80, pollToken = ++metaOnboardingRuntime.token;
        pollStarted = true;
        async function pollMetaConnection() {
          if (pollToken !== metaOnboardingRuntime.token) return;
          if (!connectBtn.isConnected) { stopMetaOnboardingPoll(); return; }
          attempts++;
          try {
            var polled = await metaOnboardingRequest("status", { flowId: flowId });
            if (pollToken !== metaOnboardingRuntime.token) return;
            if (polled && polled.status === "connected" && polled.connection) {
              stopMetaOnboardingPoll(); connectBtn.disabled = false; connectBtn.textContent = original;
              var next = metaPublicCfg(cfg, polled.connection); await storageSet(META_OFFICIAL_CFG_KEY, JSON.stringify(next)); await metaSessionRemove(META_OFFICIAL_TOKEN_KEY);
              toast("Conta Meta conectada com sucesso."); await renderMetaOfficial(container); return;
            }
            if (polled && polled.status === "failed") throw new Error(polled.message || "A Meta não concluiu a conexão.");
            if (attempts >= maxAttempts) {
              stopMetaOnboardingPoll(); connectBtn.disabled = false; connectBtn.textContent = original;
              statusBox.classList.remove("is-loading"); statusBox.classList.add("is-error"); statusBox.querySelector("strong").textContent = "Tempo de conexão esgotado"; statusBox.querySelector("span").textContent = "Você pode tentar novamente ou usar a configuração manual em Avançado."; return;
            }
            metaOnboardingRuntime.timer = setTimeout(pollMetaConnection, 1500);
          } catch (err) {
            if (pollToken !== metaOnboardingRuntime.token) return;
            stopMetaOnboardingPoll(); connectBtn.disabled = false; connectBtn.textContent = original;
            statusBox.classList.remove("is-loading"); statusBox.classList.add("is-error"); statusBox.querySelector("strong").textContent = "Não foi possível concluir a conexão"; statusBox.querySelector("span").textContent = err.message;
          }
        }
        metaOnboardingRuntime.timer = setTimeout(pollMetaConnection, 1500);
      } catch (e) {
        var rawMessage = String(e && e.message || ""), rawCode = String(e && e.code || ""); var backendMissing = /not[_ -]?found|http\s*404/i.test(rawMessage) || /NOT_FOUND|META_BACKEND_UNAVAILABLE/i.test(rawCode);
        statusBox.classList.remove("is-loading", "is-ok", "is-error", "is-attention"); statusBox.classList.add(backendMissing ? "is-attention" : "is-error"); statusBox.querySelector("strong").textContent = backendMissing ? "Conexão automática não está disponível nesta instalação" : "Conexão automática indisponível"; statusBox.querySelector("span").textContent = backendMissing ? "A Cloud API manual continua disponível. Abra Configuração manual para conectar WABA, Phone Number ID e token desta sessão." : (rawMessage + " A configuração manual continua disponível abaixo."); metaOpenAdvanced(advanced, { scroll: false }); connectCard.classList.add("is-attention"); connectBtn.textContent = backendMissing ? "Verificar novamente" : "Tentar novamente"; if (!backendMissing) toast(rawMessage, true); else toast("Use a Configuração manual enquanto o Embedded Signup não estiver publicado no servidor.");
      } finally {
        if (!pollStarted) { connectBtn.disabled = false; if (connectBtn.textContent === "Preparando conexão…") connectBtn.textContent = original; }
      }
    });
    disconnect.addEventListener("click",async function(){try{if(mode==="embedded")await metaOnboardingRequest("disconnect",{});}catch(_){ }await metaSessionRemove(META_OFFICIAL_TOKEN_KEY);await storageSet(META_OFFICIAL_CFG_KEY,JSON.stringify({apiVersion:cfg.apiVersion||"v23.0",connectionMode:"manual",updatedAt:Date.now()}));toast("Conta Meta desconectada.");await renderMetaOfficial(container);});
    validate.addEventListener("click",async function(){try{statusBox.classList.remove("is-error","is-ok");statusBox.classList.add("is-loading");statusBox.querySelector("strong").textContent="Validando conexão…";var data,next;if(mode==="embedded"){data=await metaOnboardingRequest("validate",{});next=metaPublicCfg(cfg,data.connection||data);await storageSet(META_OFFICIAL_CFG_KEY,JSON.stringify(next));}else{var active=tokenInput.value.trim()||await metaSessionGet(META_OFFICIAL_TOKEN_KEY),manual=currentManualCfg();if(tokenInput.value.trim())await metaSessionSet(META_OFFICIAL_TOKEN_KEY,tokenInput.value.trim());data=await metaRequest(manual,active,manual.phoneNumberId+"?fields=display_phone_number,verified_name,quality_rating");next=Object.assign(manual,{verifiedName:data.verified_name||"",displayPhoneNumber:data.display_phone_number||"",qualityRating:data.quality_rating||"",lastValidatedAt:Date.now()});await storageSet(META_OFFICIAL_CFG_KEY,JSON.stringify(next));}statusBox.classList.remove("is-loading");statusBox.classList.add("is-ok");statusBox.querySelector("strong").textContent=(next.verifiedName||"Número conectado")+" · "+(next.displayPhoneNumber||next.phoneNumberId);statusBox.querySelector("span").textContent="Qualidade: "+String(next.qualityRating||"não informada")+" · Graph "+metaGraphVersion(next);toast("Cloud API validada com sucesso.");}catch(e){var vm=String(e&&e.message||""),vc=String(e&&e.code||""),missing=/not[_ -]?found|http\s*404/i.test(vm)||/NOT_FOUND|META_BACKEND_UNAVAILABLE/i.test(vc);statusBox.classList.remove("is-loading","is-ok","is-error","is-attention");statusBox.classList.add(missing?"is-attention":"is-error");statusBox.querySelector("strong").textContent=missing?"Validação automática indisponível":"Falha na validação";statusBox.querySelector("span").textContent=missing?"O servidor desta instalação ainda não publicou o Embedded Signup. Use a Configuração manual para validar diretamente pela Cloud API.":vm;if(missing){metaOpenAdvanced(advanced,{scroll:false});toast("Configuração manual aberta para validar a Cloud API.");}else toast(vm,true);}});
    templates.addEventListener("click",async function(){try{templateOut.textContent="Carregando templates…";var data;if(mode==="embedded")data=await metaOnboardingRequest("templates",{});else{var active=tokenInput.value.trim()||await metaSessionGet(META_OFFICIAL_TOKEN_KEY),manual=currentManualCfg();if(!manual.wabaId)throw new Error("Informe o WABA ID.");data=await metaRequest(manual,active,manual.wabaId+"/message_templates?fields=name,status,language,category&limit=100");}var list=Array.isArray(data.data)?data.data:(Array.isArray(data.templates)?data.templates:[]);templateOut.innerHTML="";if(!list.length){templateOut.textContent="Nenhum template retornado pela conta.";return;}list.slice(0,30).forEach(function(item){templateOut.appendChild(el("div",{class:"extuiMetaOfficialTemplate"},[el("strong",{text:item.name||"Template"}),el("span",{text:(item.language||"—")+" · "+(item.category||"—")}),el("em",{text:item.status||"—"})]));});}catch(e){templateOut.textContent=e.message;toast(e.message,true);}});
    send.addEventListener("click",async function(){var to=prompt("Número de destino com DDI, somente dígitos (ex.: 5511999999999):");if(!to)return;var body=prompt("Mensagem de teste. O envio de texto livre depende da janela de atendimento de 24h:","Teste enviado pela extensão via Meta Oficial.");if(!body)return;try{var normalized=String(to).replace(/\D/g,"");if(!normalized)throw new Error("Número de destino inválido.");var result;if(mode==="embedded")result=await metaOnboardingRequest("sendTest",{to:normalized,body:String(body).slice(0,4096)});else{var active=tokenInput.value.trim()||await metaSessionGet(META_OFFICIAL_TOKEN_KEY),manual=currentManualCfg();if(!manual.phoneNumberId)throw new Error("Informe o Phone Number ID.");var payload={messaging_product:"whatsapp",recipient_type:"individual",to:normalized,type:"text",text:{preview_url:false,body:String(body).slice(0,4096)}};result=await metaRequest(manual,active,manual.phoneNumberId+"/messages",{method:"POST",body:JSON.stringify(payload)});}toast(result&&result.messages&&result.messages[0]?"Mensagem aceita pela Meta · "+result.messages[0].id:"Solicitação enviada à Meta.");}catch(e){toast(e.message,true);}});
  }

  async function renderAudioTranscriptionSection(container) { await refreshAiConnections(container); }
  async function renderAiTranslationSection(container) { await refreshAiConnections(container); }

  async function renderSection(container) { if (!core) throw new Error("Integration Core indisponível."); try { await refresh(container); } catch (error) { container.innerHTML = '<div class="extuiiLoadError">Não foi possível carregar as integrações.</div>'; } }
  async function renderAiSection(container) { if (!core) throw new Error("Integration Core indisponível."); try { await refreshAiConnections(container); } catch (error) { container.innerHTML = '<div class="extuiiLoadError">Não foi possível carregar as conexões de IA.</div>'; } }
  document.addEventListener("ext:dashboard-section-change", function () { closeDrawer(); });
  window.addEventListener("pagehide", closeDrawer);
  window.__extIntegrations = { openProvider: openProviderDrawer, refreshAiConnections: refreshAiConnections, modelPolicy: modelPolicy };
  window.__extDashboardShell.registerSection("ai-connect", renderAiSection);
  window.__extDashboardShell.registerSection("ai-transcription", renderAudioTranscriptionSection);
  window.__extDashboardShell.registerSection("ai-translation", renderAiTranslationSection);
  window.__extDashboardShell.registerSection("integracoes", renderSection);
  window.__extDashboardShell.registerSection("meta-oficial", renderMetaOfficial);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
