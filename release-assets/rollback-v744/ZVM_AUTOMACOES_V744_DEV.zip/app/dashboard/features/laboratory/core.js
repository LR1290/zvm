;
try{
(function (root, factory) {
  "use strict";
  var assistantsCore = root && root.__extAiAssistantsCore;
  var agentsCore = root && root.__extAiAgentsCore;
  var toolsRegistry = root && root.__extAiToolsRegistry;
  var api = factory(assistantsCore, agentsCore, toolsRegistry);
  if (root) root.__extLaboratorioCore = api;
})(typeof window !== "undefined" ? window : null, function (assistantsCore, agentsCore, toolsRegistry) {
  "use strict";

  var VARIABLE_PATTERN = /(?:\{\{|\{|#)(?:primeiro_nome|primeiroNome|first_name|fn|nome|nome_completo|full_name|nome_extapp|nome_ext|nome_whatsapp|numero|telefone|phone|email|empresa|company|origem_lead|leadSource|cidade|city|estado|state|endereco|address|cep|postalCode|idioma|language|saudacao|saudação|periodo_dia|periodo-dia|dia_semana|data|hora)/i;
  var UNIT_MS = { seconds: 1000, minutes: 60000, hours: 3600000, days: 86400000 };
  var UNIT_LABELS = { seconds: "segundos", minutes: "minutos", hours: "horas", days: "dias" };
  var ITEM_LABELS = { message: "Mensagem", audio: "Áudio", image: "Imagem", video: "Vídeo", media: "Imagem/Vídeo (legado)", sticker: "Figurinha", document: "Documento", pix: "PIX", contact: "Contato" };
  var AI_PROVIDER_LABELS = { openai: "OpenAI", gemini: "Google Gemini", xai: "Grok" };
  var MAX_FLOW_STEPS = 100;

  function digits(value) { return String(value || "").replace(/\D/g, ""); }

  function formatPhoneNumber(raw) {
    var value = digits(raw);
    if (!value) return "";
    if (value.length >= 12 && value.slice(0, 2) === "55") {
      var rest = value.slice(2);
      var ddd = rest.slice(0, 2);
      var number = rest.slice(2);
      if (number.length === 9) return "+55 (" + ddd + ") " + number.slice(0, 5) + "-" + number.slice(5);
      if (number.length === 8) return "+55 (" + ddd + ") " + number.slice(0, 4) + "-" + number.slice(4);
    }
    return "+" + value;
  }

  function resolveVariables(text, context, nowValue) {
    var template = String(text || "");
    if (!VARIABLE_PATTERN.test(template)) return template;
    context = context || {};
    var localName = String(context.localAlias || context.nome_extapp || context.extensionName || "").trim();
    var whatsappName = String(context.whatsappName || context.nome_whatsapp || context.name || "").trim();
    var fullName = localName || whatsappName || String(context.name || "").trim();
    var firstName = fullName.split(/\s+/)[0] || "";
    var now = nowValue instanceof Date ? nowValue : new Date(nowValue || Date.now());
    var hour = now.getHours();
    var greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
    var period = hour < 12 ? "manhã" : hour < 18 ? "tarde" : "noite";
    var dateText = String(now.getDate()).padStart(2, "0") + "/" + String(now.getMonth() + 1).padStart(2, "0") + "/" + now.getFullYear();
    var timeText = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    var vars = {
      primeiro_nome:firstName, primeiroNome:firstName, first_name:firstName, fn:firstName,
      nome:fullName, nome_completo:fullName, full_name:fullName,
      nome_extapp:localName || fullName, nome_ext:localName || fullName, nome_whatsapp:whatsappName || fullName,
      numero:formatPhoneNumber(context.phone || context.numero), telefone:formatPhoneNumber(context.phone || context.numero), phone:formatPhoneNumber(context.phone || context.numero),
      email:String(context.email || ""), empresa:String(context.empresa || context.company || ""), company:String(context.company || context.empresa || ""),
      origem_lead:String(context.origem_lead || context.leadSource || ""), leadSource:String(context.leadSource || context.origem_lead || ""),
      cidade:String(context.cidade || context.city || ""), city:String(context.city || context.cidade || ""), estado:String(context.estado || context.state || ""), state:String(context.state || context.estado || ""),
      endereco:String(context.endereco || context.address || ""), address:String(context.address || context.endereco || ""), cep:String(context.cep || context.postalCode || ""), postalCode:String(context.postalCode || context.cep || ""),
      idioma:String(context.idioma || context.language || "pt-BR"), language:String(context.language || context.idioma || "pt-BR"),
      saudacao:greeting, "saudação":greeting, periodo_dia:period, "periodo-dia":period,
      dia_semana:now.toLocaleDateString("pt-BR", { weekday:"long" }), data:dateText, hora:timeText
    };
    function expr(raw, original) {
      var m=String(raw||"").trim().match(/^([^|]+?)(?:\|\s*(?:fallback|default|padrao|padrão)\s*:\s*["']([^"']*)["'])?$/i);
      var key=String(m&&m[1]||raw).trim(),fallback=m&&m[2];
      if(Object.prototype.hasOwnProperty.call(vars,key)){var value=vars[key];return value!=null&&String(value)!==""?String(value):(fallback!=null?fallback:"");}
      return fallback!=null?fallback:original;
    }
    var out=template.replace(/\{\{\s*([^{}]+?)\s*\}\}/g,function(all,raw){return expr(raw,all);});
    out=out.replace(/(^|[^\{])\{([A-Za-z0-9_À-ÿ-]+)\}(?!\})/g,function(all,prefix,key){return prefix+expr(key,"{"+key+"}");});
    Object.keys(vars).sort(function(a,b){return b.length-a.length;}).forEach(function(key){var token="#"+key;if(out.indexOf(token)>=0)out=out.split(token).join(String(vars[key]||""));});
    return out;
  }

  function delayToMs(amount, unit) {
    return Math.max(0, Number(amount) || 0) * (UNIT_MS[unit] || UNIT_MS.minutes);
  }

  function formatDelay(amount, unit) {
    var value = Math.max(0, Number(amount) || 0);
    return value + " " + (UNIT_LABELS[unit] || UNIT_LABELS.minutes);
  }

  function formatDuration(ms) {
    var seconds = Math.max(0, Math.round((Number(ms) || 0) / 1000));
    if (!seconds) return "0 segundos";
    var days = Math.floor(seconds / 86400); seconds %= 86400;
    var hours = Math.floor(seconds / 3600); seconds %= 3600;
    var minutes = Math.floor(seconds / 60); seconds %= 60;
    var parts = [];
    if (days) parts.push(days + (days === 1 ? " dia" : " dias"));
    if (hours) parts.push(hours + (hours === 1 ? " hora" : " horas"));
    if (minutes) parts.push(minutes + (minutes === 1 ? " minuto" : " minutos"));
    if (seconds || !parts.length) parts.push(seconds + (seconds === 1 ? " segundo" : " segundos"));
    return parts.join(" ");
  }

  function event(state, title, detail, extra) {
    return Object.assign({ state: state, title: title, detail: detail || "" }, extra || {});
  }

  function itemFromCatalog(catalog, kind, itemId) {
    var entries = catalog && catalog[kind];
    return entries && entries[itemId] ? entries[itemId] : null;
  }

  function itemName(item, fallback) {
    return item && (item.fileName || item.name || item.displayName) || fallback || "Item sem nome";
  }

  function formatFileSize(dataUrl) {
    if (!dataUrl) return null;
    var kb = Math.round((String(dataUrl).length * 0.75) / 1024);
    return kb >= 1024 ? (kb / 1024).toFixed(1) + " MB" : kb + " KB";
  }

                                                                         
                                                                           
                                                                     
                                                                            
                                                                           
                                                                           
                                                  
  function buildMediaPreview(kind, content, itemDisplayName, context, now) {
    if (kind === "audio") return content && content.data ? { media: { kind: "audio", src: content.data } } : {};
    if (kind === "media" || kind === "image" || kind === "video") {
      var isImage = kind === "image" || (kind === "media" && content && content.data && /^data:image\//.test(content.data));
      var mediaCaption = content && content.caption ? resolveVariables(content.caption, context, now) : "";
      return content && content.data ? { media: { kind: isImage ? "image" : "video", src: content.data, caption: mediaCaption } } : {};
    }
    if (kind === "sticker") {
      return content && content.data ? { media: { kind: "image", src: content.data, sticker: true } } : {};
    }
    if (kind === "document") {
      return { media: { kind: "document", fileName: (content && content.fileName) || itemDisplayName, sizeLabel: formatFileSize(content && content.data) } };
    }
    return {};
  }

  function simulateItem(kind, item, content, context, now) {
    if (!item) return [event("error", "Item não encontrado", "Selecione um conteúdo salvo válido.")];
    if (kind === "message") {
      var template = content && content.data || "";
      return [event("simulated", "Mensagem simulada", resolveVariables(template, context, now), { template: template })];
    }
    if (kind === "pix") {
      var pixDetail = (content && content.keyType ? content.keyType + ": " : "") + (content && content.key || "Chave não informada");
      if (content && content.merchantName) pixDetail += " · " + content.merchantName;
      return [event("simulated", "PIX simulado", pixDetail)];
    }
    if (kind === "contact") {
      return [event("simulated", "Contato simulado", (content && content.contactName || itemName(item)) + (content && content.contactPhone ? " · " + content.contactPhone : ""))];
    }
    if (kind === "audio" || kind === "media" || kind === "image" || kind === "video" || kind === "sticker" || kind === "document") {
      var displayName = itemName(item, kind);
      var detail = kind === "document" ? "" : displayName;
      return [event("simulated", (ITEM_LABELS[kind] || "Conteúdo") + " simulado", detail, buildMediaPreview(kind, content, displayName, context, now))];
    }
    return [event("simulated", (ITEM_LABELS[kind] || "Conteúdo") + " simulado", itemName(item, kind))];
  }

  function crmLabel(snapshot, crmId, columnId) {
    var crm = (snapshot.crmList || []).find(function (entry) { return entry.id === crmId; });
    var column = crm && (crm.columns || []).find(function (entry) { return entry.id === columnId; });
    return {
      crm: crm && (crm.name || crm.id) || "CRM não encontrado",
      column: column && (column.title || column.name || column.id) || "etapa não encontrada"
    };
  }

  function contextIsInColumn(snapshot, context, crmId, columnId) {
    var phone = digits(context && context.phone);
    if (!phone) return false;
    var crm = (snapshot.crmList || []).find(function (entry) { return entry.id === crmId; });
    var column = crm && (crm.columns || []).find(function (entry) { return entry.id === columnId; });
    return !!(column && (column.items || []).some(function (entry) {
      return entry && entry.contact && digits(entry.contact.phoneNumber) === phone;
    }));
  }

  function firstNext(node) { return node && node.nextNodeIds && node.nextNodeIds[0] || null; }

  function promptPreview(value) {
    var normalized = String(value || "").replace(/\s+/g, " ").trim();
    return normalized.length > 240 ? normalized.slice(0, 237) + "..." : normalized;
  }

                                                                       
                                                                     
                                                                           
                          
  function multimodalEvents(assistant) {
    var multimodal = assistant && assistant.multimodal;
    if (!multimodal || (!multimodal.image && !multimodal.audio)) return [];
    var kinds = [];
    if (multimodal.image) kinds.push("Imagem");
    if (multimodal.audio) kinds.push("Áudio");
    return [event("simulated", "Entrada multimodal: " + kinds.join(" · "), "Na execução real, a extensão enviará esta mídia ao serviço de IA compatível.", { multimodalSimulation: true })];
  }

                                                                         
                                                                         
                                                                 
                                                                             
                                                                              
  function externalActionsEvents(assistant, snapshot) {
    var enabledIds = assistant && assistant.externalActions && Array.isArray(assistant.externalActions.enabled) ? assistant.externalActions.enabled : [];
    if (!enabledIds.length) return [];
    var allActions = snapshot && Array.isArray(snapshot.externalActions) ? snapshot.externalActions : [];
    var authorized = enabledIds.map(function (id) { return allActions.find(function (action) { return action.id === id; }); }).filter(Boolean);
    if (!authorized.length) return [];
    var summary = authorized.map(function (action) { return action.name + " (" + action.method + ")"; }).join(" · ");
    return [event("simulated", "Ações Externas disponíveis", summary + ". Nenhuma chamada de rede é feita no Laboratório.", { externalActionIds: authorized.map(function (action) { return action.id; }), externalActionSimulation: true })];
  }

  function simulateAgentStep(data, snapshot, context, now) {
    try {
      var agent = agentsCore.resolveForExecution(snapshot.agents, snapshot.assistants, snapshot.integrations, data.agentId, null, snapshot.knowledge);
      var agentTools = toolsRegistry ? toolsRegistry.definitionsFor(agent.assistant.tools && agent.assistant.tools.enabled) : [];
      var capabilityParts = [
        agent.assistant.context && agent.assistant.context.mode === "recent" ? "Contexto" : null,
        agent.assistant.memory && agent.assistant.memory.mode === "customer" ? "Memória" : null,
        agent.assistant.knowledge && agent.assistant.knowledge.mode === "base" ? "Base de Conhecimento" : null,
        agentTools.length + " tool" + (agentTools.length === 1 ? "" : "s")
      ].filter(Boolean);
      return [
        event("simulated", "Agente: " + agent.agentName, "Assistant: " + agent.assistant.assistantName + " · Máx. etapas: " + agent.maxSteps, { agentSimulation: true, maxSteps: agent.maxSteps, template: promptPreview(resolveVariables(data.task || "", context, now)), templateLabel: "Tarefa resolvida" }),
        event("simulated", "Capacidades herdadas", capabilityParts.join(" · "), { agentSimulation: true, toolIds: agentTools.map(function (tool) { return tool.id; }) })
      ].concat(multimodalEvents(agent.assistant)).concat(externalActionsEvents(agent.assistant, snapshot)).concat([
        event("simulated", "1. Avaliaria o objetivo", "A tarefa desta etapa seria combinada ao objetivo do agente, sem consultar o serviço de IA.", { agentSimulation: true }),
        event("simulated", "2. Poderia utilizar ferramentas permitidas", "Nenhuma ferramenta é executada no Laboratório.", { agentSimulation: true }),
        event("simulated", "3. Produziria resposta final", "Resposta do agente simulada, sem envio ao cliente.", { agentSimulation: true })
      ]);
    } catch (error) {
      return [event("error", "Agente inválido", error && error.message || "A configuração do agente não pôde ser resolvida.")];
    }
  }

  function simulateAiGenerateStep(data, snapshot, context, now) {
    if (assistantsCore && assistantsCore.nodeMode(data) === "assistant") {
      try {
        var assistant = assistantsCore.resolveForExecution(snapshot.assistants, snapshot.integrations, data.assistantId, null, snapshot.knowledge);
        var assistantPrompt = resolveVariables(data.prompt || "", context, now);
        var assistantModel = assistant.modelMode === "default" ? "padrão · " + assistant.model : assistant.model;
        var contextSummary = assistant.context && assistant.context.mode === "recent" ? " · Contexto recente: até " + assistant.context.messageCount + " mensagens (simulado)" : "";
        var result = [];
        if (assistant.memory && assistant.memory.mode === "customer") result.push(event("simulated", "Memória do cliente", "Na execução real, até 20 memórias salvas poderão ser utilizadas.", { memoryMode: "customer" }));
        if (assistant.knowledge && assistant.knowledge.mode === "base") {
          var knowledgeBase = snapshot.knowledge && Array.isArray(snapshot.knowledge.bases) ? snapshot.knowledge.bases.find(function (base) { return base.id === assistant.knowledge.baseId; }) : null;
          result.push(event("simulated", "Base de Conhecimento: " + (knowledgeBase && knowledgeBase.name || "requer atenção"), "Na execução real, o Extensão buscará os trechos mais relevantes desta base.", { knowledgeMode: "base" }));
        }
        var availableTools = toolsRegistry ? toolsRegistry.definitionsFor(assistant.tools && assistant.tools.enabled) : [];
        if (availableTools.length) result.push(event("simulated", "Ferramentas disponíveis", availableTools.map(function (tool) { return tool.label; }).join(" · ") + ". Nenhuma ferramenta é executada no Laboratório.", { toolIds: availableTools.map(function (tool) { return tool.id; }), toolSimulation: true }));
        result = result.concat(multimodalEvents(assistant)).concat(externalActionsEvents(assistant, snapshot));
        result.push(event("simulated", "IA · Assistente: " + assistant.assistantName, "Serviço de IA: " + (AI_PROVIDER_LABELS[assistant.providerId] || assistant.providerId) + " · Modelo: " + assistantModel + contextSummary + " · Resposta de IA simulada", { template: promptPreview(assistantPrompt), templateLabel: "Instruções finais", contextMessageCount: assistant.context && assistant.context.mode === "recent" ? assistant.context.messageCount : 0 }));
        return result;
      } catch (error) {
        return [event("error", "IA · Assistente inválido", error && error.message || "A configuração do assistente não pôde ser resolvida.")];
      }
    }
    var providerId = data.providerId || "";
    var providerLabel = AI_PROVIDER_LABELS[providerId] || "serviço de IA não configurado";
    var providerMetadata = snapshot.integrations && snapshot.integrations.providers && snapshot.integrations.providers[providerId];
    var model = data.model || providerMetadata && providerMetadata.model || "modelo padrão";
    var resolvedPrompt = resolveVariables(data.prompt || "", context, now);
    return [event("simulated", "IA · Chamaria " + providerLabel + " / " + model, "Resposta de IA simulada", { template: promptPreview(resolvedPrompt), templateLabel: "Instruções finais" })];
  }

  var LAB_OPT_IN_TERMINAL_TYPES = ["sendText","sendAudio","sendImage","sendVideo","sendSticker","sendDocument","sendPix","sendList","sendContact","sendSignature","sendQuickResponse","sendMedia","moveToColumn","condition"];
  var LAB_SAVED_NODE_KIND = { sendAudio:"audio", sendImage:"image", sendVideo:"video", sendSticker:"sticker", sendDocument:"document", sendPix:"pix", sendList:"interactive-list", sendContact:"contact", sendSignature:"signature", sendQuickResponse:"quick-response" };
  function isTerminalNode(node) { return !!node && (node.type === "end" || node.type === "endHuman" || (LAB_OPT_IN_TERMINAL_TYPES.indexOf(node.type) >= 0 && !!(node.data && node.data.isTerminal === true))); }
  function labDjb2Hash(str){var hash=5381;str=String(str||"");for(var i=0;i<str.length;i++)hash=(((hash<<5)+hash)+str.charCodeAt(i))|0;return hash>>>0;}

  function simulateFlow(flow, snapshot, context, decisions, now) {
    var timeline = [event("executed", "Início", flow && flow.name || "Fluxo")];
    var totalDelayMs = 0;
    if (!flow || !Array.isArray(flow.nodes) || !flow.startNodeId) {
      timeline.push(event("error", "Fluxo incompleto", "A definição não possui um ponto inicial executável."));
      return { timeline: timeline, totalDelayMs: totalDelayMs };
    }

    var nodesById = {};
    flow.nodes.forEach(function (node) { if (node && node.id) nodesById[node.id] = node; });
    var nodeId = flow.startNodeId;
    var visits = {};
    var steps = 0;
    decisions = decisions || {};

    while (nodeId && steps < MAX_FLOW_STEPS) {
      steps++;
      var node = nodesById[nodeId];
      if (!node) { timeline.push(event("error", "Conexão inválida", "O próximo node não existe na definição.")); break; }
      visits[nodeId] = (visits[nodeId] || 0) + 1;
      if (visits[nodeId] > 2) { timeline.push(event("warning", "Ciclo interrompido", "A simulação detectou repetição do mesmo caminho.")); break; }

      var data = node.data || {};
      if (node.type === "start") {
        timeline.push(event("executed", "Início estrutural", "Ponto inicial do diagrama."));
        nodeId = firstNext(node);
      } else if (node.type === "sendText") {
        var message = data.itemId ? itemFromCatalog(snapshot.items, "message", data.itemId) : null;
        var template = message && message.content ? message.content.data : data.text || "";
        timeline.push(event("simulated", "Enviaria mensagem", resolveVariables(template, context, now), { template: template }));
        nodeId = isTerminalNode(node) ? null : firstNext(node);
      } else if (node.type === "aiAgent") {
        simulateAgentStep(data, snapshot, context, now).forEach(function (entry) { timeline.push(entry); });
        nodeId = firstNext(node);
      } else if (node.type === "aiGenerate") {
        simulateAiGenerateStep(data, snapshot, context, now).forEach(function (entry) { timeline.push(entry); });
        nodeId = firstNext(node);
      } else if (LAB_SAVED_NODE_KIND[node.type] && !(node.type === "sendContact" && !data.itemId && (data.contactName || data.contactPhone))) {
        var savedKind = LAB_SAVED_NODE_KIND[node.type];
        var savedItem = itemFromCatalog(snapshot.items, savedKind, data.itemId);
        var savedContent = savedItem && savedItem.content;
        var savedEvents = simulateItem(savedKind, savedItem, savedContent, context, now);
        savedEvents.forEach(function (entry) { timeline.push(entry); });
        nodeId = isTerminalNode(node) ? null : firstNext(node);
      } else if (node.type === "sendMedia") {
        var kind = data.itemKind || "media";
        var media = itemFromCatalog(snapshot.items, kind, data.itemId);
        var mediaItemName = itemName(media, data.mediaType || "Arquivo configurado");
        var mediaDetail = mediaItemName;
        if (data.caption) mediaDetail += " · Legenda: " + resolveVariables(data.caption, context, now);
        timeline.push(event("simulated", "Enviaria " + (ITEM_LABELS[kind] || "arquivo").toLowerCase(), mediaDetail, buildMediaPreview(kind, media && media.content, mediaItemName, context, now)));
        nodeId = isTerminalNode(node) ? null : firstNext(node);
      } else if (node.type === "sendContact") {
        timeline.push(event("simulated", "Enviaria contato", (data.contactName || "Contato") + (data.contactPhone ? " · " + data.contactPhone : "")));
        nodeId = isTerminalNode(node) ? null : firstNext(node);
      } else if (node.type === "intervalo" || node.type === "delay") {
        var amount = typeof data.delayMs === "number" ? data.delayMs / 1000 : data.amount || 0;
        var unit = typeof data.delayMs === "number" ? "seconds" : data.unit || "minutes";
        var delayMs = typeof data.delayMs === "number" ? data.delayMs : delayToMs(amount, unit);
        totalDelayMs += delayMs;
        timeline.push(event("wait", "Aguardaria " + formatDelay(amount, unit), "A simulação continua imediatamente."));
        nodeId = firstNext(node);
      } else if (node.type === "moveToColumn") {
        var target = crmLabel(snapshot, data.crmId, data.columnId);
        timeline.push(event("simulated", "Simularia mover no CRM", target.crm + " · " + target.column));
        nodeId = isTerminalNode(node) ? null : firstNext(node);
      } else if (node.type === "condition") {
        var conditionChoice = decisions.conditions && decisions.conditions[node.id] || "auto";
        var matched = conditionChoice === "true" || (conditionChoice === "auto" && contextIsInColumn(snapshot, context, data.crmId, data.columnId));
        var conditionTarget = crmLabel(snapshot, data.crmId, data.columnId);
        timeline.push(event("decision", "Condição: contato em " + conditionTarget.column, matched ? "Caminho verdadeiro" : "Caminho falso"));
        nodeId = isTerminalNode(node) ? null : (matched ? firstNext(node) : node.nextNodeIdOnConditionFalse);
      } else if (node.type === "userInput") {
        var inputChoice = decisions.inputs && decisions.inputs[node.id] || "expected";
        var inputLabels = { expected: "Resposta esperada", different: "Resposta diferente", expiration: "Tempo expirado", stop: "Permanecer aguardando" };
        timeline.push(event("decision", "Esperaria uma resposta", "Decisão simulada: " + inputLabels[inputChoice]));
        if (inputChoice === "stop") { nodeId = null; }
        else if (inputChoice === "different") nodeId = node.nextNodeIdOnDifferentAnswer;
        else if (inputChoice === "expiration") nodeId = node.nextNodeIdOnExpiration;
        else nodeId = firstNext(node);
      } else if (node.type === "randomizer") {
        var weights = data.weights || [];
        var randomChoice = decisions.randomizers && decisions.randomizers[node.id];
        var selectedIndex;
        if (randomChoice === "random") {
          var totalWeight = weights.reduce(function (sum, weight) { return sum + Math.max(0, Number(weight && weight.weight) || 0); }, 0);
          var stickyMode = node.data && node.data.mode === "sticky";
          var stickyKey = context && (context.chatId || context.contactId || context.stickyKey) || flow.id || "laboratory";
          var roll = (stickyMode ? (labDjb2Hash(String(stickyKey)+":"+String(node.id)) % 100000) / 100000 : Math.random()) * totalWeight;
          var accumulator = 0;
          selectedIndex = 0;
          for (var weightIndex = 0; weightIndex < weights.length; weightIndex++) {
            accumulator += Math.max(0, Number(weights[weightIndex] && weights[weightIndex].weight) || 0);
            if (roll < accumulator) { selectedIndex = weightIndex; break; }
          }
        } else {
          selectedIndex = Math.max(0, Number(randomChoice) || 0);
        }
        timeline.push(event("decision", "Aleatorizar", "Caminho simulado: " + String.fromCharCode(65 + selectedIndex)));
        nodeId = weights[selectedIndex] && weights[selectedIndex].nextNodeId || null;
      } else if (node.type === "end") {
        timeline.push(event("final", "Fim", "Ramo finalizado intencionalmente."));
        nodeId = null;
      } else if (node.type === "endHuman") {
        timeline.push(event("warning", "Transferiria para atendimento humano", "A simulação termina sem alterar a conversa."));
        nodeId = null;
      } else {
        timeline.push(event("warning", "Node não simulado", node.type || "Tipo desconhecido"));
        nodeId = firstNext(node);
      }
    }

    if (steps >= MAX_FLOW_STEPS) timeline.push(event("error", "Limite de segurança atingido", "A definição excedeu " + MAX_FLOW_STEPS + " passos simulados."));
    else timeline.push(event("final", "Finalizado", totalDelayMs ? "Tempo real estimado: " + formatDuration(totalDelayMs) : "Sem espera programada."));
    return { timeline: timeline, totalDelayMs: totalDelayMs };
  }

  function simulateFunnel(funnel, snapshot, context, now) {
    var timeline = [event("executed", "Início", funnel && funnel.name || "Funil")];
    var totalDelayMs = 0;
    if (!funnel || !Array.isArray(funnel.items) || !funnel.items.length) {
      timeline.push(event("error", "Funil vazio", "A definição não possui etapas."));
      return { timeline: timeline, totalDelayMs: totalDelayMs };
    }
    funnel.items.forEach(function (step, index) {
      if (index > 0 && Number(step.delayAmount) > 0) {
        var waitMs = delayToMs(step.delayAmount, step.delayUnit || "minutes");
        totalDelayMs += waitMs;
        timeline.push(event("wait", "Aguardaria " + formatDelay(step.delayAmount, step.delayUnit || "minutes"), "Antes da etapa " + (index + 1) + "."));
      }
      if (step.type === "aiGenerate") {
        var aiEvents = simulateAiGenerateStep({ mode: "assistant", assistantId: step.assistantId, prompt: step.prompt || "" }, snapshot, context, now);
        aiEvents.forEach(function (entry, eventIndex) {
          entry.title = "Etapa " + (index + 1) + " · " + (eventIndex === aiEvents.length - 1 && entry.state !== "error" ? "Gerar com IA · simulado" : entry.title);
          timeline.push(entry);
        });
        return;
      }
      if (step.type === "aiAgent") {
        var agentEvents = simulateAgentStep({ agentId: step.agentId, task: step.task || "" }, snapshot, context, now);
        agentEvents.forEach(function (entry, eventIndex) {
          entry.title = "Etapa " + (index + 1) + " · " + (eventIndex === 0 && entry.state !== "error" ? "Executar Agente · simulado" : entry.title);
          timeline.push(entry);
        });
        return;
      }
      var item = itemFromCatalog(snapshot.items, step.type, step.itemId);
      var content = item && item.content;
      var result = simulateItem(step.type, item, content, context, now)[0];
      result.title = "Etapa " + (index + 1) + " · " + result.title;
      timeline.push(result);
    });
    timeline.push(event("final", "Finalizado", "Tempo real estimado: " + formatDuration(totalDelayMs)));
    return { timeline: timeline, totalDelayMs: totalDelayMs };
  }

  return {
    resolveVariables: resolveVariables,
    delayToMs: delayToMs,
    formatDuration: formatDuration,
    simulateItem: simulateItem,
    simulateFlow: simulateFlow,
    simulateFunnel: simulateFunnel,
    constants: { itemLabels: ITEM_LABELS, unitLabels: UNIT_LABELS, aiProviderLabels: AI_PROVIDER_LABELS }
  };
});
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
