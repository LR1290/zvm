;
try{
(function () {
  "use strict";

  if (window.__extLaboratorioModuleBooted) return;
  window.__extLaboratorioModuleBooted = true;

  var core = window.__extLaboratorioCore;
  var STORE_CONFIG = {
    message: { key: "EXTUI:textMessageStore", field: "textMessageList", label: "Mensagem" },
    audio: { key: "EXTUI:audioStore", field: "audioList", label: "Áudio" },
    image: { key: "EXTUI:mediaStore", field: "mediaList", label: "Imagem", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", field: "mediaList", label: "Vídeo", virtualMediaKind: "video" },
    media: { key: "EXTUI:mediaStore", field: "mediaList", label: "Imagem/Vídeo (legado)", legacyOnly: true },
    document: { key: "EXTUI:documentStore", field: "documentList", label: "Documento" },
    sticker: { key: "EXTUI:stickerStore", field: "stickerList", label: "Figurinha" },
    pix: { key: "EXTUI:pixStore", field: "pixList", label: "PIX" },
    contact: { key: "EXTUI:contactCardStore", field: "contactList", label: "Contato" }
  };
  var SESSION = {
    mode: "simulation",
    automationType: "flow",
    itemKind: "message",
    selected: {},
    name: "João Silva",
    phone: "5511999999999",
    scenario: "custom",
    decisions: { conditions: {}, inputs: {}, randomizers: {} },
    result: null
  };
  var LAB_SCENARIOS = [
    { id:"new-lead", label:"Novo lead", name:"Marina Alves", phone:"5511987654321", inputDecision:"expected", hint:"Simula um contato novo que responde normalmente." },
    { id:"returning", label:"Cliente recorrente", name:"Carlos Mendes", phone:"5511976543210", inputDecision:"expected", hint:"Simula alguém já conhecido voltando ao atendimento." },
    { id:"different", label:"Resposta diferente", name:"Ana Souza", phone:"5511965432109", inputDecision:"different", hint:"Força caminhos de resposta diferente quando existirem." },
    { id:"silent", label:"Sem resposta", name:"Bruno Lima", phone:"5511954321098", inputDecision:"expiration", hint:"Simula expiração de etapas que aguardam resposta." }
  ];

  var ICONS = {
    flask: '<path d="M9 3h6"/><path d="M10 9V3h4v6l5 9a2 2 0 0 1-1.8 3H6.8A2 2 0 0 1 5 18z"/><path d="M7.5 15h9"/>',
    shield: '<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3z"/><path d="m9 12 2 2 4-4"/>',
    play: '<path d="m6 3 14 9-14 9z"/>',
    send: '<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    route: '<circle cx="6" cy="19" r="3"/><path d="M9 19h4.5a3.5 3.5 0 0 0 0-7h-3a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    alert: '<path d="M12 3 2.5 20h19z"/><path d="M12 9v4M12 17h.01"/>',
    document: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>'
  };

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      if (key === "class") node.className = attrs[key];
      else if (key === "text") node.textContent = attrs[key];
      else if (key.indexOf("on") === 0 && typeof attrs[key] === "function") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      else node.setAttribute(key, attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); });
    return node;
  }

  function icon(name) {
    var span = el("span", { class: "extuilIcon", "aria-hidden": "true" });
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (ICONS[name] || "") + "</svg>";
    return span;
  }

  function parseState(raw) {
    if (!raw) return {};
    try {
      var parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
      return parsed && parsed.state || {};
    } catch (err) { return {}; }
  }

  function parseContent(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; }
    catch (err) { return null; }
  }

  function storageGet(keys) {
    return window.__extDashboardShell.storageGet(keys);
  }

  function listName(item) {
    return item && (item.name || item.fileName || item.displayName || item.title || item.id) || "Item sem nome";
  }

  function indexItems(list) {
    return (list || []).reduce(function (result, item) {
      if (item && item.id) result[item.id] = Object.assign({}, item);
      return result;
    }, {});
  }

  async function loadSnapshot() {
    var keys = Object.keys(STORE_CONFIG).map(function (kind) { return STORE_CONFIG[kind].key; });
    keys.push("EXTUI:extappFlowStore", "EXTUI:extappFunnelStore", "EXTUI:CrmStore", "EXTUI:integrationsStore", "EXTUI:aiAssistantsStore", "EXTUI:aiAgentsStore", "EXTUI:knowledgeBasesStore", "EXTUI:externalActionsStore");
    var values = await storageGet(keys);
    var items = {};
    Object.keys(STORE_CONFIG).forEach(function (kind) {
      var config = STORE_CONFIG[kind];
      items[kind] = indexItems(parseState(values[config.key])[config.field]);
    });
    var mediaRows=Object.keys(items.media||{}).map(function(id){return items.media[id];}),mediaIds=mediaRows.map(function(x){return x.id;}),mediaContent=mediaIds.length?await storageGet(mediaIds):{};items.image={};items.video={};mediaRows.forEach(function(item){var c=parseContent(mediaContent&&mediaContent[item.id])||{},kind=String(item.mediaKind||c.mediaKind||"").toLowerCase(),mime=String(c.mimeType||c.type||"").toLowerCase(),name=String(c.fileName||c.name||item.name||"").toLowerCase(),data=String(c.data||c.base64||"");if(kind!=="image"&&kind!=="video")kind=/^data:video\//i.test(data)||mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name)?"video":"image";items[kind][item.id]=Object.assign({},item,{content:c,mediaKind:kind});});
    return {
      items: items,
      flowList: parseState(values["EXTUI:extappFlowStore"]).flowList || [],
      funnelList: parseState(values["EXTUI:extappFunnelStore"]).funnelList || [],
      crmList: parseState(values["EXTUI:CrmStore"]).crmList || [],
      assistants: window.__extAiAssistantsCore ? window.__extAiAssistantsCore.normalizeStore(values["EXTUI:aiAssistantsStore"]) : { assistants: [] },
      agents: window.__extAiAgentsCore ? window.__extAiAgentsCore.normalizeStore(values["EXTUI:aiAgentsStore"]) : { agents: [] },
      knowledge: window.__extKnowledgeCore ? window.__extKnowledgeCore.normalizeStore(values["EXTUI:knowledgeBasesStore"]) : { bases: [] },
                                                                           
                                                                        
      externalActions: window.__extExternalActionsCore ? window.__extExternalActionsCore.normalizeStore(values["EXTUI:externalActionsStore"]).actions : [],
      integrations: window.__extIntegrationCore && window.__extIntegrationCore.normalizeStore
        ? window.__extIntegrationCore.normalizeStore(values["EXTUI:integrationsStore"])
        : { providers: {} }
    };
  }

                                                                            
                                                                            
                                                                            
                                                                         
                                                                       
                                                              
  function idsNeeded(type, entity, itemKind) {
    var ids = {};
    if (type === "item" && entity) ids[entity.id] = true;
    if (type === "flow" && entity) {
      (entity.nodes || []).forEach(function (node) {
        var data = node && node.data;
        if ((node.type === "sendText" || node.type === "sendMedia") && data && data.itemId) ids[data.itemId] = true;
      });
    }
    if (type === "funnel" && entity) {
      (entity.items || []).forEach(function (step) {
        if (["message", "audio", "media", "sticker", "document", "pix", "contact"].indexOf(step.type) >= 0 && step.itemId) ids[step.itemId] = true;
      });
    }
    return Object.keys(ids);
  }

  async function hydrateContent(snapshot, ids) {
    if (!ids.length) return snapshot;
    var values = await storageGet(ids);
    Object.keys(snapshot.items).forEach(function (kind) {
      Object.keys(snapshot.items[kind]).forEach(function (id) {
        if (Object.prototype.hasOwnProperty.call(values, id)) snapshot.items[kind][id].content = parseContent(values[id]);
      });
    });
    return snapshot;
  }

  function getSelected(snapshot, type) {
    var list = type === "flow" ? snapshot.flowList : type === "funnel" ? snapshot.funnelList : Object.keys(snapshot.items[SESSION.itemKind] || {}).map(function (id) { return snapshot.items[SESSION.itemKind][id]; });
    var selectedId = SESSION.selected[type === "item" ? "item:" + SESSION.itemKind : type];
    var selected = list.find(function (entry) { return entry.id === selectedId; }) || list[0] || null;
    if (selected) SESSION.selected[type === "item" ? "item:" + SESSION.itemKind : type] = selected.id;
    return selected;
  }

  function selectControl(label, value, options, onChange, helper) {
    var wrap = el("div", { class: "extuilField" });
    wrap.appendChild(el("label", { text: label }));
    var select = el("select", { class: "extuilSelect", "aria-label": label });
    options.forEach(function (option) {
      var optionNode = el("option", { value: option.value, text: option.label });
      if (String(option.value) === String(value)) optionNode.selected = true;
      select.appendChild(optionNode);
    });
    select.addEventListener("change", function () { onChange(select.value); });
    wrap.appendChild(select);
    if (helper) wrap.appendChild(el("span", { class: "extuilFieldHint", text: helper }));
    return wrap;
  }

  function inputControl(label, value, onInput, placeholder) {
    var wrap = el("div", { class: "extuilField" });
    wrap.appendChild(el("label", { text: label }));
    var input = el("input", { class: "extuilInput", type: "text", value: value, placeholder: placeholder || "", autocomplete: "off" });
    input.addEventListener("input", function () { onInput(input.value); });
    wrap.appendChild(input);
    return wrap;
  }

  function entityOptions(list, emptyLabel) {
    if (!list.length) return [{ value: "", label: emptyLabel }];
    return list.map(function (entry) { return { value: entry.id, label: listName(entry) }; });
  }

  function decisionControls(flow) {
    var nodes = flow && flow.nodes || [];
    var special = nodes.filter(function (node) { return ["condition", "userInput", "randomizer"].indexOf(node.type) >= 0; });
    if (!special.length) return null;
    var section = el("section", { class: "extuilDecisionGroup", "aria-labelledby": "extuilDecisionTitle" });
    section.appendChild(el("div", { id: "extuilDecisionTitle", class: "extuilGroupTitle", text: "Decisões da simulação" }));
    section.appendChild(el("p", { class: "extuilGroupHint", text: "Escolha caminhos sem aguardar eventos externos." }));
    special.forEach(function (node, index) {
      var label = "Etapa " + (index + 1) + " · ";
      var options;
      var bucket;
      if (node.type === "condition") {
        label += "Condição"; bucket = SESSION.decisions.conditions;
        options = [{ value: "auto", label: "Avaliar com o contato fictício" }, { value: "true", label: "Caminho verdadeiro" }, { value: "false", label: "Caminho falso" }];
      } else if (node.type === "userInput") {
        label += "Esperar resposta"; bucket = SESSION.decisions.inputs;
        options = [{ value: "expected", label: "Resposta esperada" }, { value: "different", label: "Resposta diferente" }, { value: "expiration", label: "Tempo expirado" }, { value: "stop", label: "Permanecer aguardando" }];
      } else {
        label += "Aleatorizar"; bucket = SESSION.decisions.randomizers;
        options = (node.data && node.data.weights || []).map(function (_, branch) { return { value: String(branch), label: "Caminho " + String.fromCharCode(65 + branch) }; });
        options.push({ value: "random", label: "Sortear conforme os pesos" });
      }
      if (bucket[node.id] == null) bucket[node.id] = options[0] && options[0].value;
      section.appendChild(selectControl(label, bucket[node.id], options, function (value) { bucket[node.id] = value; }));
    });
    return section;
  }

  function applyLabScenario(scenario, flow) {
    if (!scenario) return;
    SESSION.scenario = scenario.id;
    SESSION.name = scenario.name;
    SESSION.phone = scenario.phone;
    SESSION.result = null;
    SESSION.decisions = { conditions: {}, inputs: {}, randomizers: {} };
    if (flow && Array.isArray(flow.nodes)) {
      flow.nodes.forEach(function(node){
        if (!node || !node.id) return;
        if (node.type === "userInput") SESSION.decisions.inputs[node.id] = scenario.inputDecision || "expected";
        else if (node.type === "condition") SESSION.decisions.conditions[node.id] = "auto";
        else if (node.type === "randomizer") SESSION.decisions.randomizers[node.id] = "random";
      });
    }
  }

  function modeSwitch(rerender) {
    var switcher = el("div", { class: "extuilModeSwitch", role: "tablist", "aria-label": "Modo do laboratório" });
    [
      { value: "simulation", label: "Simulação segura", icon: "shield" },
      { value: "real", label: "Envio real", icon: "send" }
    ].forEach(function (mode) {
      var button = el("button", { type: "button", class: "extuilModeBtn" + (SESSION.mode === mode.value ? " is-active" : ""), role: "tab", "aria-selected": SESSION.mode === mode.value ? "true" : "false", "data-extui-academy-target": mode.value === "real" ? "laboratory-real-mode" : "laboratory-simulation-mode" });
      button.appendChild(icon(mode.icon)); button.appendChild(el("span", { text: mode.label }));
      button.addEventListener("click", async function () {
        if (mode.value === "real" && SESSION.mode !== "real") {
          var ok = window.extConfirm ? await window.extConfirm("Ativar envio real? As próximas execuções poderão enviar mensagens e executar ações em contatos reais.", { danger: true, okLabel: "Ativar envio real" }) : window.confirm("Ativar envio real?");
          if (!ok) return;
        }
        SESSION.mode = mode.value; rerender();
      });
      switcher.appendChild(button);
    });
    return switcher;
  }

  function renderSimulation(panel, snapshot, rerender, resultPanel) {
    panel.appendChild(el("span", { class: "extuilModeBadge is-simulation", text: "SIMULAÇÃO", "data-extui-academy-target": "laboratory-simulation" }));
    panel.appendChild(el("div", { class: "extuilPanelEyebrow", text: "AMBIENTE ISOLADO" }));
    panel.appendChild(el("h2", { text: "Monte o cenário" }));
    panel.appendChild(el("p", { class: "extuilPanelIntro", text: "Leia suas automações e conteúdos salvos sem executar ações no WhatsApp." }));

    panel.appendChild(selectControl("O que deseja simular?", SESSION.automationType, [
      { value: "flow", label: "Fluxo" }, { value: "funnel", label: "Funil" }, { value: "item", label: "Item salvo" }
    ], function (value) { SESSION.automationType = value; SESSION.result = null; rerender(); }));

    if (SESSION.automationType === "item") {
      panel.appendChild(selectControl("Tipo de item", SESSION.itemKind, Object.keys(STORE_CONFIG).filter(function(kind){return !STORE_CONFIG[kind].legacyOnly;}).map(function (kind) { return { value: kind, label: STORE_CONFIG[kind].label }; }), function (value) { SESSION.itemKind = value; SESSION.result = null; rerender(); }));
    }

    var selected = getSelected(snapshot, SESSION.automationType);
    var sourceList = SESSION.automationType === "flow" ? snapshot.flowList : SESSION.automationType === "funnel" ? snapshot.funnelList : Object.keys(snapshot.items[SESSION.itemKind] || {}).map(function (id) { return snapshot.items[SESSION.itemKind][id]; });
    var selectedKey = SESSION.automationType === "item" ? "item:" + SESSION.itemKind : SESSION.automationType;
    var sourceLabel = SESSION.automationType === "flow" ? "Fluxo" : SESSION.automationType === "funnel" ? "Funil" : "Item";
    panel.appendChild(selectControl(sourceLabel, selected && selected.id || "", entityOptions(sourceList, "Nenhum conteúdo disponível"), function (value) { SESSION.selected[selectedKey] = value; SESSION.result = null; rerender(); }));

    var scenarios = el("section", { class:"extuilScenarioGroup", "aria-label":"Cenários rápidos" });
    scenarios.appendChild(el("div", { class:"extuilGroupTitle", text:"Cenários rápidos" }));
    scenarios.appendChild(el("p", { class:"extuilGroupHint", text:"Preencha um contexto fictício e decisões comuns com um clique. Tudo continua isolado." }));
    var scenarioGrid = el("div", { class:"extuilScenarioGrid" });
    LAB_SCENARIOS.forEach(function(scenario){
      var button = el("button", { type:"button", class:"extuilScenarioBtn" + (SESSION.scenario === scenario.id ? " is-active" : ""), title:scenario.hint });
      button.appendChild(el("strong", { text:scenario.label }));
      button.appendChild(el("span", { text:scenario.hint }));
      button.addEventListener("click", function(){ applyLabScenario(scenario, SESSION.automationType === "flow" ? selected : null); rerender(); });
      scenarioGrid.appendChild(button);
    });
    var customBtn=el("button", {type:"button",class:"extuilScenarioBtn"+(SESSION.scenario==="custom"?" is-active":""),title:"Edite nome, número e decisões manualmente."},[el("strong",{text:"Personalizado"}),el("span",{text:"Use seus próprios valores fictícios."})]);
    customBtn.addEventListener("click",function(){SESSION.scenario="custom";SESSION.result=null;rerender();});scenarioGrid.appendChild(customBtn);
    scenarios.appendChild(scenarioGrid);panel.appendChild(scenarios);

    var contextGroup = el("section", { class: "extuilContextGroup", "data-extui-academy-target": "laboratory-contact" });
    contextGroup.appendChild(el("div", { class: "extuilGroupTitle", text: "Contato fictício" }));
    contextGroup.appendChild(el("p", { class: "extuilGroupHint", text: "Usado somente para resolver variáveis e condições locais." }));
    var contextGrid = el("div", { class: "extuilFieldGrid" });
    contextGrid.appendChild(inputControl("Nome", SESSION.name, function (value) { SESSION.name = value; SESSION.scenario = "custom"; }, "João Silva"));
    contextGrid.appendChild(inputControl("Número", SESSION.phone, function (value) { SESSION.phone = value; SESSION.scenario = "custom"; }, "5511999999999"));
    contextGroup.appendChild(contextGrid);
    panel.appendChild(contextGroup);

    if (SESSION.automationType === "flow") {
      var choices = decisionControls(selected);
      if (choices) panel.appendChild(choices);
    }

    var runButton = el("button", { type: "button", class: "extui-btn extui-btn--primary extuilRunBtn", "data-extui-academy-target": "laboratory-run" });
    runButton.appendChild(icon("play")); runButton.appendChild(el("span", { text: "Executar simulação" }));
    runButton.disabled = !selected;
    runButton.addEventListener("click", async function () {
      runButton.disabled = true;
      try {
        await hydrateContent(snapshot, idsNeeded(SESSION.automationType, selected, SESSION.itemKind));
        var context = { name: SESSION.name, phone: SESSION.phone };
        if (SESSION.automationType === "flow") SESSION.result = core.simulateFlow(selected, snapshot, context, SESSION.decisions, new Date());
        else if (SESSION.automationType === "funnel") SESSION.result = core.simulateFunnel(selected, snapshot, context, new Date());
        else SESSION.result = { timeline: core.simulateItem(SESSION.itemKind, selected, selected && selected.content, context, new Date()), totalDelayMs: 0 };
        renderTimeline(resultPanel, SESSION.result);
        window.dispatchEvent(new CustomEvent("ext:lab-simulation-complete", { detail: { type: SESSION.automationType } }));
      } catch (err) {
        renderError(resultPanel, err.message || "Não foi possível simular este cenário.");
      } finally { runButton.disabled = !selected; }
    });
    panel.appendChild(runButton);
    panel.appendChild(el("div", { class: "extuilSafetyNote" }, [icon("shield"), el("span", { text: "Nenhum envio, espera, movimento no CRM ou alteração nos dados é realizado." })]));
  }

  function automationHasAiStep(entity, type) {
    if (type === "flow") return (entity.nodes || []).some(function (node) { return node.type === "aiGenerate" || node.type === "aiAgent"; });
    return (entity.items || []).some(function (step) { return step.type === "aiGenerate" || step.type === "aiAgent"; });
  }

  function renderRealTest(panel, snapshot) {
    panel.appendChild(el("span", { class: "extuilModeBadge is-real", text: "ENVIO REAL" }));
    panel.appendChild(el("div", { class: "extuilPanelEyebrow extuilPanelEyebrow--danger", text: "AMBIENTE REAL" }));
    panel.appendChild(el("h2", { text: "Testar com um contato" }));
    panel.appendChild(el("p", { class: "extuilPanelIntro", text: "Reutiliza a automação e o mecanismo de envio já existentes na extensão." }));
    var warning = el("div", { class: "extuilRealWarning", role: "note" });
    warning.appendChild(icon("alert"));
    warning.appendChild(el("div", {}, [el("strong", { text: "Este teste enviará mensagens reais para o contato selecionado." }), el("span", { text: "O WhatsApp Web precisa estar aberto, utilizável e com licença válida." })]));
    panel.appendChild(warning);

    var realType = SESSION.automationType === "funnel" ? "funnel" : "flow";
    SESSION.automationType = realType;
    panel.appendChild(selectControl("Tipo de automação", realType, [{ value: "flow", label: "Fluxo" }, { value: "funnel", label: "Funil" }], function (value) { SESSION.automationType = value; SESSION.result = null; renderCurrentPanel(); }));
    var list = realType === "flow" ? snapshot.flowList : snapshot.funnelList;
    var selected = getSelected(snapshot, realType);
    panel.appendChild(selectControl(realType === "flow" ? "Fluxo" : "Funil", selected && selected.id || "", entityOptions(list, "Nenhuma automação disponível"), function (value) { SESSION.selected[realType] = value; renderCurrentPanel(); }));

                                                                          
                                                                       
                                                                          
                                                                       
    if (selected && automationHasAiStep(selected, realType)) {
      var aiWarning = el("div", { class: "extuilRealWarning", role: "note" });
      aiWarning.appendChild(icon("alert"));
      aiWarning.appendChild(el("div", {}, [el("strong", { text: "Esta automação tem etapa(s) de IA." }), el("span", { text: "O teste real usará o serviço de IA configurado e poderá consumir sua cota usando sua própria chave de acesso. O modo Simulação não usa serviços externos." })]));
      panel.appendChild(aiWarning);
    }

    var button = el("button", { type: "button", class: "extui-btn extuilRealBtn" });
    button.appendChild(icon("send")); button.appendChild(el("span", { text: "Selecionar contato e testar" }));
    button.disabled = !selected;
    button.addEventListener("click", function () {
      if (!selected || typeof window.__extOpenAutomationTestDialog !== "function" || typeof window.__extSendToWhatsAppTab !== "function") return;
      window.__extOpenAutomationTestDialog({
        onConfirm: function (contact) {
          var payload = { phoneNumber: contact.value, isTest: true };
          payload[realType === "flow" ? "flowId" : "funnelId"] = selected.id;
          return window.__extSendToWhatsAppTab(realType === "flow" ? "EXTUI_FLUXOS_START_MANUAL" : "EXTUI_FUNNELS_START_MANUAL", payload);
        }
      });
    });
    panel.appendChild(button);
    panel.appendChild(el("p", { class: "extuilRealFootnote", text: "A confirmação e a busca de contatos são as mesmas já usadas nas telas de Fluxos e Funis." }));
  }

  var currentPanelRenderer = null;
  function renderCurrentPanel() { if (currentPanelRenderer) currentPanelRenderer(); }

                                                                        
                                                                      
                                                                     
                                                                       
                                                                       
                        
  function renderMediaPreview(media) {
    if (media.kind === "image") {
      var imgWrap = el("div", { class: "extuilMediaPreview" });
      imgWrap.appendChild(el("img", { class: "extuilMediaImage", src: media.src, alt: media.caption || "Pré-visualização da imagem" }));
      if (media.caption) imgWrap.appendChild(el("span", { class: "extuilMediaCaption", text: media.caption }));
      return imgWrap;
    }
    if (media.kind === "video") {
      var vidWrap = el("div", { class: "extuilMediaPreview" });
      vidWrap.appendChild(el("video", { class: "extuilMediaVideo", src: media.src, controls: "controls", preload: "metadata" }));
      if (media.caption) vidWrap.appendChild(el("span", { class: "extuilMediaCaption", text: media.caption }));
      return vidWrap;
    }
    if (media.kind === "audio") {
      return el("div", { class: "extuilMediaPreview" }, [el("audio", { class: "extuilMediaAudio", src: media.src, controls: "controls", preload: "metadata" })]);
    }
                                                                   
                                                                          
                                              
    var docWrap = el("div", { class: "extuilMediaPreview extuilMediaDocument" });
    docWrap.appendChild(icon("document"));
    var docInfo = el("div", {});
    docInfo.appendChild(el("strong", { text: media.fileName || "Documento" }));
    if (media.sizeLabel) docInfo.appendChild(el("span", { class: "extuilMediaCaption", text: media.sizeLabel }));
    docWrap.appendChild(docInfo);
    return docWrap;
  }

  function renderTimeline(container, result) {
    container.innerHTML = "";
    var header = el("div", { class: "extuilResultHeader" });
    header.appendChild(el("div", {}, [el("div", { class: "extuilPanelEyebrow", text: "RESULTADO" }), el("h2", { text: "Linha do tempo" })]));
    header.appendChild(el("span", { class: "extuilResultBadge", text: (result.timeline || []).length + " eventos" }));
    container.appendChild(header);
    if (result.totalDelayMs) container.appendChild(el("div", { class: "extuilDuration" }, [icon("clock"), el("span", { text: "Duração real estimada: " + core.formatDuration(result.totalDelayMs) })]));
    var timeline = el("ol", { class: "extuilTimeline", "aria-label": "Resultado da simulação" });
    (result.timeline || []).forEach(function (entry) {
      var item = el("li", { class: "extuilTimelineItem is-" + entry.state });
      var marker = el("span", { class: "extuilTimelineMarker" });
      marker.appendChild(icon(entry.state === "wait" ? "clock" : entry.state === "warning" || entry.state === "error" ? "alert" : entry.state === "decision" ? "route" : "check"));
      var content = el("div", { class: "extuilTimelineContent" });
      content.appendChild(el("strong", { text: entry.title }));
      if (entry.template != null && entry.template !== entry.detail) {
        content.appendChild(el("span", { class: "extuilTimelineLabel", text: entry.templateLabel || "Template" }));
        content.appendChild(el("code", { text: entry.template || "(vazio)" }));
        content.appendChild(el("span", { class: "extuilTimelineLabel", text: "Resultado" }));
      }
      if (entry.detail) content.appendChild(el("p", { text: entry.detail }));
      if (entry.media) content.appendChild(renderMediaPreview(entry.media));
      item.appendChild(marker); item.appendChild(content); timeline.appendChild(item);
    });
    container.appendChild(timeline);
  }

  function renderEmptyResult(container) {
    container.innerHTML = "";
    var empty = el("div", { class: "extuilResultEmpty" });
    empty.appendChild(icon("route"));
    empty.appendChild(el("h2", { text: "A execução aparecerá aqui" }));
    empty.appendChild(el("p", { text: "Cada etapa, decisão e espera será descrita em uma linha do tempo legível." }));
    container.appendChild(empty);
  }

  function renderError(container, message) {
    container.innerHTML = "";
    container.appendChild(el("div", { class: "extuilLoadError", role: "alert" }, [icon("alert"), el("span", { text: message })]));
  }

  async function renderLaboratorioSection(container) {
    if (!core) { renderError(container, "O núcleo de simulação não foi carregado."); return; }
    var page = el("div", { class: "extuilPage" });
    var hero = el("header", { class: "extuilHeader" });
    var heading = el("div", { class: "extuilHeading" });
    heading.appendChild(el("div", { class: "extuilHeadingIcon" }, [icon("flask")]));
    heading.appendChild(el("div", {}, [el("span", { class: "extuilKicker", text: "BANCADA DE AUTOMAÇÕES" }), el("h1", { text: "Laboratório Extensão" }), el("p", { text: "Valide conteúdo, caminhos e tempos antes de usar uma conversa real." })]));
    hero.appendChild(heading);
    page.appendChild(hero);
    var loading = el("div", { class: "extuilLoading", role: "status", text: "Preparando ambiente isolado..." });
    page.appendChild(loading); container.appendChild(page);
    try {
      var snapshot = await loadSnapshot();
      loading.remove();
      var labSummary = el("div", { class: "extuilCapabilityGrid" }, [
        el("div",{},[icon("shield"),el("span",{text:"Segurança"}),el("strong",{text:"Simulação sem envio"})]),
        el("div",{},[icon("route"),el("span",{text:"Caminhos"}),el("strong",{text:String((snapshot.flowList||[]).length)+" fluxos"})]),
        el("div",{},[icon("route"),el("span",{text:"Sequências"}),el("strong",{text:String((snapshot.funnelList||[]).length)+" funis"})]),
        el("div",{},[icon("clock"),el("span",{text:"Resultado"}),el("strong",{text:"Linha do tempo"})])
      ]);
      page.appendChild(labSummary);
      var shell = el("div", { class: "extuilWorkbench" });
      var controls = el("div", { class: "extuilControls" });
      var panel = el("section", { class: "extuilPanel" });
      var result = el("section", { class: "extuilPanel extuilResultPanel", "aria-live": "polite" });
      controls.appendChild(modeSwitch(renderCurrentPanel)); controls.appendChild(panel);
      shell.appendChild(controls); shell.appendChild(result); page.appendChild(shell);
      currentPanelRenderer = function () {
        panel.innerHTML = "";
        var switcher = controls.querySelector(".extuilModeSwitch");
        var replacement = modeSwitch(renderCurrentPanel);
        controls.replaceChild(replacement, switcher);
        if (SESSION.mode === "simulation") renderSimulation(panel, snapshot, renderCurrentPanel, result);
        else renderRealTest(panel, snapshot);
        if (SESSION.result && SESSION.mode === "simulation") renderTimeline(result, SESSION.result);
        else if (SESSION.mode === "simulation") renderEmptyResult(result);
        else {
          result.innerHTML = "";
          var realInfo = el("div", { class: "extuilResultEmpty extuilResultEmpty--real" });
          realInfo.appendChild(icon("send"));
          realInfo.appendChild(el("h2", { text: "Execução pelo mecanismo real" }));
          realInfo.appendChild(el("p", { text: "Após escolher o contato, o teste continua no WhatsApp Web e respeita os gates de licença existentes." }));
          result.appendChild(realInfo);
        }
      };
      renderCurrentPanel();
    } catch (err) {
      loading.remove(); renderError(page, err.message || "Não foi possível carregar o Laboratório.");
    }
  }

  if (window.__extDashboardShell) window.__extDashboardShell.registerSection("laboratorio", renderLaboratorioSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
