;
try{
(function () {
  "use strict";

  if (window.__extFollowUpDashModuleBooted) return;
  window.__extFollowUpDashModuleBooted = true;

                                                                          
                                                                      
                                                                         
                                                                
                                                                         
                                                                         
                                                                       
                                                         
    
                                                                       
                                                                      
                                                                    
                                                                        
                                                           
  var FOLLOWUP_KEY = "EXTUI:extappFollowUpStore";
  var FOLLOWUP_QUEUE_KEY = "EXTUI:extappFollowUpQueueStore";
  var CRM_KEY = "EXTUI:CrmStore";
  var QUICK_ITEMS_RECENTS_KEY = "EXTUI:quickItemsRecents";
                                                                              
                                                                                     
  var followUpActiveStorageHandler = null;
  try {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
      [CRM_KEY, FOLLOWUP_KEY, FOLLOWUP_QUEUE_KEY].forEach(function (key) {
        window.ExtensionStorage.subscribe(key, function (_newValue, _oldValue, _changedKey, meta) { if (meta && meta.local === true) return; if (typeof followUpActiveStorageHandler === "function") followUpActiveStorageHandler(key); });
      });
    }
  } catch (_) {}
                                                                          
                                                                          
                                                                           
                                                                      
  var ITEM_STORES = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList", label: "Mensagem", icon: "message" },
    audio: { key: "EXTUI:audioStore", listField: "audioList", label: "Áudio", icon: "audio" },
    image: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem", icon: "media", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Vídeo", icon: "video", virtualMediaKind: "video" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem/Vídeo (legado)", icon: "media", legacyOnly: true },
    document: { key: "EXTUI:documentStore", listField: "documentList", label: "Documento", icon: "document" },
    funnel: { key: "EXTUI:extappFunnelStore", listField: "funnelList", label: "Funil", icon: "funnel" }
  };
  var ICONS = {
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    audio: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    media: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    video: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m10 9 5 3-5 3z"/>',
    sticker: '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>',
    document: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
    funnel: '<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>'
  };

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function icon(name) {
    var span = document.createElement("span");
    span.className = "extui-svgicon";
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || "") + "</svg>";
    return span;
  }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function storageGet(key) {
    return window.__extDashboardShell.storageGet(key).then(function (result) { return result ? result[key] : undefined; });
  }
  function storageSet(key, value) {
    var obj = {}; obj[key] = value;
    return window.__extDashboardShell.storageSet(obj);
  }
  function parsePersisted(raw) {
    if (!raw) return null;
    try { return typeof raw === "string" ? JSON.parse(raw) : raw; } catch (_) { return null; }
  }
  function fmtTiming(t) {
    var parts = [];
    if (t.days) parts.push(t.days + "d");
    if (t.hours) parts.push(t.hours + "h");
    if (t.minutes) parts.push(t.minutes + "min");
    return parts.length ? parts.join(" ") : "0min";
  }
  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
  }

  async function loadRules() {
    var state = parsePersisted(await storageGet(FOLLOWUP_KEY));
    return (state && state.state && state.state.followUpList) || [];
  }
  async function saveRules(list) { await storageSet(FOLLOWUP_KEY, JSON.stringify({ state: { followUpList: list }, version: 0 })); }
  async function loadQueue() {
    var state = parsePersisted(await storageGet(FOLLOWUP_QUEUE_KEY));
    return (state && state.state && state.state.queue) || [];
  }
  async function saveQueue(queue) { await storageSet(FOLLOWUP_QUEUE_KEY, JSON.stringify({ state: { queue: queue }, version: 0 })); }
  async function loadCrmList() {
    var state = parsePersisted(await storageGet(CRM_KEY));
    return (state && state.state && state.state.crmList) || [];
  }

  function renderFollowUp(root) {
    var wrap = el("div", { class: "extuiFollowUpWrap" });
    root.appendChild(wrap);

    var followHead = el("div", { class: "extuiPageHeading extuiFollowUpPageHeading" }, [
      el("div", { class: "extuiPageHeadingMain" }, [
        el("div", { class: "extuiPageHeadingIcon" }, [icon("clock")]),
        el("div", { class: "extuiPageHeadingCopy" }, [
          el("div", { class: "extuiPageHeadingEyebrow", text: "Automação de relacionamento" }),
          el("h1", { text: "FollowUp" }),
          el("p", { text: "Reengaje contatos por etapa, tempo e resposta sem sair do fluxo de trabalho." })
        ])
      ])
    ]);
    wrap.appendChild(followHead);

    var layout = el("div", { class: "extuiFollowUpLayout" });
    var card = el("section", { class: "extuiCard extuiFollowUpCard extuiFollowUpCard--form extuiFollowUpBuilder" });
    card.appendChild(el("div", { class: "extuiFollowUpCardHead" }, [
      el("div", {}, [el("span", { class: "extuiFollowUpCardEyebrow", text: "Nova automação" }), el("h2", { text: "Criar regra" })]),
      el("span", { class: "extuiFollowUpStepBadge", text: "1" })
    ]));
    card.appendChild(el("p", { class: "extuiFollowUpHint", text: "Defina onde observar o contato, quanto tempo esperar e qual item ou funil deve ser disparado." }));

                                                                            
    var form = el("div", { class: "extuiFollowUpForm", "data-extui-academy-target": "followup-form" });
    form.appendChild(el("label", { text: "Nome da regra" }));
    var nameInput = el("input", { type: "text", placeholder: "Ex: Reengajar sem resposta" });
    form.appendChild(nameInput);

    var crmRow = el("div", { class: "extuiFollowUpFieldRow" });
    var crmSelect = el("select", {});
    var columnSelect = el("select", {});
    crmRow.appendChild(el("div", { class: "extuiFollowUpFieldCol" }, [el("label", { text: "CRM" }), crmSelect]));
    crmRow.appendChild(el("div", { class: "extuiFollowUpFieldCol" }, [el("label", { text: "Coluna" }), columnSelect]));
    form.appendChild(crmRow);

    form.appendChild(el("label", { text: "Quando disparar" }));
    var triggerSelect = el("select", {}, [
      el("option", { value: "timing", text: "Depois de um tempo parado na coluna" }),
      el("option", { value: "onEnter", text: "Assim que entrar na coluna" })
    ]);
    form.appendChild(triggerSelect);

    var timingRow = el("div", { class: "extuiFollowUpTimingRow" });
    var daysInput = el("input", { type: "number", min: "0", value: "0" });
    var hoursInput = el("input", { type: "number", min: "0", value: "0" });
    var minutesInput = el("input", { type: "number", min: "0", value: "30" });
    [["Dias", daysInput], ["Horas", hoursInput], ["Minutos", minutesInput]].forEach(function (pair) {
      timingRow.appendChild(el("div", { class: "extuiFollowUpTimingCol" }, [el("span", { text: pair[0] }), pair[1]]));
    });
    form.appendChild(timingRow);
    triggerSelect.addEventListener("change", function () { timingRow.style.display = triggerSelect.value === "timing" ? "flex" : "none"; });

    var contentRow = el("div", { class: "extuiFollowUpFieldRow" });
    var sendTypeSelect = el("select", {});
    Object.keys(ITEM_STORES).filter(function(t){return !ITEM_STORES[t].legacyOnly;}).forEach(function (t) { sendTypeSelect.appendChild(el("option", { value: t, text: ITEM_STORES[t].label })); });
    var itemSelect = el("select", {});
    contentRow.appendChild(el("div", { class: "extuiFollowUpFieldCol" }, [el("label", { text: "Tipo" }), sendTypeSelect]));
    contentRow.appendChild(el("div", { class: "extuiFollowUpFieldCol" }, [el("label", { text: "Item/Funil" }), itemSelect]));
    form.appendChild(contentRow);

    var cancelRow = el("label", { class: "extuiFollowUpToggleRow", "data-extui-academy-target": "followup-cancel-on-reply" });
    var cancelCheckbox = el("input", { type: "checkbox", checked: "checked" });
    var cancelSwitch = el("span", { class: "extuiSwitch" }, [cancelCheckbox, el("span", { class: "track" })]);
    cancelRow.appendChild(cancelSwitch);
    cancelRow.appendChild(el("span", { text: "Cancelar se o contato responder antes do disparo" }));
    form.appendChild(cancelRow);

    var logicPreview = el("div", { class: "extuiFollowUpLogicPreview" });
    form.appendChild(logicPreview);
    function paintLogicPreview(){
      var crmOpt=crmSelect.options[crmSelect.selectedIndex], colOpt=columnSelect.options[columnSelect.selectedIndex], itemOpt=itemSelect.options[itemSelect.selectedIndex];
      var when=triggerSelect.value==="onEnter"?"assim que entrar":((Number(daysInput.value)||0)+"d "+(Number(hoursInput.value)||0)+"h "+(Number(minutesInput.value)||0)+"min depois de permanecer");
      logicPreview.innerHTML="";
      logicPreview.appendChild(el("span",{text:"SE"}));
      logicPreview.appendChild(el("strong",{text:"o contato estiver em "+(crmOpt?crmOpt.text:"CRM")+" / "+(colOpt?colOpt.text:"etapa")}));
      logicPreview.appendChild(el("span",{text:"E"}));
      logicPreview.appendChild(el("strong",{text:when}));
      logicPreview.appendChild(el("span",{text:"ENTÃO"}));
      logicPreview.appendChild(el("strong",{text:"executar "+(itemOpt?itemOpt.text:"o conteúdo selecionado")+(cancelCheckbox.checked?" · cancelar se houver resposta":"")}));
    }
    [triggerSelect,daysInput,hoursInput,minutesInput,sendTypeSelect,itemSelect,cancelCheckbox,crmSelect,columnSelect].forEach(function(node){node.addEventListener("change",paintLogicPreview);node.addEventListener("input",paintLogicPreview);});

    var createBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary", text: "Salvar e ativar regra" });
    form.appendChild(createBtn);
    card.appendChild(form);
    layout.appendChild(card);

    var rulesCard = el("section", { class: "extuiCard extuiFollowUpCard extuiFollowUpCard--rules", "data-extui-academy-target": "followup-monitor" });
    var rulesCount = el("span", { class: "extuiFollowUpRulesCount", text: "0 regras" });
    rulesCard.appendChild(el("div", { class: "extuiFollowUpCardHead" }, [
      el("div", {}, [el("span", { class: "extuiFollowUpCardEyebrow", text: "Monitoramento" }), el("h2", { text: "Regras criadas" })]),
      rulesCount
    ]));
    rulesCard.appendChild(el("p", { class: "extuiFollowUpHint", text: "Acompanhe regras ativas, contatos aguardando e envios concluídos." }));
    var monitorKpis = el("div", { class: "extuiFollowUpMonitorKpis" }, [
      el("div", { "data-follow-kpi":"active" }, [el("strong",{text:"0"}),el("span",{text:"ativas"})]),
      el("div", { "data-follow-kpi":"pending" }, [el("strong",{text:"0"}),el("span",{text:"aguardando"})]),
      el("div", { "data-follow-kpi":"sent" }, [el("strong",{text:"0"}),el("span",{text:"concluídos"})]),
      el("div", { "data-follow-kpi":"errors" }, [el("strong",{text:"0"}),el("span",{text:"erros"})])
    ]);
    rulesCard.appendChild(monitorKpis);

                                                                            
    var toolbarRow = el("div", { class: "extuiFollowUpToolbar" });
                                                                        
                                                                          
                                                                         
                                               
    var searchWrap = el("div", { class: "extuiSearch" }, [icon("search")]);
    var searchInput = el("input", { type: "search", placeholder: "Buscar regra pelo nome..." });
    searchWrap.appendChild(searchInput);
    var filterSelect = el("select", {}, [
      el("option", { value: "all", text: "Todas" }),
      el("option", { value: "active", text: "Só ativas" }),
      el("option", { value: "inactive", text: "Só inativas" })
    ]);
    toolbarRow.appendChild(searchWrap);
    toolbarRow.appendChild(filterSelect);
    rulesCard.appendChild(toolbarRow);

    var listEl = el("div", { class: "extuiFollowUpList" });
    rulesCard.appendChild(listEl);
    layout.appendChild(rulesCard);
    wrap.appendChild(layout);

    var _crmList = [];
    async function refreshCrmOptions() {
      crmSelect.innerHTML = "";
      _crmList = await loadCrmList().catch(function () { return []; });
      if (_crmList.length === 0) { crmSelect.appendChild(el("option", { value: "", text: "Nenhum CRM criado" })); columnSelect.innerHTML = ""; columnSelect.appendChild(el("option", { value: "", text: "—" })); return; }
      _crmList.forEach(function (c) { crmSelect.appendChild(el("option", { value: c.id, text: c.name || c.id })); });
      refreshColumnOptions();
    }
    function refreshColumnOptions() {
      columnSelect.innerHTML = "";
      var crm = _crmList.find(function (c) { return c.id === crmSelect.value; });
      var columns = (crm && crm.columns) || [];
      if (columns.length === 0) { columnSelect.appendChild(el("option", { value: "", text: "Sem colunas" })); return; }
      columns.forEach(function (col) { columnSelect.appendChild(el("option", { value: col.id, text: col.title || "(sem nome)" })); });
    }
    crmSelect.addEventListener("change", refreshColumnOptions);

    async function refreshItemOptions() {
      itemSelect.innerHTML = "";
      var cfg = ITEM_STORES[sendTypeSelect.value];
      var values = await Promise.all([storageGet(cfg.key), storageGet(QUICK_ITEMS_RECENTS_KEY)]).catch(function () { return [null, null]; });
      var state = parsePersisted(values[0]);
      var list = (state && state.state && state.state[cfg.listField]) || [];
      if(cfg.virtualMediaKind&&list.length){var filtered=[];for(var mi=0;mi<list.length;mi++){var item=list[mi],kind=String(item&&item.mediaKind||"");if(kind!=="image"&&kind!=="video"){try{var content=parsePersisted(await storageGet(String(item.id)))||{},mime=String(content.mimeType||content.type||"").toLowerCase(),name=String(content.fileName||content.name||item.name||"").toLowerCase(),data=String(content.data||content.base64||"");kind=content.mediaKind||(/^data:video\//i.test(data)||mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name)?"video":"image");}catch(_){kind="image";}}if(kind===cfg.virtualMediaKind)filtered.push(item);}list=filtered;}
      if (list.length === 0) { itemSelect.appendChild(el("option", { value: "", text: "Nenhum item salvo" })); return; }
      list.forEach(function (it) { itemSelect.appendChild(el("option", { value: it.id, text: it.fileName || it.name || it.id })); });
    }
    sendTypeSelect.addEventListener("change", refreshItemOptions);
    Promise.all([refreshCrmOptions(), refreshItemOptions()]).then(paintLogicPreview);
    timingRow.style.display = "flex";

    var _filterText = "", _filterState = "all";
    var _cachedRules = [], _cachedQueue = [], _listLoaded = false, _listLoadSeq = 0, _listLoadingTimer = 0;
    searchInput.addEventListener("input", function () { _filterText = searchInput.value.toLowerCase(); paintList(); });
    filterSelect.addEventListener("change", function () { _filterState = filterSelect.value; paintList(); });

    function paintList() {
      var rules = _cachedRules, queue = _cachedQueue;
      rulesCount.textContent = rules.length + (rules.length === 1 ? " regra" : " regras");
      var activeCount=rules.filter(function(r){return !!r.active;}).length;
      var pendingCount=(queue||[]).filter(function(q){return q.status==="pending"||q.status==="waiting";}).length;
      var sentCount=(queue||[]).filter(function(q){return q.status==="sent"||q.status==="done"||q.status==="processed";}).length;
      var followErrorCount=(queue||[]).filter(function(q){return q.status==="error"||q.status==="failed";}).length;
      [["active",activeCount],["pending",pendingCount],["sent",sentCount],["errors",followErrorCount]].forEach(function(pair){var n=monitorKpis.querySelector('[data-follow-kpi="'+pair[0]+'"] strong');if(n)n.textContent=String(pair[1]);});

      var filtered = rules.filter(function (r) {
        if (_filterState === "active" && !r.active) return false;
        if (_filterState === "inactive" && r.active) return false;
        if (_filterText && (r.nome || "").toLowerCase().indexOf(_filterText) === -1) return false;
        return true;
      });

      if (rules.length === 0) {
        listEl.innerHTML = "";
        listEl.appendChild(el("div", { class: "extuiFollowUpEmptyState" }, [
          icon("clock"),
          el("div", { class: "title", text: "Nenhuma regra criada" }),
          el("div", { class: "desc", text: "Crie sua primeira regra ao lado para iniciar o monitoramento automático do CRM." })
        ]));
        return;
      }
      if (filtered.length === 0) {
        listEl.innerHTML = "";
        listEl.appendChild(el("div", { class: "extuiFollowUpEmptyState" }, [icon("search"), el("div", { class: "title", text: "Nenhuma regra encontrada" }), el("div", { class: "desc", text: "Ajuste a busca ou o filtro." })]));
        return;
      }

      listEl.innerHTML = "";
      filtered.forEach(function (rule) {
        var crm = _crmList.find(function (c) { return c.id === rule.source.crmId; });
        var column = crm && crm.columns && crm.columns.find(function (c) { return c.id === rule.source.columnId; });
        var ruleQueue = queue.filter(function (q) { return q.followUpId === rule.id; });
        var pendingCount = ruleQueue.filter(function (q) { return q.status === "pending"; }).length;
        var sentCount = ruleQueue.filter(function (q) { return q.status === "sent"; }).length;

        var row = el("div", { class: "extuiFollowUpRow" });
        row.appendChild(icon((ITEM_STORES[rule.sendType] && ITEM_STORES[rule.sendType].icon) || "clock"));
        var mid = el("div", { class: "extuiFollowUpRowMid" });
        mid.appendChild(el("div", { class: "name", text: rule.nome }));
        mid.appendChild(el("div", { class: "meta", text: (crm && crm.name || "CRM indisponível") + " → " + (column && column.title || "Lista indisponível") + " · " + (rule.acionamento.type === "onEnter" ? "na entrada" : "após " + fmtTiming(rule.acionamento.timing)) }));
        mid.appendChild(el("div", { class: "meta", text: pendingCount + " aguardando · " + sentCount + " enviado(s)" }));
        row.appendChild(mid);

        var switchLabel = el("label", { class: "extuiSwitch" });
        var switchInput = el("input", { type: "checkbox" });
        switchInput.checked = !!rule.active;
        switchLabel.appendChild(switchInput);
        switchLabel.appendChild(el("span", { class: "track" }));
        switchInput.addEventListener("change", async function () {
          var next = switchInput.checked;
          try {
            var freshRules = await loadRules();
            var target = freshRules.find(function (r) { return r.id === rule.id; });
            if (target) target.active = next;
            await saveRules(freshRules);
            rule.active = next;
            toast(next ? "Regra ativada!" : "Regra desativada.");
          } catch (err) { switchInput.checked = !next; toast("Falha ao salvar.", true); }
        });
        row.appendChild(switchLabel);

        var delBtn = el("button", { type: "button", class: "extui-btn extui-btn--danger", text: "Excluir" });
        delBtn.addEventListener("click", async function () {
          var deleteAction=window.__extTrashConfirm?await window.__extTrashConfirm({title:"Excluir regra de FollowUp?",message:'A regra "'+rule.nome+'" pode ser enviada para a Lixeira. A fila de contatos aguardando dela será removida.'}):(await window.extConfirm('Excluir a regra "' + rule.nome + '"? A fila de contatos aguardando dela também é removida.', { danger: true })?"permanent":null);if(!deleteAction)return;
          try {
            if(deleteAction==="trash"&&window.__extTrashService)await window.__extTrashService.add({type:"followup",label:rule.nome||"FollowUp",payload:{item:rule}});
            var freshRules = (await loadRules()).filter(function (r) { return r.id !== rule.id; });
            await saveRules(freshRules);
            var freshQueue = (await loadQueue()).filter(function (q) { return q.followUpId !== rule.id; });
            await saveQueue(freshQueue);
            toast("Regra excluída.");
            refreshList(false);
          } catch (err) { toast("Falha ao excluir.", true); }
        });
        row.appendChild(delBtn);
        listEl.appendChild(row);
      });
    }
    async function refreshList(showDelayedLoader) {
      var seq = ++_listLoadSeq;
      clearTimeout(_listLoadingTimer);
      if (showDelayedLoader && !_listLoaded) {
        _listLoadingTimer = setTimeout(function () {
          if (seq !== _listLoadSeq || _listLoaded || !listEl.isConnected) return;
          listEl.innerHTML = '<div class="extuiFollowUpEmpty" role="status">Carregando regras...</div>';
        }, 450);
      }
      try {
        var values = await Promise.all([loadRules(), loadQueue()]);
        if (seq !== _listLoadSeq || !listEl.isConnected) return;
        clearTimeout(_listLoadingTimer);
        _cachedRules = values[0] || [];
        _cachedQueue = values[1] || [];
        _listLoaded = true;
        paintList();
      } catch (err) {
        if (seq !== _listLoadSeq || !listEl.isConnected) return;
        clearTimeout(_listLoadingTimer);
        listEl.innerHTML = '<div class="extuiFollowUpEmpty" role="alert">Erro ao carregar regras.</div>';
        rulesCount.textContent = "Erro";
      }
    }
    refreshList(true);
                                                                                
                                                                              
                                                                                      
    followUpActiveStorageHandler = function (key) {
      var shell = window.__extDashboardShell;
      if (!listEl.isConnected || !shell || typeof shell.getCurrentSection !== "function" || shell.getCurrentSection() !== "followup") return;
      if (key === CRM_KEY) {
        refreshCrmOptions().then(paintList).catch(function () { paintList(); });
        return;
      }
      if (key === FOLLOWUP_KEY || key === FOLLOWUP_QUEUE_KEY) refreshList(false);
    };

    createBtn.addEventListener("click", async function () {
      var nome = nameInput.value.trim();
      if (!nome) { toast("Dê um nome pra regra.", true); return; }
      if (!crmSelect.value || !columnSelect.value) { toast("Escolha o CRM e a coluna.", true); return; }
      if (!itemSelect.value) { toast("Escolha o que enviar.", true); return; }
      createBtn.disabled = true;
      try {
        var rules = await loadRules();
        rules.push({
          id: uid(),
          nome: nome,
          active: true,
          source: { crmId: crmSelect.value, columnId: columnSelect.value },
          acionamento: { type: triggerSelect.value, timing: { days: parseInt(daysInput.value, 10) || 0, hours: parseInt(hoursInput.value, 10) || 0, minutes: parseInt(minutesInput.value, 10) || 0 } },
          sendType: sendTypeSelect.value,
          itemId: itemSelect.value,
          cancelOnReply: cancelCheckbox.checked
        });
        await saveRules(rules);
        nameInput.value = "";
        refreshList(false);
        toast("Regra criada!");
      } catch (err) {
        toast("Falha ao criar regra.", true);
      } finally { createBtn.disabled = false; }
    });
  }

  window.__extDashboardShell.registerSection("followup", renderFollowUp);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
