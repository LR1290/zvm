;(function(root){
  'use strict';
  var core=root.ExtensionCore=root.ExtensionCore||{};
  var owner=core.DevFeatureOverrides;
  var availability=core.FeatureAvailability;
  var readyPromise=null;

  function authorized(){return !!(owner&&typeof owner.isAuthorizedDev==='function'&&owner.isAuthorizedDev());}
  function statuses(){
    if(!availability||typeof availability.list!=='function')return Object.freeze([]);
    return Object.freeze(availability.list().map(function(entry){
      var explained=typeof availability.explain==='function'?availability.explain(entry.id):null;
      return Object.freeze({id:entry.id,canonicalState:entry.state,effectiveState:explained&&explained.effectiveState||entry.state,override:explained&&explained.override||null,owner:entry.owner||'',since:entry.since||'',reason:entry.reason||''});
    }));
  }
  function removeConsoleApi(){try{if(Object.prototype.hasOwnProperty.call(root,'ZVMDev'))delete root.ZVMDev;}catch(_){} }
  function exposeConsoleApi(){
    if(!authorized()){removeConsoleApi();return false;}
    var features=Object.freeze({
      list:function(){return statuses();},
      enable:function(featureId){return owner.setActive(String(featureId||'')).then(function(){refreshBadge();return statuses();});},
      disableOverride:function(featureId){return owner.clear(String(featureId||'')).then(function(){refreshBadge();return statuses();});},
      reset:function(){return owner.reset().then(function(){refreshBadge();return statuses();});}
    });
    var api=Object.freeze({features:features});
    try{Object.defineProperty(root,'ZVMDev',{value:api,configurable:true,enumerable:false,writable:false});}catch(_){root.ZVMDev=api;}
    return true;
  }
  function badgeId(){return 'extuiDevFeatureOverrideBadge';}
  function refreshBadge(){
    var existing=root.document&&root.document.getElementById?root.document.getElementById(badgeId()):null;
    if(!authorized()){
      if(existing&&typeof existing.remove==='function')existing.remove();
      return 0;
    }
    var count=owner&&typeof owner.list==='function'?Object.keys(owner.list()).length:0;
    if(!count){if(existing&&typeof existing.remove==='function')existing.remove();return 0;}
    if(!existing&&root.document&&root.document.createElement&&root.document.body){existing=root.document.createElement('button');existing.type='button';existing.id=badgeId();existing.className='extuiDevOverrideBadge';existing.setAttribute('aria-label','Overrides temporários de desenvolvimento ativos');existing.addEventListener('click',function(){try{root.__extDashboardShell&&root.__extDashboardShell.showSection('ajustes',{force:true});}catch(_){}});root.document.body.appendChild(existing);}
    if(existing)existing.textContent='DEV · '+count+' override'+(count===1?'':'s')+' ativo'+(count===1?'':'s');
    return count;
  }
  function ready(){
    if(readyPromise)return readyPromise;
    readyPromise=Promise.resolve(owner&&typeof owner.ready==='function'?owner.ready():false).then(function(){
      if(!authorized()){removeConsoleApi();refreshBadge();return false;}
      exposeConsoleApi();refreshBadge();return true;
    },function(){removeConsoleApi();refreshBadge();return false;});
    return readyPromise;
  }
  function text(value){return String(value==null?'':value);}
  async function mount(host){
    if(!host||!await ready())return false;
    host.replaceChildren();
    var intro=root.document.createElement('div');intro.className='extuiCard extuiDevFeatureOverrideCard';
    var title=root.document.createElement('h3');title.textContent='Disponibilidade de recursos — DEV';
    var desc=root.document.createElement('p');desc.textContent='Ative temporariamente recursos dormentes somente nesta build DEV. Isso não altera BETA/RELEASE, licenças, capabilities, integridade ou Build Authority.';
    intro.appendChild(title);intro.appendChild(desc);
    var list=root.document.createElement('div');list.className='extuiDevFeatureOverrideList';intro.appendChild(list);
    function renderRows(){
      list.replaceChildren();
      statuses().forEach(function(row){
        var line=root.document.createElement('div');line.className='extuiDevFeatureOverrideRow';
        var copy=root.document.createElement('div');copy.className='extuiDevFeatureOverrideCopy';
        var strong=root.document.createElement('strong');strong.textContent=row.id;
        var meta=root.document.createElement('span');meta.textContent='Oficial: '+row.canonicalState+' · Efetivo: '+row.effectiveState;
        var reason=root.document.createElement('small');reason.textContent=text(row.reason);
        copy.appendChild(strong);copy.appendChild(meta);copy.appendChild(reason);
        var toggle=root.document.createElement('button');toggle.type='button';toggle.className='extuiShellMenuSwitch';toggle.setAttribute('role','switch');toggle.setAttribute('aria-label','Override DEV para '+row.id);toggle.setAttribute('aria-checked',String(row.override==='active'));
        toggle.addEventListener('click',async function(){toggle.disabled=true;try{if(row.override==='active')await owner.clear(row.id);else await owner.setActive(row.id);renderRows();refreshBadge();}finally{toggle.disabled=false;}});
        line.appendChild(copy);line.appendChild(toggle);list.appendChild(line);
      });
    }
    renderRows();
    var actions=root.document.createElement('div');actions.className='extuiDevFeatureOverrideActions';
    var reset=root.document.createElement('button');reset.type='button';reset.className='extui-btn extui-btn--ghost';reset.textContent='Restaurar política oficial';reset.addEventListener('click',async function(){reset.disabled=true;try{await owner.reset();renderRows();refreshBadge();}finally{reset.disabled=false;}});
    actions.appendChild(reset);intro.appendChild(actions);host.appendChild(intro);return true;
  }
  var api=Object.freeze({ready:ready,isAvailable:function(){return authorized();},mount:mount,refreshBadge:refreshBadge,statuses:statuses});
  core.DevFeatureOverridesUI=api;
  ready();
})(typeof window!=='undefined'?window:globalThis);
