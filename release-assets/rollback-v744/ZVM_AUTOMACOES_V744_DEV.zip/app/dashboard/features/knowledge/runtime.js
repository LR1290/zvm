;
try{
(function (root) {
  "use strict";
  if (root.__extKnowledgePdf) return;
  var modulePromise = null;

  function loadPdfJs() {
    if (!modulePromise) {
      var moduleUrl = root.chrome.runtime.getURL("vendor/pdfjs/pdf.min.mjs");
      modulePromise = import(moduleUrl).then(function (pdfjs) {
        pdfjs.GlobalWorkerOptions.workerSrc = root.chrome.runtime.getURL("vendor/pdfjs/pdf.worker.min.mjs");
        return pdfjs;
      }).catch(function (error) {
        modulePromise = null;
        throw error;
      });
    }
    return modulePromise;
  }
  function pageText(items) {
    var lines = []; var current = ""; var previousY = null;
    (Array.isArray(items) ? items : []).forEach(function (item) {
      if (!item || typeof item.str !== "string") return;
      var value = item.str.trim(); var y = item.transform && Number(item.transform[5]);
      if (previousY != null && Number.isFinite(y) && Math.abs(y - previousY) > 4 && current.trim()) { lines.push(current.trim()); current = ""; }
      if (value) current += (current ? " " : "") + value;
      if (item.hasEOL && current.trim()) { lines.push(current.trim()); current = ""; }
      if (Number.isFinite(y)) previousY = y;
    });
    if (current.trim()) lines.push(current.trim());
    return lines.join("\n");
  }
  async function extract(arrayBuffer, onProgress, injectedPdfJs) {
    var pdfjs = injectedPdfJs || await loadPdfJs();
    var bytes = new Uint8Array(arrayBuffer);
    var loadingTask = pdfjs.getDocument({ data: bytes, useWorkerFetch: false, isEvalSupported: false, enableScripting: false, disableFontFace: true, verbosity: 0 });
    var document = await loadingTask.promise; var pages = [];
    try {
      for (var pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
        var page = await document.getPage(pageNumber); var content = await page.getTextContent();
        var text = pageText(content && content.items);
        if (text.trim()) pages.push({ pageNumber: pageNumber, text: text });
        if (typeof onProgress === "function") onProgress(pageNumber, document.numPages);
        if (page && typeof page.cleanup === "function") page.cleanup();
      }
    } finally { if (typeof document.destroy === "function") await document.destroy(); }
    return pages;
  }
  var api = Object.freeze({ extract: extract, pageText: pageText });
  root.__extKnowledgePdf = api;
})(typeof window !== "undefined" ? window : globalThis);
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
;
try{
(function () {
  "use strict";
  if (window.__extKnowledgeModuleBooted) return;
  window.__extKnowledgeModuleBooted = true;

  var core = window.__extKnowledgeCore;
  var integrationCore = window.__extIntegrationCore;
                                                                            
                                                                           
                                                                           
                                                                        
                    
  var assistantsCore = window.__extAiAssistantsCore;
  var agentsCore = window.__extAiAgentsCore;
  var rootEl = null;
  var snapshot = null;
  var activeBaseId = null;
  var activeLayer = null;
  var activeIndexJob = null;
  var renderGeneration = 0;
                                                                      
                                                                    
  var documentQuery = "";
  var documentKindFilter = "all";

  function el(tag, attrs, children) {
    var node = document.createElement(tag); attrs = attrs || {};
    Object.keys(attrs).forEach(function (key) {
      if (key === "class") node.className = attrs[key];
      else if (key === "text") node.textContent = attrs[key];
      else if (key.slice(0, 2) === "on" && typeof attrs[key] === "function") node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
      else if (attrs[key] !== false && attrs[key] != null) node.setAttribute(key, attrs[key] === true ? "" : attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(child); }); return node;
  }
  function icon(path) { var span = el("span", { class: "extuikIcon", "aria-hidden": "true" }); span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + path + '</svg>'; return span; }
  var ICONS = {
    database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
    edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/>', trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6"/>',
    refresh: '<path d="M20 11a8.1 8.1 0 0 0-15.5-2M4 4v5h5M4 13a8.1 8.1 0 0 0 15.5 2M20 20v-5h-5"/>', back: '<path d="m15 18-6-6 6-6"/>'
  };
  function send(type, payload) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (response) {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response || response.ok !== true) { var error = new Error(response && response.userMessage || "Não foi possível concluir a operação."); error.code = response && response.errorCode; reject(error); return; }
        resolve(response.result);
      });
    });
  }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function closeLayer() { if (!activeLayer) return; document.removeEventListener("keydown", activeLayer.keyHandler, true); var previous = activeLayer.previous; activeLayer.node.remove(); activeLayer = null; if (previous && previous.isConnected) previous.focus(); }
  function modal(title, subtitle) {
    closeLayer(); var previous = document.activeElement;
    var layer = el("div", { class: "extuikLayer" }); var backdrop = el("button", { type: "button", class: "extuikBackdrop", "aria-label": "Fechar" });
    var dialog = el("section", { class: "extuikDialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "extuikDialogTitle", tabindex: "-1" });
    var close = el("button", { type: "button", class: "extuikClose", "aria-label": "Fechar", text: "×" });
    dialog.appendChild(el("header", { class: "extuikDialogHeader" }, [el("div", {}, [el("h2", { id: "extuikDialogTitle", text: title }), subtitle ? el("p", { text: subtitle }) : null]), close]));
    layer.appendChild(backdrop); layer.appendChild(dialog); document.body.appendChild(layer);
    function dismiss() { closeLayer(); } backdrop.addEventListener("click", dismiss); close.addEventListener("click", dismiss);
    var keyHandler = function (event) {
      if (event.key === "Escape") { event.preventDefault(); dismiss(); return; }
      if (event.key !== "Tab") return; var items = dialog.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])');
      if (!items.length) return; var first = items[0], last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", keyHandler, true); activeLayer = { node: layer, previous: previous, keyHandler: keyHandler }; dialog.focus(); return dialog;
  }
  function field(label, control, help) { var wrap = el("label", { class: "extuikField" }, [el("span", { text: label }), control]); if (help) wrap.appendChild(el("small", { text: help })); return wrap; }
  function providerLabel(id) { var provider = integrationCore.providerById(id); return provider ? provider.label : id; }
  function statusLabel(status) { return ({ empty: "Vazia", preparing: "Preparando", indexing: "Indexando", ready: "Pronta", attention: "Requer atenção", error: "Erro" })[status] || "Vazia"; }
  function dateLabel(value) { return value ? new Date(value).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "Nunca"; }
  function sizeLabel(value) { var bytes = Number(value) || 0; return bytes < 1024 ? bytes + " B" : bytes < 1048576 ? (bytes / 1024).toFixed(1) + " KB" : (bytes / 1048576).toFixed(1) + " MB"; }
  function currentBase() { return snapshot && snapshot.knowledge.bases.find(function (base) { return base.id === activeBaseId; }) || null; }
  function isActiveRoute() { return !!(rootEl && rootEl.isConnected && window.__extDashboardShell && window.__extDashboardShell.getCurrentSection() === "knowledge"); }
  function storageGet(key) { return window.__extDashboardShell.storageGet(key).then(function (result) { return result && result[key]; }); }
  async function loadSnapshot() {
    var values = await Promise.all([send("EXTUI_KNOWLEDGE_GET_STATE"), send("EXTUI_INTEGRATION_GET_STATE"), storageGet(assistantsCore.STORE_KEY), storageGet(agentsCore.STORE_KEY)]);
    var agentsList = agentsCore.normalizeStore(values[3]).agents;
    return {
      knowledge: core.normalizeStore(values[0]), integrations: values[1],
      hasAssistants: assistantsCore.normalizeStore(values[2]).assistants.length > 0,
      hasAgents: agentsList.length > 0,
      agents: agentsList
    };
  }
  async function refresh() { var next = await loadSnapshot(); if (!isActiveRoute()) return; snapshot = next; render(); }
  function openIntegration(providerId) {
    closeLayer(); window.__extDashboardShell.showSection("ai-connect").then(function () {
      if (window.__extIntegrations && typeof window.__extIntegrations.openProvider === "function") window.__extIntegrations.openProvider(providerId, { onChange: async function () { if (window.__extIntegrations && window.__extIntegrations.refreshAiConnections) await window.__extIntegrations.refreshAiConnections(document.getElementById("extappContentArea")); } });
    });
  }
  function providerConfigured(providerId) {
    var metadata = snapshot.integrations.providers && snapshot.integrations.providers[providerId];
    return !!(metadata && metadata.configured && metadata.enabled && metadata.status === integrationCore.STATUSES.CONNECTED);
  }

                                                                
                                                                   
                                                                    
                                             
  function agentAclField(currentAllowedAgentIds, allAgents) {
    var wrap = el("div", { class: "extuiaAgentAcl" });
    if (!allAgents.length) {
      wrap.appendChild(el("p", { class: "extuiaAgentAclEmpty", text: "Crie um Agente IA antes de restringir quem pode usar esta base - sem nenhum Agente, a restrição não teria efeito." }));
      var cta = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Criar Agente IA ↗" });
      cta.addEventListener("click", function () { window.__extDashboardShell.showSection("ai-agents").then(function () { if (window.__extAiAgents) window.__extAiAgents.openAgent(null); }); });
      wrap.appendChild(cta);
      return { el: wrap, getValue: function () { return null; } };
    }
    var restricted = Array.isArray(currentAllowedAgentIds);
    var selected = {}; (currentAllowedAgentIds || []).forEach(function (id) { selected[id] = true; });
    var groupName = "extuikAcl" + Math.random().toString(36).slice(2, 8);
    var allRadio = el("input", { type: "radio", name: groupName }); allRadio.checked = !restricted;
    var restrictedRadio = el("input", { type: "radio", name: groupName }); restrictedRadio.checked = restricted;
    var modeRow = el("div", { class: "extuiaAgentAclMode", role: "radiogroup", "aria-label": "Quem pode usar" }, [
      el("label", {}, [allRadio, el("span", { text: "Permitir todos os Agentes" })]),
      el("label", {}, [restrictedRadio, el("span", { text: "Restringir a Agentes específicos" })])
    ]);
    var search = el("input", { type: "search", placeholder: "Buscar agente...", "aria-label": "Buscar agente" });
    var toolbar = el("div", { class: "extuiaAgentAclToolbar" }, [search]);
    var selectAllBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extui-btn--sm", text: "Selecionar todos" });
    var clearBtn = el("button", { type: "button", class: "extui-btn extui-btn--ghost extui-btn--sm", text: "Limpar seleção" });
    toolbar.appendChild(selectAllBtn); toolbar.appendChild(clearBtn);
    var list = el("div", { class: "extuiaAgentAclList", role: "group", "aria-label": "Agentes permitidos" });
    var checkboxes = allAgents.map(function (agent) {
      var checkbox = el("input", { type: "checkbox" }); checkbox.checked = !!selected[agent.id];
      var row = el("label", { class: "extuiaAgentAclRow" }, [checkbox, el("span", { text: agent.name || "(sem nome)" })]);
      list.appendChild(row);
      return { agent: agent, checkbox: checkbox, row: row };
    });
    var restrictedBlock = el("div", { class: "extuiaAgentAclRestricted" }, [toolbar, list]);
    function syncVisibility() { restrictedBlock.hidden = !restrictedRadio.checked; }
    allRadio.addEventListener("change", syncVisibility); restrictedRadio.addEventListener("change", syncVisibility); syncVisibility();
    search.addEventListener("input", function () {
      var query = search.value.trim().toLowerCase();
      checkboxes.forEach(function (entry) { entry.row.hidden = query.length > 0 && (entry.agent.name || "").toLowerCase().indexOf(query) === -1; });
    });
    selectAllBtn.addEventListener("click", function () { checkboxes.forEach(function (entry) { if (!entry.row.hidden) entry.checkbox.checked = true; }); });
    clearBtn.addEventListener("click", function () { checkboxes.forEach(function (entry) { entry.checkbox.checked = false; }); });
    wrap.appendChild(modeRow); wrap.appendChild(restrictedBlock);
    return {
      el: wrap,
      getValue: function () {
        if (!restrictedRadio.checked) return null;
        return checkboxes.filter(function (entry) { return entry.checkbox.checked; }).map(function (entry) { return entry.agent.id; });
      }
    };
  }

  function openBaseForm(base) {
    var dialog = modal(base ? "Editar base" : "Nova Base de Conhecimento", "O serviço usado para gerar respostas e o serviço usado para preparar a busca podem ser escolhidos separadamente.");
    var form = el("form", { class: "extuikForm" }); var name = el("input", { type: "text", maxlength: "100", required: true, autocomplete: "off" }); name.value = base && base.name || "";
    var description = el("textarea", { rows: "3", maxlength: "300", placeholder: "Ex.: catálogo de produtos e políticas comerciais" }); description.value = base && base.description || "";
    var provider = el("select", { required: true }); integrationCore.EMBEDDING_PROVIDER_IDS.forEach(function (id) { provider.appendChild(el("option", { value: id, text: providerLabel(id) })); }); provider.value = base && base.embeddingProviderId || "openai";
    var model = el("select", { required: true }); var providerState = el("div", { class: "extuikProviderState", role: "status" });
    async function updateModels() {
      var providerId = provider.value; var defaultId = core.DEFAULT_EMBEDDING_MODELS[providerId]; var models = [{ id: defaultId, label: defaultId }];
      model.innerHTML = ""; models.forEach(function (entry) { model.appendChild(el("option", { value: entry.id, text: entry.label })); });
      if (base && base.embeddingProviderId === providerId && base.embeddingModel && base.embeddingModel !== defaultId) model.appendChild(el("option", { value: base.embeddingModel, text: base.embeddingModel }));
      model.value = base && base.embeddingProviderId === providerId ? base.embeddingModel : defaultId;
      providerState.innerHTML = "";
      if (!providerConfigured(providerId)) {
        providerState.className = "extuikProviderState is-attention"; providerState.appendChild(el("span", { text: "Configure " + providerLabel(providerId) + " antes de preparar a busca desta base." }));
        var configure = el("button", { type: "button", class: "extui-btn extui-btn--secondary", text: "Configurar " + providerLabel(providerId) }); configure.addEventListener("click", function () { openIntegration(providerId); }); providerState.appendChild(configure); return;
      }
      providerState.className = "extuikProviderState is-ready"; providerState.textContent = providerLabel(providerId) + " conectado.";
      try {
        var result = await send("EXTUI_INTEGRATION_LIST_EMBEDDING_MODELS", { provider: providerId }); var discovered = result && Array.isArray(result.models) ? result.models : [];
        discovered.forEach(function (entry) { if (!Array.from(model.options).some(function (option) { return option.value === entry.id; })) model.appendChild(el("option", { value: entry.id, text: entry.label || entry.id })); });
        if (base && base.embeddingProviderId === providerId && Array.from(model.options).some(function (option) { return option.value === base.embeddingModel; })) model.value = base.embeddingModel;
      } catch (error) { if (window.__extReportRuntimeError) window.__extReportRuntimeError("KNOWLEDGE_MODEL_DISCOVERY_FAILED", error); }
    }
    provider.addEventListener("change", updateModels);
    form.appendChild(field("Nome", name)); form.appendChild(field("Descrição", description)); form.appendChild(field("Serviço para preparar a busca", provider, "Mostra apenas serviços compatíveis com busca inteligente.")); form.appendChild(field("Modelo para busca inteligente", model, "Ao trocar o serviço ou o modelo, a base precisa ser preparada novamente.")); form.appendChild(providerState);
    form.appendChild(el("div", { class: "extuikPrivacy", role: "note", text: "O conteúdo será enviado ao provedor selecionado para gerar representações de busca. Os vetores resultantes ficam locais." }));
                                                                         
                                                                          
                                                                        
    var baseAcl = agentAclField(base && base.allowedAgentIds, snapshot.agents);
    form.appendChild(el("fieldset", { class: "extuikAclSection" }, [el("legend", { text: "Quem pode usar esta base" }), el("p", { class: "extuikAclHint", text: "Escolha os Agentes IA que poderão consultar esta Base de Conhecimento. Cada Agente também precisa estar com o uso de bases ativado." }), baseAcl.el]));
    var footer = el("footer", { class: "extuikDialogFooter" }); var cancel = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" }); var save = el("button", { type: "submit", class: "extui-btn extui-btn--primary", text: base ? "Salvar alterações" : "Criar base" }); footer.appendChild(cancel); footer.appendChild(save); form.appendChild(footer); dialog.appendChild(form);
    cancel.addEventListener("click", closeLayer); form.addEventListener("submit", async function (event) {
      event.preventDefault(); save.disabled = true;
      try {
        var draft = { name: name.value, description: description.value, embeddingProviderId: provider.value, embeddingModel: model.value };
        var result = base ? await send("EXTUI_KNOWLEDGE_UPDATE_BASE", { baseId: base.id, base: draft }) : await send("EXTUI_KNOWLEDGE_CREATE_BASE", { base: draft });
        var savedBaseId = result && result.base && result.base.id || result && result.id || base && base.id || null;
        if (savedBaseId) await send("EXTUI_KNOWLEDGE_SET_BASE_ACL", { baseId: savedBaseId, allowedAgentIds: baseAcl.getValue() });
        closeLayer(); activeBaseId = savedBaseId; toast(base ? "Base atualizada." : "Base criada."); await refresh();
      } catch (error) { toast(error.message, true); save.disabled = false; }
    });
    updateModels(); name.focus();
  }

  function openManualForm(base, document) {
    var dialog = modal(document ? "Editar texto manual" : "Adicionar texto manual", "Use para FAQs, políticas, catálogos pequenos e instruções internas.");
    var form = el("form", { class: "extuikForm" }); var title = el("input", { type: "text", maxlength: "180", required: true, autocomplete: "off" }); title.value = document && document.title || "";
    var content = el("textarea", { rows: "14", required: true, placeholder: "Digite o conteúdo que poderá ser consultado pelos Assistentes." }); content.value = document && document.text || "";
    form.appendChild(field("Título", title)); form.appendChild(field("Conteúdo", content, "Texto puro: nenhum HTML ou Markdown é executado."));
    var footer = el("footer", { class: "extuikDialogFooter" }); var cancel = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Cancelar" }); var save = el("button", { type: "submit", class: "extui-btn extui-btn--primary", text: document ? "Salvar texto" : "Adicionar fonte" }); footer.appendChild(cancel); footer.appendChild(save); form.appendChild(footer); dialog.appendChild(form);
    cancel.addEventListener("click", closeLayer); form.addEventListener("submit", async function (event) {
      event.preventDefault(); save.disabled = true;
      try { await send("EXTUI_KNOWLEDGE_SAVE_DOCUMENT", { baseId: base.id, document: { id: document && document.id, title: title.value, kind: "manual", text: content.value, sizeBytes: new Blob([content.value]).size } }); closeLayer(); toast("Fonte salva. Atualize a busca da base para aplicar as alterações."); await refresh(); }
      catch (error) { toast(error.message, true); save.disabled = false; }
    }); title.focus();
  }
  async function importFile(base, file, status) {
    if (!file) return;
    if (file.size > core.LIMITS.MAX_FILE_BYTES) { toast("O arquivo excede o limite de 5 MB.", true); return; }
    var extension = String(file.name || "").split(".").pop().toLowerCase();
    if (["txt", "md", "pdf"].indexOf(extension) < 0) { toast("Use um arquivo TXT, Markdown ou PDF.", true); return; }
    status.hidden = false; status.textContent = "Lendo " + file.name + "…";
    try {
      var document = { title: file.name, kind: extension === "pdf" ? "pdf" : extension, sizeBytes: file.size };
      if (extension === "pdf") {
        var buffer = await file.arrayBuffer();
        document.pages = await window.__extKnowledgePdf.extract(buffer, function (current, total) { status.textContent = "Extraindo PDF · página " + current + " de " + total; });
        if (!document.pages.length) { var noText = new Error("Este PDF não contém texto legível."); noText.code = core.ERRORS.PDF_NO_TEXT; throw noText; }
      } else document.text = core.normalizeText(await file.text());
      status.textContent = "Salvando fonte local…"; await send("EXTUI_KNOWLEDGE_SAVE_DOCUMENT", { baseId: base.id, document: document });
      toast("Fonte adicionada. Atualize a busca da base para aplicar as alterações."); await refresh();
    } catch (error) { toast(error.message || "Não foi possível importar o arquivo.", true); }
    finally { status.hidden = true; }
  }
  async function removeDocument(base, document) {
    if (!await window.extConfirm("Remover “" + document.title + "”?\n\nA busca atual continuará funcionando até a próxima atualização.", { danger: true, okLabel: "Remover fonte" })) return;
    try { await send("EXTUI_KNOWLEDGE_REMOVE_DOCUMENT", { baseId: base.id, documentId: document.id }); toast("Fonte removida. Atualize a busca da base."); await refresh(); }
    catch (error) { toast(error.message, true); }
  }
  async function startIndex(base) {
    if (!providerConfigured(base.embeddingProviderId)) { openIntegration(base.embeddingProviderId); return; }
    var preview;
    try { preview = await send("EXTUI_KNOWLEDGE_INDEX_PREVIEW", { baseId: base.id }); }
    catch (error) { toast(error.message, true); return; }
    if (!preview.chunkCount) { toast("Adicione ao menos uma fonte com texto antes de preparar a busca.", true); return; }
    if (!await window.extConfirm("Preparar busca de “" + base.name + "” agora?\n\n" + preview.chunkCount + " trechos serão enviados em pequenos grupos ao " + providerLabel(base.embeddingProviderId) + ". A preparação da busca usa o serviço configurado e pode gerar consumo na sua conta.", { okLabel: "Preparar busca" })) return;
    var jobId = core.createUuid(window.crypto); activeBaseId = base.id; activeIndexJob = { baseId: base.id, jobId: jobId }; render();
    try { await send("EXTUI_KNOWLEDGE_INDEX_START", { baseId: base.id, jobId: jobId }); toast("Busca preparada com sucesso."); }
    catch (error) { if (error.code !== core.ERRORS.CANCELLED) toast(error.message, true); }
    finally { activeIndexJob = null; await refresh(); }
  }
  async function deleteBase(base) {
    try {
      var count = (await send("EXTUI_KNOWLEDGE_REFERENCE_COUNT", { baseId: base.id })).count || 0;
      var detail = count ? "Esta base é utilizada por " + count + " Assistente" + (count === 1 ? "" : "s") + ". Eles permanecerão salvos e passarão a exigir atenção." : "Nenhum Assistente usa esta base.";
      if (!await window.extConfirm("Excluir “" + base.name + "”?\n\n" + detail + "\n\nDocumentos, trechos preparados e histórico local serão apagados.", { danger: true, okLabel: "Excluir base" })) return;
      await send("EXTUI_KNOWLEDGE_DELETE_BASE", { baseId: base.id }); activeBaseId = null; toast("Base excluída."); await refresh();
    } catch (error) { toast(error.message, true); }
  }

                                                                        
                                                                          
                                                                          
                                                                       
                                                                        
                                                                      
  function aiHubNav(activeKey) {
    var items = [{ key: "ai-connect", label: "Conexões & Recursos" }, { key: "ai-assistants", label: "Perfis IA" }, { key: "ai-agents", label: "Agentes IA" }, { key: "ai-memory", label: "Memória IA" }, { key: "knowledge", label: "Base de Conhecimento" }];
    var nav = el("nav", { class: "extuiAiHubNav", "aria-label": "Navegação do Hub de IA" });
    items.forEach(function (item) {
      var btn = el("button", { type: "button", class: "extuiAiHubNavItem" + (item.key === activeKey ? " extuiActive" : ""), text: item.label });
      if (item.key === activeKey) btn.setAttribute("aria-current", "page");
      else btn.addEventListener("click", function () { window.__extDashboardShell.showSection(item.key); });
      nav.appendChild(btn);
    });
    return nav;
  }
  function hasConnectedProvider() { return integrationCore.PROVIDER_IDS.some(function (id) { var item = snapshot.integrations && snapshot.integrations.providers && snapshot.integrations.providers[id]; return !!(item && item.configured && item.enabled && item.status === integrationCore.STATUSES.CONNECTED); }); }
  function aiSetupPath(activeKey, hasAssistants, hasAgents) {
    var hasConnection = hasConnectedProvider();
    var path = el("div", { class: "extuiAiSetupPath", role: "group", "aria-label": "Ordem recomendada de configuração" });
    var steps = [
      { n: 1, key: "ai-connect", title: "Conexão IA", desc: "Conecte um serviço", status: hasConnection ? "Concluído" : "Pendente" },
      { n: 2, key: "ai-assistants", title: "Perfis IA", desc: "Defina o comportamento", status: hasAssistants ? "Concluído" : "Pendente" },
      { n: 3, key: "ai-agents", title: "Agentes IA", desc: "Use um perfil", status: hasAgents ? "Configurado" : "Pendente" },
      { n: 4, key: "ai-memory", title: "Memória IA", desc: "Enriqueça o contexto", status: "Opcional" },
      { n: 5, key: "knowledge", title: "Conhecimento", desc: "Ensine fatos específicos", status: "Opcional" }
    ];
    steps.forEach(function (step) {
      var stateName = step.key === activeKey ? "current" : ((step.key === "ai-connect" && hasConnection) || (step.key === "ai-assistants" && hasAssistants) || (step.key === "ai-agents" && hasAgents) ? "done" : "pending");
      var btn = el("button", { type: "button", class: "extuiAiSetupStep", "data-state": stateName });
      btn.appendChild(el("div", { class: "extuiAiSetupStepHead" }, [el("span", { class: "extuiAiSetupStepNumber", text: String(step.n) }), el("span", { class: "extuiAiSetupStepTitle", text: step.title })]));
      btn.appendChild(el("span", { class: "extuiAiSetupStepDesc", text: step.desc }));
      btn.appendChild(el("span", { class: "extuiAiSetupStepStatus", text: step.status }));
      if (step.key !== activeKey) btn.addEventListener("click", function () { window.__extDashboardShell.showSection(step.key); });
      path.appendChild(btn);
    });
    return path;
  }
  function actionButton(label, iconName, className, handler) { var button = el("button", { type: "button", class: className || "extui-btn extui-btn--ghost" }, [icon(ICONS[iconName]), el("span", { text: label })]); button.addEventListener("click", handler); return button; }
  function renderList() {
    var page = el("div", { class: "extuiaPage extuikPage" });
    page.appendChild(aiHubNav("knowledge"));
    page.appendChild(aiSetupPath("knowledge", snapshot.hasAssistants, snapshot.hasAgents));
    var header = el("header", { class: "extuikPageHeader", "data-extui-academy-target": "knowledge-header" }, [el("div", {}, [el("span", { class: "extuikEyebrow", text: "AUTOMAÇÃO · CONHECIMENTO" }), el("h1", { text: "Base de Conhecimento" }), el("p", { text: "Ensine seus Assistentes a consultar informações específicas da sua empresa." })])]);
    header.appendChild(actionButton("Nova base", "plus", "extui-btn extui-btn--primary", function () { openBaseForm(null); })); page.appendChild(header);
    if (!snapshot.knowledge.bases.length) {
      var empty = el("section", { class: "extuikEmpty" }, [icon(ICONS.database), el("h2", { text: "Conhecimento reutilizável, sob seu controle" }), el("p", { text: "Adicione texto, TXT, Markdown ou PDF. O Extensão guarda documentos e vetores localmente e envia apenas os trechos recuperados durante a execução." })]);
      empty.appendChild(actionButton("Criar primeira base", "plus", "extui-btn extui-btn--primary", function () { openBaseForm(null); })); page.appendChild(empty); rootEl.appendChild(page); return;
    }
    var grid = el("section", { class: "extuikGrid", "aria-label": "Bases de Conhecimento" });
    snapshot.knowledge.bases.forEach(function (base) {
      var card = el("article", { class: "extuikCard", "data-state": base.status });
      card.appendChild(el("div", { class: "extuikCardTop" }, [el("div", { class: "extuikCardIcon" }, [icon(ICONS.database)]), el("span", { class: "extuikState", text: statusLabel(base.status) })]));
      card.appendChild(el("h2", { text: base.name })); card.appendChild(el("p", { class: base.description ? "" : "is-muted", text: base.description || "Sem descrição" }));
      card.appendChild(el("dl", { class: "extuikStats" }, [el("div", {}, [el("dt", { text: "Documentos" }), el("dd", { text: String(base.documentCount) })]), el("div", {}, [el("dt", { text: "Trechos" }), el("dd", { text: String(base.chunkCount) })]), el("div", {}, [el("dt", { text: "Embeddings" }), el("dd", { text: providerLabel(base.embeddingProviderId) } )]) ]));
      card.appendChild(el("small", { class: "extuikIndexed", text: "Última preparação da busca: " + dateLabel(base.indexedAt) }));
      var actions = el("footer", { class: "extuikCardActions" }); actions.appendChild(actionButton("Abrir", "file", "extui-btn extui-btn--secondary", function () { activeBaseId = base.id; documentQuery = ""; documentKindFilter = "all"; render(); })); actions.appendChild(actionButton("Editar", "edit", "extui-btn extui-btn--ghost", function () { openBaseForm(base); })); actions.appendChild(actionButton("Reindexar", "refresh", "extui-btn extui-btn--ghost", function () { startIndex(base); })); actions.appendChild(actionButton("Excluir", "trash", "extui-btn extui-btn--ghost extuikDanger", function () { deleteBase(base); })); card.appendChild(actions); grid.appendChild(card);
    }); page.appendChild(grid); rootEl.appendChild(page);
  }
  async function renderDetail(base, generation) {
    var page = el("div", { class: "extuiaPage extuikPage" });
    page.appendChild(aiHubNav("knowledge"));
    page.appendChild(aiSetupPath("knowledge", snapshot.hasAssistants, snapshot.hasAgents));
    var back = actionButton("Voltar às bases", "back", "extui-btn extui-btn--ghost", function () { activeBaseId = null; render(); }); page.appendChild(back);
    var header = el("header", { class: "extuikDetailHeader" }, [el("div", {}, [el("span", { class: "extuikEyebrow", text: providerLabel(base.embeddingProviderId) + " · " + base.embeddingModel }), el("h1", { text: base.name }), el("p", { text: base.description || "Organize as fontes usadas pelos Assistentes." })]), el("span", { class: "extuikState", text: statusLabel(base.status) })]); page.appendChild(header);
    var documents;
    try { documents = await send("EXTUI_KNOWLEDGE_LIST_DOCUMENTS", { baseId: base.id }); } catch (error) { page.appendChild(el("div", { class: "extuikError", text: error.message })); rootEl.appendChild(page); return; }
    if (activeBaseId !== base.id || generation !== renderGeneration || !isActiveRoute()) return;
    var toolbar = el("section", { class: "extuikToolbar" }); toolbar.appendChild(actionButton("Texto manual", "plus", "extui-btn extui-btn--secondary", function () { openManualForm(base, null); }));
    var fileInput = el("input", { type: "file", accept: ".txt,.md,.pdf,text/plain,text/markdown,application/pdf", class: "extuikHiddenInput" }); var upload = actionButton("Importar TXT, MD ou PDF", "file", "extui-btn extui-btn--secondary", function () { fileInput.click(); }); toolbar.appendChild(upload); toolbar.appendChild(fileInput);
    var importStatus = el("span", { class: "extuikImportStatus", role: "status", text: "Preparando arquivo…", hidden: true }); toolbar.appendChild(importStatus); fileInput.addEventListener("change", function () { var file = fileInput.files && fileInput.files[0]; fileInput.value = ""; importFile(base, file, importStatus); });
    page.appendChild(toolbar);
    var privacy = el("aside", { class: "extuikPrivacyGrid" }, [el("div", {}, [el("strong", { text: "Preparação da busca" }), el("span", { text: "Os trechos de texto são enviados ao serviço escolhido; os dados preparados para a busca ficam neste navegador." })]), el("div", {}, [el("strong", { text: "Execução" }), el("span", { text: "Somente os trechos mais relevantes vão ao serviço de IA que gera a resposta — nunca a base inteira." })])]); page.appendChild(privacy);
    if (base.pendingChanges) page.appendChild(el("div", { class: "extuikPending", role: "status", text: "Há alterações aguardando atualização da busca. A versão anterior continua funcionando até a nova preparação terminar." }));
    var indexPanel = el("section", { class: "extuikIndexPanel" }, [el("div", {}, [el("h2", { text: "Índice semântico" }), el("p", { text: documents.length + " de " + core.LIMITS.MAX_DOCUMENTS_PER_BASE + " documentos · limite de 1.000.000 caracteres · até 800 trechos" })])]);
    if (activeIndexJob && activeIndexJob.baseId === base.id) {
      var progress = el("div", { class: "extuikProgress", role: "status", id: "extuikIndexProgress" }, [el("span", { class: "extuikSpinner" }), el("span", { text: "Preparando busca…" })]); indexPanel.appendChild(progress);
      indexPanel.appendChild(el("button", { type: "button", class: "extui-btn extui-btn--danger", text: "Cancelar preparo", onclick: function () { send("EXTUI_KNOWLEDGE_INDEX_CANCEL", activeIndexJob).then(function () { toast("Cancelamento solicitado."); }); } }));
    } else indexPanel.appendChild(actionButton(base.activeIndex ? "Atualizar busca" : "Preparar busca", "refresh", "extui-btn extui-btn--primary", function () { startIndex(base); }));
    page.appendChild(indexPanel);
    var section = el("section", { class: "extuikDocuments" }, [el("header", {}, [el("div", {}, [el("h2", { text: "Fontes" }), el("p", { text: "Conteúdo local usado para construir a próxima revisão do índice." })])])]);
                                                                        
                                                                           
                                                                    
    if (documents.length) {
      var docToolbar = el("div", { class: "extuikDocFilterBar" });
                                                                           
                                                                         
                                                                     
                                    
      var searchWrap = el("div", { class: "extuiSearch extuikDocSearch" }, [icon('<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>')]);
      var searchInput = el("input", { type: "search", placeholder: "Buscar fonte pelo título...", "aria-label": "Buscar fonte", value: documentQuery });
      searchInput.addEventListener("input", function () { documentQuery = searchInput.value; renderDocumentRows(); });
      searchWrap.appendChild(searchInput);
      docToolbar.appendChild(searchWrap);
      var kindOptions = [{ value: "all", label: "Todos os tipos" }].concat(
        Array.from(new Set(documents.map(function (d) { return d.kind; }))).sort().map(function (k) { return { value: k, label: k === "manual" ? "Texto manual" : k.toUpperCase() }; })
      );
      var kindSelect = el("select", { class: "extuikDocKindFilter", "aria-label": "Filtrar por tipo" });
      kindOptions.forEach(function (opt) { var o = el("option", { value: opt.value, text: opt.label }); if (opt.value === documentKindFilter) o.selected = true; kindSelect.appendChild(o); });
      kindSelect.addEventListener("change", function () { documentKindFilter = kindSelect.value; renderDocumentRows(); });
      docToolbar.appendChild(kindSelect);
      section.appendChild(docToolbar);
    }
    var rowsHost = el("div", { class: "extuikDocumentRows" });
    section.appendChild(rowsHost);
    function renderDocumentRows() {
      rowsHost.innerHTML = "";
      var queryLower = documentQuery.trim().toLowerCase();
      var filtered = documents.filter(function (d) {
        if (documentKindFilter !== "all" && d.kind !== documentKindFilter) return false;
        if (queryLower && d.title.toLowerCase().indexOf(queryLower) === -1) return false;
        return true;
      });
      if (!documents.length) { rowsHost.appendChild(el("div", { class: "extuikDocumentsEmpty", text: "Nenhuma fonte adicionada. Comece com um texto manual ou importe um arquivo de até 5 MB." })); return; }
      if (!filtered.length) { rowsHost.appendChild(el("div", { class: "extuikDocumentsEmpty", text: "Nenhuma fonte encontrada para esta busca/filtro." })); return; }
      filtered.forEach(renderDocumentRow);
    }
    function renderDocumentRow(document) {
      var row = el("article", { class: "extuikDocument" }, [el("div", { class: "extuikDocumentIcon" }, [icon(ICONS.file)]), el("div", { class: "extuikDocumentMain" }, [el("h3", { text: document.title }), el("p", { text: document.kind.toUpperCase() + " · " + sizeLabel(document.sizeBytes) + " · " + document.charCount.toLocaleString("pt-BR") + " caracteres · " + document.chunkCount + " trechos" }), el("small", { text: "Adicionada em " + dateLabel(document.createdAt) })])]);
      var actions = el("div", { class: "extuikDocumentActions" }); if (document.kind === "manual") actions.appendChild(actionButton("Editar", "edit", "extui-btn extui-btn--ghost", async function () { try { openManualForm(base, await send("EXTUI_KNOWLEDGE_GET_DOCUMENT", { baseId: base.id, documentId: document.id })); } catch (error) { toast(error.message, true); } })); actions.appendChild(actionButton("Remover", "trash", "extui-btn extui-btn--ghost extuikDanger", function () { removeDocument(base, document); })); row.appendChild(actions); rowsHost.appendChild(row);
    }
    renderDocumentRows();
    page.appendChild(section); rootEl.appendChild(page);
  }
  function render() { if (!snapshot || !isActiveRoute()) return; var generation = ++renderGeneration; rootEl.innerHTML = ""; var base = currentBase(); if (base) renderDetail(base, generation); else { activeBaseId = null; renderList(); } }
  async function renderSection(container) { rootEl = container; var loadToken = ++renderGeneration; var loadingTimer = setTimeout(function () { if (loadToken === renderGeneration && isActiveRoute() && !rootEl.childNodes.length) rootEl.innerHTML = '<div class="extuikLoading" role="status">Carregando Bases de Conhecimento…</div>'; }, 450); try { await refresh(); } catch (error) { if (!isActiveRoute()) return; rootEl.innerHTML = ""; rootEl.appendChild(el("div", { class: "extuikError", role: "alert", text: error.message })); } finally { clearTimeout(loadingTimer); } }
  chrome.runtime.onMessage.addListener(function (message, sender) {
    if (!sender || sender.id !== chrome.runtime.id) return;
    if (!message || message.type !== "EXTUI_KNOWLEDGE_INDEX_PROGRESS" || !activeIndexJob || !message.progress || message.progress.jobId !== activeIndexJob.jobId) return;
    var target = document.getElementById("extuikIndexProgress"); if (!target) return; var progress = message.progress;
    var labels = { preparing: "Preparando documentos", embedding: "Preparando busca inteligente", saving: "Salvando revisão", complete: "Busca preparada", failed: "Falha ao preparar a busca", cancelled: "Preparação da busca cancelada" };
    var suffix = progress.total ? " · " + (progress.completed || 0) + " de " + progress.total + " trechos" : ""; target.lastChild.textContent = (labels[progress.state] || "Indexando") + suffix;
  });

  document.addEventListener("ext:dashboard-section-change", function (event) { if (!event.detail || event.detail.section !== "knowledge") closeLayer(); });
  window.addEventListener("pagehide", closeLayer);
  window.__extDashboardShell.registerSection("knowledge", renderSection);
})();
}catch(_extuiBundleError){if(globalThis.__extRecordBootError)globalThis.__extRecordBootError(_extuiBundleError);else throw _extuiBundleError;}
