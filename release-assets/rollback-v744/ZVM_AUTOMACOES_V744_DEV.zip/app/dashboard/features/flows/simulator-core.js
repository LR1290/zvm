;(function () {
  'use strict';
  if (window.ExtensionFlowSimulatorCore) return;

  var SEND_LABELS = {
    sendAudio: 'Áudio', sendImage: 'Imagem', sendVideo: 'Vídeo', sendSticker: 'Figurinha',
    sendDocument: 'Documento', sendPix: 'PIX', sendList: 'Lista', sendContact: 'Contato',
    sendSignature: 'Assinatura', sendQuickResponse: 'Resposta rápida', sendMedia: 'Mídia',
    aiGenerate: 'Resposta de IA', aiAgent: 'Agente de IA', actions: 'Ações', actionList: 'Ações'
  };
  var DOMAIN_TRIGGERS = ['columnMoved','funnelCompleted','followUpSent','scheduleSent','orderChanged','manual'];

  function clone(value) { return JSON.parse(JSON.stringify(value == null ? null : value)); }
  function firstNext(node) { return node && Array.isArray(node.nextNodeIds) ? (node.nextNodeIds[0] || null) : null; }
  function findNode(flow, id) { return flow && Array.isArray(flow.nodes) ? flow.nodes.find(function (node) { return node && String(node.id) === String(id); }) || null : null; }
  function normalizeText(value) { return String(value == null ? '' : value).trim().toLowerCase(); }
  function ruleMatches(rule, rawText, caseSensitive) {
    var text = caseSensitive ? String(rawText || '') : normalizeText(rawText);
    var keywords = (rule && Array.isArray(rule.keywords) ? rule.keywords : []).map(function (k) { return caseSensitive ? String(k) : normalizeText(k); }).filter(Boolean);
    var type = rule && rule.type || 'contains';
    if (!keywords.length) return type === 'notContains';
    if (type === 'startsWith') return keywords.some(function (k) { return text.indexOf(k) === 0; });
    if (type === 'endsWith') return keywords.some(function (k) { return text.slice(-k.length) === k; });
    if (type === 'equals') return keywords.some(function (k) { return text === k; });
    if (type === 'notContains') return keywords.every(function (k) { return text.indexOf(k) < 0; });
    return keywords.some(function (k) { return text.indexOf(k) >= 0; });
  }
  function triggerMatches(trigger, event) {
    trigger = trigger || {};
    event = event || {};
    var type = trigger.type || 'keyword';
    if (type === 'keyword') {
      if (event.type !== 'message') return false;
      var rules = Array.isArray(trigger.keywordRules) ? trigger.keywordRules : [];
      if (!rules.length) return false;
      var positive = rules.filter(function (r) { return r && r.type !== 'notContains'; });
      var negative = rules.filter(function (r) { return r && r.type === 'notContains'; });
      return (positive.length === 0 || positive.some(function (r) { return ruleMatches(r, event.text || '', !!trigger.isCaseSensitive); })) &&
        negative.every(function (r) { return ruleMatches(r, event.text || '', !!trigger.isCaseSensitive); });
    }
    if (type === 'messageReceived' || type === 'newChat' || type === 'newDay') return event.type === 'message';
    if (event.type !== type) return false;
    if (type === 'funnelCompleted') {
      var sourceId = trigger.data && String(trigger.data.sourceId || '');
      return !sourceId || sourceId === String(event.sourceId || event.funnelId || '');
    }
    if (type === 'columnMoved') {
      var crmId = trigger.data && String(trigger.data.crmId || '');
      var columnId = trigger.data && String(trigger.data.columnId || '');
      if (crmId && crmId !== String(event.crmId || '')) return false;
      if (columnId && columnId !== String(event.columnId || '')) return false;
      return true;
    }
    return DOMAIN_TRIGGERS.indexOf(type) >= 0;
  }
  function isWithinWindow(trigger, now) {
    trigger = trigger || {};
    now = now instanceof Date ? now : new Date(now || Date.now());
    if (isNaN(now.getTime())) now = new Date();
    var weekly = trigger.weeklyHours && trigger.weeklyHours[now.getDay()];
    function inHours(from, to) {
      if (!from || !to || from === to) return true;
      var hh = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
      return from <= to ? (hh >= from && hh <= to) : (hh >= from || hh <= to);
    }
    if (weekly) {
      if (weekly.active === false) return false;
      return inHours(weekly.from, weekly.to);
    }
    if (Array.isArray(trigger.activeDays) && trigger.activeDays.length && trigger.activeDays.indexOf(now.getDay()) < 0) return false;
    var hours = trigger.activeHours || null;
    return !hours || inHours(hours.from, hours.to);
  }
  function evaluateEntry(flow, context, event) {
    var trigger = flow && flow.trigger || {};
    context = context || {};
    if (context.isGroupChat === true && trigger.sendToGroups === false) return { accepted:false, reason:'AUDIENCE_GROUP_DISABLED' };
    if (context.isGroupChat === false && trigger.sendToContacts === false) return { accepted:false, reason:'AUDIENCE_CONTACT_DISABLED' };
    if (!isWithinWindow(trigger, context.now)) return { accepted:false, reason:'SCHEDULE_BLOCKED' };
    if (trigger.crmGate && trigger.crmGate.crmId && trigger.crmGate.columnId) {
      if (String(context.crmId || '') !== String(trigger.crmGate.crmId) || String(context.columnId || '') !== String(trigger.crmGate.columnId)) return { accepted:false, reason:'CRM_GATE_BLOCKED' };
    }
    if (!triggerMatches(trigger, event)) return { accepted:false, reason:'TRIGGER_NOT_MATCHED' };
    return { accepted:true, reason:null };
  }
  function createSession(flow, context) {
    var ctx = Object.assign({ isGroupChat:false, crmId:'', columnId:'', now:new Date() }, context || {});
    return { flowId: flow && flow.id || null, status:'idle', currentNodeId:flow && flow.startNodeId || null, waitingNodeId:null, waitingStartedAtMs:null, expiresAtMs:null, resumeAtMs:null, pendingDecision:null, context:ctx, events:[], visited:[], stepCount:0, error:null };
  }
  function pushEvent(session, event) { session.events.push(Object.assign({ index:session.events.length, at:Date.now() }, event || {})); }
  var OPT_IN_TERMINAL_TYPES = ['sendText','sendAudio','sendImage','sendVideo','sendSticker','sendDocument','sendPix','sendList','sendContact','sendSignature','sendQuickResponse','sendMedia','moveToColumn','condition'];
  function isTerminalNode(node) { return !!node && (node.type === 'end' || node.type === 'endHuman' || (OPT_IN_TERMINAL_TYPES.indexOf(node.type) >= 0 && !!(node.data && node.data.isTerminal === true))); }
  function extDjb2Hash(str) { var hash=5381; str=String(str||''); for(var i=0;i<str.length;i++) hash=(((hash<<5)+hash)+str.charCodeAt(i))|0; return hash>>>0; }
  function nextRandomizer(node, randomFn, stickyKey) {
    var weights = node && node.data && Array.isArray(node.data.weights) ? node.data.weights : [];
    var total = weights.reduce(function (sum, row) { return sum + Math.max(0, Number(row && row.weight) || 0); }, 0);
    if (!weights.length || total <= 0) return { id:null, index:-1 };
    var sticky = node && node.data && node.data.mode === 'sticky';
    var unit = sticky ? (extDjb2Hash(String(stickyKey || 'simulator') + ':' + String(node && node.id || '')) % 100000) / 100000 : Number((randomFn || Math.random)());
    var roll = Math.max(0, Math.min(0.999999999, unit)) * total;
    var acc = 0;
    for (var i=0;i<weights.length;i++) { acc += Math.max(0, Number(weights[i] && weights[i].weight) || 0); if (roll < acc) return { id:weights[i] && weights[i].nextNodeId || null, index:i }; }
    return { id:weights[weights.length-1] && weights[weights.length-1].nextNodeId || null, index:weights.length-1 };
  }
  function delayMs(node) {
    if (node && node.data && typeof node.data.delayMs === 'number') return Math.max(0, node.data.delayMs);
    var amount = Math.max(0, Number(node && node.data && node.data.amount) || 0);
    var factor = { seconds:1000, minutes:60000, hours:3600000, days:86400000 }[node && node.data && node.data.unit || 'minutes'] || 60000;
    return amount * factor;
  }
  function displayText(node) {
    var data = node && node.data || {};
    if (node.type === 'sendText') return data.text || (data.itemId ? 'Mensagem salva selecionada' : 'Mensagem não configurada');
    if (node.type === 'aiGenerate') return data.prompt ? 'IA · ' + String(data.prompt) : 'Resposta de IA simulada';
    if (node.type === 'aiAgent') return data.task ? 'Agente IA · ' + String(data.task) : 'Execução do agente de IA simulada';
    return SEND_LABELS[node.type] || node.type;
  }
  function runForward(flow, session, options) {
    options = options || {};
    var guard = 0, maxSteps = Math.max(20, Number(options.maxSteps) || 250);
    while (session.status === 'running' && session.currentNodeId && guard++ < maxSteps) {
      var node = findNode(flow, session.currentNodeId);
      if (!node) { session.status='error'; session.error='NODE_NOT_FOUND'; pushEvent(session,{kind:'error',text:'A próxima etapa não foi encontrada.'}); break; }
      session.visited.push(String(node.id)); session.stepCount += 1;
      if (node.type === 'start') { session.currentNodeId = firstNext(node); continue; }
      if (node.type === 'sendText') { pushEvent(session,{kind:'message',direction:'out',nodeId:node.id,nodeType:node.type,text:displayText(node)}); session.currentNodeId=isTerminalNode(node)?null:firstNext(node); continue; }
      if (SEND_LABELS[node.type]) { pushEvent(session,{kind:node.type === 'aiGenerate' || node.type === 'aiAgent' ? 'message':'action',direction:'out',nodeId:node.id,nodeType:node.type,text:displayText(node),itemId:node.data&&node.data.itemId||null,itemKind:node.data&&node.data.itemKind||null,caption:node.data&&node.data.caption||''}); session.currentNodeId=isTerminalNode(node)?null:firstNext(node); continue; }
      if (node.type === 'moveToColumn') {
        session.context.crmId = node.data && node.data.crmId || '';
        session.context.columnId = node.data && node.data.columnId || '';
        pushEvent(session,{kind:'action',nodeId:node.id,nodeType:node.type,text:'Mover para coluna do CRM',crmId:session.context.crmId,columnId:session.context.columnId});
        session.currentNodeId=isTerminalNode(node)?null:firstNext(node); continue;
      }
      if (node.type === 'condition') {
        var matches = node.data && node.data.conditionType === 'inColumn' && String(session.context.crmId||'') === String(node.data.crmId||'') && String(session.context.columnId||'') === String(node.data.columnId||'');
        var condNext = matches ? firstNext(node) : (node.nextNodeIdOnConditionFalse || null);
        var condDecision = { nodeId:node.id, nodeType:node.type, result:!!matches, label:matches?'Condição atendida':'Condição não atendida', nextNodeId:isTerminalNode(node)?null:condNext };
        if (options.pauseOnDecision) { session.status='pausedDecision'; session.pendingDecision=condDecision; session.currentNodeId=node.id; pushEvent(session,{kind:'decisionPause',nodeId:node.id,nodeType:node.type,text:'Decisão pausada',result:condDecision.result,label:condDecision.label,nextNodeId:condDecision.nextNodeId}); break; }
        pushEvent(session,{kind:'branch',nodeId:node.id,nodeType:node.type,result:condDecision.result,label:condDecision.label,nextNodeId:condDecision.nextNodeId});
        session.currentNodeId=condDecision.nextNodeId; continue;
      }
      if (node.type === 'randomizer') {
        var pick = nextRandomizer(node, options.random, session.context && (session.context.chatId || session.context.contactId || session.context.stickyKey || session.flowId));
        var randomDecision = { nodeId:node.id, nodeType:node.type, label:pick.index>=0?'Caminho '+String.fromCharCode(65+pick.index):'Sem caminho', chosenIndex:pick.index, nextNodeId:pick.id };
        if (options.pauseOnDecision) { session.status='pausedDecision'; session.pendingDecision=randomDecision; session.currentNodeId=node.id; pushEvent(session,{kind:'decisionPause',nodeId:node.id,nodeType:node.type,text:'Decisão pausada',label:randomDecision.label,chosenIndex:randomDecision.chosenIndex,nextNodeId:randomDecision.nextNodeId}); break; }
        pushEvent(session,{kind:'branch',nodeId:node.id,nodeType:node.type,label:randomDecision.label,chosenIndex:randomDecision.chosenIndex,nextNodeId:randomDecision.nextNodeId});
        session.currentNodeId=randomDecision.nextNodeId; continue;
      }
      if (node.type === 'delay' || node.type === 'intervalo') {
        var ms = delayMs(node), scale = Math.max(0, Number(options.delayScale) || 0);
        pushEvent(session,{kind:'wait',nodeId:node.id,nodeType:node.type,durationMs:ms,effectiveDurationMs:scale>0?Math.max(1,Math.round(ms*scale)):0,text:'Aguardar'});
        session.currentNodeId=isTerminalNode(node)?null:firstNext(node);
        if (scale > 0 && ms > 0) { session.status='waitingDelay'; session.resumeAtMs=Date.now()+Math.max(1,Math.round(ms*scale)); break; }
        continue;
      }
      if (node.type === 'userInput') {
        var timeoutMs = Math.max(0, Number(node.expirationTimeoutInMs) || 0);
        session.status='waitingForInput'; session.waitingNodeId=node.id; session.currentNodeId=node.id;
        session.waitingStartedAtMs=Date.now(); session.expiresAtMs=timeoutMs > 0 ? session.waitingStartedAtMs + timeoutMs : null;
        pushEvent(session,{kind:'prompt',nodeId:node.id,nodeType:node.type,text:'Aguardando resposta do contato',expectedAnswer:node.data&&node.data.expectedAnswer||'',expectedMessages:node.data&&node.data.expectedMessages||null,timeoutMs:timeoutMs||null,expiresAtMs:session.expiresAtMs});
        break;
      }
      if (node.type === 'end') { pushEvent(session,{kind:'system',nodeId:node.id,nodeType:node.type,text:'Ramo finalizado.'}); session.currentNodeId=null; break; }
      if (node.type === 'endHuman') { pushEvent(session,{kind:'system',nodeId:node.id,nodeType:node.type,text:'Atendimento transferido para uma pessoa.'}); session.status='needsHuman'; session.currentNodeId=null; break; }
      if (node.type === 'unsupported') { session.status='error'; session.error='FLOW_NODE_UNSUPPORTED'; pushEvent(session,{kind:'error',nodeId:node.id,nodeType:node.type,text:'Tipo de etapa não suportado.'}); break; }
      session.status='error'; session.error='FLOW_NODE_UNKNOWN'; pushEvent(session,{kind:'error',nodeId:node.id,nodeType:node.type,text:'Tipo de etapa desconhecido: '+String(node.type)}); break;
    }
    if (guard >= maxSteps && session.status === 'running') { session.status='error'; session.error='MAX_STEPS'; pushEvent(session,{kind:'error',text:'A simulação foi interrompida por excesso de etapas.'}); }
    if (session.status === 'running' && !session.currentNodeId) { session.status='finished'; pushEvent(session,{kind:'system',text:'Fluxo concluído.'}); }
    return session;
  }
  function startAccepted(flow, session, event, options) {
    var result = evaluateEntry(flow, session.context, event);
    if (!result.accepted) { pushEvent(session,{kind:'blocked',reason:result.reason,text:result.reason}); return session; }
    session.status='running'; session.currentNodeId=flow && flow.startNodeId || null; session.waitingNodeId=null; session.waitingStartedAtMs=null; session.expiresAtMs=null; session.resumeAtMs=null; session.pendingDecision=null;
    pushEvent(session,{kind:'accepted',triggerType:flow&&flow.trigger&&flow.trigger.type||'keyword',text:'Gatilho aceito'});
    return runForward(flow, session, options);
  }
  function fireTrigger(flow, session, eventType, options) {
    session = session || createSession(flow,{});
    if (session.status !== 'idle' && session.status !== 'finished' && session.status !== 'error' && session.status !== 'needsHuman') return session;
    if (session.status !== 'idle') { var ctx = clone(session.context); session = createSession(flow, ctx); }
    var type = eventType || (flow && flow.trigger && flow.trigger.type) || 'manual';
    var event = Object.assign({type:type}, options && options.event || {});
    return startAccepted(flow, session, event, options);
  }

  function continueDecision(flow, session, options) {
    if (!session || session.status !== 'pausedDecision' || !session.pendingDecision) return session;
    var pending = session.pendingDecision;
    session.pendingDecision = null;
    session.status = 'running';
    session.currentNodeId = pending.nextNodeId || null;
    pushEvent(session,{kind:'branch',nodeId:pending.nodeId,nodeType:pending.nodeType,result:pending.result,label:pending.label,chosenIndex:pending.chosenIndex,nextNodeId:pending.nextNodeId});
    return runForward(flow, session, options);
  }
  function resumeDelay(flow, session, options) {
    if (!session || session.status !== 'waitingDelay') return session;
    session.status = 'running';
    session.resumeAtMs = null;
    return runForward(flow, session, options);
  }

  function expireInput(flow, session, options) {
    if (!session || session.status !== 'waitingForInput') return session;
    var node = findNode(flow, session.waitingNodeId || session.currentNodeId);
    if (!node) { session.status='error'; session.error='WAIT_NODE_NOT_FOUND'; pushEvent(session,{kind:'error',text:'A etapa em espera não foi encontrada.'}); return session; }
    var next = node.nextNodeIdOnExpiration || null;
    session.status='running'; session.waitingNodeId=null; session.waitingStartedAtMs=null; session.expiresAtMs=null; session.resumeAtMs=null; session.pendingDecision=null; session.currentNodeId=next;
    pushEvent(session,{kind:'branch',nodeId:node.id,nodeType:'userInput',label:'Tempo esgotado',nextNodeId:next});
    return runForward(flow, session, options);
  }
  function submitMessage(flow, session, text, options) {
    session = session || createSession(flow,{});
    pushEvent(session,{kind:'message',direction:'in',text:String(text||'')});
    if (session.status === 'waitingForInput') {
      var node = findNode(flow, session.waitingNodeId || session.currentNodeId);
      if (!node) { session.status='error'; session.error='WAIT_NODE_NOT_FOUND'; return session; }
      var expectedMessages = node.data && node.data.expectedMessages;
      var next = null;
      if (Array.isArray(expectedMessages) && expectedMessages.length) {
        var lower = normalizeText(text), idx = expectedMessages.findIndex(function (m) { return normalizeText(m) === lower; });
        next = idx >= 0 ? ((node.nextNodeIds && node.nextNodeIds[idx]) || null) : (node.nextNodeIdOnDifferentAnswer || null);
      } else {
        var expected = normalizeText(node.data && node.data.expectedAnswer || '');
        var matches = expected ? normalizeText(text).indexOf(expected) >= 0 : true;
        next = matches ? firstNext(node) : (node.nextNodeIdOnDifferentAnswer || null);
      }
      session.status='running'; session.waitingNodeId=null; session.waitingStartedAtMs=null; session.expiresAtMs=null; session.resumeAtMs=null; session.pendingDecision=null; session.currentNodeId=next;
      pushEvent(session,{kind:'branch',nodeId:node.id,nodeType:'userInput',label:next===node.nextNodeIdOnDifferentAnswer?'Resposta diferente':'Resposta aceita',nextNodeId:next});
      return runForward(flow, session, options);
    }
    if (session.status === 'idle' || session.status === 'finished' || session.status === 'error' || session.status === 'needsHuman') {
      if (session.status !== 'idle') { var ctx = clone(session.context); session = createSession(flow,ctx); pushEvent(session,{kind:'message',direction:'in',text:String(text||'')}); }
      return startAccepted(flow, session, {type:'message',text:String(text||'')}, options);
    }
    return session;
  }

  window.ExtensionFlowSimulatorCore = {
    createSession:createSession,
    evaluateEntry:evaluateEntry,
    submitMessage:submitMessage,
    fireTrigger:fireTrigger,
    runForward:runForward,
    expireInput:expireInput,
    continueDecision:continueDecision,
    resumeDelay:resumeDelay,
    triggerMatches:triggerMatches,
    isWithinTriggerWindow:isWithinWindow
  };
})();
