(function (root) {
  'use strict';

  var GROUP_LAYOUT = Object.freeze({
    maxColumns: 4,
    nodeWidth: 260,
    nodeHeight: 92,
    columnGap: 80,
    rowGap: 68,
    paddingX: 40,
    paddingTop: 60,
    paddingBottom: 40,
    headerHeight: 36,
    returnLaneGap: 24,
    gridSize: 20
  });

  function nowMs() { return Date.now(); }
  function asId(value) { return String(value == null ? '' : value).trim(); }
  function asArray(value) { return Array.isArray(value) ? value : []; }
  function uniquePush(list, value) { if (value && list.indexOf(value) < 0) list.push(value); }

  function outgoingTargets(node) {
    var out = [];
    asArray(node && node.nextNodeIds).forEach(function (id) { uniquePush(out, asId(id)); });
    [
      node && node.nextNodeIdOnExpiration,
      node && node.nextNodeIdOnDifferentAnswer,
      node && node.nextNodeIdOnConditionFalse
    ].forEach(function (id) { uniquePush(out, asId(id)); });
    var weights = node && node.data && Array.isArray(node.data.weights) ? node.data.weights : [];
    weights.forEach(function (weight) { uniquePush(out, asId(weight && weight.nextNodeId)); });
    return out;
  }

  function nodeDimensions(node) {
    var measured = node && node.measured && typeof node.measured === 'object' ? node.measured : null;
    var width = Number(measured && measured.width);
    var height = Number(measured && measured.height);
    if (!Number.isFinite(width) || width <= 0) width = Number(node && node.width);
    if (!Number.isFinite(height) || height <= 0) height = Number(node && node.height);
    if (!Number.isFinite(width) || width <= 0) width = GROUP_LAYOUT.nodeWidth;
    if (!Number.isFinite(height) || height <= 0) height = GROUP_LAYOUT.nodeHeight;
    return { width: width, height: height };
  }

  function analyzeFlowNodeGroups(flow) {
    var nodes = asArray(flow && flow.nodes);
    var validIds = new Set();
    var startIds = new Set();
    nodes.forEach(function (node) {
      if (!node) return;
      var id = asId(node.id);
      if (!id) return;
      validIds.add(id);
      if (node.type === 'start') startIds.add(id);
    });

    var owner = new Set();
    var groups = [];
    var warnings = [];
    asArray(flow && flow.nodeGroups).forEach(function (raw, index) {
      if (!raw || !asId(raw.id)) {
        warnings.push({ code: 'GROUP_ID_INVALID', index: index });
        return;
      }
      var id = asId(raw.id);
      var members = [];
      asArray(raw.memberNodeIds).forEach(function (value) {
        var memberId = asId(value);
        if (!memberId) {
          warnings.push({ code: 'GROUP_MEMBER_ID_INVALID', groupId: id });
          return;
        }
        if (!validIds.has(memberId)) {
          warnings.push({ code: 'GROUP_MEMBER_MISSING', groupId: id, nodeId: memberId });
          return;
        }
        if (startIds.has(memberId)) {
          warnings.push({ code: 'GROUP_START_FORBIDDEN', groupId: id, nodeId: memberId });
          return;
        }
        if (owner.has(memberId)) {
          warnings.push({ code: 'GROUP_MEMBER_DUPLICATE_OWNER', groupId: id, nodeId: memberId });
          return;
        }
        if (members.indexOf(memberId) >= 0) {
          warnings.push({ code: 'GROUP_MEMBER_DUPLICATE', groupId: id, nodeId: memberId });
          return;
        }
        members.push(memberId);
      });
      if (members.length < 2) {
        warnings.push({ code: 'GROUP_TOO_SMALL', groupId: id });
        return;
      }
      members.forEach(function (memberId) { owner.add(memberId); });
      var createdAt = Number(raw.createdAtInMs) || nowMs();
      groups.push({
        id: id,
        name: String(raw.name || 'Grupo'),
        memberNodeIds: members,
        layoutMode: raw.layoutMode === 'free' ? 'free' : 'structured',
        layoutRevision: Math.max(0, Number(raw.layoutRevision) || 0),
        collapsed: raw.collapsed === true,
        createdAtInMs: createdAt,
        updatedAtInMs: Number(raw.updatedAtInMs) || createdAt
      });
    });
    return { groups: groups, warnings: warnings };
  }

  function normalizeFlowNodeGroups(flow) {
    return analyzeFlowNodeGroups(flow).groups;
  }

  function validateFlowNodeGroups(flow) {
    var analyzed = analyzeFlowNodeGroups(flow);
    var original = asArray(flow && flow.nodeGroups);
    var normalizedJson = JSON.stringify(analyzed.groups);
    var originalJson = JSON.stringify(original);
    return {
      valid: analyzed.warnings.length === 0 && normalizedJson === originalJson,
      warnings: analyzed.warnings,
      groups: analyzed.groups
    };
  }

  function remapNodeGroups(groups, nodeIdMap, makeGroupId) {
    var out = [];
    var mapper = nodeIdMap || {};
    var makeId = typeof makeGroupId === 'function' ? makeGroupId : function () { return 'group-' + nowMs(); };
    asArray(groups).forEach(function (group) {
      if (!group) return;
      var seen = new Set();
      var members = [];
      asArray(group.memberNodeIds).forEach(function (oldId) {
        var nextId = asId(mapper[asId(oldId)]);
        if (!nextId || seen.has(nextId)) return;
        seen.add(nextId);
        members.push(nextId);
      });
      if (members.length < 2) return;
      var createdAt = Number(group.createdAtInMs) || nowMs();
      out.push({
        id: asId(makeId()) || ('group-' + nowMs()),
        name: String(group.name || 'Grupo'),
        memberNodeIds: members,
        layoutMode: group.layoutMode === 'free' ? 'free' : 'structured',
        layoutRevision: Math.max(0, Number(group.layoutRevision) || 0),
        collapsed: group.collapsed === true,
        createdAtInMs: createdAt,
        updatedAtInMs: nowMs()
      });
    });
    return out;
  }

  function groupEntryId(group) {
    var members = asArray(group && group.memberNodeIds);
    return members.length ? asId(members[0]) || null : null;
  }

  function groupExitId(group) {
    var members = asArray(group && group.memberNodeIds);
    return members.length ? asId(members[members.length - 1]) || null : null;
  }

  function analyzeGroupSelectionTopology(flow, nodeIds) {
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    var ids = [];
    asArray(nodeIds).forEach(function (value) { var id = asId(value); if (id && ids.indexOf(id) < 0) ids.push(id); });
    if (ids.length < 2) return { ok: false, nodeIds: ids, orderedNodeIds: ids, entryNodeIds: [], exitNodeIds: [], externalIncoming: [], externalOutgoing: [], internalEdges: [], reason: 'SELECTION_TOO_SMALL' };
    for (var i = 0; i < ids.length; i += 1) {
      var candidate = byId[ids[i]];
      if (!candidate) return { ok: false, nodeIds: ids, orderedNodeIds: ids, entryNodeIds: [], exitNodeIds: [], externalIncoming: [], externalOutgoing: [], internalEdges: [], reason: 'NODE_MISSING' };
      if (candidate.type === 'start') return { ok: false, nodeIds: ids, orderedNodeIds: ids, entryNodeIds: [], exitNodeIds: [], externalIncoming: [], externalOutgoing: [], internalEdges: [], reason: 'START_FORBIDDEN' };
    }
    var selected = new Set(ids);
    var internalOut = Object.create(null), internalIn = Object.create(null), undirected = Object.create(null);
    var internalEdges = [], externalIncoming = [], externalOutgoing = [];
    ids.forEach(function (id) { internalOut[id] = []; internalIn[id] = []; undirected[id] = []; });
    nodes.forEach(function (node) {
      var sourceId = asId(node && node.id);
      if (!sourceId) return;
      outgoingTargets(node).forEach(function (targetId) {
        if (!targetId || !byId[targetId]) return;
        var sourceSelected = selected.has(sourceId), targetSelected = selected.has(targetId);
        if (sourceSelected && targetSelected) {
          uniquePush(internalOut[sourceId], targetId); uniquePush(internalIn[targetId], sourceId);
          uniquePush(undirected[sourceId], targetId); uniquePush(undirected[targetId], sourceId);
          internalEdges.push({ sourceId: sourceId, targetId: targetId });
        } else if (!sourceSelected && targetSelected) externalIncoming.push({ sourceId: sourceId, targetId: targetId });
        else if (sourceSelected && !targetSelected) externalOutgoing.push({ sourceId: sourceId, targetId: targetId });
      });
    });
    var seen = new Set(), queue = [ids[0]];
    while (queue.length) {
      var current = queue.shift(); if (seen.has(current)) continue; seen.add(current);
      asArray(undirected[current]).forEach(function (next) { if (!seen.has(next)) queue.push(next); });
    }
    if (seen.size !== ids.length) return { ok: false, nodeIds: ids, orderedNodeIds: ids, entryNodeIds: [], exitNodeIds: [], externalIncoming: externalIncoming, externalOutgoing: externalOutgoing, internalEdges: internalEdges, internalIn: internalIn, internalOut: internalOut, reason: 'DISCONNECTED_SELECTION' };
    var entryNodeIds = ids.filter(function (id) { return internalIn[id].length === 0; });
    var exitNodeIds = ids.filter(function (id) { return internalOut[id].length === 0; });
    if (!entryNodeIds.length) entryNodeIds = externalIncoming.map(function (edge) { return edge.targetId; }).filter(function (id, index, list) { return list.indexOf(id) === index; });
    if (!exitNodeIds.length) exitNodeIds = externalOutgoing.map(function (edge) { return edge.sourceId; }).filter(function (id, index, list) { return list.indexOf(id) === index; });

    var indegree = Object.create(null), depth = Object.create(null), orderIndex = Object.create(null);
    ids.forEach(function (id, index) { indegree[id] = internalIn[id].length; depth[id] = 0; orderIndex[id] = index; });
    var topoQueue = ids.filter(function (id) { return indegree[id] === 0; }).sort(function (a,b) { return orderIndex[a]-orderIndex[b]; });
    var ordered = [];
    while (topoQueue.length) {
      var top = topoQueue.shift(); ordered.push(top);
      internalOut[top].forEach(function (next) {
        depth[next] = Math.max(depth[next] || 0, (depth[top] || 0) + 1);
        indegree[next] -= 1;
        if (indegree[next] === 0) { topoQueue.push(next); topoQueue.sort(function (a,b) { return orderIndex[a]-orderIndex[b]; }); }
      });
    }
    var cycleDetected = ordered.length !== ids.length;
    if (cycleDetected) ids.forEach(function (id) { if (ordered.indexOf(id) < 0) { depth[id] = Math.max(0, Number(depth[id]) || 0); ordered.push(id); } });
    return {
      ok: true, nodeIds: ids, orderedNodeIds: ordered, entryNodeIds: entryNodeIds, exitNodeIds: exitNodeIds,
      entryNodeId: entryNodeIds[0] || null, exitNodeId: exitNodeIds[0] || null,
      externalIncoming: externalIncoming, externalOutgoing: externalOutgoing, internalEdges: internalEdges,
      internalIn: internalIn, internalOut: internalOut, depthByNodeId: depth, cycleDetected: cycleDetected, reason: null
    };
  }

  function linearizeSerialSelection(flow, nodeIds) {
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    var ids = [];
    asArray(nodeIds).forEach(function (value) { var id = asId(value); if (id && ids.indexOf(id) < 0) ids.push(id); });
    if (ids.length < 2) return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'SELECTION_TOO_SMALL' };
    for (var i = 0; i < ids.length; i += 1) {
      var candidate = byId[ids[i]];
      if (!candidate) return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'NODE_MISSING' };
      if (candidate.type === 'start') return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'START_FORBIDDEN' };
    }

    var selected = new Set(ids);
    var internalOut = Object.create(null);
    var internalIn = Object.create(null);
    var externalIncoming = [];
    var externalOutgoing = [];
    ids.forEach(function (id) { internalOut[id] = []; internalIn[id] = []; });

    nodes.forEach(function (node) {
      var sourceId = asId(node && node.id);
      if (!sourceId) return;
      outgoingTargets(node).forEach(function (targetId) {
        if (!targetId || !byId[targetId]) return;
        var sourceSelected = selected.has(sourceId);
        var targetSelected = selected.has(targetId);
        if (sourceSelected && targetSelected) {
          uniquePush(internalOut[sourceId], targetId);
          uniquePush(internalIn[targetId], sourceId);
        } else if (!sourceSelected && targetSelected) {
          externalIncoming.push({ sourceId: sourceId, targetId: targetId });
        } else if (sourceSelected && !targetSelected) {
          externalOutgoing.push({ sourceId: sourceId, targetId: targetId });
        }
      });
    });

    for (var j = 0; j < ids.length; j += 1) {
      var id = ids[j];
      if (internalOut[id].length > 1 || internalIn[id].length > 1) {
        return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'BRANCHED_INTERNAL_TOPOLOGY' };
      }
    }

    var starts = ids.filter(function (id) { return internalIn[id].length === 0; });
    var ends = ids.filter(function (id) { return internalOut[id].length === 0; });
    if (starts.length !== 1 || ends.length !== 1) {
      return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'NOT_A_SINGLE_CHAIN' };
    }

    var ordered = [];
    var cursor = starts[0];
    var visited = new Set();
    while (cursor && !visited.has(cursor)) {
      visited.add(cursor);
      ordered.push(cursor);
      cursor = internalOut[cursor][0] || null;
    }
    if (ordered.length !== ids.length) {
      return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'DISCONNECTED_SELECTION' };
    }

    var first = ordered[0];
    var last = ordered[ordered.length - 1];
    if (externalIncoming.length > 1 || externalIncoming.some(function (edge) { return edge.targetId !== first; })) {
      return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'AMBIGUOUS_EXTERNAL_ENTRY' };
    }
    if (externalOutgoing.length > 1 || externalOutgoing.some(function (edge) { return edge.sourceId !== last; })) {
      return { ok: false, orderedNodeIds: [], entryNodeId: null, exitNodeId: null, reason: 'AMBIGUOUS_EXTERNAL_EXIT' };
    }

    return {
      ok: true,
      orderedNodeIds: ordered,
      entryNodeId: first,
      exitNodeId: last,
      externalIncoming: externalIncoming,
      externalOutgoing: externalOutgoing,
      reason: null
    };
  }

  function expandSelectionEntities(selectionKeys, groups) {
    var groupMap = Object.create(null);
    asArray(groups).forEach(function (group) { var id = asId(group && group.id); if (id) groupMap[id] = group; });
    var out = [];
    asArray(selectionKeys).forEach(function (key) {
      var raw = asId(key);
      if (!raw) return;
      if (raw.indexOf('group:') === 0) {
        var group = groupMap[raw.slice(6)];
        asArray(group && group.memberNodeIds).forEach(function (id) { uniquePush(out, asId(id)); });
        return;
      }
      if (raw.indexOf('node:') === 0) raw = raw.slice(5);
      uniquePush(out, raw);
    });
    return out;
  }

  function snapGroupValue(value) {
    return Math.round(Number(value || 0) / GROUP_LAYOUT.gridSize) * GROUP_LAYOUT.gridSize;
  }

  function deriveStructuredGroupLayout(flow, group, options) {
    var opts = options || {}, nodes = asArray(flow && flow.nodes), byId = Object.create(null), orderIndex = Object.create(null);
    nodes.forEach(function (node, index) { var id = asId(node && node.id); if (id) { byId[id] = node; orderIndex[id] = index; } });
    var members = asArray(group && group.memberNodeIds).map(asId).filter(function (id) { return id && byId[id]; });
    var dimensions = Object.create(null); members.forEach(function (id) { dimensions[id] = nodeDimensions(byId[id]); });
    if (!members.length) return { rows: [], positions: Object.create(null), dimensions: dimensions, rowHeights: [], rowWidths: [], rowTops: [], memberRows: Object.create(null), bounds: {x:0,y:0,width:0,height:0}, wrapTransitions: [], constants: GROUP_LAYOUT, topology: null };
    var topology = analyzeGroupSelectionTopology(flow, members);
    var depth = topology.ok ? topology.depthByNodeId : Object.create(null);
    var layers = Object.create(null), maxDepth = 0;
    members.forEach(function (id, index) {
      var d = topology.ok ? Math.max(0, Number(depth[id]) || 0) : Math.floor(index / GROUP_LAYOUT.maxColumns);
      maxDepth = Math.max(maxDepth, d); (layers[d] || (layers[d] = [])).push(id);
    });
    var layerKeys = Object.keys(layers).map(Number).sort(function(a,b){return a-b;});
    layerKeys.forEach(function (d) {
      layers[d].sort(function (a,b) {
        var ai = topology.ok && topology.internalIn[a] || [], bi = topology.ok && topology.internalIn[b] || [];
        function bary(list) { if (!list.length) return orderIndex[list[0]] || 0; var total=0,count=0; list.forEach(function(p){ if (orderIndex[p] !== undefined) { total += orderIndex[p]; count++; } }); return count ? total/count : 0; }
        var av=bary(ai), bv=bary(bi); if (av!==bv) return av-bv; return orderIndex[a]-orderIndex[b];
      });
    });
    var memberXs = members.map(function(id){return Number(byId[id].position && byId[id].position.x);}).filter(Number.isFinite);
    var memberYs = members.map(function(id){return Number(byId[id].position && byId[id].position.y);}).filter(Number.isFinite);
    var requestedAnchorX = Number.isFinite(Number(opts.anchorX)) ? Number(opts.anchorX) : null;
    var requestedAnchorY = Number.isFinite(Number(opts.anchorY)) ? Number(opts.anchorY) : null;
    var anchorX = snapGroupValue(requestedAnchorX == null ? ((memberXs.length ? Math.min.apply(Math, memberXs) : 120) - GROUP_LAYOUT.paddingX) : requestedAnchorX);
    var anchorY = snapGroupValue(requestedAnchorY == null ? ((memberYs.length ? Math.min.apply(Math, memberYs) : 160) - GROUP_LAYOUT.paddingTop) : requestedAnchorY);
    var layerWidths = Object.create(null), layerHeights = Object.create(null), contentHeight = 0;
    layerKeys.forEach(function(d){
      layerWidths[d] = layers[d].reduce(function(max,id){return Math.max(max,dimensions[id].width);},0);
      var h=layers[d].reduce(function(sum,id){return sum+dimensions[id].height;},0)+Math.max(0,layers[d].length-1)*GROUP_LAYOUT.rowGap;
      layerHeights[d]=h; contentHeight=Math.max(contentHeight,h);
    });
    var positions=Object.create(null), x=anchorX+GROUP_LAYOUT.paddingX;
    layerKeys.forEach(function(d){
      var y=anchorY+GROUP_LAYOUT.paddingTop+(contentHeight-layerHeights[d])/2;
      layers[d].forEach(function(id){ positions[id]={x:snapGroupValue(x),y:snapGroupValue(y)}; y += dimensions[id].height+GROUP_LAYOUT.rowGap; });
      x += layerWidths[d]+GROUP_LAYOUT.columnGap;
    });
    var contentWidth=0; layerKeys.forEach(function(d,index){contentWidth += layerWidths[d] + (index<layerKeys.length-1?GROUP_LAYOUT.columnGap:0);});
    var rows=layerKeys.map(function(d){return layers[d].slice();}), rowHeights=layerKeys.map(function(d){return layerHeights[d];}), rowWidths=layerKeys.map(function(d){return layerWidths[d];});
    var memberRows=Object.create(null), rowTops=[]; rows.forEach(function(row,i){rowTops[i]=Math.min.apply(Math,row.map(function(id){return positions[id].y;})); row.forEach(function(id){memberRows[id]=i;});});
    return { rows:rows, positions:positions, dimensions:dimensions, rowHeights:rowHeights, rowWidths:rowWidths, rowTops:rowTops, memberRows:memberRows,
      bounds:{x:anchorX,y:anchorY,width:GROUP_LAYOUT.paddingX*2+contentWidth,height:GROUP_LAYOUT.paddingTop+GROUP_LAYOUT.paddingBottom+contentHeight},
      wrapTransitions:[], constants:GROUP_LAYOUT, topology:topology };
  }

  function deriveFreeGroupLayout(flow, group, options) {
    var opts=options||{}, nodes=asArray(flow&&flow.nodes), byId=Object.create(null);
    nodes.forEach(function(node){var id=asId(node&&node.id);if(id)byId[id]=node;});
    var members=asArray(group&&group.memberNodeIds).map(asId).filter(function(id){return id&&byId[id];});
    var dimensions=Object.create(null), positions=Object.create(null);
    var minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    members.forEach(function(id){var node=byId[id],size=nodeDimensions(node),pos=node.position||{x:0,y:0};dimensions[id]=size;positions[id]={x:Number(pos.x)||0,y:Number(pos.y)||0};minX=Math.min(minX,positions[id].x);minY=Math.min(minY,positions[id].y);maxX=Math.max(maxX,positions[id].x+size.width);maxY=Math.max(maxY,positions[id].y+size.height);});
    if(!members.length)return{rows:[],positions:positions,dimensions:dimensions,rowHeights:[],rowWidths:[],rowTops:[],memberRows:Object.create(null),bounds:{x:0,y:0,width:0,height:0},wrapTransitions:[],constants:GROUP_LAYOUT,topology:null};
    var baseX=minX-GROUP_LAYOUT.paddingX,baseY=minY-GROUP_LAYOUT.paddingTop;
    if(Number.isFinite(Number(opts.anchorX))||Number.isFinite(Number(opts.anchorY))){var dx=Number.isFinite(Number(opts.anchorX))?Number(opts.anchorX)-baseX:0,dy=Number.isFinite(Number(opts.anchorY))?Number(opts.anchorY)-baseY:0;members.forEach(function(id){positions[id]={x:snapGroupValue(positions[id].x+dx),y:snapGroupValue(positions[id].y+dy)};});minX+=dx;maxX+=dx;minY+=dy;maxY+=dy;baseX+=dx;baseY+=dy;}
    return {rows:[members.slice()],positions:positions,dimensions:dimensions,rowHeights:[maxY-minY],rowWidths:[maxX-minX],rowTops:[minY],memberRows:Object.create(null),bounds:{x:baseX,y:baseY,width:(maxX-minX)+GROUP_LAYOUT.paddingX*2,height:(maxY-minY)+GROUP_LAYOUT.paddingTop+GROUP_LAYOUT.paddingBottom},wrapTransitions:[],constants:GROUP_LAYOUT,topology:analyzeGroupSelectionTopology(flow,members)};
  }

  function deriveGroupLayout(flow, group, options) {
    return group && group.layoutMode === 'free' ? deriveFreeGroupLayout(flow, group, options) : deriveStructuredGroupLayout(flow, group, options);
  }

  function canonicalizeFlowGroupPositions(flow) {
    if (!flow || !Array.isArray(flow.nodes)) return false;
    var byId = Object.create(null);
    flow.nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    var changed = false;
    normalizeFlowNodeGroups(flow).forEach(function (group) {
      if (group.layoutMode === 'free') return;
      var layout = deriveGroupLayout(flow, group);
      asArray(group.memberNodeIds).forEach(function (nodeId) {
        var node = byId[asId(nodeId)], next = layout.positions[asId(nodeId)];
        if (!node || !next) return;
        var current = node.position || {};
        if (Number(current.x) === Number(next.x) && Number(current.y) === Number(next.y)) return;
        node.position = { x: next.x, y: next.y };
        changed = true;
      });
    });
    return changed;
  }

  function buildGroupWrapPath(flow, group, sourceId, targetId) {
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    sourceId = asId(sourceId);
    targetId = asId(targetId);
    var source = byId[sourceId];
    var target = byId[targetId];
    if (!source || !target) return null;
    var layout = deriveGroupLayout(flow, group);
    var wrap = layout.wrapTransitions.some(function (item) { return item.sourceId === sourceId && item.targetId === targetId; });
    if (!wrap) return null;
    var sourcePos = layout.positions[sourceId] || source.position;
    var targetPos = layout.positions[targetId] || target.position;
    if (!sourcePos || !targetPos) return null;
    var sourceSize = layout.dimensions[sourceId] || nodeDimensions(source);
    var targetSize = layout.dimensions[targetId] || nodeDimensions(target);
    var sourceX = Number(sourcePos.x) + sourceSize.width;
    var sourceY = Number(sourcePos.y) + sourceSize.height / 2;
    var targetX = Number(targetPos.x);
    var targetY = Number(targetPos.y) + targetSize.height / 2;
    var outX = Number(layout.bounds.x) + Number(layout.bounds.width);
    var inX = Number(layout.bounds.x);
    var sourceRow = Number(layout.memberRows[sourceId]);
    var rowTop = Number.isFinite(sourceRow) ? Number(layout.rowTops[sourceRow]) : Number(sourcePos.y);
    var rowHeight = Number.isFinite(sourceRow) ? Number(layout.rowHeights[sourceRow]) : sourceSize.height;
    var laneY = rowTop + rowHeight + GROUP_LAYOUT.rowGap / 2;
    return {
      sourceId: sourceId,
      targetId: targetId,
      boundaryOut: { x: outX, y: sourceY },
      boundaryIn: { x: inX, y: targetY },
      points: [
        { x: sourceX, y: sourceY },
        { x: outX, y: sourceY },
        { x: outX, y: laneY },
        { x: inX, y: laneY },
        { x: inX, y: targetY },
        { x: targetX, y: targetY }
      ]
    };
  }

  function cloneValue(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function connectionSlots(node) {
    var slots = [];
    asArray(node && node.nextNodeIds).forEach(function (target, index) {
      var id = asId(target);
      if (id) slots.push({ kind: 'nextNodeIds', index: index, targetId: id });
    });
    [
      ['nextNodeIdOnExpiration', node && node.nextNodeIdOnExpiration],
      ['nextNodeIdOnDifferentAnswer', node && node.nextNodeIdOnDifferentAnswer],
      ['nextNodeIdOnConditionFalse', node && node.nextNodeIdOnConditionFalse]
    ].forEach(function (pair) {
      var id = asId(pair[1]);
      if (id) slots.push({ kind: pair[0], targetId: id });
    });
    var weights = node && node.data && Array.isArray(node.data.weights) ? node.data.weights : [];
    weights.forEach(function (weight, index) {
      var id = asId(weight && weight.nextNodeId);
      if (id) slots.push({ kind: 'weight', index: index, targetId: id });
    });
    return slots;
  }

  function canonicalSimpleOutputSlot(node) {
    if (!node) return null;
    if (node.type === 'condition' || node.type === 'randomizer' || node.type === 'userInput' || node.type === 'endHuman') return null;
    return { kind: 'nextNodeIds', index: 0, targetId: asId(asArray(node.nextNodeIds)[0]) || null };
  }

  function patchConnectionSlot(node, slot, targetId) {
    if (!node || !slot) return null;
    var fields = Object.create(null);
    var target = asId(targetId) || null;
    if (slot.kind === 'nextNodeIds') {
      var nextIds = asArray(node.nextNodeIds).slice();
      while (nextIds.length <= Number(slot.index || 0)) nextIds.push(null);
      nextIds[Number(slot.index || 0)] = target;
      fields.nextNodeIds = nextIds;
    } else if (slot.kind === 'weight') {
      var data = cloneValue(node.data || {});
      if (!Array.isArray(data.weights)) data.weights = [];
      while (data.weights.length <= Number(slot.index || 0)) data.weights.push({});
      data.weights[Number(slot.index || 0)] = Object.assign({}, data.weights[Number(slot.index || 0)] || {}, { nextNodeId: target });
      fields.data = data;
    } else {
      fields[slot.kind] = target;
    }
    return { id: asId(node.id), fields: fields };
  }

  function mergeNodePatch(targetMap, patch) {
    if (!patch || !patch.id) return;
    if (!targetMap[patch.id]) targetMap[patch.id] = { id: patch.id, fields: Object.create(null) };
    var targetFields = targetMap[patch.id].fields;
    Object.keys(patch.fields || {}).forEach(function (key) { targetFields[key] = cloneValue(patch.fields[key]); });
  }

  function buildSerialReorderPatch(flow, group, nextMemberIds) {
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    var members = asArray(group && group.memberNodeIds).map(asId).filter(Boolean);
    var requested = [];
    asArray(nextMemberIds).forEach(function (value) { var id = asId(value); if (id && requested.indexOf(id) < 0) requested.push(id); });
    if (requested.length !== members.length || requested.some(function (id) { return members.indexOf(id) < 0; })) {
      return { ok: false, reason: 'MEMBER_SET_MISMATCH', nodePatches: [] };
    }
    if (requested.some(function (id, index) {
      var node = byId[id];
      if (!node) return true;
      if (node.type === 'condition' || node.type === 'randomizer' || node.type === 'userInput') return true;
      return node.type === 'endHuman' && index !== requested.length - 1;
    })) {
      return { ok: false, reason: 'AMBIGUOUS_NODE_TYPE_FOR_REORDER', nodePatches: [] };
    }

    var topology = linearizeSerialSelection(flow, members);
    if (!topology.ok) return { ok: false, reason: topology.reason, nodePatches: [], topology: topology };
    var oldOrdered = topology.orderedNodeIds;
    if (oldOrdered.length !== members.length || oldOrdered.some(function (id) { return members.indexOf(id) < 0; })) {
      return { ok: false, reason: 'GROUP_TOPOLOGY_MISMATCH', nodePatches: [], topology: topology };
    }

    var outputSlotById = Object.create(null);
    for (var i = 0; i < oldOrdered.length; i += 1) {
      var nodeId = oldOrdered[i];
      var node = byId[nodeId];
      var slots = connectionSlots(node);
      if (slots.length > 1) return { ok: false, reason: 'AMBIGUOUS_OUTPUT_SLOT', nodePatches: [], topology: topology };
      outputSlotById[nodeId] = slots[0] || canonicalSimpleOutputSlot(node);
    }
    for (var requestedIndex = 0; requestedIndex < requested.length - 1; requestedIndex += 1) {
      if (!outputSlotById[requested[requestedIndex]]) {
        return { ok: false, reason: 'OUTPUT_SLOT_UNAVAILABLE', nodePatches: [], topology: topology };
      }
    }

    var externalIncoming = asArray(topology.externalIncoming)[0] || null;
    var externalExit = asArray(topology.externalOutgoing)[0] || null;
    var patches = Object.create(null);
    if (externalIncoming) {
      var incomingSource = byId[externalIncoming.sourceId];
      var incomingSlots = connectionSlots(incomingSource).filter(function (slot) { return slot.targetId === topology.entryNodeId; });
      if (incomingSlots.length !== 1) return { ok: false, reason: 'AMBIGUOUS_EXTERNAL_ENTRY_SLOT', nodePatches: [], topology: topology };
      mergeNodePatch(patches, patchConnectionSlot(incomingSource, incomingSlots[0], requested[0]));
    }

    requested.forEach(function (nodeId, index) {
      var node = byId[nodeId];
      var targetId = index < requested.length - 1 ? requested[index + 1] : (externalExit && externalExit.targetId || null);
      var slot = outputSlotById[nodeId];
      if (!slot && targetId) slot = canonicalSimpleOutputSlot(node);
      if (slot) mergeNodePatch(patches, patchConnectionSlot(node, slot, targetId));
    });

    return {
      ok: true,
      reason: null,
      nodePatches: Object.keys(patches).map(function (id) { return patches[id]; }),
      nextMemberNodeIds: requested,
      topology: topology
    };
  }

  function buildGroupMemberRemovalPatch(flow, group, removeNodeId) {
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    var members = asArray(group && group.memberNodeIds).map(asId).filter(Boolean);
    var removeId = asId(removeNodeId);
    if (!removeId || members.indexOf(removeId) < 0 || !byId[removeId]) {
      return { ok: false, reason: 'MEMBER_NOT_FOUND', nodePatches: [], nextMemberNodeIds: members, dissolveGroup: false };
    }
    var topology = linearizeSerialSelection(flow, members);
    if (!topology.ok) return { ok: false, reason: topology.reason, nodePatches: [], nextMemberNodeIds: members, dissolveGroup: false, topology: topology };
    var ordered = topology.orderedNodeIds;
    var index = ordered.indexOf(removeId);
    if (index < 0) return { ok: false, reason: 'GROUP_TOPOLOGY_MISMATCH', nodePatches: [], nextMemberNodeIds: members, dissolveGroup: false, topology: topology };

    var predecessorId = index > 0 ? ordered[index - 1] : null;
    var successorId = index < ordered.length - 1 ? ordered[index + 1] : null;
    var externalIncoming = asArray(topology.externalIncoming)[0] || null;
    var externalExit = asArray(topology.externalOutgoing)[0] || null;
    var patches = Object.create(null);

    if (predecessorId) {
      var predecessor = byId[predecessorId];
      var predecessorSlots = connectionSlots(predecessor).filter(function (slot) { return slot.targetId === removeId; });
      if (predecessorSlots.length !== 1) return { ok: false, reason: 'AMBIGUOUS_PREDECESSOR_SLOT', nodePatches: [], nextMemberNodeIds: members, dissolveGroup: false, topology: topology };
      mergeNodePatch(patches, patchConnectionSlot(predecessor, predecessorSlots[0], successorId || (externalExit && externalExit.targetId) || null));
    } else if (externalIncoming) {
      var incomingSource = byId[externalIncoming.sourceId];
      var incomingSlots = connectionSlots(incomingSource).filter(function (slot) { return slot.targetId === removeId; });
      if (incomingSlots.length !== 1) return { ok: false, reason: 'AMBIGUOUS_EXTERNAL_ENTRY_SLOT', nodePatches: [], nextMemberNodeIds: members, dissolveGroup: false, topology: topology };
      mergeNodePatch(patches, patchConnectionSlot(incomingSource, incomingSlots[0], successorId || (externalExit && externalExit.targetId) || null));
    }

    var removedNode = byId[removeId];
    var removedSlots = connectionSlots(removedNode);
    if (removedSlots.length > 1) return { ok: false, reason: 'AMBIGUOUS_REMOVED_OUTPUT_SLOT', nodePatches: [], nextMemberNodeIds: members, dissolveGroup: false, topology: topology };
    if (removedSlots[0]) mergeNodePatch(patches, patchConnectionSlot(removedNode, removedSlots[0], null));

    var nextMembers = ordered.filter(function (id) { return id !== removeId; });
    var layout = deriveGroupLayout(flow, group);
    var removedPosition = {
      x: layout.bounds.x + layout.bounds.width + GROUP_LAYOUT.columnGap,
      y: layout.bounds.y + GROUP_LAYOUT.paddingTop
    };
    return {
      ok: true,
      reason: null,
      nodePatches: Object.keys(patches).map(function (id) { return patches[id]; }),
      nextMemberNodeIds: nextMembers,
      dissolveGroup: nextMembers.length < 2,
      removedNodeId: removeId,
      removedPosition: removedPosition,
      topology: topology
    };
  }

  function buildGroupAwareOrganizePatch(flow) {
    var nodes = asArray(flow && flow.nodes);
    if (!nodes.length) return { ok: false, reason: 'FLOW_EMPTY', positions: Object.create(null) };
    var byId = Object.create(null);
    var order = Object.create(null);
    nodes.forEach(function (node, index) {
      var id = asId(node && node.id);
      if (!id) return;
      byId[id] = node;
      order[id] = index;
    });
    var groups = normalizeFlowNodeGroups(flow);
    var owner = Object.create(null);
    groups.forEach(function (group) { asArray(group.memberNodeIds).forEach(function (id) { owner[asId(id)] = group.id; }); });

    var entities = Object.create(null);
    var nodeEntity = Object.create(null);
    groups.forEach(function (group) {
      var key = 'group:' + group.id;
      var preview = deriveGroupLayout(flow, group, { anchorX: 0, anchorY: 0 });
      entities[key] = {
        key: key,
        type: 'group',
        group: group,
        order: Math.min.apply(Math, group.memberNodeIds.map(function (id) { return Number(order[id]); })),
        width: preview.bounds.width,
        height: preview.bounds.height,
        outgoing: []
      };
      group.memberNodeIds.forEach(function (id) { nodeEntity[id] = key; });
    });
    nodes.forEach(function (node) {
      var id = asId(node && node.id);
      if (!id || nodeEntity[id]) return;
      var key = 'node:' + id;
      nodeEntity[id] = key;
      var size = nodeDimensions(node);
      entities[key] = { key: key, type: 'node', nodeId: id, order: Number(order[id]) || 0, width: size.width, height: size.height, outgoing: [] };
    });

    nodes.forEach(function (node) {
      var sourceId = asId(node && node.id), sourceKey = nodeEntity[sourceId];
      if (!sourceKey || !entities[sourceKey]) return;
      outgoingTargets(node).forEach(function (targetId) {
        var targetKey = nodeEntity[targetId];
        if (!targetKey || targetKey === sourceKey || !entities[targetKey]) return;
        uniquePush(entities[sourceKey].outgoing, targetKey);
      });
    });

    var startNode = byId[asId(flow && flow.startNodeId)] || nodes.find(function (node) { return node && node.type === 'start'; }) || nodes[0];
    var startKey = startNode && nodeEntity[asId(startNode.id)];
    var depth = Object.create(null), queue = [];
    if (startKey) { depth[startKey] = 0; queue.push(startKey); }
    while (queue.length) {
      var current = queue.shift(), currentDepth = depth[current], entity = entities[current];
      asArray(entity && entity.outgoing).forEach(function (nextKey) {
        if (depth[nextKey] === undefined || depth[nextKey] > currentDepth + 1) {
          depth[nextKey] = currentDepth + 1;
          queue.push(nextKey);
        }
      });
    }
    var maxDepth = Object.keys(depth).reduce(function (max, key) { return Math.max(max, depth[key]); }, -1);
    Object.keys(entities).sort(function (a, b) { return entities[a].order - entities[b].order; }).forEach(function (key) {
      if (depth[key] === undefined) depth[key] = ++maxDepth;
    });

    var layers = Object.create(null);
    Object.keys(entities).forEach(function (key) { var d = depth[key] || 0; (layers[d] || (layers[d] = [])).push(entities[key]); });
    Object.keys(layers).forEach(function (d) { layers[d].sort(function (a, b) { return a.order - b.order; }); });
    var depthKeys = Object.keys(layers).map(Number).sort(function (a, b) { return a - b; });
    var xByDepth = Object.create(null), cursorX = 90, horizontalGap = 140;
    depthKeys.forEach(function (d) {
      xByDepth[d] = cursorX;
      var maxWidth = layers[d].reduce(function (max, entity) { return Math.max(max, entity.width || GROUP_LAYOUT.nodeWidth); }, GROUP_LAYOUT.nodeWidth);
      cursorX += maxWidth + horizontalGap;
    });

    var wave = [0, 110, -70, 150, 35, -115, 90, -35], baseY = 280, verticalGap = 90;
    var entityPositions = Object.create(null), minY = Infinity;
    depthKeys.forEach(function (d) {
      var layer = layers[d], center = baseY + wave[d % wave.length];
      var totalHeight = layer.reduce(function (sum, entity) { return sum + (entity.height || GROUP_LAYOUT.nodeHeight); }, 0) + Math.max(0, layer.length - 1) * verticalGap;
      var y = center - totalHeight / 2;
      layer.forEach(function (entity) {
        var snappedY = Math.round(y / 20) * 20;
        entityPositions[entity.key] = { x: xByDepth[d], y: snappedY };
        minY = Math.min(minY, snappedY);
        y += (entity.height || GROUP_LAYOUT.nodeHeight) + verticalGap;
      });
    });
    var shiftY = minY < 60 ? Math.ceil((60 - minY) / 20) * 20 : 0;
    var positions = Object.create(null);
    Object.keys(entities).forEach(function (key) {
      var entity = entities[key], entityPos = entityPositions[key] || { x: 90, y: 280 };
      entityPos = { x: entityPos.x, y: entityPos.y + shiftY };
      if (entity.type === 'node') {
        positions[entity.nodeId] = entityPos;
        return;
      }
      var layout = deriveGroupLayout(flow, entity.group, { anchorX: entityPos.x, anchorY: entityPos.y });
      Object.keys(layout.positions).forEach(function (nodeId) { positions[nodeId] = { x: layout.positions[nodeId].x, y: layout.positions[nodeId].y }; });
    });
    return { ok: true, reason: null, positions: positions, entityPositions: entityPositions };
  }

  function analyzeSelectionActions(flow, selectionKeys) {
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    var startIds = new Set();
    nodes.forEach(function (node) {
      var id = asId(node && node.id);
      if (!id) return;
      byId[id] = node;
      if (node.type === 'start') startIds.add(id);
    });

    var groups = normalizeFlowNodeGroups(flow);
    var groupMap = Object.create(null);
    var memberOwner = Object.create(null);
    groups.forEach(function (group) {
      groupMap[group.id] = group;
      asArray(group.memberNodeIds).forEach(function (nodeId) { memberOwner[asId(nodeId)] = group.id; });
    });

    var groupIds = [];
    var looseNodeIds = [];
    asArray(selectionKeys).forEach(function (key) {
      var raw = asId(key);
      if (!raw) return;
      if (raw.indexOf('group:') === 0) {
        var groupId = raw.slice(6);
        if (groupMap[groupId]) uniquePush(groupIds, groupId);
        return;
      }
      var nodeId = raw.indexOf('node:') === 0 ? raw.slice(5) : raw;
      if (!nodeId || !byId[nodeId] || startIds.has(nodeId)) return;
      uniquePush(looseNodeIds, nodeId);
    });

    // If a selected group already owns a selected member, the member is not a second
    // independent entity for action enablement. expandSelectionEntities still dedupes it.
    var selectedGroupSet = new Set(groupIds);
    looseNodeIds = looseNodeIds.filter(function (nodeId) {
      var ownerId = memberOwner[nodeId];
      return !ownerId || !selectedGroupSet.has(ownerId);
    });

    var normalizedKeys = groupIds.map(function (id) { return 'group:' + id; })
      .concat(looseNodeIds.map(function (id) { return 'node:' + id; }));
    var expandedNodeIds = expandSelectionEntities(normalizedKeys, groups)
      .filter(function (nodeId) { return !!byId[nodeId] && !startIds.has(nodeId); });

    var groupingBlockedByMembership = looseNodeIds.some(function (nodeId) { return !!memberOwner[nodeId]; });
    var topology = null;
    var canGroup = false;
    if (groupIds.length === 0 && !groupingBlockedByMembership && looseNodeIds.length >= 2) {
      topology = analyzeGroupSelectionTopology(flow, looseNodeIds);
      canGroup = !!topology.ok;
    }

    return {
      groupIds: groupIds,
      looseNodeIds: looseNodeIds,
      expandedNodeIds: expandedNodeIds,
      canMove: expandedNodeIds.length > 0,
      canGroup: canGroup,
      canEditGroup: groupIds.length === 1,
      canDelete: expandedNodeIds.length > 0,
      groupingReason: canGroup ? null : (topology && topology.reason) || (groupIds.length ? 'GROUP_SELECTION_PRESENT' : groupingBlockedByMembership ? 'ALREADY_GROUPED_MEMBER' : looseNodeIds.length < 2 ? 'SELECTION_TOO_SMALL' : null),
      topology: topology
    };
  }

  function buildGroupCreation(flow, nodeIds, options) {
    var opts = options || {};
    var nodes = asArray(flow && flow.nodes);
    var byId = Object.create(null);
    nodes.forEach(function (node) { var id = asId(node && node.id); if (id) byId[id] = node; });
    var selected = [];
    asArray(nodeIds).forEach(function (value) {
      var id = asId(value);
      if (!id || selected.indexOf(id) >= 0) return;
      selected.push(id);
    });

    var groups = normalizeFlowNodeGroups(flow);
    var owned = new Set();
    groups.forEach(function (group) { asArray(group.memberNodeIds).forEach(function (id) { owned.add(asId(id)); }); });
    if (selected.some(function (id) { return owned.has(id); })) {
      return { ok: false, reason: 'ALREADY_GROUPED_MEMBER', group: null, positionPatches: Object.create(null) };
    }

    var topology = analyzeGroupSelectionTopology(flow, selected);
    if (!topology.ok) {
      return { ok: false, reason: topology.reason || 'INVALID_GROUP_TOPOLOGY', group: null, positionPatches: Object.create(null), topology: topology };
    }

    var now = Number(opts.nowInMs);
    if (!Number.isFinite(now) || now <= 0) now = nowMs();
    var groupId = asId(opts.groupId);
    if (!groupId) groupId = 'group-' + now + '-' + Math.random().toString(36).slice(2, 8);
    if (groups.some(function (group) { return group.id === groupId; })) {
      return { ok: false, reason: 'GROUP_ID_DUPLICATE', group: null, positionPatches: Object.create(null), topology: topology };
    }
    var group = {
      id: groupId,
      name: String(opts.groupName || ('Grupo ' + (groups.length + 1))),
      memberNodeIds: topology.orderedNodeIds.slice(),
      layoutMode: opts.layoutMode === 'free' ? 'free' : 'structured',
      layoutRevision: 1,
      collapsed: false,
      createdAtInMs: now,
      updatedAtInMs: now
    };
    var tempFlow = { nodes: nodes, nodeGroups: groups.concat([group]) };
    var organizeBefore = opts.organizeBefore !== false;
    var layoutGroup = group.layoutMode === 'free' && organizeBefore ? Object.assign({}, group, { layoutMode: 'structured' }) : group;
    var layout = deriveGroupLayout(tempFlow, layoutGroup);
    var positionPatches = Object.create(null);
    group.memberNodeIds.forEach(function (nodeId) {
      if (layout.positions[nodeId]) positionPatches[nodeId] = { x: layout.positions[nodeId].x, y: layout.positions[nodeId].y };
    });
    return {
      ok: true,
      reason: null,
      group: group,
      topology: topology,
      positionPatches: positionPatches,
      bounds: layout.bounds
    };
  }

  var GROUP_VIEW_PREFIX = '__ext-group__:';

  function groupViewNodeId(groupId) {
    var id = asId(groupId);
    return id ? GROUP_VIEW_PREFIX + id : '';
  }

  function parseGroupViewNodeId(nodeId) {
    var id = asId(nodeId);
    return id.indexOf(GROUP_VIEW_PREFIX) === 0 ? id.slice(GROUP_VIEW_PREFIX.length) : '';
  }

  function findGroupContainingNode(flow, nodeId) {
    var id = asId(nodeId);
    if (!id) return null;
    var groups = normalizeFlowNodeGroups(flow);
    for (var i = 0; i < groups.length; i += 1) {
      if (asArray(groups[i].memberNodeIds).indexOf(id) >= 0) return groups[i];
    }
    return null;
  }

  function resolveExternalAppendSource(flow, nodeId) {
    var id = asId(nodeId);
    if (!id) return '';
    var group = findGroupContainingNode(flow, id);
    if (!group) return id;
    var topology = analyzeGroupSelectionTopology(flow, asArray(group.memberNodeIds));
    if (topology && topology.ok) {
      var exits = asArray(topology.exitNodeIds).map(asId).filter(Boolean);
      if (exits.indexOf(id) >= 0) return id;
      if (exits.length === 1) return exits[0];
      // A branched group has no single canonical exit. Keep the user's
      // selected member rather than silently jumping to an arbitrary sibling.
      return id;
    }
    return groupExitId(group) || id;
  }

  function boundaryHandleHash(text) {
    var hash=2166136261; text=String(text||'');
    for(var i=0;i<text.length;i+=1){hash^=text.charCodeAt(i);hash=Math.imul(hash,16777619);}
    return (hash>>>0).toString(36);
  }
  function boundaryHandleId(direction,nodeId,edge) {
    var semantic=[asId(edge&&edge.id),asId(edge&&edge.source),String(edge&&edge.sourceHandle||''),asId(edge&&edge.target),String(edge&&edge.targetHandle||'')].join('|');
    return 'group-'+direction+':'+encodeURIComponent(asId(nodeId))+':'+boundaryHandleHash(semantic);
  }
  function parseBoundaryHandleNodeId(handleId,direction) {
    var prefix='group-'+direction+':', raw=String(handleId||''); if(raw.indexOf(prefix)!==0)return'';
    var rest=raw.slice(prefix.length), split=rest.lastIndexOf(':'); if(split<0)return'';
    try{return decodeURIComponent(rest.slice(0,split));}catch(e){return rest.slice(0,split);}
  }
  function deriveGroupBoundaryPorts(flow, group, edges) {
    if(!group)return{inputs:[],outputs:[]};
    var members=new Set(asArray(group.memberNodeIds).map(asId)), layout=deriveGroupLayout(flow,group), nodes=asArray(flow&&flow.nodes), byId=Object.create(null);
    nodes.forEach(function(n){var id=asId(n&&n.id);if(id)byId[id]=n;});
    var semanticEdges=asArray(edges);
    if(!semanticEdges.length){
      nodes.forEach(function(node){var source=asId(node&&node.id);outgoingTargets(node).forEach(function(target){semanticEdges.push({id:'semantic:'+source+':'+target,source:source,target:target,sourceHandle:null,targetHandle:null});});});
    }
    var inputs=[],outputs=[];
    semanticEdges.forEach(function(edge){
      var source=asId(edge&&edge.source),target=asId(edge&&edge.target),sourceInside=members.has(source),targetInside=members.has(target);
      if(sourceInside===targetInside)return;
      var memberId=sourceInside?source:target, node=byId[memberId], pos=layout.positions[memberId]||(node&&node.position)||{x:layout.bounds.x,y:layout.bounds.y}, size=layout.dimensions[memberId]||nodeDimensions(node);
      if(targetInside){var y=Number(pos.y)+size.height/2;inputs.push({direction:'in',edgeId:asId(edge.id),nodeId:memberId,handleId:boundaryHandleId('in',memberId,edge),boundary:{x:layout.bounds.x,y:y},member:{x:Number(pos.x),y:y}});}
      else {var y2=Number(pos.y)+size.height/2;outputs.push({direction:'out',edgeId:asId(edge.id),nodeId:memberId,handleId:boundaryHandleId('out',memberId,edge),boundary:{x:layout.bounds.x+layout.bounds.width,y:y2},member:{x:Number(pos.x)+size.width,y:y2}});}
    });
    // A collapsed group must remain connectable even when a branch has no current
    // external edge. Expose one latent boundary port per topological entry/exit
    // member that is not already represented by a crossing semantic edge.
    var topology=analyzeGroupSelectionTopology(flow,asArray(group.memberNodeIds));
    function addLatent(direction,nodeId){
      if(!nodeId||!byId[nodeId])return;
      var list=direction==='in'?inputs:outputs;
      if(list.some(function(port){return port.nodeId===nodeId;}))return;
      var node=byId[nodeId],pos=layout.positions[nodeId]||(node.position||{x:layout.bounds.x,y:layout.bounds.y}),size=layout.dimensions[nodeId]||nodeDimensions(node),y=Number(pos.y)+size.height/2;
      var pseudo=direction==='in'?{id:'latent-in:'+nodeId,source:'',target:nodeId}:{id:'latent-out:'+nodeId,source:nodeId,target:''};
      list.push({direction:direction,edgeId:'',nodeId:nodeId,latent:true,handleId:boundaryHandleId(direction,nodeId,pseudo),boundary:{x:direction==='in'?layout.bounds.x:layout.bounds.x+layout.bounds.width,y:y},member:{x:direction==='in'?Number(pos.x):Number(pos.x)+size.width,y:y}});
    }
    if(topology&&topology.ok){asArray(topology.entryNodeIds).forEach(function(id){addLatent('in',id);});asArray(topology.exitNodeIds).forEach(function(id){addLatent('out',id);});}
    inputs.sort(function(a,b){return a.boundary.y-b.boundary.y||a.handleId.localeCompare(b.handleId);});outputs.sort(function(a,b){return a.boundary.y-b.boundary.y||a.handleId.localeCompare(b.handleId);});
    return {inputs:inputs,outputs:outputs,entry:inputs[0]||null,exit:outputs[0]||null};
  }
  function deriveGroupExternalPorts(flow, group, edges) { return deriveGroupBoundaryPorts(flow,group,edges); }

  function deriveVisualGroupEdge(flow, edge) {
    if(!edge||typeof edge!=='object')return edge;var out=Object.assign({},edge),sourceGroup=findGroupContainingNode(flow,out.source),targetGroup=findGroupContainingNode(flow,out.target);
    if(sourceGroup&&(!targetGroup||targetGroup.id!==sourceGroup.id)){out.source=groupViewNodeId(sourceGroup.id);out.sourceHandle=boundaryHandleId('out',edge.source,edge);}
    if(targetGroup&&(!sourceGroup||sourceGroup.id!==targetGroup.id)){out.target=groupViewNodeId(targetGroup.id);out.targetHandle=boundaryHandleId('in',edge.target,edge);}
    return out;
  }

  function resolveGroupProxyConnection(flow, connection) {
    var input=connection||{},out=Object.assign({},input),sourceGroupId=parseGroupViewNodeId(out.source),targetGroupId=parseGroupViewNodeId(out.target),groups=normalizeFlowNodeGroups(flow);
    var sourceGroup=sourceGroupId?groups.find(function(g){return g.id===sourceGroupId;}):null,targetGroup=targetGroupId?groups.find(function(g){return g.id===targetGroupId;}):null;
    out.sourceWasGroupProxy=!!sourceGroup;out.targetWasGroupProxy=!!targetGroup;
    if(sourceGroup)out.source=parseBoundaryHandleNodeId(out.sourceHandle,'out')||groupExitId(sourceGroup)||out.source;
    if(targetGroup)out.target=parseBoundaryHandleNodeId(out.targetHandle,'in')||groupEntryId(targetGroup)||out.target;
    return out;
  }

  function deriveExternalAppendPlacement(flow, nodeId, options) {
    var id = asId(nodeId);
    var group = findGroupContainingNode(flow, id);
    if (!group) return null;
    var layout = deriveGroupLayout(flow, group);
    var sourceNodeId = resolveExternalAppendSource(flow, id);
    var sourcePos = layout.positions[sourceNodeId];
    if (!sourceNodeId || !sourcePos) return null;
    var opts = options || {};
    var gap = Number(opts.gap);
    if (!Number.isFinite(gap) || gap < GROUP_LAYOUT.gridSize) gap = 80;
    function snap(value) { return Math.round(Number(value || 0) / GROUP_LAYOUT.gridSize) * GROUP_LAYOUT.gridSize; }
    return {
      groupId: group.id,
      sourceNodeId: sourceNodeId,
      bounds: layout.bounds,
      position: {
        x: snap(layout.bounds.x + layout.bounds.width + gap),
        y: snap(sourcePos.y)
      }
    };
  }

  var COLLAPSED_GROUP_SIZE = Object.freeze({ width: 220, height: 84 });

  function collapsedGroupView(flow, group, options) {
    if (!group) return null;
    var opts = options || {};
    var layout = deriveGroupLayout(flow, group, opts);
    var topology = analyzeGroupSelectionTopology(flow, asArray(group.memberNodeIds));
    var entryNodeId = topology.entryNodeId || groupEntryId(group);
    var exitNodeId = topology.exitNodeId || groupExitId(group);
    if (!layout || !layout.bounds) return null;
    return {
      id: asId(group.id),
      name: String(group.name || 'Grupo'),
      memberCount: asArray(group.memberNodeIds).length,
      position: { x: Number(layout.bounds.x) || 0, y: Number(layout.bounds.y) || 0 },
      width: COLLAPSED_GROUP_SIZE.width,
      height: COLLAPSED_GROUP_SIZE.height,
      entryNodeId: entryNodeId,
      exitNodeId: exitNodeId,
      entryNodeIds: topology.entryNodeIds || [],
      exitNodeIds: topology.exitNodeIds || [],
      bounds: layout.bounds
    };
  }

  function projectCollapsedEdges(flow, groups, edges, groupNodeIdFn) {
    var normalizedGroups=asArray(groups).filter(function(group){return group&&group.collapsed===true;});
    if(!normalizedGroups.length)return asArray(edges).map(function(edge){return Object.assign({},edge);});
    var nodeOwner=Object.create(null);normalizedGroups.forEach(function(group){asArray(group.memberNodeIds).forEach(function(nodeId){nodeOwner[asId(nodeId)]=group;});});
    var makeGroupNodeId=typeof groupNodeIdFn==='function'?groupNodeIdFn:groupViewNodeId,out=[];
    asArray(edges).forEach(function(edge){if(!edge||typeof edge!=='object')return;var sourceId=asId(edge.source),targetId=asId(edge.target),sourceGroup=nodeOwner[sourceId]||null,targetGroup=nodeOwner[targetId]||null;if(sourceGroup&&targetGroup&&sourceGroup.id===targetGroup.id)return;var projected=Object.assign({},edge);if(sourceGroup){projected.source=makeGroupNodeId(sourceGroup.id);projected.sourceHandle=boundaryHandleId('out',sourceId,edge);}if(targetGroup){projected.target=makeGroupNodeId(targetGroup.id);projected.targetHandle=boundaryHandleId('in',targetId,edge);}out.push(projected);});
    return out;
  }

  function planConnectionRemoval(flow, semanticEdges, candidateEdge) {
    var candidate = candidateEdge && typeof candidateEdge === 'object' ? candidateEdge : null;
    if (!candidate) return { ok: false, reason: 'EDGE_REQUIRED', edge: null, requiresUngroup: false, groupId: null };
    var candidateId = asId(candidate.id);
    var semantic = null;
    if (candidateId) {
      semantic = asArray(semanticEdges).find(function (edge) { return edge && asId(edge.id) === candidateId; }) || null;
    }
    if (!semantic) semantic = candidate;
    var sourceId = asId(semantic.source);
    var targetId = asId(semantic.target);
    if (!sourceId || !targetId) return { ok: false, reason: 'EDGE_ENDPOINTS_REQUIRED', edge: null, requiresUngroup: false, groupId: null };
    var sourceGroup = findGroupContainingNode(flow, sourceId);
    var targetGroup = findGroupContainingNode(flow, targetId);
    var internalGroup = sourceGroup && targetGroup && sourceGroup.id === targetGroup.id ? sourceGroup : null;
    return {
      ok: true,
      reason: null,
      edge: {
        id: asId(semantic.id),
        source: sourceId,
        sourceHandle: semantic.sourceHandle == null ? null : String(semantic.sourceHandle),
        target: targetId,
        targetHandle: semantic.targetHandle == null ? null : String(semantic.targetHandle)
      },
      requiresUngroup: false,
      requiresGroupRepair: !!internalGroup,
      groupId: internalGroup ? internalGroup.id : null
    };
  }

  function repairGroupAfterMutation(flow, groupId, options) {
    var id=asId(groupId),group=normalizeFlowNodeGroups(flow).find(function(item){return item.id===id;});
    if(!group)return{ok:false,reason:'GROUP_NOT_FOUND',positionPatches:Object.create(null),bounds:null,group:null};
    var validIds=new Set(asArray(flow&&flow.nodes).map(function(n){return asId(n&&n.id);}).filter(Boolean));
    var nextMembers=asArray(group.memberNodeIds).map(asId).filter(function(nodeId,index,list){return validIds.has(nodeId)&&list.indexOf(nodeId)===index;});
    if(nextMembers.length<2)return{ok:true,reason:null,dissolveGroup:true,positionPatches:Object.create(null),bounds:null,group:Object.assign({},group,{memberNodeIds:nextMembers})};
    var nextGroup=Object.assign({},group,{memberNodeIds:nextMembers,layoutRevision:Math.max(0,Number(group.layoutRevision)||0)+1,updatedAtInMs:nowMs()});
    var tempFlow=Object.assign({},flow,{nodeGroups:normalizeFlowNodeGroups(flow).map(function(item){return item.id===id?nextGroup:item;})});
    var layout=deriveGroupLayout(tempFlow,nextGroup),patches=Object.create(null);
    if(nextGroup.layoutMode!=='free')nextMembers.forEach(function(nodeId){if(layout.positions[nodeId])patches[nodeId]={x:layout.positions[nodeId].x,y:layout.positions[nodeId].y};});
    return{ok:true,reason:null,dissolveGroup:false,positionPatches:patches,bounds:layout.bounds,group:nextGroup,topology:layout.topology||null};
  }


  function normalizeRect(rect) {
    var x = Number(rect && rect.x) || 0;
    var y = Number(rect && rect.y) || 0;
    var width = Number(rect && rect.width) || 0;
    var height = Number(rect && rect.height) || 0;
    if (width < 0) { x += width; width = -width; }
    if (height < 0) { y += height; height = -height; }
    return { x: x, y: y, width: width, height: height };
  }

  function rectsIntersectPositive(a, b) {
    var ra = normalizeRect(a);
    var rb = normalizeRect(b);
    var width = Math.min(ra.x + ra.width, rb.x + rb.width) - Math.max(ra.x, rb.x);
    var height = Math.min(ra.y + ra.height, rb.y + rb.height) - Math.max(ra.y, rb.y);
    return width > 0 && height > 0;
  }

  root.ExtensionFlowGroupsCore = Object.freeze({
    GROUP_LAYOUT: GROUP_LAYOUT,
    nodeDimensions: nodeDimensions,
    normalizeFlowNodeGroups: normalizeFlowNodeGroups,
    validateFlowNodeGroups: validateFlowNodeGroups,
    remapNodeGroups: remapNodeGroups,
    groupEntryId: groupEntryId,
    groupExitId: groupExitId,
    analyzeGroupSelectionTopology: analyzeGroupSelectionTopology,
    linearizeSerialSelection: linearizeSerialSelection,
    expandSelectionEntities: expandSelectionEntities,
    deriveGroupLayout: deriveGroupLayout,
    deriveStructuredGroupLayout: deriveStructuredGroupLayout,
    deriveFreeGroupLayout: deriveFreeGroupLayout,
    buildGroupWrapPath: buildGroupWrapPath,
    canonicalizeFlowGroupPositions: canonicalizeFlowGroupPositions,
    analyzeSelectionActions: analyzeSelectionActions,
    buildGroupCreation: buildGroupCreation,
    buildSerialReorderPatch: buildSerialReorderPatch,
    buildGroupMemberRemovalPatch: buildGroupMemberRemovalPatch,
    buildGroupAwareOrganizePatch: buildGroupAwareOrganizePatch,
    groupViewNodeId: groupViewNodeId,
    parseGroupViewNodeId: parseGroupViewNodeId,
    findGroupContainingNode: findGroupContainingNode,
    resolveExternalAppendSource: resolveExternalAppendSource,
    deriveGroupExternalPorts: deriveGroupExternalPorts,
    deriveGroupBoundaryPorts: deriveGroupBoundaryPorts,
    deriveVisualGroupEdge: deriveVisualGroupEdge,
    resolveGroupProxyConnection: resolveGroupProxyConnection,
    deriveExternalAppendPlacement: deriveExternalAppendPlacement,
    collapsedGroupView: collapsedGroupView,
    projectCollapsedEdges: projectCollapsedEdges,
    planConnectionRemoval: planConnectionRemoval,
    repairGroupAfterMutation: repairGroupAfterMutation,
    rectsIntersectPositive: rectsIntersectPositive
  });
})(typeof window !== 'undefined' ? window : globalThis);
