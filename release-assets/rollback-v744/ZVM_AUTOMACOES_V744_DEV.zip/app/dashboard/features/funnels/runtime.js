;
try{
(function () {
  "use strict";

  if (window.__extFunisModuleBooted) return;
  window.__extFunisModuleBooted = true;

  var FUNNEL_STORE_KEY = "EXTUI:extappFunnelStore";
  var RUNNING_STORE_KEY = "EXTUI:extappFunnelRunningStore";
  var QUICK_ITEMS_RECENTS_KEY = "EXTUI:quickItemsRecents";
  var AI_ASSISTANTS_STORE_KEY = "EXTUI:aiAssistantsStore";
  var AI_AGENTS_STORE_KEY = "EXTUI:aiAgentsStore";
  var funnelsCore = window.__extFunnelsCore;
  var assistantsCore = window.__extAiAssistantsCore;
  var agentsCore = window.__extAiAgentsCore;
  var integrationCore = window.__extIntegrationCore;
  var ITEM_STORAGE_BY_TYPE = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList" },
    audio: { key: "EXTUI:audioStore", listField: "audioList" },
    image: { key: "EXTUI:mediaStore", listField: "mediaList", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", listField: "mediaList", virtualMediaKind: "video" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList", legacyOnly: true },
    sticker: { key: "EXTUI:stickerStore", listField: "stickerList" },
    document: { key: "EXTUI:documentStore", listField: "documentList" },
    pix: { key: "EXTUI:pixStore", listField: "pixList" },
    "interactive-list": { key: "EXTUI:interactiveListStore", listField: "interactiveListList" },
    contact: { key: "EXTUI:contactCardStore", listField: "contactList" },
    signature: { key: "EXTUI:signaturesStore", listField: "list", plainSignatureStore: true }
  };
  var TYPE_LABELS = { message: "Mensagem", audio: "Áudio", image: "Imagem", video: "Vídeo", media: "Imagem/Vídeo (legado)", sticker: "Figurinha", document: "Documento", pix: "PIX", "interactive-list": "Lista", contact: "Contato", signature: "Assinatura", aiGenerate: "Gerar com IA", aiAgent: "Executar Agente" };
  var DELAY_UNIT_LABELS = { seconds: "segundos", minutes: "minutos", hours: "horas" };

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "id-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
  }
  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }


                                                                       
                                                                          
                                               
  var ICONS = {
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    audio: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
    video: '<rect x="3" y="5" width="14" height="14" rx="2"/><path d="m17 9 4-2v10l-4-2z"/>',
    media: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    sticker: '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>',
    document: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
    pix: '<path d="M7.5 6.5 12 2l4.5 4.5L12 11z"/><path d="M7.5 17.5 12 13l4.5 4.5L12 22z"/><path d="m2 12 4.5-4.5L11 12l-4.5 4.5z"/><path d="m13 12 4.5-4.5L22 12l-4.5 4.5z"/>',
    "interactive-list": '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
    contact: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    signature: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4z"/>',
    funnel: '<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>',
    edit: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
    chevronUp: '<path d="m18 15-6-6-6 6"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    arrowLeft: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    activity: '<path d="M3 12h4l3-7 4 14 3-7h4"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    play: '<path d="m6 3 14 9-14 9z"/>',
    aiGenerate: '<path d="m12 3-1.9 4.8a2 2 0 0 1-1.1 1.1L4.2 10.8 9 12.7a2 2 0 0 1 1.1 1.1L12 18.6l1.9-4.8a2 2 0 0 1 1.1-1.1l4.8-1.9L15 8.9a2 2 0 0 1-1.1-1.1Z"/><path d="M5 3v4M3 5h4M19 17v4M17 19h4"/>',
    aiAgent: '<rect x="3" y="8" width="18" height="12" rx="3"/><path d="M12 4v4M8 13h.01M16 13h.01M8 17h8"/>',
    external: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>'
  };
  function icon(name, extraClass) {
    var span = document.createElement("span");
    span.className = "extui-svgicon" + (extraClass ? " " + extraClass : "");
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || "") + "</svg>";
    return span;
  }

  function storageGet(key) {
    return window.__extDashboardShell.storageGet(key).then(function (result) { return result ? result[key] : undefined; });
  }
  function storageSet(key, value) {
    var obj = {}; obj[key] = value;
    return window.__extDashboardShell.storageSet(obj);
  }
  function parsePersisted(raw) {
    if (raw == null || raw === "") return null;
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); }
      catch (err) { err.code = err.code || "FUNNEL_STORE_CORRUPT"; throw err; }
    }
    var state = raw && raw.state != null ? raw.state : raw;
    if (typeof state === "string") {
      try { state = JSON.parse(state); }
      catch (err2) { err2.code = err2.code || "FUNNEL_STORE_CORRUPT"; throw err2; }
    }
    if (!state || typeof state !== "object" || Array.isArray(state)) {
      var invalid = new Error("Os dados de Funis estão inválidos e não serão sobrescritos.");
      invalid.code = "FUNNEL_STORE_CORRUPT";
      throw invalid;
    }
    return state;
  }
  async function loadFunnels() {
    var raw = await storageGet(FUNNEL_STORE_KEY);
    var state = parsePersisted(raw) || {};
    return Array.isArray(state.funnelList) ? state.funnelList.filter(function (item) { return item && typeof item === "object"; }) : [];
  }
  function mutateFunnelStore(action, payload) {
    var cancelEcho=window.ExtensionStorage&&typeof window.ExtensionStorage.expectLocalEcho==="function"?window.ExtensionStorage.expectLocalEcho([FUNNEL_STORE_KEY],1500):null;
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage({ type:"EXTUI_DATA_MUTATE", scope:"funnels", action:action, payload:payload || {} }, function (response) {
          if (chrome.runtime.lastError) { if(typeof cancelEcho==="function")cancelEcho(); reject(new Error(chrome.runtime.lastError.message)); return; }
          if (!response || response.ok !== true) { if(typeof cancelEcho==="function")cancelEcho(); var err = new Error(response && response.userMessage || "Não foi possível salvar o funil."); err.code = response && response.errorCode || "FUNNEL_SAVE_FAILED"; reject(err); return; }
          if(typeof cancelEcho==="function")setTimeout(cancelEcho,250); resolve(response.result || {});
        });
      } catch (err) { if(typeof cancelEcho==="function")cancelEcho(); reject(err); }
    });
  }
  async function saveFunnels(funnelList) {
    try { await mutateFunnelStore("replace_all", { funnels:Array.isArray(funnelList) ? funnelList : [] }); }
    catch (_) { await storageSet(FUNNEL_STORE_KEY, JSON.stringify({ state: { funnelList: Array.isArray(funnelList) ? funnelList : [] }, version: 0 })); }
    var verified = await loadFunnels();
    if (verified.length !== (Array.isArray(funnelList) ? funnelList.length : 0)) throw new Error("A extensão não conseguiu confirmar o salvamento dos funis.");
    return verified;
  }
  async function saveFunnelDefinition(funnel) {
    var clean = funnelsCore ? funnelsCore.serializeDefinition(funnel) : Object.assign({},funnel);
    clean.createdAtInMs=Math.max(0,Number(clean.createdAtInMs)||Date.now());clean.updatedAtInMs=Date.now();
    try { await mutateFunnelStore("upsert", { funnel:clean }); }
    catch (_) { var all = await loadFunnels(), idx = all.findIndex(function (f) { return f.id === clean.id; }); if (idx >= 0) all[idx] = clean; else all.push(clean); await saveFunnels(all); }
    var verified = (await loadFunnels()).find(function (f) { return f && f.id === clean.id; });
    if (!verified) throw new Error("O funil não permaneceu salvo após a gravação.");
    return verified;
  }
  async function removeFunnelDefinition(id) {
    try { await mutateFunnelStore("remove", { id:id }); }
    catch (_) { var all = await loadFunnels(); await saveFunnels(all.filter(function (f) { return f.id !== id; })); }
    if ((await loadFunnels()).some(function (f) { return f && f.id === id; })) throw new Error("O funil não pôde ser removido.");
  }
  async function loadRunning() {
    var raw = await storageGet(RUNNING_STORE_KEY);
    var state = parsePersisted(raw);
    return (state && state.runningList) || [];
  }
  async function loadRunningCounts() {
    var list = await loadRunning();
    var counts = {};
    list.forEach(function (r) {
      if (r.status === "running") counts[r.funnelId] = (counts[r.funnelId] || 0) + 1;
    });
    return counts;
  }
  async function funnelMediaKind(item){if(item&&(item.mediaKind==="image"||item.mediaKind==="video"))return item.mediaKind;if(!item||!item.id)return"unknown";try{var raw=await storageGet(String(item.id)),c=raw?(typeof raw==="string"?JSON.parse(raw):raw):{},mime=String(c.mimeType||c.type||"").toLowerCase(),name=String(c.fileName||c.name||item.name||"").toLowerCase(),data=String(c.data||c.base64||"");if(c.mediaKind==="image"||c.mediaKind==="video")return c.mediaKind;if(/^data:video\//i.test(data)||mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name))return"video";if(/^data:image\//i.test(data)||mime.indexOf("image/")===0||/\.(png|jpe?g|gif|webp|bmp|avif|heic|heif)$/.test(name))return"image";return"unknown";}catch(_){return"unknown";}}
  async function loadItemsForType(type) {
    var config = ITEM_STORAGE_BY_TYPE[type];
    if (!config) return [];
    var values = await Promise.all([storageGet(config.key), storageGet(QUICK_ITEMS_RECENTS_KEY)]);
    var raw = values[0];
    var parsed = null;
    try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; } catch (_) { parsed = null; }
    var list = [];
    if (config.plainSignatureStore) {
      if (window.ExtensionSignatureStore && typeof window.ExtensionSignatureStore.list === "function") {
        try { list = await window.ExtensionSignatureStore.list(); } catch (_) { list = []; }
      } else if (Array.isArray(parsed)) list = parsed;
      else if (parsed && parsed.state && Array.isArray(parsed.state.list)) list = parsed.state.list;
      else if (parsed && Array.isArray(parsed.list)) list = parsed.list;
    } else list = (parsed && parsed.state && parsed.state[config.listField]) || [];
    if(config.virtualMediaKind){var filtered=[];for(var mi=0;mi<list.length;mi++)if(await funnelMediaKind(list[mi])===config.virtualMediaKind)filtered.push(list[mi]);list=filtered;}
    var recentRank = {};
    (Array.isArray(values[1]) ? values[1] : []).forEach(function (recent, index) { if (recent && recent.type === type) recentRank[recent.id] = index; });
    return list.map(function (item, index) {
      var displayName = (type === "document" ? (item.fileName || item.name || item.displayName) : (type === "signature" ? (item.name || item.title) : item.name)) || item.id;
      return { id: item.id, displayName: displayName, favorite: !!item.favorite, recentRank: Object.prototype.hasOwnProperty.call(recentRank, item.id) ? recentRank[item.id] : Infinity, originalIndex: index };
    }).sort(function (a, b) {
      if (a.favorite !== b.favorite) return a.favorite ? -1 : 1;
      if (a.recentRank !== b.recentRank) return a.recentRank - b.recentRank;
      return a.originalIndex - b.originalIndex;
    });
  }

  async function loadAiReferences() {
    var values = await Promise.all([storageGet(AI_ASSISTANTS_STORE_KEY), storageGet(AI_AGENTS_STORE_KEY)]);
    return {
      assistants: assistantsCore ? assistantsCore.normalizeStore(values[0]).assistants : [],
      agents: agentsCore ? agentsCore.normalizeStore(values[1]).agents : [],
      rawAssistants: values[0],
      rawAgents: values[1]
    };
  }

  function assistantFor(references, assistantId) {
    return references.assistants.find(function (assistant) { return assistant.id === assistantId; }) || null;
  }
  function agentFor(references, agentId) {
    return references.agents.find(function (agent) { return agent.id === agentId; }) || null;
  }
  function providerLabel(providerId) {
    var provider = integrationCore && integrationCore.providerById ? integrationCore.providerById(providerId) : null;
    return provider ? provider.label : (providerId || "Serviço indisponível");
  }
  function assistantModelLabel(assistant) {
    if (!assistant) return "Requer atenção";
    return assistant.modelMode === "specific" && assistant.model ? assistant.model : "modelo padrão";
  }
  function appendReferenceOptions(select, entries, selectedId, emptyLabel, missingLabel) {
    select.appendChild(el("option", { value: "", text: emptyLabel }));
    entries.forEach(function (entry) {
      var option = el("option", { value: entry.id, text: entry.name + (entry.enabled === false ? " · desativado" : "") });
      if (entry.id === selectedId) option.setAttribute("selected", "selected");
      select.appendChild(option);
    });
    if (selectedId && !entries.some(function (entry) { return entry.id === selectedId; })) {
      select.appendChild(el("option", { value: selectedId, text: missingLabel, selected: "selected" }));
    }
  }
  function preflightDefinition(funnel, references) {
    return funnelsCore ? funnelsCore.preflight(funnel, references.rawAssistants, references.rawAgents) : { ok: true, issues: [] };
  }
  async function openAiReference(section, apiName, methodName, entityId) {
    try {
      var result = await window.__extDashboardShell.showSection(section);
      if (!result || result.ok !== true) return;
      var api = window[apiName];
      if (api && typeof api[methodName] === "function") api[methodName](entityId || null);
    } catch (error) {
      toast("Não foi possível abrir a configuração de IA.", true);
    }
  }
  function appendItemGroups(select, items, selectedId) {
    var groups = [
      { label: "Favoritos", items: items.filter(function (item) { return item.favorite; }) },
      { label: "Recentes", items: items.filter(function (item) { return !item.favorite && item.recentRank !== Infinity; }) },
      { label: "Todos", items: items.filter(function (item) { return !item.favorite && item.recentRank === Infinity; }) }
    ];
    groups.forEach(function (group) {
      if (!group.items.length) return;
      var optgroup = el("optgroup", { label: group.label });
      group.items.forEach(function (item) {
        var option = el("option", { value: item.id, text: item.displayName });
        if (String(item.id) === String(selectedId || "")) option.setAttribute("selected", "selected");
        optgroup.appendChild(option);
      });
      select.appendChild(optgroup);
    });
    if (selectedId && !items.some(function (item) { return String(item.id) === String(selectedId); })) select.appendChild(el("option", { value: selectedId, text: "Item removido · selecione outro", selected: "selected", "data-missing-saved-item": "true" }));
  }
  function hasMissingSavedItem(step, itemLists) {
    if (!step || !ITEM_STORAGE_BY_TYPE[step.type]) return false;
    if (!step.itemId) return true;
    return !(itemLists[step.type] || []).some(function (item) { return String(item.id) === String(step.itemId); });
  }

  var containerEl = null;
  var renderGeneration = 0;
  var editorNavigationCleanup = null;

  function beginRender() {
    return { generation: ++renderGeneration, container: containerEl };
  }

  function renderIsCurrent(render) {
    var shell = window.__extDashboardShell;
    return !!(render && render.generation === renderGeneration && render.container === containerEl && render.container && render.container.isConnected && shell && shell.getCurrentSection() === "funis");
  }

  function clearEditorNavigationGuard() {
    if (editorNavigationCleanup) { editorNavigationCleanup(); editorNavigationCleanup = null; }
  }

  async function validateFunnelMetadataName(name, excludeId) {
    var funnels = await loadFunnels(), key = normalizeFunnelSearch(name);
    return funnels.some(function (item) { return item && String(item.id) !== String(excludeId || "") && normalizeFunnelSearch(item.name) === key; })
      ? "Já existe um Funil com esse nome. Escolha outro nome para continuar." : true;
  }
  async function openFunnelMetadataModal(funnel, mode) {
    var modal = window.__extAutomationMetadataModal;
    if (!modal || typeof modal.open !== "function") throw new Error("A janela de metadados do Funil não está disponível.");
    var creating = mode === "create" || !funnel;
    return modal.open({
      title: creating ? "Criar novo Funil" : "Editar Funil",
      confirmLabel: creating ? "Criar Funil" : "Salvar alterações",
      nameLabel: "Nome",
      name: funnel && funnel.name || "Novo funil",
      nameMaxLength: 160,
      namePlaceholder: "Nome do Funil",
      description: funnel && funnel.description || "",
      descriptionMaxLength: 300,
      descriptionPlaceholder: "Explique a finalidade deste Funil",
      color: funnel && funnel.color || "#f43f5e",
      defaultColor: "#f43f5e",
      hint: "A cor identifica este Funil nos cards e seletores. Etapas e execuções não são alteradas.",
      emptyNameMessage: "Digite um nome para continuar.",
      validateName: function (name) { return validateFunnelMetadataName(name, funnel && funnel.id); }
    });
  }
  async function createNamedFunnel() {
    var values = await openFunnelMetadataModal(null, "create");
    if (!values) return null;
    var funnel = newEmptyFunnel();
    funnel.name = values.name;
    funnel.description = values.description;
    funnel.color = values.color;
    if (window.__extPlaySystemSound) window.__extPlaySystemSound("success");
    return funnel;
  }
  async function updateFunnelMetadata(funnel) {
    var values = await openFunnelMetadataModal(funnel, "edit");
    if (!values) return null;
    var current = (await loadFunnels()).find(function (item) { return item.id === funnel.id; });
    if (!current) throw new Error("O Funil não foi encontrado.");
    current.name = values.name;
    current.description = values.description;
    current.color = values.color;
    current.updatedAtInMs = Date.now();
    return saveFunnelDefinition(current);
  }

  function newEmptyFunnel() {
    return { id: uid(), name: "Novo funil", description: "", color: "#f43f5e", items: [], favorite: false };
  }
  function newEmptyItem() {
    return funnelsCore ? funnelsCore.createStep("message") : { type: "message", itemId: "", delayAmount: 0, delayUnit: "minutes" };
  }
  function duplicateFunnelDefinition(funnel) {
    if (funnelsCore) return funnelsCore.duplicateDefinition(funnel, uid);
    var copy = JSON.parse(JSON.stringify(funnel)); copy.id = uid(); copy.name = (funnel.name || "Funil") + " — Cópia"; copy.favorite = false; return copy;
  }
  function formatStepCount(count) {
    return count + " " + (count === 1 ? "etapa" : "etapas");
  }
  function fmtFunnelRelativeUpdated(ms) {
    ms = Number(ms) || 0;
    if (!ms) return "";
    var diffMin = Math.round((Date.now() - ms) / 60000);
    if (diffMin < 1) return "Atualizado agora";
    if (diffMin < 60) return "Atualizado há " + diffMin + " min";
    var diffH = Math.round(diffMin / 60);
    if (diffH < 24) return "Atualizado há " + diffH + "h";
    var diffD = Math.round(diffH / 24);
    if (diffD < 30) return "Atualizado há " + diffD + "d";
    return "Atualizado em " + new Date(ms).toLocaleDateString("pt-BR");
  }
  var funnelSearchTerm = "";
  var funnelEditorOpen = false;
  function normalizeFunnelSearch(value) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").trim();
  }

                                                                             
  async function renderListScreen() {
    funnelEditorOpen = false;
    try {
      var funnelListUrl = new URL(location.href);
      if (funnelListUrl.searchParams.has("funnelId")) {
        funnelListUrl.searchParams.delete("funnelId");
        history.replaceState({ extappSection: "funis" }, "", funnelListUrl.pathname + (funnelListUrl.searchParams.toString() ? "?" + funnelListUrl.searchParams.toString() : "") + funnelListUrl.hash);
      }
    } catch (_) {}
    var currentRender = beginRender();
    clearEditorNavigationGuard();
    containerEl.innerHTML = "";
    if (window.__extDashboardShell && window.__extDashboardShell.refreshSectionChrome) window.__extDashboardShell.refreshSectionChrome();
    var wrap = el("div", { class: "extuiFunnelSection", "data-extui-academy-target": "funnel-time-units" });
    var header = el("div", { class: "extuifHeader extuiFunnelListHeader", "data-extui-academy-target": "funnel-overview" }, [
      el("div", { class: "extuiFunnelListTitle" }, [
        el("span", { class: "extuiFunnelEyebrow", text: "Automações sequenciais" }),
        el("h2", { text: "Funis" }),
        el("p", { text: "Organize mensagens e intervalos em uma sequência de acompanhamento." })
      ]),
      el("div", { class: "extuiFunnelHeaderActions" }, [
        el("button", { type: "button", class: "extui-btn extui-btn--ghost", title: "Abrir histórico de execuções", onClick: function () { if (window.__extDashboardShell) window.__extDashboardShell.showSection("atividades", { force: true }); } }, [
          icon("activity"),
          el("span", { text: "Histórico" })
        ]),
        el("button", { type: "button", class: "extui-btn extui-btn--ghost extuiFunnelRunningBtn", onClick: function () { renderRunningScreen(); } }, [
          icon("activity"),
          el("span", { text: "Execuções em andamento" })
        ]),
        el("button", { type: "button", class: "extui-btn extui-btn--primary extuiFunnelNewBtn", onClick: async function () {
          var funnel=await createNamedFunnel();if(funnel)renderEditorScreen(funnel);
        } }, [icon("plus"), el("span", { text: "Novo funil" })])
      ])
    ]);
    wrap.appendChild(header);

    var searchWrap = el("div", { class: "extuiSearch extuiFunnelSearchInput" }, [icon("search")]);
    var searchInput = el("input", { type: "search", placeholder: "Buscar funil pelo nome...", autocomplete: "off", "aria-label": "Buscar funil pelo nome" });
    searchInput.value = funnelSearchTerm;
    searchWrap.appendChild(searchInput);
    wrap.appendChild(searchWrap);

    var funnels = await loadFunnels();
    var counts = await loadRunningCounts();
    if (!renderIsCurrent(currentRender)) return false;
    var list = el("div", { class: "extuiFunnelList" });
    var noResults = el("div", { class: "extuifEmpty extuiFunnelSearchEmpty" }, [
      icon("search", "extuifEmptyIcon"),
      el("div", { class: "extuiFunnelEmptyTitle", text: "Nenhum funil encontrado" }),
      el("div", { class: "extuifEmptyText", text: "Ajuste a busca ou limpe o filtro para ver todos os funis." })
    ]);
    var clearSearch = el("button", { type: "button", class: "extui-btn extui-btn--ghost", text: "Limpar busca" });
    noResults.appendChild(clearSearch);
    noResults.hidden = true;
    function applyFunnelSearch() {
      var term = normalizeFunnelSearch(funnelSearchTerm);
      var visibleCount = 0;
      list.querySelectorAll(".extuiFunnelRow--interactive").forEach(function (row) {
        var matches = !term || String(row.getAttribute("data-search-text") || "").indexOf(term) >= 0;
        row.hidden = !matches;
        if (matches) visibleCount += 1;
      });
      noResults.hidden = !term || !funnels.length || visibleCount > 0;
    }
    clearSearch.addEventListener("click", function () { funnelSearchTerm = ""; searchInput.value = ""; applyFunnelSearch(); searchInput.focus(); });
    searchInput.addEventListener("input", function () { funnelSearchTerm = searchInput.value; applyFunnelSearch(); });
    if (funnels.length === 0) {
      list.appendChild(el("div", { class: "extuifEmpty" }, [
        icon("funnel", "extuifEmptyIcon"),
        el("div", { class: "extuiFunnelEmptyTitle", text: "Crie sua primeira sequência" }),
        el("div", { class: "extuifEmptyText", text: "Combine itens salvos e intervalos para acompanhar contatos no tempo certo." }),
        el("button", { type: "button", class: "extui-btn extui-btn--primary", onClick: async function () {
          var funnel=await createNamedFunnel();if(funnel)renderEditorScreen(funnel);
        } }, [icon("plus"), el("span", { text: "Criar primeiro funil" })])
      ]));
    } else {
                                                                        
                                                                       
                                                                           
      funnels.forEach(function (funnel) {
        var row = el("div", {
          class: "extuiFunnelRow extuiFunnelRow--interactive",
          role: "button",
          tabindex: "0",
          "aria-label": "Abrir funil " + funnel.name,
          "data-search-text": normalizeFunnelSearch((funnel.name || "") + " " + (funnel.description || ""))
        });
        row.style.setProperty("--extui-funnel-accent", funnel.color || "#f43f5e");
                                                                      
                                                                             
                                                                          
                                                                          
                                         
        row.appendChild(icon("funnel", "extuiFunnelRowIcon"));
        var mainCol = el("div", { class: "extuifFlowMain extuiFunnelRowMain" });
        var nameRow = el("div", { class: "extuifFlowNameRow" });
        nameRow.appendChild(el("div", { class: "extuiFunnelRowName", text: funnel.name }));
        var runningCount = counts[funnel.id] || 0;
        if (runningCount > 0) nameRow.appendChild(el("div", { class: "extuifChip", text: runningCount + " em andamento" }));
        if (funnelsCore && funnelsCore.hasAiSteps(funnel)) nameRow.appendChild(el("div", { class: "extuifChip extuiFunnelAiChip", text: "Utiliza IA" }));
        mainCol.appendChild(nameRow);
        if (String(funnel.description || "").trim()) mainCol.appendChild(el("div", { class: "extuiFunnelRowDescription", text: funnel.description }));
        var funnelUpdated=fmtFunnelRelativeUpdated(funnel.updatedAtInMs||funnel.updatedAt||funnel.createdAtInMs);var funnelMeta=el("div",{class:"extuiFunnelRowMeta"},[el("span",{class:"extuiAutomationMetaSteps",text:formatStepCount(funnel.items.length)}),funnelUpdated?el("span",{class:"extuiAutomationMetaUpdated",text:funnelUpdated}):null].filter(Boolean));mainCol.appendChild(funnelMeta);
        row.appendChild(mainCol);

        var actions = el("div", { class: "extuifFlowActions" });
        var funnelFav=el("button",{type:"button",class:"extuiItensIconBtn extuiFlowFavoriteBtn"+(funnel.favorite?" is-favorite":""),title:funnel.favorite?"Remover dos favoritos":"Adicionar aos favoritos",text:funnel.favorite?"★":"☆","aria-label":(funnel.favorite?"Remover dos favoritos ":"Adicionar aos favoritos ")+funnel.name});funnelFav.addEventListener("click",async function(e){e.stopPropagation();var all=await loadFunnels(),f=all.find(function(x){return x.id===funnel.id;});if(!f)return;f.favorite=!f.favorite;f.updatedAtInMs=Date.now();await saveFunnelDefinition(f);renderListScreen();});actions.appendChild(funnelFav);
        actions.appendChild(el("button", { class: "extuiItensIconBtn", title: "Editar Funil", "aria-label": "Editar metadados do funil " + funnel.name, onClick: async function (e) {
          e.stopPropagation();
          try { var updated = await updateFunnelMetadata(funnel); if (updated) { toast("Funil atualizado."); renderListScreen(); } }
          catch (error) { toast(error && error.message || "Não foi possível atualizar o Funil.", true); }
        } }, [icon("edit")]));
        actions.appendChild(el("button", { type: "button", class: "extuiItensIconBtn", title: "Executar teste", "aria-label": "Executar teste do funil " + funnel.name, onClick: async function (e) {
          e.stopPropagation();
          if (typeof window.__extOpenAutomationTestDialog !== "function" || typeof window.__extSendToWhatsAppTab !== "function") { toast("Recarregue o Painel de Controle e tente novamente.", true); return; }
          var references = await loadAiReferences();
          var preflight = preflightDefinition(funnel, references);
          if (!preflight.ok) { toast(preflight.issues[0].message, true); return; }
          window.__extOpenAutomationTestDialog({ onConfirm: function (contact) {
            return window.__extSendToWhatsAppTab("EXTUI_FUNNELS_START_MANUAL", { funnelId: funnel.id, phoneNumber: contact.value, isTest: true });
          } });
        } }, [icon("play")]));
        actions.appendChild(el("button", { type: "button", class: "extuiItensIconBtn", title: "Duplicar", "aria-label": "Duplicar funil " + funnel.name, onClick: async function (e) {
          e.stopPropagation();
          var source = (await loadFunnels()).find(function (item) { return item.id === funnel.id; });
          if (!source) return;
          var duplicated = duplicateFunnelDefinition(source);
          await saveFunnelDefinition(duplicated);
          toast('Funil duplicado como "' + duplicated.name + '".');
          renderListScreen();
        } }, [icon("copy")]));
        actions.appendChild(el("button", { class: "extuiItensIconBtn extuiItensIconBtn--danger", title: "Excluir", "aria-label": "Excluir funil " + funnel.name, onClick: async function (e) {
          e.stopPropagation();
          var action=window.__extTrashConfirm?await window.__extTrashConfirm({title:'Excluir funil?',message:'Você pode enviar "'+funnel.name+'" para a Lixeira, criar um backup antes da exclusão ou apagar definitivamente.'}):(await extConfirm('Excluir o funil "' + funnel.name + '"?', { danger: true })?'permanent':null);if(!action)return;
          if(action==='trash'&&window.__extTrashService)await window.__extTrashService.add({type:'funnel',label:funnel.name,payload:{item:funnel}});
          await removeFunnelDefinition(funnel.id);
          toast(action==='trash'?"Funil enviado para a Lixeira.":"Funil excluído definitivamente.");
          renderListScreen();
        } }, [icon("trash")]));
        row.appendChild(actions);
        row.addEventListener("click", function () { renderEditorScreen(funnel); });
        row.addEventListener("keydown", function (e) {
          if (e.target !== row || (e.key !== "Enter" && e.key !== " ")) return;
          e.preventDefault();
          renderEditorScreen(funnel);
        });
        list.appendChild(row);
      });
    }
    wrap.appendChild(list);
    wrap.appendChild(noResults);
    applyFunnelSearch();
    containerEl.appendChild(wrap);
    return true;
  }

                                                                             
  async function renderEditorScreen(funnel) {
    funnelEditorOpen = true;
    var currentRender = beginRender();
    clearEditorNavigationGuard();
    containerEl.innerHTML = "";
    if (window.__extDashboardShell && window.__extDashboardShell.refreshSectionChrome) window.__extDashboardShell.refreshSectionChrome();
    funnel = funnelsCore ? funnelsCore.serializeDefinition(funnel) : JSON.parse(JSON.stringify(funnel));
    var itemLists = {};
    var itemTypes = Object.keys(ITEM_STORAGE_BY_TYPE);
    var loaded = await Promise.all(itemTypes.map(loadItemsForType).concat([loadAiReferences()]));
    itemTypes.forEach(function (type, index) { itemLists[type] = loaded[index]; });
    var aiReferences = loaded[loaded.length - 1];
    if (!renderIsCurrent(currentRender)) return false;

    var wrap = el("div", { class: "extuiFunnelSection extuiFunnelSection--editor" });
    var toolbar = el("div", { class: "extuiFunnelEditorToolbar" });
    var dirty = false;
    var dirtyIndicator = el("span", { class: "extuiFunnelDirtyIndicator", text: "Alterações não salvas", hidden: "hidden" });
    function markDirty() { dirty = true; dirtyIndicator.hidden = false; if(typeof paintFunnelSummary==="function") paintFunnelSummary(); }
                                                                          
                                                                           
                                                                          
                                                                       
                                                                         
                                                                   
    async function tryLeaveEditor() {
      if (dirty && !await window.extConfirm("Há alterações não salvas neste funil. Deseja sair sem salvar?", { danger: true })) return false;
      clearEditorNavigationGuard();
      return true;
    }
    function onBeforeUnload(event) {
      if (!dirty) return;
      event.preventDefault();
      event.returnValue = "";
    }
    window.addEventListener("beforeunload", onBeforeUnload);
    if (window.__extDashboardShell && typeof window.__extDashboardShell.setNavigationGuard === "function") {
      window.__extDashboardShell.setNavigationGuard(function () { return tryLeaveEditor(); });
    }
    editorNavigationCleanup = function () {
      window.removeEventListener("beforeunload", onBeforeUnload);
      if (window.__extDashboardShell && typeof window.__extDashboardShell.setNavigationGuard === "function") window.__extDashboardShell.setNavigationGuard(null);
    };

    toolbar.appendChild(el("button", { type: "button", class: "extuiFunnelBackBtn", "aria-label": "Voltar para a lista de funis", onClick: async function () { if (await tryLeaveEditor()) renderListScreen(); } }, [
      icon("arrowLeft"),
      el("span", { text: "Voltar" })
    ]));
    toolbar.appendChild(el("span", { class: "extuiFunnelToolbarDivider", "aria-hidden": "true" }));

    var titleBlock = el("div", { class: "extuiFunnelEditorTitle" });
    titleBlock.appendChild(el("span", { class: "extuiFunnelEyebrow", text: "Editor de funil" }));
    var nameInput = el("input", { class: "extuiFunnelNameInput", type: "text", "aria-label": "Nome do funil" });
    nameInput.value = funnel.name;
    titleBlock.appendChild(nameInput);
    toolbar.appendChild(titleBlock);

    var stepCount = el("span", { class: "extuiFunnelStepCount", text: formatStepCount(funnel.items.length) });
    toolbar.appendChild(stepCount);
    toolbar.appendChild(dirtyIndicator);
    var toolbarActions = el("div", { class: "extuiFunnelEditorActions" });
    toolbar.appendChild(toolbarActions);
    wrap.appendChild(toolbar);

    var workspace = el("div", { class: "extuiFunnelWorkspace" });
    var costNotice = el("div", { class: "extuiFunnelAiCostNotice", role: "note", hidden: "hidden" }, [
      icon("alert"),
      el("span", { text: "Este Funil usa serviços de IA e pode gerar consumo nas contas conectadas." })
    ]);
    var workspaceIntro = el("div", { class: "extuiFunnelWorkspaceIntro" }, [
      el("div", { class: "extuiFunnelWorkspaceTitle", text: "Sequência" }),
      el("p", { text: "As etapas são executadas de cima para baixo." }),
      costNotice
    ]);
    workspace.appendChild(workspaceIntro);
    var funnelSummary = el("div", { class: "extuiFunnelSummary" });
    workspace.appendChild(funnelSummary);
    function funnelDelayMinutes(item){ var n=Number(item.delayAmount)||0,u=item.delayUnit||"minutes"; if(u==="seconds")return n/60;if(u==="hours")return n*60;if(u==="days")return n*1440;return n; }
    function paintFunnelSummary(){
      var total=funnel.items.length, delayed=funnel.items.filter(function(item,idx){return idx>0&&(Number(item.delayAmount)||0)>0;}).length;
      var mins=Math.round(funnel.items.reduce(function(sum,item,idx){return sum+(idx?funnelDelayMinutes(item):0);},0));
      var kinds={};funnel.items.forEach(function(item){kinds[item.type]=(kinds[item.type]||0)+1;});
      funnelSummary.innerHTML="";
      funnelSummary.appendChild(el("div",{},[el("span",{text:"Etapas"}),el("strong",{text:String(total)}),el("small",{text:"sequência atual"})]));
      funnelSummary.appendChild(el("div",{},[el("span",{text:"Esperas"}),el("strong",{text:String(delayed)}),el("small",{text:mins?mins+" min estimados":"sem atraso"})]));
      funnelSummary.appendChild(el("div",{},[el("span",{text:"Tipos"}),el("strong",{text:String(Object.keys(kinds).length)}),el("small",{text:"conteúdos/ações"})]));
      funnelSummary.appendChild(el("div",{},[el("span",{text:"Estado"}),el("strong",{text:dirty?"Editando":"Pronto"}),el("small",{text:dirty?"há alterações":"sem alterações"})]));
    }
    var itemsWrap = el("div", { class: "extuiFunnelItemsWrap" });
    workspace.appendChild(itemsWrap);
    wrap.appendChild(workspace);

    function updateCostNotice() {
      var visible = funnelsCore && funnelsCore.hasAiSteps(funnel);
      costNotice.hidden = !visible;
    }

                                                                         
                                                                           
                                                                        
                                                                      
                                                    
    function addItem() {
      funnel.items.push(newEmptyItem());
      markDirty();
      renderItemRows();
    }
    var addItemBtn = el("button", { type: "button", class: "extuiFunnelAddItemBtn", onClick: addItem }, [
      icon("plus"),
      el("span", { text: "Adicionar etapa" })
    ]);

    function stepPresentation(item) {
      if (item.type === "aiGenerate") {
        var assistant = assistantFor(aiReferences, item.assistantId);
        return {
          entity: assistant,
          attention: !assistant || assistant.enabled === false,
          summary: assistant ? assistant.name : "Assistente não encontrado",
          detail: assistant ? providerLabel(assistant.providerId) + " · " + assistantModelLabel(assistant) : "Requer atenção"
        };
      }
      if (item.type === "aiAgent") {
        var agent = agentFor(aiReferences, item.agentId);
        var assistant = agent ? assistantFor(aiReferences, agent.assistantId) : null;
        var tools = assistant && assistant.tools && Array.isArray(assistant.tools.enabled) ? assistant.tools.enabled.length : 0;
        return {
          entity: agent,
          attention: !agent || agent.enabled === false || !assistant || assistant.enabled === false,
          summary: agent ? agent.name : "Agente não encontrado",
          detail: agent ? "Até " + agent.maxSteps + " etapas · " + tools + " ferramenta" + (tools === 1 ? "" : "s") : "Requer atenção"
        };
      }
      return null;
    }

    function appendAiConfiguration(main, configRow, item, idx, presentation) {
      var isGenerate = item.type === "aiGenerate";
      var entityField = el("label", { class: "extuiFunnelField extuiFunnelAiEntityField" }, [el("span", { text: isGenerate ? "Assistente" : "Agente" })]);
      var entitySelect = el("select", { "aria-label": (isGenerate ? "Assistente" : "Agente") + " da etapa " + (idx + 1) });
      appendReferenceOptions(entitySelect, isGenerate ? aiReferences.assistants : aiReferences.agents, isGenerate ? item.assistantId : item.agentId, isGenerate ? "Selecione um Assistente" : "Selecione um Agente", isGenerate ? "Assistente não encontrado · requer atenção" : "Agente não encontrado · requer atenção");
      entitySelect.addEventListener("change", function () {
        if (isGenerate) item.assistantId = entitySelect.value || null;
        else item.agentId = entitySelect.value || null;
        markDirty();
        renderItemRows();
      });
      entityField.appendChild(entitySelect);
      configRow.appendChild(entityField);
      main.appendChild(configRow);

      var aiPanel = el("div", { class: "extuiFunnelAiConfig" + (presentation.attention ? " is-attention" : "") });
      var promptField = el("label", { class: "extuiFunnelField extuiFunnelAiPromptField" }, [el("span", { text: isGenerate ? "Instruções da etapa" : "Tarefa da etapa" })]);
      var textarea = el("textarea", {
        rows: "4",
        maxlength: isGenerate ? "12000" : "6000",
        placeholder: isGenerate ? "Ex.: Responda à dúvida de {primeiro_nome} com clareza e objetividade." : "Ex.: Qualifique {primeiro_nome} e indique o próximo passo comercial.",
        "aria-label": (isGenerate ? "Instruções" : "Tarefa") + " da etapa " + (idx + 1)
      });
      textarea.value = isGenerate ? item.prompt || "" : item.task || "";
      textarea.addEventListener("input", function () { if (isGenerate) item.prompt = textarea.value; else item.task = textarea.value; markDirty(); });
      promptField.appendChild(textarea);
      aiPanel.appendChild(promptField);

      var footer = el("div", { class: "extuiFunnelAiFooter" }, [
        el("div", { class: "extuiFunnelAiOutput" }, [
          el("span", { text: "Saída" }),
          el("strong", { text: isGenerate ? "Enviar como mensagem" : "Responder ao cliente" })
        ])
      ]);
      var editButton = el("button", {
        type: "button",
        class: "extui-btn extui-btn--ghost extuiFunnelAiEditBtn",
        onClick: function () {
          return openAiReference(isGenerate ? "ai-assistants" : "ai-agents", isGenerate ? "__extAiAssistants" : "__extAiAgents", isGenerate ? "openAssistant" : "openAgent", presentation.entity && presentation.entity.id);
        }
      }, [el("span", { text: isGenerate ? "Editar Assistente" : "Editar Agente" }), icon("external")]);
      if (!presentation.entity) editButton.disabled = true;
      footer.appendChild(editButton);
      aiPanel.appendChild(footer);
      main.appendChild(aiPanel);
    }

    function renderItemRows() {
      itemsWrap.innerHTML = "";
      stepCount.textContent = formatStepCount(funnel.items.length);
      paintFunnelSummary();
      updateCostNotice();
      addItemBtn.hidden = funnel.items.length === 0;
      if (funnel.items.length === 0) {
        itemsWrap.appendChild(el("div", { class: "extuiFunnelEditorEmpty" }, [
          icon("funnel", "extuiFunnelEditorEmptyIcon"),
          el("div", { class: "extuiFunnelEditorEmptyTitle", text: "Monte sua sequência" }),
          el("p", { text: "Adicione a primeira etapa para definir o início deste funil." }),
          el("button", { type: "button", class: "extui-btn extui-btn--primary", onClick: addItem }, [
            icon("plus"),
            el("span", { text: "Adicionar primeira etapa" })
          ])
        ]));
        return;
      }

      funnel.items.forEach(function (item, idx) {
        var row = el("div", { class: "extuiFunnelItemRow" + (idx === funnel.items.length - 1 ? " extuiFunnelItemRow--last" : "") });
        var rail = el("div", { class: "extuiFunnelItemRail" }, [
          el("div", { class: "extuiFunnelItemIndex", text: String(idx + 1).padStart(2, "0") })
        ]);
        row.appendChild(rail);

        var presentation = stepPresentation(item);
        var main = el("div", { class: "extuiFunnelItemMain" + (presentation && presentation.attention ? " is-attention" : "") });
        var stepHeader = el("div", { class: "extuiFunnelItemHeader" });
        var identityContent = [
          el("span", { class: "extuiFunnelItemEyebrow", text: "Etapa " + String(idx + 1).padStart(2, "0") }),
          el("strong", { class: "extuiFunnelItemTypeLabel", text: TYPE_LABELS[item.type] || "Tipo desconhecido" })
        ];
        if (presentation) {
          identityContent.push(el("span", { class: "extuiFunnelItemSummary", text: presentation.summary + " · " + presentation.detail }));
          if (presentation.attention) identityContent.push(el("span", { class: "extuiFunnelAttentionBadge", text: "Requer atenção", role: "status" }));
        }
        var identity = el("div", { class: "extuiFunnelItemIdentity" }, [
          icon(TYPE_LABELS[item.type] ? item.type : "alert", "extuiFunnelItemTypeIcon"),
          el("div", { class: "extuiFunnelItemIdentityText" }, identityContent)
        ]);
        stepHeader.appendChild(identity);

        var actions = el("div", { class: "extuiFunnelItemActions" });
        if (idx > 0) {
          actions.appendChild(el("button", { type: "button", class: "extuiItensIconBtn", title: "Mover para cima", "aria-label": "Mover etapa " + (idx + 1) + " para cima", onClick: function () {
            var tmp = funnel.items[idx - 1]; funnel.items[idx - 1] = funnel.items[idx]; funnel.items[idx] = tmp;
            markDirty();
            renderItemRows();
          } }, [icon("chevronUp")]));
        }
        if (idx < funnel.items.length - 1) {
          actions.appendChild(el("button", { type: "button", class: "extuiItensIconBtn", title: "Mover para baixo", "aria-label": "Mover etapa " + (idx + 1) + " para baixo", onClick: function () {
            var tmp = funnel.items[idx + 1]; funnel.items[idx + 1] = funnel.items[idx]; funnel.items[idx] = tmp;
            markDirty();
            renderItemRows();
          } }, [icon("chevronDown")]));
        }
        actions.appendChild(el("button", { type: "button", class: "extuiItensIconBtn extuiItensIconBtn--danger", title: "Excluir etapa", "aria-label": "Excluir etapa " + (idx + 1), onClick: function () {
          funnel.items.splice(idx, 1);
          markDirty();
          renderItemRows();
        } }, [icon("trash")]));
        stepHeader.appendChild(actions);
        main.appendChild(stepHeader);

        var configRow = el("div", { class: "extuiFunnelItemConfig" });

        var typeField = el("label", { class: "extuiFunnelField extuiFunnelTypeField" }, [
          el("span", { text: "Tipo" })
        ]);
        var typeSelect = el("select", { "aria-label": "Tipo da etapa " + (idx + 1) });
        if (item.type === "media") typeSelect.appendChild(el("option", { value: "media", text: "Imagem/Vídeo (legado)", selected: "selected" }));
        else if (!TYPE_LABELS[item.type]) typeSelect.appendChild(el("option", { value: item.type, text: "Tipo desconhecido · " + item.type, selected: "selected" }));
        Object.keys(TYPE_LABELS).filter(function(t){return t!=="media";}).forEach(function (t) {
          var opt = el("option", { value: t, text: TYPE_LABELS[t] });
          if (t === item.type) opt.setAttribute("selected", "selected");
          typeSelect.appendChild(opt);
        });
        typeSelect.addEventListener("change", function () {
          var replacement = funnelsCore ? funnelsCore.createStep(typeSelect.value, item) : { type: typeSelect.value, itemId: "", delayAmount: item.delayAmount || 0, delayUnit: item.delayUnit || "minutes" };
          funnel.items[idx] = replacement;
          markDirty();
          renderItemRows();
        });
        typeField.appendChild(typeSelect);
        configRow.appendChild(typeField);

        if (presentation) {
          appendAiConfiguration(main, configRow, item, idx, presentation);
        } else if (ITEM_STORAGE_BY_TYPE[item.type]) {
          var itemField = el("label", { class: "extuiFunnelField extuiFunnelSavedItemField" }, [el("span", { text: "Item salvo" })]);
          var itemSelect = el("select", { "aria-label": "Item salvo da etapa " + (idx + 1) });
          itemSelect.appendChild(el("option", { value: "", text: "Selecione um item" }));
          appendItemGroups(itemSelect, itemLists[item.type] || [], item.itemId);
          var missingSavedItem = hasMissingSavedItem(item, itemLists);
          itemSelect.classList.toggle("is-missing", missingSavedItem);
          if (missingSavedItem && item.itemId) itemField.appendChild(el("small", { class: "extuiFunnelMissingItem", text: "Item removido · selecione outro" }));
          itemSelect.addEventListener("change", function () { item.itemId = itemSelect.value; markDirty(); renderItemRows(); });
          itemField.appendChild(itemSelect);
          configRow.appendChild(itemField);
          main.appendChild(configRow);
        } else {
          configRow.appendChild(el("div", { class: "extuiFunnelUnknownStep", role: "status" }, [icon("alert"), el("span", { text: "Este tipo de etapa não é reconhecido por esta versão. Escolha um tipo compatível para editá-la." })]));
          main.appendChild(configRow);
        }

        var metaRow = el("div", { class: "extuiFunnelItemMeta" });
        if (idx > 0) {
          metaRow.appendChild(el("div", { class: "extuiFunnelDelayLabel" }, [
            icon("clock"),
            el("span", { text: "Aguardar antes desta etapa" })
          ]));
          var delayControls = el("div", { class: "extuiFunnelDelayControls" });
          var delayAmountInput = el("input", { type: "number", min: "0", class: "extuiFunnelDelayAmount", "aria-label": "Tempo de espera antes da etapa " + (idx + 1) });
          delayAmountInput.value = item.delayAmount || 0;
          delayAmountInput.addEventListener("input", function () { item.delayAmount = parseInt(delayAmountInput.value, 10) || 0; markDirty(); });
          delayControls.appendChild(delayAmountInput);

          var delayUnitSelect = el("select", { class: "extuiFunnelDelayUnit", "aria-label": "Unidade do tempo de espera da etapa " + (idx + 1) });
          Object.keys(DELAY_UNIT_LABELS).forEach(function (u) {
            var opt = el("option", { value: u, text: DELAY_UNIT_LABELS[u] });
            if (u === item.delayUnit) opt.setAttribute("selected", "selected");
            delayUnitSelect.appendChild(opt);
          });
          delayUnitSelect.addEventListener("change", function () { item.delayUnit = delayUnitSelect.value; markDirty(); });
          delayControls.appendChild(delayUnitSelect);
          metaRow.appendChild(delayControls);
        } else {
          metaRow.appendChild(el("div", { class: "extuiFunnelItemFirstNote" }, [
            icon("activity"),
            el("span", { text: "Esta etapa inicia o funil e é enviada imediatamente." })
          ]));
        }
        main.appendChild(metaRow);
        row.appendChild(main);

        itemsWrap.appendChild(row);
      });
    }
    renderItemRows();
    nameInput.addEventListener("input", markDirty);

    workspace.appendChild(addItemBtn);

    var saveBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary extuiFunnelSaveBtn", text: "Salvar funil", onClick: async function () {
      var missingSavedItem = funnel.items.some(function (item) { return hasMissingSavedItem(item, itemLists); });
      if (missingSavedItem) { toast("Selecione um item válido para cada etapa. Um item salvo pode ter sido removido da Biblioteca.", true); return; }
      var requestedName=String(nameInput.value||"").trim()||"Novo funil",existingFunnels=await loadFunnels(),requestedKey=normalizeFunnelSearch(requestedName),duplicateName=existingFunnels.some(function(item){return item&&String(item.id)!==String(funnel.id)&&normalizeFunnelSearch(item.name)===requestedKey;});if(duplicateName){toast("Já existe um Funil com esse nome. Edite o nome para continuar.",true);window.__extPlaySystemSound&&window.__extPlaySystemSound("error");nameInput.focus();nameInput.select();return;}funnel.name=requestedName;
      var preflight = preflightDefinition(funnel, aiReferences);
      if (!preflight.ok) { toast(preflight.issues[0].message, true); return; }
      saveBtn.disabled = true; saveBtn.textContent = "Salvando...";
      try {
        funnel = await saveFunnelDefinition(funnel);
        dirty = false;
        dirtyIndicator.hidden = true;
        clearEditorNavigationGuard();
        toast("Funil salvo com sucesso.");
        nameInput.value = funnel.name || nameInput.value;
        renderItemRows();
      } catch (err) {
        toast(err && err.message || "Não foi possível salvar o funil.", true);
      } finally { saveBtn.disabled = false; saveBtn.textContent = "Salvar funil"; }
    } });
    toolbarActions.appendChild(saveBtn);

    containerEl.appendChild(wrap);
    return true;
  }

                                                                             
  function formatNextSend(ms) {
    var d = new Date(ms);
    return d.toLocaleString("pt-BR");
  }

  async function renderRunningScreen() {
    var currentRender = beginRender();
    clearEditorNavigationGuard();
    containerEl.innerHTML = "";
    if (window.__extDashboardShell && window.__extDashboardShell.refreshSectionChrome) window.__extDashboardShell.refreshSectionChrome();
    var wrap = el("div", { class: "extuiFunnelSection" });
    var header = el("div", { class: "extuifHeader" }, [
      el("h2", { text: "Execuções em andamento" }),
      el("button", { class: "extui-btn extui-btn--ghost", text: "← Voltar aos funis", onClick: function () { renderListScreen(); } })
    ]);
    wrap.appendChild(header);

    var running = await loadRunning();
    var funnels = await loadFunnels();
    if (!renderIsCurrent(currentRender)) return false;
    var active = running.filter(function (r) { return r.status === "running" || r.status === "error"; });
    var list = el("div", { class: "extuiFunnelList" });
    if (active.length === 0) {
      list.appendChild(el("div", { class: "extuifEmpty", text: "Nenhuma execução em andamento." }));
    } else {
      active.forEach(function (instance) {
        var funnel = funnels.find(function (f) { return f.id === instance.funnelId; });
        var row = el("div", { class: "extuiFunnelRow" });
        row.appendChild(el("div", { class: "extuiFunnelRowName", text: (funnel ? funnel.name : "(funil excluído)") + " — " + instance.chatId }));
        row.appendChild(el("div", { class: "extuifChip extuifChip--gray", text: "item " + (instance.currentItemIndex + 1) + " de " + (funnel ? funnel.items.length : "?") }));
        if (instance.status === "error") {
          row.appendChild(el("div", { class: "extuifChip extuiFunnelErrorChip", text: "erro no envio" }));
        } else {
          row.appendChild(el("div", { class: "extuifChip extuifChip--gray", text: "próximo: " + formatNextSend(instance.nextSendAtMs) }));
        }
        row.appendChild(el("button", { class: "extui-btn extui-btn--ghost", text: "Cancelar", onClick: async function (e) {
          e.stopPropagation();
          if (typeof window.__extSendToWhatsAppTab !== "function") { toast("Recarregue o Painel de Controle e tente novamente.", true); return; }
          try {
            await window.__extSendToWhatsAppTab("EXTUI_FUNNELS_CANCEL", { chatId: instance.chatId, executionId: instance.id });
            toast("Execução cancelada.");
            renderRunningScreen();
          } catch (error) {
            toast(error && error.message || "Não foi possível cancelar a execução.", true);
          }
        } }));
        list.appendChild(row);
      });
    }
    wrap.appendChild(list);
    containerEl.appendChild(wrap);
    return true;
  }

  function scheduleExternalFunnelRefresh(meta) {
    if (meta && meta.local === true) return;
    var shell = window.__extDashboardShell;
    if (!shell || !containerEl || !containerEl.isConnected || shell.getCurrentSection() !== "funis" || funnelEditorOpen) return;
    Promise.resolve(renderListScreen()).catch(function (err) { if(window.__extReportRuntimeError)window.__extReportRuntimeError("FUNNEL_EXTERNAL_REFRESH_FAILED",err); });
  }
  if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
    window.ExtensionStorage.subscribe(FUNNEL_STORE_KEY, function (_newValue, _oldValue, _key, meta) { scheduleExternalFunnelRefresh(meta); });
    window.ExtensionStorage.subscribe(RUNNING_STORE_KEY, function (_newValue, _oldValue, _key, meta) { scheduleExternalFunnelRefresh(meta); });
  } else if (globalThis.chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes || (!changes[FUNNEL_STORE_KEY] && !changes[RUNNING_STORE_KEY])) return;
      scheduleExternalFunnelRefresh({ local: false, area: area });
    });
  }

  window.ExtensionFunnelsUI = {
    render: async function (target, options) {
      containerEl = target;
      funnelSearchTerm = "";
      var requestedFunnelId = options && options.funnelId ? String(options.funnelId) : "";
      if (requestedFunnelId) {
        var funnels = await loadFunnels();
        var requestedFunnel = funnels.find(function (funnel) { return String(funnel && funnel.id || "") === requestedFunnelId; });
        if (requestedFunnel) return renderEditorScreen(requestedFunnel);
        toast("O Funil solicitado não foi encontrado.", true);
      }
      return renderListScreen();
    }
  };
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
