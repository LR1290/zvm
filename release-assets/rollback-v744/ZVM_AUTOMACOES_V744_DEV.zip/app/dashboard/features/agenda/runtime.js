;
try{
(function () {
  "use strict";

  if (window.__extAgendaModuleBooted) return;
  window.__extAgendaModuleBooted = true;

                                                                                     
                                                                                    
                                                                                  
                                                                               
                                                                             
                                                              
                                                                             
                                                          
  var SCHEDULE_STORE_KEY = "EXTUI:extappScheduleStore";
  var QUICK_ITEMS_RECENTS_KEY = "EXTUI:quickItemsRecents";
  var ITEM_STORES = {
    message: { key: "EXTUI:textMessageStore", listField: "textMessageList", label: "Mensagem", icon: "message" },
    audio: { key: "EXTUI:audioStore", listField: "audioList", label: "Áudio", icon: "audio" },
    image: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem", icon: "media", virtualMediaKind: "image" },
    video: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Vídeo", icon: "video", virtualMediaKind: "video" },
    media: { key: "EXTUI:mediaStore", listField: "mediaList", label: "Imagem/Vídeo (legado)", icon: "media", legacyOnly: true },
    document: { key: "EXTUI:documentStore", listField: "documentList", label: "Documento", icon: "document" },
    funnel: { key: "EXTUI:extappFunnelStore", listField: "funnelList", label: "Funil", icon: "funnel" }
  };
  var STATUS_LABELS = { scheduled: "Agendado", sent: "Enviado", error: "Erro", cancelled: "Cancelado", missed: "Não enviado" };
  var agendaContactOutsideCleanup = null;

                                                                           
                                                                        
                                                            
  var ICONS = {
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    audio: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    media: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    video: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m10 9 5 3-5 3z"/>',
    sticker: '<path d="M8 3h8a5 5 0 0 1 5 5v5a8 8 0 0 1-8 8H8a5 5 0 0 1-5-5V8a5 5 0 0 1 5-5Z"/><path d="M15 21v-3a3 3 0 0 1 3-3h3"/>',
    document: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
    funnel: '<path d="M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"/>',
    calendar: '<path d="M8 2v3"/><path d="M16 2v3"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    unknown: '<circle cx="12" cy="12" r="10"/><path d="M12 17h.01"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 2-3 4"/>'
  };
  function icon(name, extraClass) {
    var span = document.createElement("span");
    span.className = "extui-svgicon" + (extraClass ? " " + extraClass : "");
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || "") + "</svg>";
    return span;
  }

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }
  function parseLocalSchedule(dateValue,timeValue){
    var dm=String(dateValue||"").match(/^(\d{4})-(\d{2})-(\d{2})$/),tm=String(timeValue||"").match(/^(\d{2}):(\d{2})$/);if(!dm||!tm)return NaN;
    var year=Number(dm[1]),month=Number(dm[2]),day=Number(dm[3]),hour=Number(tm[1]),minute=Number(tm[2]),d=new Date(year,month-1,day,hour,minute,0,0);
    if(d.getFullYear()!==year||d.getMonth()!==month-1||d.getDate()!==day||d.getHours()!==hour||d.getMinutes()!==minute)return NaN;
    return d.getTime();
  }

  function storageGet(key) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.storage.local.get(key, function (result) {
          if (chrome.runtime && chrome.runtime.lastError) { reject(chrome.runtime.lastError); return; }
          resolve(result ? result[key] : undefined);
        });
      } catch (err) { reject(err); }
    });
  }
  function storageSet(key, value) {
    if (window.ExtensionStorage && typeof window.ExtensionStorage.set === "function") return window.ExtensionStorage.set(key, value);
    return new Promise(function (resolve, reject) {
      try {
        var obj = {}; obj[key] = value;
        chrome.storage.local.set(obj, function () {
          if (chrome.runtime && chrome.runtime.lastError) { reject(chrome.runtime.lastError); return; }
          resolve();
        });
      } catch (err) { reject(err); }
    });
  }


                                                                        
                                                                      
                                                                    
                                                                           
                                                                       
                                                                       
                                                      
  function sendToWhatsAppTab(type, payload) {
    return new Promise(function (resolve) {
      var requestId = "agenda-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      var done = false, timeoutId = null;
      function finish(result) { if (done) return; done = true; if (timeoutId) clearTimeout(timeoutId); resolve(result); }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        var tb = (tabs || [])[0];
        if (!tb) { finish(null); return; }
        var msg = Object.assign({ type: type, requestId: requestId }, payload || {});
        chrome.tabs.sendMessage(tb.id, msg, function (response) {
          if (chrome.runtime.lastError) { finish(null); return; }
          if (!response || response.requestId !== requestId || response.error) { finish(null); return; }
          finish(response.data || []);
        });
        timeoutId = setTimeout(function () { finish(null); }, 20000);
      });
    });
  }
  function searchContacts(query) { return sendToWhatsAppTab("EXTUI_DISPAROS_SEARCH_CONTACTS", { query: query }); }

  async function agendaMediaKind(item){if(item&&(item.mediaKind==="image"||item.mediaKind==="video"))return item.mediaKind;if(!item||!item.id)return"unknown";try{var c=parsePersisted(await storageGet(String(item.id)))||{},mime=String(c.mimeType||c.type||"").toLowerCase(),name=String(c.fileName||c.name||item.name||"").toLowerCase(),data=String(c.data||c.base64||"");if(c.mediaKind==="image"||c.mediaKind==="video")return c.mediaKind;if(/^data:video\//i.test(data)||mime.indexOf("video/")===0||/\.(mp4|mov|mkv|avi|3gp|flv|webm|m4v)$/.test(name))return"video";if(/^data:image\//i.test(data)||mime.indexOf("image/")===0)return"image";}catch(_){}return"unknown";}
  async function loadItemList(type) {
    var config = ITEM_STORES[type];
    var values = await Promise.all([storageGet(config.key), storageGet(QUICK_ITEMS_RECENTS_KEY)]);
    var raw = values[0];
    var parsed = null;
    try { parsed = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null; } catch (_) { parsed = null; }
    var recentRank = {},source=((parsed && parsed.state && parsed.state[config.listField]) || []);
    if(config.virtualMediaKind){var filtered=[];for(var mi=0;mi<source.length;mi++)if(await agendaMediaKind(source[mi])===config.virtualMediaKind)filtered.push(source[mi]);source=filtered;}
    (Array.isArray(values[1]) ? values[1] : []).forEach(function (recent, index) { if (recent && recent.id && (recent.type === type || (config.virtualMediaKind && recent.type === "media"))) recentRank[recent.id] = index; });
    return source.map(function (item, index) {
      return { item: item, favorite: !!item.favorite, recentRank: Object.prototype.hasOwnProperty.call(recentRank, item.id) ? recentRank[item.id] : Infinity, index: index };
    }).sort(function (a, b) {
      if (a.favorite !== b.favorite) return a.favorite ? -1 : 1;
      if (a.recentRank !== b.recentRank) return a.recentRank - b.recentRank;
      return a.index - b.index;
    });
  }
  function appendItemOptionGroups(select, rankedItems) {
    var groups = [
      { label: "Favoritos", items: rankedItems.filter(function (entry) { return entry.favorite; }) },
      { label: "Recentes", items: rankedItems.filter(function (entry) { return !entry.favorite && entry.recentRank !== Infinity; }) },
      { label: "Todos", items: rankedItems.filter(function (entry) { return !entry.favorite && entry.recentRank === Infinity; }) }
    ];
    groups.forEach(function (group) {
      if (!group.items.length) return;
      var optgroup = el("optgroup", { label: group.label });
      group.items.forEach(function (entry) { optgroup.appendChild(el("option", { value: entry.item.id, text: entry.item.name || entry.item.id })); });
      select.appendChild(optgroup);
    });
  }
  async function loadScheduleStore() {
    var raw = await storageGet(SCHEDULE_STORE_KEY),parsed={};
    if (raw != null && raw !== "") {
      try { parsed=typeof raw==="string"?JSON.parse(raw):raw; }
      catch (err) { err.code=err.code||"AGENDA_STORE_CORRUPT"; throw err; }
      if(!parsed||typeof parsed!=="object"||Array.isArray(parsed)){var invalid=new Error("Os dados da Agenda estão inválidos e não serão sobrescritos.");invalid.code="AGENDA_STORE_CORRUPT";throw invalid;}
    }
    parsed.list=Array.isArray(parsed.list)?parsed.list:[];parsed.missedHistory=Array.isArray(parsed.missedHistory)?parsed.missedHistory:[];parsed.sendAfterWhatsAppOpens=parsed.sendAfterWhatsAppOpens===true;return parsed;
  }
  async function loadSchedules(){return (await loadScheduleStore()).list;}
  async function saveSchedules(list,patch) {var store=await loadScheduleStore();store.list=list;Object.assign(store,patch||{});store.schemaVersion=Math.max(3,Number(store.schemaVersion)||0);await storageSet(SCHEDULE_STORE_KEY,JSON.stringify(store));}

  function fmtDateTime(ms) {
    var d = new Date(ms);
    return d.toLocaleDateString("pt-BR") + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  }

  function renderNewScheduleCard(wrap, onCreated) {
    var card = el("div", { class: "extuiCard extuiAgendaCreateCard" }, [el("h2", { text: "Novo agendamento" })]);
    var typeSelect = el("select", { id: "extuiAgendaType" });
    Object.keys(ITEM_STORES).filter(function(type){return !ITEM_STORES[type].legacyOnly;}).forEach(function (type) {
      if(type!=="funnel"||!window.__extPlanGate)typeSelect.appendChild(el("option", { value: type, text: ITEM_STORES[type].label }));else window.__extPlanGate.state().then(function(plan){if(plan.isPaid)typeSelect.appendChild(el("option",{value:type,text:ITEM_STORES[type].label}));});
    });
    var itemSelect = el("select", { id: "extuiAgendaItem" });
                                                                          
                                                                      
                                                                            
                                                                 
                                          
    var contactState = { phone: "", name: "" };
    var contactListId = "extuiAgendaContactPickerList-" + Date.now();
    var contactInput = el("input", { type: "text", id: "extuiAgendaContactSearch", placeholder: "Nome ou número (ex: Luan, ou 5511999999999)", autocomplete: "off", role: "combobox", "aria-autocomplete": "list", "aria-controls": contactListId, "aria-expanded": "false" });
    var contactSuggestList = el("div", { id: contactListId, class: "extuiAgendaContactPickerList", role: "listbox" });
    var contactSuggestDropdown = el("div", { class: "extuiAgendaContactPickerDropdown" }, [contactSuggestList]);
    var contactPickerWrap = el("div", { class: "extuiAgendaContactPicker" }, [contactInput, contactSuggestDropdown]);
    var dateInput = el("input", { type: "date", id: "extuiAgendaDate" });
    var timeInput = el("input", { type: "time", id: "extuiAgendaTime" });
    var recurrenceSelect=el("select",{id:"extuiAgendaRecurrence"});[{id:"none",label:"Não repetir"},{id:"daily",label:"Todos os dias"},{id:"weekly",label:"Toda semana"},{id:"monthly",label:"Todo mês"},{id:"days",label:"A cada N dias"}].forEach(function(x){recurrenceSelect.appendChild(el("option",{value:x.id,text:x.label}));});
    var recurrenceDays=el("input",{type:"number",id:"extuiAgendaRecurrenceDays",min:"1",max:"365",value:"1"});recurrenceDays.hidden=true;recurrenceSelect.addEventListener("change",function(){recurrenceDays.hidden=recurrenceSelect.value!=="days";});
    var submitBtn = el("button", { type: "button", class: "extui-btn extui-btn--primary extuiAgendaSubmitBtn", text: "Agendar" });

    async function refreshItemOptions() {
      itemSelect.innerHTML = "";
      var type = typeSelect.value;
      try {
        var list = await loadItemList(type);
        if (list.length === 0) {
          itemSelect.appendChild(el("option", { value: "", text: "Nenhum item salvo deste tipo" }));
          return;
        }
        appendItemOptionGroups(itemSelect, list);
      } catch (err) {
        itemSelect.appendChild(el("option", { value: "", text: "Erro ao carregar" }));
      }
    }
    typeSelect.addEventListener("change", refreshItemOptions);
    refreshItemOptions();

                                                                           
    var _contactSearchDebounce = null;
    var _contactSearchSeq = 0;
    function closeContactSuggestions() { contactSuggestDropdown.classList.remove("extuiOpen"); contactInput.setAttribute("aria-expanded", "false"); }
    function selectContactRow(row) {
      if (!row || !row.getAttribute("data-value")) return;
      contactState.phone = row.getAttribute("data-value");
      contactState.name = row.getAttribute("data-label") || "";
      contactInput.value = contactState.name;
      closeContactSuggestions();
      contactInput.focus();
    }
    contactInput.addEventListener("input", function () {
      contactState.phone = ""; contactState.name = "";
      var query = contactInput.value.trim();
      clearTimeout(_contactSearchDebounce);
      var seq = ++_contactSearchSeq;
      if (!query) { closeContactSuggestions(); contactSuggestList.innerHTML = ""; return; }
      contactSuggestList.innerHTML = '<div class="extuiAgendaContactPickerEmpty">Buscando...</div>';
      contactSuggestDropdown.classList.add("extuiOpen");
      contactInput.setAttribute("aria-expanded", "true");
      _contactSearchDebounce = setTimeout(async function () {
        var results = (await searchContacts(query)) || [];
        if (seq !== _contactSearchSeq || !contactPickerWrap.isConnected || contactInput.value.trim() !== query) return;
        contactSuggestList.innerHTML = "";
        if (!results.length) { contactSuggestList.appendChild(el("div", { class: "extuiAgendaContactPickerEmpty", text: "Nenhum contato encontrado - o número digitado será usado diretamente" })); return; }
        results.forEach(function (r) {
          var row = el("div", { class: "extuiAgendaContactPickerRow", role: "option", tabindex: "-1", "data-value": r.value, "data-label": r.label });
          row.appendChild(document.createTextNode(r.label + " "));
          row.appendChild(el("span", { class: "extuiAgendaContactPickerSub", text: "(" + (r.displayNumber || "") + ")" }));
          contactSuggestList.appendChild(row);
        });
      }, 250);
    });
    contactInput.addEventListener("keydown", function (ev) { if (ev.key === "ArrowDown") { var first = contactSuggestList.querySelector('[role="option"]'); if (first) { ev.preventDefault(); first.focus(); } } else if (ev.key === "Escape") { closeContactSuggestions(); } });
    contactSuggestList.addEventListener("click", function (ev) { selectContactRow(ev.target.closest(".extuiAgendaContactPickerRow")); });
    contactSuggestList.addEventListener("keydown", function (ev) {
      var row = ev.target.closest('.extuiAgendaContactPickerRow'); if (!row) return;
      var rows = Array.prototype.slice.call(contactSuggestList.querySelectorAll('.extuiAgendaContactPickerRow')), index = rows.indexOf(row);
      if (ev.key === "ArrowDown" || ev.key === "ArrowUp") { ev.preventDefault(); var next = rows[Math.max(0, Math.min(rows.length - 1, index + (ev.key === "ArrowDown" ? 1 : -1)))]; if (next) next.focus(); }
      else if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); selectContactRow(row); }
      else if (ev.key === "Escape") { ev.preventDefault(); closeContactSuggestions(); contactInput.focus(); }
    });
    if (agendaContactOutsideCleanup) agendaContactOutsideCleanup();
    var agendaOutsideClick = function (ev) { if (!contactPickerWrap.isConnected) return; if (!contactPickerWrap.contains(ev.target)) closeContactSuggestions(); };
    document.addEventListener("click", agendaOutsideClick);
    agendaContactOutsideCleanup = function () { document.removeEventListener("click", agendaOutsideClick); clearTimeout(_contactSearchDebounce); _contactSearchSeq++; agendaContactOutsideCleanup = null; };


    card.appendChild(el("div", { class: "extuiAgendaFormGrid", "data-extui-academy-target": "agenda-fields" }, [
      el("label", {}, [el("span", { text: "Tipo" }), typeSelect]),
      el("label", {}, [el("span", { text: "Item" }), itemSelect]),
      el("label", { class: "extuiAgendaContactField", "data-extui-academy-target": "agenda-contact" }, [el("span", { text: "Contato / WhatsApp" }), contactPickerWrap]),
      el("label", {}, [el("span", { text: "Data" }), dateInput]),
      el("label", {}, [el("span", { text: "Hora" }), timeInput]),
      el("label", {}, [el("span", { text: "Recorrência" }), recurrenceSelect]),
      el("label", {}, [el("span", { text: "Intervalo (dias)" }), recurrenceDays])
    ]));
    submitBtn.addEventListener("click",async function(){
      var itemId=String(itemSelect.value||""),phone=String(contactState.phone||contactInput.value||"").replace(/\D/g,""),at=parseLocalSchedule(dateInput.value,timeInput.value);
      if(!itemId){toast("Escolha um item.",true);return;}if(phone.length<8){toast("Informe um contato ou número válido.",true);return;}if(!Number.isFinite(at)||at<=Date.now()){toast("Escolha uma data e hora futuras.",true);return;}
      submitBtn.disabled=true;try{
        var plan=window.__extPlanGate?await window.__extPlanGate.state():{kind:"locked",isFree:false,isPaid:false,locked:true};
        if(!plan.isPaid&&!plan.isFree){await window.__extPlanGate.requirePaid("Agenda","agenda");return;}
        if(plan.isFree&&typeSelect.value==="funnel"){await window.__extPlanGate.requirePaid("Funis agendados","funis");return;}
        if(plan.isFree&&recurrenceSelect.value!=="none"){await window.__extPlanGate.requirePaid("Agendamentos recorrentes","agenda");return;}
        var schedules=await loadSchedules(),activeCount=schedules.filter(function(x){return x&&["scheduled","retrying","sending"].indexOf(x.status)>=0;}).length;
        if(plan.isFree)await window.__extPlanGate.requireScheduleCapacity(activeCount);
        var itemName=itemSelect.options[itemSelect.selectedIndex]?itemSelect.options[itemSelect.selectedIndex].text:itemId,recurrence={type:recurrenceSelect.value||"none"};if(recurrence.type==="days")recurrence.intervalDays=Math.max(1,Math.min(365,Number(recurrenceDays.value)||1));
        schedules.push({id:(crypto.randomUUID?crypto.randomUUID():("schedule-"+Date.now()+"-"+Math.random().toString(36).slice(2,8))),type:typeSelect.value,itemId:itemId,itemName:itemName,targetChatId:phone,targetChatName:contactState.name||"",scheduleAtMs:at,status:"scheduled",createdAt:Date.now(),sentAt:null,errorMessage:null,attempts:0,recurrence:recurrence});
        await saveSchedules(schedules);if(plan.isFree){var nextCount=schedules.filter(function(x){return x&&["scheduled","retrying","sending"].indexOf(x.status)>=0;}).length;await window.__extPlanGate.usage("commit","scheduleItem",nextCount);}
        toast("Agendado!");contactState.phone="";contactState.name="";contactInput.value="";dateInput.value="";timeInput.value="";recurrenceSelect.value="none";recurrenceDays.hidden=true;if(typeof onCreated==="function")onCreated();
      }catch(err){if(err&&err.code==="EXTAPP_PLAN_UPGRADE_REQUIRED")return;toast(err&&err.message||"Falha ao criar agendamento.",true);}finally{submitBtn.disabled=false;}
    });
    card.appendChild(submitBtn);
    wrap.appendChild(card);
  }

  function renderListCard(wrap, schedules, onChanged) {
    var card = el("div", { class: "extuiCard extuiAgendaListCard", "data-extui-academy-target": "agenda-list" }, [el("h2", { text: "Itens agendados" })]);
    var searchWrap = el("div", { class: "extuiSearch" }, [icon("search")]);
    var searchInput = el("input", { type: "text", id: "extuiAgendaSearch", placeholder: "Buscar por nome ou número..." });
    searchWrap.appendChild(searchInput);
    card.appendChild(searchWrap);
    var listEl = el("div", { class: "extuiAgendaList" });
    card.appendChild(listEl);

    function renderRows(filterText) {
      listEl.innerHTML = "";
      var filtered = schedules.filter(function (s) {
        if (!filterText) return true;
        var t = filterText.toLowerCase();
        return (s.itemName || "").toLowerCase().indexOf(t) !== -1 || (s.targetChatName || "").toLowerCase().indexOf(t) !== -1 || (s.targetChatId || "").indexOf(t) !== -1;
      }).sort(function (a, b) { return a.scheduleAtMs - b.scheduleAtMs; });
      if (filtered.length === 0) {
        listEl.appendChild(el("div", { class: "extuiAgendaEmpty" }, [
          icon("calendar", "extuiAgendaEmptyIcon"),
          el("span", { text: "Nenhum item agendado" })
        ]));
        return;
      }
      filtered.forEach(function (s) {
        var config = ITEM_STORES[s.type];
        var row = el("div", { class: "extuiAgendaRow" });
        row.appendChild(el("span", { class: "extuiAgendaRowIcon" }, [icon(config ? config.icon : "unknown")]));
                                                                          
                                                                       
                                         
        var mid = el("div", { class: "extuiAgendaRowMid" }, [
          el("div", { class: "extuiAgendaRowName", text: s.itemName || s.itemId }),
          el("div", { class: "extuiAgendaRowMeta" }, [
            el("span", { text: (s.targetChatName ? s.targetChatName + " · " : "") + s.targetChatId + " · " }),
            el("span", { class: "extuiAgendaRowWhen", text: fmtDateTime(s.scheduleAtMs) })
          ])
        ]);
        row.appendChild(mid);
        row.appendChild(el("span", { class: "extuiAgendaStatus extuiAgendaStatus--" + s.status, text: STATUS_LABELS[s.status] || s.status }));
        if (s.status === "scheduled") {
          var cancelBtn = el("button", { type: "button", class: "extuiAgendaCancelBtn", text: "Cancelar" });
          cancelBtn.addEventListener("click", async function () {
            if (!await extConfirm("Cancelar este agendamento?", { danger: true })) return;
            s.status = "cancelled";
            try { await saveSchedules(schedules); onChanged(); } catch (err) { toast("Falha ao cancelar", true); }
          });
          row.appendChild(cancelBtn);
        }
        if (s.status === "error" && s.errorMessage) row.title = s.errorMessage;
        listEl.appendChild(row);
      });
    }
    searchInput.addEventListener("input", function () { renderRows(searchInput.value); });
    renderRows("");
    wrap.appendChild(card);
  }

  async function renderAgendaSection(container) {
    if (container._extuiAgendaUnsubscribe) { try { container._extuiAgendaUnsubscribe(); } catch (_) {} container._extuiAgendaUnsubscribe = null; }
    var wrap = el("div", { class: "extuiAgendaSection" }), refreshTimer = 0, agendaSectionChangeHandler = null;
    function cleanupAgendaWatch() {
      clearTimeout(refreshTimer);
      if (container._extuiAgendaUnsubscribe) { try { container._extuiAgendaUnsubscribe(); } catch (_) {} container._extuiAgendaUnsubscribe = null; }
      if (agendaSectionChangeHandler) { document.removeEventListener("ext:dashboard-section-change", agendaSectionChangeHandler); agendaSectionChangeHandler = null; }
    }
    container.appendChild(wrap);

    async function renderDeliveryPreference(){var store=await loadScheduleStore(),card=el("div",{class:"extuiCard extuiAgendaPreferenceCard","data-extui-academy-target":"agenda-offline"},[el("h2",{text:"Quando o WhatsApp estava fechado"})]),label=el("label",{class:"extuiPersonalizacaoCheck"}),box=el("input",{type:"checkbox"});box.checked=store.sendAfterWhatsAppOpens===true;label.appendChild(box);label.appendChild(document.createTextNode(" Enviar somente se o horário venceu há no máximo 5 minutos"));card.appendChild(label);card.appendChild(el("p",{class:"extuiAjustesKeyLabel",text:"Quando ativado, itens muito atrasados são marcados como não enviados em vez de serem disparados ao reabrir o WhatsApp."}));box.addEventListener("change",async function(){var s=await loadScheduleStore();s.sendAfterWhatsAppOpens=box.checked;await storageSet(SCHEDULE_STORE_KEY,JSON.stringify(s));toast("Preferência da Agenda salva.");});wrap.appendChild(card);}

    async function reload() {
      var schedules;
      try {
        schedules = await loadSchedules();
      } catch (err) {
        schedules = [];
      }
      wrap.innerHTML = "";
      var now = Date.now(), today = new Date(now);
      var todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
      var tomorrowStart = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1).getTime();
      var scheduled = schedules.filter(function(s){return s.status==="scheduled";});
      var todayCount = scheduled.filter(function(s){return s.scheduleAtMs >= todayStart && s.scheduleAtMs < tomorrowStart;}).length;
      var errorCount = schedules.filter(function(s){return s.status==="error";}).length;
      var next = scheduled.slice().sort(function(a,b){return a.scheduleAtMs-b.scheduleAtMs;}).find(function(s){return s.scheduleAtMs>=now;});
      var summary = el("div", { class: "extuiAgendaSummary" }, [
        el("div",{},[el("span",{text:"Agendados"}),el("strong",{text:String(scheduled.length)}),el("small",{text:"ativos"})]),
        el("div",{},[el("span",{text:"Hoje"}),el("strong",{text:String(todayCount)}),el("small",{text:"para executar"})]),
        el("div",{},[el("span",{text:"Erros"}),el("strong",{text:String(errorCount)}),el("small",{text:errorCount?"requer atenção":"sem falhas"})]),
        el("div",{},[el("span",{text:"Próximo"}),el("strong",{text:next?fmtDateTime(next.scheduleAtMs):"—"}),el("small",{text:next?(next.itemName||"item agendado"):"nenhum próximo"})])
      ]);
      wrap.appendChild(summary);
      renderNewScheduleCard(wrap, reload);
      renderListCard(wrap, schedules, reload);
      await renderDeliveryPreference();
    }
    await reload();
    if (window.ExtensionStorage && typeof window.ExtensionStorage.subscribe === "function") {
      container._extuiAgendaUnsubscribe = window.ExtensionStorage.subscribe(SCHEDULE_STORE_KEY, function (next, previous, key, meta) {
        if (meta && meta.local === true) return;
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(function () { if (wrap.isConnected) reload(); }, 45);
      });
      agendaSectionChangeHandler = function (event) {
        if (!event.detail || event.detail.section !== "agenda") cleanupAgendaWatch();
      };
      document.addEventListener("ext:dashboard-section-change", agendaSectionChangeHandler);
    }
  }

  document.addEventListener("ext:dashboard-section-change", function (event) { if (!event.detail || event.detail.section !== "agenda") { if (agendaContactOutsideCleanup) agendaContactOutsideCleanup(); } });
  window.__extDashboardShell.registerSection("agenda", renderAgendaSection);
})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
