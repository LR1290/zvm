;

try{
(function () {
  "use strict";

  if (window.__extSalvarDashModuleBooted) return;
  window.__extSalvarDashModuleBooted = true;

                                                                             
                                                                            
                                                                          
                                                                  
                                                                             
                                                                          
                                                                             
                                                                           
                                                                     
                                                                          
                                  
  var EXPORT_TIMEOUT_MS = 25000;

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else if (k.indexOf("on") === 0 && typeof attrs[k] === "function") e.addEventListener(k.slice(2).toLowerCase(), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }
  function toast(message, isError) { return window.__extDashboardShell.toast(message, !!isError); }

                                                                            
                                                                             
                              
  function sendToWhatsAppTab(type, payload) {
    return new Promise(function (resolve, reject) {
      var requestId = "salvar-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      var done = false, timeoutId = null;
      function finish(result) { if (done) return; done = true; if (timeoutId) clearTimeout(timeoutId); resolve(result); }
      function fail(code, message) { if (done) return; done = true; if (timeoutId) clearTimeout(timeoutId); var err = new Error(message); err.code = code; reject(err); }
      chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, function (tabs) {
        if (chrome.runtime.lastError) { fail("WHATSAPP_TAB_QUERY_FAILED", chrome.runtime.lastError.message || "Não foi possível localizar o WhatsApp Web."); return; }
        var tb = (tabs || [])[0];
        if (!tb) { fail("WHATSAPP_TAB_NOT_FOUND", "Abra o WhatsApp Web para carregar estes dados."); return; }
        var msg = Object.assign({ type: type, requestId: requestId }, payload || {});
        chrome.tabs.sendMessage(tb.id, msg, function (response) {
          if (chrome.runtime.lastError) { fail("WHATSAPP_MESSAGE_FAILED", chrome.runtime.lastError.message || "Não foi possível comunicar com o WhatsApp Web."); return; }
          if (!response || response.requestId !== requestId) { fail("WHATSAPP_RESPONSE_INVALID", "A resposta do WhatsApp Web não corresponde à solicitação."); return; }
          if (response.error) { fail(response.code || "WHATSAPP_RESPONSE_ERROR", String(response.error)); return; }
          finish(response.data || []);
        });
        timeoutId = setTimeout(function () { fail("WHATSAPP_RESPONSE_TIMEOUT", "O WhatsApp Web demorou demais para responder."); }, 20000);
      });
    });
  }
  function fetchLabels() { return sendToWhatsAppTab("EXTUI_DISPAROS_FETCH_LABELS"); }
  function fetchGroups() { return sendToWhatsAppTab("EXTUI_SALVAR_FETCH_GROUPS"); }

                                                                          
                                                                    
                                                                      
                                                                    
  function requestExport(payload) {
    return window.__extDashboardShell.sendToWhatsAppTab("EXTUI_EXPORT_CONTACTS", payload, EXPORT_TIMEOUT_MS);
  }

  function renderSalvar(root) {
    var state = { step:1, source:"all", labelIds:[], groupId:"", prefix:"", limit:0, format:"csv", labelsCache:null, groupsCache:null, lastPreview:null, lastPreviewKey:"", previewBusy:false };
    root.innerHTML = "";
    var wrap = el("div", { class:"extuiContactExport" }); root.appendChild(wrap);
    var header = el("section", { class:"extuiContactExportHeader extuiPageCompactHeader" }, [
      el("div", { class:"extuiPageCompactHeaderCopy" }, [
        el("span", { class:"extuiContactExportEyebrow", text:"EXPORTAÇÃO DE CONTATOS" }),
        el("h2", { text:"Exportar contatos" }),
        el("p", { text:"Escolha a origem, confira o recorte e selecione o formato antes de baixar." })
      ])
    ]);
    var stepper=el("div",{class:"extuiContactExportStepper",role:"list","aria-label":"Etapas da exportação"});
    var stepDefs=[[1,"Origem","De onde vêm os contatos"],[2,"Recorte","Quem entra no arquivo"],[3,"Exportar","Formato e confirmação"]],stepButtons=[];
    stepDefs.forEach(function(def){var b=el("button",{type:"button",class:"extuiContactExportStep",role:"listitem"},[el("b",{text:String(def[0])}),el("span",{},[el("strong",{text:def[1]}),el("small",{text:def[2]})])]);b.dataset.step=String(def[0]);b.addEventListener("click",function(){if(def[0]<state.step)goStep(def[0]);});stepButtons.push(b);stepper.appendChild(b);});
    header.appendChild(stepper);wrap.appendChild(header);
    var panel=el("section",{class:"extuiContactExportPanel"});wrap.appendChild(panel);

    function payloadKey(payload){return JSON.stringify(payload||{});}
    function currentFilterPayload(){if(state.source==="labels")return{source:"labels",labelIds:state.labelIds.slice()};if(state.source==="group")return{source:"group",groupId:state.groupId};if(state.source==="customers")return{source:"customers"};return{source:"all",prefix:String(state.prefix||"").trim(),limit:Math.max(0,parseInt(state.limit,10)||0)};}
    function filterValid(payload){payload=payload||currentFilterPayload();if(payload.source==="labels")return payload.labelIds.length>0;if(payload.source==="group")return !!payload.groupId;return true;}
    function sourceName(){return state.source==="labels"?"Etiquetas":state.source==="group"?"Grupo":state.source==="customers"?"Painel de Clientes":"Todos os contatos";}
    function stepHead(kicker,title,desc){return el("div",{class:"extuiContactExportPanelHead"},[el("span",{text:kicker}),el("h3",{text:title}),el("p",{text:desc})]);}
    function actions(left,right){var row=el("div",{class:"extuiContactExportActions","data-extui-academy-target":"salvar-actions"});(left||[]).forEach(function(x){row.appendChild(x);});row.appendChild(el("span",{class:"extuiContactExportActionSpacer"}));(right||[]).forEach(function(x){row.appendChild(x);});return row;}
    function updateStepper(){stepButtons.forEach(function(b,index){var step=index+1;b.classList.toggle("is-active",step===state.step);b.classList.toggle("is-complete",step<state.step);b.disabled=step>state.step;b.setAttribute("aria-current",step===state.step?"step":"false");});}
    function goStep(step){state.step=Math.max(1,Math.min(3,Number(step)||1));updateStepper();renderStep();}

    function renderSourceStep(){panel.innerHTML="";panel.appendChild(stepHead("PASSO 1 DE 3","Escolha a origem","Comece pelo conjunto de contatos que deseja exportar."));var grid=el("div",{class:"extuiContactExportSourceGrid","data-extui-academy-target":"salvar-source"});[
      ["all","Todos os contatos","Use a lista geral e, se quiser, limite a quantidade."],
      ["labels","Por etiqueta","Exporte somente contatos com uma ou mais etiquetas do WhatsApp Business."],
      ["group","Por grupo","Exporte participantes de um grupo específico."],
      ["customers","Painel de Clientes","Use os clientes cadastrados na base centralizada, mantendo o formato atual de exportação."]
    ].forEach(function(def){var b=el("button",{type:"button",class:"extuiContactExportSource"+(state.source===def[0]?" is-active":"")},[el("span",{class:"extuiContactExportSourceMark"}),el("strong",{text:def[1]}),el("small",{text:def[2]})]);b.addEventListener("click",function(){state.source=def[0];state.lastPreview=null;state.lastPreviewKey="";grid.querySelectorAll(".extuiContactExportSource").forEach(function(x){x.classList.remove("is-active");});b.classList.add("is-active");});grid.appendChild(b);});panel.appendChild(grid);var next=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Continuar: definir recorte →"});next.addEventListener("click",function(){goStep(2);});panel.appendChild(actions([], [next]));}

    function previewState(box,message,mode){box.innerHTML="";box.appendChild(el("div",{class:"extuiContactExportPreviewState "+(mode||""),text:message}));}
    function paintPreview(box,result,payload){box.innerHTML="";var count=Math.max(0,Number(result&&result.count)||0),contacts=result&&Array.isArray(result.contacts)?result.contacts:[],unresolved=Math.max(0,Number(result&&result.unresolvedCount)||0);box.appendChild(el("div",{class:"extuiContactExportPreviewHead"},[el("div",{},[el("strong",{text:count+" contato"+(count===1?" encontrado":"s encontrados")}),el("small",{text:contacts.length<count?"Prévia: "+contacts.length+" de "+count+" contatos.":"Prévia atualizada com o recorte atual."})]),el("span",{text:sourceName()})]));if(unresolved)box.appendChild(el("div",{class:"extuiContactExportNotice",text:unresolved+" registro(s) sem telefone resolvido não serão exportados."}));var list=el("div",{class:"extuiContactExportPreviewList"});if(!contacts.length)list.appendChild(el("div",{class:"extuiContactExportPreviewEmpty",text:"Nenhum contato encontrado com este recorte."}));contacts.slice(0,80).forEach(function(contact,index){var name=String(contact&&contact.name||"Contato sem nome"),phone=String(contact&&contact.user||"");list.appendChild(el("div",{class:"extuiContactExportPreviewRow"},[el("span",{text:String(index+1).padStart(2,"0")}),el("strong",{text:name,title:name}),el("small",{text:phone,title:phone})]));});box.appendChild(list);}
    async function customerExport(payload){
      if(!window.ExtensionCustomerStore)throw new Error("O Painel de Clientes ainda não está disponível.");
      var customers=await window.ExtensionCustomerStore.list(),contacts=customers.map(function(c){return{name:String(c.name||c.whatsappName||"Contato sem nome"),user:String(c.phone||"").replace(/\D/g,"")};}).filter(function(c){return c.user.length>=8;});
      if(payload&&payload.previewOnly)return{count:contacts.length,contacts:contacts.slice(0,200),unresolvedCount:Math.max(0,customers.length-contacts.length),truncated:contacts.length>200};
      if(!contacts.length)throw new Error("Nenhum cliente com WhatsApp válido foi encontrado.");
      function csvCell(value){var t=String(value==null?"":value).replace(/^\s*([=+\-@])/,"'$1").replace(/\u0000/g,"");return '"'+t.replace(/"/g,'""')+'"';}
      function vText(value){return String(value==null?"":value).replace(/\\/g,"\\\\").replace(/\r\n|\r|\n/g,"\\n").replace(/;/g,"\\;").replace(/,/g,"\\,");}
      var dateStr=new Date().toLocaleDateString("pt-BR").split("/").join("-"),blob,filename;
      if(payload&&payload.format==="vcf"){var vcf=contacts.map(function(c){var n=vText(c.name),p=c.user.replace(/[^0-9+]/g,"");return "BEGIN:VCARD\r\nVERSION:3.0\r\nN:"+n+"\r\nFN:"+n+"\r\nTEL;TYPE=VOICE:"+p+"\r\nEND:VCARD";}).join("\r\n");blob=new Blob([vcf],{type:"text/vcard"});filename=contacts.length+"_contatos_("+dateStr+").vcf";}else{var rows=[["First Name","Mobile Phone"]].concat(contacts.map(function(c){return[c.name,c.user];})),csv=rows.map(function(row){return row.map(csvCell).join(",");}).join("\r\n")+"\r\n";blob=new Blob(["﻿"+csv],{type:"text/csv"});filename=contacts.length+"_contatos_("+dateStr+").csv";}
      var url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},1500);return{count:contacts.length,unresolvedCount:Math.max(0,customers.length-contacts.length)};
    }
    async function refreshPreview(box,manual){var payload=currentFilterPayload();if(!filterValid(payload)){state.lastPreview=null;state.lastPreviewKey="";previewState(box,payload.source==="labels"?"Selecione ao menos uma etiqueta.":"Selecione um grupo.","is-waiting");return null;}state.previewBusy=true;previewState(box,"Buscando contatos no WhatsApp…","is-loading");try{var result=payload.source==="customers"?await customerExport(Object.assign({},payload,{format:state.format,previewOnly:true})):await requestExport(Object.assign({},payload,{format:state.format,previewOnly:true}));state.lastPreview=result||{count:0,contacts:[]};state.lastPreviewKey=payloadKey(payload);paintPreview(box,state.lastPreview,payload);return state.lastPreview;}catch(err){state.lastPreview=null;state.lastPreviewKey="";previewState(box,err&&err.message?err.message:"Não foi possível carregar a prévia.","is-error");if(manual)toast(err&&err.message?err.message:"Falha ao atualizar a prévia.",true);return null;}finally{state.previewBusy=false;}}

    function renderAllFilter(filterHost){var grid=el("div",{class:"extuiContactExportFieldGrid"});var prefix=el("input",{type:"text",id:"extuiSalvarPrefix",placeholder:"Ex.: Cliente -"});prefix.value=state.prefix;prefix.addEventListener("input",function(){state.prefix=prefix.value;state.lastPreviewKey="";});var limit=el("input",{type:"number",id:"extuiSalvarLimit",min:"0",step:"1",value:String(state.limit||0)});limit.value=String(state.limit||0);limit.addEventListener("input",function(){state.limit=Math.max(0,parseInt(limit.value,10)||0);state.lastPreviewKey="";});grid.appendChild(el("label",{class:"extuiContactExportField"},[el("span",{text:"Prefixo no nome (opcional)"}),prefix,el("small",{text:"Adiciona um texto antes do nome no arquivo exportado."})]));grid.appendChild(el("label",{class:"extuiContactExportField"},[el("span",{text:"Quantidade máxima de contatos"}),limit,el("small",{text:"0 = exportar todos os contatos encontrados."})]));filterHost.appendChild(grid);}
    function renderLabelsFilter(filterHost,onReady){var list=el("div",{class:"extuiContactExportPicker"},[el("div",{class:"extuiContactExportPickerState",text:"Carregando etiquetas…"})]);filterHost.appendChild(list);(state.labelsCache?Promise.resolve(state.labelsCache):fetchLabels()).then(function(labels){state.labelsCache=labels||[];list.innerHTML="";if(!state.labelsCache.length){list.appendChild(el("div",{class:"extuiContactExportPickerState",text:"Nenhuma etiqueta encontrada. O WhatsApp Business precisa estar aberto."}));onReady&&onReady();return;}state.labelsCache.forEach(function(label){var row=el("label",{class:"extuiContactExportCheck"}),cb=el("input",{type:"checkbox"});cb.checked=state.labelIds.indexOf(label.id)!==-1;cb.addEventListener("change",function(){var idx=state.labelIds.indexOf(label.id);if(cb.checked&&idx<0)state.labelIds.push(label.id);if(!cb.checked&&idx>=0)state.labelIds.splice(idx,1);state.lastPreviewKey="";});row.appendChild(cb);row.appendChild(el("span",{text:label.name||"Etiqueta"}));list.appendChild(row);});onReady&&onReady();}).catch(function(){list.innerHTML="";list.appendChild(el("div",{class:"extuiContactExportPickerState is-error",text:"Não foi possível carregar as etiquetas."}));onReady&&onReady();});}
    function renderGroupFilter(filterHost,onReady){var select=el("select",{class:"extuiContactExportGroup"},[el("option",{value:"",text:"Carregando grupos…"})]);filterHost.appendChild(el("label",{class:"extuiContactExportField"},[el("span",{text:"Grupo do WhatsApp"}),select,el("small",{text:"Somente participantes com telefone resolvido entram no arquivo."})]));select.addEventListener("change",function(){state.groupId=select.value;state.lastPreviewKey="";});(state.groupsCache?Promise.resolve(state.groupsCache):fetchGroups()).then(function(groups){state.groupsCache=groups||[];select.innerHTML="";select.appendChild(new Option(state.groupsCache.length?"Selecione um grupo…":"Nenhum grupo encontrado",""));state.groupsCache.forEach(function(group){select.appendChild(new Option(group.label,group.value));});select.value=state.groupId||"";onReady&&onReady();}).catch(function(){select.innerHTML="";select.appendChild(new Option("Falha ao carregar grupos",""));onReady&&onReady();});}

    function renderFilterStep(){panel.innerHTML="";panel.appendChild(stepHead("PASSO 2 DE 3","Defina o recorte","Ajuste somente o que for necessário e confira a prévia antes de continuar."));panel.appendChild(el("div",{class:"extuiContactExportContext"},[el("span",{text:"Origem"}),el("strong",{text:sourceName()}),el("button",{type:"button",class:"extuiContactExportInlineLink",text:"Alterar"})]));panel.lastChild.lastChild.addEventListener("click",function(){goStep(1);});var filterHost=el("div",{class:"extuiContactExportFilters"}),preview=el("div",{class:"extuiContactExportPreview"});panel.appendChild(filterHost);panel.appendChild(preview);var update=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Atualizar prévia"}),back=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"← Voltar à origem"}),next=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Continuar: escolher formato →"});function syncNext(){next.disabled=!filterValid();}update.addEventListener("click",async function(){update.disabled=true;await refreshPreview(preview,true);update.disabled=false;syncNext();});back.addEventListener("click",function(){goStep(1);});next.addEventListener("click",async function(){if(!filterValid()){toast(state.source==="labels"?"Selecione ao menos uma etiqueta.":"Selecione um grupo.",true);return;}next.disabled=true;if(state.lastPreviewKey!==payloadKey(currentFilterPayload()))await refreshPreview(preview,false);next.disabled=false;if(state.lastPreview)goStep(3);});var hook=function(){syncNext();if(filterValid())refreshPreview(preview,false);else previewState(preview,state.source==="labels"?"Selecione uma ou mais etiquetas para gerar a prévia.":"Selecione um grupo para gerar a prévia.","is-waiting");};if(state.source==="all"){renderAllFilter(filterHost);hook();filterHost.addEventListener("input",function(){syncNext();});}else if(state.source==="labels")renderLabelsFilter(filterHost,function(){filterHost.addEventListener("change",function(){syncNext();});hook();});else if(state.source==="group")renderGroupFilter(filterHost,function(){filterHost.addEventListener("change",function(){syncNext();if(filterValid())refreshPreview(preview,false);});hook();});else{filterHost.appendChild(el("div",{class:"extuiContactExportNotice",text:"Os clientes serão lidos da base centralizada do Painel de Clientes. O arquivo final continuará usando o mesmo formato da exportação atual."}));hook();}panel.appendChild(actions([back,update],[next]));}

    function renderExportStep(){panel.innerHTML="";panel.appendChild(stepHead("PASSO 3 DE 3","Escolha o formato e exporte","Confira o resumo e faça o download."));var summary=el("div",{class:"extuiContactExportSummary"},[el("div",{},[el("span",{text:"Origem"}),el("strong",{text:sourceName()})]),el("div",{},[el("span",{text:"Contatos encontrados"}),el("strong",{text:String(Math.max(0,Number(state.lastPreview&&state.lastPreview.count)||0))})]),el("div",{},[el("span",{text:"Limite"}),el("strong",{text:state.source==="all"?(state.limit?String(state.limit):"Todos"):"Conforme origem"})])]);panel.appendChild(summary);var formats=el("div",{class:"extuiContactExportFormats"});[["csv","Planilha (.csv)","Ideal para Excel, Google Sheets e análise em tabela."],["vcf","Contatos (.vcf)","Ideal para importar contatos em agendas e telefones."]].forEach(function(def){var b=el("button",{type:"button",class:"extuiContactExportFormat"+(state.format===def[0]?" is-active":"")},[el("span",{class:"extuiContactExportFormatRadio"}),el("strong",{text:def[1]}),el("small",{text:def[2]})]);b.addEventListener("click",function(){state.format=def[0];formats.querySelectorAll(".extuiContactExportFormat").forEach(function(x){x.classList.remove("is-active");});b.classList.add("is-active");});formats.appendChild(b);});panel.appendChild(formats);var back=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"← Voltar ao recorte"}),exportBtn=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:"Exportar contatos"});back.addEventListener("click",function(){goStep(2);});exportBtn.addEventListener("click",async function(){var payload=currentFilterPayload();if(!filterValid(payload)){goStep(2);return;}exportBtn.disabled=true;exportBtn.textContent="Exportando…";try{var result=payload.source==="customers"?await customerExport(Object.assign({},payload,{format:state.format,previewOnly:false})):await requestExport(Object.assign({},payload,{format:state.format,previewOnly:false}));toast((Number(result&&result.count)||0)+" contato(s) exportado(s).");}catch(err){toast(err&&err.message?err.message:"Falha ao exportar.",true);}finally{exportBtn.disabled=false;exportBtn.textContent="Exportar contatos";}});panel.appendChild(actions([back],[exportBtn]));}

    function renderStep(){if(state.step===1)renderSourceStep();else if(state.step===2)renderFilterStep();else renderExportStep();}
    updateStepper();renderStep();
  }

  window.__extDashboardShell.registerSection("salvar", renderSalvar);

})();
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
