;(function(){
"use strict";
if(window.__extAutomationMetadataModal)return;
var DEFAULT_PALETTE=["#10b981","#3b82f6","#8b5cf6","#f59e0b","#ef4444","#22d3ee","#f472b6","#fb923c","#fbbf24"];
function el(tag,attrs,children){
  var node=document.createElement(tag);attrs=attrs||{};
  Object.keys(attrs).forEach(function(key){
    var value=attrs[key];
    if(key==="class")node.className=value;
    else if(key==="text")node.textContent=value;
    else if(key.indexOf("on")===0&&typeof value==="function")node.addEventListener(key.slice(2).toLowerCase(),value);
    else node.setAttribute(key,value);
  });
  (children||[]).forEach(function(child){if(child)node.appendChild(child);});
  return node;
}
function open(options){
  options=options||{};
  return new Promise(function(resolve){
    var previousFocus=document.activeElement,settled=false;
    var overlay=el("div",{class:"extui-modal-overlay extuiAutomationMetaModalOverlay"});
    var modal=el("div",{class:"extuiCrmModal extuiAutomationMetaModal",role:"dialog","aria-modal":"true",tabindex:"-1"});
    var titleId="extui-automation-meta-title-"+Date.now();
    modal.setAttribute("aria-labelledby",titleId);
    modal.appendChild(el("h3",{id:titleId,text:options.title||"Editar automação"}));
    var form=el("div",{class:"extuiAutomationMetaForm"});
    form.appendChild(el("label",{text:options.nameLabel||"Nome"}));
    var nameInput=el("input",{type:"text",maxlength:String(options.nameMaxLength||160),placeholder:options.namePlaceholder||"Nome"});
    nameInput.value=String(options.name||"");form.appendChild(nameInput);
    form.appendChild(el("label",{text:"Descrição"}));
    var descriptionInput=el("textarea",{maxlength:String(options.descriptionMaxLength||300),rows:"4",placeholder:options.descriptionPlaceholder||"Descrição (opcional)"});
    descriptionInput.value=String(options.description||"");form.appendChild(descriptionInput);
    form.appendChild(el("label",{text:"Cor de identificação"}));
    var chosen=String(options.color||options.defaultColor||DEFAULT_PALETTE[0]);
    var palette=Array.isArray(options.palette)&&options.palette.length?options.palette.slice():DEFAULT_PALETTE.slice();
    var picker=el("div",{class:"extui-modal__colors extuiHybridColorPicker",role:"radiogroup","aria-label":"Cor de identificação"});
    var presets=el("div",{class:"extuiHybridColorPickerPresets"});
    var controls=el("div",{class:"extuiHybridColorPickerControls"});
    var nativeInput=el("input",{type:"color",class:"extuiHybridColorNative",value:/^#[0-9a-f]{6}$/i.test(chosen)?chosen:"#10b981","aria-label":"Escolher outra cor"});
    var customBtn=el("button",{type:"button",class:"extuiHybridColorCustomBtn","aria-label":"Escolher outra cor",title:"Escolher outra cor"});
    var customSwatch=el("span",{class:"extuiHybridColorCustomSwatch","aria-hidden":"true"});
    customBtn.appendChild(customSwatch);
    customBtn.appendChild(el("span",{class:"extuiHybridColorCustomText",text:"Outra cor"}));
    customBtn.appendChild(el("span",{class:"extuiHybridColorCustomIcon",text:"⌾","aria-hidden":"true"}));
    function syncCustom(activePreset){
      customSwatch.style.background=chosen;
      customBtn.style.setProperty("--extui-custom-color",chosen);
      customBtn.classList.toggle("is-selected",!activePreset&&palette.indexOf(chosen)<0);
      if(/^#[0-9a-f]{6}$/i.test(chosen))nativeInput.value=chosen;
    }
    function activate(swatch,color){
      chosen=String(color||DEFAULT_PALETTE[0]);
      Array.prototype.forEach.call(presets.querySelectorAll(".extui-modal__color"),function(item){
        var active=item===swatch;
        item.classList.toggle("selected",active);
        item.setAttribute("aria-checked",active?"true":"false");
        item.setAttribute("tabindex",active?"0":"-1");
      });
      syncCustom(swatch);
    }
    palette.forEach(function(color){
      var selected=String(color).toLowerCase()===chosen.toLowerCase();
      var sw=el("button",{type:"button",class:"extui-modal__color extuiHybridColorPreset"+(selected?" selected":""),role:"radio","aria-label":"Cor "+color,"aria-checked":selected?"true":"false",tabindex:selected?"0":"-1"});
      sw.style.background=color;
      sw.addEventListener("click",function(){activate(sw,color);});
      sw.addEventListener("keydown",function(event){
        if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].indexOf(event.key)<0)return;
        event.preventDefault();
        var items=Array.prototype.slice.call(presets.querySelectorAll(".extui-modal__color"));
        var current=items.indexOf(sw),delta=(event.key==="ArrowLeft"||event.key==="ArrowUp")?-1:1,next=items[(current+delta+items.length)%items.length];
        if(next){next.focus();next.click();}
      });
      presets.appendChild(sw);
    });
    customBtn.addEventListener("click",function(){nativeInput.click();});
    nativeInput.addEventListener("input",function(){activate(null,nativeInput.value);});
    nativeInput.addEventListener("change",function(){activate(null,nativeInput.value);});
    controls.appendChild(customBtn);controls.appendChild(nativeInput);picker.appendChild(presets);picker.appendChild(controls);
    form.appendChild(picker);
    if(options.hint)form.appendChild(el("p",{class:"extuiAutomationMetaHint",text:options.hint}));
    var error=el("p",{class:"extuiAutomationMetaError",role:"alert","aria-live":"polite"});error.hidden=true;form.appendChild(error);
    modal.appendChild(form);
    var actions=el("div",{class:"extui-modal__actions"});
    var cancelBtn=el("button",{type:"button",class:"extui-btn extui-btn--ghost",text:"Cancelar"});
    var confirmBtn=el("button",{type:"button",class:"extui-btn extui-btn--primary",text:options.confirmLabel||"Salvar"});
    actions.appendChild(cancelBtn);actions.appendChild(confirmBtn);modal.appendChild(actions);overlay.appendChild(modal);
    function finish(value){
      if(settled)return;settled=true;
      document.removeEventListener("keydown",onKeyDown,true);overlay.remove();
      if(previousFocus&&previousFocus.isConnected&&typeof previousFocus.focus==="function"){try{previousFocus.focus({preventScroll:true});}catch(_){previousFocus.focus();}}
      resolve(value);
    }
    function focusables(){return Array.prototype.slice.call(modal.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(function(node){return !node.hidden;});}
    function onKeyDown(event){
      if(event.key==="Escape"){event.preventDefault();finish(null);return;}
      if(event.key!=="Tab")return;
      var nodes=focusables();if(!nodes.length)return;
      var first=nodes[0],last=nodes[nodes.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
    async function submit(){
      var name=String(nameInput.value||"").trim(),description=String(descriptionInput.value||"").trim();
      error.hidden=true;error.textContent="";
      if(!name){error.textContent=options.emptyNameMessage||"Informe um nome.";error.hidden=false;nameInput.focus();return;}
      if(typeof options.validateName==="function"){
        var verdict=await options.validateName(name);
        if(verdict!==true){error.textContent=typeof verdict==="string"?verdict:"Já existe um item com esse nome.";error.hidden=false;nameInput.focus();nameInput.select();return;}
      }
      finish({name:name,description:description,color:chosen});
    }
    cancelBtn.addEventListener("click",function(){finish(null);});
    confirmBtn.addEventListener("click",function(){submit().catch(function(err){error.textContent=err&&err.message||"Não foi possível validar os dados.";error.hidden=false;});});
    overlay.addEventListener("click",function(event){if(event.target===overlay)finish(null);});
    document.addEventListener("keydown",onKeyDown,true);
    document.body.appendChild(overlay);
    var activePreset=presets.querySelector(".selected");syncCustom(activePreset);
    requestAnimationFrame(function(){nameInput.focus();nameInput.select();});
  });
}
window.__extAutomationMetadataModal=Object.freeze({open:open,palette:DEFAULT_PALETTE.slice()});
})();