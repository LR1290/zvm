;
try{
(function(){
  "use strict";
  if(window.__extBroadcastEmbedEntryBooted)return;
  window.__extBroadcastEmbedEntryBooted=true;

  var mount=document.getElementById("extuiBroadcastEmbedRoot");
  var sections=Object.create(null),navigationGuard=null,authorized=false,authorizationSettled=false,rendering=false;
  var query=new URLSearchParams(location.search),instance=String(query.get("embedInstance")||"");

  function trustedContext(){
    if(window.parent===window||query.get("embed")!=="whatsapp"||!/^[A-Za-z0-9_-]{8,128}$/.test(instance))return false;
    try{
      var ancestors=location.ancestorOrigins;
      if(ancestors&&ancestors.length&&String(ancestors[0])!=="https://web.whatsapp.com")return false;
    }catch(_){}
    try{
      if(document.referrer&&new URL(document.referrer).origin!=="https://web.whatsapp.com")return false;
    }catch(_){return false;}
    return true;
  }
  function clear(){while(mount&&mount.firstChild)mount.firstChild.remove();}
  if(!window.__extDialogLifecycle){
    window.__extDialogLifecycle=function(overlay,modal,opts){
      opts=opts||{};var previousFocus=document.activeElement,closed=false;
      if(!modal.getAttribute("role"))modal.setAttribute("role","dialog");
      if(!modal.hasAttribute("aria-modal"))modal.setAttribute("aria-modal","true");
      if(!modal.hasAttribute("tabindex"))modal.setAttribute("tabindex","-1");
      function focusables(){return Array.prototype.slice.call(modal.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')).filter(function(node){return !node.hidden&&node.getAttribute("aria-hidden")!=="true"&&node.getClientRects().length;});}
      function cleanup(){document.removeEventListener("keydown",onKeyDown,true);}
      function close(reason){if(closed)return false;if(typeof opts.beforeClose==="function"&&opts.beforeClose(reason)===false)return false;closed=true;cleanup();if(overlay&&overlay.isConnected)overlay.remove();if(typeof opts.onClose==="function")opts.onClose(reason);if(opts.restoreFocus!==false&&previousFocus&&previousFocus.isConnected&&typeof previousFocus.focus==="function"){try{previousFocus.focus({preventScroll:true});}catch(_){try{previousFocus.focus();}catch(_){}}}return true;}
      function onKeyDown(event){if(event.key==="Escape"&&opts.escape!==false){event.preventDefault();event.stopPropagation();close("escape");return;}if(event.key!=="Tab"||opts.trapFocus===false)return;var nodes=focusables();if(!nodes.length){event.preventDefault();modal.focus();return;}var first=nodes[0],last=nodes[nodes.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
      if(opts.backdrop!==false&&overlay)overlay.addEventListener("click",function(event){if(event.target===overlay)close("backdrop");});
      document.addEventListener("keydown",onKeyDown,true);
      function focusInitial(){if(closed)return;var target=opts.initialFocus;if(typeof target==="function")target=target();if(!target||typeof target.focus!=="function")target=focusables()[0]||modal;try{target.focus({preventScroll:true});}catch(_){try{target.focus();}catch(_){}}}
      if(opts.deferFocus===false)focusInitial();else requestAnimationFrame(focusInitial);
      return{close:close,focus:focusInitial,cleanup:cleanup,isClosed:function(){return closed;}};
    };
  }
  if(!window.extModalPrompt){
    window.extModalPrompt=function(message,opts){
      opts=opts||{};return new Promise(function(resolve){
        var overlay=document.createElement("div"),modal=document.createElement("div"),settled=false,lifecycle=null;
        overlay.className="extui-modal-overlay";modal.className="extui-modal";modal.setAttribute("aria-label",opts.title||(opts.input?"Entrada de dados":"Confirmação"));modal.style.width="380px";modal.style.padding="22px";
        var title=null;if(opts.title){title=document.createElement("h3");title.textContent=String(opts.title);title.style.margin="0 0 10px";title.style.color="var(--extui-text)";}
        var msg=document.createElement("p");msg.style.margin="0";msg.style.color="var(--extui-text)";msg.style.fontSize="14px";msg.style.lineHeight="1.5";msg.style.whiteSpace="pre-line";msg.textContent=String(message==null?"":message);
        var input=null;if(opts.input){input=document.createElement("input");input.type="text";input.id="extui-embed-modal-input-"+Date.now()+"-"+Math.random().toString(36).slice(2,7);input.value=opts.inputValue||"";if(opts.inputPlaceholder)input.placeholder=opts.inputPlaceholder;input.setAttribute("aria-label",opts.inputLabel||opts.inputPlaceholder||"Valor");}
        var actions=document.createElement("div");actions.className="extuifModalActions";
        function close(confirmed){if(settled)return;settled=true;if(lifecycle)lifecycle.close(confirmed?"confirm":"cancel");else overlay.remove();resolve(opts.input?(confirmed?input.value:null):confirmed);}
        function onEnter(ev){if(ev.key==="Enter"&&opts.input&&document.activeElement===input){ev.preventDefault();close(true);}}
        if(opts.cancel!==false){var cancelBtn=document.createElement("button");cancelBtn.type="button";cancelBtn.className="extui-btn extui-btn--ghost";cancelBtn.textContent=opts.cancelLabel||"Cancelar";cancelBtn.addEventListener("click",function(){close(false);});actions.appendChild(cancelBtn);}
        var okBtn=document.createElement("button");okBtn.type="button";okBtn.className="extui-btn "+(opts.danger?"extui-btn--danger":"extui-btn--primary");okBtn.textContent=opts.okLabel||"OK";okBtn.addEventListener("click",function(){close(true);});actions.appendChild(okBtn);
        if(title)modal.appendChild(title);modal.appendChild(msg);if(input){if(opts.inputLabel){var label=document.createElement("label");label.textContent=opts.inputLabel;label.setAttribute("for",input.id);modal.appendChild(label);}modal.appendChild(input);}modal.appendChild(actions);overlay.appendChild(modal);document.body.appendChild(overlay);
        lifecycle=window.__extDialogLifecycle(overlay,modal,{initialFocus:input||okBtn,onClose:function(reason){document.removeEventListener("keydown",onEnter,true);if(!settled&&(reason==="escape"||reason==="backdrop")){settled=true;resolve(opts.input?null:false);}}});
        document.addEventListener("keydown",onEnter,true);if(input)requestAnimationFrame(function(){try{input.select();}catch(_){}});
      });
    };
    window.extConfirm=function(message,opts){return window.extModalPrompt(message,Object.assign({},opts,{cancel:true}));};
    window.extAlert=function(message,opts){return window.extModalPrompt(message,Object.assign({},opts,{cancel:false}));};
    window.extPrompt=function(message,defaultValue,opts){return window.extModalPrompt(message,Object.assign({},opts,{cancel:true,input:true,inputValue:defaultValue}));};
  }
  function status(title,description,retry){
    clear();
    document.body.setAttribute("data-extui-access-state","blocked");
    var card=document.createElement("section");card.className="extuiBroadcastEmbedGate";card.setAttribute("role","alert");
    var h=document.createElement("h1");h.textContent=title;var p=document.createElement("p");p.textContent=description;
    card.appendChild(h);card.appendChild(p);
    if(retry){var b=document.createElement("button");b.type="button";b.className="extui-btn extui-btn--primary";b.textContent="Tentar novamente";b.addEventListener("click",authorize);card.appendChild(b);}
    mount.appendChild(card);
  }
  function toast(message,isError){
    message=String(message==null?"":message);
    var region=document.getElementById("extuid-global-status-region");
    if(!region){region=document.createElement("div");region.id="extuid-global-status-region";region.setAttribute("role",isError?"alert":"status");region.setAttribute("aria-live",isError?"assertive":"polite");region.className="extuiBroadcastEmbedStatusRegion";document.body.appendChild(region);}
    region.textContent=message;
    if(!isError)return region;
    var wrap=document.getElementById("extuid-global-toast-wrap");if(!wrap){wrap=document.createElement("div");wrap.id="extuid-global-toast-wrap";wrap.className="extuiToastWrap";document.body.appendChild(wrap);}
    var item=document.createElement("div");item.className="extuiToast extuiToast--error";item.setAttribute("role","alert");item.textContent=message;wrap.appendChild(item);while(wrap.children.length>3)wrap.firstElementChild.remove();setTimeout(function(){if(item.parentNode)item.remove();},4200);return item;
  }
  function storageGet(keys){
    try{if(window.ExtensionStorage&&typeof window.ExtensionStorage.getMany==="function"){var list=Array.isArray(keys)?keys:(typeof keys==="string"?[keys]:Object.keys(keys||{}));return window.ExtensionStorage.getMany(list).then(function(value){return value||{};});}}catch(_){}
    return new Promise(function(resolve,reject){try{chrome.storage.local.get(keys,function(value){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message));return;}resolve(value||{});});}catch(err){reject(err);}});
  }
  function storageSet(values){
    values=values&&typeof values==="object"?values:{};
    try{if(window.ExtensionStorage&&typeof window.ExtensionStorage.setMany==="function")return window.ExtensionStorage.setMany(values).then(function(){});}catch(_){}
    return new Promise(function(resolve,reject){try{chrome.storage.local.set(values,function(){if(chrome.runtime.lastError){reject(new Error(chrome.runtime.lastError.message));return;}resolve();});}catch(err){reject(err);}});
  }
  function sendToWhatsAppTab(type,payload,timeoutMs){
    return new Promise(function(resolve,reject){
      var requestId="extuid-embed-"+Date.now()+"-"+Math.random().toString(36).slice(2,9),settled=false,timer=0;
      function finish(err,data){if(settled)return;settled=true;if(timer)clearTimeout(timer);if(err)reject(err);else resolve(data);}
      try{chrome.tabs.query({url:"https://web.whatsapp.com/*"},function(tabs){
        if(chrome.runtime.lastError){finish(new Error(chrome.runtime.lastError.message));return;}
        var list=tabs||[],tab=list.find(function(candidate){return candidate&&candidate.active;})||list[0];
        if(!tab||tab.id==null){finish(new Error("Abra o WhatsApp Web e aguarde o carregamento."));return;}
        chrome.tabs.sendMessage(tab.id,{type:type,requestId:requestId,payload:payload||{}},function(response){
          if(chrome.runtime.lastError){finish(new Error(chrome.runtime.lastError.message));return;}
          if(!response||response.requestId!==requestId){finish(new Error("Resposta inválida do WhatsApp Web."));return;}
          if(response.error){var error=new Error(response.error);if(response.code)error.code=response.code;finish(error);return;}
          finish(null,response.data);
        });
        timer=setTimeout(function(){finish(new Error("Tempo esgotado. Confira se o WhatsApp Web terminou de carregar."));},Math.max(1000,Number(timeoutMs)||25000));
      });}catch(err){finish(err);}
    });
  }
  function registerSection(name,renderer){sections[String(name||"")]=renderer;if(name==="disparos")tryMount();}
  function setNavigationGuard(guard){navigationGuard=typeof guard==="function"?guard:null;}
  async function tryMount(force){
    if(!authorized||!authorizationSettled||rendering||!mount)return false;
    var renderer=sections.disparos;if(typeof renderer!=="function")return false;
    if(!force&&mount.getAttribute("data-extui-mounted")==="1")return true;
    if(navigationGuard){var allowed=await Promise.resolve(navigationGuard("disparos"));if(allowed===false)return false;}
    rendering=true;try{clear();document.body.setAttribute("data-extui-access-state","authorized");mount.setAttribute("data-extui-mounted","1");await Promise.resolve(renderer(mount));return true;}catch(err){mount.removeAttribute("data-extui-mounted");status("Não foi possível abrir Disparos",err&&err.message||"Falha ao carregar a área.",true);if(window.__extReportRuntimeError)window.__extReportRuntimeError("BROADCAST_EMBED_RENDER_FAILED",err);return false;}finally{rendering=false;}
  }
  async function showSection(name,options){if(String(name)!=="disparos")return{ok:false,section:name,reason:"dedicated-entrypoint"};var ok=await tryMount(!!(options&&options.force));return{ok:ok,section:"disparos"};}
  window.__extDashboardShell=Object.freeze({registerSection:registerSection,showSection:showSection,refreshSectionChrome:function(){},getCurrentSection:function(){return"disparos";},hasSection:function(name){return typeof sections[String(name||"")]==="function";},getRegisteredSections:function(){return Object.keys(sections).filter(function(name){return typeof sections[name]==="function";}).sort();},setNavigationGuard:setNavigationGuard,toast:toast,sendToWhatsAppTab:sendToWhatsAppTab,storageGet:storageGet,storageSet:storageSet});

  async function authorize(){
    authorizationSettled=false;authorized=false;document.body.setAttribute("data-extui-access-state","checking");
    if(!trustedContext()){authorizationSettled=true;status("Acesso ao embed recusado","Abra Disparos pelo botão da extensão dentro do WhatsApp Web.",false);return;}
    if(!window.__extS0||typeof window.__extS0._p!=="function"||typeof window.__extS0._n!=="function"){authorizationSettled=true;status("Sessão indisponível","Recarregue o WhatsApp Web e tente novamente.",true);return;}
    try{
      var session=await window.__extS0._p();
      if(!session||session.authorized!==true){authorizationSettled=true;status("Sessão não autorizada","Valide a extensão no WhatsApp Web antes de abrir Disparos.",true);return;}
      var entitled=await window.__extS0._n("disparos");
      if(entitled!==true){authorizationSettled=true;status("Disparos indisponível","Seu plano atual não autorizou o módulo Disparos.",false);return;}
      authorized=true;authorizationSettled=true;await tryMount(false);
    }catch(err){authorizationSettled=true;status("Não foi possível validar o acesso",err&&err.message||"Tente novamente em instantes.",true);if(window.__extReportRuntimeError)window.__extReportRuntimeError("BROADCAST_EMBED_AUTH_FAILED",err);}
  }
  authorize();
})();
}catch(_extuiBundleError){if(window.__extRecordBootError)window.__extRecordBootError(_extuiBundleError);}
