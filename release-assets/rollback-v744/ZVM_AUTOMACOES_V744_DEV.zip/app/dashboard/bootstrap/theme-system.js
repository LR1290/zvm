try{
(function (root) {
  "use strict";
  if (root.__extThemeSystem) return;

  var STORAGE_KEY = "EXTUI:extappOptionsStore";
  var APPEARANCE_SNAPSHOT_KEY = "EXTUI:extappAppearanceStore";
  var APPEARANCE_KEYS = ["appearanceDefinition","themeStateVersion","mode","theme","visualTheme","fontFamily","motion","radiusPreset","iconTheme","icon3dColor","quickShelfUseIconTheme","sidebarMainIconSize","disparosIconSize","dashboardUseSidebarIconSize","dashboardMenuIconSize","accessibilityTextScale","accessibilityContrast","accessibilityColorAssist","customColors","appearanceRevision"];
  var FACTORY_DEFAULTS = Object.freeze({
    appearanceDefinition: "default",
    themeStateVersion: 7,
    mode: "auto",
    visualTheme: "padrao",
    fontFamily: "system",
    motion: "auto",
    radiusPreset: "default",
    iconTheme: "monochrome",
    icon3dColor: "olive",
    quickShelfUseIconTheme: false,
    sidebarMainIconSize: 36,
    sidebarPlacement: "left-native",
    rightSidebarPanelsFollowRail: false,
    disparosIconSize: 38,
    dashboardUseSidebarIconSize: false,
    dashboardMenuIconSize: 28,
    accessibilityTextScale: 110,
    accessibilityContrast: "enhanced",
    accessibilityColorAssist: true,
    floatingWindowMovable: true,
    floatingWindowResizable: false,
    floatingWorkspaceLayoutVersion: 4,
    menuVisibility: {}
  });

  var FONTS = Object.freeze({
    default: '-apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
    system: '-apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
    segoe: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
    arial: 'Arial, Helvetica, sans-serif',
    aureus: 'Georgia, "Times New Roman", serif',
    retro: 'ui-monospace, SFMono-Regular, Consolas, monospace',
    matrix: 'ui-monospace, SFMono-Regular, Consolas, monospace',
    mono: 'ui-monospace, SFMono-Regular, Consolas, monospace',
    espresso: 'Georgia, "Times New Roman", serif'
  });

  function p(dark, light) { return Object.freeze({ dark: Object.freeze(dark), light: Object.freeze(light) }); }
  var THEMES = Object.freeze({
    padrao: Object.freeze({
      id: "padrao", label: "Padrão", fontFamily: "system", motion: "normal", radiusPreset: "default",
      palette: p(
        { primary:"#00c85a", primaryBright:"#00e676", primaryDim:"#0a3d24", bg:"#080808", card:"#0d0d0d", card2:"#151515", text:"#e0e0e0", textDim:"#a0a0a0", border:"#1e1e1e" },
        { primary:"#009e56", primaryBright:"#00b862", primaryDim:"#d7f3e3", bg:"#f3f6f4", card:"#ffffff", card2:"#f8faf9", text:"#17201b", textDim:"#68736c", border:"#dce5df" }
      )
    }),
    extapp: Object.freeze({
      id: "extapp", label: "ZVM", fontFamily: "system", motion: "normal", radiusPreset: "default",
      palette: p(
        {
          primary:"#00c85a", primaryBright:"#00e676", primaryDim:"#0a3d24", bg:"#080808", card:"#0d0d0d", card2:"#151515", card3:"#1a1d1b",
          text:"#e0e0e0", textDim:"#a0a0a0", textFaint:"#747d77", border:"#1e1e1e", borderStrong:"#303530", borderSubtle:"#181b19",
          surfaceHover:"#171d19", surfaceActive:"#1c251f", success:"#00c85a", danger:"#f05060", dangerDim:"#35151b", warning:"#f5a623",
          scrollbarTrack:"transparent", scrollbarThumb:"#303530", scrollbarThumbHover:"#4b554e", shadowCompact:"0 1px 2px rgba(0,0,0,.36)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.56)", shadowLg:"0 12px 32px -10px rgba(0,0,0,.70)", glow:"0 0 0 3px rgba(0,200,90,.18)", focusRing:"0 0 0 3px rgba(0,200,90,.32)"
        },
        {
          primary:"#009e56", primaryBright:"#00b862", primaryDim:"#d7f3e3", bg:"#f3f6f4", card:"#ffffff", card2:"#f8faf9", card3:"#edf3ef",
          text:"#17201b", textDim:"#68736c", textFaint:"#87918a", border:"#dce5df", borderStrong:"#c8d5cd", borderSubtle:"#e8eeea",
          surfaceHover:"#eef4f0", surfaceActive:"#e4eee8", success:"#009e56", danger:"#c22e44", dangerDim:"#fbe2e6", warning:"#b3720f",
          scrollbarTrack:"transparent", scrollbarThumb:"#c8d5cd", scrollbarThumbHover:"#aabbb0", shadowCompact:"0 1px 2px rgba(20,30,24,.06)", shadowMd:"0 4px 14px -4px rgba(20,30,24,.12)", shadowLg:"0 14px 34px -10px rgba(20,30,24,.16)", glow:"0 0 0 3px rgba(0,158,86,.16)", focusRing:"0 0 0 3px rgba(0,158,86,.28)"
        }
      )
    }),
    whatsapp: Object.freeze({
      id: "whatsapp", label: "Jade", fontFamily: "system", motion: "auto", radiusPreset: "default",
      palette: p(
        { primary:"#00a884", primaryBright:"#00c9a7", primaryDim:"#005c4b", bg:"#0b141a", card:"#111b21", card2:"#202c33", card3:"#233138", text:"#e9edef", textDim:"#8696a0", textFaint:"#667781", border:"#222d34", borderStrong:"#313d45", borderSubtle:"#1f2c33", surfaceHover:"#202c33", surfaceActive:"#233138", success:"#00a884", danger:"#ea0038", dangerDim:"#3b1820", warning:"#ffd279", scrollbarTrack:"transparent", scrollbarThumb:"#374248", scrollbarThumbHover:"#4b5961", shadowCompact:"0 1px 2px rgba(0,0,0,.34)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.55)", shadowLg:"0 12px 32px -10px rgba(0,0,0,.68)", glow:"0 0 0 3px rgba(0,168,132,.18)", focusRing:"0 0 0 3px rgba(0,168,132,.32)" },
        { primary:"#008069", primaryBright:"#00a884", primaryDim:"#d9fdd3", bg:"#f0f2f5", card:"#ffffff", card2:"#f0f2f5", card3:"#e9edef", text:"#111b21", textDim:"#667781", textFaint:"#8696a0", border:"#e9edef", borderStrong:"#d1d7db", borderSubtle:"#f0f2f5", surfaceHover:"#f5f6f6", surfaceActive:"#e9edef", success:"#008069", danger:"#ea0038", dangerDim:"#ffe6ec", warning:"#f7b928", scrollbarTrack:"transparent", scrollbarThumb:"#c5cbd0", scrollbarThumbHover:"#aeb7bd", shadowCompact:"0 1px 2px rgba(11,20,26,.06)", shadowMd:"0 4px 14px -4px rgba(11,20,26,.12)", shadowLg:"0 12px 32px -10px rgba(11,20,26,.18)", glow:"0 0 0 3px rgba(0,128,105,.14)", focusRing:"0 0 0 3px rgba(0,128,105,.25)" }
      )
    }),
    system: Object.freeze({
      id: "system", label: "Cobalto", fontFamily: "system", motion: "auto", radiusPreset: "default",
      palette: p(
        { primary:"#5e9eff", primaryBright:"#78adff", primaryDim:"#18385f", bg:"#111214", card:"#181a1d", card2:"#22252a", card3:"#292d33", text:"#f0f2f5", textDim:"#a6adb7", textFaint:"#7e8793", border:"#30343a", borderStrong:"#454b54", borderSubtle:"#282c31", surfaceHover:"#262a30", surfaceActive:"#2d3239", success:"#4cc38a", danger:"#ef5b6c", dangerDim:"#3b1c23", warning:"#e9b949", scrollbarTrack:"transparent", scrollbarThumb:"#454b54", scrollbarThumbHover:"#5d6570", shadowCompact:"0 1px 2px rgba(0,0,0,.32)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.48)", shadowLg:"0 12px 32px -10px rgba(0,0,0,.62)", glow:"0 0 0 3px rgba(94,158,255,.17)", focusRing:"0 0 0 3px rgba(94,158,255,.30)" },
        { primary:"#276fd6", primaryBright:"#3b82f6", primaryDim:"#dbeafe", bg:"#f3f4f6", card:"#ffffff", card2:"#f8fafc", card3:"#edf2f7", text:"#17191d", textDim:"#67717e", textFaint:"#88919c", border:"#d9dee5", borderStrong:"#c5ccd5", borderSubtle:"#e9edf2", surfaceHover:"#eef3f9", surfaceActive:"#e4ebf4", success:"#27875d", danger:"#c9384b", dangerDim:"#fbe7ea", warning:"#a9670b", scrollbarTrack:"transparent", scrollbarThumb:"#c5ccd5", scrollbarThumbHover:"#a8b2bf", shadowCompact:"0 1px 2px rgba(23,25,29,.06)", shadowMd:"0 4px 14px -4px rgba(23,25,29,.12)", shadowLg:"0 12px 32px -10px rgba(23,25,29,.18)", glow:"0 0 0 3px rgba(39,111,214,.14)", focusRing:"0 0 0 3px rgba(39,111,214,.24)" }
      )
    }),
    dark: Object.freeze({
      id: "dark", label: "Ônix", fontFamily: "system", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#8b9daf", primaryBright:"#b5c2ce", primaryDim:"#252e36", bg:"#050607", card:"#0b0d0f", card2:"#121519", card3:"#191d22", text:"#f1f4f6", textDim:"#8b949e", textFaint:"#69737d", border:"#20252a", borderStrong:"#343b42", borderSubtle:"#171b1f", surfaceHover:"#171b20", surfaceActive:"#1d2228", success:"#69a98a", danger:"#df5b68", dangerDim:"#32171c", warning:"#d4ad68", scrollbarTrack:"transparent", scrollbarThumb:"#343b42", scrollbarThumbHover:"#4b545e", shadowCompact:"0 1px 2px rgba(0,0,0,.40)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.60)", shadowLg:"0 12px 32px -10px rgba(0,0,0,.74)", glow:"0 0 0 3px rgba(181,194,206,.12)", focusRing:"0 0 0 3px rgba(181,194,206,.22)" },
        { primary:"#4f6173", primaryBright:"#64788d", primaryDim:"#e4e8ec", bg:"#eef1f3", card:"#ffffff", card2:"#f7f8f9", card3:"#e9edf0", text:"#15191d", textDim:"#69747e", textFaint:"#8b959e", border:"#d8dde2", borderStrong:"#c1c8cf", borderSubtle:"#e8ecef", surfaceHover:"#eef1f4", surfaceActive:"#e3e8ec", success:"#4b8067", danger:"#b74050", dangerDim:"#f8e6e9", warning:"#946b2b", scrollbarTrack:"transparent", scrollbarThumb:"#c1c8cf", scrollbarThumbHover:"#a4afb8", shadowCompact:"0 1px 2px rgba(21,25,29,.05)", shadowMd:"0 4px 14px -4px rgba(21,25,29,.11)", shadowLg:"0 12px 32px -10px rgba(21,25,29,.16)", glow:"0 0 0 3px rgba(79,97,115,.12)", focusRing:"0 0 0 3px rgba(79,97,115,.22)" }
      )
    }),
    classic: Object.freeze({
      id: "classic", label: "Sálvia", fontFamily: "segoe", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#3ca68a", primaryBright:"#63c2a8", primaryDim:"#173d34", bg:"#121611", card:"#1b211a", card2:"#283028", card3:"#333d33", text:"#eee9dc", textDim:"#b5b0a2", textFaint:"#8f9186", border:"#465246", borderStrong:"#657365", borderSubtle:"#333d33", surfaceHover:"#303a30", surfaceActive:"#394639", success:"#63c2a8", danger:"#d8666b", dangerDim:"#3c1f20", warning:"#d9aa55", scrollbarTrack:"transparent", scrollbarThumb:"#657365", scrollbarThumbHover:"#7d8b7c", shadowCompact:"0 1px 2px rgba(0,0,0,.32)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.49)", shadowLg:"0 12px 32px -10px rgba(0,0,0,.63)", glow:"0 0 0 3px rgba(60,166,138,.18)", focusRing:"0 0 0 3px rgba(99,194,168,.28)" },
        { primary:"#2f7563", primaryBright:"#3f9079", primaryDim:"#d7e8e1", bg:"#ebe7dc", card:"#fffdf8", card2:"#f1ecdf", card3:"#e4dccb", text:"#242720", textDim:"#66695f", textFaint:"#85877d", border:"#d0c7b4", borderStrong:"#b4a993", borderSubtle:"#e2dbce", surfaceHover:"#ece5d8", surfaceActive:"#dfd6c5", success:"#2f7563", danger:"#a6464e", dangerDim:"#f5dfe2", warning:"#8b5e18", scrollbarTrack:"transparent", scrollbarThumb:"#b4a993", scrollbarThumbHover:"#978b74", shadowCompact:"0 1px 2px rgba(36,39,32,.06)", shadowMd:"0 4px 14px -4px rgba(36,39,32,.12)", shadowLg:"0 12px 32px -10px rgba(36,39,32,.17)", glow:"0 0 0 3px rgba(47,117,99,.14)", focusRing:"0 0 0 3px rgba(47,117,99,.24)" }
      )
    }),
    vibrant: Object.freeze({
      id: "vibrant", label: "Íris", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#8b5cf6", primaryBright:"#22d3ee", primaryDim:"#372861", bg:"#090716", card:"#131025", card2:"#201a38", card3:"#292149", text:"#f5f3ff", textDim:"#b5acd2", textFaint:"#857aa8", border:"#332a50", borderStrong:"#4a3d70", borderSubtle:"#292140", surfaceHover:"#292149", surfaceActive:"#33285a", success:"#2dd4bf", danger:"#fb7185", dangerDim:"#431d2a", warning:"#fbbf24", scrollbarTrack:"transparent", scrollbarThumb:"#4a3d70", scrollbarThumbHover:"#68579a", shadowCompact:"0 1px 2px rgba(0,0,0,.34)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.52)", shadowLg:"0 14px 36px -10px rgba(0,0,0,.68)", glow:"0 0 0 3px rgba(139,92,246,.18)", focusRing:"0 0 0 3px rgba(34,211,238,.28)" },
        { primary:"#7c3aed", primaryBright:"#0891b2", primaryDim:"#ede9fe", bg:"#f7f4ff", card:"#ffffff", card2:"#f3efff", card3:"#eae4fb", text:"#24193c", textDim:"#786b90", textFaint:"#9c90af", border:"#ddd5f2", borderStrong:"#c8bbe8", borderSubtle:"#ebe6f7", surfaceHover:"#f0ebfa", surfaceActive:"#e8e0f7", success:"#0f8a7e", danger:"#c83c5a", dangerDim:"#fbe5eb", warning:"#9a690c", scrollbarTrack:"transparent", scrollbarThumb:"#c8bbe8", scrollbarThumbHover:"#aa9bcf", shadowCompact:"0 1px 2px rgba(36,25,60,.05)", shadowMd:"0 4px 14px -4px rgba(36,25,60,.11)", shadowLg:"0 12px 32px -10px rgba(36,25,60,.17)", glow:"0 0 0 3px rgba(124,58,237,.13)", focusRing:"0 0 0 3px rgba(8,145,178,.22)" }
      )
    }),
    gray: Object.freeze({
      id: "gray", label: "Grafite", fontFamily: "system", motion: "reduced", radiusPreset: "default",
      palette: p(
        { primary:"#9ca3af", primaryBright:"#d1d5db", primaryDim:"#30343a", bg:"#111214", card:"#191b1e", card2:"#23262a", card3:"#2b2f34", text:"#ededee", textDim:"#a4a8ad", textFaint:"#7f858c", border:"#34383d", borderStrong:"#484d54", borderSubtle:"#2b2f33", surfaceHover:"#2b2f34", surfaceActive:"#33383e", success:"#7aa58d", danger:"#d96772", dangerDim:"#3b2024", warning:"#c9a45f", scrollbarTrack:"transparent", scrollbarThumb:"#484d54", scrollbarThumbHover:"#616870", shadowCompact:"0 1px 2px rgba(0,0,0,.30)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.46)", shadowLg:"0 12px 32px -10px rgba(0,0,0,.60)", glow:"0 0 0 3px rgba(156,163,175,.14)", focusRing:"0 0 0 3px rgba(209,213,219,.20)" },
        { primary:"#626b75", primaryBright:"#7b8794", primaryDim:"#e5e7eb", bg:"#f1f2f3", card:"#ffffff", card2:"#f7f7f8", card3:"#eceeef", text:"#25282c", textDim:"#6f757c", textFaint:"#90969c", border:"#dcdfe2", borderStrong:"#c6cbd0", borderSubtle:"#e9ebed", surfaceHover:"#f0f1f2", surfaceActive:"#e7e9eb", success:"#557966", danger:"#ae4854", dangerDim:"#f7e6e8", warning:"#896829", scrollbarTrack:"transparent", scrollbarThumb:"#c6cbd0", scrollbarThumbHover:"#aab1b8", shadowCompact:"0 1px 2px rgba(37,40,44,.05)", shadowMd:"0 4px 14px -4px rgba(37,40,44,.10)", shadowLg:"0 12px 32px -10px rgba(37,40,44,.15)", glow:"0 0 0 3px rgba(98,107,117,.12)", focusRing:"0 0 0 3px rgba(98,107,117,.22)" }
      )
    }),
    royal: Object.freeze({
      id: "royal", label: "Ametista", fontFamily: "segoe", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#6d5bd0", primaryBright:"#9b8cff", primaryDim:"#282253", bg:"#0b0b18", card:"#141426", card2:"#211f3b", card3:"#2a274a", text:"#f3f1ff", textDim:"#ada7cb", textFaint:"#817a9e", border:"#343157", borderStrong:"#4a4673", borderSubtle:"#2a2847", surfaceHover:"#2a274a", surfaceActive:"#332f59", success:"#5bc5a2", danger:"#ef6b84", dangerDim:"#401d2a", warning:"#e6b85c", scrollbarTrack:"transparent", scrollbarThumb:"#4a4673", scrollbarThumbHover:"#645f92", shadowCompact:"0 1px 2px rgba(0,0,0,.34)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.52)", shadowLg:"0 14px 36px -10px rgba(0,0,0,.68)", glow:"0 0 0 3px rgba(109,91,208,.18)", focusRing:"0 0 0 3px rgba(155,140,255,.26)" },
        { primary:"#5645b5", primaryBright:"#7564d6", primaryDim:"#e8e5ff", bg:"#f3f1fb", card:"#ffffff", card2:"#f6f4ff", card3:"#ece9fa", text:"#25213f", textDim:"#716b8d", textFaint:"#938ca8", border:"#ddd8ef", borderStrong:"#c7c0e3", borderSubtle:"#ebe7f6", surfaceHover:"#f0edf9", surfaceActive:"#e7e3f5", success:"#3d856c", danger:"#b74661", dangerDim:"#f9e5ea", warning:"#8d6823", scrollbarTrack:"transparent", scrollbarThumb:"#c7c0e3", scrollbarThumbHover:"#aaa0cf", shadowCompact:"0 1px 2px rgba(37,33,63,.05)", shadowMd:"0 4px 14px -4px rgba(37,33,63,.10)", shadowLg:"0 12px 32px -10px rgba(37,33,63,.16)", glow:"0 0 0 3px rgba(86,69,181,.13)", focusRing:"0 0 0 3px rgba(86,69,181,.23)" }
      )
    }),
    scarlet: Object.freeze({
      id: "scarlet", label: "Escarlate", fontFamily: "system", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#d63b45", primaryBright:"#ff5964", primaryDim:"#49171d", bg:"#0c1011", card:"#151919", card2:"#1d2322", card3:"#252d2b", text:"#f3f5f4", textDim:"#a7b0ae", textFaint:"#78827f", border:"#2f3936", borderStrong:"#465550", borderSubtle:"#252d2b", surfaceHover:"#232b29", surfaceActive:"#2a3431", success:"#22b8aa", danger:"#ff5964", dangerDim:"#42151b", warning:"#e2aa58", scrollbarTrack:"transparent", scrollbarThumb:"#465550", scrollbarThumbHover:"#5e7069", shadowCompact:"0 1px 2px rgba(0,0,0,.35)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.54)", shadowLg:"0 14px 36px -10px rgba(0,0,0,.70)", glow:"0 0 0 3px rgba(214,59,69,.18)", focusRing:"0 0 0 3px rgba(0,139,139,.30)" },
        { primary:"#b4232d", primaryBright:"#d13b45", primaryDim:"#fde7e8", bg:"#f5f8f7", card:"#ffffff", card2:"#f0f5f3", card3:"#e6efec", text:"#211b1c", textDim:"#686f6d", textFaint:"#89918e", border:"#d7e1de", borderStrong:"#becdc8", borderSubtle:"#e6ecea", surfaceHover:"#edf3f1", surfaceActive:"#e2ece8", success:"#078490", danger:"#b4232d", dangerDim:"#fde7e8", warning:"#9a6416", scrollbarTrack:"transparent", scrollbarThumb:"#becdc8", scrollbarThumbHover:"#9fb3ac", shadowCompact:"0 1px 2px rgba(33,27,28,.05)", shadowMd:"0 4px 14px -4px rgba(33,27,28,.11)", shadowLg:"0 12px 32px -10px rgba(33,27,28,.17)", glow:"0 0 0 3px rgba(180,35,45,.13)", focusRing:"0 0 0 3px rgba(7,132,144,.24)" }
      )
    }),
    blush: Object.freeze({
      id: "blush", label: "Blush", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#d979a4", primaryBright:"#f0a5c6", primaryDim:"#4b2839", bg:"#130e13", card:"#1f151f", card2:"#302130", card3:"#3d2b3e", text:"#fff3f8", textDim:"#cfb0c1", textFaint:"#9f8294", border:"#514050", borderStrong:"#73586e", borderSubtle:"#3d2b3e", surfaceHover:"#39283a", surfaceActive:"#463149", success:"#78b99b", danger:"#f06f91", dangerDim:"#48202d", warning:"#e3ae68", scrollbarTrack:"transparent", scrollbarThumb:"#73586e", scrollbarThumbHover:"#8b6c85", shadowCompact:"0 1px 2px rgba(0,0,0,.32)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.49)", shadowLg:"0 14px 36px -10px rgba(0,0,0,.63)", glow:"0 0 0 3px rgba(217,121,164,.20)", focusRing:"0 0 0 3px rgba(240,165,198,.28)" },
        { primary:"#a84f7b", primaryBright:"#c96998", primaryDim:"#f3bfd3", bg:"#fcedf2", card:"#fffdfb", card2:"#f7e4ed", card3:"#eed4e2", text:"#53364f", textDim:"#755b70", textFaint:"#92798d", border:"#dfc2d2", borderStrong:"#c8a3ba", borderSubtle:"#eedbe5", surfaceHover:"#f3dfe9", surfaceActive:"#e9cfdd", success:"#54866f", danger:"#a84768", dangerDim:"#f8dde7", warning:"#8f601a", scrollbarTrack:"transparent", scrollbarThumb:"#c8a3ba", scrollbarThumbHover:"#ad819b", shadowCompact:"0 1px 2px rgba(83,54,79,.06)", shadowMd:"0 4px 14px -4px rgba(83,54,79,.12)", shadowLg:"0 12px 32px -10px rgba(83,54,79,.18)", glow:"0 0 0 3px rgba(168,79,123,.14)", focusRing:"0 0 0 3px rgba(168,79,123,.24)" }
      )
    }),
    amber: Object.freeze({
      id: "amber", label: "Âmbar", fontFamily: "system", motion: "normal", radiusPreset: "default",
      palette: p(
        { primary:"#d97706", primaryBright:"#f59e0b", primaryDim:"#4b2a08", bg:"#15120f", card:"#1e1914", card2:"#292119", card3:"#34291f", text:"#f5efe8", textDim:"#b9a99a", textFaint:"#88796b", border:"#403429", borderStrong:"#59483a", borderSubtle:"#342a21", surfaceHover:"#34291f", surfaceActive:"#3d3024", success:"#69a57d", danger:"#df6462", dangerDim:"#421d1b", warning:"#f5a623", scrollbarTrack:"transparent", scrollbarThumb:"#59483a", scrollbarThumbHover:"#735f4c", shadowCompact:"0 1px 2px rgba(0,0,0,.32)", shadowMd:"0 4px 14px -4px rgba(0,0,0,.48)", shadowLg:"0 14px 36px -10px rgba(0,0,0,.64)", glow:"0 0 0 3px rgba(217,119,6,.18)", focusRing:"0 0 0 3px rgba(245,158,11,.28)" },
        { primary:"#b85f00", primaryBright:"#c76e00", primaryDim:"#fff0dc", bg:"#f8f4ef", card:"#ffffff", card2:"#f5eee7", card3:"#eee3d8", text:"#2b2520", textDim:"#776b61", textFaint:"#988b80", border:"#e4d7ca", borderStrong:"#cfbdad", borderSubtle:"#efe6de", surfaceHover:"#f4ebe3", surfaceActive:"#ebdfd3", success:"#4f8564", danger:"#b24949", dangerDim:"#f8e4e4", warning:"#a65b00", scrollbarTrack:"transparent", scrollbarThumb:"#cfbdad", scrollbarThumbHover:"#b49d89", shadowCompact:"0 1px 2px rgba(43,37,32,.05)", shadowMd:"0 4px 14px -4px rgba(43,37,32,.10)", shadowLg:"0 12px 32px -10px rgba(43,37,32,.16)", glow:"0 0 0 3px rgba(184,95,0,.13)", focusRing:"0 0 0 3px rgba(199,110,0,.23)" }
      )
    }),
    aureus: Object.freeze({
      id: "aureus", label: "Aureus", secret: true, secretKey: "godmode", fontFamily: "segoe", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#d8ad4a", primaryBright:"#ffd166", primaryDim:"#4b3810", bg:"#090806", card:"#12100b", card2:"#1d190f", card3:"#292216", text:"#fff7df", textDim:"#c9b989", textFaint:"#8f805f", border:"#3e3420", borderStrong:"#5b4a28", borderSubtle:"#2b2418", surfaceHover:"#251f13", surfaceActive:"#302817", success:"#70c59a", danger:"#ef6575", dangerDim:"#3d181d", warning:"#ffd166", scrollbarTrack:"transparent", scrollbarThumb:"#5b4a28", scrollbarThumbHover:"#80693a", shadowCompact:"0 1px 2px rgba(0,0,0,.38)", shadowMd:"0 6px 18px -6px rgba(216,173,74,.22)", shadowLg:"0 18px 44px -14px rgba(216,173,74,.26)", glow:"0 0 0 3px rgba(255,209,102,.18)", focusRing:"0 0 0 3px rgba(255,209,102,.30)" },
        { primary:"#9b6b10", primaryBright:"#b78320", primaryDim:"#fff2c9", bg:"#fbf7ed", card:"#fffdf8", card2:"#f8f0dc", card3:"#efe3c4", text:"#30240f", textDim:"#796945", textFaint:"#998866", border:"#e2d4ae", borderStrong:"#ccb981", borderSubtle:"#eee4ca", surfaceHover:"#f7efd9", surfaceActive:"#efe2bf", success:"#4e8567", danger:"#b84856", dangerDim:"#f9e2e6", warning:"#9b6b10", scrollbarTrack:"transparent", scrollbarThumb:"#ccb981", scrollbarThumbHover:"#ad9560", shadowCompact:"0 1px 2px rgba(48,36,15,.05)", shadowMd:"0 5px 16px -5px rgba(155,107,16,.14)", shadowLg:"0 14px 36px -12px rgba(155,107,16,.18)", glow:"0 0 0 3px rgba(155,107,16,.13)", focusRing:"0 0 0 3px rgba(155,107,16,.23)" }
      )
    }),
    retrowave: Object.freeze({
      id: "retrowave", label: "CRT Âmbar", secret: true, secretKey: "retro", fontFamily: "segoe", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#f59e0b", primaryBright:"#ffc857", primaryDim:"#4b2a05", bg:"#090704", card:"#120e05", card2:"#1c1407", card3:"#271c09", text:"#ffe7a6", textDim:"#c8a86a", textFaint:"#8f7446", border:"#3e2d10", borderStrong:"#5b4318", borderSubtle:"#2b1f0c", surfaceHover:"#241a09", surfaceActive:"#30230c", success:"#7dbb7a", danger:"#e76157", dangerDim:"#3d1713", warning:"#ffc857", scrollbarTrack:"transparent", scrollbarThumb:"#5b4318", scrollbarThumbHover:"#7d5c20", shadowCompact:"0 1px 2px rgba(0,0,0,.42)", shadowMd:"0 5px 16px -5px rgba(245,158,11,.18)", shadowLg:"0 14px 36px -12px rgba(245,158,11,.22)", glow:"0 0 0 3px rgba(245,158,11,.16)", focusRing:"0 0 0 3px rgba(255,200,87,.28)" },
        { primary:"#a85c00", primaryBright:"#c87500", primaryDim:"#ffebbd", bg:"#f8f2e5", card:"#fffaf0", card2:"#f5e8cd", card3:"#ead8b5", text:"#332411", textDim:"#79623f", textFaint:"#9a8055", border:"#dfcba3", borderStrong:"#c6aa73", borderSubtle:"#eadcc1", surfaceHover:"#f3e6ce", surfaceActive:"#ead7b5", success:"#54815a", danger:"#ad4a44", dangerDim:"#f7e2df", warning:"#9a5b0b", scrollbarTrack:"transparent", scrollbarThumb:"#c6aa73", scrollbarThumbHover:"#a88850", shadowCompact:"0 1px 2px rgba(51,36,17,.05)", shadowMd:"0 4px 14px -4px rgba(168,92,0,.12)", shadowLg:"0 12px 32px -10px rgba(168,92,0,.17)", glow:"0 0 0 3px rgba(168,92,0,.13)", focusRing:"0 0 0 3px rgba(168,92,0,.23)" }
      )
    }),
    espresso: Object.freeze({
      id: "espresso", label: "Expresso", secret: true, secretKey: "coffee", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#c98652", primaryBright:"#f1be8f", primaryDim:"#4a2a18", bg:"#0e0906", card:"#17100b", card2:"#241810", card3:"#302116", text:"#f9eadb", textDim:"#c4a58d", textFaint:"#8f7562", border:"#3b2a20", borderStrong:"#594032", borderSubtle:"#2c1f18", surfaceHover:"#2a1c14", surfaceActive:"#352319", success:"#79b78e", danger:"#e46868", dangerDim:"#3c1818", warning:"#dfa45f", scrollbarTrack:"transparent", scrollbarThumb:"#594032", scrollbarThumbHover:"#755646", shadowCompact:"0 1px 2px rgba(0,0,0,.34)", shadowMd:"0 5px 16px -5px rgba(201,134,82,.16)", shadowLg:"0 14px 36px -12px rgba(201,134,82,.20)", glow:"0 0 0 3px rgba(201,134,82,.16)", focusRing:"0 0 0 3px rgba(241,190,143,.27)" },
        { primary:"#9c5f32", primaryBright:"#b97442", primaryDim:"#f7dfca", bg:"#f8f2ed", card:"#fffdfb", card2:"#f3e7de", card3:"#ead9cc", text:"#30231c", textDim:"#766155", textFaint:"#978075", border:"#dfcec3", borderStrong:"#c8b0a0", borderSubtle:"#eee2da", surfaceHover:"#f2e5dc", surfaceActive:"#e8d7cb", success:"#558166", danger:"#b34b4b", dangerDim:"#f8e2e2", warning:"#956020", scrollbarTrack:"transparent", scrollbarThumb:"#c8b0a0", scrollbarThumbHover:"#aa8e7b", shadowCompact:"0 1px 2px rgba(48,35,28,.05)", shadowMd:"0 4px 14px -4px rgba(48,35,28,.11)", shadowLg:"0 12px 32px -10px rgba(48,35,28,.16)", glow:"0 0 0 3px rgba(156,95,50,.12)", focusRing:"0 0 0 3px rgba(156,95,50,.22)" }
      )
    }),
    cosmos42: Object.freeze({
      id: "cosmos42", label: "Espaço 42", secret: true, secretKey: "42", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#8f83ff", primaryBright:"#70d6ff", primaryDim:"#262150", bg:"#030510", card:"#090d1d", card2:"#10162b", card3:"#171f3a", text:"#f1f3ff", textDim:"#a5acd0", textFaint:"#747d9f", border:"#252d4a", borderStrong:"#394365", borderSubtle:"#1a2138", surfaceHover:"#151c34", surfaceActive:"#1d2744", success:"#5ad1ad", danger:"#ee668b", dangerDim:"#3d1930", warning:"#ffd166", scrollbarTrack:"transparent", scrollbarThumb:"#394365", scrollbarThumbHover:"#53608c", shadowCompact:"0 1px 2px rgba(0,0,0,.40)", shadowMd:"0 6px 18px -5px rgba(112,214,255,.14)", shadowLg:"0 16px 42px -12px rgba(143,131,255,.24)", glow:"0 0 0 3px rgba(143,131,255,.18)", focusRing:"0 0 0 3px rgba(112,214,255,.28)" },
        { primary:"#6757cf", primaryBright:"#3b9ec5", primaryDim:"#e7e4ff", bg:"#f2f4fb", card:"#ffffff", card2:"#eef1fb", card3:"#e2e6f5", text:"#252642", textDim:"#6d7391", textFaint:"#9096ad", border:"#d6daeb", borderStrong:"#c0c6df", borderSubtle:"#e7e9f3", surfaceHover:"#edf0f8", surfaceActive:"#e3e7f3", success:"#3f856f", danger:"#b84868", dangerDim:"#f8e3ea", warning:"#8c681c", scrollbarTrack:"transparent", scrollbarThumb:"#c0c6df", scrollbarThumbHover:"#a3aac9", shadowCompact:"0 1px 2px rgba(37,38,66,.05)", shadowMd:"0 4px 14px -4px rgba(37,38,66,.11)", shadowLg:"0 12px 32px -10px rgba(103,87,207,.16)", glow:"0 0 0 3px rgba(103,87,207,.12)", focusRing:"0 0 0 3px rgba(59,158,197,.22)" }
      )
    }),
    neoncore: Object.freeze({
      id: "neoncore", label: "Grade Neon", secret: true, secretKey: "neon", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#37e8ff", primaryBright:"#ff4fd8", primaryDim:"#15344b", bg:"#070414", card:"#100a21", card2:"#1a1032", card3:"#241641", text:"#f9f1ff", textDim:"#bdacd3", textFaint:"#89789f", border:"#342656", borderStrong:"#4f3976", borderSubtle:"#291d47", surfaceHover:"#21133d", surfaceActive:"#2b184c", success:"#45e0b2", danger:"#ff5c90", dangerDim:"#46152c", warning:"#ffd166", scrollbarTrack:"transparent", scrollbarThumb:"#4f3976", scrollbarThumbHover:"#6c5198", shadowCompact:"0 1px 2px rgba(0,0,0,.38)", shadowMd:"0 6px 18px -5px rgba(55,232,255,.14)", shadowLg:"0 16px 42px -12px rgba(255,79,216,.19)", glow:"0 0 0 3px rgba(55,232,255,.17)", focusRing:"0 0 0 3px rgba(55,232,255,.30)" },
        { primary:"#008ea0", primaryBright:"#b12b98", primaryDim:"#dff8fb", bg:"#f7f2fb", card:"#ffffff", card2:"#f2eafa", card3:"#e8ddf4", text:"#2d2138", textDim:"#766382", textFaint:"#9786a2", border:"#ded2ea", borderStrong:"#c8b6dc", borderSubtle:"#ede5f3", surfaceHover:"#f1e9f7", surfaceActive:"#e8dcf2", success:"#2c8971", danger:"#bd3f69", dangerDim:"#f9e2ec", warning:"#936b17", scrollbarTrack:"transparent", scrollbarThumb:"#c8b6dc", scrollbarThumbHover:"#aa95c2", shadowCompact:"0 1px 2px rgba(45,33,56,.05)", shadowMd:"0 4px 14px -4px rgba(45,33,56,.11)", shadowLg:"0 12px 32px -10px rgba(177,43,152,.15)", glow:"0 0 0 3px rgba(0,142,160,.12)", focusRing:"0 0 0 3px rgba(0,142,160,.23)" }
      )
    }),
    zenith: Object.freeze({
      id: "zenith", label: "Névoa Zen", secret: true, secretKey: "zen", fontFamily: "system", motion: "reduced", radiusPreset: "rounded",
      palette: p(
        { primary:"#64eed7", primaryBright:"#a6ffe9", primaryDim:"#173f38", bg:"#06100e", card:"#0b1714", card2:"#11231e", card3:"#19302a", text:"#e9fff9", textDim:"#9bc7bc", textFaint:"#6f978e", border:"#25453d", borderStrong:"#376159", borderSubtle:"#1b342e", surfaceHover:"#142a24", surfaceActive:"#1c362f", success:"#64eed7", danger:"#df7474", dangerDim:"#371b1b", warning:"#d8bd72", scrollbarTrack:"transparent", scrollbarThumb:"#376159", scrollbarThumbHover:"#4f7d73", shadowCompact:"0 1px 2px rgba(0,0,0,.28)", shadowMd:"0 4px 14px -4px rgba(100,238,215,.11)", shadowLg:"0 14px 36px -12px rgba(100,238,215,.14)", glow:"0 0 0 3px rgba(100,238,215,.13)", focusRing:"0 0 0 3px rgba(100,238,215,.24)" },
        { primary:"#288a78", primaryBright:"#3aa38e", primaryDim:"#dcf7ef", bg:"#f1f7f4", card:"#ffffff", card2:"#edf5f1", card3:"#e1eee8", text:"#20312c", textDim:"#657c75", textFaint:"#899d96", border:"#d2e2dc", borderStrong:"#bacfc7", borderSubtle:"#e5eee9", surfaceHover:"#ecf4f0", surfaceActive:"#e2ede8", success:"#288a78", danger:"#b34e52", dangerDim:"#f7e4e5", warning:"#8d6b2d", scrollbarTrack:"transparent", scrollbarThumb:"#bacfc7", scrollbarThumbHover:"#9db8ae", shadowCompact:"0 1px 2px rgba(32,49,44,.04)", shadowMd:"0 4px 14px -4px rgba(32,49,44,.09)", shadowLg:"0 12px 32px -10px rgba(40,138,120,.12)", glow:"0 0 0 3px rgba(40,138,120,.10)", focusRing:"0 0 0 3px rgba(40,138,120,.20)" }
      )
    }),
    signalrain: Object.freeze({
      id: "signalrain", label: "Chuva Digital", secret: true, secretKey: "rain", fontFamily: "segoe", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#2af598", primaryBright:"#7df9ff", primaryDim:"#143f39", bg:"#04110e", card:"#081915", card2:"#0c251f", card3:"#133126", text:"#e7fff8", textDim:"#93c9c0", textFaint:"#6d9d96", border:"#1d4338", borderStrong:"#2b5e51", borderSubtle:"#122d25", surfaceHover:"#10271f", surfaceActive:"#153126", success:"#2af598", danger:"#df7474", dangerDim:"#3a171a", warning:"#7df9ff", scrollbarTrack:"transparent", scrollbarThumb:"#2b5e51", scrollbarThumbHover:"#3d8170", shadowCompact:"0 1px 2px rgba(0,0,0,.30)", shadowMd:"0 4px 14px -4px rgba(42,245,152,.12)", shadowLg:"0 14px 36px -12px rgba(125,249,255,.18)", glow:"0 0 0 3px rgba(42,245,152,.14)", focusRing:"0 0 0 3px rgba(125,249,255,.24)" },
        { primary:"#168b72", primaryBright:"#238fa1", primaryDim:"#dffaf2", bg:"#eef8f5", card:"#ffffff", card2:"#e7f4f0", card3:"#dcece7", text:"#17312a", textDim:"#5f7e76", textFaint:"#809a93", border:"#cee2dc", borderStrong:"#b3cbc4", borderSubtle:"#e2efeb", surfaceHover:"#e8f2ef", surfaceActive:"#dcebe7", success:"#168b72", danger:"#b54a55", dangerDim:"#f7e4e7", warning:"#238fa1", scrollbarTrack:"transparent", scrollbarThumb:"#b3cbc4", scrollbarThumbHover:"#97b6ad", shadowCompact:"0 1px 2px rgba(23,49,42,.04)", shadowMd:"0 4px 14px -4px rgba(23,49,42,.09)", shadowLg:"0 12px 32px -10px rgba(22,139,114,.12)", glow:"0 0 0 3px rgba(22,139,114,.10)", focusRing:"0 0 0 3px rgba(35,143,161,.20)" }
      )
    }),
    festivalpop: Object.freeze({
      id: "festivalpop", label: "Festa Pop", secret: true, secretKey: "party", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#ff70a6", primaryBright:"#70d6ff", primaryDim:"#4a1e37", bg:"#110816", card:"#190d22", card2:"#231233", card3:"#30194a", text:"#fff5fb", textDim:"#d5b1c6", textFaint:"#a7849b", border:"#47285c", borderStrong:"#61377c", borderSubtle:"#311d45", surfaceHover:"#2a163d", surfaceActive:"#341c49", success:"#3df2c2", danger:"#ff7b7b", dangerDim:"#4f1c25", warning:"#ffd166", scrollbarTrack:"transparent", scrollbarThumb:"#61377c", scrollbarThumbHover:"#7f4f9f", shadowCompact:"0 1px 2px rgba(0,0,0,.32)", shadowMd:"0 4px 14px -4px rgba(255,112,166,.14)", shadowLg:"0 14px 36px -12px rgba(112,214,255,.18)", glow:"0 0 0 3px rgba(255,112,166,.16)", focusRing:"0 0 0 3px rgba(112,214,255,.24)" },
        { primary:"#b94779", primaryBright:"#2c9cbc", primaryDim:"#fde6f0", bg:"#f9f2fb", card:"#ffffff", card2:"#f5e9f8", card3:"#eadcf2", text:"#341f3c", textDim:"#77627f", textFaint:"#9a85a1", border:"#dfd0ea", borderStrong:"#c5b1d7", borderSubtle:"#eee4f4", surfaceHover:"#f3e9f8", surfaceActive:"#e9ddf1", success:"#2d8b71", danger:"#bd4e5f", dangerDim:"#f9e4e9", warning:"#8f6616", scrollbarTrack:"transparent", scrollbarThumb:"#c5b1d7", scrollbarThumbHover:"#aa93bf", shadowCompact:"0 1px 2px rgba(52,31,60,.05)", shadowMd:"0 4px 14px -4px rgba(52,31,60,.11)", shadowLg:"0 12px 32px -10px rgba(185,71,121,.15)", glow:"0 0 0 3px rgba(185,71,121,.12)", focusRing:"0 0 0 3px rgba(44,156,188,.20)" }
      )
    }),
    velocityred: Object.freeze({
      id: "velocityred", label: "Vermelho Turbo", secret: true, secretKey: "overdrive", fontFamily: "segoe", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#ff5b45", primaryBright:"#ffb36b", primaryDim:"#4d1711", bg:"#0f0706", card:"#180b09", card2:"#24100d", card3:"#311611", text:"#fff1ee", textDim:"#d1aba3", textFaint:"#9f7f79", border:"#4a231c", borderStrong:"#66332a", borderSubtle:"#2d1410", surfaceHover:"#28120f", surfaceActive:"#341712", success:"#68d391", danger:"#ff8181", dangerDim:"#4f1a1a", warning:"#ffb36b", scrollbarTrack:"transparent", scrollbarThumb:"#66332a", scrollbarThumbHover:"#87463a", shadowCompact:"0 1px 2px rgba(0,0,0,.34)", shadowMd:"0 4px 14px -4px rgba(255,91,69,.14)", shadowLg:"0 14px 36px -12px rgba(255,91,69,.22)", glow:"0 0 0 3px rgba(255,91,69,.16)", focusRing:"0 0 0 3px rgba(255,179,107,.24)" },
        { primary:"#c14331", primaryBright:"#d07a2f", primaryDim:"#ffe2dd", bg:"#fbf5f3", card:"#ffffff", card2:"#f6ebe8", card3:"#ecdcd8", text:"#321f1b", textDim:"#78615d", textFaint:"#9a827c", border:"#e3d0cb", borderStrong:"#cdb3ac", borderSubtle:"#efe4e0", surfaceHover:"#f4e9e6", surfaceActive:"#eadbd7", success:"#3f8a63", danger:"#bc4f4f", dangerDim:"#f9e2e2", warning:"#9a5f1b", scrollbarTrack:"transparent", scrollbarThumb:"#cdb3ac", scrollbarThumbHover:"#af8f87", shadowCompact:"0 1px 2px rgba(50,31,27,.05)", shadowMd:"0 4px 14px -4px rgba(50,31,27,.11)", shadowLg:"0 12px 32px -10px rgba(193,67,49,.15)", glow:"0 0 0 3px rgba(193,67,49,.12)", focusRing:"0 0 0 3px rgba(208,122,47,.20)" }
      )
    }),
    glitchcore: Object.freeze({
      id: "glitchcore", label: "Falha Digital", secret: true, secretKey: "glitch", fontFamily: "system", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#ff3eb5", primaryBright:"#37e8ff", primaryDim:"#4a163d", bg:"#090613", card:"#11091c", card2:"#19102b", card3:"#23163b", text:"#fff2fd", textDim:"#d3b2cb", textFaint:"#9d82a1", border:"#3a2852", borderStrong:"#4f3970", borderSubtle:"#26193e", surfaceHover:"#201331", surfaceActive:"#2a1a41", success:"#44e2b3", danger:"#ff8089", dangerDim:"#4d1d2c", warning:"#37e8ff", scrollbarTrack:"transparent", scrollbarThumb:"#4f3970", scrollbarThumbHover:"#6c5394", shadowCompact:"0 1px 2px rgba(0,0,0,.35)", shadowMd:"0 4px 14px -4px rgba(255,62,181,.15)", shadowLg:"0 14px 36px -12px rgba(55,232,255,.18)", glow:"0 0 0 3px rgba(255,62,181,.16)", focusRing:"0 0 0 3px rgba(55,232,255,.24)" },
        { primary:"#b72d86", primaryBright:"#007f8f", primaryDim:"#fde5f5", bg:"#f8f4fb", card:"#ffffff", card2:"#f2ebfa", card3:"#e6ddf4", text:"#311f3a", textDim:"#766583", textFaint:"#9787a4", border:"#ddd2ea", borderStrong:"#c3b4d8", borderSubtle:"#ede6f3", surfaceHover:"#efe7f7", surfaceActive:"#e5daf1", success:"#2d8b73", danger:"#bf4c67", dangerDim:"#f9e2ea", warning:"#1b8ea2", scrollbarTrack:"transparent", scrollbarThumb:"#c3b4d8", scrollbarThumbHover:"#a896bf", shadowCompact:"0 1px 2px rgba(49,31,58,.05)", shadowMd:"0 4px 14px -4px rgba(49,31,58,.11)", shadowLg:"0 12px 32px -10px rgba(183,45,134,.15)", glow:"0 0 0 3px rgba(183,45,134,.12)", focusRing:"0 0 0 3px rgba(0,127,143,.20)" }
      )
    }),
    portalvoid: Object.freeze({
      id: "portalvoid", label: "Portal XYZZY", secret: true, secretKey: "xyzzy", fontFamily: "segoe", motion: "normal", radiusPreset: "rounded",
      palette: p(
        { primary:"#b758ff", primaryBright:"#70d6ff", primaryDim:"#331651", bg:"#060513", card:"#0b0a1b", card2:"#120f2a", card3:"#1a1438", text:"#f7f3ff", textDim:"#bbb0d9", textFaint:"#8a82aa", border:"#312850", borderStrong:"#493b72", borderSubtle:"#211a38", surfaceHover:"#1a1433", surfaceActive:"#231c42", success:"#60ddb8", danger:"#ee7095", dangerDim:"#4a1b31", warning:"#ffd166", scrollbarTrack:"transparent", scrollbarThumb:"#493b72", scrollbarThumbHover:"#64549a", shadowCompact:"0 1px 2px rgba(0,0,0,.36)", shadowMd:"0 4px 14px -4px rgba(183,88,255,.14)", shadowLg:"0 14px 36px -12px rgba(112,214,255,.16)", glow:"0 0 0 3px rgba(183,88,255,.16)", focusRing:"0 0 0 3px rgba(112,214,255,.24)" },
        { primary:"#7a3db5", primaryBright:"#2f8eb2", primaryDim:"#eee3fb", bg:"#f5f4fb", card:"#ffffff", card2:"#efebfa", card3:"#e4ddf2", text:"#2f2540", textDim:"#706784", textFaint:"#928aa5", border:"#d8d0e8", borderStrong:"#bfb2d7", borderSubtle:"#ebe5f4", surfaceHover:"#eee9f8", surfaceActive:"#e4dcf1", success:"#2f8c72", danger:"#bb4e68", dangerDim:"#f9e3ea", warning:"#916619", scrollbarTrack:"transparent", scrollbarThumb:"#bfb2d7", scrollbarThumbHover:"#a595c0", shadowCompact:"0 1px 2px rgba(47,37,64,.05)", shadowMd:"0 4px 14px -4px rgba(47,37,64,.11)", shadowLg:"0 12px 32px -10px rgba(122,61,181,.15)", glow:"0 0 0 3px rgba(122,61,181,.12)", focusRing:"0 0 0 3px rgba(47,142,178,.20)" }
      )
    }),
    brasaviva: Object.freeze({
      id: "brasaviva", label: "Brasa Viva", secret: true, secretKey: "brasa", fontFamily: "system", motion: "normal", radiusPreset: "rounded",
      palette: { sidebarBg: "#130807", sidebarSurface: "#20100d", sidebarText: "#fde9d8", sidebarMuted: "#f2b58c", sidebarAccent: "#ff8b4d", sidebarAccent2: "#ffb36b", sidebarBorder: "rgba(255,139,77,0.26)", panelBg: "#160a08", panelSurface: "#26110d", panelSurface2: "#311610", panelText: "#fff0e4", panelMuted: "#eab391", panelAccent: "#ff8b4d", panelAccent2: "#ffb36b", panelBorder: "rgba(255,139,77,0.22)", danger: "#ff6d4d", success: "#ffb36b" }
    }),
    oceanoazul: Object.freeze({
      id: "oceanoazul", label: "Azul Oceano", secret: true, secretKey: "oceano", fontFamily: "system", motion: "reduced", radiusPreset: "rounded",
      palette: { sidebarBg: "#041017", sidebarSurface: "#0a1820", sidebarText: "#dff7ff", sidebarMuted: "#94d7ef", sidebarAccent: "#4bb7e8", sidebarAccent2: "#6ce3ff", sidebarBorder: "rgba(75,183,232,0.24)", panelBg: "#05121b", panelSurface: "#0c1c25", panelSurface2: "#112530", panelText: "#ebfbff", panelMuted: "#9edbec", panelAccent: "#4bb7e8", panelAccent2: "#6ce3ff", panelBorder: "rgba(75,183,232,0.22)", danger: "#ff8b6b", success: "#6ce3ff" }
    }),
    pixelpop: Object.freeze({
      id: "pixelpop", label: "Pixel Pop", secret: true, secretKey: "pixel", fontFamily: "mono", motion: "normal", radiusPreset: "compact",
      palette: { sidebarBg: "#100717", sidebarSurface: "#180c24", sidebarText: "#f8ebff", sidebarMuted: "#d5a4ff", sidebarAccent: "#ff62d7", sidebarAccent2: "#63f4ff", sidebarBorder: "rgba(255,98,215,0.28)", panelBg: "#12081a", panelSurface: "#1b0d28", panelSurface2: "#231036", panelText: "#fff3ff", panelMuted: "#dfb9ff", panelAccent: "#ff62d7", panelAccent2: "#63f4ff", panelBorder: "rgba(255,98,215,0.22)", danger: "#ff7ca2", success: "#63f4ff" }
    }),
    matrix: Object.freeze({
      id: "matrix", label: "Matrix", secret: true, fontFamily: "segoe", motion: "normal", radiusPreset: "compact",
      palette: p(
        { primary:"#00ff88", primaryBright:"#7dffb8", primaryDim:"#06351f", bg:"#020705", card:"#06110c", card2:"#0a1b12", card3:"#10281b", text:"#d8ffe9", textDim:"#78b993", textFaint:"#48765d", border:"#123b26", borderStrong:"#1b5a39", borderSubtle:"#0b2819", surfaceHover:"#0d2418", surfaceActive:"#123520", success:"#00ff88", danger:"#ff4d6d", dangerDim:"#3c101c", warning:"#d6ff4d", scrollbarTrack:"transparent", scrollbarThumb:"#1b5a39", scrollbarThumbHover:"#24794c", shadowCompact:"0 1px 2px rgba(0,0,0,.5)", shadowMd:"0 6px 18px -5px rgba(0,0,0,.72)", shadowLg:"0 16px 42px -12px rgba(0,255,136,.2)", glow:"0 0 0 3px rgba(0,255,136,.18)", focusRing:"0 0 0 3px rgba(0,255,136,.32)" },
        { primary:"#008f4f", primaryBright:"#00b866", primaryDim:"#d9f8e7", bg:"#eff8f2", card:"#ffffff", card2:"#f4fbf6", card3:"#e7f5ec", text:"#0c2417", textDim:"#527061", textFaint:"#789487", border:"#cfe6d7", borderStrong:"#b3d6c0", borderSubtle:"#e4f0e8", surfaceHover:"#edf7f0", surfaceActive:"#e1f1e6", success:"#008f4f", danger:"#bf3652", dangerDim:"#f9e2e8", warning:"#7c850e", scrollbarTrack:"transparent", scrollbarThumb:"#b3d6c0", scrollbarThumbHover:"#91bfa1", shadowCompact:"0 1px 2px rgba(12,36,23,.05)", shadowMd:"0 4px 14px -4px rgba(12,36,23,.11)", shadowLg:"0 12px 32px -10px rgba(0,143,79,.18)", glow:"0 0 0 3px rgba(0,143,79,.12)", focusRing:"0 0 0 3px rgba(0,143,79,.24)" }
      )
    })
  });

  var ICON_3D_COLORS = Object.freeze({
    olive: { label:"Verde-oliva", bg:"#607d3b" },
    mint: { label:"Verde", bg:"#00a884" },
    sky: { label:"Azul claro", bg:"#38a9db" },
    blue: { label:"Azul", bg:"#3867d6" },
    wine: { label:"Vinho", bg:"#8f3554" },
    rose: { label:"Rosê", bg:"#c06c84" },
    gray: { label:"Cinza", bg:"#66727d" },
    orange: { label:"Laranja", bg:"#d97706" },
    violet: { label:"Violeta", bg:"#7557c8" },
    graphite: { label:"Grafite", bg:"#343a40" }
  });

  function pickAppearance(source) {
    var out={};source=source&&typeof source==="object"?source:{};APPEARANCE_KEYS.forEach(function(k){if(Object.prototype.hasOwnProperty.call(source,k))out[k]=source[k];});return out;
  }
  function readRaw() {
    return new Promise(function(resolve,reject){
      try{if(root.chrome&&chrome.storage&&chrome.storage.local){chrome.storage.local.get([STORAGE_KEY,APPEARANCE_SNAPSHOT_KEY],function(r){if(chrome.runtime&&chrome.runtime.lastError){var readErr=new Error(chrome.runtime.lastError.message||"Não foi possível ler a aparência atual.");void chrome.runtime.lastError;reject(readErr);return;}var base=parse(r&&r[STORAGE_KEY]),shadow=parse(r&&r[APPEARANCE_SNAPSHOT_KEY]);if((Number(shadow.appearanceRevision)||0)>(Number(base.appearanceRevision)||0))base=Object.assign({},base,pickAppearance(shadow));resolve(base);});return;}}catch(err){reject(err);return;}
      try{if(root.ExtensionStorage&&root.ExtensionStorage.get){Promise.resolve(root.ExtensionStorage.get(STORAGE_KEY)).then(function(v){resolve(parse(v));},reject);return;}}catch(err2){reject(err2);return;}resolve({});
    });
  }
  function writeRaw(value) {
    var patch=pickAppearance(value);
    return new Promise(function(resolve,reject){
      function fallback(){try{if(!(root.chrome&&chrome.storage&&chrome.storage.local)){reject(new Error("Os dados da extensão não estão disponíveis no momento"));return;}chrome.storage.local.get([STORAGE_KEY,APPEARANCE_SNAPSHOT_KEY],function(r){if(chrome.runtime&&chrome.runtime.lastError){var readErr=new Error(chrome.runtime.lastError.message||"Não foi possível ler as opções atuais.");void chrome.runtime.lastError;reject(readErr);return;}var current=parse(r&&r[STORAGE_KEY]),next=Object.assign({},current,patch),rev=(Number(current.appearanceRevision)||0)+1;next.themeStateVersion=7;next.appearanceRevision=rev;var shadow=pickAppearance(next),payload={};shadow.themeStateVersion=7;shadow.appearanceRevision=rev;payload[STORAGE_KEY]=next;payload[APPEARANCE_SNAPSHOT_KEY]=shadow;chrome.storage.local.set(payload,function(){if(chrome.runtime&&chrome.runtime.lastError)reject(chrome.runtime.lastError);else resolve(next);});});}catch(e){reject(e);}}
      try{if(root.chrome&&chrome.runtime&&chrome.runtime.sendMessage){chrome.runtime.sendMessage({type:"EXTUI_OPTIONS_COMMIT",scope:"appearance",patch:patch},function(res){if(chrome.runtime&&chrome.runtime.lastError){fallback();return;}if(res&&res.ok===true&&res.value){resolve(res.value);return;}fallback();});return;}}catch(_){}fallback();
    });
  }
  function parse(raw) { if (!raw) return {}; if (typeof raw === "string") { try { return JSON.parse(raw)||{}; } catch (_) { return {}; } } return Object.assign({}, raw); }
  function normalize(opts) {
    var source=opts&&typeof opts==="object"?opts:{};
    var hadMode=Object.prototype.hasOwnProperty.call(source,"mode");
    var themeStateVersion=Number(source.themeStateVersion)||0;
    var placementVersion=Number(source.sidebarPlacementVersion)||0;
    var placementUserSet=source.sidebarPlacementUserSet===true;
    var workspaceVersion=Number(source.floatingWorkspaceLayoutVersion)||0;
    opts=Object.assign({},FACTORY_DEFAULTS,source);
    if(themeStateVersion<3 && !hadMode && Object.prototype.hasOwnProperty.call(source,"theme")) opts.mode=source.theme === "dark" ? "dark" : source.theme === "light" ? "light" : "auto";
    opts.themeStateVersion=7;
                                                                            
                                                                              
    if(!hadMode&&source.theme) opts.mode=source.theme === "light" ? "light" : source.theme === "dark" ? "dark" : "auto";
    if(opts.fontFamily==="default")opts.fontFamily="system";
    if(!THEMES[opts.visualTheme]) opts.visualTheme="padrao";
    if(["auto","dark","light"].indexOf(opts.mode)<0) opts.mode="dark";
    if(opts.mode==="dark"||opts.mode==="light") opts.theme=opts.mode;
    if(opts.iconTheme!=="3d" && opts.iconTheme!=="monochrome" && opts.iconTheme!=="color") opts.iconTheme="monochrome";
    if(opts.sidebarPlacement!=="right-conversation" && opts.sidebarPlacement!=="left-native") opts.sidebarPlacement="left-native";
    if(!placementUserSet && placementVersion<2) opts.sidebarPlacement="left-native";
    opts.sidebarPlacementVersion=2;
    opts.sidebarPlacementUserSet=placementUserSet;
    opts.rightSidebarPanelsFollowRail=opts.rightSidebarPanelsFollowRail===true;
    if(workspaceVersion<4)opts.floatingWindowMovable=true;
    if(workspaceVersion<2)opts.floatingWindowResizable=false;
    opts.floatingWorkspaceLayoutVersion=4;
    opts.floatingWindowMovable=opts.floatingWindowMovable===true;
    opts.floatingWindowResizable=opts.floatingWindowResizable===true;
    if(!ICON_3D_COLORS[opts.icon3dColor]) opts.icon3dColor="olive";
    if(!FONTS[opts.fontFamily]) opts.fontFamily=THEMES[opts.visualTheme].fontFamily;
    if(["auto","normal","reduced","off"].indexOf(opts.motion)<0) opts.motion="auto";
    if(["compact","default","rounded"].indexOf(opts.radiusPreset)<0) opts.radiusPreset="default";
    opts.menuVisibility=opts.menuVisibility&&typeof opts.menuVisibility==="object"?opts.menuVisibility:{};
    opts.quickShelfUseIconTheme=opts.quickShelfUseIconTheme===true;
    opts.accessibilityTextScale=Math.max(100,Math.min(200,Math.round(Number(opts.accessibilityTextScale)||110)));
    opts.accessibilityContrast=opts.accessibilityContrast==="standard"?"standard":"enhanced";
    opts.accessibilityColorAssist=opts.accessibilityColorAssist!==false;
    return opts;
  }
  function parseRgbColor(value){var m=String(value||"").match(/rgba?\(\s*(\d+(?:\.\d+)?)\s*[, ]\s*(\d+(?:\.\d+)?)\s*[, ]\s*(\d+(?:\.\d+)?)/i);return m?[Number(m[1]),Number(m[2]),Number(m[3])]:null;}
  function detectWhatsAppMode(){try{if(!root.location||root.location.hostname!=="web.whatsapp.com"||!root.document)return null;var seeds=[root.document.querySelector('[data-testid="navbar-primary-section"]'),root.document.querySelector('[data-testid="chatlist-header"]'),root.document.getElementById("app")].filter(Boolean);for(var i=0;i<seeds.length;i++){var node=seeds[i],depth=0;while(node&&depth++<5){var cs=root.getComputedStyle?root.getComputedStyle(node):null,rgb=cs&&parseRgbColor(cs.backgroundColor);if(rgb){var y=(.2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2])/255;if(y<.42)return "dark";if(y>.68)return "light";}node=node.parentElement;}}}catch(_){}return null;}
  function resolvedMode(opts) {if(opts.mode==="dark"||opts.mode==="light")return opts.mode;var wa=detectWhatsAppMode();if(wa)return wa;try{return root.matchMedia&&root.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(_){return "light";}}
  function luminance(hex){var n=parseInt(String(hex).replace("#",""),16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;function f(v){v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4);}return .2126*f(r)+.7152*f(g)+.0722*f(b);}
  function a11yHexRgb(value){var v=String(value||"").trim(),m=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(v);if(!m)return null;var h=m[1];if(h.length===3)h=h.split("").map(function(c){return c+c;}).join("");return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
  function a11yRgbHex(rgb){return"#"+rgb.map(function(v){return Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,"0");}).join("");}
  function a11yLum(value){var rgb=a11yHexRgb(value);if(!rgb)return null;function f(v){v/=255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);}return .2126*f(rgb[0])+.7152*f(rgb[1])+.0722*f(rgb[2]);}
  function a11yContrast(a,b){var la=a11yLum(a),lb=a11yLum(b);if(la==null||lb==null)return 0;return(Math.max(la,lb)+.05)/(Math.min(la,lb)+.05);}
  function a11yMinContrast(fg,bgs){var rows=(bgs||[]).filter(Boolean),min=Infinity;for(var i=0;i<rows.length;i++){var ratio=a11yContrast(fg,rows[i]);if(!ratio)return 0;min=Math.min(min,ratio);}return min===Infinity?0:min;}
  function a11yEnsureContrast(fg,bgs,target,toward){var from=a11yHexRgb(fg),to=a11yHexRgb(toward);if(!from||!to||!Array.isArray(bgs)||!bgs.length)return fg;if(a11yMinContrast(fg,bgs)>=target)return fg;for(var step=1;step<=24;step++){var t=step/24,candidate=a11yRgbHex([from[0]+(to[0]-from[0])*t,from[1]+(to[1]-from[1])*t,from[2]+(to[2]-from[2])*t]);if(a11yMinContrast(candidate,bgs)>=target)return candidate;}return toward;}
  var appliedPaletteVars = [];
  function resolveThemePalette(theme,mode){
    var raw=theme&&theme.palette||{},palette=raw&&raw[mode];
    if(palette&&typeof palette==="object")return palette;
    if(raw&&typeof raw==="object"&&(raw.panelBg||raw.sidebarBg)){
      var accent=raw.panelAccent||raw.sidebarAccent||"#00c85a",accent2=raw.panelAccent2||raw.sidebarAccent2||accent;
      if(mode==="light")return{primary:accent,primaryBright:accent2,primaryDim:"#e5f3ec",bg:"#f3f6f4",card:"#ffffff",card2:"#f5f8f6",card3:"#eaf0ec",text:"#1c2821",textDim:"#65736b",textFaint:"#87928c",border:"#d8e1dc",borderStrong:"#c1cec7",borderSubtle:"#e8eeea",surfaceHover:"#edf3ef",surfaceActive:"#e3ece6",success:raw.success||accent,danger:raw.danger||"#c84252",dangerDim:"#f9e4e8",warning:accent2,scrollbarTrack:"transparent",scrollbarThumb:"#c1cec7",scrollbarThumbHover:"#a5b6ad",shadowCompact:"0 1px 2px rgba(28,40,33,.05)",shadowMd:"0 4px 14px -4px rgba(28,40,33,.11)",shadowLg:"0 12px 32px -10px rgba(28,40,33,.16)",glow:"0 0 0 3px color-mix(in srgb, "+accent+" 14%, transparent)",focusRing:"0 0 0 3px color-mix(in srgb, "+accent+" 24%, transparent)"};
      return{primary:accent,primaryBright:accent2,primaryDim:raw.sidebarSurface||raw.panelSurface2||"#173428",bg:raw.panelBg||raw.sidebarBg||"#080808",card:raw.panelSurface||raw.sidebarSurface||"#0d0d0d",card2:raw.panelSurface2||raw.sidebarSurface||"#151515",card3:raw.sidebarSurface||raw.panelSurface2||"#1a1d1b",text:raw.panelText||raw.sidebarText||"#e0e0e0",textDim:raw.panelMuted||raw.sidebarMuted||"#a0a0a0",textFaint:raw.sidebarMuted||raw.panelMuted||"#747d77",border:raw.panelBorder||raw.sidebarBorder||"#1e1e1e",borderStrong:raw.sidebarBorder||raw.panelBorder||"#303530",borderSubtle:raw.panelBorder||raw.sidebarBorder||"#181b19",surfaceHover:raw.panelSurface2||raw.sidebarSurface||"#171d19",surfaceActive:raw.sidebarSurface||raw.panelSurface2||"#1c251f",success:raw.success||accent,danger:raw.danger||"#f05060",dangerDim:"#35151b",warning:accent2,scrollbarTrack:"transparent",scrollbarThumb:raw.sidebarBorder||"#303530",scrollbarThumbHover:accent,shadowCompact:"0 1px 2px rgba(0,0,0,.36)",shadowMd:"0 4px 14px -4px rgba(0,0,0,.56)",shadowLg:"0 12px 32px -10px rgba(0,0,0,.70)",glow:"0 0 0 3px color-mix(in srgb, "+accent+" 18%, transparent)",focusRing:"0 0 0 3px color-mix(in srgb, "+accent+" 30%, transparent)"};
    }
    return THEMES.padrao.palette[mode]||THEMES.padrao.palette.dark;
  }
  function apply(opts) {
    opts=normalize(opts);var doc=root.document;if(!doc||!doc.documentElement)return opts;
    var el=doc.documentElement,mode=resolvedMode(opts),theme=THEMES[opts.visualTheme],palette=resolveThemePalette(theme,mode);
    el.setAttribute("data-extui-theme",mode);el.setAttribute("data-extui-mode",opts.mode);el.setAttribute("data-extui-visual-theme",opts.visualTheme);el.setAttribute("data-extui-theme-ready","true");el.style.colorScheme=mode;
    el.setAttribute("data-extui-motion",opts.motion);el.setAttribute("data-extui-radius",opts.radiusPreset);el.setAttribute("data-extui-icon-theme",opts.iconTheme);el.setAttribute("data-extui-sidebar-placement",opts.sidebarPlacement);el.setAttribute("data-extui-right-panels-follow-rail",String(opts.rightSidebarPanelsFollowRail===true));
    var a11yScale=Math.max(100,Math.min(200,Number(opts.accessibilityTextScale)||110)),a11yRatio=a11yScale/100;el.setAttribute("data-extui-a11y-text-scale",String(a11yScale));el.setAttribute("data-extui-a11y-contrast",opts.accessibilityContrast);el.setAttribute("data-extui-a11y-color-assist",String(opts.accessibilityColorAssist===true));el.style.setProperty("--extui-a11y-text-scale",String(a11yRatio));el.style.setProperty("--extui-a11y-text-floor",(11.5*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-micro-size",(12*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-label-size",(13*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-caption-size",(13.5*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-body-size",(14*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-section-size",(13*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-heading-size",(18*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-display-size",(24*a11yRatio).toFixed(2)+"px");el.style.setProperty("--extui-text-control-size",(14*a11yRatio).toFixed(2)+"px");
                                                                          
                                                                            
                                                                          
    appliedPaletteVars.forEach(function(css){try{el.style.removeProperty(css);}catch(_){}});
    appliedPaletteVars=[];
    palette=Object.assign({},palette);var a11ySurfaces=[palette.bg,palette.card,palette.card2,palette.card3].filter(function(v){return !!a11yHexRgb(v);}),a11yFocusColor=a11yEnsureContrast(palette.primaryBright||palette.primary||palette.text,a11ySurfaces,3,palette.text||palette.primaryBright||palette.primary);if(opts.accessibilityContrast==="enhanced"){if(palette.textDim)palette.textDim=a11yEnsureContrast(palette.textDim,a11ySurfaces,4.5,palette.text||palette.textDim);palette.textFaint=palette.textDim||palette.textFaint;}
    Object.keys(palette).forEach(function(k){
                                                                       
                                                                           
                                                                              
                     
      var name=k.replace(/[A-Z]/g,function(m){return "-"+m.toLowerCase();}).replace(/([a-zA-Z])(\d+)/g,"$1-$2");
      var css="--extui-"+name;el.style.setProperty(css,palette[k]);appliedPaletteVars.push(css);
    });
    el.style.setProperty("--extui-a11y-focus-color",a11yFocusColor||palette.primaryBright||palette.primary||palette.text||"#00e676");
    el.style.setProperty("--extui-sidebar-theme-accent",palette.primaryBright||palette.primary||"#00e676");
    el.style.setProperty("--extui-font-family",FONTS[opts.fontFamily]||FONTS.system);
    el.style.setProperty("--extui-sidebar-icon-size",Math.max(16,Math.min(64,Number(opts.sidebarMainIconSize)||36))+"px");
    var dash=opts.dashboardUseSidebarIconSize===true?(Number(opts.sidebarMainIconSize)||36):(Number(opts.dashboardMenuIconSize)||28);
    el.style.setProperty("--extui-dashboard-menu-icon-size",Math.max(16,Math.min(64,dash))+"px");
    el.style.setProperty("--extui-disparos-icon-size",Math.max(20,Math.min(64,Number(opts.disparosIconSize)||38))+"px");
    var c=ICON_3D_COLORS[opts.icon3dColor]||ICON_3D_COLORS.olive;el.style.setProperty("--extui-icon-3d-bg",c.bg);el.style.setProperty("--extui-icon-3d-fg",luminance(c.bg)>.45?"#121714":"#ffffff");
    el.style.setProperty("--extui-muted",palette.textDim||"");el.style.setProperty("--extui-surface",palette.card||"");el.style.setProperty("--extui-input",palette.card||"");
    var shelfTheme=opts.iconTheme==="color"?"color":opts.quickShelfUseIconTheme?opts.iconTheme:"color";el.setAttribute("data-extui-quick-shelf-icon-theme",shelfTheme);
    return opts;
  }
  function matchesFactory(opts) {
    opts=normalize(opts);return ["mode","visualTheme","fontFamily","motion","radiusPreset","iconTheme","icon3dColor","quickShelfUseIconTheme","sidebarMainIconSize","dashboardUseSidebarIconSize","dashboardMenuIconSize","accessibilityTextScale","accessibilityContrast","accessibilityColorAssist"].every(function(k){return JSON.stringify(opts[k])===JSON.stringify(FACTORY_DEFAULTS[k]);});
  }
  function withDefinition(opts){opts=normalize(opts);opts.appearanceDefinition=matchesFactory(opts)?"default":"custom";return opts;}
  async function load(){
    var raw=parse(await readRaw()),source=raw;
    if(raw.appearanceDefinition==="default"){source=Object.assign({},raw);APPEARANCE_KEYS.forEach(function(k){if(Object.prototype.hasOwnProperty.call(FACTORY_DEFAULTS,k))source[k]=FACTORY_DEFAULTS[k];});}
    var normalized=withDefinition(source);
    if(raw.themeStateVersion!==7 || raw.mode!==normalized.mode || raw.theme!==normalized.theme || raw.visualTheme!==normalized.visualTheme || raw.appearanceDefinition!==normalized.appearanceDefinition || (raw.iconTheme && raw.iconTheme!==normalized.iconTheme)){try{normalized=withDefinition(await writeRaw(normalized));}catch(_){}}
    return normalized;
  }
  async function save(opts){opts=withDefinition(opts);var merged=await writeRaw(opts);opts=withDefinition(Object.assign({},opts,merged||{}));apply(opts);return opts;}
  function selectTheme(opts,id){opts=normalize(opts);var t=THEMES[id]||THEMES.padrao;opts.visualTheme=t.id;opts.fontFamily=t.fontFamily;opts.motion=t.motion;opts.radiusPreset=t.radiusPreset;return withDefinition(opts);}
  function factory(){return Object.assign({},FACTORY_DEFAULTS,{menuVisibility:{}});}

  var api=Object.freeze({version:"3.1.0",storageKey:STORAGE_KEY,defaults:FACTORY_DEFAULTS,themes:THEMES,fonts:FONTS,icon3dColors:ICON_3D_COLORS,normalize:normalize,resolvedMode:resolvedMode,apply:apply,load:load,save:save,matchesFactory:matchesFactory,withDefinition:withDefinition,selectTheme:selectTheme,factory:factory,ready:function(){return ready;}});
  root.__extThemeSystem=api;root.ExtensionCore=root.ExtensionCore||{};root.ExtensionCore.ThemeSystem=api;

  try{if(root.document&&root.document.documentElement)root.document.documentElement.setAttribute("data-extui-theme-ready","false");}catch(_){}
  var ready=load().then(function(o){apply(o);return o;}).catch(function(err){if(root.__extReportRuntimeError)root.__extReportRuntimeError("THEME_INITIAL_LOAD_FAILED",err);var f=factory();apply(f);return f;});
  try { if(root.matchMedia){var mq=root.matchMedia("(prefers-color-scheme: dark)");var listener=function(){load().then(function(o){if(o.mode==="auto")apply(o);}).catch(function(err){if(root.__extReportRuntimeError)root.__extReportRuntimeError("THEME_AUTO_REFRESH_FAILED",err);});};if(mq.addEventListener)mq.addEventListener("change",listener);else if(mq.addListener)mq.addListener(listener);} } catch(_){}
  try {
                                                                             
                                                                            
                                                                        
    if(root.ExtensionStorage&&typeof root.ExtensionStorage.subscribe==="function"){
      root.ExtensionStorage.subscribe(STORAGE_KEY,function(newValue){apply(parse(newValue));});
    }
  } catch(_){}
})(typeof window!=="undefined"?window:self);
}catch(_extuiBundleError){window.__extRecordBootError(_extuiBundleError);}
;
