;(function(){"use strict";
  var scriptPromises=Object.create(null),sectionPromises=Object.create(null),adaptivePath="app/dashboard/features/delivery/adaptive-delivery.js";
  var sectionScripts=Object.freeze({
    "disparos":["app/content/features/workspace/data/client-locale.js","app/shared/core/spreadsheet-import.js","app/dashboard/features/backup/settings.js","app/dashboard/features/broadcast/core.js"],
    "fluxos":["app/dashboard/features/automation-metadata-modal.js","app/dashboard/features/funnels/runtime.js","app/dashboard/features/flows/groups-core.js","app/dashboard/features/flows/simulator-core.js","app/dashboard/features/flows/runtime.js"],
    "funis":["app/dashboard/features/automation-metadata-modal.js","app/dashboard/features/funnels/runtime.js","app/dashboard/features/flows/groups-core.js","app/dashboard/features/flows/simulator-core.js","app/dashboard/features/flows/runtime.js"],
    "agenda":["app/dashboard/features/agenda/runtime.js"],
    "followup":["app/dashboard/features/followup/runtime.js"],
    "crm":["app/dashboard/features/crm/ai.js","app/dashboard/features/crm/ui.js"],
    "customers":["app/content/features/workspace/data/client-locale.js","app/content/features/workspace/panel-client-helper-core.js","app/dashboard/features/customers/panel.js"],
    "crm-funnel":["app/dashboard/features/crm/ai.js","app/dashboard/features/crm/ui.js","app/dashboard/features/crm/funnel.js"],
    "salvar":["app/dashboard/features/import-export/save-export.js"],
    "laboratorio":["app/dashboard/features/laboratory/core.js","app/dashboard/features/automation-metadata-modal.js","app/dashboard/features/funnels/runtime.js","app/dashboard/features/flows/groups-core.js","app/dashboard/features/flows/simulator-core.js","app/dashboard/features/flows/runtime.js","app/dashboard/features/laboratory/panel.js"],
    "ai-memory":["app/dashboard/features/ai/memory.js"],
    "knowledge":["app/dashboard/features/knowledge/runtime.js"],
    "ai-connect":["app/dashboard/features/ai/policy.js","app/dashboard/features/integrations/runtime.js"],
    "ai-transcription":["app/dashboard/features/ai/policy.js","app/dashboard/features/integrations/runtime.js"],
    "ai-translation":["app/dashboard/features/ai/policy.js","app/dashboard/features/integrations/runtime.js"],
    "integracoes":["app/dashboard/features/ai/policy.js","app/dashboard/features/integrations/runtime.js"],
    "meta-oficial":["app/dashboard/features/ai/policy.js","app/dashboard/features/integrations/runtime.js"],
    "ai-assistants":["app/dashboard/features/ai/policy.js","app/dashboard/features/integrations/runtime.js","app/dashboard/features/ai/assistants.js"],
    "ai-agents":["app/dashboard/features/ai/agents.js"],
    "quick-responses":["app/dashboard/features/library/items.js"],
    "itens-message":["app/dashboard/features/library/items.js"],
    "itens-audio":["app/dashboard/features/library/items.js"],
    "itens-image":["app/dashboard/features/library/items.js"],
    "itens-video":["app/dashboard/features/library/items.js"],
    "itens-media":["app/dashboard/features/library/items.js"],
    "itens-sticker":["app/dashboard/features/library/items.js"],
    "itens-document":["app/dashboard/features/library/items.js"],
    "itens-pix":["app/dashboard/features/library/items.js"],
    "itens-interactive-list":["app/dashboard/features/library/items.js"],
    "itens-contact":["app/dashboard/features/library/items.js"],
    "itens-signature":["app/dashboard/features/library/items.js"],
    "ajustes":[adaptivePath,"app/shared/core/backup-secure-envelope.js","app/shared/core/backup-external-structured.js","app/shared/core/backup-compatibility.js","app/dashboard/features/backup/large-json.js","app/dashboard/features/backup/settings.js"],
    "backup":[adaptivePath,"app/shared/core/backup-secure-envelope.js","app/shared/core/backup-external-structured.js","app/shared/core/backup-compatibility.js","app/dashboard/features/backup/large-json.js","app/dashboard/features/backup/settings.js"],
    "delivery":[adaptivePath],
    "encomendas":[adaptivePath],
    "atividades":[adaptivePath]
  });
  function url(path){try{return chrome.runtime.getURL(path);}catch(_){return "../../"+path;}}
  function loadScript(path){
    if(scriptPromises[path])return scriptPromises[path];
    scriptPromises[path]=new Promise(function(resolve,reject){
      var absolute=url(path),existing=Array.prototype.find.call(document.scripts,function(node){return node.src===absolute;});
      if(existing&&existing.dataset.extappLazyLoaded==="1"){resolve(true);return;}
      var s=existing||document.createElement("script");
      function done(){s.dataset.extappLazyLoaded="1";resolve(true);}
      function failed(){if(s&&s.dataset&&s.dataset.extappLazyModule===path&&!s.dataset.extappLazyLoaded)s.remove();delete scriptPromises[path];reject(new Error("Não foi possível carregar o módulo: "+path));}
      if(existing){if(existing.readyState==="complete"||existing.readyState==="loaded"){done();return;}existing.addEventListener("load",done,{once:true});existing.addEventListener("error",failed,{once:true});return;}
      s.src=absolute;s.async=true;s.dataset.extappLazyModule=path;s.addEventListener("load",done,{once:true});s.addEventListener("error",failed,{once:true});(document.head||document.documentElement).appendChild(s);
    });
    return scriptPromises[path];
  }
  function canLoad(section){return Object.prototype.hasOwnProperty.call(sectionScripts,String(section||""));}
  function ensure(section){section=String(section||"");if(!canLoad(section))return Promise.resolve(false);if(sectionPromises[section])return sectionPromises[section];var list=sectionScripts[section];sectionPromises[section]=list.reduce(function(chain,path){return chain.then(function(){return loadScript(path);});},Promise.resolve()).then(function(){return true;}).catch(function(error){delete sectionPromises[section];if(window.__extRecordBootError)window.__extRecordBootError(error);throw error;});return sectionPromises[section];}
  function reportLazyLoadFailure(error){if(window.__extReportRuntimeError)window.__extReportRuntimeError("DASHBOARD_LAZY_MODULE_LOAD_FAILED",error);else if(window.__extRecordBootError)window.__extRecordBootError(error);}
  function sectionFromTarget(target){var el=target&&target.closest&&target.closest('[data-section]');return el?String(el.getAttribute('data-section')||''):"";}
  document.addEventListener('pointerover',function(ev){var section=sectionFromTarget(ev.target);if(canLoad(section))ensure(section).catch(reportLazyLoadFailure);},{capture:true,passive:true});
  document.addEventListener('pointerdown',function(ev){var section=sectionFromTarget(ev.target);if(canLoad(section))ensure(section).catch(reportLazyLoadFailure);},{capture:true,passive:true});
  function scheduleAdaptive(){var load=function(){loadScript(adaptivePath).catch(reportLazyLoadFailure);};if(typeof requestIdleCallback==="function")requestIdleCallback(load,{timeout:1800});else setTimeout(load,1000);}
  try{var u=new URL(location.href),section=String(u.searchParams.get('section')||(history.state&&history.state.extappSection)||'');if(canLoad(section))window.addEventListener("load",function(){ensure(section).catch(reportLazyLoadFailure);},{once:true});window.addEventListener("load",scheduleAdaptive,{once:true});}catch(_){window.addEventListener("load",scheduleAdaptive,{once:true});}
  window.addEventListener("ext:load-adaptive-delivery",function(){loadScript(adaptivePath).catch(reportLazyLoadFailure);});
  window.__extDashboardLazyLoader=Object.freeze({canLoad:canLoad,ensure:ensure,loadScript:loadScript});
})();
