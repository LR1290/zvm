(function(t){"use strict";if(!t.__extExpansionStaticData)throw new Error("Dados estáticos ausentes.");Object.freeze(t.__extExpansionStaticData)})(window);
