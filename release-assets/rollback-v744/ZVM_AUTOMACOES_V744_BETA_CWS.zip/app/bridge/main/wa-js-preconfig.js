(function(){var i=window.WPPConfig&&typeof window.WPPConfig=="object"?window.WPPConfig:{};window.WPPConfig=Object.assign({},i,{linkPreviewApiServers:[],disableGoogleAnalytics:!0})})();
