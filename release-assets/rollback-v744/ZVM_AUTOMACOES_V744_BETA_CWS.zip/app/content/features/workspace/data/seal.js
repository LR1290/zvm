(function(t){"use strict";if(!t.__extWorkspaceStaticData)throw new Error("Dados estáticos ausentes.");Object.freeze(t.__extWorkspaceStaticData)})(window);
